package jp.co.jsbank.mobile.bff.config.filter;

/**
 * リクエストパラメータフィルター
 */
public class CharacterCheck {

    /**
     * 第2水準の文字種チェック<br />
     * 半角英数記号・全角英数記号・全角カタカナ・全角ひらがな・漢字（第一水準・第二水準）は許容する。
     *
     * @param str チェック対象文字列
     * @return true:エラーあり/false:エラーなし
     */
    public static boolean checkForbiddenCharacter(String str) {
        char[] charArray = str.toCharArray();
		for (char c : charArray) {
			// JISコードの配列で取得
			int targetChar = getSJISByte(c);

			// 半角文字OK(『?』以外)
			if ((0x20 <= targetChar && targetChar <= 0x3D) || (0x40 <= targetChar && targetChar <= 0x7E)) {
				continue;
			} else if (targetChar == 0x3F) {
				// // 半角文字『?』について、入力文字が『?』であればOK
				if ("?".equals(String.valueOf(c)) || "―".equals(String.valueOf(c)) || "－".equals(String.valueOf(c))) {
					continue;
				} else {
					return true;
				}
			} else if (targetChar == 63) {

				// 半角カナOK
				continue;
			} else if (0xA1 <= targetChar && targetChar <= 0xDF) {

				// 半角カナOK
				continue;
			} else if (0x8140 <= targetChar && targetChar <= 0x84BE) {

				// 全角非漢字OK
				continue;
			} else if (0x889F <= targetChar && targetChar <= 0x9872) {

				// 第一水準OK
				continue;
			} else if ((0x989F <= targetChar && targetChar <= 0x9FFC)
					|| (0xE040 <= targetChar && targetChar <= 0xEAA4)) {

				// 第二水準OK
				continue;
			} else if (0xFA56 == targetChar) {

				// 全角アポストロフィ"'" OK
				continue;
			} else {

				// NG
				return true;
			}
		}
        return false;
    }

    /**
     * Shift-JISでバイト変換
     *
     * @param c 変換対象文字
     * @return 変換後文字列
     */
    private static int getSJISByte(char c) {
        int targetChar = 0;
        try {
            // MS932でバイト変換
            byte[] byteArray = String.valueOf(c).getBytes("Shift-JIS");
            if (byteArray.length <= 1) {
                // 半角文字
                targetChar = (byteArray[0] & 0xFF);
            } else {
                // 全角文字
                targetChar = (((byteArray[0] & 0xFF) * 0x100) + (byteArray[1] & 0xFF));
            }
        } catch (Exception e) {
        }
        return targetChar;
    }
}

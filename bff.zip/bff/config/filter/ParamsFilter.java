package jp.co.jsbank.mobile.bff.config.filter;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.servlet.FilterChain;
import javax.servlet.ReadListener;
import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.assertj.core.util.Arrays;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.util.Base64Utils;
import org.springframework.web.filter.OncePerRequestFilter;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import jp.co.jsbank.mobile.bff.common.Constant;
import jp.co.jsbank.mobile.bff.common.ErrorCodeConstant;
import jp.co.jsbank.mobile.bff.common.ErrorResult;
import jp.co.jsbank.mobile.bff.common.MessageIdConstant;
import jp.co.jsbank.mobile.bff.common.RequestHeaderContext;
import jp.co.jsbank.mobile.bff.common.util.DecryptorHelper;
import jp.co.jsbank.mobile.bff.common.util.MessageUtils;
import jp.co.jsbank.mobile.bff.config.Config;

/**
 * リクエストパラメータフィルター
 */
public class ParamsFilter extends OncePerRequestFilter {

	private static Logger logger = LoggerFactory.getLogger(ParamsFilter.class);

	private static final String METHOD_POST = "POST";
	private static final String METHOD_PUT = "PUT";
	private static final String REQUEST_ENCODING = "UTF-8";
	private static final String RESPONSE_ENCODING = "text/html;charset=utf-8";
	private static final String CLASSTYPE = "java.lang.String";

    /**
     * 金融機関コード
     */
    private String bankCode = "1344";
    /**
     * アプリケーションID
     */
    private String applicationID = "jsbapp01";
    /**
     * クライアントID
     */
    private String clientID = "010000";
    /**
     * 端末識別するID
     */
    private String deviceMk = "sm";
    /**
     * フォーマット
     */
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS z");
    /**
     * 区切りの文字列
     */
    private String splitValue = " ";
	/**
	 * 本人照合パス
	 */
	private static final String[] UNEXCLUDE_URLS = new String[] { "/account-opening/AB0701", "/account-opening/AB0702",
			"/account-opening/AB0703", "/account-opening/AB0704", "/account-opening/AB0705", "/account-opening/AB0706",
			"/account-opening/AB0707", "/account-opening/AB0708", "/account-opening/AB0709", "/account-opening/AB0710",
			"/account-opening/AB0711", "/account-opening/AB0712", "/account-opening/AB0713", "/account-opening/AB0714",
			"/account-opening/AB0715", "/account-opening/AB0718", "/account-opening/AB0719", "/account-opening/AB0716",
			"/account-opening/AB0717", "/account-opening/AB0720", "/account-opening/AB0721", "/cashcard-issue/AB0802",
			"/cashcard-issue/AB0803", "/cashcard-issue/AB0804", "/cashcard-issue/AB0805", "/cashcard-issue/AB0807",
			"/cashcard-issue/AB0808", "/easy-reception/AB0901", "/easy-reception/AB0904", "/easy-reception/AB0906",
			"/sign-up/AB0101", "/sign-up/AB0102", "/sign-up/AB0103", "/sign-up/AB0105", "/sign-up/AB0106",
			"/sign-up/AB0112", "/ekyc/AB1201", "/ekyc/AB1202", "/ekyc/AB1203" };

	/**
	 * health用除外されたURL
	 */
	private static final String[] EXCLUDE_URLS = new String[] { "/health/liveness", "/health/readiness" };

	// 暗号化種別.
	private static final String JAG_CRYPT_TYPE_AES = "AES";
	private static final String JAG_CRYPT_TYPE_AES_CBC_PKCS5PADDING = "AES/CBC/PKCS5Padding";
	private static final String JAG_CRYPT_TYPE_SHA256 = "SHA-256";

	// KEY長
	// AESの場合はBYTE指定. 16byte -> 128bit長. 32byte -> 256bit長.
	private static final int JAG_CRYPT_AES_KEY_LENGTH_128BIT = 16; // AES 128bit, 16*8 = 128bit.
	private static final int JAG_CRYPT_AES_DEFAULT_KEY_LENGTH = JAG_CRYPT_AES_KEY_LENGTH_128BIT; // AES 128bit.

	@Override
	public void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		request.setCharacterEncoding(REQUEST_ENCODING);
		response.setContentType(RESPONSE_ENCODING);

		// リクエストヘッダ関連処理
		String checkResult;
		try {
			checkResult = this.initHeaderContext(request);

			if (!StringUtils.isBlank(checkResult) && !isExcludedUrl(request)) {

				response.setStatus(HttpStatus.BAD_REQUEST.value());
				// エラークラス
				ErrorResult errorResult = new ErrorResult();

                // エラーコード設定
                errorResult.setErrorCode(MessageIdConstant.MESSAGE_ID_MBAP0001);
                // エラーメッセージ設定
                errorResult.setErrorMessage(
                        MessageUtils.getMessageText(MessageIdConstant.MESSAGE_ID_MBAP0001, checkResult,MessageIdConstant.MESSAGE_ID_MBAP0001));
                response.getWriter().write(JSONObject.toJSONString(errorResult));
                // ログ出力
                logger.warn(splicingLogInfo(ErrorCodeConstant.LOG_LABLE_W, "", MessageIdConstant.MESSAGE_ID_MBAP0001));
				return;
			}
		} catch (Exception e) {
			for (StackTraceElement elm : e.getStackTrace())
				logger.info(Constant.STRDEF_AT + elm.toString());
			Optional.ofNullable(e.getCause()).ifPresent(cause -> {
				logger.info(Constant.STRDEF_CAUSED_BY + cause.toString());
				Arrays.asList(cause.getStackTrace()).stream().forEach(ste -> logger.info(Constant.STRDEF_AT + ste.toString()));
			});
			// 予期せぬエラーが発生しました。しばらく時間をおいてからアクセスいただくか、窓口へお問い合わせください。{0}+{1}
			makeMBAP0009ErrorMessage(response);

			return;
		}

		if (!isExcludedUrl(request)) {
			String bffVersion = "1.0.0";
			if ("1".equals(request.getHeader("os"))) {
				if (Constant.JBA_RETAIL.equals(request.getHeader("applicationId"))) {
					bffVersion = Config.getAndroidRetailVersion();
				} else {
					bffVersion = Config.getAndroidBizzVersion();
				}
			} else {
				if (Constant.JBA_RETAIL.equals(request.getHeader("applicationId"))) {
					bffVersion = Config.getIosRetailVersion();
				} else {
					bffVersion = Config.getIosBizzVersion();
				}
			}
			// バージョンチェック
			int diff = compareVersion(request.getHeader("version"), bffVersion);
			if (diff < 0) {
				response.setStatus(HttpStatus.UPGRADE_REQUIRED.value());
				// エラークラス
				ErrorResult errorResult = new ErrorResult();

				// エラーコード設定
				errorResult.setErrorCode(MessageIdConstant.MESSAGE_ID_MBAP0006);
				// エラーメッセージ設定
				errorResult.setErrorMessage(MessageUtils.getMessageText(MessageIdConstant.MESSAGE_ID_MBAP0006,MessageIdConstant.MESSAGE_ID_MBAP0006));
				response.getWriter().write(JSONObject.toJSONString(errorResult));
                logger.info(splicingLogInfo(ErrorCodeConstant.LOG_LABLE_I, "", MessageIdConstant.MESSAGE_ID_MBAP0006));
				return;
			}
		}

		CustomHttpServletRequestWrapper requestWrapper = null;
		try {
			requestWrapper = new CustomHttpServletRequestWrapper(request);
			Map<String, Object> dataMap = new HashMap<String, Object>();

			// リクエスト請求の判断
			if (METHOD_POST.equals(requestWrapper.getMethod()) || METHOD_PUT.equals(requestWrapper.getMethod())) {

				String postData = getPostData(requestWrapper);
                logger.debug("引数："+ postData);
				dataMap = modifyParams(postData);
			} else {
				dataMap = modifyParameters(requestWrapper.getParameterMap());
			}

			if (Objects.nonNull(dataMap) && !isExcludedUrl(request)) {
				for (String key : dataMap.keySet()) {

					// 文字種チェック
					if (CharacterCheck.checkForbiddenCharacter(dataMap.get(key).toString())) {

						response.setStatus(HttpStatus.BAD_REQUEST.value());
						// エラークラス
						ErrorResult errorResult = new ErrorResult();

                        // エラーコード設定
                        errorResult.setErrorCode(MessageIdConstant.MESSAGE_ID_MBAP0011);
                        // エラーメッセージ設定
                        errorResult.setErrorMessage(MessageUtils.getMessageText(MessageIdConstant.MESSAGE_ID_MBAP0011,
                                MessageIdConstant.MESSAGE_ID_MBAP0011, ErrorCodeConstant.LOG_LABLE_W));
                        logger.warn(splicingLogInfo(ErrorCodeConstant.LOG_LABLE_W, "", MessageIdConstant.MESSAGE_ID_MBAP0011));
                        response.getWriter().write(JSONObject.toJSONString(errorResult));
						return;
					}
				}
			}
		} catch (Exception e) {
			for (StackTraceElement elm : e.getStackTrace())
				logger.info(Constant.STRDEF_AT + elm.toString());
			Optional.ofNullable(e.getCause()).ifPresent(cause -> {
				logger.info(Constant.STRDEF_CAUSED_BY + cause.toString());
				Arrays.asList(cause.getStackTrace()).stream().forEach(ste -> logger.info(Constant.STRDEF_AT + ste.toString()));
			});
			// 予期せぬエラーが発生しました。しばらく時間をおいてからアクセスいただくか、窓口へお問い合わせください。{0}+{1}
			makeMBAP0009ErrorMessage(response);

			return;
		}

		filterChain.doFilter(requestWrapper, response);
	}

	/**
	 * バージョンチェック
	 * @param appVersion アプリバージョン
	 * @param bffVersion BFFバージョン
	 * @return チェック結果
	 */
	private static int compareVersion(String appVersion, String bffVersion) {

		// バージョン一致
		if (appVersion.equals(bffVersion)) {
			return 0;
		}

		String[] appVersions = appVersion.split("\\.");
		String[] bffVersions = bffVersion.split("\\.");
		int idx = 0;
		int minLength = Math.min(appVersions.length, bffVersions.length);
		int diff = 0;
		while (idx < minLength && (diff = appVersions[idx].length() - bffVersions[idx].length()) == 0
				&& (diff = appVersions[idx].compareTo(bffVersions[idx])) == 0) {
			++idx;
		}
		diff = (diff != 0) ? diff : appVersions.length - bffVersions.length;
		return diff;
	}

	/**
	 * MBAP0009エラーメッセージ作成
	 * 「予期せぬエラーが発生しました。しばらく時間をおいてからアクセスいただくか、窓口へお問い合わせください。{0}+{1}」
	 *
	 * @param response レスポンス
	 * @throws IOException IO異常
	 */
	private void makeMBAP0009ErrorMessage(HttpServletResponse response) throws IOException {

		response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
		// エラークラス
		ErrorResult errorResult = new ErrorResult();

        // エラーコード設定
        errorResult.setErrorCode(MessageIdConstant.MESSAGE_ID_MBAP0009);
        // エラーメッセージ設定
        errorResult.setErrorMessage(MessageUtils.getMessageText(MessageIdConstant.MESSAGE_ID_MBAP0009,
                MessageIdConstant.MESSAGE_ID_MBAP0009, ErrorCodeConstant.LOG_LABLE_I));
        response.getWriter().write(JSONObject.toJSONString(errorResult));

        logger.info(splicingLogInfo(ErrorCodeConstant.LOG_LABLE_I, "", MessageIdConstant.MESSAGE_ID_MBAP0011));
	}

	/**
	 * リクエストヘッダ関連処理
	 *
	 * @param request HTTP請求
	 * @return リクエストヘッダ
	 * @throws Exception 異常
	 */
	private String initHeaderContext(HttpServletRequest request) throws Exception {

		// 処理結果
		String result = "";

		// 取引ID
		String transactionID = request.getHeader("transactionID");
		// アプリケーションID
		String applicationId = request.getHeader("applicationId");
		// 端末ID
		String deviceId = request.getHeader("deviceId");
		// 利用者IDトークン
		String userIdToken = request.getHeader("userIdToken");
		// バンキングIDトークン
		String jbaIdToken = request.getHeader("jbaIdToken");
		// バージョン
		String version = request.getHeader("version");
		// OS
		String os = request.getHeader("os");
		// 画面ID
		String screenID = request.getHeader("screenID");
		// イベントID
		String eventID = request.getHeader("eventID");
		// 認可トークン
		String jagBearerToken = request.getHeader("jagBearerToken");
		// AESによる復号化
		String decriptedStr = "";

		StringBuffer stringBuffer = new StringBuffer();

		// 取引IDチェック
		if (StringUtils.isBlank(transactionID)) {

			stringBuffer.append("取引ID,");
		}

		// アプリケーションIDチェック
		if (StringUtils.isBlank(applicationId)) {

			stringBuffer.append("アプリケーションID,");
		}

		// 端末IDチェック
		if (StringUtils.isBlank(deviceId)) {

			stringBuffer.append("端末ID,");
		}

		// リクエストパス
		String uri = request.getRequestURI();

		List<Object> excludeUrlsList = Arrays.asList(UNEXCLUDE_URLS);

		if (!excludeUrlsList.contains(uri)) {

			// 利用者IDトークンチェック
			if (StringUtils.isBlank(userIdToken)) {

				stringBuffer.append("利用者ID,");
			}

			// バンキングIDトークン
			if (StringUtils.isBlank(jbaIdToken)) {

				stringBuffer.append("バンキングID,");
			}
		}

		// バージョンチェック
		if (StringUtils.isBlank(version)) {

			stringBuffer.append("バージョン,");
		}

		// アプリケーションIDチェック
		if (StringUtils.isBlank(os)) {

			stringBuffer.append("OS,");
		}

		// 画面IDチェック
		if (StringUtils.isBlank(screenID)) {

			stringBuffer.append("画面ID,");
		}

		// イベントIDチェック
		if (StringUtils.isBlank(eventID)) {

			stringBuffer.append("イベントID,");
		}

		// 認可トークンチェック
		if (StringUtils.isBlank(jagBearerToken)) {

			stringBuffer.append("認可トークン,");
		} else if (!isExcludedUrl(request)) {
			decriptedStr = decryptAESByJavaCrypt(jagBearerToken, Config.getSecretKey(), Config.getSalt());
			decriptedStr = decriptedStr.split("_")[1];

		}

		if (!StringUtils.isBlank(stringBuffer)) {

			stringBuffer.replace(stringBuffer.length() - 1, stringBuffer.length(), "");

			return stringBuffer.toString();
		}

		new RequestHeaderContext.RequestHeaderContextBuild().transactionID(transactionID).applicationId(applicationId)
				.deviceId(deviceId).userIdToken(userIdToken).jbaIdToken(jbaIdToken).version(version).os(os)
				.screenID(screenID).eventID(eventID).jagBearerToken(decriptedStr).bulid();

		return result;
	}

	/**
	 * AESによる復号化. 実装は JavaCrypt が提供するものを利用する. 適用アルゴリズム:
	 * AES/CBC/PKCS5Padding(128bit).
	 *
	 * @param encStr 暗号化文字
	 * @param secret キー
	 * @param salt   シークレット文字列
	 * @return 復号化結果
	 * @throws Exception 異常
	 */
	public static String decryptAESByJavaCrypt(String encStr, String secret, String salt) throws Exception {

		// IvParameterSpecのインスタンスを取得する.
		IvParameterSpec iv = getIvParameterSpecFromSalt(salt);
		SecretKeySpec key = getSecretSpecFromSecretKeyString(secret);

		// 暗号器と暗号モードを設定する.
		Cipher decrypter;
		try {

			decrypter = Cipher.getInstance(JAG_CRYPT_TYPE_AES_CBC_PKCS5PADDING);
		} catch (NoSuchAlgorithmException | NoSuchPaddingException e) {

			throw new Exception(e);
		}
		try {

			decrypter.init(Cipher.DECRYPT_MODE, key, iv);
		} catch (InvalidKeyException | InvalidAlgorithmParameterException e) {

			throw new Exception(e);
		}

		// 復号化を実施する.
		byte[] encBytes = Base64Utils.decodeFromString(encStr);
		String decryptStr;
		try {
			byte[] decBytes = decrypter.doFinal(encBytes);
			decryptStr = new String(decBytes, StandardCharsets.UTF_8);
		} catch (IllegalBlockSizeException | BadPaddingException e) {

			throw new Exception(e);
		}
		return decryptStr;
	}

	/**
	 * シークレット文字列からSecretKeySpecのインスタンスを取得する.
	 *
	 * @param secret キー
	 * @return 処理結果
	 */
	private static SecretKeySpec getSecretSpecFromSecretKeyString(String secret) {
		byte[] secretKeyBytes = secret.getBytes(StandardCharsets.UTF_8);
		SecretKeySpec key = new SecretKeySpec(secretKeyBytes, JAG_CRYPT_TYPE_AES);
		return key;
	}

	/**
	 * SALT文字列からIvParameterSpecのインスタンスを取得する.
	 *
	 * TODO: SALTからIV(Initial Vector)を生成する方法はIESと要すり合わせ. 現状は以下の実装をもとに生成すること.
	 *
	 * @param salt シークレット文字列
	 * @return SALT文字列
	 * @throws Exception 異常
	 */
	private static IvParameterSpec getIvParameterSpecFromSalt(String salt) throws Exception {
		byte[] iv = new byte[JAG_CRYPT_AES_DEFAULT_KEY_LENGTH];
		try {
			// SHA256によるダイジェスト取得.
			MessageDigest digest = MessageDigest.getInstance(JAG_CRYPT_TYPE_SHA256);
			digest.reset();
			digest.update(salt.getBytes(StandardCharsets.UTF_8));
			byte[] digestBytes = digest.digest(); // 32byte取得される想定.

			// 検査する.
			if (digestBytes.length < JAG_CRYPT_AES_DEFAULT_KEY_LENGTH) {

				throw new Exception();
			}

			// 指定されたバイト数を取得する.
			for (int i = 0; i < iv.length; i++) {

				iv[i] = digestBytes[i];
			}

		} catch (NoSuchAlgorithmException e) {
			throw new Exception(e);
		}

		return new IvParameterSpec(iv);
	}

	/**
	 * パラメータのスペースを削除する
	 *
	 * @param params リクエスト請求パラメータ
	 * @return パラメータ
	 */
	private Map<String, Object> modifyParameters(Map<String, String[]> params) {

		Map<String, Object> getMap = new HashMap<String, Object>();

		Set<String> set = params.keySet();

		Iterator<String> it = set.iterator();

		while (it.hasNext()) {

			String key = (String) it.next();

			String values = params.get(key)[0];

			values = values.trim();

			getMap.put(key, values);
		}

		return getMap;
	}

	/**
	 * postデータを取得する
	 *
	 * @param request HTTP請求
	 * @return パラメータ
	 */
	private static String getPostData(CustomHttpServletRequestWrapper request) {
		return new String(request.getBody());
	}

	/**
	 * postデータを取得する
	 *
	 * @param json post請求
	 * @return パラメータ
	 */
	private static Map<String, Object> modifyParams(String json) {

		Map<String, Object> params = JSON.parseObject(json);

		if (Objects.nonNull(params)) {

			Map<String, Object> maps = new HashMap<>(params.size());

			for (String key : params.keySet()) {

				Object value = getValue(params.get(key));

				maps.put(key, value);
			}

			return maps;
		}

		return null;
	}

	/**
	 * 除外されたURL判定
	 *
	 * @param request HTTPリクエスト
	 * @return 結果
	 */
	private static boolean isExcludedUrl(HttpServletRequest request) {
		String uri = request.getRequestURI();
		List<Object> excludeUrlsList = Arrays.asList(EXCLUDE_URLS);

		if (excludeUrlsList.contains(uri)) {
			return true;
		}

		return false;
	}

	/**
	 * postデータを取得する
	 *
	 * @param obj パラメータ
	 * @return パラメータ
	 */
	private static Object getValue(Object obj) {

		if (obj == null) {

			return null;
		}

		String type = obj.getClass().getName();

		// スペースを削除する
		if (CLASSTYPE.equals(type)) {

			obj = obj.toString().trim();
		}

		return obj;
	}

	@Override
	public void destroy() {
	}

	static class CustomHttpServletRequestWrapper extends HttpServletRequestWrapper {

		private byte[] body;

		/**
		 * getBody
		 *
		 * @param request HTTPリクエスト請求
		 */
		CustomHttpServletRequestWrapper(HttpServletRequest request) throws Exception {
			super(request);

			String commonKey = request.getHeader("jagBearerToken");

			if (!isExcludedUrl(request)) {
				commonKey = decryptAESByJavaCrypt(commonKey, Config.getSecretKey(), Config.getSalt());
				commonKey = commonKey.split("_")[1];

			}

			BufferedReader reader = request.getReader();
			try (StringWriter writer = new StringWriter()) {
				int read;
				char[] buf = new char[1024 * 8];
				while ((read = reader.read(buf)) != -1) {
					writer.write(buf, 0, read);
				}
				String bodyJson = writer.getBuffer().toString();
				if (!bodyJson.isEmpty()) {
					bodyJson = DecryptorHelper.decrypt(bodyJson, commonKey);

				}

				this.body = bodyJson.getBytes();
			}
		}

		public byte[] getBody() {
			return body;
		}

		@Override
		public ServletInputStream getInputStream() throws IOException {
			ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(body);
			return new ServletInputStream() {

				@Override
				public int read() throws IOException {
					return byteArrayInputStream.read();
				}

				@Override
				public void setReadListener(ReadListener listener) {
				}

				@Override
				public boolean isReady() {
					return false;
				}

				@Override
				public boolean isFinished() {
					return false;
				}
			};
		}
	}

    /**
     * メッセージ内容
     *
     * @param ex 例外
     * @param message メッセージ
     * @param msgId メッセージID
     * @param logLabel ログレベル
     * @return メッセージ
     */
    private String splicingLogInfo( String logLabel, String message, String msgId) {

        // ログ出力時のタイムスタンプ
        String currentTimestamp = "";
        // 取引ID
        String transactionID = RequestHeaderContext.getInstance().getTransactionID();
        // ユーザーID
        String userID = "";
        // 端末ID
        String deviceID = "";
        // 出力箇所
        String invokerName = "";
        // メッセージID
        String messageID = msgId;
        // ログメッセージ本文
        String messageBody = message;
        // 画面ID
        String gcreenID = "";
        // イベントID
        String eventID = "";
        // 取引通番
        String transactionSeqNo = "";
        // トレースID
        String traceID = "";
        // スレッドID
        String threadID = "";
        // 重大度
        String severity = logLabel;
        // コンテキスト・ルート名
        String contextRoot = "";
        // API識別子
        String apiID = "";
        // AIFログレベル
        String aifLogLvNum = "";
        // AIFロガー名
        String aifLogType = "";
        // AIF追跡番号
        String aifTtracNo = "";
        // OS
        String os = "";
        // バージョン
        String version = "";

        // スタックエラーメッセージ情報解析
       invokerName = "ParamsFilter" + "#" + "";


        currentTimestamp = sdf.format(new Date());

        userID = StringUtils.isBlank(RequestHeaderContext.getInstance().getUserIdToken())
                ? RequestHeaderContext.getInstance().getDeviceId()
                : RequestHeaderContext.getInstance().getUserIdToken();
        deviceID = deviceMk + RequestHeaderContext.getInstance().getDeviceId().replace("-", "").toLowerCase();

        gcreenID = RequestHeaderContext.getInstance().getScreenId();
        eventID = RequestHeaderContext.getInstance().getEventID();
        os = RequestHeaderContext.getInstance().getOs();
        version = RequestHeaderContext.getInstance().getVersion();

        StringBuffer sb = new StringBuffer();
        sb.append(currentTimestamp + splitValue);
        sb.append(bankCode + splitValue);
        sb.append(userID + splitValue);
        sb.append(applicationID + splitValue);
        sb.append(clientID + splitValue);
        sb.append(deviceID + splitValue);
        sb.append(messageID + splitValue);
        sb.append(severity + splitValue);
        sb.append(contextRoot + splitValue);
        sb.append(aifLogLvNum + splitValue);
        sb.append(aifLogType + splitValue);
        sb.append(aifTtracNo + splitValue);
        sb.append(traceID + splitValue);
        sb.append(transactionID + splitValue);
        sb.append(transactionSeqNo + splitValue);
        sb.append(threadID + splitValue);
        sb.append(apiID + splitValue);
        sb.append(invokerName + splitValue);
        sb.append(messageBody + splitValue);
        sb.append(gcreenID + splitValue);
        sb.append(eventID + splitValue);
        sb.append(os + splitValue);
        sb.append(version + splitValue);

        return sb.toString();

    }
}

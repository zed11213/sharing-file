package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 共通リクエスト・ヘッダ
 */
@Data
public class CommonRequestHeader {

    /**
     * 取引ID
     */
    private String transactionID;

    /**
     * 取引通番
     */
    private String transactionSeqNo;

    /**
     * トレースID
     */
    private String traceID;

    /**
     * 経路選択情報
     */
    private String routingInfo;
}

package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * ファイルストリームDTO
 */
@Data
public class FileStreamDto {

    /**
     * 書類種類
     */
    private String documentsType;

    /**
     * ファイル名
     */
    private String fileName;

    /**
     * ファイルストリーム
     */
    private String fileStream;
}

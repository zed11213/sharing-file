package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 営業地区部店DTO
 */
@Data
public class DepartmentStoreDto {
    /**
     * 地区コード
     */
    private String addressCode;
    /**
     * 店番
     */
    private String branchNumber;
    /**
     * 地区区分
     */
    private String areaCode;
    /**
     * 都道府県漢字
     */
    private String prefecture;
    /**
     * 市区町村漢字
     */
    private String city;
    /**
     * 町漢字
     */
    private String addrDetail1;
    /**
     * 丁目漢字
     */
    private String addrDetail2;
    /**
     * 地区郵便番号
     */
    private String areaZipCode;
    /**
     * 金融機関コード
     */
    private String bankCode;
    /**
     * 店名（漢字）
     */
    private String branchKanjiName;
    /**
     * 所属部門区分
     */
    private String divisionType;
    /**
     * 照会店舗タイプ
     */
    private String branchInquiryType;
    /**
     * 支店郵便番号
     */
    private String branchZipCode;
    /**
     * 店舗住所
     */
    private String branchKanjiAddress;
    /**
     * 電話番号
     */
    private String phoneNumber;
    /**
     * 店舗案内
     */
    private String branchGuide;
    /**
     * 緯度
     */
    private String latitude;
    /**
     * 経度
     */
    private String longitude;
    /**
     * 表示グループ名
     */
    private String displayGroupName;
    /**
     * 表示順
     */
    private String displayOrder;
}

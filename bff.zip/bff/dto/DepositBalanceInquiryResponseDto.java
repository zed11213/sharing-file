package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 預金残高照会レスポンスDTO
 */
@Data
public class DepositBalanceInquiryResponseDto {

    /**
     * CIF番号
     */
    private String cifNumber;

}

package jp.co.jsbank.mobile.bff.dto;

import java.util.List;

import lombok.Data;

/**
 * 口座開設申込情報（法人）DTO
 */
@Data
public class AccountOpeningApplicationCorporationInfoDto {

    /**
     * 受付番号
     */
    private String receiptNumber;

    /**
     * 顧客ID
     */
    private String customerId;

    /**
     * CIF番号
     */
    private String cifNumber;

    /**
     * 人格区分
     */
    private String personType;

    /**
     * 申込ステータス
     */
    private String applyStatus;

    /**
     * 申請開始日時
     */
    private String applyStartDateTime;

    /**
     * 申請有効期限日時
     */
    private String applyValidDateTime;

    /**
     * 利用停止フラグ
     */
    private String useSuspendFlag;

    /**
     * 取引種別
     */
    private String transactionType;

    /**
     * 会社形態
     */
    private String companyForm;

    /**
     * 会社形態（その他）
     */
    private String companyFormOther;

    /**
     * 会社形態位置
     */
    private String companyFormLocation;

    /**
     * 事業先名（カナ）
     */
    private String businessNameKana;

    /**
     * 事業先名（漢字）
     */
    private String businessNameKanji;

    /**
     * 設立年月日
     */
    private String establishDate;

    /**
     * 資本金
     */
    private String capital;

    /**
     * 従業員人数
     */
    private String numberOfEmployees;

    /**
     * 事業先電話番号種別
     */
    private String businessPhoneType;

    /**
     * 事業先電話番号（上）
     */
    private String businessPhoneNumFirst;

    /**
     * 事業先電話番号（中）
     */
    private String businessPhoneNumMid;

    /**
     * 事業先電話番号（下）
     */
    private String businessPhoneNumLast;

    /**
     * 代表者・役員リスト
     */
    private List<RepresentativeOfficerDto> ceoOfficer;

    /**
     * 代表者氏名カナ（姓）
     */
    private String ceoKanaLast;

    /**
     * 代表者氏名カナ（名）
     */
    private String ceoKanaFirst;

    /**
     * 代表者氏名漢字（姓）
     */
    private String ceoKanjiLast;

    /**
     * 代表者氏名漢字（名）
     */
    private String ceoKanjiFirst;

    /**
     * 代表者生年月日
     */
    private String ceoBirthday;

    /**
     * 代表者郵便番号
     */
    private String ceoZipCode;

    /**
     * 代表者都道府県（カナ）
     */
    private String ceoStateKana;

    /**
     * 代表者都道府県
     */
    private String ceoState;

    /**
     * 代表者市区町村（カナ）
     */
    private String ceoCityKana;

    /**
     * 代表者市区町村
     */
    private String ceoCity;

    /**
     * 代表者丁目（カナ）
     */
    private String ceoStreetKana;

    /**
     * 代表者丁目
     */
    private String ceoStreet;

    /**
     * 代表者番地（カナ）
     */
    private String ceoAddressKana;

    /**
     * 代表者番地
     */
    private String ceoAddress;

    /**
     * 代表者建物名・号室（カナ）
     */
    private String ceoBuildingKana;

    /**
     * 代表者建物名・号室
     */
    private String ceoBuilding;

    /**
     * 実質的支配者リスト
     */
    private List<BeneficialOwnerDto> substantialRuler;

    /**
     * 所在地郵便番号
     */
    private String locationZipCode;

    /**
     * 所在地都道府県（カナ）
     */
    private String locationStateKana;

    /**
     * 所在地都道府県
     */
    private String locationState;

    /**
     * 所在地市区町村（カナ）
     */
    private String locationCityKana;

    /**
     * 所在地市区町村
     */
    private String locationCity;

    /**
     * 所在地丁目（カナ）
     */
    private String locationStreetKana;

    /**
     * 所在地丁目
     */
    private String locationStreet;

    /**
     * 所在地番地（カナ）
     */
    private String locationAddressKana;

    /**
     * 所在地番地
     */
    private String locationAddress;

    /**
     * 建物名・号室（カナ）
     */
    private String buildingRoomKana;

    /**
     * 建物名・号室
     */
    private String buildingRoom;

    /**
     * 本店所在地相違区分
     */
    private String headOfficeClassification;

    /**
     * 本店所在地郵便番号
     */
    private String headOfficeLocZipCode;

    /**
     * 本店所在地都道府県（カナ）
     */
    private String headOfficeLocStateKana;

    /**
     * 本店所在地都道府県
     */
    private String headOfficeLocState;

    /**
     * 本店所在地市区町村（カナ）
     */
    private String headOfficeLocCityKana;

    /**
     * 本店所在地市区町村
     */
    private String headOfficeLocCity;

    /**
     * 本店所在地丁目（カナ）
     */
    private String headOfficeLocStreetKana;

    /**
     * 本店所在地丁目
     */
    private String headOfficeLocStreet;

    /**
     * 本店所在地番地（カナ）
     */
    private String headOfficeLocAddressKana;

    /**
     * 本店所在地番地
     */
    private String headOfficeLocAddress;

    /**
     * 本店建物名・号室（カナ）
     */
    private String headOfficeLocBuildingKana;

    /**
     * 本店建物名・号室
     */
    private String headOfficeLocBuilding;

    /**
     * 電話番号種別１
     */
    private String phoneType1;

    /**
     * 自宅電話番号１（上）
     */
    private String homePhone1Top;

    /**
     * 自宅電話番号１（中）
     */
    private String homePhone1Middle;

    /**
     * 自宅電話番号１（下）
     */
    private String homePhone1Bottom;

    /**
     * 電話番号種別２
     */
    private String phoneType2;

    /**
     * 自宅電話番号２（上）
     */
    private String homePhone2Top;

    /**
     * 自宅電話番号２（中）
     */
    private String homePhone2Middle;

    /**
     * 自宅電話番号２（下）
     */
    private String homePhone2Bottom;

    /**
     * 取引目的
     */
    private String transactPurpose;

    /**
     * 取引目的（その他）
     */
    private String transactPurposeOther;

    /**
     * 取引目的（詳細）
     */
    private String transactPurposeDetail;

    /**
     * 事業内容
     */
    private String businessDescription;

    /**
     * 事業内容（その他）
     */
    private String businessDescriptionOther;

    /**
     * 取扱品目
     */
    private String handingItem;

    /**
     * 主要取引先（仕入）
     */
    private String mainlyTradePurchase;

    /**
     * 主要取引先（販売）
     */
    private String mainlyTradeSale;

    /**
     * 当金庫との取引希望
     */
    private String preferredTrade;

    /**
     * 当金庫との取引希望（その他）
     */
    private String otherBusinessWishes;

    /**
     * 取引のきっかけ
     */
    private String transactionTrigger;

    /**
     * 開設部店コード
     */
    private String openBranchCode;

    /**
     * メールアドレス
     */
    private String emailAddress;

    /**
     * 取引金融機関
     */
    private String financialInstitution;

    /**
     * 取引金融機関（預金状況）
     */
    private String financialInstitutionDepositStatus;

    /**
     * 取引金融機関（貸金状況）
     */
    private String financialInstitutionLoanStatus;

    /**
     * 役員役職
     */
    private String position;

    /**
     * 役員カナ氏名（姓）
     */ 
    private String officerLastName;

    /**
     * 役員カナ氏名（名）
     */
    private String officerFirstName;

    /**
     * 役員漢字氏名（名）
     */
    private String	officerKanjiLastName;

    /**
     * 役員漢字氏名（名）
     */
    private String officerKanjiFirstName;

    /**
     * 役員生年月日
     */
    private String officerBirthday;
    
    /**
     * 役員郵便番号
     */
    private String officerZipCode;

    /**
     * 役員都道府県（カナ）
     */
    private String officerPrefectureKana;

    /**
     * 役員都道府県
     */
    private String officerPrefecture;

    /**
     * 役員市区町村（カナ）
     */
    private String officerCityKana;

    /**
     * 役員市区町村
     */
    private String officerCity;

    /**
     * 役員丁目（カナ）
     */
    private String officerStreetKana;

    /**
     * 役員丁目
     */
    private String officerStreet;

    /**
     * 役員番地（カナ）
     */
    private String officerAddressKana;

    /**
     * 役員番地
     */
    private String officerAddress;

    /**
     * 役員建物名・号室（カナ）
     */
    private String officerBuildingKana;

    /**
     * 役員建物名・号室
     */
    private String officerBuilding;

    /**
     * 役員電話番号種別
     */
    private String officerPhoneType;

    /**
     * 役員電話番号（上）
     */
    private String officerPhoneNumOneFirst;

    /**
     * 役員電話番号（中）
     */
    private String officerPhoneNumOneMid;

    /**
     * 役員電話番号（下）
     */
    private String officerPhoneNumOneLast;

    /**
     * 支配者カナ氏名（姓）
     */
    private String rulerLastName;

    /**
     * 支配者カナ氏名（名）
     */
    private String rulerFirstName;

    /**
     * 支配者漢字氏名（姓）
     */
    private String rulerKanjiLastName;

    /**
     * 支配者漢字氏名（名）
     */
    private String rulerKanjiFirstName;

    /**
     * 支配者生年月日
     */
    private String rulerBirth;

    /**
     * 支配者郵便番号
     */
    private String rulerZipCode;

    /**
     * 支配者都道府県（カナ）
     */
    private String rulerPrefectureKana;

    /**
     * 支配者都道府県
     */
    private String rulerPrefecture;

    /**
     * 支配者市区町村（カナ）
     */
    private String rulerCityKana;

    /**
     * 支配者市区町村
     */
    private String rulerCity;

    /**
     * 支配者丁目（カナ）
     */
    private String rulerStreetKana;

    /**
     * 支配者丁目
     */
    private String rulerStreet;

    /**
     * 支配者番地（カナ）
     */
    private String rulerAddressKana;

    /**
     * 支配者番地
     */
    private String rulerAddress;

    /**
     * 支配者建物名・号室（カナ）
     */
    private String rulerBuildingKana;

    /**
     * 配者建物名・号室
     */
    private String rulerBuilding;	

    /**
     * 代表者本人確認書類リスト
     */
    private List<IdentityVerificationDocumentsDto> identityDocuments;

    /**
     * 事業先本人確認書類リスト
     */
    private List<IdentityVerificationDocumentsDto> businessDocuments;
    
    /**
     * 本人確認書類URL
     */
    private String identityVerificationDocumentsUrl;
}

package jp.co.jsbank.mobile.bff.dto;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.aba.CifNumberDto;
import lombok.Data;

/**
 * かんたん登録画面入力情報送信リクエストDTO
 */
@Data
public class EasyRegistrationScreenInputInfoSendingRequestDto {

    /**
     * お知らせID
     */
    private String anncmntId;

    /**
     * 非会員フラグ
     */
    private String nonMemberFlg;

    /**
     * 顧客ID
     */
    private String customerId;

    /**
     * CIF番号リスト
     */
    private List<CifNumberDto> cifNoList;

    /**
     * カナ氏名
     */
    private String custNameKana;

    /**
     * 漢字氏名
     */
    private String custNameKanji;

    /**
     * 郵便番号
     */
    private String custZipCode;

    /**
     * カナ住所
     */
    private String custAddressKana;

    /**
     * 住所
     */
    private String custAddress;

    /**
     * 電話番号
     */
    private String custPhone;

    /**
     * メールアドレス
     */
    private String custMail;

    /**
     * 受付フォーマット
     */
    private String receptionFormat;

    /**
     * 窓口支店番号
     */
    private String contactBranchNum;

    /**
     * メッセージ内容種別
     */
    private String mobileMsgType;

    /**
     * タイトル
     */
    private String anncmntTitle;

    /**
     * 掲載開始日時
     */
    private String anncmntStartDateAndTime;

    /**
     * 掲載終了日時
     */
    private String anncmntEndDateAndTime;

    /**
     * 作成日時
     */
    private String createDateAndTime;

    /**
     * メール(ファイル授受サービス)
     */
    private String fileEmail;

    /**
     * 顧客番号(ファイル授受サービス)
     */
    private String customerNumber;

    /**
     * 誕生日-年(ファイル授受サービス)
     */
    private String birthYear;

    /**
     * 誕生日-月(ファイル授受サービス)
     */
    private String birthMonth;

    /**
     * 誕生日-日(ファイル授受サービス)
     */
    private String birthDayOfMonth;

    /**
     * ファイル授受サービス申込タイプ (0: 申込, 1: 利用停止)(ファイル授受サービス)
     */
    private String fileServiceApplyType;

    /**
     * 更新フラグ (1: 更新)(ファイル授受サービス)
     */
    private String isUpdate;
}

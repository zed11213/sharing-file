package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * CC暗証番号・IBパスワード設定BFFリクエストDTO
 */
@Data
public class CcPasswordIbPasswordSettingResponseDto {

    /**
     * IBパスワード
     */
    private String ibPassword;
    
    /**
     * CC暗証番号
     */
    private String ccPassword;
    
}
package jp.co.jsbank.mobile.bff.dto;

import java.util.List;

import lombok.Data;

/**
 * 口座開設申込情報（個人事業主）DTO
 */
@Data
public class AccountOpeningApplicationBusinessOwnerInfoDto {

    /**
     * 受付番号
     */
    private String receiptNumber;

    /**
     * 顧客ID
     */
    private String customerId;

    /**
     * CIF番号
     */
    private String cifNumber;

    /**
     * 人格区分
     */
    private String personType;

    /**
     * 申込ステータス
     */
    private String applyStatus;

    /**
     * 申請開始日時
     */
    private String applyStartDateTime;

    /**
     * 申請有効期限日時
     */
    private String applyValidDateTime;

    /**
     * 利用停止フラグ
     */
    private String useSuspendFlag;

    /**
     * 取引種別
     */
    private String transactionType;

    /**
     * 氏名カナ（姓）
     */
    private String nameKanaLast;

    /**
     * 氏名カナ（名）
     */
    private String nameKannFirst;

    /**
     * 氏名漢字（姓）
     */
    private String nameKanjiLast;

    /**
     * 氏名漢字（名）
     */
    private String nameKanjiFirst;

    /**
     * 生年月日
     */
    private String birthday;

    /**
     * 性別
     */
    private String gender;

    /**
     * 屋号カナ
     */
    private String roomNoKana;

    /**
     * 屋号
     */
    private String roomNo;

    /**
     * 従業員人数
     */
    private String numberOfEmployees;

    /**
     * 自宅郵便番号
     */
    private String homeZipCode;

    /**
     * 自宅都道府県（カナ）
     */
    private String homeStateKana;

    /**
     * 自宅都道府県
     */
    private String homeState;

    /**
     * 自宅市区町村（カナ）
     */
    private String homeCityKana;

    /**
     * 自宅市区町村
     */
    private String homeCity;

    /**
     * 自宅丁目（カナ）
     */
    private String homeStreetKana;

    /**
     * 自宅丁目
     */
    private String homeStreet;

    /**
     * 自宅番地（カナ）
     */
    private String homeAddressKana;

    /**
     * 自宅番地
     */
    private String homeAddress;

    /**
     * 自宅建物名・号室（カナ）
     */
    private String homeBuildingKana;

    /**
     * 自宅建物名・号室
     */
    private String homeBuilding;

    /**
     * 所在地郵便番号
     */
    private String locationZipCode;

    /**
     * 所在地都道府県（カナ）
     */
    private String locationStateKana;

    /**
     * 所在地都道府県
     */
    private String locationState;

    /**
     * 所在地市区町村（カナ）
     */
    private String locationCityKana;

    /**
     * 所在地市区町村
     */
    private String locationCity;

    /**
     * 所在地丁目（カナ）
     */
    private String locationStreetKana;

    /**
     * 所在地丁目
     */
    private String locationStreet;

    /**
     * 所在地番地（カナ）
     */
    private String locationAddressKana;

    /**
     * 所在地番地
     */
    private String locationAddress;

    /**
     * 建物名・号室（カナ）
     */
    private String buildingRoomKana;

    /**
     * 建物名・号室
     */
    private String buildingRoom;

    /**
     * 電話番号種別１
     */
    private String phoneType1;

    /**
     * 自宅電話番号１（上）
     */
    private String homePhone1Top;

    /**
     * 自宅電話番号１（中）
     */
    private String homePhone1Middle;

    /**
     * 自宅電話番号１（下）
     */
    private String homePhone1Bottom;

    /**
     * 電話番号種別２
     */
    private String phoneType2;

    /**
     * 自宅電話番号２（上）
     */
    private String homePhone2Top;

    /**
     * 自宅電話番号２（中）
     */
    private String homePhone2Middle;

    /**
     * 自宅電話番号２（下）
     */
    private String homePhone2Bottom;

    /**
     * 取引目的
     */
    private String transactPurpose;

    /**
     * 取引目的（その他 ）
     */
    private String transactPurposeOther;

    /**
     * 取引目的（詳細）
     */
    private String transactPurposeDetail;

    /**
     * 職業事業内容
     */
    private String businessDescription;

    /**
     * 職業事業内容（その他）
     */
    private String businessDescriptionOther;

    /**
     * 取扱品目
     */
    private String handingItem;

    /**
     * 主要取引先（仕入）
     */
    private String mainlyTradePurchase;

    /**
     * 主要取引先（販売）
     */
    private String mainlyTradeSale;

    /**
     * 当金庫との取引希望
     */
    private String preferredTrade;

    /**
     * 当金庫との取引希望（その他）
     */
    private String otherBusinessWishes;

    /**
     * 取引のきっかけ
     */
    private String transactionTrigger;

    /**
     * 開設部店コード
     */
    private String openBranchCode;

    /**
     * メールアドレス
     */
    private String emailAddress;

    /**
     * 取引金融機関
     */
    private String financialInstitution;

    /**
     * 取引金融機関（預金状況）
     */
    private String financialInstitutionDepositStatus;

    /**
     * 取引金融機関（貸金状況）
     */
    private String financialInstitutionLoanStatus;

    /**
     * 本人確認書類リスト
     */
    private List<IdentityVerificationDocumentsDto> identityDocuments;
    
    /**
     * 本人確認書類URL
     */
    private String identityVerificationDocumentsUrl;
}

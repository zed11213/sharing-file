package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 解約口座删除リクエストDTO
 */
@Data
public class CancellationAccountDeleteRequestDto {

    /**
     * 店番
     */
    private String branchNumber;

    /**
     * 口座番号
     */
    private String accountNumber;

    /**
     * 預金種目
     */
    private String accountType;
}

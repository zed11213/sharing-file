package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * メールアドレス変更BFFレスボスDTO
 */
@Data
public class EmailAddressChangingResponseDto {

    /**
     * 確認コード
     */
    private String confirmationCode;

    /**
     * 番号検証TRXキー
     */
    private String noVerifyTRXKey;
}

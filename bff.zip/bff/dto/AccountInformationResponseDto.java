package jp.co.jsbank.mobile.bff.dto;

import java.util.List;

import lombok.Data;

/**
 * 口座情報DTO
 */
@Data
public class AccountInformationResponseDto {

    /**
     * 口座情報DTOリスト
     */
    private List<AccountInformationDto> accountInformationList;

}

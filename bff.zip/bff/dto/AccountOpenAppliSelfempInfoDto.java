package jp.co.jsbank.mobile.bff.dto;

import java.util.List;

import lombok.Data;

/**
 * 口座開設申込情報（個人事業主）DTO
 */
@Data
public class AccountOpenAppliSelfempInfoDto {

	/**
	 * 受付番号
	 */
	private String receiptNumber;

	/**
	 * CIF番号
	 */
	private String cifNumber;

	/**
	 * 申込ステータス
	 */
	private String applyStatus;

	/**
	 * 取引種別
	 */
	private String transactionType;

	/**
	 * 人格コード
	 */
	private String personCode;

	/**
	 * 申込日
	 */
	private String applicationDate;

	/**
	 * 申請開始日時
	 */
	private String applyStartDateTime;

	/**
	 * 申請有効期限日時
	 */
	private String applyValidDateTime;

	/**
	 * バージョン
	 */
	private String version;

	/**
	 * カナ氏名（姓）
	 */
	private String customerLastName;

	/**
	 * カナ氏名（名）
	 */
	private String customerFirstName;

	/**
	 * 漢字氏名（姓）
	 */
	private String customerKanjiLastName;

	/**
	 * 漢字氏名（名）
	 */
	private String customerKanjiFirstName;

	/**
	 * 性別
	 */
	private String gender;

	/**
	 * 性別回答有無
	 */
	private String genderAnswer;

	/**
	 * 屋号カナ
	 */
	private String roomNoKana;

	/**
	 * 屋号
	 */
	private String roomNo;

	/**
	 * 従業員人数
	 */
	private String numberOfEmployees;

	/**
	 * 生年月日
	 */
	private String birthday;

	/**
	 * 郵便番号
	 */
	private String zipCode;

	/**
	 * 都道府県（カナ）
	 */
	private String prefectureKana;

	/**
	 * 都道府県
	 */
	private String prefecture;

	/**
	 * 市区町村（カナ）
	 */
	private String cityKana;

	/**
	 * 市区町村
	 */
	private String city;

	/**
	 * 丁目（カナ）
	 */
	private String addrDetail2Kana;

	/**
	 * 丁目
	 */
	private String addrDetail2;

	/**
	 * 番地（カナ）
	 */
	private String addrDetail3Kana;

	/**
	 * 番地
	 */
	private String addrDetail3;

	/**
	 * 建物名・号室（カナ）
	 */
	private String buildingRoomKana;

	/**
	 * 建物名・号室
	 */
	private String buildingRoom;

	/**
	 * 所在地相違区分
	 */
	private String locationClassification;

	/**
	 * 所在地郵便番号
	 */
	private String locationZipCode;

	/**
	 * 所在地都道府県（カナ）
	 */
	private String locationPrefectureKana;

	/**
	 * 所在地都道府県
	 */
	private String locationPrefecture;

	/**
	 * 所在地市区町村（カナ）
	 */
	private String locationCityKana;

	/**
	 * 所在地市区町村
	 */
	private String locationCity;

	/**
	 * 所在地丁目（カナ）
	 */
	private String locationStreetKana;

	/**
	 * 所在地丁目
	 */
	private String locationStreet;

	/**
	 * 所在地番地（カナ）
	 */
	private String locationAddressKana;

	/**
	 * 所在地番地
	 */
	private String locationAddress;

	/**
	 * 所在地建物名・号室（カナ）
	 */
	private String locationBuildingRoomKana;

	/**
	 * 所在地建物名・号室
	 */
	private String locationBuildingRoom;

	/**
	 * 電話番号種別
	 */
	private String phoneType;

	/**
	 * 電話番号（上）
	 */
	private String phoneNumOneFirst;

	/**
	 * 電話番号（中）
	 */
	private String phoneNumOneMid;

	/**
	 * 電話番号（下）
	 */
	private String phoneNumOneLast;

	/**
	 * 事業先電話番号種別
	 */
	private String businessPhoneType;

	/**
	 * 事業先電話番号（上）
	 */
	private String businessPhoneNumFirst;

	/**
	 * 事業先電話番号（中）
	 */
	private String businessPhoneNumMid;

	/**
	 * 事業先電話番号（下）
	 */
	private String businessPhoneNumLast;

	/**
	 * 取引目的
	 */
	private String transactPurpose;

	/**
	 * 取引目的（その他）
	 */
	private String transactPurposeOther;

	/**
	 * 取引目的（詳細）
	 */
	private String transactPurposeDetail;

	/**
	 * 事業内容
	 */
	private String businessDescription;

	/**
	 * 事業内容（その他）
	 */
	private String businessDescriptionOther;

	/**
	 * 取扱品目
	 */
	private String handingItem;

	/**
	 * 主要取引先（仕入）
	 */
	private String mainlyTradePurchase;

	/**
	 * 主要取引先（販売）
	 */
	private String mainlyTradeSale;

	/**
	 * 当金庫との取引希望
	 */
	private String preferredTrade;

	/**
	 * 当金庫との取引希望（その他）
	 */
	private String otherBusinessWishes;

	/**
	 * 取引のきっかけ
	 */
	private String transactionTrigger;

	/**
	 * 取引金融機関
	 */
	private String financialInstitution;

	/**
	 * 取引金融機関（預金状況）
	 */
	private String financialInstitutionDepositStatus;

	/**
	 * 取引金融機関（貸金状況）
	 */
	private String financialInstitutionLoanStatus;

	/**
	 * メールアドレス
	 */
	private String emailAddress;

	/**
	 * 開設店番
	 */
	private String openBranchNumber;

	/**
	 * eKYC本人確認結果
	 */
	private String ekycResult;

	/**
	 * 代表者本人確認書類リスト
	 */
	private List<IdentityVerificationDocumentsfileStreamDto> identityDocuments;
}

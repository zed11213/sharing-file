package jp.co.jsbank.mobile.bff.dto.ba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeaderBA;
import lombok.Data;

/**
 * 個別フロー CIF照会（モバイル用）レスポンスDTO
 */
@Data
public class CifInquiryBaResponseDto {

    /**
     * 共通レスポンス・ヘッダ
     */
    private CommonResponseHeaderBA commonResponseHeader;

    /**
     * CIF番号
     */
    private String cifNumber;

    /**
     * 統一顧客番号
     */
    private String unifiedCifNumber;

    /**
     * 世帯主
     */
    private String householder;

    /**
     * 性別（コード）
     */
    private String genderCode;

    /**
     * 性別（文言）
     */
    private String genderValue;

    /**
     * 生（設立）年月日
     */
    private String birthday;

    /**
     * 人格（コード）
     */
    private String personCode;

    /**
     * 人格（文言）
     */
    private String personValue;

    /**
     * 業種（コード）
     */
    private String categoryCode;

    /**
     * 業種（文言）
     */
    private String categoryValue;

    /**
     * 担当者コード
     */
    private String contactPersonCode;

    /**
     * 会員区分
     */
    private String memberCategory;

    /**
     * 会員番号
     */
    private String memberNumber;

    /**
     * 注意コード1
     */
    private String cautionIndicationCode1;

    /**
     * 注意コード2
     */
    private String cautionIndicationCode2;

    /**
     * 注意コード3
     */
    private String cautionIndicationCode3;

    /**
     * 注意コード4
     */
    private String cautionIndicationCode4;

    /**
     * 注意コード5
     */
    private String cautionIndicationCode5;

    /**
     * 注意コード6
     */
    private String cautionIndicationCode6;

    /**
     * 注意コード7
     */
    private String cautionIndicationCode7;

    /**
     * 注意コード8
     */
    private String cautionIndicationCode8;

    /**
     * 注意コード9
     */
    private String cautionIndicationCode9;

    /**
     * 注意コード10
     */
    private String cautionIndicationCode10;

    /**
     * 注意コード11
     */
    private String cautionIndicationCode11;

    /**
     * 注意コード12
     */
    private String cautionIndicationCode12;

    /**
     * 注意コード13
     */
    private String cautionIndicationCode13;

    /**
     * 注意コード14
     */
    private String cautionIndicationCode14;

    /**
     * 注意コード15
     */
    private String cautionIndicationCode15;

    /**
     * 注意コード16
     */
    private String cautionIndicationCode16;

    /**
     * 注意コード17
     */
    private String cautionIndicationCode17;

    /**
     * 注意コード18
     */
    private String cautionIndicationCode18;

    /**
     * 注意コード19
     */
    private String cautionIndicationCode19;

    /**
     * 注意コード20
     */
    private String cautionIndicationCode20;

    /**
     * 注意コード21
     */
    private String cautionIndicationCode21;

    /**
     * 取引時確認状態
     */
    private String transactionConfirmation;

    /**
     * 国籍（コード）
     */
    private String nationalityCode;

    /**
     * 国籍（文言）
     */
    private String nationalityValue;

    /**
     * 郵便番号
     */
    private String zipCode;

    /**
     * 住所コード
     */
    private String districtCode;

    /**
     * 漢字住所
     */
    private String address;

    /**
     * カナ住所
     */
    private String addressKana;

    /**
     * 電話番号
     */
    private String phoneNumber1;

    /**
     * 携帯電話番号
     */
    private String phoneNumber2;

    /**
     * IP電話番号
     */
    private String phoneNumber3;

    /**
     * カナ氏名
     */
    private String nameKana;

    /**
     * 漢字氏名
     */
    private String nameKanji;

    /**
     * 本人死亡
     */
    private String death;

    /**
     * マネロン情報
     */
    private String moneyLaundering;

    /**
     * 店番
     */
    private String branchNumber;

    /**
     * 共通本人確認区分
     */
    private String commonSelfConfirm;

    /**
     * 共通本人確認区分（文言）
     */
    private String commonSelfConfirmValue;

    /**
     * 居住者区分
     */
    private String residentClassification;

    /**
     * CIR開設日
     */
    private String openingDate;

    /**
     * バンキングアプリ登録
     */
    private String bankingAppRegister;

    /**
     * バンキングアプリ停止
     */
    private String bankingAppStopping;

    /**
     * 普通預金口座1_預金種目
     */
    private String accountType1;

    /**
     * 普通預金口座1_店番
     */
    private String accountBranchNumber1;

    /**
     * 普通預金口座1_口座番号
     */
    private String accountNumber1;

    /**
     * 普通預金口座2_預金種目
     */
    private String accountType2;

    /**
     * 普通預金口座2_店番
     */
    private String accountBranchNumber2;

    /**
     * 普通預金口座2_口座番号
     */
    private String accountNumber2;

    /**
     * 普通預金口座3_預金種目
     */
    private String accountType3;

    /**
     * 普通預金口座3_店番
     */
    private String accountBranchNumber3;

    /**
     * 普通預金口座3_口座番号
     */
    private String accountNumber3;

    /**
     * 普通預金口座4_預金種目
     */
    private String accountType4;

    /**
     * 普通預金口座4_店番
     */
    private String accountBranchNumber4;

    /**
     * 普通預金口座4_口座番号
     */
    private String accountNumber4;

    /**
     * 普通預金口座5_預金種目
     */
    private String accountType5;

    /**
     * 普通預金口座5_店番
     */
    private String accountBranchNumber5;

    /**
     * 普通預金口座5_口座番号
     */
    private String accountNumber5;

    /**
     * 口座開設可否
     */
    private String accountOpeningJudgement;

    /**
     * 口座開設可否（文言）
     */
    private String accountOpeningJudgementValue;

}

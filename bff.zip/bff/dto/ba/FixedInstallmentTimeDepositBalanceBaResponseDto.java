package jp.co.jsbank.mobile.bff.dto.ba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeaderBA;
import lombok.Data;

/**
 * 残高照会（定期積金）レスポンスDTO（ABA ← BA）
 */
@Data
public class FixedInstallmentTimeDepositBalanceBaResponseDto {

    /**
     * 共通レスポンス・ヘッダ
     */
    private CommonResponseHeaderBA commonResponseHeader;

    /**
     * 店番
     */
    private String branchNumber;

    /**
     * 預金種目
     */
    private String accountType;

    /**
     * 口座番号
     */
    private String accountNumber;

    /**
     * サブNo
     */
    private String subNo;

    /**
     * 期間
     */
    private String period;

    /**
     * 回数
     */
    private String numberOfTimes;

    /**
     * 振替日・集金日
     */
    private String transferDate;

    /**
     * 課税区分（コード）
     */
    private String taxClassCode;

    /**
     * 課税区分（文言）
     */
    private String taxClassName;

    /**
     * 契約日
     */
    private String contractDate;

    /**
     * 満期日
     */
    private String maturityDate;

    /**
     * 元帳残高
     */
    private String balanceOfLedger;

    /**
     * 契約額
     */
    private String agreementAmount;

    /**
     * 掛金額
     */
    private String premium;

    /**
     * 夢付き
     */
    private String dreamFlag;

    /**
     * 利率
     */
    private String interest;

    /**
     * 給付補填金
     */
    private String payupAmount;

    /**
     * CIF番号
     */
    private String cifNumber;

    /**
     * 最終掛込日
     */
    private String lastTransferDate;

    /**
     * 種類
     */
    private String kinds;

    /**
     * 振替口座預金種目
     */
    private String transferAccountType;

    /**
     * 振替口座店番
     */
    private String transferAccountBranchNumber;

    /**
     * 振替口座番号
     */
    private String transferAccountNumber;

    /**
     * 種類名
     */
    private String kindsName;

    /**
     * 商品名
     */
    private String productName;

}

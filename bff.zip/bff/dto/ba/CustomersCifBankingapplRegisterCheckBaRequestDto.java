package jp.co.jsbank.mobile.bff.dto.ba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import jp.co.jsbank.mobile.bff.dto.CommonResponseHeaderBA;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 1.32.利用登録可否チェック（BA API: BA_API0032）リクエストDTO（ABA → BA）
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class CustomersCifBankingapplRegisterCheckBaRequestDto extends RequestBodyDto {

    /**
     * 店番
     */
    private String cifNumber;

    /**
     * CIF番号
     */
    private String branchNumber;

    /**
     * 預金種目
     */
    private String accountType;

    /**
     * 口座番号
     */
    private String accountNumber;




}





package jp.co.jsbank.mobile.bff.dto.ba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeaderBA;
import lombok.Data;

/**
 * 1.32.利用登録可否チェック（BA API: BA_API0032）レスポンスDTO（ABA ← BA）
 */
@Data
public class CustomersCifBankingapplRegisterCheckBaResponseDto {

    /**
     * 共通レスポンス・ヘッダ
     */
    private CommonResponseHeaderBA commonResponseHeader;

    /**
     * 判定結果
     */
    private String checkResult;

}

package jp.co.jsbank.mobile.bff.dto.ba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeaderBA;
import lombok.Data;

/**
 * 残高照会（定期預金）レスポンスDTO（ABA ← BA）
 */
@Data
public class FixedTermDepositBalanceBaResponseDto {

    /**
     * 共通レスポンス・ヘッダ
     */
    private CommonResponseHeaderBA commonResponseHeader;

    /**
     * 預金種目
     */
    private String accountType;

    /**
     * 店番
     */
    private String branchNumber;

    /**
     * 口座番号
     */
    private String accountNumber;

    /**
     * サブNo
     */
    private String subNo;

    /**
     * 期間（月数）
     */
    private String periodCode;

    /**
     * 利率
     */
    private String interestRate;

    /**
     * 課税区分（コード）
     */
    private String taxClassCode;

    /**
     * 課税区分（文言）
     */
    private String taxClassName;

    /**
     * 契約日
     */
    private String contractDate;

    /**
     * 満期日
     */
    private String maturityDate;

    /**
     * 元帳残高
     */
    private String balanceOfLedger;

    /**
     * 利息受取方法
     */
    private String interestReceivingMethod;

    /**
     * 利息受取預金種目
     */
    private String interestReceiveAccountType;

    /**
     * 利息受取店番
     */
    private String interestReceiveBranchNumber;

    /**
     * 利息受取口座番号
     */
    private String interestReceiveAccountNumber;

    /**
     * 当初金額
     */
    private String startAmount;

    /**
     * スーパー定期種類
     */
    private String superRegularType;

    /**
     * 懸賞金区分（コード）
     */
    private String rewardAmountTypeCode;

    /**
     * 懸賞金区分（文言）
     */
    private String rewardAmountTypeValue;

    /**
     * 抽選回数
     */
    private String lotteryTimes;

    /**
     * 取扱組
     */
    private String handlingGroup;

    /**
     * 開始抽選番号
     */
    private String lotteryNoStart;

    /**
     * 終了抽選番号
     */
    private String lotteryNoEnd;

    /**
     * 抽選日
     */
    private String lotteryDate;

    /**
     * CIF番号
     */
    private String cifNumber;

    /**
     * お取引区分
     */
    private String transactionClassification;

    /**
     * 取扱い口数
     */
    private String numberOfLottery;

}

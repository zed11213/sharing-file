package jp.co.jsbank.mobile.bff.dto.ba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 個別フロー CIF照会（モバイル用）リクエストDTO
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class CifInquiryBaRequestDto extends RequestBodyDto {

    /**
     * CIF番号
     */
    private String cifNumber;

    /**
     * 店番
     */
    private String branchNumber;

}

package jp.co.jsbank.mobile.bff.dto.ba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 残高照会（定期積金）リクエストDTO（ABA → BA）
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class FixedInstallmentTimeDepositBalanceBaRequestDto extends RequestBodyDto {

    /**
     * 預金種目
     */
    private String accountType;

    /**
     * 店番
     */
    private String branchNumber;

    /**
     * 口座番号
     */
    private String accountNumber;

    /**
     * サブNo
     */
    private String subNo;

}

package jp.co.jsbank.mobile.bff.dto;
import lombok.Data;

/**
 * CIF情報DTO
 */
@Data
public class CifCustomerInfomationDto {

    /**
     * CIF番号
     */
    private String cifNo;

    /**
     * 初回登録フラグ
     */
    private String registerFlg;

    /**
     * 登録口座番号
     */
    private String registerAccountNumber;

    /**
     * 登録口座預金種目
     */
    private String registerAccountType;

    /**
     * 解約フラグ
     */
    private String dissolutionFlg;


}
package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 口座情報DTO
 */
@Data
public class AccountInfosDto {

    /**
     * 科目
     */
    private String subjectNameCode;

    /**
     * 科目（文言）
     */
    private String subjectNameValue;

    /**
     * 預金種目
     */
    private String accountType;

    /**
     * 店番
     */
    private String branchNumber;

    /**
     * 口座番号
     */
    private String accountNumber;

    /**
     * サブNo
     */
    private String accountSubNumber;

    /**
     * 総合口座フラグ
     */
    private String generalAccountFlag;

    /**
     * 総合口座リンク先（預金種目）
     */
    private String linkedAccountType;

    /**
     * 総合口座リンク先（店番）
     */
    private String linkedBranchNumber;

    /**
     * 総合口座リンク先（口座番号）
     */
    private String linkedAccountNumber;

    /**
     * 総合口座リンク先（サブNo）
     */
    private String linkedSubNumber;

    /**
     * 商品名
     */
    private String productName;

    /**
     * 未資金化残高
     */
    private String unfundedBalance;

    /**
     * 資金化残高
     */
    private String fundedBalance;

    /**
     * 元帳残高
     */
    private String balanceOfLedger;

    /**
     * 解約済表示
     */
    private String isAlive;

}

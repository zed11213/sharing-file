package jp.co.jsbank.mobile.bff.dto;

import java.util.List;

import lombok.Data;

/**
 * CC発行申込情報DTO
 */
@Data
public class CcIssuingApplicationInformationDto {

    /**
     * 受付番号
     */
    private String receiptNumber;
    
    /**
     * 顧客ID
     */
    private String customerId;
    
    /**
     * ユーザーID
     */
    private String userID;   
    
    /**
     * CIF番号
     */
    private String cifNumber;
    
    /**
     * 人格区分
     */
    private String personalityFlag; 
    
    /**
     * 申込ステータス
     */
    private String applyStatus; 
    
    /**
     * 申請開始日時
     */
    private String applyStartDateTime; 
  
    /**
     * 申請有効期限日時
     */
    private String applyValidDateTime; 
    
    /**
     * 利用停止フラグ
     */
    private String useSuspendFlag; 
    
    /**
     * 取引種別
     */
    private String transactionType; 
    
    /**
     * 氏名カナ（姓）
     */
    private String employeeKanaLast; 
    
    /**
     * 氏名カナ（名）
     */
    private String employeeKanaFirst; 
    
    /**
     * 氏名漢字（姓）
     */
    private String employeeKanjiLast; 
    
    /**
     * 氏名漢字（名）
     */
    private String employeeKanjiFirst; 
    
    /**
     * 生年月日
     */
    private String dateOfBirth; 
    
    /**
     * 自宅郵便番号
     */
    private String homeZipCode; 
    
    /**
     * メールアドレス
     */
    private String emailAddress; 

    /**
     * 部店コード
     */
    private String branchCode;
    
    /**
     * 普通預金口座番号
     */
    private String accountNumber; 
    
    /**
     * 取引目的
     */
    private String transactionPurpose; 
    
    /**
     * 取引目的（その他）
     */
    private String transactPurposeOther; 
	  
    /**
     * 職業
     */
    private String occupation; 
    
    /**
     * 職業（その他）
     */
    private String occupationOther; 
    
    /**
     * キャッシュカード種類
     */
    private String cashcardType; 
    
    /**
     * CC暗証番号
     */
    private String ccPinCode; 
    
    /**
     * eKYC確認結果
     */
    private String ekycResult; 
    
    /**
     * 本人確認書類Dto
     */
    private List<IdentityDocumentsDto> identityDocumentsDtoList; 

}

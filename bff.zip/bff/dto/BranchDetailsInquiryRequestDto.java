package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 支店詳細照会リクエストDTO
 */
@Data
public class BranchDetailsInquiryRequestDto {

    /**
     * 店番
     */
    private String branchNumber;
}

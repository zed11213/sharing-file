package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * メールアドレス登録BFFリクエストDTO
 */
@Data
public class EmailAddRegistrationRequestDto {

    /**
     * メールアドレス
     */
    private String emailAddress;
    
    /**
     * 受付番号
     */
    private String receiptNumber;

    /**
     * メールOTP
     */
    private String mailOTP;
    
    /**
     * 更新パターン
     */
    private String updateType;
}

package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 送信先顧客IDDto
 * */
@Data
public class DestinationCustIdDto {
    
    /**
     * 送信先顧客ID
     * */
    private String destinationCustId;
}

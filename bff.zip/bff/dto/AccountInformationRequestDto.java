package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 口座情報取得BFFリクエストDTO
 */
@Data
public class AccountInformationRequestDto {

    /**
     * 店番
     */
    private String branchCode;
    
    /**
     * CIF番号
     */
    private String cifNo;
}

package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 契約管理操作履歴照会BFFリクエストDTO
 */
@Data
public class ContractManagementOperationHistoryInquiryRequestDto {

	/**
     * 受付番号
     */
    private String receptionNumber;
}

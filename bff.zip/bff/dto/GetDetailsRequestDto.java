package jp.co.jsbank.mobile.bff.dto;
import lombok.Data;

/**
 * 明細取得情報リクエストDTO
 */
@Data
public class GetDetailsRequestDto {

    /**
     * 口座番号
     */
    private String accountNumber;

    /**
     * 店番
     */
    private String branchNumber;

    /**
     * CIF番号
     */
    private String cifNumber;

    /**
     * 預金種目
     */
    private String accountType;
}

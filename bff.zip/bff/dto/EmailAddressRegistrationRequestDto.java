package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * メールアドレス登録リクエストDTO
 */
@Data
public class EmailAddressRegistrationRequestDto {

    /**
     * メールアドレス
     */
    private String emailAddress;

    /**
     * 更新パターン
     */
    private String updateType;

    /**
     * 人格区分
     */
    private String personType;
}

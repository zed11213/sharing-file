package jp.co.jsbank.mobile.bff.dto;

import java.util.List;

import lombok.Data;

/**
 * 支店一覧一覧照会レスポンスDTO
 */
@Data
public class BranchStoreDtoResponseDto {

	/**
	 * 支店一覧照会
	 */
	private List<BranchStoreDto> branchList;

}

package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 認証キー検証BFFリクエストDTO
 */
@Data
public class AuthenticationKeyVerificationRequestDto {

    /**
     * 所属
     */
    private String divisionCode;
    
    /**
     * 利用者認証キー
     */
    private String userAuthCode;

    /**
     * デバイスID
     */
    private String deviceId;
}

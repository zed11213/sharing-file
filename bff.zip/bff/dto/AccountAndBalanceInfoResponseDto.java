package jp.co.jsbank.mobile.bff.dto;

import java.util.List;
import java.util.Map;

import lombok.Data;

/**
 * 口座一覧レスポンスDTO
 */
@Data
public class AccountAndBalanceInfoResponseDto {

    /**
     * 口座一覧リスト
     */
    private List<AccountInfoResponseDto> accountInfoResponseDtoList;

    /**
     * 各科目毎残高合計
     */
    private Map<String, String> subjectTotalBalance;

    /**
     * 全口座残高合計
     */
    private String allAccountsTotalBalance;
    
}

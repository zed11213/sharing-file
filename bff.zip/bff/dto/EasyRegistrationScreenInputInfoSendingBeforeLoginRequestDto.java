package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * ログイン前かんたん登録画面入力情報送信リクエストDTO
 */
@Data
public class EasyRegistrationScreenInputInfoSendingBeforeLoginRequestDto {
    /**
     * 非会員フラグ
     */
    private String nonMemberFlg;

    /**
     * お知らせID
     */
    private String anncmntId;
    /**
     * 受付案内タイトル
     */
    private String receptionInformationTitle;
    /**
     * カナ氏名
     */
    private String custNameKana;
    /**
     * 漢字氏名
     */
    private String custNameKanji;
    /**
     * 郵便番号
     */
    private String custZipCode;
    /**
     * カナ住所
     */
    private String custAddressKana;
    /**
     * 住所
     */
    private String custAddress;
    /**
     * 電話番号
     */
    private String custPhone;
    /**
     * メールアドレス
     */
    private String custMail;
    /**
     * 受付フォーマット
     */
    private String receptionFormat;
    /**
     * 窓口支店番号
     */
    private String contactBranchNum;
    /**
     * メッセージ内容種別
     */
    private String mobileMsgType;
    /**
     * タイトル
     */
    private String anncmntTitle;
    /**
     * 掲載開始日時
     */
    private String anncmntStartDateAndTime;
    
    /**
     * 掲載開始日時
     */
    private String anncmntEndDateAndTime;
    /**
     * 作成日時
     */
    private String createDateAndTime;
    /**
     * お知らせ種別コード
     */
    private String informationTypeCode;
    /**
     * 文書種別コード
     */
    private String documentTypeCode;
}

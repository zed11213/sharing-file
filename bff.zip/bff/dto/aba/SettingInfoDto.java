package jp.co.jsbank.mobile.bff.dto.aba;
import lombok.Data;

/**
 * 設定情報DTO
 */
@Data
public class SettingInfoDto {

    /**
     * 設定種別
     */
    private String settingType;

    /**
     * 設定区分
     */
    private String settingDivision;

    /**
     * 設定値
     */
    private String settingContent;
}

package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 利用者属性登録ABAレスボスDTO
 */
@Data
public class UserAttributeRegistrationAbaResponseDto {

    /**
     * 共通レスポンス・ボディ
     */
    private CommonResponseHeader commonResponseHeader;

    /**
     * 利用者ID
     */
    private String userId;
}

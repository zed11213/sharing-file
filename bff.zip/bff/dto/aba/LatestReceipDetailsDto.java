package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * 最新受領情報明細DTO
 */
@Data
public class LatestReceipDetailsDto {

    /**
     * 回次
     */
    private String lotteryTimes;

    /**
     * 抽選区分
     */
    private String lotteryType;

    /**
     * 取扱組
     */
    private String lotterySet;

}

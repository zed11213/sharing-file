package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 申込回答閲覧ABAレスボスDTO
 */
@Data
public class ApplicationAnswerViewAbaResponseDto  {
	
	 /**
     * 共通レスポンス・ボディ
     */
    private CommonResponseHeader commonResponseHeader;
    
    /**
     * 受付案内タイトル
     */
    private String receptionInformationTitle;
    
    /**
     * 申込データ(確認済)
     */
    private String applicationDataVerified;
    
    /**
     * 回答本文
     */
    private String answerBody;
    
    /**
     * 画像バケット名
     */
    private String imageBucketName;
    
    /**
     * 画像ファイル名
     */
    private String imageFilename;
    
    /**
     * 画像位置
     */
    private String imagePosition;
    
    /**
     * 画像リンク先有無
     */
    private String imageLinkTargetExistence;
    
    /**
     * 画像リンク先URL
     */
    private String imageLinkTargetUrl;
    
    /**
     * ボタンラベル文言
     */
    private String buttonLabelMessage;
    
}

package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * IVR送信ABAリクエストDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class IvrSendingAbaRequestDto extends RequestBodyDto {

    /**
     * 電話番号
     */
    private String phoneNumber;

    /**
     * 更新パターン
     * */
    private String updateType;
}

package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 顧客照会情報ABADTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class CustomerInquiryInformationAbaDto extends RequestBodyDto {
    /**
     * CIF番号
     */
    private String cifNo;

    /**
     * 人格区分
     */
    private String personCode;

    /**
     * 利用者区分
     */
    private String userType;

    /**
     * 預金種目コード
     */
    private String accountType;

    /**
     * 店番
     */
    private String branchCode;

    /**
     * 口座番号
     */
    private String accountNumber;

    /**
     * 漢字氏名
     */
    private String customerKanjiName;

    /**
     * カナ氏名
     */
    private String customerName;

    /**
     * 生年月日
     */
    private String birthday;

    /**
     * 郵便番号
     */
    private String zipCode;

    /**
     * 電話番号１
     */
    private String phoneNumberOne;

    /**
     * 電話番号２
     */
    private String phoneNumberTwo;

    /**
     * 電話番号３
     */
    private String phoneNumberThree;

    /**
     * 住所
     */
    private String address;

    /**
     * 性別
     */
    private String gender;

    /**
     * 所属
     */
    private String division;

    /**
     * 利用者認証キー
     */
    private String certKey;

    /**
     * メールアドレス
     */
    private String mailAddress;

    /**
     * 端末ID
     */
    private String deviceId;

    /**
     * OS
     */
    private String os;

    /**
     * 通帳レスフラグ
     */
    private String lessFlg;

    /**
     * 最終更新日時
     */
    private String updateDatetime;
}

package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 利用者属性更新AbaレスポンスDTO
 */
@Data
public class UpdateUserAttAbaResponseDto {
	
	
	 /**
     * 共通レスポンス・ボディ
     */
    private CommonResponseHeader commonResponseHeader;
    
	 /**
     * 確認ステータス
     */
    private String confirmationStatus;
    
 }

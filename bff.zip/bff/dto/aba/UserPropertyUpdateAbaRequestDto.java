package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * 利用者属性更新ABAリクエストDTO
 */
@Data
public class UserPropertyUpdateAbaRequestDto {

    /**
     * 利用者ID
     */
    private String userId;
    
    /**
     * プッシュ通知用デバイストークン
     */
    private String deviceToken;

    /**
     * OS種類
     */
    private String osType;

}

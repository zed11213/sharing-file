package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 顧客登録情報ABAリクエストDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class CustomerRegistrationAbaRequestDto extends RequestBodyDto {

    /**
     * CIF番号
     */
    private String cifNo;

    /**
     * 人格区分
     */
    private String personCode;

    /**
     * 利用者区分
     */
    private String userType;

    /**
     * 預金種目コード
     */
    private String accountType;

    /**
     * 店番
     */
    private String branchCode;

    /**
     * 口座番号
     */
    private String accountNumber;

    /**
     * 漢字氏名
     */
    private String customerKanjiName;

    /**
     * カナ氏名
     */
    private String customerName;

    /**
     * 生年月日
     */
    private String birthday;

    /**
     * 郵便番号
     */
    private String zipCode;

    /**
     * 電話番号１
     */
    private String phoneNumberOne;

    /**
     * 電話番号２
     */
    private String phoneNumberTwo;

    /**
     * 電話番号３
     */
    private String phoneNumberThree;

    /**
     * 住所
     */
    private String address;

    /**
     * 性別
     */
    private String gender;

    /**
     * 所属
     */
    private String division;

    /**
     * 利用者認証キー
     */
    private String certKey;

    /**
     * メールアドレス
     */
    private String mailAddress;

    /**
     * 設定情報
     */
    private List<SettingInfoDto> settingInfos;

    /**
     * 端末ID
     */
    private String deviceId;

    /**
     * OS
     */
    private String os;

    /**
     * 通帳レスフラグ
     */
    private String lessFlg;

    /**
     * 利用者ステータス
     */
    private String userStatus;

    /**
     * 利用状況
     */
    private String utilizationStatus;

    /**
     * 顧客ステータス
     */
    private String customerStatus;

    /**
     * 通知用トークン
     */
    private String registrationToken;


}

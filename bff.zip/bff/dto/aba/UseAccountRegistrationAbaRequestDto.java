package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 利用口座登録ABAリクエストDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class UseAccountRegistrationAbaRequestDto extends RequestBodyDto {

    /**
     * 顧客ID
     */
    private String customerId;

    /**
     * 店番
     */
    private String branchCode;

    /**
     * 登録口座番号
     */
    private String registerAccountNumber;

    /**
     * 預金種目
     */
    private String accountType;

    /**
     * サブNo
     */
    private String subNo;

}

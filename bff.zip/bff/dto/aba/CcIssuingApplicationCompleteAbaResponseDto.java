package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * CC発行申込完了レスポンスDTO
 */
@Data
public class CcIssuingApplicationCompleteAbaResponseDto {
	
	
	 /**
     * 共通レスポンス・ボディ
     */
    private CommonResponseHeader commonResponseBody;
    
 }




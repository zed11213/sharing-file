package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * CC発行申込内容照会ABAクエストDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class CcIssuingApplicationContentInquiryAbaRequestDto extends RequestBodyDto {


	 /**
     * 受付番号
     */
    private String receiptNumber;
 }




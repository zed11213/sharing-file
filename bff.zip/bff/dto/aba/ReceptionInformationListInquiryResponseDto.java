package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import jp.co.jsbank.mobile.bff.dto.ReceptionGuideDto;
import lombok.Data;

/**
 * かんたん受付案内一覧照会ABAリクエストDTO
 */
@Data
public class ReceptionInformationListInquiryResponseDto {
	
	 /**
     * 共通レスポンス・ボディ
     */
    private CommonResponseHeader commonResponseHeader;
    
    /**
     * かんたん受付案内Dtoレスト
     */
    private List<ReceptionGuideDto> receptionGuideList;
    
    /**
     * 該当件数
     */
    private String dataCount;
}

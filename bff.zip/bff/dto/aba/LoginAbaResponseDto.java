package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * ログインABAレスボスDTO
 */
@Data
public class LoginAbaResponseDto {

    /**
     * 認証トークン
     */
    private String authenticationToken;

    /**
     * 認証有効期間
     */
    private String authenticationEffectivePeriod;
}

package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * かんたん受付申込詳細照会リクエストDTO
 */
@Data
public class ReceptionAnswerDetailInquiryAbaRequestDto {

    /**
     * お知らせID
     */
    private String anncmntId;
    
    /**
     * 申込ID
     */
    private String applyId;
 
}

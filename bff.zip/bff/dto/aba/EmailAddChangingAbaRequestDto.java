package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * メールアドレス変更ABAリクエストDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class EmailAddChangingAbaRequestDto extends RequestBodyDto {

    /**
     * メールアドレス
     */
    private String emailAddress;

    /**
     * 処理区分
     */
    private String processType;
}

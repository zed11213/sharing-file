package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import jp.co.jsbank.mobile.bff.dto.AnnouncementStatusDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * モバイルメッセージ詳細照会ABAリクエストDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class MobileMessageInquiryAbaRequestDto extends RequestBodyDto {

    /**
     * お知らせID
     */
    private String anncmntId;

    /**
     * お知らせステータス
     */
    private List<AnnouncementStatusDto> anncmntStatusList;

    /**
     * 公開中フラグ
     */
    private String releasedFlg;
}

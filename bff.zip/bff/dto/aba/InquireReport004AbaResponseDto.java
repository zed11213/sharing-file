package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import jp.co.jsbank.mobile.bff.dto.PeriodicDepositMaturityDto;
import lombok.Data;

/**
 * 帳票CSV内容照会_定期積金満期案内ABAレスポンスDTO
 */
@Data
public class InquireReport004AbaResponseDto {

    /**
     * 共通レスポンスヘッダ
     */
    private CommonResponseHeader commonResponseHeader;

    /**
     * 帳票バージョン
     */
    private String formVersion;

    /**
     * 本状作成日
     */
    private String bookCreateDate;

    /**
     * 定期積金満期明細表リスト
     */
    private List<PeriodicDepositMaturityDto> periodicDepositMaturityList;

    /**
     * 取扱店名
     */
    private String branchKanjiName;

    /**
     * 取扱電話番号
     */
    private String branchPhoneNumber;
}

package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.BACommonResponseHeader;
import lombok.Data;

/**
 * 共通レスポンス・ヘッダ
 */
@Data
public class CommonHeaderBaResponseDto {

    /**
     * 共通レスポンス・ヘッダ
     */
    private BACommonResponseHeader commonResponseHeader;

}

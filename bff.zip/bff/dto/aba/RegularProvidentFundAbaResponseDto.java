package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 定期積金残高照会AbaレスポンスDTO
 */
@Data
public class RegularProvidentFundAbaResponseDto {
    /**
     * 共通レスポンス・ボディ
     */
    private CommonResponseHeader commonResponseHeader;

    /**
     * CIF番号
     */
    private String cifNumber;

    /**
     * 店番
     */
    private String branchNumber;

    /**
     * 預金種目
     */
    private String accountType;

    /**
     * 口座番号
     */
    private String accountNumber;

    /**
     * サブNo
     */
    private String accountSubNumber;

    /**
     * 期間
     */
    private String periodCode;

    /**
     * 回数
     */
    private String numberOfTimes;

    /**
     * 振替日・集金日
     */
    private String transferDate;

    /**
     * 課税区分
     */
    private String taxClassCode;

    /**
     * 課税区分（文言）
     */
    private String taxClassName;

    /**
     * 契約日
     */
    private String contractDate;

    /**
     * 満期日
     */
    private String maturityDate;

    /**
     * 元帳残高
     */
    private String balanceOfLedger;

    /**
     * 契約額
     */
    private String agreementAmount;

    /**
     * 掛金額
     */
    private String amount;

    /**
     * 夢付き
     */
    private String withDream;

    /**
     * 利率
     */
    private String interestRate;

    /**
     * 給付補填金
     */
    private String payupAmount;
}

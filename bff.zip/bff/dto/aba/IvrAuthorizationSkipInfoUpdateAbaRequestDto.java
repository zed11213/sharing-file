package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * IVR認証スキップ情報更新ABAリクエストDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class IvrAuthorizationSkipInfoUpdateAbaRequestDto extends RequestBodyDto {
	
    /**
     * CIF番号
     */
    private String cifNumber;

    /**
     * 店番
     */
    private String branchNumber;

    /**
     * 使用済みフラグ
     */
    private String usedFlag;
}

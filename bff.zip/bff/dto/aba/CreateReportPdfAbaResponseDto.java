package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 帳票PDF出力ABAレスポンスDTO
 */
@Data
public class CreateReportPdfAbaResponseDto {

    /**
     * 共通レスポンスヘッダ
     */
    private CommonResponseHeader commonResponseHeader;

    /**
     * 帳票PDFファイルオブジェクト
     */
    private Object formPdfFileObject;
}

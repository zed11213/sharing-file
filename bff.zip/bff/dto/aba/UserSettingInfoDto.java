package jp.co.jsbank.mobile.bff.dto.aba;
import java.util.List;

import lombok.Data;

/**
 * 利用者情報DTO
 */
@Data
public class UserSettingInfoDto {

    /**
     * 設定情報DTOリスト
     */
    private List<SettingInfoDto> settingInfos;
}

package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * ログイン履歴登録ABAリクエストDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class RegistloginHistoryAbaRequestDto extends RequestBodyDto {

    /**
     * 顧客ID
     */
    private String customerId;

    /**
     * 利用者ID
     */
    private String userId;

}

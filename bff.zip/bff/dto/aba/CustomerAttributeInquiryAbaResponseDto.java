package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 顧客属性照会ABAレスボスDTO
 */
@Data
public class CustomerAttributeInquiryAbaResponseDto {

    /**
     * 共通レスポンス・ボディ
     */
    private CommonResponseHeader commonResponseHeader;

    /**
     * 顧客属性情報
     */
    private List<CustomerAttributeInfoDto> customerList;

    /**
     * 該当件数
     */
    private String dataCount;
}

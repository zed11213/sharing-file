package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * 復元処理リクエストDTO
 */
@Data
public class RecoveryProcessAbaRequestDto {

    /**
     * receptionNumber 受付番号
     */
    private String receptionNumber;

}

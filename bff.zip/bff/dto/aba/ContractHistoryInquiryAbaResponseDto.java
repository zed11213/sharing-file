package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * 契約管理操作履歴照会ABAレスボスDTO
 */
@Data
public class ContractHistoryInquiryAbaResponseDto {

    /**
     * 画面ID
     */
    private String screenID;

    /**
     * 人格区分
     */
    private String personTyp;
}

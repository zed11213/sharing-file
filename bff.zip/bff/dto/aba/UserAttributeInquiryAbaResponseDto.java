package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 利用者属性照会ABAレスボスDTO
 */
@Data
public class UserAttributeInquiryAbaResponseDto {

    /**
     * 共通レスポンス・ボディ
     */
    private CommonResponseHeader commonResponseHeader;

    /**
     * 利用者属性情報
     */
    private List<UserAttributeInfoDto> userInfoList;
}

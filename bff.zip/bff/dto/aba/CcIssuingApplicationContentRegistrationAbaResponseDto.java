package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * CC発行申込内容登録レスボスDTO
 */
@Data
public class CcIssuingApplicationContentRegistrationAbaResponseDto {

    /**
     * 共通レスポンス・ボディ
     */
    private CommonResponseHeader commonResponseHeader;

    /**
     * 受付番号
     */
    private String receiptNumber;

}

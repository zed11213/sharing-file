package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * モバイルメッセージ詳細照会レスポンスDTO
 */
@Data
public class MobileMessageDetailInquiryApiAbaResponseDto {

    /**
     * 共通レスポンスヘッダ
     */
    private CommonResponseHeader commonResponseHeader;

    /**
     * お知らせID
     */
    private String informationId;

    /**
     * バージョン
     */
    private String anncmntVer;

    /**
     * タイトル
     */
    private String anncmntTitle;

    /**
     * 作成日時
     */
    private String anncmntTime;

    /**
     * お知らせステータス
     */
    private String anncmntStatus;

    /**
     * 掲載開始日時
     */
    private String anncmntStartTime;

    /**
     * 掲載終了日時
     */
    private String anncmntEndDate;

    /**
     * 重要フラグ
     */
    private String highPriorityFlg;

    /**
     * 個別通知フラグ
     */
    private String indivisualFlg;

    /**
     * Push通知有無フラグ
     */
    private String pushNotifyFlg;

    /**
     * Push通知本文
     */
    private String pushNotifyMsg;

    /**
     * Push通知指定日時
     */
    private String pushNotifyTime;

    /**
     * メッセージ種類
     */
    private String mobileMsgType;

    /**
     * 同意チェック有無
     */
    private String acceptanceChkFlg;

    /**
     * モバイルメッセージ本文
     */
    private String MobileMsg;

    /**
     * 画像有無フラグ
     */
    private String imgFlg;

    /**
     * 画像位置
     */
    private String imgVPosition;

    /**
     * 画像バケット名PUB
     */
    private String imgBucketPub;

    /**
     * 画像バケット名PVT
     */
    private String imgBucketPvt;

    /**
     * 画像ファイル名
     */
    private String imgFilename;

    /**
     * 画像確認ボタン有無名
     */
    private String btnFlg;

    /**
     * 送信先支店番号
     */
    private String destinationBranceNum;

    /**
     * 送信先CIF番号
     */
    private String destinationCifNum;

    /**
     * 更新タイムスタンプ
     */
    private String updateTs;
}

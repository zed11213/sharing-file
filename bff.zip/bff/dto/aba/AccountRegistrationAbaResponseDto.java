package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 利用口座登録AbaレスポンスDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class AccountRegistrationAbaResponseDto extends RequestBodyDto {
    /**
     * 共通レスポンス・ボディ
     */
    private CommonResponseHeader commonResponseHeader;

    /**
     * CIF番号
     */
    private String cifNo;

}

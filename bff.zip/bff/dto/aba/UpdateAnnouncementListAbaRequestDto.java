package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * お知らせ一覧更新ABAリクエストDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class UpdateAnnouncementListAbaRequestDto extends RequestBodyDto {

    /**
     * 利用者ID
     */
    private String userId;

    /**
     * お知らせ種別コード
     */
    private String anncmntType;

    /**
     * 文書種別コード
     */
    private String documentType;

    /**
     * お知らせID
     */
    private String anncmntId;

    /**
     * 申込ID
     */
    private String applyId;

    /**
     * 個別確認フラグ
     */
    private String confirmFlg;

    /**
     * 帳票ダウンロードフラグ
     */
    private String reportDlFlg;

    /**
     * 既読フラグ
     */
    private String readFlg;

    /**
     * お気に入りフラグ
     */
    private String bookmarkFlg;
}

package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.AccountInfoDto;
import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 口座情報DTO
 */
@Data
public class AccountInformationAbaResponseDto {
    /**
     * 共通レスポンスヘッダー
     */
    private CommonResponseHeader commonResponseHeader;
    
    /**
     * 残高情報DTO
     */
    private List<AccountInfoDto> balanceList;
}

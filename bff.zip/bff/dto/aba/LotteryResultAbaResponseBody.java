package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 抽選結果明細レスポンスDTO
 */
@Data
public class LotteryResultAbaResponseBody {


    /**
     * 共通レスポンス・ボディ
     */
    private CommonResponseHeader commonResponseBody;
    
    /**
     * 抽選結果明細DTOリスト
     */
    private List<LotteryResultsDetailsDto> lotteryResultsDetailsDtoList;

}

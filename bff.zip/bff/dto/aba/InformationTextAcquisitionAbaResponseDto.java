package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * お知らせ本文取得レスポンスDTO
 */
@Data
public class InformationTextAcquisitionAbaResponseDto {
	
    /**
     * 共通レスポンスヘッダ
     */
    private CommonResponseHeader commonResponseHeader;
    
	 /**
     * お知らせ本文
     */
    private String informationText;
    
 }

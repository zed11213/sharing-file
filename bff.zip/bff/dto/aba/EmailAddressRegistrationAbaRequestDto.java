package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * メールアドレス登録ABAリクエストDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class EmailAddressRegistrationAbaRequestDto extends RequestBodyDto {

    /**
     * メールアドレス
     */
    private String emailAddress;

    /**
     * 更新パターン
     */
    private String updateType;
}

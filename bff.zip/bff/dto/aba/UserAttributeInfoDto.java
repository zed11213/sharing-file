package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import lombok.Data;

/**
 * 利用者属性情報DTO
 */
@Data
public class UserAttributeInfoDto {

    /**
     * 顧客ID
     */
    private String customerId;

    /**
     * 利用者ID
     */
    private String userId;

    /**
     * 利用者区分
     */
    private String userType;

    /**
     * ステータス
     */
    private String status;

    /**
     * 利用状況
     */
    private String utilizationStatus;

    /**
     * 漢字氏名
     */
    private String customerKanjiName;

    /**
     * カナ氏名
     */
    private String customerName;

    /**
     * 所属
     */
    private String division;

    /**
     * メールアドレス
     */
    private String mailAddress;

    /**
     * 事業先利用者認証キー
     */
    private String certKey;

    /**
     * 設定情報DTOリスト
     */
    private List<SettingInfoDto> settingInfos;

    /**
     * 端末ID
     */
    private String deviceId;

    /**
     * OS
     */
    private String os;

    /**
     * 最新更新日時
     */
    private String updateTs;

    /**
     * 通知用トークン
     */
    private String registrationToken;
}

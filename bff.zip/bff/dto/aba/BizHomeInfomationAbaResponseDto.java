package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * biz自宅情報保存ABAレスポンスDTO
 */
@Data
public class BizHomeInfomationAbaResponseDto {

    /**
     * 受付番号
     */
    private String receiptNumber;

    /**
     * 共通レスポンスヘッダ
     */
    private CommonResponseHeader commonResponseHeader;
}

package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * かんたん受付申込登録AbaレスボスDTO
 */
@Data
public class EasyReceptionApplicationRegistrationAbaResponseDto  {
	
	 /**
     * 共通レスポンス・ボディ
     */
    private CommonResponseHeader commonResponseHeader;
}

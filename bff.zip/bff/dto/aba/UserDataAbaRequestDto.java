package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 利用者情報ABAレスボスDto
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class UserDataAbaRequestDto extends RequestBodyDto {

	/**
	 * 顧客ID
	 */
	private String customerId;

	/**
	 * 利用者ID
	 */
	private String userId;

	/**
	 * 利用者区分
	 */
	private String userType;

	/**
	 * ステータス
	 */
	private String status;

	/**
	 * 漢字氏名
	 */
	private String customerKanjiName;

	/**
	 * カナ氏名
	 */
	private String customerName;

	/**
	 * 所属
	 */
	private String division;

	/**
	 * メールアドレス
	 */
	private String mailAddress;

	/**
	 * 事業先利用者認証キー
	 */
	private String certKey;

	/**
	 * 設定情報
	 */
	private List<SettingInfoDto> settingInfosDtoList;

	/**
	 * 端末ID
	 */
	private String deviceId;

	/**
	 * OS
	 */
	private String os;

	/**
	 * 最新更新日時
	 */
	private String updateTs;
	
	/**
	 * JBAID
	 */
	private String jbaId;

}

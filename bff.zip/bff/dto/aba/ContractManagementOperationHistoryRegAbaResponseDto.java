package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 契約管理操作履歴登録レスポンスDTO
 */
@Data
public class ContractManagementOperationHistoryRegAbaResponseDto {
	
	
	 /**
     * 共通レスポンス・ボディ
     */
    private CommonResponseHeader commonResponseHeader;
    
    /**
     * IBパスワード
     */
    private String ibPassword;
 }

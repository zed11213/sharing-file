package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 部店リストリクエストDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class DepartmentStoreAbaRequestDto extends RequestBodyDto {

    /**
     * 郵便番号
     */
    private String zipCode;
}

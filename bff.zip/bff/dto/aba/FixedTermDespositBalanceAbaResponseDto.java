package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 定期預金残高照会レスポンスDTO
 */
@Data
public class FixedTermDespositBalanceAbaResponseDto {

    /**
     * 共通レスポンス・ヘッダ
     */
    private CommonResponseHeader commonResponseHeader;

    /**
     * 定期預金残高照会DTO
     */
    private FixedTermDespositBalanceDto fixedTermDespositBalanceDto;

}

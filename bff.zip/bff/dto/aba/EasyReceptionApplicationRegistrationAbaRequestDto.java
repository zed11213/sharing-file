package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * かんたん受付申込登録ABAリクエストDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class EasyReceptionApplicationRegistrationAbaRequestDto extends RequestBodyDto {

    /**
     * お知らせID
     */
    private String anncmntId;

    /**
     * 非会員フラグ
     */
    private String nonMemberFlg;

    /**
     * CIF番号リスト
     */
    private List<CifNumberDto> cifNoList;

    /**
     * 顧客ID
     */
    private String customerId;

    /**
     * 利用者ID
     */
    private String userId;

    /**
     * カナ氏名
     */
    private String custNameKana;

    /**
     * 漢字氏名
     */
    private String custNameKanji;

    /**
     * 郵便番号
     */
    private String custZipCode;

    /**
     * カナ住所
     */
    private String custAddressKana;

    /**
     * 住所
     */
    private String custAddress;

    /**
     * 電話番号
     */
    private String custPhone;

    /**
     * メールアドレス
     */
    private String custMail;

    /**
     * 受付フォーマット
     */
    private String receptionFormat;

    /**
     * 窓口支店番号
     */
    private String contactBranchNum;

    /**
     * メッセージ内容種別
     */
    private String mobileMsgType;

    /**
     * タイトル
     */
    private String anncmntTitle;

    /**
     * 掲載開始日時
     */
    private String anncmntStartDateAndTime;

    /**
     * 掲載終了日時
     */
    private String anncmntEndDateAndTime;

    /**
     * 作成日時
     */
    private String createDateAndTime;

}

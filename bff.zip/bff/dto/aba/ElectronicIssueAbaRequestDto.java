package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 帳票PDF内容照会ABAリクエストDTO
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class ElectronicIssueAbaRequestDto extends RequestBodyDto {

    /**
     * 帳票ID
     */
    private String formID;

    /**
     * 交付ステータス
     */
    private String deliveryStatus;

    /**
     * 顧客ID
     */
    private String customerID;

    /**
     * 文書種別コード
     */
    private String documentTypeCode;

    /**
     * ロットID
     */
    private String lotID;

    /**
     * 帳票取得開始通番
     */
    private String comDmSequenceNoStart;

    /**
     * 帳票取得終了通番
     */
    private String comDmSequenceNoEnd;

}

package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import jp.co.jsbank.mobile.bff.dto.CurrentAccountDto;
import lombok.Data;

/**
 * 帳票CSV内容照会_当座勘定照合表ABAレスポンスDTO
 */
@Data
public class InquireReport015AbaResponseDto {

    /**
     * 共通レスポンスヘッダ
     */
    private CommonResponseHeader commonResponseHeader;

    /**
     * 帳票バージョン
     */
    private String formVersion;

    /**
     * 作成日
     */
    private String createDate;

    /**
     * 当座勘定明細表リスト
     */
    private List<CurrentAccountDto> currentAccountList;

    /**
     * 取扱店名
     */
    private String branchKanjiName;

    /**
     * 取扱電話番号
     */
    private String branchPhoneNumber;
}

package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 顧客登録情報更新ABAレスボスDTO
 */
@Data
public class CustomerRegistrationInformationUpdateAbaResponseDto {

    /**
     * ABA応答共通ヘッダー
     */
    private CommonResponseHeader commonResponseHeader;

    /**
     * 依頼番号
     */
    private String requestNo;

    /**
     * 最終更新日時
     */
    private String updateDatetime;
}

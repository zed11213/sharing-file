package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 利用者情報ABAリクエストDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class StopTradingAbaRequestDto extends RequestBodyDto {

    /**
     * 利用者ID
     */
    private String userId;

    /**
     * 顧客ID
     */
    private String customerId;

}

package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * CIF番号DTO
 */
@Data
public class CifNumberDto {
	
    /**
     * CIF番号
     */
    private String cifNo;

}

package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 通知預金明細レスポンスDTO
 */
@Data
public class NotificationDepositAbaResponseDto {

	/**
	 * 共通レスポンス・ヘッダ
	 */
	private CommonResponseHeader commonResponseHeader;

	/**
	 * 口座番号
	 */
	private String accountNumber;

	/**
	 * 店番
	 */
	private String branchNumber;

	/**
	 * 通知預金明細DTOリスト
	 */
	private List<NotificationDepositDetailsDto> noticeDepositList;

}

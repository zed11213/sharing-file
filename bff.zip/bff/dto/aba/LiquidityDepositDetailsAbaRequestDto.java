package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 入出金明細(流動性預金)リクエストDTO
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class LiquidityDepositDetailsAbaRequestDto extends RequestBodyDto {

    /**
     * 明細継続フラグ
     */
    private String detailContinuationFlag;

    /**
     * 開始明細ID
     */
    private String detailIdFrom;

    /**
     * 最大検索件数
     */
    private String maxInquiryCount;
    
    /**
     * 預金種目
     */
    private String accountType;
    
    /**
     * 店番
     */
    private String branchNumber;

    /**
     * 顧客ID
     */
    private String customerId;

    /**
     * 口座番号
     */
    private String accountNumber;

    /**
     * 照会開始年月日
     */
    private String dateOfInquiryFrom;

    /**
     * 照会終了年月日
     */
    private String dateOfInquiryTo;
}

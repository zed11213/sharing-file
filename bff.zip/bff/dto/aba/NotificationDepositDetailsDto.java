package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * 通知預金明細DTO
 */
@Data
public class NotificationDepositDetailsDto {

    /**
     * サブNO
     */
    private String subNo;

    /**
     * 明細ID
     */
    private String detailId;

    /**
     * お預かり金額
     */
    private String fundedBalance;

    /**
     * 当初契約日
     */
    private String initialContractDate;

    /**
     * 契約日
     */
    private String contractDate;

    /**
     * 利率
     */
    private String interestRate;

    /**
     * 課税区分（文言）
     */
    private String taxClassName;
}

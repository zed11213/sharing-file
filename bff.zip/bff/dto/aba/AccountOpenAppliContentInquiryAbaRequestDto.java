package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * 口座開設申込内容照会ABAリクエストDTO
 */
@Data
public class AccountOpenAppliContentInquiryAbaRequestDto {

    /**
     * 受付番号
     */
    private String receiptNumber;
    
    /**
     * 人格区分
     */
    private String personType;
}

package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import jp.co.jsbank.mobile.bff.dto.PeriodicTimeDepositDetailsDto;
import lombok.Data;

/**
 * 定期積金明細レスポンスDTO
 */
@Data
public class PeriodicDepositDetailsAbaResponseDto {

    /**
     * 共通レスポンスヘッダ
     */
    private CommonResponseHeader commonResponseHeader;

    /**
     * 定期積金明細DTOリスト
     */
    private List<PeriodicTimeDepositDetailsDto> cumulativeDepositDetails;
}

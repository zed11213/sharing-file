package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * 口座情報ABAレスボスDTO
 */
@Data
public class BankAccountInfoAbaResponseDto {

    /**
     * 口座番号
     */
    private String bankAccountNumber;

    /**
     * キャッシュカード暗証番号
     */
    private String cashCardPassword;
}

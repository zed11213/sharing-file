package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import jp.co.jsbank.mobile.bff.dto.LoginHistoryDetailsDto;
import lombok.Data;

/**
 * ログイン履歴レスポンスDTO
 */
@Data
public class LoginHistoryAbaResponseDto {

    /**
     * 共通レスポンスヘッダ
     */
    private CommonResponseHeader commonResponseHeader;

    /**
     * ログイン履歴DTOリスト
     */
    private List<LoginHistoryDetailsDto> loginHistoryList;
}

package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * 受付通知閲覧AbaリクエストDTO
 */
@Data
public class ApplicationAnswerViewAbaRequestDto {
    /**
     * 利用者ID
     */
    private String userId;
    
    /**
     * お知らせID
     */
    private String informationId;
    
    /**
     * 申込ステータス
     */
    private String applicationStatus;
    
    /**
     * 申込ID
     */
    private String applicationId;

    
}

package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * お知らせ一覧登録AbaレスボスDTO
 */
@Data
public class InformationListRegistrationApiAbaResponseDto  {
	
	 /**
     * 共通レスポンス・ボディ
     */
    private CommonResponseHeader commonResponseHeader;
}

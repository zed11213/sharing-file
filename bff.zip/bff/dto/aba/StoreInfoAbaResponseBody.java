package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 部店照会レスポンスDTO
 */
@Data
public class StoreInfoAbaResponseBody {

	
    /**
     * 共通レスポンス・ボディ
     */
    private CommonResponseHeader commonResponseBody;
    
    /**
     * 部店情報DTOリスト
     */
    private List<StoreInfoDto> storeInfoDtoList;

}

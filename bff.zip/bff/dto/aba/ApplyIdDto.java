package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * 回答先申込ID
 */
@Data
public class ApplyIdDto {
	
    /**
     * 回答先申込ID
     */
    private String applyId;

}

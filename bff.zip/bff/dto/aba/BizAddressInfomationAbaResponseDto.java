package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * biz所在地情報ABAレスポンスDTO
 */
@Data
public class BizAddressInfomationAbaResponseDto {

    /**
     * 共通レスポンスヘッダ
     */
    private CommonResponseHeader commonResponseHeader;
}

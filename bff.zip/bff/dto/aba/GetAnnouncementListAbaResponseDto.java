package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import jp.co.jsbank.mobile.bff.dto.GetAnnouncementListResponseDto;
import lombok.Data;

/**
 * お知らせ一覧参照ABADTO
 */
@Data
public class GetAnnouncementListAbaResponseDto {

    /**
     * 共通レスポンスヘッダ
     */
    private CommonResponseHeader commonResponseHeader;
    
    /**
     * お知らせ一覧取得DtoレスポンスDTO
     */
    private GetAnnouncementListResponseDto getAnnouncementListResponseDto;

}

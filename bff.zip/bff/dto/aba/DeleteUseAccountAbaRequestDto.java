package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 利用口座削除ABAリクエストDTO
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class DeleteUseAccountAbaRequestDto  extends RequestBodyDto {

    /**
     * 顧客ID
     */
    private String customerId;

    /**
     * CIF番号
     */
    private String cifNo;

    // ABAチームのCIF番号体系変更に伴う影響調査対応 店番追加 2025/02/19  start
    /**
     * 店番
     */
    private String branchNumber;
    // ABAチームのCIF番号体系変更に伴う影響調査対応 店番追加 2025/02/19  end

}

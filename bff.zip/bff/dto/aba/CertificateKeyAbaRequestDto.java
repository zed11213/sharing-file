package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 認証キー発行ABAリクエストDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class CertificateKeyAbaRequestDto extends RequestBodyDto {

    /**
     * カナ氏名（姓）
     */
    private String customerLastName;

    /**
     * カナ氏名（名）
     */
    private String customerFirstName;

    /**
     * 漢字氏名（姓）
     */
    private String customerKanjiLastName;

    /**
     * 漢字氏名（名）
     */
    private String customerKanjiFirstName;

    /**
     * 所属
     */
    private String divisionCode;

    /**
     * 利用者ID
     */
    private String bizUserId;

}

package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * キャッシュカード認証リクエストDTO
 */
@Data
public class CashCardAuthAbaRequestDto {
	
    /**
     * 口座番号
     */
    private String bankAccountNumber;

    /**
     * キャッシュカード暗証番号
     */
    private String cashCardPassword;

}

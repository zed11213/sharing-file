package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * 引継ぎ口座情報リクエストDTO
 */
@Data
public class TakeoverAccountInfoAbaRequestDto {

    /**
     * 利用者ID
     */
    private String userId;
}

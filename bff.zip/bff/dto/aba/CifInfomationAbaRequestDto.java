package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * CIF属性照会ABAリクエストDTO
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class CifInfomationAbaRequestDto extends RequestBodyDto {

    /**
     * 顧客ID
     */
    private String customerId;

}

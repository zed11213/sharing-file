package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * IVR認証ABAリクエストDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class IvrAuthorizationAbaRequestDto extends RequestBodyDto {

    /**
     * 受付番号
     */
    private String receiptNumber;

    /**
     * 電話番号
     */
    private String phoneNumber;
    
    /**
     * IVROTP
     */
    private String ivrOTP;

    /**
     * 画面ID
     */
    private String pageId;
    
    /**
     * 更新パターン
     */
    private String updateType;
}

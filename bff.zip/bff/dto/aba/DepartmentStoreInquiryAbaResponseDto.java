package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 部店照会ABAリクエストDTO
 */
@Data
public class DepartmentStoreInquiryAbaResponseDto {

    /**
     * 共通レスポンス・ヘッダ
     */
    private CommonResponseHeader commonResponseHeader;
    
    /**
     * 支店照会件数
     */
    private String branchInquiryCount;
    
    /**
     * 部店照会DTOリスト
     */
    private List<DepartmentStoreInquiryDto> branchList;
}

package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * IVR送信ABAレスポンスDTO
 */
@Data
public class KanaNameInquiryAbaResponseDto {
	
	
	 /**
     * 共通レスポンス・ボディ
     */
    private CommonResponseHeader commonResponseHeader;
    
	 /**
     * 明細情報リスト
     */
    private List<CustomerDto> customerList;
 }

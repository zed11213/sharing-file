package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 定期積金残高照会レスポンスDTO
 */
@Data
public class FixedTermFixedBalanceAbaResponseDto {

    /**
     * 共通レスポンス・ヘッダ
     */
    private CommonResponseHeader commonResponseHeader;

    /**
     * 定期積金残高照会DTO
     */
    private FixedTermFixedBalanceDto fixedTermDespositBalanceDto;

}

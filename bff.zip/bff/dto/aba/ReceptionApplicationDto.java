package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * かんたん受付申込Dto
 */
@Data
public class ReceptionApplicationDto {
    /**
     * かんたん受付ID
     */
    private String receptionId;

    /**
     * 利用者ID
     */
    private String userId;

    /**
     * 申込ID
     */
    private String applicationId;

    /**
     * アプリ会員／非会員
     */
    private String memberNonmember;

    /**
     * CIF番号
     */
    private String cifNum;

    /**
     * 申込日時
     */
    private String applicationTime;

    /**
     * 漢字氏名
     */
    private String kannjiName;

    /**
     * 担当店番
     */
    private String storeNumber;

    /**
     * 申込ステータス
     */
    private String applicationStatus;

}

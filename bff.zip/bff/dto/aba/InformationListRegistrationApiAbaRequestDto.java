package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * お知らせ一覧登録リクエストDTO
 */
@Data
public class InformationListRegistrationApiAbaRequestDto {

    /**
     * 利用者ID
     */
    private String userId;

    /**
     * お知らせID
     */
    private String informationId;
    /**
     * 受付案内タイトル
     */
    private String receptionInformationTitle;
    /**
     * 申込ID
     */
    private String applicationId;
    /**
     * お知らせ種別ID
     */
    private String informationTypeId;
    /**
     * 受付日時
     */
    private String receptionTime;

}

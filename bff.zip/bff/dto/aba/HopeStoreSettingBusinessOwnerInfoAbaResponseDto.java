package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.AccountOpeningApplicationBusinessOwnerInfoDto;
import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 希望店設定ABAレスポンスDTO（個人事業主）
 */
@Data
public class HopeStoreSettingBusinessOwnerInfoAbaResponseDto {

    /**
     * 共通レスポンス・ヘッダ
     */
    private CommonResponseHeader commonResponseHeader;

    /**
     * 受付番号
     * 
     */
    private String receiptNumber;
    
    /**
     * 希望部店
     */
    private String hopeDepartmentStore;
    
    /**
     * 人格区分
     */
    private String personType;
    
    /**
     * 画面ID
     */
    private String screenId;

    /**
     * 口座開設申込情報（個人事業主）DTO
     */
    private AccountOpeningApplicationBusinessOwnerInfoDto soleProprietor;
}

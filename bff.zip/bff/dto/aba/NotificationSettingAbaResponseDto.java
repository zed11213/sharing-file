package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 通知設定情報ABAレスポンスDTO
 */
@Data
public class NotificationSettingAbaResponseDto {
	
	
	 /**
     * 共通レスポンス・ボディ
     */
    private CommonResponseHeader commonResponseHeader;
    
    /**
     * 利用者情報DTO
     */
    private List<SettingInfoDto> settingInfos;
 }

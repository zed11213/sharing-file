package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import jp.co.jsbank.mobile.bff.dto.DiscountedBillCalculationDto;
import lombok.Data;

/**
 * 帳票CSV内容照会_割引手形計算明細表ABAレスポンスDTO
 */
@Data
public class InquireReport018AbaResponseDto {

	/**
	 * 共通レスポンスヘッダ
	 */
	private CommonResponseHeader commonResponseHeader;

	/**
	 * 帳票バージョン
	 */
	private String formVersion;

	/**
	 * 共通作成日付
	 */
	private String comCreateDate;

	/**
	 * 割引手形計算明細表リスト
	 */
	private List<DiscountedBillCalculationDto> discountedBillCalculationList;

	/**
	 * 顧客毎件数項目
	 */
	private String eachCustomerCountItem;

	/**
	 * 徴収済金額
	 */
	private String paymentAmount;

	/**
	 * 取組金額合計
	 */
	private String totalAmountOfEfforts;

	/**
	 * 割引料合計
	 */
	private String totalDiscount;

	/**
	 * 取立料合計
	 */
	private String totalCollectionFee;

	/**
	 * ラベル識別番号
	 */
	private String labelIdentificationNumber;

	/**
	 * 消費税コメント
	 */
	private String consumptionTaxComment;

	/**
	 * 取扱店名
	 */
	private String branchKanjiName;

	/**
	 * 取扱電話番号
	 */
	private String branchPhoneNumber;
}

package jp.co.jsbank.mobile.bff.dto.aba;
import lombok.Data;

/**
 * CIF情報DTO
 */
@Data
public class BalanceGraphDto {

    /**
     * 収支年月
     */
    private String balanceMonth;

    /**
     * 入金額
     */
    private String depositAmount;

    /**
     * 出金額
     */
    private String investedAmount;

    /**
     * 月残高
     */
    private String monthlyBalance; 
}

package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 利用者削除ABAリクエストDTO
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class DeleteUserAbaRequestDto  extends RequestBodyDto {

    /**
     * 顧客ID
     */
    private String customerId;

    /**
     * 利用者ID
     */
    private String userId;

}

package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.AccountInfoDto;
import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 残高情報照会レスポンスDTO
 */
@Data
public class AccountInfoAbaResponseDto {

    /**
     * 共通レスポンス・ヘッダ
     */
    private CommonResponseHeader commonResponseHeader;

    /**
     * 残高情報DTO
     */
    private List<AccountInfoDto> balanceList;
}

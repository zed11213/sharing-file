package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * 受付通知閲覧リクエストDTO
 */
@Data
public class EeceptionNotificationViewRequestDto {

    /**
     * お知らせID
     */
    private String anncmntId;
    
    /**
     * 受付案内ステータス
     */
    private String receptionGuideStatus;
 
}

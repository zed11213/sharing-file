package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 通帳レス設定情報ABAリクエストDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class BankBookLessPreferenceAbaRequestDto extends RequestBodyDto {

    /**
     * CIF番号
     */
    private String cifNumber;

    /**
     * 店番
     */
    private String branchCode;
}

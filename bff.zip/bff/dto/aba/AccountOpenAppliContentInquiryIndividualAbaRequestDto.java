package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 *  口座開設申込内容照会（個人）ABAリクエストDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class AccountOpenAppliContentInquiryIndividualAbaRequestDto extends RequestBodyDto {

	/**
	 * 受付番号
	 */
	private String receiptNumber;

}

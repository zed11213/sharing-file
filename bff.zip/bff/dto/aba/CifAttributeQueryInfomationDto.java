package jp.co.jsbank.mobile.bff.dto.aba;
import lombok.Data;

/**
 * CIF情報DTO
 */
@Data
public class CifAttributeQueryInfomationDto {

    /**
     * CIF番号
     */
    private String cifNo;

    /**
     * 店番
     */
    private String branchCode;
}

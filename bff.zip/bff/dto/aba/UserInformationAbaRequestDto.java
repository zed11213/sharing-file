package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 利用者情報ABAリクエストDTO
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class UserInformationAbaRequestDto extends RequestBodyDto {
    
    /**
     * 利用者区分
     */
    private String userType;
    
    /**
     * 顧客ID
     */
    private String customerId;
    
    /**
     * ステータス
     */
    private String status;

    /**
     * 利用状況
     */
    private String utilizationStatus;

    /**
     * 漢字氏名
     */
    private String customerKanjiName;

    /**
     * カナ氏名
     */
    private String customerName;

    /**
     * 所属
     */
    private String division;

    /**
     * 利用者認証キー
     */
    private String certKey;

    /**
     * メールアドレス
     */
    private String mailAddress;

    /**
     * 設定情報
     */
    private List<SettingInfoDto> settingInfos;

    /**
     * 端末ID
     */
    private String deviceId;

    /**
     * OS
     */
    private String os;
}

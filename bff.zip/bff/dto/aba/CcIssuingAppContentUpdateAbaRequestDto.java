package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * CC発行申込内容更新リクエストDTO
 */
@Data
public class CcIssuingAppContentUpdateAbaRequestDto  {
	
	
	 /**
     * 受付番号
     */
    private String receptionNumber;
    
	 /**
     * CC暗証番号
     */
    private String ccPassword;
    
 }

package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 収支グラフ情報ABAレスポンス・ボディ
 */
@Data
public class BalanceGraphAbaResponseBody {


    /**
     * 共通レスポンス・ボディ
     */
    private CommonResponseHeader commonResponseBody;
    
    /**
     * 収支グラフ情報DTOリスト
     */
    private List<BalanceGraphDto> balanceInfoList;

}

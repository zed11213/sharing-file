package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * 契約管理操作履歴登録リクエストDTO
 */
@Data
public class ContractHistoryRegistrationAbaRequestDto {

    /**
     * 顧客ID
     */
    private String customerId;

    /**
     * 利用者ID
     */
    private String userId;

    /**
     * 人格区分
     */
    private String personalityKubun;

    /**
     * JBAID
     */
    private String jbaid;

    /**
     * 画面ID
     */
    private String screenId;

    /**
     * テーブル
     */
    private String table;

    /**
     * 検索KEY
     */
    private String searchKey;

}

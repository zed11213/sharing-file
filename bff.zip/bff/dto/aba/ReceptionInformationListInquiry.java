package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import jp.co.jsbank.mobile.bff.dto.ReceptionGuideStatusDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * かんたん受付案内一覧照会リクエストDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class ReceptionInformationListInquiry extends RequestBodyDto {

    /**
     * 受付案内種類
     */
    private String receptionGuideType;

    /**
     * タイトル
     */
    private String anncmntTitle;

    /**
     * 掲載開始日from
     */
    private String anncmntStartTimeFrom;

    /**
     * 掲載開始日to
     */
    private String anncmntStartTimeTo;

    /**
     * 掲載終了日from
     */
    private String anncmntEndTimeFrom;

    /**
     * 掲載終了日to
     */
    private String anncmntEndTimeTo;

    /**
     * 受付案内ステータスレスト
     */
    private List<ReceptionGuideStatusDto> receptionGuideStatusList;

    /**
     * 非会員受付有無フラグ
     */
    private String nonMemberAplyFlg;

    /**
     * 公開中フラグ
     */
    private String releasedFlg;

    /**
     * 承認依頼者支店番号
     */
    private String requesterBranch;

    /**
     * 承認依頼者部門コード
     */
    private String requesterDept;

    /**
     * 判定結果
     */
    private String judgementResult;

    /**
     * 本人申請除外フラグ
     */
    private String selfExceptFlg;

    /**
     * 照会開始位置
     */
    private String index;

    /**
     * 照会件数
     */
    private String count;
}

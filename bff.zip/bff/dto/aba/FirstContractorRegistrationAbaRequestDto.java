package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * 初回契約者登録リクエストDTO
 */
@Data
public class FirstContractorRegistrationAbaRequestDto {

    /**
     * CIF番号
     */
    private String cifNumber;

    /**
     * カナ氏名
     */
    private String kanaFullName;

    /**
     * 生年月日
     */
    private String birthdate;

    /**
     * 郵便番号
     */
    private String postalCode;

    /**
     * 電話番号
     */
    private String phoneNumber;

}

package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 収支グラフ情報ABAレスポンスDTO
 */
@Data
public class BalanceGraphAbaResponseDto {

    /**
     * 共通レスポンス・ヘッダ
     */
    private CommonResponseHeader commonResponseHeader;

    /**
     * 収支グラフ情報DTOリスト
     */
    private List<BalanceGraphDto> balanceInfoList;

}

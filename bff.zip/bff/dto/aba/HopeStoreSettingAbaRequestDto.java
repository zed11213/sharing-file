package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * 希望店設定ABAリクエストDTO
 */
@Data
public class HopeStoreSettingAbaRequestDto {

    /**
     * 受付番号
     * 
     */
    private String receiptNumber;
    
    /**
     * 希望部店
     */
    private String hopeDepartmentStore;
    
    /**
     * 人格区分
     */
    private String personType;
    
    /**
     * 画面ID
     */
    private String screenId;
}

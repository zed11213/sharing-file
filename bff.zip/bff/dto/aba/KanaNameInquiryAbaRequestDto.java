package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * カナ氏名照会ABAリクエストDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class KanaNameInquiryAbaRequestDto extends RequestBodyDto {

    /**
     * カナ氏名（姓）                                                  
     */
    private String customerLastName;
    
    /**
     * カナ氏名（名）   
     */
    private String customerFirstName;
    
    /**
     * 生年月日
     */
    private String birthday;
    
    /**
     * 店番
     */
    private String branchNumber;
}

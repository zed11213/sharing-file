package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 利用者属性照会ABAリクエストDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class UserAttributeInquiryAbaRequestDto extends RequestBodyDto {

    /**
     * 顧客ID
     */
    private String customerId;

    /**
     * 利用者ID
     */
    private String userId;

    /**
     * 事業先利用者認証キー
     */
    private String certKey;
}

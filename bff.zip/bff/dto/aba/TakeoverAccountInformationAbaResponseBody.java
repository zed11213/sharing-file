package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;


/**
 * 引継ぎ口座情報レスポンスDTO
 */
@Data
public class TakeoverAccountInformationAbaResponseBody {

	/**
	 * 共通レスポンス・ボディ
	 */
	private CommonResponseHeader commonResponseBody;
	
	// 口座番号 
	private String bankAccountNumber;

}

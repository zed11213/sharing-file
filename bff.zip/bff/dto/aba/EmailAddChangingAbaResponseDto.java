package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * メールアドレス変更AbaレスポンスDTO
 */
@Data
public class EmailAddChangingAbaResponseDto {
	
	
	 /**
     * 共通レスポンス・ボディ
     */
    private CommonResponseHeader commonResponseHeader;
    
    /**
     * 確認コード
     */
    private String confirmationCode;

    /**
     * 番号検証TRXキー
     */
    private String noVerifyTRXKey;
    
    
 }

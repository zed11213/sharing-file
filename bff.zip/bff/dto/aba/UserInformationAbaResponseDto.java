package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 利用者情報ABAレスポンスDTO
 */
@Data
public class UserInformationAbaResponseDto {
    /**
     * 共通レスポンスヘッダ
     */
    private CommonResponseHeader commonResponseHeader;

}

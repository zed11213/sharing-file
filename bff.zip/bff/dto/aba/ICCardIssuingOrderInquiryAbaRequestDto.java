package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * ICカード発行依頼照会ABAリクエストDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class ICCardIssuingOrderInquiryAbaRequestDto extends RequestBodyDto {

    /**
     * 預金種目
     */
    private String accountType;

    /**
     * 店番
     */
    private String branchNumber;

    /**
     * 口座番号
     */
    private String accountNumber;

    /**
     * CC暗証番号
     */
    private String ccPinCode;
}

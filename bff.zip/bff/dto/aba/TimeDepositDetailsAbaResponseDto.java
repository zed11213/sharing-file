package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 定期預金明細レスポンスDTO
 */
@Data
public class TimeDepositDetailsAbaResponseDto {

    /**
     * 共通レスポンス・ヘッダ
     */
    private CommonResponseHeader commonResponseHeader;

    /**
     * 定期預金明細DTOリスト
     */
    private List<TimeDepositDetailsDto> termDepositDetails;
}

package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * デザイン更新ABAレスボスDTO
 */
@Data
public class UpdateDesignInfomationAbaResponseDto {

    /**
     * 共通レスポンス・ボディ
     */
    private CommonResponseHeader commonResponseHeader;
}

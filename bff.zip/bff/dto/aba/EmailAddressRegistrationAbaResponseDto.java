package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * メールアドレス登録ABAレスポンスDTO
 */
@Data
public class EmailAddressRegistrationAbaResponseDto {

	 /**
     * 共通レスポンス・ボディ
     */
    private CommonResponseHeader commonResponseHeader;

	 /**
     * トランザクションコード
     */
    private String transactionCode;


 }

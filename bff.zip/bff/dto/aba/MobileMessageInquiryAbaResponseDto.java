package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import jp.co.jsbank.mobile.bff.dto.VersionDto;
import lombok.Data;

/**
 * モバイルメッセージ詳細照会ABAレスポンスDTO
 */
@Data
public class MobileMessageInquiryAbaResponseDto {

    /**
     * 共通レスポンスヘッダ
     */
    private CommonResponseHeader commonResponseHeader;

    /**
     * お知らせID
     */
    private String anncmntId;
    
    /**
     * バージョンDTOリスト
     */
    private List<VersionDto> versionList;

}

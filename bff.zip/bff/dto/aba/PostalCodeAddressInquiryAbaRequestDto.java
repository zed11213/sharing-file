package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 郵便番号住所リクエストDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class PostalCodeAddressInquiryAbaRequestDto extends RequestBodyDto {

    /**
     * 郵便番号
     */
    private String zipCode;
}

package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * お知らせ一覧リクエストDTO
 */
@Data
public class AnnouncementRequestDto {

    /**
     * お知らせID
     */
    private String anncmntId;
    
    /**
     * 申込ID
     */
    private String applyId;
    
    /**
     * CIF番号
     */
    private String cifNo;

    /**
     * お知らせ種別コード
     */
    private String anncmntType;

    /**
     * 文書種別コード
     */
    private String documentType;

    /**
     * メッセージ内容種別
     */
    private String mobileMsgType;

    /**
     * タイトル検索キーワード
     */
    private String anncmntTitleSearchKeywords;

    /**
     * カナ氏名
     */
    private String customerName;

    /**
     * お気に入りフラグ
     */
    private String bookmarkFlg;

    /**
     * 既読フラグ
     */
    private String readFlg;

    /**
     * 個別確認結果フラグ
     */
    private String confirmFlg;

    /**
     * 公開日期間指定FROM
     */
    private String anncmntDateAndTimeFrom;

    /**
     * 公開日期間指定TO
     */
    private String anncmntDateAndTimeTo;

    /**
     * 掲載開始日時FROM
     */
    private String anncmntStartDateAndTimeFrom;

    /**
     * 掲載開始日時TO
     */
    private String anncmntStartDateAndTimeTo;

    /**
     * 掲載終了日時FROM
     */
    private String anncmntEndDateAndTimeFrom;

    /**
     * 掲載終了日時TO
     */
    private String anncmntEndDateAndTimeTo;

    /**
     * ソート順
     */
    private String sortOrder;

    /**
     * 照会開始位置
     */
    private String index;

    /**
     * 照会件数
     */
    private String count;

    /**
     * お知らせステータス
     */
    private String anncmntStatus;
}

package jp.co.jsbank.mobile.bff.dto.liquidekyc;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import lombok.Data;

/**
 * トークン取得リスポンスDTO
 */
@Data
public class GetTokenResponseDTO {

    /**
     * 連携ID
     */
    private String applicantId;
    
    /**
     * トークン
     */
    private String token;
}

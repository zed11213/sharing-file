package jp.co.jsbank.mobile.bff.dto.liquidekyc;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import lombok.Data;

/**
 * 自動判定結果 結果
 * EkycVerificationResultResponseDto
 */

@Data
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class EkycVerificationResultResponseDto {
    
    /**
     * 真贋確認 結果
     */
    // private EkycVerificationResultDto verificationResult;

    /**
     * 過去ユーザ同一人物判定結果
     * result: 
     * 1：同一人物なし
     * 2：同一人物あり
     */
    // private EkycCommonVerificationResultDto multipleUserVerificationResult;
    
    /**
     * 顔の使い回し判定結果
     * result:
     * 1：検知なし
     * 2：検知あり（自社データ）
     * 3：検知あり（他社データ）
     * 4：検知あり（自社・他社データ）
     * 5：判定エラー
     */
    // private EkycCommonVerificationResultDto reuseFaceVerificationResult;

    /**
     * 本人特定事項の使い回し判定結果
     */
    // private EkycCommonVerificationResultDto reuseIdentificationInformationVerificationResult;

    /**
     * 警告リスト（本人特定事項）判定結果
     * 
     */
    // private EkycCommonVerificationResultDto warningListIdentificationInformationVerificationResult;

    /**
     * 警告リスト(顔）判定結果
     */
    // private EkycCommonVerificationResultDto warningListFaceVerificationResult;

    private OptionalVerificationResultDto optionalVerificationResult;
    
}

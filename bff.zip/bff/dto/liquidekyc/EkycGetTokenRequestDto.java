
package jp.co.jsbank.mobile.bff.dto.liquidekyc;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import lombok.Data;

/**
 * Token取得リクエストDTO
 */
@Data
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class EkycGetTokenRequestDto {

    /**
     *　連携ID
     */
    private String applicantId;

    /**
     * 優先度　　default １　
     */
    private String operationAssignmentPriority;

    /**
     * redirectUrl
     */
    private String redirectUrl;

    /**
     * errorRedirectUrl
     */
    private String errorRedirectUrl;
}
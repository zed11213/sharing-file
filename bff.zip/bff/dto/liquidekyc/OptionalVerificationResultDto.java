package jp.co.jsbank.mobile.bff.dto.liquidekyc;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import java.util.List;
import lombok.Data;

/**
 * ⾃動判定処理オプション
 * EkycCommonVerificationResultDto
 */

@Data
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class OptionalVerificationResultDto {
    /**
     * 総合判定
     * 1：OK
     * 2：NG
     * 4：実施待ち
     */
    private String result;

    /**
     * インジェクション攻撃判定
     * 1：OK
     * 2：NG
     * 3：OFF設定のため未実施または、PCの場
     * 合
     * 4：実施待ち
     */
    private String injectionAttackVerification;

    /**
     * 顔の使い回し判定
     * 1：OK
     * 2：NG
     * 3：OFF設定のため未実施または、PCの場
     * 合
     * 4：実施待ち
     */
    private String reuseFaceVerification;

    /**
     * 本⼈特定事項の使い回し判定
     * 1：OK
     * 2：NG
     * 3：OFF設定のため未実施または、PCの場
     * 合
     * 4：実施待ち
     */
    private String reuseIdentificationInformationVerification;

    /**
     * 警告リスト（本⼈特定事項）判定
     * 1：OK
     * 2：NG
     * 3：OFF設定のため未実施または、PCの場
     * 合
     * 4：実施待ち
     */
    private String warningListIdentificationInformationVerification;

    /**
     * 警告リスト（顔）判定
     * 1：OK
     * 2：NG
     * 3：OFF設定のため未実施または、PCの場
     * 合
     * 4：実施待ち
     */
    private String warningListFaceVerification;
}

package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 割引手形計算明細表DTO
 */
@Data
public class DiscountedBillCalculationDto {

    /**
     * お支払人
     */
    private String payer;

    /**
     * 支払場所
     */
    private String paymentPlace;

    /**
     * 取組年月日
     */
    private String dateOfEfforts;

    /**
     * 取組番号
     */
    private String actionNumber;

    /**
     * 手形種類
     */
    private String billType;

    /**
     * 振出日
     */
    private String drawDate;

    /**
     * 手形金額
     */
    private String billAmount;

    /**
     * 手形期日
     */
    private String billDueDate;

    /**
     * 割引料_日数
     */
    private String discountDays;

    /**
     * 割引料_利率
     */
    private String discountRate;

    /**
     * 割引料_金額
     */
    private String discountAmount;
}

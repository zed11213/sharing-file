package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 認証キー発行BFFリクエストDTO
 */
@Data
public class CertificateKeyRequestDto {

    /**
     * カナ氏名（姓）
     */
    private String customerLastName;

    /**
     * カナ氏名（名）
     */
    private String customerFirstName;

    /**
     * 漢字氏名（姓）
     */
    private String customerKanjiLastName;

    /**
     * 漢字氏名（名）
     */
    private String customerKanjiFirstName;

    /**
     * 所属
     */
    private String divisionCode;

}

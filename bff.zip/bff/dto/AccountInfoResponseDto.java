package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 残高情報照会レスポンスDTO
 */
@Data
public class AccountInfoResponseDto {

	/**
	 * 店番
	 */
	private String branchNumber;

	/**
	 * 店名（漢字）
	 */
	private String branchName;

	/**
	 * 科目コード
	 */
	private String subjectNameCode;

	/**
	 * 科目名（文言）
	 */
	private String subjectNameValue;

	/**
	 * 口座番号
	 */
	private String accountNumber;

	/**
	 * 資金化残高
	 */
	private String fundingBalance;

	/**
	 * 残高
	 */
	private String balance;

	/**
	 * 毎残高の合計
	 */
	private String balanceTotal;

	/**
	 * 総合口座フラグ
	 */
	private String generalAccountFlag;

	/**
	 * 総合口座リンク先-預金種目
	 */
	private String linkedAccountType;

	/**
	 * 総合口座リンク先-店番
	 */
	private String linkedBranchNumber;

	/**
	 * 総合口座リンク先-口座番号
	 */
	private String linkedAccountNumber;

	/**
	 * 総合口座リンク先-サブNo
	 */
	private String linkedSubNumber;

	/**
	 * 解約フラグ
	 */
	private String dissolutionFlg;

	/**
	 * 預金種目
	 */
	private String accountType;

	/**
	 * CIF番号
	 */
	private String cifNo;
}

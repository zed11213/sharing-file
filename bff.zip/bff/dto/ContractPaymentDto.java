package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 約定払込DTO
 */
@Data
public class ContractPaymentDto {

    /**
     * 約定払込年月日
     */
    private String contractPaymentDate;

    /**
     * 合計未払利息額
     */
    private String totalAccruedInterest;
}

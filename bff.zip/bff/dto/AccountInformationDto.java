package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 口座情報DTO
 */
@Data
public class AccountInformationDto {

    /**
     * 口座番号
     */
    private String accountNumber;

    /**
     * 科目名（文言）
     */
    private String subjectNameValue;

}

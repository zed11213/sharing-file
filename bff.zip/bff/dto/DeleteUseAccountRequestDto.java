package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 利用口座削除BFFリクエストDTO
 */
@Data
public class DeleteUseAccountRequestDto {

    /**
     * CIF番号
     */
    private String cifNo;

    // ABAチームのCIF番号体系変更に伴う影響調査対応 店番追加 2025/02/19  start
    /**
     * 店番
     */
    private String branchNumber;
    // ABAチームのCIF番号体系変更に伴う影響調査対応 店番追加 2025/02/19  end
}

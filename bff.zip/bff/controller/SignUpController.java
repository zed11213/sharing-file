package jp.co.jsbank.mobile.bff.controller;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import jp.co.jsbank.mobile.bff.common.JsonResult;
import jp.co.jsbank.mobile.bff.dto.AuthorizationResponseDto;
import jp.co.jsbank.mobile.bff.dto.BankbookPatternPreferenceRequestDto;
import jp.co.jsbank.mobile.bff.dto.BindingNotificationRequestDto;
import jp.co.jsbank.mobile.bff.dto.DepartmentStoreInquiryResponseDto;
import jp.co.jsbank.mobile.bff.dto.EmailAddressAuthorizationRequestDto;
import jp.co.jsbank.mobile.bff.dto.EmailAddressRegistrationRequestDto;
import jp.co.jsbank.mobile.bff.dto.EmailAddressRegistrationResponseDto;
import jp.co.jsbank.mobile.bff.dto.IdentityVerificationRequestDto;
import jp.co.jsbank.mobile.bff.dto.IdentityVerificationResponseDto;
import jp.co.jsbank.mobile.bff.dto.IvrAuthenticationRequestDto;
import jp.co.jsbank.mobile.bff.dto.IvrAuthenticationResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.IvrSendingRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.IvrSendingResponseDto;
import jp.co.jsbank.mobile.bff.service.SignUpService;

/**
 * 初回登録コントロール
 */
@RestController
public class SignUpController {

	@Resource
	private SignUpService signUpService;

	/**
	 * メールアドレス登録
	 *
	 * @param requestDto メールアドレス登録リクエストDTO
	 * @return 処理結果
	 */
	@PostMapping(path = "/sign-up/AB0101")
	public String emailAddressRegistration(@RequestBody EmailAddressRegistrationRequestDto requestDto) {
		EmailAddressRegistrationResponseDto result = signUpService.emailAddressRegistration(requestDto);
		return JsonResult.success(result);
	}

	/**
	 * メールアドレス認証
	 *
	 * @param requestDto メールアドレス認証リクエストDTO
	 * @return 処理結果
	 */
	@PostMapping(path = "/sign-up/AB0102")
	public String emailAddressAuthorization(@RequestBody EmailAddressAuthorizationRequestDto requestDto) {
		AuthorizationResponseDto result = signUpService.emailAddressAuthorization(requestDto);
		return JsonResult.success(result);
	}

	/**
	 * 本人照合
	 *
	 * @param identityVerificationReq 本人照合リクエストDTO
	 * @return 処理結果
	 */
	@PostMapping(path = "/sign-up/AB0103")
	public String identityVerification(@RequestBody IdentityVerificationRequestDto identityVerificationReq) {
		IdentityVerificationResponseDto responseDto = signUpService.identityVerification(identityVerificationReq);
		return JsonResult.success(responseDto);
	}

	/**
	 * IVR送信
	 *
	 * @param requestDto IVR送信リクエストDTO
	 * @return 処理結果
	 */
	@PostMapping(path = "/sign-up/AB0105")
	public String ivrSending(@RequestBody IvrSendingRequestDto requestDto) {
		IvrSendingResponseDto result = signUpService.ivrSending(requestDto);
		return JsonResult.success(result);
	}

	/**
	 * IVR認証
	 *
	 * @param requestDto IVR認証リクエストDTO
	 * @return 処理結果
	 */
	@PostMapping(path = "/sign-up/AB0106")
	public String ivrAuthentication(@RequestBody IvrAuthenticationRequestDto requestDto) {
		IvrAuthenticationResponseDto result = signUpService.ivrAuthentication(requestDto);
		return JsonResult.success(result);
	}

	/**
	 * 部店照会
	 *
	 * @return 処理結果
	 */
	@PostMapping(path = "/sign-up/AB0112")
	public String departmentStoreInquiry() {
		List<DepartmentStoreInquiryResponseDto> butenInquiryLIst = signUpService.departmentStoreInquiry();
		return JsonResult.success(butenInquiryLIst);
	}

	/**
	 * 通帳パターン設定
	 *
	 * @param requestDto 通帳パターン設定リクエストDTO
	 * @return 処理結果
	 */
	@PostMapping(path = "/sign-up/AB0120")
	public String bankbookPatternPreference(@RequestBody BankbookPatternPreferenceRequestDto requestDto) {
		String result = signUpService.bankbookPatternPreference(requestDto);
		return JsonResult.success(result);
	}
	/**
	 * バインディング
	 *
	 * @param requestDto バインディング リソースDTO
	 * @return 処理結果
	 */
	@PostMapping(path = "/sign-up/AB0121")
	public String bindingNotification(@RequestBody BindingNotificationRequestDto requestDto) {
		String result = signUpService.bindingNotification(requestDto);
		return JsonResult.success(result);
	}
}

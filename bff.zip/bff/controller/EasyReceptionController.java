package jp.co.jsbank.mobile.bff.controller;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import jp.co.jsbank.mobile.bff.common.JsonResult;
import jp.co.jsbank.mobile.bff.dto.ApplicationAnswerViewResponseDto;
import jp.co.jsbank.mobile.bff.dto.EasyRegistrationScreenAcquisitionResponseDto;
import jp.co.jsbank.mobile.bff.dto.EasyRegistrationScreenInputInfoSendingRequestDto;
import jp.co.jsbank.mobile.bff.dto.GuidanceInquiryInfTypeIdResponseDto;
import jp.co.jsbank.mobile.bff.dto.ReceptionInformationViewRequestDto;
import jp.co.jsbank.mobile.bff.dto.ReceptionInformationViewResponseDto;
import jp.co.jsbank.mobile.bff.dto.ReceptionNotificationViewRequestDto;
import jp.co.jsbank.mobile.bff.dto.ReceptionNotificationViewResponseDto;
import jp.co.jsbank.mobile.bff.service.EasyReceptionService;

/**
 * かんたん受付コントロール
 */
@RestController
public class EasyReceptionController {

    @Resource
    private EasyReceptionService easyReceptionService;

    /**
     * かんたん受付申込一覧照会
     *
     * @return JsonResult
     */
    @PostMapping(path = "/easy-reception/AB0901")
    public String guidanceInquiryInformationTypeId() {

        // お知らせ種別IDで案内照会
        GuidanceInquiryInfTypeIdResponseDto responseDto = easyReceptionService.guidanceInquiryInformationTypeId();

        return JsonResult.success(responseDto);

    }

    /**
     * 受付案内閲覧
     *
     * @param requestDto 受付案内閲覧リクエストDTO
     * @return JsonResult
     */
    @PostMapping(path = "/easy-reception/AB0902")
    public String receptionInformationView(@RequestBody ReceptionInformationViewRequestDto requestDto) {
        // 受付案内閲覧
        ReceptionInformationViewResponseDto receptionInformationViewResponseDto = easyReceptionService
                .receptionInformationView(requestDto);

        return JsonResult.success(receptionInformationViewResponseDto);
    }

    /**
     * かんたん登録画面取得
     *
     * @return JsonResult
     */
    @PostMapping(path = "/easy-reception/AB0903")
    public String easyRegistrationScreenAcquisition() {

        // かんたん登録画面取得
        EasyRegistrationScreenAcquisitionResponseDto responseDto = easyReceptionService
                .easyRegistrationScreenAcquisition();

        return JsonResult.success(responseDto);
    }

    /**
     * ログイン前受付案内閲覧
     *
     * @param requestDto 受付案内閲覧リクエストDTO
     * @return JsonResult
     */
    @PostMapping(path = "/easy-reception/AB0904")
    public String receptionInformationViewBeforeLogin(@RequestBody ReceptionInformationViewRequestDto requestDto) {
        // 受付案内閲覧
        ReceptionInformationViewResponseDto receptionInformationViewResponseDto = easyReceptionService
                .receptionInformationView(requestDto);

        return JsonResult.success(receptionInformationViewResponseDto);
    }

    /**
     * かんたん登録画面入力情報送信
     *
     * @param requestDto かんたん登録画面入力情報送信リクエストDTO
     * @return JsonResult
     */
    @PostMapping(path = "/easy-reception/AB0905")
    public String easyRegistrationScreenInputInfoSending(
            @RequestBody EasyRegistrationScreenInputInfoSendingRequestDto requestDto) {

        // 受付通知閲覧
        String result = easyReceptionService.easyRegistrationScreenInputInfoSending(requestDto);

        return JsonResult.success(result);
    }

    /**
     * ログイン前かんたん登録画面入力情報送信
     *
     * @param requestDto かんたん登録画面入力情報送信リクエストDTO
     * @return JsonResult
     */
    @PostMapping(path = "/easy-reception/AB0906")
    public String easyRegistrationScreenInputInfoSendingBeforeLogin(
            @RequestBody EasyRegistrationScreenInputInfoSendingRequestDto requestDto) {

        // 受付通知閲覧
        String result = easyReceptionService.easyRegistrationScreenInputInfoSending(requestDto);

        return JsonResult.success(result);
    }

    /**
     * 受付通知閲覧
     *
     * @param requestDto 受付通知閲覧リクエストDTO
     * @return JsonResult
     */
    @PostMapping(path = "/easy-reception/AB0907")
    public String receptionNotificationView(@RequestBody ReceptionNotificationViewRequestDto requestDto) {
        // お知らせID
        String anncmntId = requestDto.getAnncmntId();

        // 申込ID
        String applicationId = requestDto.getApplicationId();

        // 受付通知閲覧
        ReceptionNotificationViewResponseDto result = easyReceptionService.receptionNotificationView(anncmntId,
                applicationId);

        return JsonResult.success(result);
    }

    /**
     * 申込回答閲覧
     *
     * @param requestDto 受付通知閲覧リクエストDTO
     * @return JsonResult
     */
    @PostMapping(path = "/easy-reception/AB0908")
    public String applicationAnswerView(@RequestBody ReceptionInformationViewRequestDto requestDto) {
                                                      
        // 申込回答内容
        ApplicationAnswerViewResponseDto result = easyReceptionService.applicationAnswerView(requestDto);

        return JsonResult.success(result);
    }

}

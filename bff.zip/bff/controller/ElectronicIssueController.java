package jp.co.jsbank.mobile.bff.controller;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import jp.co.jsbank.mobile.bff.common.JsonResult;
import jp.co.jsbank.mobile.bff.dto.ElectronicIssueRequestDto;
import jp.co.jsbank.mobile.bff.dto.InformationViewResponseDto;
import jp.co.jsbank.mobile.bff.service.ElectronicIssueService;

/**
 * 電子交付コントロール
 */
@RestController
public class ElectronicIssueController {

    @Resource
    private ElectronicIssueService electronicIssueService;

    /**
     * お知らせ閲覧
     *
     * @param requestDto 電子交付ABAリクエストDTO
     * 
     * @return JsonResult
     */
    @PostMapping(path = "/electronic-issue/AB0501")
    public String informationView(@RequestBody ElectronicIssueRequestDto requestDto) {

        InformationViewResponseDto result = electronicIssueService.informationView(requestDto);
        return JsonResult.success(result);
    }

    /**
     * 帳票PDFダウンロード
     *
     * @param requestDto 電子交付ABAリクエストDTO
     * @return JsonResult
     */
    @PostMapping(path = "/electronic-issue/AB0502")
    public String reportPdfDownload(@RequestBody ElectronicIssueRequestDto requestDto) {

        Object result = electronicIssueService.reportPdfDownload(requestDto);
        return JsonResult.success(result);
    }

}

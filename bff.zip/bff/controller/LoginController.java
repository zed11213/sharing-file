package jp.co.jsbank.mobile.bff.controller;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import jp.co.jsbank.mobile.bff.common.JsonResult;
import jp.co.jsbank.mobile.bff.dto.LoginHistoryResponseDto;
import jp.co.jsbank.mobile.bff.dto.LoginRequestDto;
import jp.co.jsbank.mobile.bff.service.LoginService;

/**
 * ログインコントロール
 */
@RestController
public class LoginController {

	@Resource
	private LoginService loginService;

	/**
	 * ログイン認証
	 *
	 * @return JsonResult
	 */
	@PostMapping("/login/AB0201")
	public String loginAuthentication(@RequestBody LoginRequestDto requestDto) {

		LoginHistoryResponseDto response = loginService.loginAuthentication(requestDto);
		return JsonResult.success(response);
	}
}

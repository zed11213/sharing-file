package jp.co.jsbank.mobile.bff.common;

import jp.co.jsbank.mobile.bff.common.exception.GlobalExceptionHandler;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.jsbank.mobile.bff.common.exception.InternalServerErrorException;
import jp.co.jsbank.mobile.bff.common.redis.RedisHandler;
import jp.co.jsbank.mobile.bff.common.util.HashHelper;
import jp.co.jsbank.mobile.bff.entity.TokenIdEntity;
import jp.co.jsbank.mobile.bff.service.TokenIdService;

/**
 * ID取得クラス
 */
@Service
public class GetIdByTokenHandler {

	@Autowired
	private RedisHandler redisHandler;

	@Autowired
	private TokenIdService tokenIdService;

	/**
	 * コンストラクタ
	 */
	private GetIdByTokenHandler() {
		super();
	}
    private Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);
	/**
	 * ID取得
	 *
	 * @param tokenId トークンID
	 * @return ID
	 */
	public String getIdByToken(String tokenId) {

		try {
			// redisのIDが存在の場合
			if (redisHandler.exists(tokenId)) {
				return redisHandler.get(tokenId);
			}
		} catch (InternalServerErrorException e) {
			// 処理なし
		}

		try {
			// DBのIDが存在の場合
			String id = tokenIdService.selectIdByToken(tokenId);
            logger.info("setCustomerId3-> " + id);
			if (!StringUtils.isBlank(id)) {
				return id;
			} else {
				// エラー戻る
				throw new InternalServerErrorException(ErrorCodeConstant.ERROR_CODE_MBAP0010, "");
			}
		} catch (Exception e) {
			throw new InternalServerErrorException(ErrorCodeConstant.ERROR_CODE_MBAP0010, "");
		}
	}

	/**
	 * トークン登録
	 *
	 * @param id   ID
	 * @param uuid uuid
	 * @return トークンID
	 */
	public String insertToken(String id, String uuid) {
		// トークン化
		// DBの利用者ID追加
		String resTokenId;
		try {
			String tokenId = HashHelper.cryptoHash(id, uuid);
			// TOKEN_MAPPINGエンティティ
			TokenIdEntity tokenIdEntity = new TokenIdEntity();
			// ID設定
			tokenIdEntity.setId(id);
			// TOKENID設定
			tokenIdEntity.setToken(tokenId);
			resTokenId = tokenIdService.insertIdAndToken(tokenIdEntity);

			if (!StringUtils.equals(tokenId, resTokenId)) {
				// redisの利用者ID設定
				redisHandler.set(tokenId, id);
			}
		} catch (Exception e) {
			// エラー戻る
			throw new InternalServerErrorException(ErrorCodeConstant.ERROR_CODE_MBAP0010, "");
		}

		return resTokenId;
	}
}

package jp.co.jsbank.mobile.bff.common.logger;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import jp.co.jsbank.mobile.bff.common.ErrorCodeConstant;
import jp.co.jsbank.mobile.bff.common.RequestHeaderContext;
import jp.co.jsbank.mobile.bff.config.Config;

/**
 * ログ出力クラス
 */
@Aspect
@Component
public class LoggingAspects {

	/**
	 * ログ出力のためのクラス
	 */
	private static final Logger LOGGER = LoggerFactory.getLogger(LoggingAspects.class);

	/**
	 * 金融機関コード
	 */
	private String bankCode = "1344";
	/**
	 * アプリケーションID
	 */
	private String applicationID = "jsbapp01";
	/**
	 * クライアントID
	 */
	private String clientID = "010000";
	/**
	 * 端末識別するID
	 */
	private String deviceMk = "sm";
	/**
	 * フォーマット
	 */
	private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS z");
	/**
	 * 区切りの文字列
	 */
	private String splitValue = " ";

	/**
	 * Beforeアノテーションのより、指定したメソッドの前に開始ログを追加する。
	 *
	 * @param joinPoint メソッドの情報
	 */
	@Before("execution(* jp.co.jsbank.mobile.bff.controller..*(..))")
	public void controllerStartLog(JoinPoint joinPoint) {

		String args = null;
		String active = Config.getActive();
		if (StringUtils.isNotBlank(active) && "test".equals(active)) {
			if (!joinPoint.getSignature().getName().contains("putSignedUrl")) {
				args = Arrays.toString(joinPoint.getArgs());
			}
		}

		StringBuffer sb = getLogMessage(joinPoint);
		if (args != null) {
			sb.append(args + splitValue);
		}
		sb.append("開始");

		LOGGER.info(sb.toString());
	}

	/**
	 * AfterReturningアノテーションのより、指定したメソッドの後に終了ログを追加する。
	 *
	 * @param joinPoint メソッドの情報
	 * @param returnOb  メソッドの戻り値
	 */
	@AfterReturning(returning = "returnOb", pointcut = "execution(* jp.co.jsbank.mobile.bff.controller..*(..))")
	public void doAfterReturning(JoinPoint joinPoint, Object returnOb) {

        StringBuffer sb = getLogMessage(joinPoint);
        sb.append("終了");

        LOGGER.info(sb.toString());

	}

	/**
	 * ログ本文作成
	 *
	 * @param joinPoint メソッドの情報
	 * @return ログ本文
	 */
	private StringBuffer getLogMessage(JoinPoint joinPoint) {
        // ログ出力時のタイムスタンプ
        String currentTimestamp = "";
        // 取引ID
        String transactionID = RequestHeaderContext.getInstance().getTransactionID();
        // ユーザーID
        String userID = "";
        // 端末ID
        String deviceID = "";
        // 出力箇所
        String invokerName = "";
        // メッセージID
        String messageID = "MWXU0001";
        // ログメッセージ本文
        String messageBody = "";
        // 画面ID
        String gcreenID = "";
        // イベントID
        String eventID = "";
        // 取引通番
        String transactionSeqNo = "";
        // トレースID
        String traceID = "";
        // スレッドID
        String threadID = "";
        // 重大度
        String severity = ErrorCodeConstant.LOG_LABLE_I;
        // コンテキスト・ルート名
        String contextRoot = "";
        // API識別子
        String apiID = "";
        // AIFログレベル
        String aifLogLvNum = "";
        // AIFロガー名
        String aifLogType = "";
        // AIF追跡番号
        String aifTtracNo = "";
        // OS
        String os = "";
        // バージョン
        String version = "";

        // スタックエラーメッセージ情報解析
        invokerName = "LoggingAspects" + "#" + "";

        currentTimestamp = sdf.format(new Date());

        userID = StringUtils.isBlank(RequestHeaderContext.getInstance().getUserIdToken())
                ? RequestHeaderContext.getInstance().getDeviceId()
                : RequestHeaderContext.getInstance().getUserIdToken();
        deviceID = deviceMk + RequestHeaderContext.getInstance().getDeviceId().replace("-", "").toLowerCase();
        invokerName = joinPoint.getSignature().getDeclaringTypeName() + "#" + joinPoint.getSignature().getName();

        gcreenID = RequestHeaderContext.getInstance().getScreenId();
        eventID = RequestHeaderContext.getInstance().getEventID();
        os = RequestHeaderContext.getInstance().getOs();
        version = RequestHeaderContext.getInstance().getVersion();


        StringBuffer sb = new StringBuffer();
        sb.append(currentTimestamp + splitValue);
        sb.append(bankCode + splitValue);
        sb.append(userID + splitValue);
        sb.append(applicationID + splitValue);
        sb.append(clientID + splitValue);
        sb.append(deviceID + splitValue);
        sb.append(messageID + splitValue);
        sb.append(severity + splitValue);
        sb.append(contextRoot + splitValue);
        sb.append(aifLogLvNum + splitValue);
        sb.append(aifLogType + splitValue);
        sb.append(aifTtracNo + splitValue);
        sb.append(traceID + splitValue);
        sb.append(transactionID + splitValue);
        sb.append(transactionSeqNo + splitValue);
        sb.append(threadID + splitValue);
        sb.append(apiID + splitValue);
        sb.append(invokerName + splitValue);
        sb.append(messageBody + splitValue);
        sb.append(gcreenID + splitValue);
        sb.append(eventID + splitValue);
        sb.append(os + splitValue);
        sb.append(version + splitValue);

		return sb;
	}

}

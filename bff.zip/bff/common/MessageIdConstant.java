package jp.co.jsbank.mobile.bff.common;

/**
 * エラーメッセージIDクラス
 */
public class MessageIdConstant {

    /**
     * エラーメッセージID : MBAP0001
     */
    public static final String MESSAGE_ID_MBAP0001 = "MBAP0001";

    /**
     * エラーメッセージID : MBAP0004
     */
    public static final String MESSAGE_ID_MBAP0004 = "MBAP0004";

    /**
     * エラーメッセージID : MBAP0006
     */
    public static final String MESSAGE_ID_MBAP0006 = "MBAP0006";

    /**
     * エラーメッセージID : MBAP0007
     */
    public static final String MESSAGE_ID_MBAP0007 = "MBAP0007";

    /**
     * エラーメッセージID : MBAP0008
     */
    public static final String MESSAGE_ID_MBAP0008 = "MBAP0008";

    /**
     * エラーメッセージID : MBAP0009
     */
    public static final String MESSAGE_ID_MBAP0009 = "MBAP0009";

    /**
     * エラーメッセージID : MBAP0010
     */
    public static final String MESSAGE_ID_MBAP0010 = "MBAP0010";

    /**
     * エラーメッセージID : MBAP0011
     */
    public static final String MESSAGE_ID_MBAP0011 = "MBAP0011";

    /**
     * エラーメッセージID : MBAP0012
     */
    public static final String MESSAGE_ID_MBAP0012 = "MBAP0012";

    /**
     * エラーメッセージID : MBAP0101
     */
    public static final String MESSAGE_ID_MBAP0101 = "MBAP0101";

    /**
     * エラーメッセージID : MBAP0102
     */
    public static final String MESSAGE_ID_MBAP0102 = "MBAP0102";

    /**
     * エラーメッセージID : MBAP0103
     */
    public static final String MESSAGE_ID_MBAP0103 = "MBAP0103";

    /**
     * エラーメッセージID : MBAP01031
     */
    public static final String MESSAGE_ID_MBAP01031 = "MBAP01031";

    /**
     * エラーメッセージID : MBAP01032
     */
    public static final String MESSAGE_ID_MBAP01032 = "MBAP01032";

    /**
     * エラーメッセージID : MBAP0104
     */
    public static final String MESSAGE_ID_MBAP0104 = "MBAP0104";

    /**
     * エラーメッセージID : MBAP1000
     */
    public static final String MESSAGE_ID_MBAP1000 = "MBAP1000";

    /**
     * エラーメッセージID : MBAP1001
     */
    public static final String MESSAGE_ID_MBAP1001 = "MBAP1001";

    /**
     * エラーメッセージID : MBAP1003
     */
    public static final String MESSAGE_ID_MBAP1003 = "MBAP1003";

    /**
     * エラーメッセージID : MBAP1004
     */
    public static final String MESSAGE_ID_MBAP1004 = "MBAP1004";

    /**
     * エラーメッセーMBAP1001ジID : MBAP1005
     */
    public static final String MESSAGE_ID_MBAP1005 = "MBAP1005";

    /**
     * エラーメッセージID : MBAP1006
     */
    public static final String MESSAGE_ID_MBAP1006 = "MBAP1006";

    /**
     * エラーメッセージID : MBAP1008
     */
    public static final String MESSAGE_ID_MBAP1008 = "MBAP1008";

    /**
     * エラーメッセージID : MBAP1010
     */
    public static final String MESSAGE_ID_MBAP1010 = "MBAP1010";

    /**
     * エラーメッセージID : MBAP1011
     */
    public static final String MESSAGE_ID_MBAP1011 = "MBAP1011";

    /**
     * エラーメッセージID : MBAP1014
     */
    public static final String MESSAGE_ID_MBAP1014 = "MBAP1014";

    /**
     * エラーメッセージID : MBAP1013
     */
    public static final String MESSAGE_ID_MBAP1013 = "MBAP1013";

    /**
     * エラーメッセージID : MBAP1015
     */
    public static final String MESSAGE_ID_MBAP1015 = "MBAP1015";

    /**
     * エラーメッセージID : MBAP1016
     */
    public static final String MESSAGE_ID_MBAP1016 = "MBAP1016";

    /**
     * エラーメッセージID : MBAP1017
     */
    public static final String MESSAGE_ID_MBAP1017 = "MBAP1017";

    /**
     * エラーメッセージID : MBAP1018
     */
    public static final String MESSAGE_ID_MBAP1018 = "MBAP1018";

    /**
     * エラーメッセージID : MBAP1019
     */
    public static final String MESSAGE_ID_MBAP1019 = "MBAP1019";

    /**
     * エラーメッセージID : MBAP1020
     */
    public static final String MESSAGE_ID_MBAP1020 = "MBAP1020";

    /**
     * エラーメッセージID : MBAP1021
     */
    public static final String MESSAGE_ID_MBAP1021 = "MBAP1021";

    /**
     * エラーメッセージID : MBAP10211
     */
    public static final String MESSAGE_ID_MBAP10211 = "MBAP10211";

    /**
     * エラーメッセージID : MBAP10212
     */
    public static final String MESSAGE_ID_MBAP10212 = "MBAP10212";

    /**
     * エラーメッセージID : MBAP1022
     */
    public static final String MESSAGE_ID_MBAP1022 = "MBAP1022";

    /**
     * エラーメッセージID : MBAP10221
     */
    public static final String MESSAGE_ID_MBAP10221 = "MBAP10221";

    /**
     * エラーメッセージID : MBAP10222
     */
    public static final String MESSAGE_ID_MBAP10222 = "MBAP10222";

    /**
     * エラーメッセージID : MBAP1023
     */
    public static final String MESSAGE_ID_MBAP1023 = "MBAP1023";

    /**
     * エラーメッセージID : MBAP1024
     */
    public static final String MESSAGE_ID_MBAP1024 = "MBAP1024";

    /**
     * エラーメッセージID : MBAP1025
     */
    public static final String MESSAGE_ID_MBAP1025 = "MBAP1025";

    /**
     * エラーメッセージID : MBAP1026
     */
    public static final String MESSAGE_ID_MBAP1026 = "MBAP1026";

    /**
     * エラーメッセージID : MBAP1027
     */
    public static final String MESSAGE_ID_MBAP1027 = "MBAP1027";

    /**
     * エラーメッセージID : MBAP10271
     */
    public static final String MESSAGE_ID_MBAP10271 = "MBAP10271";

    /**
     * エラーメッセージID : MBAP10131
     */
    public static final String MESSAGE_ID_MBAP10131 = "MBAP10131";

    /**
     * エラーメッセージID : MBAP10132
     */
    public static final String MESSAGE_ID_MBAP10132= "MBAP10132";

    /**
     * エラーメッセージID : MBAP10274
     */
    public static final String MESSAGE_ID_MBAP10274 = "MBAP10274";

    /**
     * エラーメッセージID : MBAP10275
     */
    public static final String MESSAGE_ID_MBAP10275 = "MBAP10275";

    /**
     * エラーメッセージID : MBAP10133
     */
    public static final String MESSAGE_ID_MBAP10133= "MBAP10133";

    /**
     * エラーメッセージID : MBAP1029
     */
    public static final String MESSAGE_ID_MBAP1029 = "MBAP1029";

    /**
     * エラーメッセージID : MBAP10291
     */
    public static final String MESSAGE_ID_MBAP10291 = "MBAP10291";

    /**
     * エラーメッセージID : MBAP10292
     */
    public static final String MESSAGE_ID_MBAP10292 = "MBAP10292";

    /**
     * エラーメッセージID : MBAP1030
     */
    public static final String MESSAGE_ID_MBAP1030 = "MBAP1030";

    /**
     * エラーメッセージID : MBAP10301
     */
    public static final String MESSAGE_ID_MBAP10301 = "MBAP10301";

    /**
     * エラーメッセージID : MBAP10302
     */
    public static final String MESSAGE_ID_MBAP10302 = "MBAP10302";

    /**
     * エラーメッセージID : MBAP1032
     */
    public static final String MESSAGE_ID_MBAP1032 = "MBAP1032";

    /**
     * エラーメッセージID : MBAP1032
     */
    public static final String MESSAGE_ID_MBAP10321 = "MBAP1032";

    /**
     * エラーメッセージID : MBAP10321
     */
    public static final String MESSAGE_ID_MBAP10322 = "MBAP10321";

    /**
     * エラーメッセージID : MBAP1033
     */
    public static final String MESSAGE_ID_MBAP1033 = "MBAP1033";

    /**
     * エラーメッセージID : MBAP1034
     */
    public static final String MESSAGE_ID_MBAP1034 = "MBAP1034";
    /**
     * エラーメッセージID : MBAP10341
     */
    public static final String MESSAGE_ID_MBAP10341 = "MBAP10341";

    /**
     * エラーメッセージID : MBAP1040
     */
    public static final String MESSAGE_ID_MBAP1040 = "MBAP1040";

    /**
     * エラーメッセージID : MBAP1041
     */
    public static final String MESSAGE_ID_MBAP1041 = "MBAP1041";

    /**
     * エラーメッセージID : MBAP1042
     */
    public static final String MESSAGE_ID_MBAP1042 = "MBAP1042";

    /**
     * エラーメッセージID : MBAP1047
     */
    public static final String MESSAGE_ID_MBAP1047 = "MBAP1047";

    /**
     * エラーメッセージID : MBAP1048
     */
    public static final String MESSAGE_ID_MBAP1048 = "MBAP1048";

    /**
     * エラーメッセージID : MBAP1049
     */
    public static final String MESSAGE_ID_MBAP1049 = "MBAP1049";

    /**
     * エラーメッセージID : MBAP1050
     */
    public static final String MESSAGE_ID_MBAP1050 = "MBAP1050";

    /**
     * エラーメッセージID : MBAP1051
     */
    public static final String MESSAGE_ID_MBAP1051 = "MBAP1051";

    /**
     * エラーメッセージID : MBAP1052
     */
    public static final String MESSAGE_ID_MBAP1052 = "MBAP1052";

    /**
     * エラーメッセージID : MBAP1054
     */
    public static final String MESSAGE_ID_MBAP1054 = "MBAP1054";

    /**
     * エラーメッセージID : MBAP1061
     */
    public static final String MESSAGE_ID_MBAP1061 = "MBAP1061";

    /**
     * エラーメッセージID : MBAP1063
     */
    public static final String MESSAGE_ID_MBAP1063 = "MBAP1063";

    /**
     * エラーメッセージID : MBAP1053
     */
    public static final String MESSAGE_ID_MBAP1053 = "MBAP1053";

    /**
     * エラーメッセージID : MBAP1100
     */
    public static final String MESSAGE_ID_MBAP1100 = "MBAP1100";

    /**
     * エラーメッセージID : MBAP1102
     */
    public static final String MESSAGE_ID_MBAP1102 = "MBAP1102";

    /**
     * エラーメッセージID : MBAP1103
     */
    public static final String MESSAGE_ID_MBAP1103 = "MBAP1103";

    /**
     * エラーメッセージID : MBAP1200
     */
    public static final String MESSAGE_ID_MBAP1200 = "MBAP1200";

    /**
     * エラーメッセージID : MBAP12001
     */
    public static final String MESSAGE_ID_MBAP12001 = "MBAP12001";


    /**
     * エラーメッセージID : MBAP1201
     */
    public static final String MESSAGE_ID_MBAP1201 = "MBAP1201";

    /**
     * エラーメッセージID : MBAP1202
     */
    public static final String MESSAGE_ID_MBAP1202 = "MBAP1202";

    /**
     * エラーメッセージID : MBAP1205
     */
    public static final String MESSAGE_ID_MBAP1205 = "MBAP1205";

    /**
     * エラーメッセージID : MBAP1206
     */
    public static final String MESSAGE_ID_MBAP1206 = "MBAP1206";

    /**
     * エラーメッセージID : MBAP1207
     */
    public static final String MESSAGE_ID_MBAP1207 = "MBAP1207";

    /**
     * エラーメッセージID : MBAP1208
     */
    public static final String MESSAGE_ID_MBAP1208 = "MBAP1208";

    /**
     * エラーメッセージID : MBAP1209
     */
    public static final String MESSAGE_ID_MBAP1209 = "MBAP1209";

    /**
     * エラーメッセージID : MBAP1210
     */
    public static final String MESSAGE_ID_MBAP1210 = "MBAP1210";

    /**
     * エラーメッセージID : MBAP1212
     */
    public static final String MESSAGE_ID_MBAP1212 = "MBAP1212";

    /**
     * エラーメッセージID : MBAP1213
     */
    public static final String MESSAGE_ID_MBAP1213 = "MBAP1213";

    /**
     * エラーメッセージID : MBAP1217
     */
    public static final String MESSAGE_ID_MBAP1217 = "MBAP1217";

    /**
     * エラーメッセージID : MBAP1218
     */
    public static final String MESSAGE_ID_MBAP1218 = "MBAP1218";

    /**
     * エラーメッセージID : MBAP1219
     */
    public static final String MESSAGE_ID_MBAP1219 = "MBAP1219";

    /**
     * エラーメッセージID : MBAP1220
     */
    public static final String MESSAGE_ID_MBAP1220 = "MBAP1220";

    /**
     * エラーメッセージID : MBAP1302
     */
    public static final String MESSAGE_ID_MBAP1302 = "MBAP1302";

    /**
     * エラーメッセージID：MBAP13021
     */
    public static final String MESSAGE_ID_MBAP13021 = "MBAP13021";

    /**
     * エラーメッセージID：MBAP13022
     */
    public static final String MESSAGE_ID_MBAP13022 = "MBAP13022";

    /**
     * エラーメッセージID : MBAP1303
     */
    public static final String MESSAGE_ID_MBAP1303 = "MBAP1303";

    /**
     * エラーメッセージID：MBAP13031
     */
    public static final String MESSAGE_ID_MBAP13031 = "MBAP13031";

    /**
     * エラーメッセージID：MBAP13032
     */
    public static final String MESSAGE_ID_MBAP13032 = "MBAP13032";

    /**
     * エラーメッセージID : MBAP1304
     */
    public static final String MESSAGE_ID_MBAP1304 = "MBAP1304";

    /**
     * エラーメッセージID : MBAP1305
     */
    public static final String MESSAGE_ID_MBAP1305 = "MBAP1305";

    /**
     * エラーメッセージID : MBAP1306
     */
    public static final String MESSAGE_ID_MBAP1306 = "MBAP1306";

    /**
     * エラーメッセージID : MBAP1307
     */
    public static final String MESSAGE_ID_MBAP1307 = "MBAP1307";

    /**
     * エラーメッセージID : MBAP1308
     */
    public static final String MESSAGE_ID_MBAP1308 = "MBAP1308";

    /**
     * エラーメッセージID : MBAP1309
     */
    public static final String MESSAGE_ID_MBAP1309 = "MBAP1309";

    /**
     * エラーメッセージID : MBAP1007
     */
    public static final String MESSAGE_ID_MBAP1007 = "MBAP1007";

    /**
     * エラーメッセージID : MBAP1002
     */
    public static final String MESSAGE_ID_MBAP1002 = "MBAP1002";

    /**
     * エラーメッセージID : MBAP1009
     */
    public static final String MESSAGE_ID_MBAP1009 = "MBAP1009";

    /**
     * エラーメッセージID : MBOP0003
     */
    public static final String MESSAGE_ID_MBOP0003 = "MBOP0003";

    /**
     * エラーメッセージID : MBSU0001
     */
    public static final String MESSAGE_ID_MBSU0001 = "MBSU0001";

    /**
     * エラーメッセージID : MBSU0002
     */
    public static final String MESSAGE_ID_MBSU0002 = "MBSU0002";

    /**
     * エラーメッセージID : MBSU0003
     */
    public static final String MESSAGE_ID_MBSU0003 = "MBSU0003";

    /**
     * エラーメッセージID : MBSU0004
     */
    public static final String MESSAGE_ID_MBSU0004 = "MBSU0004";

    /**
     * エラーメッセージID : MBAP1044
     */
    public static final String MESSAGE_ID_MBAP1044 = "MBAP1044";

    /**
     * エラーメッセージID : MBAP1045
     */
    public static final String MESSAGE_ID_MBAP1045 = "MBAP1045";

    /**
     * エラーメッセージID : MBAP1055
     */
    public static final String MESSAGE_ID_MBAP1055 = "MBAP1055";

    /**
     * エラーメッセージID : MBAP1062
     */
    public static final String MESSAGE_ID_MBAP1062 = "MBAP1062";

    /**
     * エラーメッセージID : MBAP1401
     */
    public static final String MESSAGE_ID_MBAP1401 = "MBAP1401";

    /**
     * エラーメッセージID : MBAP1402
     */
    public static final String MESSAGE_ID_MBAP1402 = "MBAP1402";

    /**
     * エラーメッセージID : MBAP1406
     */
    public static final String MESSAGE_ID_MBAP1406 = "MBAP1406";

    /**
     * エラーメッセージID : MBAP1407
     */
    public static final String MESSAGE_ID_MBAP1407 = "MBAP1407";

    /**
     * エラーメッセージID : MBAP1408
     */
    public static final String MESSAGE_ID_MBAP1408 = "MBAP1408";

    /**
     * エラーメッセージID : MBAP1410
     */
    public static final String MESSAGE_ID_MBAP1410 = "MBAP1410";

    /**
     * エラーメッセージID : MBAP1412
     */
    public static final String MESSAGE_ID_MBAP1412 = "MBAP1412";

    /**
     * エラーメッセージID : MBAP1211
     */
    public static final String MESSAGE_ID_MBAP1211 = "MBAP1211";

    /**
     * エラーメッセージID : MBAP1058
     */
    public static final String MESSAGE_ID_MBAP1058 = "MBAP1058";

    /**
     * エラーメッセージID : MBAP1066
     */
    public static final String MESSAGE_ID_MBAP1066 = "MBAP1066";

    /**
     * エラーメッセージID : MBAP1067
     */
    public static final String MESSAGE_ID_MBAP1067 = "MBAP1067";

    /**
     * エラーメッセージID : MBAP1068
     */
    public static final String MESSAGE_ID_MBAP1068 = "MBAP1068";

    /**
     * エラーメッセージID : MBAP1069
     */
    public static final String MESSAGE_ID_MBAP1069 = "MBAP1069";

    /**
     * エラーメッセージID : MBAP1070
     */
    public static final String MESSAGE_ID_MBAP1070 = "MBAP1070";

    /**
     * エラーメッセージID : MBAP1071
     */
    public static final String MESSAGE_ID_MBAP1071 = "MBAP1071";

    /**
     * エラーメッセージID : MBAP1404
     */
    public static final String MESSAGE_ID_MBAP1404 = "MBAP1404";

    /**
     * エラーメッセージID : MBAP1215
     */
    public static final String MESSAGE_ID_MBAP1215 = "MBAP1215";

    /**
     * エラーメッセージID : MBAP0105
     */
    public static final String MESSAGE_ID_MBAP0105 = "MBAP0105";

    /**
     * エラーメッセージID : MBOP0004
     */
    public static final String MESSAGE_ID_MBOP0004 = "MBOP0004";

    /**
     * エラーメッセージID : MBST0001
     */
    public static final String MESSAGE_ID_MBST0001 = "MBST0001";

    /**
     * エラーメッセージID : MBST0002
     */
    public static final String MESSAGE_ID_MBST0002 = "MBST0002";

    /**
     * エラーメッセージID : MBST0003
     */
    public static final String MESSAGE_ID_MBST0003 = "MBST0003";

    /**
     * エラーメッセージID : MBST0004
     */
    public static final String MESSAGE_ID_MBST0004 = "MBST0004";


    /**
     * エラーメッセージID : MBCC0001
     */
    public static final String MESSAGE_ID_MBCC0001 = "MBCC0001";


    /**
     * エラーメッセージID : MBST0005
     */
    public static final String MESSAGE_ID_MBST0005 = "MBST0005";

    /**
     * エラーメッセージID : MBST0006
     */
    public static final String MESSAGE_ID_MBST0006 = "MBST0006";

    // 以下はBAエラー
    /**
     * エラーメッセージID : MBBA0000
     */
    public static final String MESSAGE_ID_MBBA0000 = "MBBA0000";

    /**
     * エラーメッセージID : MBBA0001
     */
    public static final String MESSAGE_ID_MBBA0001 = "MBBA0001";

    /**
     * エラーメッセージID : MBBA0003
     */
    public static final String MESSAGE_ID_MBBA0003 = "MBBA0003";

    /**
     * エラーメッセージID : MBBA0005
     */
    public static final String MESSAGE_ID_MBBA0005 = "MBBA0005";
    /**
     * エラーメッセージID : MBBA0007
     */
    public static final String MESSAGE_ID_MBBA0007 = "MBBA0007";

    /**
     * エラーメッセージID : MBBA1000
     */
    public static final String MESSAGE_ID_MBBA1000 = "MBBA1000";

    /**
     * エラーメッセージID : MBBA1001
     */
    public static final String MESSAGE_ID_MBBA1001 = "MBBA1001";

    /**
     * エラーメッセージID : MBBA1002
     */
    public static final String MESSAGE_ID_MBBA1002 = "MBBA1002";

    /**
     * エラーメッセージID : MBBA1003
     */
    public static final String MESSAGE_ID_MBBA1003 = "MBBA1003";

     /**
     * エラーメッセージID : MBBA1004
     */
    public static final String MESSAGE_ID_MBBA1004 = "MBBA1004";

     /**
     * エラーメッセージID : MBBA1005
     */
    public static final String MESSAGE_ID_MBBA1005 = "MBBA1005";

     /**
     * エラーメッセージID : MBBA1006
     */
    public static final String MESSAGE_ID_MBBA1006 = "MBBA1006";

     /**
     * エラーメッセージID : MBBA1007
     */
    public static final String MESSAGE_ID_MBBA1007 = "MBBA1007";

     /**
     * エラーメッセージID : MBBA1008
     */
    public static final String MESSAGE_ID_MBBA1008 = "MBBA1008";

    /**
     * エラーメッセージID : MBBA1009
     */
    public static final String MESSAGE_ID_MBBA1009 = "MBBA1009";

    /**
     * エラーメッセージID : MBBA1010
     */
    public static final String MESSAGE_ID_MBBA1010 = "MBBA1010";

     /**
     * エラーメッセージID : MBBA1011
     */
    public static final String MESSAGE_ID_MBBA1011 = "MBBA1011";

     /**
     * エラーメッセージID : MBBA1012
     */
    public static final String MESSAGE_ID_MBBA1012 = "MBBA1012";

     /**
     * エラーメッセージID : MBBA1013
     */
    public static final String MESSAGE_ID_MBBA1013 = "MBBA1013";

     /**
     * エラーメッセージID : MBBA1014
     */
    public static final String MESSAGE_ID_MBBA1014 = "MBBA1014";

     /**
     * エラーメッセージID : MBBA1015
     */
    public static final String MESSAGE_ID_MBBA1015 = "MBBA1015";

     /**
     * エラーメッセージID : MBBA1016
     */
    public static final String MESSAGE_ID_MBBA1016 = "MBBA1016";

     /**
     * エラーメッセージID : MBBA1017
     */
    public static final String MESSAGE_ID_MBBA1017 = "MBBA1017";

     /**
     * エラーメッセージID : MBBA1018
     */
    public static final String MESSAGE_ID_MBBA1018 = "MBBA1018";

     /**
     * エラーメッセージID : MBBA1019
     */
    public static final String MESSAGE_ID_MBBA1019 = "MBBA1019";

     /**
     * エラーメッセージID : MBBA1020
     */
    public static final String MESSAGE_ID_MBBA1020 = "MBBA1020";

     /**
     * エラーメッセージID : MBBA1021
     */
    public static final String MESSAGE_ID_MBBA1021 = "MBBA1021";

    /**
     * エラーメッセージID : MBBA1022
     */
    public static final String MESSAGE_ID_MBBA1022 = "MBBA1022";

    /**
     * エラーメッセージID : MBBA1023
     */
    public static final String MESSAGE_ID_MBBA1023 = "MBBA1023";

    /**
     * エラーメッセージID : MBBA1024
     */public static final String MESSAGE_ID_MBBA1024 = "MBBA1024";

     /**
     * エラーメッセージID : MBBA1025
     */
    public static final String MESSAGE_ID_MBBA1025 = "MBBA1025";

     /**
     * エラーメッセージID : MBBA1026
     */
    public static final String MESSAGE_ID_MBBA1026 = "MBBA1026";

    /**
     * エラーメッセージID : MBBA1027
     */
    public static final String MESSAGE_ID_MBBA1027 = "MBBA1027";

    /**
     * エラーメッセージID : MBBA1028
     */
    public static final String MESSAGE_ID_MBBA1028 = "MBBA1028";

    /**
     * エラーメッセージID : MBBA1029
     */
    public static final String MESSAGE_ID_MBBA1029 = "MBBA1029";

    /**
     * エラーメッセージID : MBBA1030
     */
    public static final String MESSAGE_ID_MBBA1030 = "MBBA1030";

    /**
     * エラーメッセージID : MBBA1031
     */
    public static final String MESSAGE_ID_MBBA1031 = "MBBA1031";

    /**
     * エラーメッセージID : MBBA1032
     */
    public static final String MESSAGE_ID_MBBA1032 = "MBBA1032";

    /**
     * エラーメッセージID : MBBA1033
     */
    public static final String MESSAGE_ID_MBBA1033 = "MBBA1033";

    /**
     * エラーメッセージID : MBBA1034
     */
    public static final String MESSAGE_ID_MBBA1034 = "MBBA1034";

     /**
     * エラーメッセージID : MBBA1035
     */
    public static final String MESSAGE_ID_MBBA1035 = "MBBA1035";

     /**
     * エラーメッセージID : MBBA1036
     */
    public static final String MESSAGE_ID_MBBA1036 = "MBBA1036";

     /**
     * エラーメッセージID : MBBA1037
     */
    public static final String MESSAGE_ID_MBBA1037 = "MBBA1037";

     /**
     * エラーメッセージID : MBBA1038
     */
    public static final String MESSAGE_ID_MBBA1038 = "MBBA1038";

    /**
     * エラーメッセージID : MBBA1039
     */
    public static final String MESSAGE_ID_MBBA1039 = "MBBA1039";

    /**
     * エラーメッセージID : MBBA1040
     */
    public static final String MESSAGE_ID_MBBA1040 = "MBBA1040";

    /**
     * エラーメッセージID : MBBA1041
     */
    public static final String MESSAGE_ID_MBBA1041 = "MBBA1041";

     /**
     * エラーメッセージID : MBBA1042
     */
    public static final String MESSAGE_ID_MBBA1042 = "MBBA1042";

     /**
     * エラーメッセージID : MBBA1043
     */
    public static final String MESSAGE_ID_MBBA1043 = "MBBA1043";

     /**
     * エラーメッセージID : MBBA1044
     */
    public static final String MESSAGE_ID_MBBA1044 = "MBBA1044";

     /**
     * エラーメッセージID : MBBA1045
     */
    public static final String MESSAGE_ID_MBBA1045 = "MBBA1045";

     /**
     * エラーメッセージID : MBBA1046
     */
    public static final String MESSAGE_ID_MBBA1046 = "MBBA1046";

    /**
     * エラーメッセージID : MBBA1047
     */
    public static final String MESSAGE_ID_MBBA1047 = "MBBA1047";

    /**
     * エラーメッセージID : MBBA1048
     */
    public static final String MESSAGE_ID_MBBA1048 = "MBBA1048";

    /**
     * エラーメッセージID : MBBA1049
     */
    public static final String MESSAGE_ID_MBBA1049 = "MBBA1049";

    /**
     * エラーメッセージID : MBBA2000
     */
    public static final String MESSAGE_ID_MBBA2000 = "MBBA2000";

    /**
     * エラーメッセージID : MBBA5000
     */
    public static final String MESSAGE_ID_MBBA5000 = "MBBA5000";

    /**
     * エラーメッセージID : MBBA5001
     */
    public static final String MESSAGE_ID_MBBA5001 = "MBBA5001";

    /**
     * エラーメッセージID : MBBA5002
     */
    public static final String MESSAGE_ID_MBBA5002 = "MBBA5002";

    /**
     * エラーメッセージID : MBBA5003
     */
    public static final String MESSAGE_ID_MBBA5003 = "MBBA5003";

    /**
     * エラーメッセージID : MBBA9999
     */
    public static final String MESSAGE_ID_MBBA9999 = "MBBA9999";

    /**
     * エラーメッセージID : MBBA9998 想定外のホストエラー
     */
    public static final String MESSAGE_ID_MBBA9998 = "MBBA9998";

    /**
     * エラーメッセージID : MBBA1050 受付可否エラー
     */
    public static final String MESSAGE_ID_MBBA1050 = "MBBA1050";

    /**
     * ファイル授受エラーメッセージID : MBFS0001
     */
    public static final String MESSAGE_ID_MBFS0001 = "MBFS0001";

    /**
     * ファイル授受エラーメッセージID : MBFS0002
     */
    public static final String MESSAGE_ID_MBFS0002 = "MBFS0002";

    /**
     * ファイル授受エラーメッセージID : MBFS0003
     */
    public static final String MESSAGE_ID_MBFS0003 = "MBFS0003";

    /**
     * ファイル授受エラーメッセージID : MBFS0003
     */
    public static final String MESSAGE_ID_MBFS0004 = "MBFS0004";

    /**
     * ファイル授受エラーメッセージID : MBFS0005
     */
    public static final String MESSAGE_ID_MBFS0005 = "MBFS0005";

    /**
     * ファイル授受エラーメッセージID : MBFS0006
     */
    public static final String MESSAGE_ID_MBFS0006 = "MBFS0006";

    /**
     * ファイル授受エラーメッセージID : MBFS0007
     */
    public static final String MESSAGE_ID_MBFS0007 = "MBFS0007";

    /**
     * ファイル授受エラーメッセージID : MBFS0008
     */
    public static final String MESSAGE_ID_MBFS0008 = "MBFS0008";

}

package jp.co.jsbank.mobile.bff.common;

import java.util.Map;

/**
 * 定数クラス
 */
public class Constant {

    // 共同化でホスト名変更対応 2024/12/10 start
	// 全て環境変数を取得する
	public static final Map<String, String> envs = System.getenv();
	// 共同化でホスト名変更対応 2024/12/10 end

    /**
     * JSON KEY: code
     */
    public static final String JSON_RESULT_CODE = "code";

    /**
     * JSON KEY: data
     */
    public static final String JSON_RESULT_DATA = "data";

    /**
     * ログ出力時のタイムスタンプ
     */
    public static final String CURRENT_TIMESTAMP = "yyyy-MM-dd HH:mm:ss.SSS z";

    /**
     * 固定ログメッセージテキスト: SYSTEM
     */
    public static final String SYSTEM = "SYSTEM";

    /**
     * 空の記号
     */
    public static final String EMPTY_SYMBOL = " ";

    /**
     * 金融機関コード固定値：城南信金： '1344'
     */
    public static final String FIXED_VALUE_FINANCIAL_CODE = "1344";
    /**
     * アプリケーションID固定値：'jsbapp01'　
     */
    public static final String FIXED_VALUE_APPLICATION_ID = "jsbapp01";

    /**
     * クライアントID固定値： '000001'
     */
    public static final String FIXED_VALUE_CLIENT_ID = "000001";

    /**
     * クライアントID固定値:スマホ(個人向け)： '040000'
     */
    public static final String FIXED_VALUE_CLIENT_ID_FOR_PERSONAL = "040000";

    /**
     * クライアントID固定値:スマホ(法人向け)： '050000'
     */
    public static final String FIXED_VALUE_CLIENT_ID_FOR_CORPORATE = "050000";

    /**
     * 処理結果： OK
     */
    public static final String OK = "OK";

    /**
     * 処理結果： Fail
     */
    public static final String FAIL = "Fail";

    /**
     * ""
     */
    public static final String EMPTY = "";

    /**
     * 公開フラグ
     */
    public static final String PUBLIC_FLG = "1";

    /**
     * IOS
     */
    public static final String IOS = "2";

    /**
     * ANDROID
     */
    public static final String ANDROID = "1";

    /**
     * 東京都
     */
    public static final String TOKYO = "東京都";

    /**
     * 神奈川県
     */
    public static final String KANAGAWA_PREFECTURE = "神奈川県";

    /**
     * 川崎市
     */
    public static final String KAWASAKI_CITY = "川崎市";

    /**
     * 横浜市
     */
    public static final String YOKOHAMA_CITY = "横浜市";

    /**
     * 相模原市
     */
    public static final String SAGAMIHARA_CITY = "相模原市";

    /**
     * 大和市
     */
    public static final String YAMATO_CITY = "大和市";

    /**
     * 厚木市
     */
    public static final String ATSUGI_CITY = "厚木市";

    /**
     * 海老名市
     */
    public static final String EBINA_CITY = "海老名市";

    /**
     * 座間市
     */
    public static final String ZAMA_CITY = "座間市";

    /**
     * 藤沢市
     */
    public static final String FUJISAWA_CITY = "藤沢市";

    /**
     * 伊勢原市
     */
    public static final String ISEHARA_CITY = "伊勢原市";

    /**
     * 綾瀬市
     */
    public static final String AYASE_CITY = "綾瀬市";

    /**
     * 平塚市
     */
    public static final String HIRATSUKA = "平塚市";

    /**
     * 秦野市
     */
    public static final String HADANO_CITY = "秦野市";

    /**
     * 茅ケ崎市
     */
    public static final String CHIGASAKI_CITY = "茅ケ崎市";

    /**
     * 鎌倉市
     */
    public static final String KAMAKURA_CITY = "鎌倉市";

    /**
     * 高座郡
     */
    public static final String KOZA_DISTRICT = "高座郡";

    /**
     * 愛甲郡
     */
    public static final String AIKO_GUN = "愛甲郡";

     // 共同化ため ホスト名変更対応 2024/12/10 start
    /**
     * GATEWAY_BASE_URL
     */
    public static final String JAG_BASE_PATH = envs.get("JAG_BASE_PATH");
    public static final String GATEWAY_BASE_URL = "http://"+JAG_BASE_PATH;

    /**
     * 業務共通
     */
    public static final String ABA_COMMONUTILS_PATH = envs.get("ABA_COMMONUTILS_PATH");
    public static final String ABA_BASE_COMMONUTILS_URL = "http://"+ABA_COMMONUTILS_PATH+"/commonutils";

    /**
     * 契約管理
     */
    public static final String ABA_CONTRACT_PATH = envs.get("ABA_CONTRACT_PATH");
    public static final String ABA_BASE_CONTRACT_URL = "http://"+ABA_CONTRACT_PATH+"/contract";
    /**
     * 電子通帳
     */
    public static final String ABA_DIGITALPASSBOOK_PATH = envs.get("ABA_DIGITALPASSBOOK_PATH");
    public static final String ABA_BASE_DIGITALPASSBOOK_URL = "http://"+ABA_DIGITALPASSBOOK_PATH+"/digitalpassbook";

    /**
     * 電子交付
     */
    public static final String ABA_DIGITALREPORT_PATH = envs.get("ABA_DIGITALREPORT_PATH");
    public static final String ABA_BASE_DIGITALREPORT_URL = "http://"+ABA_DIGITALREPORT_PATH+"/digitalreport";

    /**
     * 顧客管理
     */
    public static final String ABA_MOBILEAPPCUSTOMER_PATH = envs.get("ABA_MOBILEAPPCUSTOMER_PATH");
    public static final String ABA_BASE_MOBILEAPPCUSTOMER_URL = "http://"+ABA_MOBILEAPPCUSTOMER_PATH+"/mobileappcustomer";

	/**
	 * 通知管理
	 */
    public static final String ABA_NOTIFICATION_PATH = envs.get("ABA_NOTIFICATION_PATH");
	public static final String ABA_BASE_NOTFICATION_URL = "http://"+ABA_NOTIFICATION_PATH+"/notification";
	// 共同化ため ホスト名変更対応 2024/12/10 end

	// 2025/01/27 共同化ため バンキングアプリでのチェック項目の確認（注意コード等）対応 BAホスト satart
	/**
	 * BAホスト名
	 */
	public static final String YJB_SVC_BA_V2BACKENDADAPTER_HOST ="http://yjb-svc-ba-v2backendadapter:9443";
	// 2025/01/27 共同化ため バンキングアプリでのチェック項目の確認（注意コード等）対応 BAホスト end

	/**
	 * 契約管理操作履歴照会
	 */
	public static final String CONTRACTMANAGE_HISTORY_INQUIRY = "/v1.4.3/contractManage/history/inquiry";

	/**
	 * 口座開設申込内容照会（法人）
	 */
	public static final String ACCOUNTOPEN_APPLICONTENT_BIZ_INQUIRY = "/v1.4.3/accountOpen/appliContent/biz/inquiry";

	/**
	 * 口座開設申込内容照会（個人事業主）
	 */
	public static final String ACCOUNTOPEN_APPLICONTENT_SELFEMP_INQUIRY = "/v1.4.3/accountOpen/appliContent/selfemp/inquiry";

	/**
	 * 口座開設申込内容照会（個人）
	 */
	public static final String ACCOUNTOPEN_APPLICONTENT_RETAIL_INQUIRY = "/v1.4.3/accountOpen/appliContent/retail/inquiry";

	/**
	 * 口座開設申込内容更新（法人）
	 */
	public static final String ACCOUNTOPEN_APPLICONTENT_BIZ_UPDATE = "/v1.4.3/accountOpen/appliContent/biz/update";

	/**
	 * 口座開設申込内容更新（個人事業主）
	 */
	public static final String ACCOUNTOPEN_APPLICONTENT_SELFEMP_UPDATE = "/v1.4.3/accountOpen/appliContent/selfemp/update";

	/**
	 * 口座開設申込内容更新（個人）
	 */
	public static final String ACCOUNTOPEN_APPLICONTENT_RETAIL_UPDATE = "/v1.4.3/accountOpen/appliContent/retail/update";

	/**
	 * 口座開設申込内容登録（法人）
	 */
	public static final String ACCOUNTOPEN_APPLICONTENT_BIZ_REGISTRATION = "/v1.4.3/accountOpen/appliContent/biz/registration";

	/**
	 * 口座開設申込内容登録（個人事業主）
	 */
	public static final String ACCOUNTOPEN_APPLICONTENT_SELFEMP_REGISTRATION = "/v1.4.3/accountOpen/appliContent/selfemp/registration";

	/**
	 * 口座開設申込内容登録（個人）
	 */
	public static final String ACCOUNTOPEN_APPLICONTENT_RETAIL_REGISTRATION = "/v1.4.3/accountOpen/appliContent/retail/registration";

	/**
	 * 口座開設申込完了
	 */
	public static final String ACCOUNTOPEN_APPLICATION_COMPLETION = "/v1.4.3/accountOpen/application/completion";

	/**
	 * 営業地区部店一覧照会
	 */
	public static final String BUSAREA_BRANCH_LIST_INQUIRY = "/v1.4.3/busArea/branch/list/inquiry";

	/**
	 * 郵便番号住所照会
	 */
	public static final String ZIPCODE_ADDRESS_INQUIRY = "/v1.4.3/zipCode/address/inquiry";

	/**
	 * 支店一覧照会
	 */
	public static final String BRANCH_LIST_INQUIRY = "/v1.4.3/branch/list/inquiry";

	/**
	 * 支店詳細照会
	 */
	public static final String BRANCH_DETAIL_INQUIRY = "/v1.4.3/branch/detail/inquiry";

	/**
	 * お知らせ一覧参照
	 */
	public static final String NOTICELIST_INQUIRY = "/v1.4.3/noticeList/inquiry";

	/**
	 * モバイルメッセージ詳細
	 */
	public static final String MOBILEMSG_DETAIL_INQUIRY = "/v1.4.3/mobileMsg/detail/inquiry";

	/**
	 * お知らせ一覧更新
	 */
	public static final String NOTICELIST_UPDATE = "/v1.4.3/noticeList/update";

	/**
	 * 利用者属性照会
	 */
	public static final String USERATTR_INQUIRY = "/v1.4.3/userAttr/inquiry";

	/**
	 * 利用者属性更新
	 */
	public static final String USERATTR_UPDATE = "/v1.4.3/userAttr/update";

	/**
	 * 利用者属性登録
	 */
	public static final String USER_REGISTRATION = "/v1.4.3/user/registration";

	/**
	 * 利用者削除
	 */
	public static final String USER_DELETE = "/v1.4.3/user/delete";

	/**
	 * 利用口座削除
	 */
	public static final String USINGACCOUNT_DELETE = "/v1.4.3/usingAccount/delete";

	/**
	 * メールアドレス登録
	 */
	public static final String MAILADDRESS_REGISTRATION = "/v1.4.3/mailAddress/registration";

	/**
	 * メールアドレス認証
	 */
	public static final String MAILADDRESS_AUTH = "/v1.4.3/mailAddress/auth";

	/**
	 * IVR送信
	 */
	public static final String IVR_SEND = "/v1.4.3/ivr/send";

	/**
	 * IVR認証
	 */
	public static final String IVR_AUTH = "/v1.4.3/ivr/auth";

	/**
	 * 認証キー発行
	 */
	public static final String AUTHKEY_ISSUE = "/v1.4.3/authKey/issue";

	/**
	 * 認証キー検証
	 */
	public static final String AUTHKEY_VERIFY = "/v1.4.3/authKey/verify";

	/**
	 * CIF属性照会
	 */
	public static final String CIFATTR_INQUIRY = "/v1.4.3/cifAttr/inquiry";

	/**
	 * 口座属性照会
	 */
	public static final String ACCOUNTATTR_INQUIRY = "/v1.4.3/accountAttr/inquiry";

	/**
	 * 普通預金残高照会
	 */
	public static final String ORDINARYDEPOSIT_BALANCE = "/v1.4.3/ordinaryDeposit/balance";

	/**
	 * 通知預金残高照会
	 */
	public static final String NOTIFICATIONDEPOSIT_BALANCE_INQUIRY = "/v1.4.3/notificationDeposit/balance/inquiry";

	/**
	 * 定期預金残高照会
	 */
	public static final String TERMDEPOSIT_BALANCE_INQUIRY = "/v1.4.3/termDeposit/balance/inquiry";

	/**
	 * 定期積金残高照会
	 */
	public static final String CUMULATIVEDEPOSITS_BALANCE_INQUIRY = "/v1.4.3/cumulativeDeposits/balance/inquiry";

	/**
	 * 納税準備預金残高照会
	 */
	public static final String TAXRESDEPOSIT_BALANCE_INQUIRY = "/v1.4.3/taxResDeposit/balance/inquiry";

	/**
	 * 当座預金残高照会
	 */
	public static final String CURRENTDEPOSIT_BALANCE_INQUIRY = "/v1.4.3/currentDeposit/balance/inquiry";

	/**
	 * 入出金明細(流動性預金)
	 */
	public static final String DEPOSITWITHDRAWAL_DETAIL_INQUIRY = "/v1.4.3/depositWithdrawal/detail/inquiry";

	/**
	 * 定期預金明細
	 */
	public static final String TERMDEPOSIT_DETAIL_INQUIRY = "/v1.4.3/termDeposit/detail/inquiry";

	/**
	 * 定期積金明細
	 */
	public static final String CUMULATIVEDEPOSITS_DETAIL_INQUIRY = "/v1.4.3/cumulativeDeposits/detail/inquiry";

	/**
	 * 通知預金明細
	 */
	public static final String NOTIFICATIONDEPOSIT_DETAIL_INQUIRY = "/v1.4.3/notificationDeposit/detail/inquiry";

	/**
	 * 概要欄メモ登録
	 */
	public static final String DETAILMEMO_REGISTRATION = "/v1.4.3/detailMemo/registration";

	/**
	 * 収支情報照会
	 */
	public static final String INCOMEPAYINFO_INQUIRY = "/v1.4.3/incomePayInfo/inquiry";

	/**
	 * 収支情報照会
	 */
	public static final String LOTTERYRESULT_INQUIRY = "/v1.4.3/lotteryResult/inquiry";

	/**
	 * CIF預金残高照会
	 */
	public static final String CIFDEPOSIT_BALANCELIST_INQUIRY = "/v1.4.3/cifDeposit/balanceList/inquiry";

	/**
	 * 利用口座登録
	 */
	public static final String USINGACCOUNT_REGISTRATION = "/v1.4.3/usingAccount/registration";

	/**
	 * 通帳レス設定
	 */
	public static final String PASSBOOKLESS_REGISTRATION = "/v1.4.3/passbookless/registration";

	/**
	 * 取引停止
	 */
	public static final String TRX_STOP = "/v1.4.3/trx/stop";

	/**
	 * 解約済口座削除
	 */
	public static final String USINGACCOUNT_ACCOUNT_DELETE = "/v1.4.3/usingAccount/account/delete";

	/**
	 * トランザクションID取得
	 */
	public static final String JAG_AZ0908 = "/jag/az0908";

	/**
	 * ユーザー削除
	 */
	public static final String JAG_AZ0936 = "/jag/az0936";

	/**
	 * ユーザー無効化有効化設定
	 */
	public static final String JAG_AZ0923 = "/jag/az0923";

	/**
	 * TCC確定またはキャンセル
	 */
	public static final String JAG_AZ0905 = "/jag/az0905";

	/**
	 * 端末とJBAIDの紐づけ
	 */
	public static final String JAG_AZ0931 = "/jag/az0931";

	/**
	 * 口座情報認証
	 */
	public static final String ACCOUNTINFO_AUTH = "/v1.4.3/accountInfo/auth";

	/**
	 * 顧客登録
	 */
	public static final String CUSTOMER_REGISTRATION = "/v1.4.3/customer/registration";

	/**
	 * 顧客情報登録
	 */
	public static final String CUSTOMERREGISTINFO_CREATE = "/v1.4.3/customerRegistInfo/create";

	/**
	 * 顧客更新情報
	 */
	public static final String CUSTOMERREGISTINFO_UPDATE = "/v1.4.3/customerRegistInfo/update";

	/**
	 * 顧客属性照会
	 */
	public static final String CUSTOMERATTR_INQUIRY = "/v1.4.3/customerAttr/inquiry";

	/**
	 * 顧客登録情報照会
	 */
	public static final String CUSTOMERREGISTINFO_INQUIRY = "/v1.4.3/customerRegistInfo/inquiry";

	/**
	 * CIF情報照会
	 */
	public static final String CIF_INQUIRY = "/v1.4.3/cif/inquiry";

	/**
	 * IVR認証スキップ情報照会
	 */
	public static final String IVRAUTHSKIP_INFO_INQUIRY = "/v1.4.3/ivrAuthSkip/info/inquiry";

	/**
	 * IVR認証スキップ情報更新
	 */
	public static final String IVRAUTHSKIP_UPDATE = "/v1.4.3/ivrAuthSkip/update";

	/**
	 * カナ氏名照会
	 */
	public static final String KANANAME_INQUIRY = "/v1.4.3/kanaName/inquiry";

	/**
	 * ログイン履歴登録
	 */
	public static final String LOGINHISTORY_REGISTRATION = "/v1.4.3/loginHistory/registration";

    /**
     * ログイン履歴照会
     */
    public static final String LOGINHISTORY_INQUIRY = "/v1.4.3/loginHistory/inquiry";


	/**
	 * CSV_定期預金利息計算（懸賞金付）（自継）
	 */
	public static final String TERMDEPOSIT_WITHPRIZEMONEY_INTERESTCALCULATION_INQUIRY = "/v1.4.3/termDeposit/withPrizeMoney/interestCalculation/inquiry";

	/**
	 * PDF_定期預金利息計算（懸賞金付）（自継）
	 */
	public static final String TERMDEPOSIT_WITHPRIZEMONEY_INTERESTCALCULATION_OUTPUT = "/v1.4.3/termDeposit/withPrizeMoney/interestCalculation/output";

	/**
	 * CSV_定期預金（懸賞金付）期日案内
	 */
	public static final String TERMDEPOSIT_WITHPRIZEMONEY_IMATURITYNOTICE_INQUIRY = "/v1.4.3/termDeposit/withPrizeMoney/maturityNotice/inquiry";

	/**
	 * PDF_定期預金（懸賞金付）期日案内
	 */
	public static final String TERMDEPOSIT_WITHPRIZEMONEY_MATURITYNOTICE_OUTPUT = "/v1.4.3/termDeposit/withPrizeMoney/maturityNotice/output";

	/**
	 * CSV_定期預金期日案内
	 */
	public static final String TERMDEPOSIT_MATURITYNOTICE_INQUIRY = "/v1.4.3/termDeposit/maturityNotice/inquiry";

	/**
	 * PDF_定期預金期日案内
	 */
	public static final String TERMDEPOSIT_MATURITYNOTICE_OUTPUT = "/v1.4.3/termDeposit/maturityNotice/output";

	/**
	 * CSV_定期積金満期案内
	 */
	public static final String CUMULATIVEDEPOSITS_MATURITYNOTICE_INQUIRY = "/v1.4.3/cumulativeDeposits/maturityNotice/inquiry";

	/**
	 * PDF_定期積金満期案内
	 */
	public static final String CUMULATIVEDEPOSITS_MATURITYNOTICE_OUTPUT = "/v1.4.3/cumulativeDeposits/maturityNotice/output";

	/**
	 * CSV_定期預金（自継）利息計算
	 */
	public static final String TERMDEPOSIT_AUTOCONTINUE_INTERESTCALCULATION_INQUIRY = "/v1.4.3/termDeposit/autoContinue/interestCalculation/inquiry";

	/**
	 * PDF_定期預金（自継）利息計算
	 */
	public static final String TERMDEPOSIT_AUTOCONTINUE_INTERESTCALCULATION_OUTPUT = "/v1.4.3/termDeposit/autoContinue/interestCalculation/output";

	/**
	 * CSV_定期預金（自継）大口定期利息計算
	 */
	public static final String LARGETERMDEPOSIT_AUTOCONTINUE_INTERESTCALC_INQUIRY = "/v1.4.3/largeTermDeposit/autoContinue/interestCalc/inquiry";

	/**
	 * PDF_定期預金（自継）大口定期利息計算
	 */
	public static final String LARGETERMDEPOSIT_AUTOCONTINUE_INTERESTCALC_OUTPUT = "/v1.4.3/largeTermDeposit/autoContinue/interestCalc/output";

	/**
	 * CSV_定期預金（自由金利）期日案内
	 */
	public static final String TERMDEPOSIT_FREEINTERESTRATE_MATURITYNOTICE_INQUIRY = "/v1.4.3/termDeposit/freeInterestRate/maturityNotice/inquiry";

	/**
	 * PDF_定期預金（自由金利）期日案内
	 */
	public static final String TERMDEPOSIT_FREEINTERESTRATE_MATURITYNOTICE_OUTPUT = "/v1.4.3/termDeposit/freeInterestRate/maturityNotice/output";

	/**
	 * CSV_借入終了案内
	 */
	public static final String BORROWING_ENDNOTICE_INQUIRY = "/v1.4.3/borrowing/endNotice/inquiry";

	/**
	 * PDF_借入終了案内
	 */
	public static final String BORROWING_ENDNOTICE_OUTPUT = "/v1.4.3/borrowing/endNotice/output";

	/**
	 * CSV_総合口座決算案内
	 */
	public static final String GENERALACCOUNT_FINANCIALRESULTSNOTICE_INQUIRY = "/v1.4.3/generalAccount/financialResultsNotice/inquiry";

	/**
	 * PDF_総合口座決算案内
	 */
	public static final String GENERALACCOUNT_FINANCIALRESULTSNOTICE_OUTPUT = "/v1.4.3/generalAccount/financialResultsNotice/output";

	/**
	 * CSV_融資期日案内
	 */
	public static final String LOAN_MATURITYNOTICE_INQUIRY = "/v1.4.3/loan/maturityNotice/inquiry";

	/**
	 * PDF_融資期日案内
	 */
	public static final String LOAN_MATURITYNOTICE_OUTPUT = "/v1.4.3/loan/maturityNotice/output";

	/**
	 * CSV_自動送金取扱終了案内
	 */
	public static final String AUTOREMITTANCE_HANDLING_ENDNOTICE_INQUIRY = "/v1.4.3/autoRemittance/handling/endNotice/inquiry";

	/**
	 * PDF_自動送金取扱終了案内
	 */
	public static final String AUTOREMITTANCE_HANDLING_ENDNOTICE_OUTPUT = "/v1.4.3/autoRemittance/handling/endNotice/output";

	/**
	 * CSV_財形年金預金受取案内
	 */
	public static final String PROPERTYPENSIONDEPOSIT_RECEIPTNOTICE_INQUIRY = "/v1.4.3/propertyPensionDeposit/receiptNotice/inquiry";

	/**
	 * PDF_財形年金預金受取案内
	 */
	public static final String PROPERTYPENSIONDEPOSIT_RECEIPTNOTICE_OUTPUT = "/v1.4.3/propertyPensionDeposit/receiptNotice/output";

	/**
	 * CSV_証貸変動金利通知
	 */
	public static final String CERTLENDING_VARIABLEINTERESTRATE_NOTICE_INQUIRY = "/v1.4.3/certLending/variableInterestRate/notice/inquiry";

	/**
	 * PDF_証貸変動金利通知
	 */
	public static final String CERTLENDING_VARIABLEINTERESTRATE_NOTICE_OUTPUT = "/v1.4.3/certLending/variableInterestRate/notice/output";

	/**
	 * CSV_借入返済通知
	 */
	public static final String BORROWING_REPAYNOTICE_INQUIRY = "/v1.4.3/borrowing/repayNotice/inquiry";

	/**
	 * PDF_借入返済通知
	 */
	public static final String BORROWING_REPAYNOTICE_OUTPUT = "/v1.4.3/borrowing/repayNotice/output";

	/**
	 * CSV_当座勘定照合表
	 */
	public static final String CURRENTACCOUNT_MATCHINGTAB_INQUIRY = "/v1.4.3/currentAccount/matchingTab/inquiry";

	/**
	 * PDF_当座勘定照合表
	 */
	public static final String CURRENTACCOUNT_MATCHINGTAB_OUTPUT = "/v1.4.3/currentAccount/matchingTab/output";

	/**
	 * CSV_当座勘定照合表兼当座勘定決算通知
	 */
	public static final String CURRENTACCOUNT_MATCHINGTAB_FINRESULTSNOTICE_INQUIRY = "/v1.4.3/currentAccount/matchingTab/finResultsNotice/inquiry";

	/**
	 * PDF_当座勘定照合表兼当座勘定決算通知
	 */
	public static final String CURRENTACCOUNT_MATCHINGTAB_FINRESULTSNOTICE_OUTPUT = "/v1.4.3/currentAccount/matchingTab/finResultsNotice/output";

	/**
	 * CSV_貸金庫使用料期日案内
	 */
	public static final String SAFETYBOX_FEE_MATURITYNOTICE_INQUIRY = "/v1.4.3/safetyBox/fee/maturityNotice/inquiry";

	/**
	 * PDF_貸金庫使用料期日案内
	 */
	public static final String SAFETYBOX_FEE_MATURITYNOTICE_OUTPUT = "/v1.4.3/safetyBox/fee/maturityNotice/output";

	/**
	 * CSV_割引手形計算明細表
	 */
	public static final String DISCBILL_CALCDETAILLIST_INQUIRY = "/v1.4.3/discBill/calcDetailList/inquiry";

	/**
	 * PDF_割引手形計算明細表
	 */
	public static final String DISCBILL_CALCDETAILLIST_OUTPUT = "/v1.4.3/discBill/calcDetailList/output";

	/**
	 * CSV_融資返済明細表
	 */
	public static final String LOANREPAYMENT_DETAILLIST_INQUIRY = "/v1.4.3/loanRepayment/detailList/inquiry";

	/**
	 * PDF_融資返済明細表
	 */
	public static final String LOANREPAYMENT_DETAILLIST_OUTPUT = "/v1.4.3/loanRepayment/detailList/output";

	/**
	 * CSV_財産形成預金残高通知書
	 */
	public static final String PROPERTYFORM_DEPOSITBALANCE_NOTICE_INQUIRY = "/v1.4.3/propertyForm/depositBalance/notice/inquiry";

	/**
	 * PDF_財産形成預金残高通知書
	 */
	public static final String PROPERTYFORM_DEPOSITBALANCE_NOTICE_OUTPUT = "/v1.4.3/propertyForm/depositBalance/notice/output";

	/**
	 * かんたん受付案内詳細照会
	 */
	public static final String EASYRECEPTION_GUIDANCEDETAIL_INQUIRY = "/v1.4.3/easyReception/guidanceDetail/inquiry";

	/**
	 * かんたん受付申込登録
	 */
	public static final String EASYRECEPTION_APPLICATION_REGISTRATION = "/v1.4.3/easyReception/application/registration";

	/**
	 * かんたん受付回答詳細照会
	 */
	public static final String EASYRECEPTION_ANSWERDETAIL_INQUIRY = "/v1.4.3/easyReception/answerDetail/inquiry";

	/**
	 * かんたん受付案内一覧照会
	 */
	public static final String EASYRECEPTION_GUIDANCELIST_INQUIRY = "/v1.4.3/easyReception/guidanceList/inquiry";

	/**
	 * かんたん受付申込詳細照会
	 */
	public static final String EASYRECEPTION_APPLICATIONDETAIL_INQUIRY = "/v1.4.3/easyReception/applicationDetail/inquiry";

	/**
	 * ICカード発行依頼照会
	 */
	public static final String ICCARD_ISSUE_REQUEST_INQUIRY = "/v1.4.3/icCard/issue/request/inquiry";

	/**
	 * CC発行申込内容登録
	 */
	public static final String CASHCARDISSUE_APPLICONTENT_REGISTRATION = "/v1.4.3/cashcardIssue/appliContent/registration";

	/**
	 * CC発行申込内容更新
	 */
	public static final String CASHCARDISSUE_APPLICONTENT_UPDATE = "/v1.4.3/cashcardIssue/appliContent/update";

	/**
	 * CC発行申込内容照会
	 */
	public static final String CASHCARDISSUE_APPLICONTENT_INQUIRY = "/v1.4.3/cashcardIssue/appliContent/inquiry";

	/**
	 * CC発行申込完了
	 */
	public static final String CASHCARDISSUE_APPLICONTENT_COMPLETION = "/v1.4.3/cashcardIssue/application/completion";

	// 2025/01/24 共同化ため バンキングアプリでのチェック項目の確認（注意コード等）対応 satart
	/**
	 * 残高照会（普通預金）（BA API: BA_API004）
	 */
	public static final String BA_ACCOUNTS_ORDINARYDEPOSIT_BALANCE_INQUIRY = "/ba/v1.0.0/accounts/ordinaryDeposit/balance/inquiry";
	// 2025/01/24 共同化ため バンキングアプリでのチェック項目の確認（注意コード等）対応 end

	/**
	 * 残高照会（定期預金）（BA API: BA_API008）
	 */
	public static final String BA_ACCOUNTS_TERMDEPOSIT_BALANCE_INQUIRY = "/ba/v1.0.0/accounts/termDeposit/balance/inquiry";

	/**
	 * 残高照会（定期積金）（BA API: BA_API009）
	 */
	public static final String BA_ACCOUNTS_INSTALLMENTTIMEDEPOSIT_BALANCE_INQUIRY = "/ba/v1.0.0/accounts/installmentTimeDeposit/balance/inquiry";

	/**
	 * 個別フロー CIF照会（モバイル用）（BA API: BA_API001）
	 */
	public static final String BA_CUSTOMERS_CIF_INQUIRY = "/ba/v1.0.0/customers/cif/inquiry";

    /**
     * 1.32.利用登録可否チェック（BA API: BA_API0032）
     */
    public static final String BA_CUSTOMERS_CIF_BANKINGAPPL_REGISTER_CHECK = "/ba/v1.0.0/customers/cif/bankingappl/register/check";

    /**
     * 日付
     */
    public static final String FORMATTER_DEFAULT_DATETIME = "yyyy-MM-dd'T'HH:mm:ss.SSSSSS";

    /**
     * 年月日
     */
    public static final String FORMATTER_DEFAULT_DATE = "yyyy-MM-dd";

    /**
     * 開始日時
     */
    public static final String START_DATE = "T23:59:59.999999";

    /**
     * 終了日時
     */
    public static final String END_DATE = "T00:00:00.000000";
	/**
	 * Timezone指定 (JST).
	 */
    public static final String MBFF_DEF_TIMEZONE_ASIA_TOKYO = "Asia/Tokyo";

	/**
	 * Timezone指定 (JST).
	 */
    public static final String MBFF_DEF_TIMEZONE_UTC = "UTC";

    /**
     * コロンの記号
     */
    public static final String COLON = ":";
    /**
     * 本抽
     */
    public static final String LOTTERY_TYPE_AUTHENTIC = "0";
    /**
     * 感謝賞
     */
    public static final String LOTTERY_TYPE_THANKS = "1";

    /**
     * 個人
     */
    public static final String JBA_RETAIL = "JBA-Retail";

    /**
     * biz
     */
    public static final String JBA_BIZZ = "JBA-Bizz";

	/** CAUSED BY. */
	public static final String STRDEF_CAUSED_BY = "Caused by: ";
	/** AT. */
	public static final String STRDEF_AT = "    at ";

    /**
     * 全角スペース
     */
    public static final String SPACE_FULL = "　";

    /**
     * 半角スペース
     */
    public static final String SPACE_HALF = " ";

    /**
     * 全角／
     */
    public static final String SLASH_FULL = "／";

    /**
     * 半角/
     */
    public static final String SLASH_HALF = "/";

    /**
     * 仮申込ID
     */
    public static final String APPLYID = "9999999999999999";


	 /**
     * BAエラーコードprefix
     */
    public static final String BA_ERROR_CODE_PREFIX_STRING = "BA--";
}

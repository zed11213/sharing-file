package jp.co.jsbank.mobile.bff.common.redis;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLParameters;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;

import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

/**
 * REDIS CONFIG クラス
 */
@Configuration
public class JedisPoolUtil {

    private Logger logger = LoggerFactory.getLogger(JedisPoolUtil.class);

    /**
     * REDIS Public Endpoint
     */
    @Value("${bff.redis.uri}")
    private String redisEndpoint;

    /**
     * REDIS TLS Certification File Path
     */
    @Value("${bff.redis.filePath}")
    private String redisTLSCertificationFilePath;

    /**
     * Redisインスタンス.
     */
    private JedisPool jedisPool = null;

    /**
     * SSL SOCKER FACTORY KEY
     */
    private static final String SSL_SOCKER_FACTORY_JCEKS = "jceks";

    /**
     * SSL SOCKER FACTORY KEY
     */
    private static final String SSL_SOCKER_FACTORY_CHANGEIT = "changeit";

    /**
     * SSL SOCKER FACTORY KEY
     */
    private static final String SSL_SOCKER_FACTORY_X = "X.509";

    /**
     * SSL SOCKER FACTORY KEY
     */
    private static final String SSL_SOCKER_FACTORY_PKIX = "PKIX";

    /**
     * SSL SOCKER FACTORY KEY
     */
    private static final String SSL_SOCKER_FACTORY_TLS = "TLSv1.2";

    /**
     * SSL SOCKER FACTORY KEY
     */
    private static final String SSL_SOCKER_FACTORY_CERT = "1";

    /**
     * REDIS接続を実施する.
     *
     * @return REDIS
     * @throws URISyntaxException URIException
     */
    @Bean
    public JedisPool connect() throws URISyntaxException {

        // Redis EndPointのURIを生成する.
        URI uri = null;
        try {
            uri = new URI(redisEndpoint);
        } catch (URISyntaxException e) {
            logger.error("RedisEndPointのURI生成時にエラーが発生しました...");
            e.printStackTrace();
        }

        // SSLSocketFactoryの生成.
        SSLSocketFactory sslSocketFactory = null;
        try {
            sslSocketFactory = createTrustStoreSslSocketFactory();
        } catch (KeyManagementException | KeyStoreException | NoSuchAlgorithmException | CertificateException
                | IOException e) {
            logger.error("SSLSocketFactory生成時にエラーが発生しました...");
            e.printStackTrace();
        }

        final SSLParameters sslParameters = new SSLParameters();
        HostnameVerifier hostnameVerifier = new HostnameVerifier() {
            @Override
            public boolean verify(String hostname, SSLSession session) {
                // 以下, はらぐちさんのコメント.
                return true;
            }
        };

        GenericObjectPoolConfig<Jedis> jedisPoolConfig = new GenericObjectPoolConfig<Jedis>();
        jedisPoolConfig.setTestWhileIdle(true);
        // jedisPoolConfig.setMinEvictableIdleTimeMillis(60000);
        // jedisPoolConfig.setTimeBetweenEvictionRunsMillis(30000);
        jedisPoolConfig.setNumTestsPerEvictionRun(-1);
        jedisPool = new JedisPool(jedisPoolConfig, uri, sslSocketFactory, sslParameters, hostnameVerifier);

        // 返却する.
        return jedisPool;
    }

    /**
     * SSLSockerFactoryの生成.
     *
     * @return SSLSocketFactory
     */
    private SSLSocketFactory createTrustStoreSslSocketFactory() throws KeyStoreException, IOException,
            NoSuchAlgorithmException, CertificateException, KeyManagementException {
        // KeyStoreの取得.
        KeyStore trustStore = KeyStore.getInstance(SSL_SOCKER_FACTORY_JCEKS);
        InputStream inputStream = new ClassPathResource(redisTLSCertificationFilePath).getInputStream();

        trustStore.load(null, SSL_SOCKER_FACTORY_CHANGEIT.toCharArray());

        CertificateFactory cerFactory = CertificateFactory.getInstance(SSL_SOCKER_FACTORY_X);
        Certificate cert = cerFactory.generateCertificates(inputStream).iterator().next();
        trustStore.setCertificateEntry(SSL_SOCKER_FACTORY_CERT, cert);
        inputStream.close();

        TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance(SSL_SOCKER_FACTORY_PKIX);
        trustManagerFactory.init(trustStore);
        TrustManager[] trustManagers = trustManagerFactory.getTrustManagers();

        SSLContext sslContext = SSLContext.getInstance(SSL_SOCKER_FACTORY_TLS);
        sslContext.init(null, trustManagers, new SecureRandom());
        return sslContext.getSocketFactory();
    }
}

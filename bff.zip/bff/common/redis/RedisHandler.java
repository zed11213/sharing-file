package jp.co.jsbank.mobile.bff.common.redis;

import java.util.Arrays;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import jp.co.jsbank.mobile.bff.common.ErrorCodeConstant;
import jp.co.jsbank.mobile.bff.common.exception.InternalServerErrorException;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

/**
 * Redis処理クラス
 */
@Component
public class RedisHandler {

    @Autowired
    private JedisPool jedisPool;
    /** CAUSED BY. */
    public static final String STRDEF_CAUSED_BY = "Caused by: ";
    /** AT. */
    public static final String STRDEF_AT = "    at ";
    private Jedis jedis;
    /** REDIS Max retry connection. */

    private int gRedisMaxRetryConnection = 2;

    /** REDIS コネクション取得リトライ時のデフォルトSLEEP時間[msec]. */
    private long REDIS_GET_CONNECTION_DEFAULT_SLEEP = 500;

    /** REDIS コネクション取得リトライ時のSLEEP時間[msec]. */
    private long gRedisRetryWailMillis = REDIS_GET_CONNECTION_DEFAULT_SLEEP;
    private Logger logger = LoggerFactory.getLogger(RedisHandler.class);
    /** SET時の最大Retry回数. */
    private int gRedisMaxSetRetryCount = 3;

	/** REDIS: expire時間の設定. [秒].
	 * 60分: 3600秒. */
	private long autoExpireSeconds = 3600;

    /**
     * キーが存在するかどうかを判断する
     *
     * @param key redisキー
     * @return boolean
     */
	public boolean exists(String key) {
		boolean exists = false;

		try {
			jedis = getRedisResourceFromPool();
			exists = jedis.exists(key);
		} catch (Exception e) {
			logger.debug(key + " existsメソッドにRedisエラーが発生しました。" + e.getMessage());
			for (StackTraceElement elm : e.getStackTrace())
				logger.debug(STRDEF_AT + elm.toString());
			Optional.ofNullable(e.getCause()).ifPresent(cause -> {
				logger.debug(STRDEF_CAUSED_BY + cause.toString());
				Arrays.asList(cause.getStackTrace()).stream().forEach(ste -> logger.debug(STRDEF_AT + ste.toString()));
			});
			throw new InternalServerErrorException(ErrorCodeConstant.ERROR_CODE_MBAP0010, "");
		} finally {
			try {
				jedisPool.returnResource(jedis);
			} catch (Exception ex) {
			}
		}

		return exists;
	}

    /**
     * キー対応レコードの削除
     *
     * @param keys redisキー
     * @return レコード数
     */
	public long del(String... keys) {
		long count = 0;
		for (int i = 0; i < gRedisMaxSetRetryCount; i++) {
			try {
				jedis = getRedisResourceFromPool();
				count = jedis.del(keys);
			} catch (Exception e) {
				logger.debug(keys + " delメソッドにRedisエラーが発生しました。" + e.getMessage());
				for (StackTraceElement elm : e.getStackTrace())
					logger.debug(STRDEF_AT + elm.toString());
				Optional.ofNullable(e.getCause()).ifPresent(cause -> {
					logger.debug(STRDEF_CAUSED_BY + cause.toString());
					Arrays.asList(cause.getStackTrace()).stream()
							.forEach(ste -> logger.debug(STRDEF_AT + ste.toString()));
				});
				continue;
			} finally {
				try {
					jedisPool.returnResource(jedis);
				} catch (Exception ex) {
				}
			}

			return count;
		}
		throw new InternalServerErrorException(ErrorCodeConstant.ERROR_CODE_MBAP0010, "");
	}

    /**
     * 指定keyのデータの取得
     *
     * @param key redisキー
     * @return redis値
     */
    public String get(String key) {
        String value = null;
        try {

            jedis = getRedisResourceFromPool();
            value = jedis.get(key);
        } catch (Exception e) {
            logger.debug(key + " getメソッドにRedisエラーが発生しました。" + e.getMessage());
            for (StackTraceElement elm : e.getStackTrace())
                logger.debug(STRDEF_AT + elm.toString());
            Optional.ofNullable(e.getCause()).ifPresent(cause -> {
                logger.debug(STRDEF_CAUSED_BY + cause.toString());
                Arrays.asList(cause.getStackTrace()).stream().forEach(ste -> logger.debug(STRDEF_AT + ste.toString()));
            });
            throw new InternalServerErrorException(ErrorCodeConstant.ERROR_CODE_MBAP0010, "");
		} finally {
			try {
				jedisPool.returnResource(jedis);
			} catch (Exception ex) {
			}
		}
        return value;
    }

    /**
     * REDISのプールからコネクションを取得する.
     *
     * @return
     * @throws Exception
     */
    private Jedis getRedisResourceFromPool() throws Exception {
        Jedis gJedis = null;
        try {
            // コネクション取得.
            for (int i = 0; i < gRedisMaxRetryConnection; i++) {
                // Jedisインスタンスを確保する.
                gJedis = jedisPool.getResource();

                // 取得できなかった場合.
                if (gJedis == null)
                    continue;

                // 不正なインスタンスを取得した場合. この場合は返却する.
                if (gJedis.isBroken()) {
                    jedisPool.returnBrokenResource(gJedis);
                    gJedis = null;
                    continue;
                }
                // 正常なインスタンスを取得した場合は breakして処理を進める.
                if (gJedis.isConnected())
                    break;

                // Retry時の所定時間SLEEP.
                try {
                    Thread.sleep(gRedisRetryWailMillis);
                } catch (InterruptedException e) {
                }
            }

            // 正常なインスタンスかどうかを検査する.
            if (gJedis == null || !gJedis.isConnected() || gJedis.isBroken()) {
                // 異常なJedisインスタンスを確保した場合はthrowする.
                throw new InternalServerErrorException(ErrorCodeConstant.ERROR_CODE_MBAP0010, "");
            }
        } catch (Exception e) {
            throw new InternalServerErrorException(ErrorCodeConstant.ERROR_CODE_MBAP0010, "");
        }
        return gJedis;
    }

    /**
     * レコードの追加
     *
     * @param key redisキー
     * @param value redis値
     * @return redis設定値
     */
	public String set(String key, String value) {
		String state = null;
		for (int i = 0; i < gRedisMaxSetRetryCount; i++) {
			try {

				// コネクションを取得する.
				jedis = getRedisResourceFromPool();
				// キーと値を設定する.
				state = jedis.set(key, value);

				// 有効期限の設定をする.
				jedis.expire(key, autoExpireSeconds);

			} catch (Exception e) {
				logger.debug(key + ":" + value + " setメソッドにRedisエラーが発生しました。" + e.getMessage());
				for (StackTraceElement elm : e.getStackTrace())
					logger.debug(STRDEF_AT + elm.toString());
				Optional.ofNullable(e.getCause()).ifPresent(cause -> {
					logger.debug(STRDEF_CAUSED_BY + cause.toString());
					Arrays.asList(cause.getStackTrace()).stream()
							.forEach(ste -> logger.debug(STRDEF_AT + ste.toString()));
				});
				continue;
			} finally {
				try {
					jedisPool.returnResource(jedis);
				} catch (Exception ex) {
				}
			}
			return state;
		}
		throw new InternalServerErrorException(ErrorCodeConstant.ERROR_CODE_MBAP0010, "");
	}
}

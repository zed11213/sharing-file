package jp.co.jsbank.mobile.bff.common.icos;

import java.io.FileNotFoundException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.ibm.cloud.objectstorage.ClientConfiguration;
import com.ibm.cloud.objectstorage.SDKGlobalConfiguration;
import com.ibm.cloud.objectstorage.auth.AWSCredentials;
import com.ibm.cloud.objectstorage.auth.AWSStaticCredentialsProvider;
import com.ibm.cloud.objectstorage.auth.BasicAWSCredentials;
import com.ibm.cloud.objectstorage.client.builder.AwsClientBuilder.EndpointConfiguration;
import com.ibm.cloud.objectstorage.services.s3.AmazonS3;
import com.ibm.cloud.objectstorage.services.s3.AmazonS3ClientBuilder;

/**
 * ICOS CONFIG クラス
 */
@Configuration
public class IcosConfigurationUtil {

	/**
	 * APIKEY.JAG-POC-BUCKET用のものを設定.
	 */
	@Value("${icos_api_key}")
	private String icosApiKey;
	/**
	 * アクセスキー
	 */
	@Value("${icos_access_key}")
	private String icosAccessKey;
	/**
	 * シークレットキー
	 */
	@Value("${icos_secret_key}")
	private String icosSecretKey;
	/**
	 * エンドポイント
	 */
	@Value("${icos_public_endpoint}")
	private String icosPublicEndpoint;
	/**
	 * icos_iam_endpoint
	 */
	@Value("${icos_iam_endpoint}")
	private String icosIamEndpoint;
	/**
	 * Service Instance Id
	 */
	@Value("${icos_serviceinstance_id}")
	private String icosServiceinstanceId;
	/**
	 * ロケーション
	 */
	@Value("${icos_location}")
	private String icosLocation;

	/**
	 * ICOS接続を実施する.
	 *
	 * @return ICOS
	 */
	@Bean
	public AmazonS3 connectIcos() throws FileNotFoundException {

		SDKGlobalConfiguration.IAM_ENDPOINT = icosIamEndpoint;

		// COS Clientのインスタンスを生成する.
		AmazonS3 cosClient = createClient(icosApiKey, icosServiceinstanceId, icosPublicEndpoint, icosLocation);

		return cosClient;
	}

	/**
	 * Create OAuth Credentials.
	 *
	 * @param apiKey            APIKEY
	 * @param serviceInstanceId サービスインスタンスID
	 * @param endpointUrl       エンドポイント
	 * @param location          ロケーション
	 * @return ICOSクライアント
	 */
	public AmazonS3 createClient(String apiKey, String serviceInstanceId, String endpointUrl, String location) {

		AWSCredentials credentials;

		// 認証情報
		credentials = new BasicAWSCredentials(icosAccessKey, icosSecretKey);

		ClientConfiguration clientConfig = new ClientConfiguration().withRequestTimeout(5000);
		clientConfig.setUseTcpKeepAlive(true);

		AmazonS3 cosClient = AmazonS3ClientBuilder.standard()
				.withCredentials(new AWSStaticCredentialsProvider(credentials))
				.withEndpointConfiguration(new EndpointConfiguration(endpointUrl, location))
				.withPathStyleAccessEnabled(true).withClientConfiguration(clientConfig).build();

		return cosClient;
	}
}

package jp.co.jsbank.mobile.bff.common.code;

/**
 * トーケン発行済フラグコード
 */
public class TokenFlgCode {
	/**
	 * 済
	 */
	public static final String ZUMI = "1";

	/**
	 * 未
	 */
	public static final String MI = "0";
}

package jp.co.jsbank.mobile.bff.common.code;

/**
 * 非会員受付有無コード
 */
public class NoMemberReceptionOptsCode {

    /**
     * 有
     */
    public static final String EXISTS = "NMR01";
    
    /**
     * 無
     */
    public static final String NO_EXISTS = "NMR02";
}

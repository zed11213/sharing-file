package jp.co.jsbank.mobile.bff.common.code;

/**
 * 申込ステータス
 */
public class AnswerSexTypeCode {

    /**
     * 申込開始
     */
    public static final String ANSWER = "1";

    /**
     * 申込完了
     */
    public static final String NO_ANSWER = "2";

    /**
     * その他(法人等)
     */
    public static final String OTHERS = "0";

    /**
     * 男
     */
    public static final String MAN = "1";

    /**
     * 女
     */
    public static final String WOMAN = "2";

    /**
     * 回答しない
     */
    public static final String DO_NOT_ANSWER = "3";

}

package jp.co.jsbank.mobile.bff.common.code;

/**
 * 非会員受付有無コード
 */
public class NonMemberAplyFlgCode {

    /**
     * 有
     */
    public static final String SAVING_ACCOUNTS = "1";

    /**
     * 無
     */
    public static final String CURRENT_ACCOUNT = "0";

    /**
     * 利用者全員（全員受付可）
     */
    public static final String ALL = "2";

    /**
     * 利用者全員（会員のみ受付可）
     */
    public static final String MEMBER = "3";

}

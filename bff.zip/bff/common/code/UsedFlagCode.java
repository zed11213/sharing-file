package jp.co.jsbank.mobile.bff.common.code;

/**
 * 使用済みフラグコード
 */
public class UsedFlagCode {

    /**
     * 未使用
     */
    public static final String UNUSED = "0";
    
    /**
     * 使用済み
     */
    public static final String USED = "1";
}

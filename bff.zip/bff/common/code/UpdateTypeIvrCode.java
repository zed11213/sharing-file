package jp.co.jsbank.mobile.bff.common.code;

/**
 * 更新パターン（IVR）コード
 */
public class UpdateTypeIvrCode {

    /**
     * 口座開設（個人）
     */
    public static final String ACCOUNT_OPENING_INDIVIDUAL = "111";

    /**
     * 口座開設（法人）
     */
    public static final String ACCOUNT_OPENING_CORPORATE = "112";

    /**
     * 口座開設（個人事業主）
     */
    public static final String ACCOUNT_OPENING_SOLE_PROPRIETORSHIP = "113";

    /**
     * CC発行
     */
    public static final String CC_ISSUANCE = "114";

    /**
     * 初回登録
     */
    public static final String SIGN_UP = "115";

}

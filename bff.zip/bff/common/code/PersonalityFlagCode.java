package jp.co.jsbank.mobile.bff.common.code;

/**
 * 人格コード
 */
public class PersonalityFlagCode {

    /**
     * 個人
     */
    public static final String INDIVIDUAL = "8";
    
    /**
     * 法人
     */
    public static final String CORPORATE = "1";

    /**
     * 個人事業者
     */
    public static final String ONE_PERSON_OPERATION_PERSON = "2";

    /**
     * 金融
     */
    public static final String FINANCE = "4";

    /**
     * 公共
     */
    public static final String OPEN = "5";

    /**
     * 役職員
     */
    public static final String JOB_TITLE_WORKER = "6";

    /**
     * 団体
     */
    public static final String ORGANIZATION = "7";

    /**
     * サラリーマン・その他
     */
    public static final String OFFICE_WORKER_OTHER = "8";
}

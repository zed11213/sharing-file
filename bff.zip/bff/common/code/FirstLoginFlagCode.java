package jp.co.jsbank.mobile.bff.common.code;

/**
 * 初回登録フラグ
 */
public class FirstLoginFlagCode {

    /**
     * それ以外
     */
    public static final String OTHER_WISE = "0";

    /**
     * 初回登録CIF
     */
    public static final String FIRST_LOGIN_CIF = "1";  

}

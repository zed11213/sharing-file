package jp.co.jsbank.mobile.bff.common.code;

/**
 * 設定値
 */
public class SettingContentCode {
    /**
     * 有効
     */
    public static final String VALID = "0";
    
    /**
     * 無効
     */
    public static final String DISABILITY = "1";
}

package jp.co.jsbank.mobile.bff.common.code;

/**
 * 取引種別コード
 */
public class TransactionTypeCode {

	/**
	 * 口座開設
	 */
	public static final String ACCOUNT_OPENING = "01";

	/**
	 * キャッシュカード発行
	 */
	public static final String CASH_CARD_ISSUANCE = "02";

	/**
	 * IVRスキップ
	 */
	public static final String IVR_SKIP = "03";

	/**
	 * 初回登録
	 */
	public static final String FIRST_REGISTRATION = "04";

	/**
	 * 各種登録設定
	 */
	public static final String VARIOUS_REGISTRATION_PREFERENCE = "05";

}

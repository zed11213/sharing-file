package jp.co.jsbank.mobile.bff.common.code;

/**
 * 更新パターン（法人）コード
 */
public class UpdateTypeBizCode {

    /**
     * 本店所在地
     */
    public static final String HEAD_OFFICE_ADDRESS = "011";

    /**
     * 開設店番
     */
    public static final String OPENING_STORE_NUMBER = "012";

    /**
     * 代表者確認書類
     */
    public static final String REPRESENTATIVE_CONFIRMATION_DOCUMENT = "013";

    /**
     * お客様情報１
     */
    public static final String GUEST_INFO_1 = "014";

    /**
     * 役員・支配者
     */
    public static final String EXECUTIVE_DOMINATOR = "015";

    /**
     * お客様情報２
     */
    public static final String GUEST_INFO_2 = "016";
    
    /**
     * お客様情報３
     */
    public static final String GUEST_INFO_3 = "018";

    /**
     * 事業先確認書類
     */
    public static final String BUSINESS_TARGET_CONFIRMATION_DOCUMENT = "017";
}

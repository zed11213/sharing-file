package jp.co.jsbank.mobile.bff.common.code;

/**
 * 利用状況コード
 */
public class UtilizationStatusCode {

    /**
     * 未利用
     */
    public static final String UNUSED = "0";

    /**
     * 利用中
     */
    public static final String USING = "1";
}

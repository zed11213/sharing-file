package jp.co.jsbank.mobile.bff.common.code;

/**
 * ログイン済フラグコード
 */
public class LoginFlgCode {
	/**
	 * ログイン済
	 */
	public static final String ZUMI = "1";

	/**
	 * 未ログイン
	 */
	public static final String MI = "0";
}

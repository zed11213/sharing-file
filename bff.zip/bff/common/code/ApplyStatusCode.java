package jp.co.jsbank.mobile.bff.common.code;

/**
 * 申込ステータス
 */
public class ApplyStatusCode {

    /**
     * 申込開始
     */
    public static final String APPLICATION_START = "01";

    /**
     * 申込完了
     */
    public static final String APPLICATION_COMPLETION = "02";

    /**
     * 申込中止
     */
    public static final String APPLICATION_SUSPENSION = "03";

    /**
     * プロセス登録済
     */
    public static final String PROCESS_REGISTRATION = "04";

    /**
     * 完了通知受付
     */
    public static final String COMPLETION_NOTICE_RECEPTION = "5";

    /**
     * 完了通知済
     */
    public static final String COMPLETION_NOTICE = "6";
}

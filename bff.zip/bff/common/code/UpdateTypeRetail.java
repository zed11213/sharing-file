package jp.co.jsbank.mobile.bff.common.code;

/**
 * 更新パターン（個人）コード
 * */
public class UpdateTypeRetail {
    /**
     * お客様情報１
     * */
    public static final String GUEST_INFO_1 = "001";
    
    /**
     * お客様情報２
     * */
    public static final String GUEST_INFO_2 = "002";
    
    /**
     * お勤め先
     * */
     public static final String WORK_NUMBER = "003";
    
    /**
     * 開設店番
     * */
    public static final String OPENING_STORE_NUMBER = "004";
    
    /**
     * CC暗証番号
     * */
    public static final String CC_PASSWORD = "005";
     
    /**
     * IB暗証番号
     * */
    public static final String IB_PASSWORD = "006";
    
    /**
     * カード種類
     * */
    public static final String CARD_TYPE = "007";
}

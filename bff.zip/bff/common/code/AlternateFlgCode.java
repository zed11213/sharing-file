package jp.co.jsbank.mobile.bff.common.code;

/**
 * 候补FLGコード
 */
public class AlternateFlgCode {

    /**
     * 営業地区部店0件以外
     */
    public static final String NON_SALES_AREA_BUTEN_EMPTY = "1";

    /**
     * 都道府県漢字存在
     */
    public static final String REFECTURES_KANJI_EXISTENCE = "2";

    /**
     * 都道府県漢字存在以外
     */
    public static final String NON_PREFECTURES_KANJI_EXISTENCE = "3";
    
    /**
     * 対象外
     */
    public static final String NON_EXISTENCE = "4";

}

package jp.co.jsbank.mobile.bff.common.code;

/**
 * 科目コード
 */
public class AccountTypeCode {

    /**
     * 普通預金
     */
    public static final String SAVING_ACCOUNTS = "001";

    /**
     * 当座預金
     */
    public static final String CURRENT_ACCOUNT = "002";
    
    /**
     * 通知預金
     */
    public static final String NOTIFICATION_DEPOSIT = "003";    
    
    /**
     * 貯蓄預金
     */
    public static final String SAVINGS_DEPOSIT = "004";
    
    /**
     * 納税預金
     */
    public static final String TAX_PAYMENT_DEPOSIT = "005";
    
    /**
     * 定期預金
     */
    public static final String FIXED_TERM_DEPOSIT = "006";
    
    /**
     * 積立定期
     */
    public static final String PERIODICAL_ACCUMULATION = "007";
    
    /**
     * 定期積金
     */
    public static final String FIXED_TERM_FIXED = "008";

    /**
     * その他
     */
    public static final String OTHER = "009";

    /**
     * カードローン
     */
    public static final String CARD_LOANS = "020";
    
    /**
     * 住宅ローン
     */
    public static final String HOUSING_LOANS = "030";

    /**
     * 総合普通
     */
    public static final String OVERALL_ORDINARY = "051";
    
    /**
     * 投資信託
     */
    public static final String INVESTMENT_TRUST = "054";
    
    /**
     * 証券保護預り
     */
    public static final String SECURITIES_PROTECTION_DEPOSIT = "055";
    
    /**
     * 一般財形
     */
    public static final String GENERAL_ASSETS = "070";
    
    /**
     * 財形年金
     */
    public static final String ASSET_FORMATION_PENSION = "071";
    
    /**
     * 住宅財形
     */
    public static final String HOUSING_PROPERTIES = "072";
    
    /**
     * 外貨普通預金
     */
    public static final String FOREIGN_CURRENCY_SAVING_ACCOUNTS = "101";

    /**
     * 外貨当座預金
     */
    public static final String FOREIGN_CURRENCY_CURRENT_ACCOUNTS = "102";
   
    /**
     * 外貨貯蓄預金
     */
    public static final String FOREIGN_CURRENCY_SAVINGS_DEPOSITS = "104";
    
    /**
     * 外貨定期預金
     */
    public static final String FOREIGN_CURRENCY_TIME_DEPOSITS = "106";
    
    /**
     * 外貨積立定期預金
     */
    public static final String FOREIGN_CURRENCY_SAVINGS_TIME_DEPOSITS = "107";    

}

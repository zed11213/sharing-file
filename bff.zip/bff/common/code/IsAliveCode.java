package jp.co.jsbank.mobile.bff.common.code;

/**
 * 解約済表示
 */
public class IsAliveCode {

    /**
     * 活口座
     */
    public static final String ISALIVE = "0";

    /**
     * 解約済
     */
    public static final String ISNOTALIVE = "1";

}

package jp.co.jsbank.mobile.bff.common.code;

/**
 * 更新パターン（個人事業主）
 */
public class UpdateTypeSelfempCode {

    /**
     * 所在地
     */
    public static final String ADDRESS = "021";

    /**
     * 開設店番
     */
    public static final String OPENING_STORE_NUMBER = "022";

    /**
     * 確認書類
     */
    public static final String CONFIRMATION_PAPER = "023";

    /**
     * お客様情報１
     */
    public static final String GUEST_INFO_1 = "024";

    /**
     * お客様情報２
     */
    public static final String GUEST_INFO_2 = "025";
    
    /**
     * お客様情報3
     */
    public static final String GUEST_INFO_3 = "026";
}

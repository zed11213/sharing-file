package jp.co.jsbank.mobile.bff.common.code;

/**
 * IVRスキップフラグコード
 */
public class IvrSkipFlgCode {

	/**
	 * 無効
	 */
	public static final String DISABLED = "0";

	/**
	 * 有効
	 */
	public static final String ENABLED = "1";
}

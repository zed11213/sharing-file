package jp.co.jsbank.mobile.bff.common.code;

/**
 * 既読フラグコード
 */
public class ReadFlgCode {
	/**
	 * 未読
	 */
	public static final String UNREADED = "0";

	/**
	 * 既読
	 */
	public static final String READED = "1";
}

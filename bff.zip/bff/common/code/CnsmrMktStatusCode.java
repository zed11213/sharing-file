package jp.co.jsbank.mobile.bff.common.code;

/**
 * 契約者のステータスコード
 */
public class CnsmrMktStatusCode {

    /**
     * 正常
     */
    public static final String NORMAL = "0";

    /**
     * 利用停止
     */
    public static final String SUSPEND = "1";

    /**
     * 取引停止
     */
    public static final String TRADING_STOP = "2";

}

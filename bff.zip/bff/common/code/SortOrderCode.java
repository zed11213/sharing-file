package jp.co.jsbank.mobile.bff.common.code;

/**
 * ソート順
 */
public class SortOrderCode {
	/**
	 * 受信日新しい順
	 */
	public static final String DESC = "0";

	/**
	 * 受信日古い順
	 */
	public static final String ASC = "1";
}

package jp.co.jsbank.mobile.bff.common.code;

/**
 * お気に入りフラグコード
 */
public class BookmarkFlgCode {
	/**
	 * お気に入りではない
	 */
	public static final String UNSTART = "0";

	/**
	 * お気に入り読
	 */
	public static final String START = "1";
}

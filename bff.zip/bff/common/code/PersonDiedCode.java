package jp.co.jsbank.mobile.bff.common.code;

/**
 * 本人死亡コード
 */
public class PersonDiedCode {
	/**
	 * 死亡
	 */
	public static final String DEATH = "1";

	/**
	 * 以外
	 */
	public static final String EXCEPT = "0";
}

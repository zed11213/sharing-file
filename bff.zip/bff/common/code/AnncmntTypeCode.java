package jp.co.jsbank.mobile.bff.common.code;

/**
 * お知らせ種別
 */
public class AnncmntTypeCode {

	/**
	 * メッセージ
	 */
	public static final String ANNCMNTTYPE_01 = "01";

	/**
	 * かんたん受付
	 */
	public static final String ANNCMNTTYPE_02 = "02";

	/**
	 * 電子交付
	 */
	public static final String ANNCMNTTYPE_03 = "03";

}

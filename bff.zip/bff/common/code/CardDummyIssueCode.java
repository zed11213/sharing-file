package jp.co.jsbank.mobile.bff.common.code;

/**
 * 本人カード仮発行
 */
public class CardDummyIssueCode {

	/**
	 * 本人カードは実際は未発行の注意コード有り:1
	 */
	public static final String YES = "1";

	/**
	 * 無し:0
	 */
	public static final String NO = "0";


}

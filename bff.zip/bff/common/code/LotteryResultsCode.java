package jp.co.jsbank.mobile.bff.common.code;

/**
 * 当選結果
 */
public class LotteryResultsCode {

	/**
	 * ドリーム大賞当せん
	 */
	public static final String BEST = "93";

	/**
	 * 1等賞当せん
	 */
	public static final String FIRST = "01";

	/**
	 * 2等賞当せん
	 */
	public static final String TWO = "02";

	/**
	 * 3等賞当せん
	 */
	public static final String THREE = "03";

	/**
	 * 被災地復興応援グルメ賞当せん
	 */
	public static final String FOUR = "22";

	/**
	 * 4等賞当せん
	 */
	public static final String LevelFOUR = "04";
	public static final String LevelFOURicon = "40";

	/**
	 * コシヒカリ賞当せん
	 */
	public static final String SIX = "33";

	/**
	 * 城南特選グルメ賞/被災地復興応援グルメ賞当せん
	 */
	public static final String FIVE = "44";

	/**
	 * ３０周年感謝賞当せん
	 */
	public static final String THANKS_30TH = "11";

	/**
	 * 創立８０周年記念特別賞当せん
	 */
	public static final String ANNIVERSARY_80TH = "04";

	/**
	 * 抽選結果待ち
	 */
	public static final String WAIT = "A1";

	/**
	 * 感謝賞結果待ち
	 */
	public static final String WAIT_THANKS = "A2";

	/**
	 * 感謝賞当せん
	 */
	public static final String WIN_THANKS = "A3";

	/**
	 * 感謝賞落せん
	 */
	public static final String THANKS_DROP = "A4";

	/**
	 * 落せん
	 */
	public static final String DROP = "A5";
}

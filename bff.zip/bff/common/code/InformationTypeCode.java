package jp.co.jsbank.mobile.bff.common.code;

/**
 * お知らせ種別コード
 */
public class InformationTypeCode {

    /**
     * 電子交付
     */
    public static final String ELECTRONIC_ISSUE = "03";
}

package jp.co.jsbank.mobile.bff.common.code;

/**
 * 通帳レス設定状態
 */
public class PassbookLessStatusCode {

    /**
     * 未設定
     */
    public static final String NOT_SET = "0";

    /**
     * 設定済
     */
    public static final String SET = "1";

    /**
     * 設定2
     */
    public static final String SET_2 = "2";
    /**
     * 設定3
     */
    public static final String SET_3 = "3";
    /**
     * 設定4
     */
    public static final String SET_4 = "4";
    /**
     * 設定5
     */
    public static final String SET_5 = "5";
}

package jp.co.jsbank.mobile.bff.common.code;

/**
 * 公開中フラグコード
 */
public class ReleasedFlgCode {
    /**
     * 公開中
     * */
    public static final String RELEASED = "1";
    
    /**
     * 未公開
     * */
    public static final String UNRELEASE = "0";
}

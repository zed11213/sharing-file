package jp.co.jsbank.mobile.bff.common.code;

/**
 * 既読フラグコード
 */
public class ImageFlgCode {
	/**
	 * 無
	 */
	public static final String NASHI = "0";

	/**
	 * 有
	 */
	public static final String ARI = "1";
}

package jp.co.jsbank.mobile.bff.common.code;

/**
 * アプリ会員/非会員コード
 */
public class AppNonMemberOptsCode {

    /**
     * TODO アプリ会員
     */
    public static final String APP_MEMBER = "AN01";
    
    /**
     * TODO アプリ非会員
     */
    public static final String APP_NO_MEMBER = "AN02";
    
}

package jp.co.jsbank.mobile.bff.common.code;

/**
 * 照会開始位置コード
 */
public class IndexCode {

    /**
     * TODO 上部
     */
    public static final String UPSIDE = "1";
    
    /**
     * TODO 下部
     */
    public static final String BOTTOM = "2";
}

package jp.co.jsbank.mobile.bff.common.code;

/**
 * メッセージ内容種別コード
 */
public class MobilelMsgTypeCode {

    /**
     * 通常
     */
    public static final String GENERALLY = "01";

    /**
     * 重要
     */
    public static final String IMPORTANT = "02";

    /**
     * 個別確認(重要扱い)
     */
    public static final String INDIVIDUAL_CONFIRMATION = "03";
}

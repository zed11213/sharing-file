package jp.co.jsbank.mobile.bff.common.code;

/**
 * 口座開設可否コード
 */
public class AccountOpeningJudgementCode {

    /**
     * 開設可
     */
    public static final String OPENING_ALLOWED = "00";

    /**
     * 開設不可 - 一括支払口座
     */
    public static final String OPENING_NOT_POSSIBLE_BULK_PAYMENT_ACCOUNT = "01";

    /**
     * 開設不可 - 本人死亡
     */
    public static final String OPENING_NOT_POSSIBLE_PERSON_DIED = "02";

    /**
     * 開設不可 - 代理人死亡
     */
    public static final String OPENING_NOT_POSSIBLE_AGENT_DIED = "03";

    /**
     * 開設不可 - 取引停止
     */
    public static final String OPENING_NOT_POSSIBLE_TRADING_STOP = "04";

    /**
     * 開設不可 - 障害取引停止
     */
    public static final String OPENING_NOT_POSSIBLE_DISORDER_TRADING_STOP = "05";

    /**
     * 開設不可 - 非居住者
     */
    public static final String OPENING_NOT_POSSIBLE_NONRESIDENT = "06";

    /**
     * 開設不可 - 本人確認未済
     */
    public static final String OPENING_NOT_POSSIBLE_IDENTIFICATION_UNFINISHED = "07";

    /**
     * 開設不可 - 取引時確認未済
     */
    public static final String CONFIRMATION_UNFINISHED_ON_OPENING_NOT_POSSIBLE_TRADING = "08";

    /**
     * 開設不可 - 個人事業者(2)・役職員(6)・サラリーマンその他(8) 以外
     */
    public static final String OPENING_NOT_POSSIBLE_ONE_PERSON_OPERATION_PERSON = "09";

    /**
     * 開設不可 - 取引件数超過 （普通預金口座数＝５）
     */
    public static final String OPENING_NOT_POSSIBLE_TRADING_COUNT_EXCESS = "101";

    /**
     * 開設不可 - 総合口座取引あり
     */
    public static final String HAS_OPENING_NOT_POSSIBLE_CONSOLIDATED_ACCOUNT_TRANSACTION = "11";
}

package jp.co.jsbank.mobile.bff.common.code;

/**
 * 更新パターン（メール）コード
 */
public class UpdateTypeMailCode {

    /**
     * 口座開設（個人）
     */
    public static final String ACCOUNT_OPENING_PRIVATE = "101";

    /**
     * 口座開設（法人）
     */
    public static final String ACCOUNT_OPENING_CORPORATIVE = "102";

    /**
     * 口座開設（個人事業主）
     */
    public static final String ACCOUNT_OPENING_SOLE_PROPRIETORSHIP = "103";

    /**
     * CC発行
     */
    public static final String CC_ISSUANCE = "104";

    /**
     * 初回登録
     */
    public static final String FIRST_REGISTRATION = "105";

    /**
     * 各種登録設定
     */
    public static final String VARIOUS_REGISTRATION_PREFERENCE = "106";
}

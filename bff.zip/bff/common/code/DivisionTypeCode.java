package jp.co.jsbank.mobile.bff.common.code;

/**
 * 所属部門区分コード
 */
public class DivisionTypeCode {

    /**
     * 営業店
     */
    public static final String BUSINESS_DEPARTMENT = "0";

    /**
     * 本部
     */
    public static final String CENTRAL_DEPARTMENT = "1";

}

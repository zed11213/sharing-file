package jp.co.jsbank.mobile.bff.common.code;

/**
 * 照会店舗タイプ区分コード
 */
public class BranchInquiryTypeCode {

    /**
     * 営業店
     */
    public static final String BUSINESS_DEPARTMENT = "0";

    /**
     * 本部
     */
    public static final String CENTRAL_DEPARTMENT = "1";

    /**
     * インターネット店
     */
    public static final String INTERNET_DEPARTMENT  = "2";

}

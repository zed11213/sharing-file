package jp.co.jsbank.mobile.bff.common.code;

/**
 * 所在地相違区分コード
 */
public class OfficeClassificationCode {

    /**
     * 所在地と同一住所
     */
    public static final String ADDRESS_AND_THE_HEAD_OFFICE = "01";
    
    /**
     * 所在地と別住所
     */
    public static final String ADDRESS_AND_ANOTHER_ADDRESS = "02";
}

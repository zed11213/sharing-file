package jp.co.jsbank.mobile.bff.common.code;

/**
 * 総合口座フラグ
 */
public class GeneralAccountFlagCode {

    /**
     * 総合以外
     */
    public static final String GENERAL_EXCEPT = "0";
    
    /**
     * 総合口座
     */
    public static final String GENERAL_ACCOUNT = "1";
}

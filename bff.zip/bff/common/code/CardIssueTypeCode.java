package jp.co.jsbank.mobile.bff.common.code;

/**
 * 本人カード発行区分
 */
public class CardIssueTypeCode {

	/**
	 * 未発行:0
	 */
	public static final String NO_ISSUE = "0";

	/**
	 * 発行済:1
	 */
	public static final String ISSUE = "1";


}

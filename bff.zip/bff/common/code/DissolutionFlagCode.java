package jp.co.jsbank.mobile.bff.common.code;

/**
 * 解約フラグ
 */
public class DissolutionFlagCode {

    /**
     * 有効
     */
    public static final String EFFECTIVE = "0";

    /**
     * 解約
     */
    public static final String CANCELLATION = "1";  

}

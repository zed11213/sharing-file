package jp.co.jsbank.mobile.bff.common.code;

/**
 * 条件判定
 */
public class ConditionalJudgementCode {

    /**
     * ture
     */
    public static final String TURE = "0";

    /**
     * false
     */
    public static final String FALSE = "1";  

}

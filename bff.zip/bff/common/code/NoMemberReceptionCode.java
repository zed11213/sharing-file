package jp.co.jsbank.mobile.bff.common.code;

/**
 * 非会員受付有無フラグ
 * */
public class NoMemberReceptionCode {

    /**
     * 有
     */
    public static final String EXISTS = "1";
    
    /**
     * 無
     */
    public static final String NO_EXISTS = "0";
}

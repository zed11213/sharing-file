package jp.co.jsbank.mobile.bff.common.code;

/**
 * 個別確認結果フラグコード
 */
public class ConfirmFlgCode {

    /**
     * 確認未済
     */
    public static final String NOT_CONFIRMATION = "0";

    /**
     * 確認済
     */
    public static final String CONFIRMATION = "1"; 

}

package jp.co.jsbank.mobile.bff.common.exception;

import lombok.Getter;
@Getter
public class EkycLocalException  extends RuntimeException {

    private final String errorCode;         
    private final String errorMsg;  
   
	/**
	 * 
	 * @param errorCode エラーコード
	 * @param errorMsg エラーメッセージ
	 */
	public EkycLocalException(String errorCode, String errorMsg) {
		super("Internal error code: " + errorCode + "message:"+ errorMsg );
        this.errorCode = errorCode;
        this.errorMsg = errorMsg;
	}
}

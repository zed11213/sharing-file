package jp.co.jsbank.mobile.bff.common.exception;

/**
 * データなし例外。
 *
 */
public class ForbiddenException extends BusinessException {

    private static final long serialVersionUID = -1L;

    /**
	 * ForbiddenExceptionのコンスタント。
	 * 
	 * @param errorMsg エラーメッセージ
	 */
	public ForbiddenException(String errorMsg) {
		super("403", errorMsg);
	}
}

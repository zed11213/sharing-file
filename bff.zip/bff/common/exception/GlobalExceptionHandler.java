package jp.co.jsbank.mobile.bff.common.exception;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import jp.co.jsbank.mobile.bff.common.Constant;
import jp.co.jsbank.mobile.bff.common.ErrorCodeConstant;
import jp.co.jsbank.mobile.bff.common.ErrorResult;
import jp.co.jsbank.mobile.bff.common.MessageIdConstant;
import jp.co.jsbank.mobile.bff.common.RequestHeaderContext;
import jp.co.jsbank.mobile.bff.common.ScreenIdConstant;
import jp.co.jsbank.mobile.bff.common.util.MessageUtils;

/**
 * グローバル異常解析器
 */
@RestControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {
	/**
	 * logger
	 */
	private Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);
	/**
	 * 金融機関コード
	 */
	private String bankCode = "1344";
	/**
	 * アプリケーションID
	 */
	private String applicationID = "jsbapp01";
	/**
	 * クライアントID
	 */
	private String clientID = "010000";
	/**
	 * 端末識別するID
	 */
	private String deviceMk = "sm";
	/**
	 * フォーマット
	 */
	private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS z");
	/**
	 * 区切りの文字列
	 */
	private String splitValue = " ";

	/**
	 * エラーハンドリング(400)
	 *
	 * @param ex      データなし例外
	 * @param request Webリクエスト
	 * @return エラー結果
	 */
	@ExceptionHandler(BadRequestException.class)
	public ResponseEntity<Object> badRequestExceptionHandler(BadRequestException ex, WebRequest request) {

		// エラークラス
		ErrorResult errorResult = new ErrorResult();

		// 画面ID取得
		String screenId = RequestHeaderContext.getInstance().getScreenId();

		// エラーメッセージ
		String errorMsg = null;
		if (ex.args != null && ex.args.length > 0) {
			errorMsg = String.valueOf(ex.args[0]);
		}

		String param = ex.getCode();
		boolean isBa = ex.getCode().contains(Constant.BA_ERROR_CODE_PREFIX_STRING);
		
		if (isBa) {
			// BA
			return baBadRequestHandler(ex, request, errorResult, errorMsg);
		}
		// ABA
		switch (ex.getCode()) {

		case ErrorCodeConstant.ERROR_CODE_10000:
		case ErrorCodeConstant.ERROR_CODE_10001:
		case ErrorCodeConstant.ERROR_CODE_91000:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP0102,
					MessageIdConstant.MESSAGE_ID_MBAP0102, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP0102));
			// HTTP応答ステータス(500)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);
		case ErrorCodeConstant.ERROR_CODE_71200:

			if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBOP0601)

					|| StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBOP0604)
					|| StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBOP0608)
					|| StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBOP0609)
					|| StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBOP0610)
					|| StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBOP0611)
					|| StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBOP0612)
					|| StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBOP0613)
					|| StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBRC0202)) {

				// エラー結果作成
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP12001,
						MessageIdConstant.MESSAGE_ID_MBAP12001, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
				// ログ出力
				logger.warn(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_W, errorMsg,
						MessageIdConstant.MESSAGE_ID_MBAP12001));

			} else {

				// エラー結果作成
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1200,
						MessageIdConstant.MESSAGE_ID_MBAP1200, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
				// ログ出力
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
						MessageIdConstant.MESSAGE_ID_MBAP1200));

			}
			// HTTP応答ステータス(418)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);
		case ErrorCodeConstant.ERROR_CODE_71030:
		case ErrorCodeConstant.ERROR_CODE_71031:

			if (!StringUtils.isBlank(errorMsg) && errorMsg.contains(Constant.COLON)) {
				param = errorMsg.split(Constant.COLON)[1];
			}
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1030,
					MessageIdConstant.MESSAGE_ID_MBAP1030, ErrorCodeConstant.LOG_LABLE_I, param);
			// ログ出力
			logger.info(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_I, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1030));
			// HTTP応答ステータス(400)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);
		case ErrorCodeConstant.ERROR_CODE_71029:

			if (!StringUtils.isBlank(errorMsg) && errorMsg.contains(Constant.COLON)) {
				param = errorMsg.split(Constant.COLON)[1];
			}
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1029,
					MessageIdConstant.MESSAGE_ID_MBAP1029, ErrorCodeConstant.LOG_LABLE_I, param);
			// ログ出力
			logger.info(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_I, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1029));
			// HTTP応答ステータス(400)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);

		case ErrorCodeConstant.ERROR_CODE_71051:

			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1051,
					MessageIdConstant.MESSAGE_ID_MBAP1051, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1051));

			// HTTP応答ステータス(400)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);

		case ErrorCodeConstant.ERROR_CODE_71061:

			if (!StringUtils.isBlank(errorMsg) && errorMsg.contains(Constant.COLON)) {
				param = errorMsg.split(Constant.COLON)[1];
			}

			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1061,
					MessageIdConstant.MESSAGE_ID_MBAP1061, ErrorCodeConstant.LOG_LABLE_I, param);
			// ログ出力
			logger.info(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_I, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1061));

			// HTTP応答ステータス(400)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);
		case ErrorCodeConstant.ERROR_CODE_71032:

			if (!StringUtils.isBlank(errorMsg) && errorMsg.contains(Constant.COLON)) {
				param = errorMsg.split(Constant.COLON)[1];
			}
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1032,
					MessageIdConstant.MESSAGE_ID_MBAP1032, null, param);
			// ログ出力
			logger.info(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_I, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1032));
			// HTTP応答ステータス(400)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);
		case ErrorCodeConstant.ERROR_CODE_71033:

			if (!StringUtils.isBlank(errorMsg) && errorMsg.contains(Constant.COLON)) {
				param = errorMsg.split(Constant.COLON)[1];
			}
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1033,
					MessageIdConstant.MESSAGE_ID_MBAP1033, ErrorCodeConstant.LOG_LABLE_I, param);
			// ログ出力
			logger.info(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_I, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1033));
			// HTTP応答ステータス(400)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);
		case ErrorCodeConstant.ERROR_CODE_71034:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1034,
					MessageIdConstant.MESSAGE_ID_MBAP1034, ErrorCodeConstant.LOG_LABLE_I, param);
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1034));
			// HTTP応答ステータス(400)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);
		case ErrorCodeConstant.ERROR_CODE_71206:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1206,
					MessageIdConstant.MESSAGE_ID_MBAP1206, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1206));
			// HTTP応答ステータス(500)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);

		case ErrorCodeConstant.ERROR_CODE_71103:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1103,
					MessageIdConstant.MESSAGE_ID_MBAP1103, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1103));

			// HTTP応答ステータス(500)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);

		case ErrorCodeConstant.ERROR_CODE_71027:

			if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0302)
					|| StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0304)
					|| StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0308)) {
				// エラー結果作成
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP10271,
						MessageIdConstant.MESSAGE_ID_MBAP10271, null, ex.getCode());
				// エラーコード設定
				errorResult.setErrorCode(MessageIdConstant.MESSAGE_ID_MBAP10271);
				// ログ出力
				logger.info(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_I, errorMsg,
						MessageIdConstant.MESSAGE_ID_MBAP10271));
				// HTTP応答ステータス(418)
				return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);
			} else if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0306)) {
				// エラー結果作成
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP10274,
						MessageIdConstant.MESSAGE_ID_MBAP10274, null, ex.getCode());
				// エラーコード設定
				errorResult.setErrorCode(MessageIdConstant.MESSAGE_ID_MBAP10274);
				// ログ出力
				logger.info(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_I, errorMsg,
						MessageIdConstant.MESSAGE_ID_MBAP10274));
			} else if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBCC0501)) {
				// エラー結果作成
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP10275,
						MessageIdConstant.MESSAGE_ID_MBAP10275, null, ex.getCode());
				// エラーコード設定
				errorResult.setErrorCode(MessageIdConstant.MESSAGE_ID_MBAP10275);
				// ログ出力
				logger.info(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_I, errorMsg,
						MessageIdConstant.MESSAGE_ID_MBAP10275));
			}

			// HTTP応答ステータス(418)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);

		case ErrorCodeConstant.ERROR_CODE_71207:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1207,
					MessageIdConstant.MESSAGE_ID_MBAP1207, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1207));

			// HTTP応答ステータス(400)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);
		case ErrorCodeConstant.ERROR_CODE_71202:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1202,
					MessageIdConstant.MESSAGE_ID_MBAP1202, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1202));

			// HTTP応答ステータス(500)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);
		case ErrorCodeConstant.ERROR_CODE_71210:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1210,
					MessageIdConstant.MESSAGE_ID_MBAP1210, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1210));

			// HTTP応答ステータス(500)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);

		case ErrorCodeConstant.ERROR_CODE_71211:
			if (!StringUtils.isBlank(errorMsg) && errorMsg.contains(Constant.COLON)) {
				param = errorMsg.split(Constant.COLON)[1];
			}
			// 追加口座登録
			if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBST0802)) {
				// エラー結果作成
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBST0005,
						MessageIdConstant.MESSAGE_ID_MBST0005, null, param);
				// ログ出力
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
						MessageIdConstant.MESSAGE_ID_MBST0005));
			} else {
				// エラー結果作成
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1211,
						MessageIdConstant.MESSAGE_ID_MBAP1211, null, param);
				// ログ出力
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
						MessageIdConstant.MESSAGE_ID_MBAP1211));
			}

			// HTTP応答ステータス(500)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);

		case ErrorCodeConstant.ERROR_CODE_71013:

			if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0502)
					|| StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBCO0202)) {
				// エラー結果作成
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP10131,
						MessageIdConstant.MESSAGE_ID_MBAP10131, null, ex.getCode());
				// エラーコード設定
				errorResult.setErrorCode(MessageIdConstant.MESSAGE_ID_MBAP10131);
				// ログ出力
				logger.info(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_I, errorMsg,
						MessageIdConstant.MESSAGE_ID_MBAP10131));

			} else if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0602)
					|| StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBCO0302)) {
				// エラー結果作成
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP10132,
						MessageIdConstant.MESSAGE_ID_MBAP10132, null, ex.getCode());
				// エラーコード設定
				errorResult.setErrorCode(MessageIdConstant.MESSAGE_ID_MBAP10132);
				// ログ出力
				logger.info(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_I, errorMsg,
						MessageIdConstant.MESSAGE_ID_MBAP10132));

			} else if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBST0402)) {
				// エラー結果作成
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP10133,
						MessageIdConstant.MESSAGE_ID_MBAP10133, null, ex.getCode());
				// エラーコード設定
				errorResult.setErrorCode(MessageIdConstant.MESSAGE_ID_MBAP10133);
				// ログ出力
				logger.info(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_I, errorMsg,
						MessageIdConstant.MESSAGE_ID_MBAP10133));
			}
			// HTTP応答ステータス(418)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);

		case ErrorCodeConstant.ERROR_CODE_71008:

			if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0502)
					|| StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBCO0202)) {
				// エラー結果作成
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1008,
						MessageIdConstant.MESSAGE_ID_MBAP1008, null, ex.getCode());

				// ログ出力
				logger.info(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_I, errorMsg,
						MessageIdConstant.MESSAGE_ID_MBAP1008));
			}

			// HTTP応答ステータス(418)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);

		case ErrorCodeConstant.ERROR_CODE_71020:

			if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0502)
					|| StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBCO0202)) {
				// エラー結果作成
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1020,
						MessageIdConstant.MESSAGE_ID_MBAP1020, null, ex.getCode());
				// ログ出力
				logger.info(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_I, errorMsg,
						MessageIdConstant.MESSAGE_ID_MBAP1020));
			}

			// HTTP応答ステータス(418)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);
		case ErrorCodeConstant.ERROR_CODE_71021:

			if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0502)
					|| StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBCO0202)) {
				// エラー結果作成
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP10211,
						MessageIdConstant.MESSAGE_ID_MBAP1021, null, ex.getCode());
				// エラーコード設定
				errorResult.setErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1021);
				// ログ出力
				logger.info(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_I, errorMsg,
						MessageIdConstant.MESSAGE_ID_MBAP1021));

			} else if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBST0402)) {
				// エラー結果作成
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP10212,
						MessageIdConstant.MESSAGE_ID_MBAP1021, null, ex.getCode());
				// エラーコード設定
				errorResult.setErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1021);
				// ログ出力
				logger.info(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_I, errorMsg,
						MessageIdConstant.MESSAGE_ID_MBAP1021));
			}
			// HTTP応答ステータス(418)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);

		case ErrorCodeConstant.ERROR_CODE_71022:

			if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0502)
					|| StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBCO0202)) {
				// エラー結果作成
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP10221,
						MessageIdConstant.MESSAGE_ID_MBAP1022, null, ex.getCode());
				// エラーコード設定
				errorResult.setErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1022);
				// ログ出力
				logger.info(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_I, errorMsg,
						MessageIdConstant.MESSAGE_ID_MBAP1022));

			} else if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBST0402)) {
				// エラー結果作成
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP10222,
						MessageIdConstant.MESSAGE_ID_MBAP1022, null, ex.getCode());
				// エラーコード設定
				errorResult.setErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1022);
				// ログ出力
				logger.info(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_I, errorMsg,
						MessageIdConstant.MESSAGE_ID_MBAP1022));
			}
			// HTTP応答ステータス(418)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);
		case ErrorCodeConstant.ERROR_CODE_71201:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1201,
					MessageIdConstant.MESSAGE_ID_MBAP1201, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1201));
			// HTTP応答ステータス(500)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);

		case ErrorCodeConstant.ERROR_CODE_71205:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1205,
					MessageIdConstant.MESSAGE_ID_MBAP1205, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1205));
			// HTTP応答ステータス(500)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);

		case ErrorCodeConstant.ERROR_CODE_71002:

			if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0502)
					|| StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBCO0202)) {
				// エラー結果作成
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1002,
						MessageIdConstant.MESSAGE_ID_MBAP1002, null, ex.getCode());
				// ログ出力
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
						MessageIdConstant.MESSAGE_ID_MBAP1002));

			}
			// HTTP応答ステータス(400)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);

		case ErrorCodeConstant.ERROR_CODE_71026:

			if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0601)
					|| StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBCO0301)) {
				// エラー結果作成
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1026,
						MessageIdConstant.MESSAGE_ID_MBAP1026, null, ex.getCode());
				// ログ出力
				logger.warn(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_W, errorMsg,
						MessageIdConstant.MESSAGE_ID_MBAP1026));

			}
			// HTTP応答ステータス(418)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);

		case ErrorCodeConstant.ERROR_CODE_71007:

			if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0602)
					|| StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBCO0302)) {
				// エラー結果作成
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1007,
						MessageIdConstant.MESSAGE_ID_MBAP1007, null, ex.getCode());
				// ログ出力
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
						MessageIdConstant.MESSAGE_ID_MBAP1007));

			}
			// HTTP応答ステータス(418)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);

		case ErrorCodeConstant.ERROR_CODE_71018:

			if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0602)
					|| StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBCO0302)) {
				// エラー結果作成
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1018,
						MessageIdConstant.MESSAGE_ID_MBAP1018, null, ex.getCode());
				// ログ出力
				logger.info(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_I, errorMsg,
						MessageIdConstant.MESSAGE_ID_MBAP1018));

			}
			// HTTP応答ステータス(418)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);

		case ErrorCodeConstant.ERROR_CODE_71017:

			if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0602)
					|| StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBCO0302)) {
				// エラー結果作成
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1017,
						MessageIdConstant.MESSAGE_ID_MBAP1017, null, ex.getCode());
				// ログ出力
				logger.info(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_I, errorMsg,
						MessageIdConstant.MESSAGE_ID_MBAP1017));

			}
			// HTTP応答ステータス(418)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);

		case ErrorCodeConstant.ERROR_CODE_71019:

			if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0602)
					|| StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBCO0302)) {
				// エラー結果作成
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1019,
						MessageIdConstant.MESSAGE_ID_MBAP1019, null, ex.getCode());
				// ログ出力
				logger.info(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_I, errorMsg,
						MessageIdConstant.MESSAGE_ID_MBAP1019));

			}

			// HTTP応答ステータス(418)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);
		case ErrorCodeConstant.ERROR_CODE_71010:

			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1010,
					MessageIdConstant.MESSAGE_ID_MBAP1010, null, ex.getCode());
			// ログ出力
			logger.info(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_I, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1010));

			// HTTP応答ステータス(418)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);

		case ErrorCodeConstant.ERROR_CODE_71023:

			if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0306)) {
				// エラー結果作成
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1023,
						MessageIdConstant.MESSAGE_ID_MBAP1023, null, ex.getCode());
				// ログ出力
				logger.info(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_I, errorMsg,
						MessageIdConstant.MESSAGE_ID_MBAP1023));

			}
			// HTTP応答ステータス(418)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);

		case ErrorCodeConstant.ERROR_CODE_71024:

			if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0306)) {
				// エラー結果作成
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1024,
						MessageIdConstant.MESSAGE_ID_MBAP1024, null, ex.getCode());
				// ログ出力
				logger.info(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_I, errorMsg,
						MessageIdConstant.MESSAGE_ID_MBAP1024));

			}
			// HTTP応答ステータス(418)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);

		case ErrorCodeConstant.ERROR_CODE_71025:

			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1025,
					MessageIdConstant.MESSAGE_ID_MBAP1025, null, ex.getCode());
			// ログ出力
			logger.info(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_I, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1025));

			// HTTP応答ステータス(418)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);

		case ErrorCodeConstant.ERROR_CODE_71208:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1208,
					MessageIdConstant.MESSAGE_ID_MBAP1208, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());

			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1208));
			// HTTP応答ステータス(500)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);

		case ErrorCodeConstant.ERROR_CODE_71100:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1100,
					MessageIdConstant.MESSAGE_ID_MBAP1100, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1100));
			// HTTP応答ステータス(500)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);

		case ErrorCodeConstant.ERROR_CODE_71102:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1102,
					MessageIdConstant.MESSAGE_ID_MBAP1102, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1102));
			// HTTP応答ステータス(400)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);

		case ErrorCodeConstant.ERROR_CODE_71001:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1001,
					MessageIdConstant.MESSAGE_ID_MBAP1001, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1001));
			// HTTP応答ステータス(418)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);

		case ErrorCodeConstant.ERROR_CODE_71000:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1000,
					MessageIdConstant.MESSAGE_ID_MBAP1000, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1000));
			// HTTP応答ステータス(500)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);

		case ErrorCodeConstant.ERROR_CODE_71004:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1004,
					MessageIdConstant.MESSAGE_ID_MBAP1004, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1004));
			// HTTP応答ステータス(500)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);

		case ErrorCodeConstant.ERROR_CODE_71005:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1005,
					MessageIdConstant.MESSAGE_ID_MBAP1005, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1005));
			// HTTP応答ステータス(500)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);

		case ErrorCodeConstant.ERROR_CODE_71006:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1006,
					MessageIdConstant.MESSAGE_ID_MBAP1006, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1006));
			// HTTP応答ステータス(500)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);

		case ErrorCodeConstant.ERROR_CODE_71003:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1003,
					MessageIdConstant.MESSAGE_ID_MBAP1003, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1003));
			// HTTP応答ステータス(500)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);

		case ErrorCodeConstant.ERROR_CODE_71047:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1047,
					MessageIdConstant.MESSAGE_ID_MBAP1047, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1047));
			// HTTP応答ステータス(500)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);

		case ErrorCodeConstant.ERROR_CODE_71306:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1306,
					MessageIdConstant.MESSAGE_ID_MBAP1306, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1306));
			// HTTP応答ステータス(400)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);

		case ErrorCodeConstant.ERROR_CODE_71307:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1307,
					MessageIdConstant.MESSAGE_ID_MBAP1307, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1307));
			// HTTP応答ステータス(400)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);

		case ErrorCodeConstant.ERROR_CODE_71308:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1308,
					MessageIdConstant.MESSAGE_ID_MBAP1308, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1308));
			// HTTP応答ステータス(400)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);

		case ErrorCodeConstant.ERROR_CODE_71309:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1309,
					MessageIdConstant.MESSAGE_ID_MBAP1309, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1309));
			// HTTP応答ステータス(400)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);

		case ErrorCodeConstant.ERROR_CODE_71401:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1401,
					MessageIdConstant.MESSAGE_ID_MBAP1401, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_I, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1401));
			// HTTP応答ステータス(418)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);

		case ErrorCodeConstant.ERROR_CODE_71402:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1402,
					MessageIdConstant.MESSAGE_ID_MBAP1402, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_I, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1402));
			// HTTP応答ステータス(418)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);

		case ErrorCodeConstant.ERROR_CODE_71410:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1410,
					MessageIdConstant.MESSAGE_ID_MBAP1410, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_I, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1410));
			// HTTP応答ステータス(418)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);

		case ErrorCodeConstant.ERROR_CODE_71406:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1406,
					MessageIdConstant.MESSAGE_ID_MBAP1406, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_I, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1406));
			// HTTP応答ステータス(418)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);

		case ErrorCodeConstant.ERROR_CODE_71407:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1407,
					MessageIdConstant.MESSAGE_ID_MBAP1407, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_I, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1407));
			// HTTP応答ステータス(418)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);

		case ErrorCodeConstant.ERROR_CODE_71408:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1408,
					MessageIdConstant.MESSAGE_ID_MBAP1408, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_I, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1408));
			// HTTP応答ステータス(418)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);
		case ErrorCodeConstant.ERROR_CODE_71404:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1404,
					MessageIdConstant.MESSAGE_ID_MBAP1404, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
			// ログ出力
			logger.info(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_I, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1404));
			// HTTP応答ステータス(418)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);
		case ErrorCodeConstant.ERROR_CODE_71412:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1412,
					MessageIdConstant.MESSAGE_ID_MBAP1412, ex.getCode());
			// ログ出力
			logger.info(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_I, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1412));
			// HTTP応答ステータス(418)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);

		case ErrorCodeConstant.ERROR_CODE_71044:

			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1044,
					MessageIdConstant.MESSAGE_ID_MBAP1044, null, ex.getCode());
			// ログ出力
			logger.info(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_I, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1044));

			// HTTP応答ステータス(418)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);
		case ErrorCodeConstant.ERROR_CODE_71209:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1209,
					MessageIdConstant.MESSAGE_ID_MBAP1209, null, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1209));
			// HTTP応答ステータス(400)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);

		case ErrorCodeConstant.ERROR_CODE_71212:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1212,
					MessageIdConstant.MESSAGE_ID_MBAP1212, null, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1212));
			// HTTP応答ステータス(400)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);
		case ErrorCodeConstant.ERROR_CODE_71217:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1217,
					MessageIdConstant.MESSAGE_ID_MBAP1217, null, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1217));
			// HTTP応答ステータス(400)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);
		case ErrorCodeConstant.ERROR_CODE_71218:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1218,
					MessageIdConstant.MESSAGE_ID_MBAP1218, null, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1218));
			// HTTP応答ステータス(400)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);
		case ErrorCodeConstant.ERROR_CODE_71219:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1219,
					MessageIdConstant.MESSAGE_ID_MBAP1219, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1219));
			// HTTP応答ステータス(500)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);
		case ErrorCodeConstant.ERROR_CODE_71220:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1220,
					MessageIdConstant.MESSAGE_ID_MBAP1220, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1220));

			// HTTP応答ステータス(400)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);
		case ErrorCodeConstant.ERROR_CODE_71213:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1213,
					MessageIdConstant.MESSAGE_ID_MBAP1213, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1213));
			// HTTP応答ステータス(500)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);

		case ErrorCodeConstant.ERROR_CODE_71062:

			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1062,
					MessageIdConstant.MESSAGE_ID_MBAP1062, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
			// ログ出力
			logger.info(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_I, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1062));
			// HTTP応答ステータス(400)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);

		case ErrorCodeConstant.ERROR_CODE_71215:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1215,
					MessageIdConstant.MESSAGE_ID_MBAP1215, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_I, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1215));
			// HTTP応答ステータス(500)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);
		case MessageIdConstant.MESSAGE_ID_MBOP0003:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBOP0003,
					MessageIdConstant.MESSAGE_ID_MBOP0003, ErrorCodeConstant.LOG_LABLE_W, ex.getCode());
			// ログ出力
			logger.warn(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_W, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBOP0003));
			// HTTP応答ステータス(418)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);
		case ErrorCodeConstant.ERROR_CODE_71302:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1302,
					MessageIdConstant.MESSAGE_ID_MBAP1302, null, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1302));

			// HTTP応答ステータス(418)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);
		case MessageIdConstant.MESSAGE_ID_MBOP0004:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBOP0004,
					MessageIdConstant.MESSAGE_ID_MBOP0004, ErrorCodeConstant.LOG_LABLE_I, errorMsg);
			// ログ出力
			logger.info(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_I, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBOP0004));
			// HTTP応答ステータス(418)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);
		case MessageIdConstant.MESSAGE_ID_MBSU0001:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBSU0001,
					MessageIdConstant.MESSAGE_ID_MBSU0001, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
			// ログ出力
			logger.info(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_I, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBSU0001));
			// HTTP応答ステータス(400)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);
		case MessageIdConstant.MESSAGE_ID_MBCC0001:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBCC0001,
					MessageIdConstant.MESSAGE_ID_MBCC0001, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
			// ログ出力
			logger.info(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_I, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBCC0001));
			// HTTP応答ステータス(400)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);
		case MessageIdConstant.MESSAGE_ID_MBSU0002:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBSU0002,
					MessageIdConstant.MESSAGE_ID_MBSU0002);
			// ログ出力
			logger.info(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_I, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBSU0002));
			// HTTP応答ステータス(400)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);

		case MessageIdConstant.MESSAGE_ID_MBSU0003:
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBSU0003,
					MessageIdConstant.MESSAGE_ID_MBSU0003);
			// ログ出力
			logger.info(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_I, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBSU0003));
			// HTTP応答ステータス(400)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);
		case MessageIdConstant.MESSAGE_ID_MBSU0004:
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBSU0004,
					MessageIdConstant.MESSAGE_ID_MBSU0004);
			// ログ出力
			logger.info(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_I, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBSU0004));
			// HTTP応答ステータス(400)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);
		case MessageIdConstant.MESSAGE_ID_MBAP0011:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP0011,
					MessageIdConstant.MESSAGE_ID_MBAP0011);
			// ログ出力
			logger.warn(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_W, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP0011));
			// HTTP応答ステータス(400)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);

		case ErrorCodeConstant.ERROR_CODE_95000:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP0105,
					MessageIdConstant.MESSAGE_ID_MBAP0105, ErrorCodeConstant.LOG_LABLE_E,
					ErrorCodeConstant.ERROR_CODE_95000);
			// エラーコード設定
			errorResult.setErrorCode(MessageIdConstant.MESSAGE_ID_MBAP0105);
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, "", MessageIdConstant.MESSAGE_ID_MBAP0105));
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);
		case MessageIdConstant.MESSAGE_ID_MBST0006:

			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBST0006,
					MessageIdConstant.MESSAGE_ID_MBST0006, ErrorCodeConstant.LOG_LABLE_E);
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBST0006));

			// HTTP応答ステータス(400)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);
        case MessageIdConstant.MESSAGE_ID_MBFS0001:
            errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBFS0001,
                    MessageIdConstant.MESSAGE_ID_MBFS0001);
            // ログ出力
            logger.info(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_I, errorMsg,
                    MessageIdConstant.MESSAGE_ID_MBFS0001));
            // HTTP応答ステータス(400)
            return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);
        case MessageIdConstant.MESSAGE_ID_MBFS0005:
            errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBFS0005,
                    MessageIdConstant.MESSAGE_ID_MBFS0005);
            // ログ出力
            logger.info(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_I, errorMsg,
                    MessageIdConstant.MESSAGE_ID_MBFS0005));
            // HTTP応答ステータス(400)
            return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);
        case MessageIdConstant.MESSAGE_ID_MBFS0006:
            errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBFS0006,
                    MessageIdConstant.MESSAGE_ID_MBFS0006);
            // ログ出力
            logger.info(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_I, errorMsg,
                    MessageIdConstant.MESSAGE_ID_MBFS0006));
            // HTTP応答ステータス(400)
            return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);
        case MessageIdConstant.MESSAGE_ID_MBFS0007:
            errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBFS0007,
                    MessageIdConstant.MESSAGE_ID_MBFS0007);
            // ログ出力
            logger.info(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_I, errorMsg,
                    MessageIdConstant.MESSAGE_ID_MBFS0007));
            // HTTP応答ステータス(400)
            return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);
        case MessageIdConstant.MESSAGE_ID_MBFS0008:
            errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBFS0008,
                    MessageIdConstant.MESSAGE_ID_MBFS0008);
            // ログ出力
            logger.info(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_I, errorMsg,
                    MessageIdConstant.MESSAGE_ID_MBFS0008));
            // HTTP応答ステータス(400)
            return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);
		default:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP0008,
					MessageIdConstant.MESSAGE_ID_MBAP0008, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, ex.getCode() + errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP0008));
			// HTTP応答ステータス(500)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);

		}

	}

	private ResponseEntity<Object> baBadRequestHandler(BadRequestException ex, WebRequest request, ErrorResult errorResult, String errorMsg) {
		// RestClientErrorHandlerつけたBA PREFIXを削除
		String code = ex.getCode().replaceFirst(Constant.BA_ERROR_CODE_PREFIX_STRING, "");
		switch (code) {
			// エラー結果作成
			// ログ出力
			case ErrorCodeConstant.BA_ERROR_CODE_91000:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1000, MessageIdConstant.MESSAGE_ID_MBBA1000, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA1000));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_92000:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA2000, MessageIdConstant.MESSAGE_ID_MBBA2000, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA2000));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_502:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA9999, MessageIdConstant.MESSAGE_ID_MBBA9999, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorResult.getErrorMessage(), MessageIdConstant.MESSAGE_ID_MBBA9999));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_1564:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA9999, MessageIdConstant.MESSAGE_ID_MBBA9999, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorResult.getErrorMessage(), MessageIdConstant.MESSAGE_ID_MBBA9999));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_2000:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA9999, MessageIdConstant.MESSAGE_ID_MBBA9999, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorResult.getErrorMessage(), MessageIdConstant.MESSAGE_ID_MBBA9999));	
				break;
            case ErrorCodeConstant.BA_ERROR_CODE_1050:
                errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1050, MessageIdConstant.MESSAGE_ID_MBBA1050, ErrorCodeConstant.LOG_LABLE_E, errorMsg);
                logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorResult.getErrorMessage(), MessageIdConstant.MESSAGE_ID_MBBA1050));
                break;
			default:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA9998, MessageIdConstant.MESSAGE_ID_MBBA9998, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA9998));	
				break;
		}
		// HTTP応答ステータス(400)
		return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);
	}

	/**
	 * エラーハンドリング(500)
	 *
	 * @param ex      データなし例外
	 * @param request Webリクエスト
	 * @return エラー結果
	 */
	@ExceptionHandler(InternalServerErrorException.class)
	public ResponseEntity<Object> internalServerErrorExceptionHandler(InternalServerErrorException ex,
			WebRequest request) {

		// エラークラス
		ErrorResult errorResult = new ErrorResult();

		// 画面ID取得
		String screenId = RequestHeaderContext.getInstance().getScreenId();

		// エラーメッセージ
		String errorMsg = null;
		if (ex.args != null && ex.args.length > 0) {
			errorMsg = String.valueOf(ex.args[0]);
		}

		boolean isBa = ex.getCode().contains(Constant.BA_ERROR_CODE_PREFIX_STRING);
		
		if (isBa) {
			// BA
			return baInternalServerErrorHandler(ex, request, errorResult, errorMsg);
		}

		// ABA
		switch (ex.getCode()) {
		case ErrorCodeConstant.ERROR_CODE_10022:
		case ErrorCodeConstant.ERROR_CODE_10031:
		case ErrorCodeConstant.ERROR_CODE_10032:
		case ErrorCodeConstant.ERROR_CODE_30010:
		case ErrorCodeConstant.ERROR_CODE_33293:
		case ErrorCodeConstant.ERROR_CODE_90000:
		case ErrorCodeConstant.ERROR_CODE_90002:
		case ErrorCodeConstant.ERROR_CODE_90003:
		case ErrorCodeConstant.ERROR_CODE_90004:
		case ErrorCodeConstant.ERROR_CODE_90005:
		case ErrorCodeConstant.ERROR_CODE_95001:
		case ErrorCodeConstant.ERROR_CODE_99999:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP0101,
					MessageIdConstant.MESSAGE_ID_MBAP0101, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP0101));
			// HTTP応答ステータス(500)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);

		case ErrorCodeConstant.ERROR_CODE_10021:
		case ErrorCodeConstant.ERROR_CODE_10023:
		case ErrorCodeConstant.ERROR_CODE_91001:
		case ErrorCodeConstant.ERROR_CODE_90006:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP0102,
					MessageIdConstant.MESSAGE_ID_MBAP0102, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP0102));
			// HTTP応答ステータス(500)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);

		case ErrorCodeConstant.ERROR_CODE_90001:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP0103,
					MessageIdConstant.MESSAGE_ID_MBAP0103, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
			// エラーコード設定
			errorResult.setErrorCode(MessageIdConstant.MESSAGE_ID_MBAP0103);
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP0103));
			// HTTP応答ステータス(503)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.SERVICE_UNAVAILABLE, request);

		case ErrorCodeConstant.ERROR_CODE_95002:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP0104,
					MessageIdConstant.MESSAGE_ID_MBAP0104, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP0104));
			// HTTP応答ステータス(503)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.SERVICE_UNAVAILABLE, request);
		case ErrorCodeConstant.ERROR_CODE_71042:

			if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0501)
					|| StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBCO0201)
					|| StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBST0401)) {
				// エラー結果作成
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1042,
						MessageIdConstant.MESSAGE_ID_MBAP1042, ErrorCodeConstant.LOG_LABLE_I, ex.getCode());
				// ログ出力
				logger.info(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_I, errorMsg,
						MessageIdConstant.MESSAGE_ID_MBAP1042));
			}

			// HTTP応答ステータス(418)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);

		case ErrorCodeConstant.ERROR_CODE_71041:

			if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0601)
					|| StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBCO0301)) {
				// エラー結果作成
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1041,
						MessageIdConstant.MESSAGE_ID_MBAP1041, null, ex.getCode());
				// ログ出力
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
						MessageIdConstant.MESSAGE_ID_MBAP1041));

			}
			// HTTP応答ステータス(418)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);
		case ErrorCodeConstant.ERROR_CODE_71063:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1063,
					MessageIdConstant.MESSAGE_ID_MBAP1063, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1063));
			// HTTP応答ステータス(500)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);

		case ErrorCodeConstant.ERROR_CODE_71054:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1054,
					MessageIdConstant.MESSAGE_ID_MBAP1054, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1054));
			// HTTP応答ステータス(400)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);
		case ErrorCodeConstant.ERROR_CODE_71302:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1302,
					MessageIdConstant.MESSAGE_ID_MBAP1302, null, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1302));

			// HTTP応答ステータス(418)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);
		case ErrorCodeConstant.ERROR_CODE_71303:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1303,
					MessageIdConstant.MESSAGE_ID_MBAP1303, null, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1303));

			// HTTP応答ステータス(418)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);

		case ErrorCodeConstant.ERROR_CODE_71304:
			// エラー結果作成
			errorResult = createErrorResult(MessageIdConstant.MESSAGE_ID_MBAP1304);
			// ログ出力
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1304,
					MessageIdConstant.MESSAGE_ID_MBAP1304, null, ex.getCode());
			// HTTP応答ステータス(500)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);

		case ErrorCodeConstant.ERROR_CODE_71305:
			// エラー結果作成
			errorResult = createErrorResult(MessageIdConstant.MESSAGE_ID_MBAP1305);
			// ログ出力
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1305,
					MessageIdConstant.MESSAGE_ID_MBAP1305, null, ex.getCode());
			// HTTP応答ステータス(500)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);
		case ErrorCodeConstant.ERROR_CODE_71048:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1048,
					MessageIdConstant.MESSAGE_ID_MBAP1048, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1048));
			// HTTP応答ステータス(400)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);

		case ErrorCodeConstant.ERROR_CODE_71049:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1049,
					MessageIdConstant.MESSAGE_ID_MBAP1049, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1049));
			// HTTP応答ステータス(400)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);

		case ErrorCodeConstant.ERROR_CODE_71050:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1050,
					MessageIdConstant.MESSAGE_ID_MBAP1050, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1050));
			// HTTP応答ステータス(400)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);
		case ErrorCodeConstant.ERROR_CODE_71055:

			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1055,
					MessageIdConstant.MESSAGE_ID_MBAP1055, null, ex.getCode());
			// ログ出力
			logger.info(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_I, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1055));

			// HTTP応答ステータス(500)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);
		case ErrorCodeConstant.ERROR_CODE_71066:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1066,
					MessageIdConstant.MESSAGE_ID_MBAP1066, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1066));

			// HTTP応答ステータス(400)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);
		case ErrorCodeConstant.ERROR_CODE_71067:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1067,
					MessageIdConstant.MESSAGE_ID_MBAP1067, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1067));
			// HTTP応答ステータス(400)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);
		case ErrorCodeConstant.ERROR_CODE_71068:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1068,
					MessageIdConstant.MESSAGE_ID_MBAP1068, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1068));
			// HTTP応答ステータス(400)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);
		case ErrorCodeConstant.ERROR_CODE_71069:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1069,
					MessageIdConstant.MESSAGE_ID_MBAP1069, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1069));
			// HTTP応答ステータス(400)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);
		case ErrorCodeConstant.ERROR_CODE_71070:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1070,
					MessageIdConstant.MESSAGE_ID_MBAP1070, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1070));
			// HTTP応答ステータス(400)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);
		case ErrorCodeConstant.ERROR_CODE_71071:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1071,
					MessageIdConstant.MESSAGE_ID_MBAP1071, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1071));
			// HTTP応答ステータス(400)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);
		case ErrorCodeConstant.ERROR_CODE_71052:

			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1052,
					MessageIdConstant.MESSAGE_ID_MBAP1052, ErrorCodeConstant.LOG_LABLE_I, ex.getCode());
			// ログ出力
			logger.info(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_I, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1052));

			// HTTP応答ステータス(500)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);
		case ErrorCodeConstant.ERROR_CODE_71053:

			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1053,
					MessageIdConstant.MESSAGE_ID_MBAP1053, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1053));

			// HTTP応答ステータス(500)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);
		case ErrorCodeConstant.ERROR_CODE_71058:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1058,
					MessageIdConstant.MESSAGE_ID_MBAP1058, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP1058));
			// HTTP応答ステータス(500)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);

		case ErrorCodeConstant.ERROR_CODE_MBST0001:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBST0001,
					MessageIdConstant.MESSAGE_ID_MBST0001, ErrorCodeConstant.LOG_LABLE_E);
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBST0001));
			// HTTP応答ステータス(500)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);
		case ErrorCodeConstant.ERROR_CODE_MBST0002:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBST0002,
					MessageIdConstant.MESSAGE_ID_MBST0002, ErrorCodeConstant.LOG_LABLE_E);
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBST0002));
			// HTTP応答ステータス(500)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);
		case ErrorCodeConstant.ERROR_CODE_MBST0003:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBST0003,
					MessageIdConstant.MESSAGE_ID_MBST0003, ErrorCodeConstant.LOG_LABLE_E);
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBST0003));
			// HTTP応答ステータス(500)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);
		case ErrorCodeConstant.ERROR_CODE_MBST0004:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBST0004,
					MessageIdConstant.MESSAGE_ID_MBST0004, ErrorCodeConstant.LOG_LABLE_E);
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBST0004));
			// HTTP応答ステータス(500)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);
		case ErrorCodeConstant.ERROR_CODE_MBAP0010:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP0010,
					MessageIdConstant.MESSAGE_ID_MBAP0010, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP0010));
			// HTTP応答ステータス(500)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);
		case ErrorCodeConstant.ERROR_CODE_MBAP0012:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP0012,
					MessageIdConstant.MESSAGE_ID_MBAP0012, null, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP0012));
			// HTTP応答ステータス(500)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);
		case ErrorCodeConstant.ERROR_CODE_MBAP0009:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP0009,
					MessageIdConstant.MESSAGE_ID_MBAP0009, ErrorCodeConstant.LOG_LABLE_E, null);
			// リクエストボディ取得してログに追加
			String requestBody0009 = "";
			try {
				if (request instanceof ServletWebRequest) {
					javax.servlet.http.HttpServletRequest httpRequest = ((ServletWebRequest) request).getRequest();
					requestBody0009 = org.springframework.util.StreamUtils.copyToString(
							httpRequest.getInputStream(), java.nio.charset.StandardCharsets.UTF_8);
				}
			} catch (Exception e) {
				requestBody0009 = "requestBody取得失敗";
			}
			String errorMsgWithRequest = (errorMsg != null ? errorMsg : "") + " | requestBody=" + requestBody0009;
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsgWithRequest,
					MessageIdConstant.MESSAGE_ID_MBAP0009));

			// HTTP応答ステータス(500)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);
        case ErrorCodeConstant.ERROR_CODE_MBFS0002:
            errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBFS0002,
                    MessageIdConstant.MESSAGE_ID_MBFS0002);
            // ログ出力
            logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
                    MessageIdConstant.MESSAGE_ID_MBFS0002));

            // HTTP応答ステータス(500)
            return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);
        case ErrorCodeConstant.ERROR_CODE_MBFS0003:
            errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBFS0003,
                    MessageIdConstant.MESSAGE_ID_MBFS0003);
            // ログ出力
            logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
                    MessageIdConstant.MESSAGE_ID_MBFS0003));

            // HTTP応答ステータス(500)
            return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);
        case ErrorCodeConstant.ERROR_CODE_MBFS0004:
            errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBFS0004,
                    MessageIdConstant.MESSAGE_ID_MBFS0004);
            // ログ出力
            logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg,
                    MessageIdConstant.MESSAGE_ID_MBFS0004));

            // HTTP応答ステータス(500)
            return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);
		default:
			// エラー結果作成
			errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP0008,
					MessageIdConstant.MESSAGE_ID_MBAP0008, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
			// ログ出力
			logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, ex.getCode() + errorMsg,
					MessageIdConstant.MESSAGE_ID_MBAP0008));
			// HTTP応答ステータス(500)
			return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);

		}
	}

	private ResponseEntity<Object> baInternalServerErrorHandler(InternalServerErrorException ex, WebRequest request, ErrorResult errorResult, String errorMsg) {
		// RestClientErrorHandlerつけたBA PREFIXを削除
		String code = ex.getCode().replaceFirst(Constant.BA_ERROR_CODE_PREFIX_STRING, "");
		switch (code) {
			// エラー結果作成
			// ログ出力
			case ErrorCodeConstant.BA_ERROR_CODE_90000:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA0000, MessageIdConstant.MESSAGE_ID_MBBA0000, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA0000));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_90001:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA0001, MessageIdConstant.MESSAGE_ID_MBBA0001, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA0001));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_91001:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1001, MessageIdConstant.MESSAGE_ID_MBBA1001, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA1001));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_91002:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1002, MessageIdConstant.MESSAGE_ID_MBBA1002, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA1002));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_91003:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1003, MessageIdConstant.MESSAGE_ID_MBBA1003, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA1003));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_91004:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1004, MessageIdConstant.MESSAGE_ID_MBBA1004, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA1004));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_91005:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1005, MessageIdConstant.MESSAGE_ID_MBBA1005, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA1005));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_91006:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1006, MessageIdConstant.MESSAGE_ID_MBBA1006, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA1006));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_91007:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1007, MessageIdConstant.MESSAGE_ID_MBBA1007, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA1007));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_91008:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1008, MessageIdConstant.MESSAGE_ID_MBBA1008, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA1008));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_91009:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1009, MessageIdConstant.MESSAGE_ID_MBBA1009, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA1009));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_91010:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1010, MessageIdConstant.MESSAGE_ID_MBBA1010, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA1010));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_91011:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1011, MessageIdConstant.MESSAGE_ID_MBBA1011, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA1011));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_91012:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1012, MessageIdConstant.MESSAGE_ID_MBBA1012, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA1012));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_91013:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1013, MessageIdConstant.MESSAGE_ID_MBBA1013, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA1013));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_91014:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1014, MessageIdConstant.MESSAGE_ID_MBBA1014, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA1014));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_91015:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1015, MessageIdConstant.MESSAGE_ID_MBBA1015, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA1015));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_91016:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1016, MessageIdConstant.MESSAGE_ID_MBBA1016, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA1016));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_91017:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1017, MessageIdConstant.MESSAGE_ID_MBBA1017, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA1017));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_91018:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1018, MessageIdConstant.MESSAGE_ID_MBBA1018, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA1018));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_91019:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1019, MessageIdConstant.MESSAGE_ID_MBBA1019, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA1019));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_91020:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1020, MessageIdConstant.MESSAGE_ID_MBBA1020, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA1020));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_91021:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1021, MessageIdConstant.MESSAGE_ID_MBBA1021, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA1021));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_91022:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1022, MessageIdConstant.MESSAGE_ID_MBBA1022, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA1022));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_91023:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1023, MessageIdConstant.MESSAGE_ID_MBBA1023, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA1023));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_91024:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1024, MessageIdConstant.MESSAGE_ID_MBBA1024, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA1024));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_91025:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1025, MessageIdConstant.MESSAGE_ID_MBBA1025, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA1025));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_91026:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1026, MessageIdConstant.MESSAGE_ID_MBBA1026, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA1026));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_91027:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1027, MessageIdConstant.MESSAGE_ID_MBBA1027, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA1027));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_91028:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1028, MessageIdConstant.MESSAGE_ID_MBBA1028, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA1028));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_91029:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1029, MessageIdConstant.MESSAGE_ID_MBBA1029, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA1029));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_91030:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1030, MessageIdConstant.MESSAGE_ID_MBBA1030, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA1030));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_91031:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1031, MessageIdConstant.MESSAGE_ID_MBBA1031, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA1031));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_91032:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1032, MessageIdConstant.MESSAGE_ID_MBBA1032, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA1032));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_91033:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1033, MessageIdConstant.MESSAGE_ID_MBBA1033, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA1033));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_91034:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1034, MessageIdConstant.MESSAGE_ID_MBBA1034, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA1034));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_91035:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1035, MessageIdConstant.MESSAGE_ID_MBBA1035, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA1035));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_91036:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1036, MessageIdConstant.MESSAGE_ID_MBBA1036, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA1036));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_91037:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1037, MessageIdConstant.MESSAGE_ID_MBBA1037, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA1037));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_91038:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1038, MessageIdConstant.MESSAGE_ID_MBBA1038, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA1038));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_91039:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1039, MessageIdConstant.MESSAGE_ID_MBBA1039, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA1039));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_91040:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1040, MessageIdConstant.MESSAGE_ID_MBBA1040, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA1040));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_91041:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1041, MessageIdConstant.MESSAGE_ID_MBBA1041, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA1041));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_91042:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1042, MessageIdConstant.MESSAGE_ID_MBBA1042, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA1042));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_91043:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1043, MessageIdConstant.MESSAGE_ID_MBBA1043, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA1043));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_91044:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1044, MessageIdConstant.MESSAGE_ID_MBBA1044, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA1044));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_91045:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1045, MessageIdConstant.MESSAGE_ID_MBBA1045, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA1045));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_91046:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1046, MessageIdConstant.MESSAGE_ID_MBBA1046, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA1046));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_91047:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1047, MessageIdConstant.MESSAGE_ID_MBBA1047, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA1047));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_91048:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1048, MessageIdConstant.MESSAGE_ID_MBBA1048, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA1048));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_91049:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA1049, MessageIdConstant.MESSAGE_ID_MBBA1049, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA1049));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_95001:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA5001, MessageIdConstant.MESSAGE_ID_MBBA5001, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA5001));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_95002:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA5002, MessageIdConstant.MESSAGE_ID_MBBA5002, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA5002));	
				break;
			default:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA9998, MessageIdConstant.MESSAGE_ID_MBBA9998, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA9998));	
				break;
		}
		// HTTP応答ステータス(500)
		return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);
	}
	
	/**
	 * エラーハンドリング(401)
	 *
	 * @param ex      データなし例外
	 * @param request Webリクエスト
	 * @return エラー結果
	 */
	@ExceptionHandler(UnauthorizedException.class)
	public ResponseEntity<Object> unauthorizedExceptionHandler(UnauthorizedException ex, WebRequest request) {

		// // エラー結果作成
		// ErrorResult errorResult =
		// createErrorResult(MessageIdConstant.MESSAGE_ID_MBAP0003);
		// // ログ出力
		// logger.error(splicingLogInfo(ex, errorMsg,
		// MessageIdConstant.MESSAGE_ID_MBAP0003));
		//
		// return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.OK,
		// request);

		return null;
	}

	/**
	 * エラーハンドリング(403)
	 *
	 * @param ex      バリエーション例外
	 * @param request Webリクエスト
	 * @return エラー結果
	 */
	@ExceptionHandler(ForbiddenException.class)
	public ResponseEntity<Object> forbiddenExceptionHandler(ForbiddenException ex, WebRequest request) {
		// エラー結果作成
		ErrorResult errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP0004,
				MessageIdConstant.MESSAGE_ID_MBAP0004, null, ex.getCode());
		// ログ出力
		logger.warn(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_W, "", MessageIdConstant.MESSAGE_ID_MBAP0004));

		return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.FORBIDDEN, request);
	}

	/**
	 * エラーハンドリング(404)
	 *
	 * @param ex      バリエーション例外
	 * @param request Webリクエスト
	 * @return エラー結果
	 */
	@ExceptionHandler(NotFoundException.class)
	public ResponseEntity<Object> notFoundExceptionHandler(NotFoundException ex, WebRequest request) {

		// // エラー結果作成
		// ErrorResult errorResult =
		// createErrorResult(MessageIdConstant.MESSAGE_ID_MBAP0005);
		// // ログ出力
		// logger.error(splicingLogInfo(ex, errorMsg,
		// MessageIdConstant.MESSAGE_ID_MBAP0005));
		//
		// return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.OK,
		// request);
		return null;
	}

	/**
	 * エラーハンドリング(426)
	 *
	 * @param ex      バリエーション例外
	 * @param request Webリクエスト
	 * @return エラー結果
	 */
	@ExceptionHandler(UpgradeRequiredException.class)
	public ResponseEntity<Object> upgradeRequiredExceptionHandler(UpgradeRequiredException ex, WebRequest request) {
		// エラー結果作成
		ErrorResult errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP0006,
				MessageIdConstant.MESSAGE_ID_MBAP0006, null, ex.getCode());
		// ログ出力
		logger.warn(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_W, "", MessageIdConstant.MESSAGE_ID_MBAP0006));

		return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.UPGRADE_REQUIRED, request);
	}

	/**
	 * エラーハンドリング(429)
	 *
	 * @param ex      バリエーション例外
	 * @param request Webリクエスト
	 * @return エラー結果
	 */
	@ExceptionHandler(TooManyRequestsException.class)
	public ResponseEntity<Object> tooManyRequestsExceptionHandler(TooManyRequestsException ex, WebRequest request) {
		// エラークラス
		ErrorResult errorResult = new ErrorResult();

		// エラーメッセージ
		String errorMsg = null;
		boolean isBa = ex.getCode().contains(Constant.BA_ERROR_CODE_PREFIX_STRING);
		if (isBa) {
			// BA
			return baTooManyRequestsHandler(ex, request, errorResult, errorMsg);
		}
		// ABA
		// エラー結果作成
		errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP0007,
				MessageIdConstant.MESSAGE_ID_MBAP0007, null, ex.getCode());
		// ログ出力
		logger.warn(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_W, "", MessageIdConstant.MESSAGE_ID_MBAP0007));

		return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.TOO_MANY_REQUESTS, request);
	}

	private ResponseEntity<Object> baTooManyRequestsHandler(TooManyRequestsException ex, WebRequest request, ErrorResult errorResult, String errorMsg) {
		// RestClientErrorHandlerつけたBA PREFIXを削除
		String code = ex.getCode().replaceFirst(Constant.BA_ERROR_CODE_PREFIX_STRING, "");
		switch (code) {
			// エラー結果作成
			// ログ出力
			case ErrorCodeConstant.BA_ERROR_CODE_90005:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA0005, MessageIdConstant.MESSAGE_ID_MBBA0005, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA0005));	
				break;
			default:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA9998, MessageIdConstant.MESSAGE_ID_MBBA9998, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA9998));	
				break;
		}
		// HTTP応答ステータス(429)
		return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.TOO_MANY_REQUESTS, request);
	}

	/**
	 * エラーハンドリング(503)
	 *
	 * @param ex      バリエーション例外
	 * @param request Webリクエスト
	 * @return エラー結果
	 */
	@ExceptionHandler(ServiceUnavailableException.class)
	public ResponseEntity<Object> serviceUnavailableExceptionHandler(ServiceUnavailableException ex,
			WebRequest request) {
		// エラークラス
		ErrorResult errorResult = new ErrorResult();

		// エラーメッセージ
		String errorMsg = null;
		boolean isBa = ex.getCode().contains(Constant.BA_ERROR_CODE_PREFIX_STRING);

		if (isBa) {
			// BA
			return baServiceUnavailableHandler(ex, request, errorResult, errorMsg);
		}
		// ABA
		// エラー結果作成
		errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP0105,
				MessageIdConstant.MESSAGE_ID_MBAP0105, ErrorCodeConstant.LOG_LABLE_E,
				ErrorCodeConstant.ERROR_CODE_95000);
		// エラーコード設定
		errorResult.setErrorCode(MessageIdConstant.MESSAGE_ID_MBAP0105);
		// ログ出力
		logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, "", MessageIdConstant.MESSAGE_ID_MBAP0105));

		return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.SERVICE_UNAVAILABLE, request);
	}

	private ResponseEntity<Object> baServiceUnavailableHandler(ServiceUnavailableException ex, WebRequest request, ErrorResult errorResult, String errorMsg) {
		// RestClientErrorHandlerつけたBA PREFIXを削除
		String code = ex.getCode().replaceFirst(Constant.BA_ERROR_CODE_PREFIX_STRING, "");
		switch (code) {
			// エラー結果作成
			// ログ出力
			case ErrorCodeConstant.BA_ERROR_CODE_90003:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA0003, MessageIdConstant.MESSAGE_ID_MBBA0003, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA0003));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_90007:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA0007, MessageIdConstant.MESSAGE_ID_MBBA0007, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA0007));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_95000:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA5000, MessageIdConstant.MESSAGE_ID_MBBA5000, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA5000));	
				break;
			case ErrorCodeConstant.BA_ERROR_CODE_95003:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA5003, MessageIdConstant.MESSAGE_ID_MBBA5003, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA5003));	
				break;
			default:
				errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBBA9998, MessageIdConstant.MESSAGE_ID_MBBA9998, ErrorCodeConstant.LOG_LABLE_E, code);
				logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, errorMsg, MessageIdConstant.MESSAGE_ID_MBBA9998));	
				break;
		}
		// HTTP応答ステータス(503)
		return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.SERVICE_UNAVAILABLE, request);
	}

	/**
	 * エラー結果作成
	 *
	 * @param messageId メッセージID
	 * @return エラー結果
	 */
	private ErrorResult createErrorResult(String messageId) {

		// エラークラス
		ErrorResult errorResult = new ErrorResult();

		// エラーコード設定
		errorResult.setErrorCode(messageId);
		// エラーメッセージ設定
		errorResult.setErrorMessage(MessageUtils.getMessageText(messageId));

		return errorResult;
	}

	/**
	 * エラー結果作成
	 *
	 * @param messageId メッセージID
	 * @param errorCode エラーコード
	 * @return エラー結果
	 */
	private ErrorResult createErrorResultWithErrorCode(String messageId, String... errorCode) {

		// エラークラス
		ErrorResult errorResult = new ErrorResult();

		// エラーコード設定
		errorResult.setErrorCode(messageId);
		// エラーメッセージ設定
		errorResult.setErrorMessage(MessageUtils.getMessageText(messageId, errorCode));

		return errorResult;
	}

	/**
	 * メッセージ内容
	 *
	 * @param ex       例外
	 * @param message  メッセージ
	 * @param msgId    メッセージID
	 * @param logLabel ログレベル
	 * @return メッセージ
	 */
	private String splicingLogInfo(Exception ex, String logLabel, String message, String msgId) {
		// ログ出力時のタイムスタンプ
		String currentTimestamp = "";
		// 取引ID
		String transactionID = RequestHeaderContext.getInstance().getTransactionID();
		// ユーザーID
		String userID = "";
		// 端末ID
		String deviceID = "";
		// 出力箇所
		String invokerName = "";
		// メッセージID
		String messageID = msgId;
		// ログメッセージ本文
		String messageBody = message;
		// 画面ID
		String gcreenID = "";
		// イベントID
		String eventID = "";
		// 取引通番
		String transactionSeqNo = "";
		// トレースID
		String traceID = "";
		// スレッドID
		String threadID = "";
		// 重大度
		String severity = logLabel;
		// コンテキスト・ルート名
		String contextRoot = "";
		// API識別子
		String apiID = "";
		// AIFログレベル
		String aifLogLvNum = "";
		// AIFロガー名
		String aifLogType = "";
		// AIF追跡番号
		String aifTtracNo = "";
        // OS
        String os = "";
        // バージョン
        String version = "";

		// スタックエラーメッセージ情報解析
		StackTraceElement[] stacks = ex.getStackTrace();
		if (stacks != null && stacks.length > 0) {
			for (StackTraceElement stack : stacks) {
				String className = stack.getClassName();
				String methodName = stack.getMethodName();
				int lineNum = stack.getLineNumber();

				if ((className.contains("Controller") || className.contains("ServiceImpl")
						|| className.contains("LogicImpl")) && lineNum > 0) {
					invokerName = className + "#" + methodName;
					break;
				}
			}
		}

		currentTimestamp = sdf.format(new Date());

		userID = StringUtils.isBlank(RequestHeaderContext.getInstance().getUserIdToken())
				? RequestHeaderContext.getInstance().getDeviceId()
				: RequestHeaderContext.getInstance().getUserIdToken();
		deviceID = deviceMk + RequestHeaderContext.getInstance().getDeviceId().replace("-", "").toLowerCase();

		gcreenID = RequestHeaderContext.getInstance().getScreenId();
		eventID = RequestHeaderContext.getInstance().getEventID();
        os = RequestHeaderContext.getInstance().getOs();
        version = RequestHeaderContext.getInstance().getVersion();

		StringBuffer sb = new StringBuffer();
		sb.append(currentTimestamp + splitValue);
		sb.append(bankCode + splitValue);
		sb.append(userID + splitValue);
		sb.append(applicationID + splitValue);
		sb.append(clientID + splitValue);
		sb.append(deviceID + splitValue);
		sb.append(messageID + splitValue);
		sb.append(severity + splitValue);
		sb.append(contextRoot + splitValue);
		sb.append(aifLogLvNum + splitValue);
		sb.append(aifLogType + splitValue);
		sb.append(aifTtracNo + splitValue);
		sb.append(traceID + splitValue);
		sb.append(transactionID + splitValue);
		sb.append(transactionSeqNo + splitValue);
		sb.append(threadID + splitValue);
		sb.append(apiID + splitValue);
		sb.append(invokerName + splitValue);
		sb.append(messageBody + splitValue);
		sb.append(gcreenID + splitValue);
		sb.append(eventID + splitValue);
        sb.append(os + splitValue);
        sb.append(version + splitValue);

		return sb.toString();

	}

	/**
	 * SpringBoot内で用意されている例外については、ResponseEntityExceptionHandlerクラスで例外ごとに
	 * 専用のメソッドが用意されているのでそれをオーバーライドする
	 */
	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		return super.handleExceptionInternal(ex, "MethodArgumentNotValidException", null,
				HttpStatus.INTERNAL_SERVER_ERROR, request);
	}

	/**
	 * すべての例外をキャッチする
	 *
	 * @param ex      バリエーション例外
	 * @param request Webリクエスト
	 * @return エラー結果
	 */
	@ExceptionHandler(Exception.class)
	public ResponseEntity<Object> handleAllException(Exception ex, WebRequest request) {
		for (StackTraceElement elm : ex.getStackTrace())
			logger.info(Constant.STRDEF_AT + elm.toString());
		Optional.ofNullable(ex.getCause()).ifPresent(cause -> {
			logger.info(Constant.STRDEF_CAUSED_BY + cause.toString());
			Arrays.asList(cause.getStackTrace()).stream()
					.forEach(ste -> logger.info(Constant.STRDEF_AT + ste.toString()));
		});
		// エラークラス
		ErrorResult errorResult = new ErrorResult();
		// エラー結果作成
		errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP0009,
				MessageIdConstant.MESSAGE_ID_MBAP0009, ErrorCodeConstant.LOG_LABLE_E, null);
		// ログ出力
		logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, "", MessageIdConstant.MESSAGE_ID_MBAP0009));

		// HTTP応答ステータス(500)
		return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);
	}

	/**
	 * すべてのハンドリングに共通する処理を挟みたい場合はオーバーライドする
	 */
	@Override
	protected ResponseEntity<Object> handleExceptionInternal(Exception ex, Object body, HttpHeaders headers,
			HttpStatus status, WebRequest request) {
		for (StackTraceElement elm : ex.getStackTrace())
			logger.info(Constant.STRDEF_AT + elm.toString());
		Optional.ofNullable(ex.getCause()).ifPresent(cause -> {
			logger.info(Constant.STRDEF_CAUSED_BY + cause.toString());
			Arrays.asList(cause.getStackTrace()).stream()
					.forEach(ste -> logger.info(Constant.STRDEF_AT + ste.toString()));
		});
		// エラークラス
		ErrorResult errorResult = new ErrorResult();
		// エラー結果作成
		errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP0009,
				MessageIdConstant.MESSAGE_ID_MBAP0009, ErrorCodeConstant.LOG_LABLE_E, null);
		// ログ出力
		logger.error(splicingLogInfo(ex, ErrorCodeConstant.LOG_LABLE_E, "", MessageIdConstant.MESSAGE_ID_MBAP0009));

		// HTTP応答ステータス(500)
		return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);
	}
}

package jp.co.jsbank.mobile.bff.common.exception;

/**
 * データなし例外。
 *
 */
public class BadRequestException extends BusinessException {

    private static final long serialVersionUID = -1L;

    /**
     * BadRequestExceptionのコンスタント。
     * 
     * @param errorCode エラーコード
     * @param errorMsg エラーメッセージ
     */
    public BadRequestException(String errorCode, String errorMsg) {
        super(errorCode, errorMsg);
    }
}

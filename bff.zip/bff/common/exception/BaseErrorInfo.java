package jp.co.jsbank.mobile.bff.common.exception;

/**
 * エラーベースクラス
 */
public interface BaseErrorInfo {
    
    /**
     *  エラーコード取得
     *  
     * @return エラーコード
     */
    Integer getResultCode();

    /**
     * エラーメッセージ取得
     * 
     * @return エラーメッセージ
     */
    String getResultMsg();
}

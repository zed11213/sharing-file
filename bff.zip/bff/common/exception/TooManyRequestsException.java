package jp.co.jsbank.mobile.bff.common.exception;

/**
 * データなし例外。
 *
 */
public class TooManyRequestsException extends BusinessException {

    private static final long serialVersionUID = -1L;

    /**
     * TooManyRequestsExceptionのコンスタント。
     * 
     * @param errorMsg エラーメッセージ
     */
    public TooManyRequestsException(String errorMsg) {
        super("429", errorMsg);
    }
}

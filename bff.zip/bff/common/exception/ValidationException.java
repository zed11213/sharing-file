package jp.co.jsbank.mobile.bff.common.exception;

/**
 * バリエーション例外。
 *
 */
public class ValidationException extends BusinessException {

    private static final long serialVersionUID = -1L;

    /**
     * ValidationExceptionのコンスタント。
     * 
     * @param name 項目名
     */
    public ValidationException(String name) {

        super("400", name);
    }
}

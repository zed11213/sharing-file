package jp.co.jsbank.mobile.bff.common.exception;

import java.io.IOException;
import java.util.Scanner;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.client.ResponseErrorHandler;

/**
 * EkycRestTemplate例外ハンドラクラス。
 */
@Component
public class EkycClientErrorHandler implements ResponseErrorHandler {
    /**
     * ログ出力のためのクラス
     */
    private static final Logger logger = LoggerFactory.getLogger(EkycClientErrorHandler.class);

	@Override
	public boolean hasError(ClientHttpResponse response) throws IOException {

		return (response.getStatusCode().series() == HttpStatus.Series.CLIENT_ERROR
				|| response.getStatusCode().series() == HttpStatus.Series.SERVER_ERROR);
	}

	@SuppressWarnings("resource")
	@Override
	public void handleError(ClientHttpResponse response) throws IOException {

		// エラーコード取得
		Scanner scanner = new Scanner(response.getBody()).useDelimiter("\\A");
		String errorResponseStr = scanner.hasNext() ? scanner.next() : "";
        int statusCode = response.getRawStatusCode();

		String errorCode = String.valueOf(statusCode);
		String errorMsg = errorResponseStr;

        logger.debug("LiquidEkyc errorResponse -> errorCode:" + errorCode + ", errorMsg: " + errorMsg);
     
		if (response.getStatusCode().series() == HttpStatus.Series.CLIENT_ERROR
				|| response.getStatusCode().series() == HttpStatus.Series.SERVER_ERROR) {
			switch (response.getStatusCode()) {
			case BAD_REQUEST:
				// HTTP応答ステータス(400)
				throw new BadRequestException(errorCode, errorMsg);
			case UNAUTHORIZED:
				// HTTP応答ステータス(401)
				throw new UnauthorizedException(errorMsg);
			case FORBIDDEN:
				// HTTP応答ステータス(403)
				throw new ForbiddenException(errorMsg);
			case NOT_FOUND:
				// HTTP応答ステータス(404)
				throw new NotFoundException(errorMsg);
			case UPGRADE_REQUIRED:
				// HTTP応答ステータス(426)
				throw new UpgradeRequiredException(errorMsg);
			case TOO_MANY_REQUESTS:
				// HTTP応答ステータス(429)
				throw new TooManyRequestsException(errorMsg);
			case INTERNAL_SERVER_ERROR:
				// HTTP応答ステータス(500)
				throw new InternalServerErrorException(errorCode, errorMsg);
			case SERVICE_UNAVAILABLE:
				// HTTP応答ステータス(503)
				throw new ServiceUnavailableException(errorMsg);
			default:
				// なし
			}
		}
	}
}

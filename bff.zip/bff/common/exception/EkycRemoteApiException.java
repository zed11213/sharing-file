package jp.co.jsbank.mobile.bff.common.exception;

import jp.co.jsbank.mobile.bff.common.EkycApiErrorCode;

import lombok.Getter;

/**
 * EKyc Error exception
 */
@Getter
public class EkycRemoteApiException extends RuntimeException {

    private final int httpStatus;
    private final EkycApiErrorCode errorCode; 
    private final String dynamicRawCode;         
    private final String dynamicRawMessage;      

    /**
     * 
     * @param httpStatus 
     * @param errorCode          
     * @param dynamicRawCode     
     * @param dynamicRawMessage  
     */
    public EkycRemoteApiException(int httpStatus, EkycApiErrorCode errorCode, String dynamicRawCode, String dynamicRawMessage) {
        super("Ekyc error: [" + errorCode.getDescription() + "], code: " + dynamicRawCode +" reason: " + dynamicRawMessage );
        this.httpStatus = httpStatus;
        this.errorCode = errorCode;
        this.dynamicRawCode = dynamicRawCode;
        this.dynamicRawMessage = dynamicRawMessage;
    }

    /**
     * 
     * @param httpStatus 
     * @param errorCode      
     * @param rawMessage    
     */
    public EkycRemoteApiException(int httpStatus, EkycApiErrorCode errorCode, String rawMessage) {
        super(String.format("Ekyc error: [%s], reason: %s", errorCode.getDescription(), rawMessage));
        this.httpStatus = httpStatus;
        this.errorCode = errorCode;
        this.dynamicRawCode = errorCode.getRawCode();
        this.dynamicRawMessage = rawMessage;
    }
}


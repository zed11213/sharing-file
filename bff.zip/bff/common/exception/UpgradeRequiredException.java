package jp.co.jsbank.mobile.bff.common.exception;

/**
 * データなし例外。
 *
 */
public class UpgradeRequiredException extends BusinessException {

    private static final long serialVersionUID = -1L;

    /**
     * UpgradeRequiredExceptionのコンスタント。
     * 
     * @param errorMsg エラーメッセージ
     */
    public UpgradeRequiredException(String errorMsg) {
        super("426", errorMsg);
    }
}

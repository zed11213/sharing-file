package jp.co.jsbank.mobile.bff.common.exception;

import java.io.IOException;
import java.util.Arrays;
import java.util.Optional;
import java.util.Scanner;

import org.junit.platform.commons.util.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.client.ResponseErrorHandler;
import com.alibaba.fastjson.JSONObject;

import jp.co.jsbank.mobile.bff.common.Constant;
import jp.co.jsbank.mobile.bff.common.MessageIdConstant;
import jp.co.jsbank.mobile.bff.dto.aba.CommonHeaderAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CommonHeaderBaResponseDto;

/**
 * RestTemplate例外ハンドラクラス。
 */
@Component
public class RestClientErrorHandler implements ResponseErrorHandler {
    /**
     * ログ出力のためのクラス
     */
    private static final Logger logger = LoggerFactory.getLogger(RestClientErrorHandler.class);

	@Override
	public boolean hasError(ClientHttpResponse response) throws IOException {

		return (response.getStatusCode().series() == HttpStatus.Series.CLIENT_ERROR
				|| response.getStatusCode().series() == HttpStatus.Series.SERVER_ERROR);
	}

	@SuppressWarnings("resource")
	@Override
	public void handleError(ClientHttpResponse response) throws IOException {

		// エラーコード取得
		Scanner scanner = new Scanner(response.getBody()).useDelimiter("\\A");
		String errorResponseStr = scanner.hasNext() ? scanner.next() : "";

		// BA独自プロパティでレスポンスがBAかABAかを判断
		boolean isBa = errorResponseStr.contains("actionCode") || errorResponseStr.contains("backendErrorCode") || errorResponseStr.contains("backendErrorMessage");
		CommonHeaderBaResponseDto baErrorReponse = null;
		CommonHeaderAbaResponseDto errorResponse = null;
		try {
			if (isBa) {
				// BA
				baErrorReponse = JSONObject.parseObject(errorResponseStr, CommonHeaderBaResponseDto.class);
			} else if (!StringUtils.isBlank(errorResponseStr)) {
				// ABA
				errorResponse = JSONObject.parseObject(errorResponseStr, CommonHeaderAbaResponseDto.class);
			} else {
				// エラーコードはnullの場合
				throw new InternalServerErrorException(MessageIdConstant.MESSAGE_ID_MBAP0009, "エラーコードなし");
			}
		} catch (Exception e) {
			for (StackTraceElement elm : e.getStackTrace())
				logger.info(Constant.STRDEF_AT + elm.toString());
			Optional.ofNullable(e.getCause()).ifPresent(cause -> {
				logger.info(Constant.STRDEF_CAUSED_BY + cause.toString());
				Arrays.asList(cause.getStackTrace()).stream()
						.forEach(ste -> logger.info(Constant.STRDEF_AT + ste.toString()));
			});
			// JSONObject変換に失敗した場合
			throw new InternalServerErrorException(MessageIdConstant.MESSAGE_ID_MBAP0009, "エラーレスポンス変換失敗");
		}


		String errorCode = null;
		String errorMsg = null;
		if (isBa && baErrorReponse != null) {
			// BAとABAのエラーコードが一部かぶって、GlobalExceptionHandlerがハンドリングできるように、一時的に"BA--"をつける。また、ハンドリングの際に外す。
			errorCode = Constant.BA_ERROR_CODE_PREFIX_STRING + baErrorReponse.getCommonResponseHeader().getErrorCode();
			errorMsg = baErrorReponse.getCommonResponseHeader().getBackendErrorMessage();
			logger.debug("BA errorResponse -> errorCode:" + errorCode + ", errorMsg: " + errorMsg);

		} else if (errorResponse != null) {
			errorCode = errorResponse.getCommonResponseHeader().getErrorCode();
			errorMsg = errorResponse.getCommonResponseHeader().getErrorMessage();
			logger.debug("ABA errorResponse -> errorCode:" + errorCode + ", errorMsg: " + errorMsg);
		}

		if (response.getStatusCode().series() == HttpStatus.Series.CLIENT_ERROR
				|| response.getStatusCode().series() == HttpStatus.Series.SERVER_ERROR) {
			switch (response.getStatusCode()) {
			case BAD_REQUEST:
				// HTTP応答ステータス(400)
				throw new BadRequestException(errorCode, errorMsg);
			case UNAUTHORIZED:
				// HTTP応答ステータス(401)
				throw new UnauthorizedException(errorMsg);
			case FORBIDDEN:
				// HTTP応答ステータス(403)
				throw new ForbiddenException(errorMsg);
			case NOT_FOUND:
				// HTTP応答ステータス(404)
				throw new NotFoundException(errorMsg);
			case UPGRADE_REQUIRED:
				// HTTP応答ステータス(426)
				throw new UpgradeRequiredException(errorMsg);
			case TOO_MANY_REQUESTS:
				// HTTP応答ステータス(429)
				throw new TooManyRequestsException(errorMsg);
			case INTERNAL_SERVER_ERROR:
				// HTTP応答ステータス(500)
				throw new InternalServerErrorException(errorCode, errorMsg);
			case SERVICE_UNAVAILABLE:
				// HTTP応答ステータス(503)
				throw new ServiceUnavailableException(errorMsg);
			default:
				// なし
			}
		}
	}
}

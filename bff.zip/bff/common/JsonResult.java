package jp.co.jsbank.mobile.bff.common;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSONObject;

import jp.co.jsbank.mobile.bff.common.logger.LoggingAspects;
import jp.co.jsbank.mobile.bff.common.util.DecryptorHelper;
import jp.co.jsbank.mobile.bff.config.Config;
import lombok.Data;

/**
 * 結果データクラス
 */
@Data
public class JsonResult {

    /**
     * レスポンスコード
     */
    private Integer statusCode;
    /**
     * ログ出力のためのクラス
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(LoggingAspects.class);

    /**
     * レスポンス結果
     */
    private Object resultDto;

    /**
     * 正常に戻りました
     *
     * @param data データ
     * @return JsonResult
     */
    public static String success(Object data) {
        JsonResult jsonResult = new JsonResult();
        jsonResult.setStatusCode(CommonEnum.SUCCESS.getResultCode());
        jsonResult.setResultDto(data);

		String active = Config.getActive();
		if (StringUtils.isNotBlank(active) && "test".equals(active)) {
			// ログ出力
			LOGGER.info(splicingLogInfo(ErrorCodeConstant.LOG_LABLE_I, jsonResult.toString(), ""));
		}

        String commonKey = RequestHeaderContext.getInstance().getJagBearerToken();
        String result = null;
        try {
            result = DecryptorHelper.encrypt(JSONObject.toJSONString(jsonResult), commonKey);
        } catch (Exception e) {
            e.printStackTrace();
        }

        return result;
    }

    /**
     * 異常に戻りました
     *
     * @param code コード
     * @param data データ
     * @return JsonResult
     */
    public static JsonResult error(Integer code, Object data) {
        JsonResult result = new JsonResult();
        result.setStatusCode(code);
        result.setResultDto(data);
        return result;
    }
    /**
     * メッセージ内容
     *
     * @param ex 例外
     * @param message メッセージ
     * @param msgId メッセージID
     * @param logLabel ログレベル
     * @return メッセージ
     */
    private static String splicingLogInfo( String logLabel, String message, String msgId) {

        // フォーマット
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS z");

        // 金融機関コード
        String bankCode = "1344";

        // 端末識別するID
        String deviceMk = "sm";

         // 区切りの文字列
        String splitValue = " ";

        // クライアントID
        String clientID = "010000";

         // アプリケーションID
        String applicationID = "jsbapp01";

        // ログ出力時のタイムスタンプ
        String currentTimestamp = "";

        // 取引ID
        String transactionID = RequestHeaderContext.getInstance().getTransactionID();
        // ユーザーID
        String userID = "";
        // 端末ID
        String deviceID = "";
        // 出力箇所
        String invokerName = "";
        // メッセージID
        String messageID = msgId;
        // ログメッセージ本文
        String messageBody = message;
        // 画面ID
        String gcreenID = "";
        // イベントID
        String eventID = "";
        // 取引通番
        String transactionSeqNo = "";
        // トレースID
        String traceID = "";
        // スレッドID
        String threadID = "";
        // 重大度
        String severity = logLabel;
        // コンテキスト・ルート名
        String contextRoot = "";
        // API識別子
        String apiID = "";
        // AIFログレベル
        String aifLogLvNum = "";
        // AIFロガー名
        String aifLogType = "";
        // AIF追跡番号
        String aifTtracNo = "";
        // OS
        String os = "";
        // バージョン
        String version = "";

        // スタックエラーメッセージ情報解析
       invokerName = "JsonResult" + "#" + "";


        currentTimestamp = sdf.format(new Date());

        userID = StringUtils.isBlank(RequestHeaderContext.getInstance().getUserIdToken())
                ? RequestHeaderContext.getInstance().getDeviceId()
                : RequestHeaderContext.getInstance().getUserIdToken();
        deviceID = deviceMk + RequestHeaderContext.getInstance().getDeviceId().replace("-", "").toLowerCase();

        gcreenID = RequestHeaderContext.getInstance().getScreenId();
        eventID = RequestHeaderContext.getInstance().getEventID();
        os = RequestHeaderContext.getInstance().getOs();
        version = RequestHeaderContext.getInstance().getVersion();

        StringBuffer sb = new StringBuffer();
        sb.append(currentTimestamp + splitValue);
        sb.append(bankCode + splitValue);
        sb.append(userID + splitValue);
        sb.append(applicationID + splitValue);
        sb.append(clientID + splitValue);
        sb.append(deviceID + splitValue);
        sb.append(messageID + splitValue);
        sb.append(severity + splitValue);
        sb.append(contextRoot + splitValue);
        sb.append(aifLogLvNum + splitValue);
        sb.append(aifLogType + splitValue);
        sb.append(aifTtracNo + splitValue);
        sb.append(traceID + splitValue);
        sb.append(transactionID + splitValue);
        sb.append(transactionSeqNo + splitValue);
        sb.append(threadID + splitValue);
        sb.append(apiID + splitValue);
        sb.append(invokerName + splitValue);
        sb.append(messageBody + splitValue);
        sb.append(gcreenID + splitValue);
        sb.append(eventID + splitValue);
        sb.append(os + splitValue);
        sb.append(version + splitValue);

        return sb.toString();

    }
}

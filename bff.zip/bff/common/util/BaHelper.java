package jp.co.jsbank.mobile.bff.common.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import io.micrometer.core.instrument.util.StringUtils;

import jp.co.jsbank.mobile.bff.common.code.AccountTypeCode;
import jp.co.jsbank.mobile.bff.logic.SignUpLogic;
import jp.co.jsbank.mobile.bff.dto.ba.*;

/**
 * BA APIアクセス ツールクラス
 */
public class BaHelper {
    /**
     * ログ出力のためのクラス
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(BaHelper.class);

    public static CifInquiryBaResponseDto CifInquiry(SignUpLogic signUpLogic, String accountType, String branchNumber, String accountNumber, String subNo) {
        String cifNumber = "";
        CifInquiryBaResponseDto result = null;
        if (AccountTypeCode.FIXED_TERM_DEPOSIT.equals(accountType)) {
            // 定期預金
            FixedTermDepositBalanceBaRequestDto baRequestDto = new FixedTermDepositBalanceBaRequestDto();
            baRequestDto.setAccountType(AccountTypeCode.FIXED_TERM_DEPOSIT);
            baRequestDto.setAccountNumber(accountNumber);
            baRequestDto.setBranchNumber(branchNumber);
            baRequestDto.setSubNo(subNo);
            FixedTermDepositBalanceBaResponseDto baResponseDto = signUpLogic.baGetFixedTermDepositBalance(baRequestDto);
            cifNumber = baResponseDto.getCifNumber();
        } else if (AccountTypeCode.FIXED_TERM_FIXED.equals(accountType)) {
            // 定期積金
            FixedInstallmentTimeDepositBalanceBaRequestDto baRequestDto = new FixedInstallmentTimeDepositBalanceBaRequestDto();
            baRequestDto.setAccountType(AccountTypeCode.FIXED_TERM_FIXED);
            baRequestDto.setAccountNumber(accountNumber);
            baRequestDto.setBranchNumber(branchNumber);
            baRequestDto.setSubNo(subNo);
            FixedInstallmentTimeDepositBalanceBaResponseDto baResponseDto = signUpLogic.baGetFixedInstallmentTimeDepositBalance(baRequestDto);
            cifNumber = baResponseDto.getCifNumber();
        } else {
            LOGGER.info("BaHelper::CifInquiry -> Error:accountType is invalid.");
        }

        if (StringUtils.isBlank(cifNumber)) {
            LOGGER.info("BaHelper::CifInquiry -> Error:cifNumber query failed.");
        } else {
            LOGGER.info("BaHelper::CifInquiry -> start.");
            CifInquiryBaRequestDto baRequestDto = new CifInquiryBaRequestDto();
            baRequestDto.setBranchNumber(branchNumber);
            baRequestDto.setCifNumber(cifNumber);
            result = signUpLogic.baCifInquiry(baRequestDto);
            LOGGER.info("BaHelper::CifInquiry -> end.");
        }
        return result;
    }
}

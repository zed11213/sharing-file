package jp.co.jsbank.mobile.bff.common.util;


public class NameParser {

    public static class ParsedName {
        public final String lastName;  // 姓
        public final String firstName; // 名

        public ParsedName(String lastName, String firstName) {
            this.lastName = lastName;
            this.firstName = firstName;
        }
    }

    public static ParsedName parseJapaneseName(String rawName) {
        // 1. null または 空文字のチェック（安全性の担保）
        if (rawName == null || rawName.trim().isEmpty()) {
            return new ParsedName("", "");
        }

        // 2. 文字列の前後にある「半角・全角すべてのスペース」を完全にトリム
        // ※ Javaの通常の trim() は全角スペースを除去できないため、正規表現で置換
        String cleanedName = rawName.replaceAll("^[ 　]+|[ 　]+$", "");

        // 3. 連続する「半角・全角スペース」を区切り文字として、最大2つに分割
        // 正規表現 [ 　]+ は、半角スペースと全角スペースの1回以上の連続を意味します
        String[] parts = cleanedName.split("[ 　]+", 2);

        // 4. 分割結果に応じたデータ割り当て
        if (parts.length == 2) {
            // 最も多いパターン：「姓[スペース]名」
            return new ParsedName(parts[0], parts[1]);
        } else if (parts.length == 1 && !parts[0].isEmpty()) {
            // イレギュラー：スペースがない場合（例：「山田太郎」）
            // 日本人の名前はどこが区切りか機械判別できないため、便宜上すべて「姓」に入れるか、仕様に合わせて調整
            return new ParsedName(parts[0], ""); 
        }

        return new ParsedName("", "");
    }

}


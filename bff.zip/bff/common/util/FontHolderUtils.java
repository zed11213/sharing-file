package jp.co.jsbank.mobile.bff.common.util;

import java.awt.Font;
import java.io.InputStream;

public class FontHolderUtils {

    private static final Font BASE_FONT = loadFont();

    private static Font loadFont() {

        try (InputStream inputStream = FontHolderUtils.class
                .getClassLoader()
                .getResourceAsStream(
                        "fonts/NotoSansJP-Regular.ttf")) {

            return Font.createFont(Font.TRUETYPE_FONT, inputStream);

        } catch (Exception e) {
            System.out.println("load error");
            throw new RuntimeException(e);
        }
    }

    public static Font getFont(float size) {
        return BASE_FONT.deriveFont(size);
    }
}

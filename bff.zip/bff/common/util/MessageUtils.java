package jp.co.jsbank.mobile.bff.common.util;

import java.util.Locale;
import org.springframework.context.MessageSource;
import org.springframework.context.support.ResourceBundleMessageSource;
import lombok.extern.slf4j.Slf4j;

/**
 * メッセージ取得ユティリティ
 */
@Slf4j
public class MessageUtils {

    private static final MessageSource MESSAGE_SOOURCE = messageSource();

    /**
     * メッセージソース作成
     * 
     * @return メッセージソース
     */
    private static MessageSource messageSource() {
        ResourceBundleMessageSource msgSource = new ResourceBundleMessageSource();
        msgSource.setBasenames("config/messages");
        msgSource.setDefaultEncoding("UTF-8");
        msgSource.setDefaultLocale(Locale.JAPAN);
        return msgSource;
    }

    /**
     * メッセージを取得する
     * 
     * @param messageId メッセージID
     * @param args 引数
     * @return メッセージ情報
     */
    public static String getMessageText(String messageId, String... args) {
        String result = messageId;
        try {
            result = MESSAGE_SOOURCE.getMessage(messageId, args, Locale.JAPAN);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return result;
    }
}

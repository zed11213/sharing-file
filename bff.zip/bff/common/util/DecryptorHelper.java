package jp.co.jsbank.mobile.bff.common.util;

import java.io.InputStream;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ibm.cloud.objectstorage.util.IOUtils;

/**
 * 暗号化ヘルプクラス。
 * 
 */
public class DecryptorHelper {

    /**
     * アルゴリズム/ブロックモード/パディング方式
     */
    private static final String ALGORITHM = "AES/ECB/PKCS5Padding";

    /**
     * ログ
     */
    private static Logger logger = LoggerFactory.getLogger(DecryptorHelper.class);

    /**
     * コンストラクタ
     */
    private DecryptorHelper() {
        super();
    }

    /**
     * 公開鍵で暗号化する
     * 
     * @param publicKeyStr 公開鍵
     * @param str 暗号化したい対象
     * @return 暗号化した対象
     */
    public static byte[] encrypterWithPublicKey(String publicKeyStr, String str) {

        byte[] encryptedWithPublicKey = null;

        //
        try {
            // 指定された鍵仕様(鍵データ)から公開鍵オブジェクトを生成する
            PublicKey publicKey = KeyFactory.getInstance("RSA")
                    .generatePublic(new X509EncodedKeySpec(Base64.getDecoder().decode(publicKeyStr)));

            // 鍵を使用してこの暗号を初期化する
            Cipher encrypterWithPublicKey = Cipher.getInstance("RSA");
            encrypterWithPublicKey.init(Cipher.ENCRYPT_MODE, publicKey);

            // 公開鍵で暗号化する
            encryptedWithPublicKey = encrypterWithPublicKey.doFinal(str.getBytes());
        } catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException | IllegalBlockSizeException
                | BadPaddingException | InvalidKeySpecException e) {
            logger.info("公開鍵で暗号化失敗しました。");
        }
        return encryptedWithPublicKey;
    }

    /**
     * 暗号化メソッド
     *
     * @param encryptStr 暗号化する文字列
     * @param jagBearerToken 認可トークン
     * @return 暗号化文字列
     */
    public static String encrypt(String encryptStr, String jagBearerToken) throws Exception {

        Cipher encrypter = Cipher.getInstance(ALGORITHM);
        encrypter.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(jagBearerToken.getBytes(), "AES"));
        byte[] byteEncryptStr = encrypter.doFinal(encryptStr.getBytes());

        return new String(Base64.getEncoder().encode(byteEncryptStr));
    }

    /**
     * 復号化メソッド
     *
     * @param encryptedStr 復号化する文字列
     * @param jagBearerToken 認可トークン
     * @return 復号化文字列
     */
    public static String decrypt(String encryptedStr, String jagBearerToken) throws Exception {

        Cipher decrypter = Cipher.getInstance(ALGORITHM);
        decrypter.init(Cipher.DECRYPT_MODE, new SecretKeySpec(jagBearerToken.getBytes(), "AES"));
        
        byte[] byteEncryptedStr = Base64.getDecoder().decode(encryptedStr.replace("\r\n", ""));

        return new String(decrypter.doFinal(byteEncryptedStr));
    }

    /**
     * 復号化メソッド
     *
     * @param encryptedStr 復号化する文字列
     * @param jagBearerToken 認可トークン
     * @return 復号化文字列
     */
    public static byte[] decryptToBytes(String encryptedStr, String jagBearerToken) throws Exception {

        Cipher decrypter = Cipher.getInstance(ALGORITHM);
        decrypter.init(Cipher.DECRYPT_MODE, new SecretKeySpec(jagBearerToken.getBytes(), "AES"));
        byte[] byteEncryptedStr = Base64.getDecoder().decode(encryptedStr.replace("\r\n", ""));

        return byteEncryptedStr;
    }

    /**
     * base64変換
     *
     * @param inputStream inputStream
     * @return base64
     */
    public static String toBase64(InputStream inputStream) {
        try {
            // toBase64
            byte[] bytes = IOUtils.toByteArray(inputStream);
            return Base64.getEncoder().encodeToString(bytes);
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }
}

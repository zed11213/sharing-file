package jp.co.jsbank.mobile.bff.common.util;

import jp.co.jsbank.mobile.bff.common.EkycIdDocumentTypeCode;
import jp.co.jsbank.mobile.bff.common.EkycIdDocumentTypeCode.BffDocumentType;
import jp.co.jsbank.mobile.bff.dto.liquidekyc.EkycIdDocumentInformationResponseDto;
import jp.co.jsbank.mobile.bff.dto.liquidekyc.EkycVerificationJoinedData;
import jp.co.jsbank.mobile.bff.dto.liquidekyc.EkycVerificationResultResponseDto;
import jp.co.jsbank.mobile.bff.dto.liquidekyc.OptionalVerificationResultDto;

import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public final class GenerateVerificationResultUtils {

    private static final DateTimeFormatter INPUT_FORMATTER = DateTimeFormatter.ofPattern("yyyyMMdd");

    private static final DateTimeFormatter OUTPUT_FORMATTER = DateTimeFormatter.ofPattern("yyyy年MM月dd日");

    private static Logger logger = LoggerFactory.getLogger(GenerateVerificationResultUtils.class);

    private GenerateVerificationResultUtils() {
    }

    public static String createBase64WithVerification(EkycVerificationJoinedData result, String apiInterface) {
        logger.info("ekyc createBase64WithVerification start");

        if (Objects.isNull(result)) {
            logger.info("ekyc result is null");
            return null;
        }

        EkycIdDocumentInformationResponseDto idDocumentInformation = result.getIdDocumentInformation();
        EkycVerificationResultResponseDto verificationResult = result.getVerificationResult();

        if (Objects.isNull(idDocumentInformation) || Objects.isNull(verificationResult)) {
            logger.info("ekyc idDocumentInformation is null");
            return null;
        }

        String text = createImageTextWith(idDocumentInformation, verificationResult, apiInterface);

        ImgBuildParameters param = ImgBuildParameters.builder()
                .fontSize(18)
                .width(640)
                .height(440)
                .build();

        String base64 = GenerateImgUtils.textToJpegBase64(text, param);

        logger.info("ekyc createBase64WithVerification end");
        return base64;
    }

    private static String createImageTextWith(EkycIdDocumentInformationResponseDto info,
            EkycVerificationResultResponseDto verification, String apiInterface) {

        logger.info("ekyc createImageTextWith start");

        String sex = info.getSex();

        StringBuilder sbuilder = new StringBuilder();

        // Ekycの書類コードがBFFの書類コードに変換すること
        String ekycIdDocumentType = info.getIdDocumentType();
        BffDocumentType documentType = EkycIdDocumentTypeCode.getBffDocumentType(ekycIdDocumentType);

        sbuilder.append("カード種別: " + documentType.getName() + "(" + apiInterface + ") ");
        sbuilder.append("\n");

        sbuilder.append("氏名: " + info.getName());
        sbuilder.append("\n");

        sbuilder.append("生年月日: " + formatDate(info.getBirthday()));
        sbuilder.append("\n");

        sbuilder.append("住所: " + info.getAddress());
        sbuilder.append("\n");

        if (sex != null && !sex.isBlank()) {
            sbuilder.append("性別: " + getSexString(sex));
            sbuilder.append("\n");
        }

        String today = LocalDate.now().format(OUTPUT_FORMATTER);
        sbuilder.append("取得日: " + today);
        sbuilder.append("\n");

        OptionalVerificationResultDto verificationResult = verification.getOptionalVerificationResult();
        String injectCheckResult = getResultString(verificationResult.getInjectionAttackVerification());
        sbuilder.append("インジェクション攻撃による申請判定結果: " + injectCheckResult);
        sbuilder.append("\n");

        String faceCheckResult = getResultString(verificationResult.getReuseFaceVerification());
        sbuilder.append("顔の使い回し判定結果: " + faceCheckResult);
        sbuilder.append("\n");

        String personalCheckResult = getResultString(verificationResult.getReuseIdentificationInformationVerification());
        sbuilder.append("本⼈特定事項の使い回し判定結果: " + personalCheckResult);
        sbuilder.append("\n");

        String warningListCheckResult = getResultString(verificationResult.getWarningListIdentificationInformationVerification());
        sbuilder.append("警告リスト（本⼈特定事項）判定結果: " + warningListCheckResult);
        sbuilder.append("\n");

        String warningFaceResult = getResultString(verificationResult.getWarningListFaceVerification());
        sbuilder.append("警告リスト（顔）判定結果: " + warningFaceResult);

        logger.info("ekyc createImageTextWith end");
        return sbuilder.toString();
    }

    private static String formatDate(String date) {

        if (date == null || date.isBlank()) {
            return "";
        }

        if (!date.matches("\\d{8}")) {
            return date;
        }

        try {
            LocalDate localDate = LocalDate.parse(date, INPUT_FORMATTER);
            return localDate.format(OUTPUT_FORMATTER);
        } catch (DateTimeParseException e) {
            return date;
        }

    }

    private static String getSexString(String value) {
        if (value == null) {
            return "";
        }

        switch (value) {
            case "1":
                return "男性";
            case "2":
                return "女性";        
            default:
                return value;
        }
    }

    private static String getResultString(String value) {
        if (value == null) {
            return "ー";
        }

        switch (value) {
            case "1":
                return "OK";
            case "2":
                return "NG";
            case "3":
                return "ー";
            case "4":
                return "実施待ち";
            default:
                return "";
        }
    }

}

// カード種別：マイナンバーカード
// 氏名：公的 花子
// 生年月日：1999年4月1日
// 住所：東京都清瀬市旭が丘１－１－１
// 取得日：2025年10月01日
// インジェクション攻撃による申請判定結果：NG
// 顔の使い回し判定結果：検知あり（自社・他社データ）
// 本⼈特定事項の使い回し判定結果：検知あり（自社・他社データ）
// 警告リスト（本⼈特定事項）判定結果：検知あり（自社・他社データ）
// 警告リスト（顔）判定結果：検知あり（自社・他社データ）

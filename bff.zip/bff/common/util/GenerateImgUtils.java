package jp.co.jsbank.mobile.bff.common.util;

import javax.imageio.ImageIO;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class GenerateImgUtils {

    private static Logger logger = LoggerFactory.getLogger(GenerateVerificationResultUtils.class);

    private GenerateImgUtils() {
    }

    public static String textToJpegBase64(String text, ImgBuildParameters param) {
        logger.info("ekyc textToJpegBase64 start");

        try {

            BufferedImage image = new BufferedImage(
                    param.getWidth(),
                    param.getHeight(),
                    BufferedImage.TYPE_INT_RGB);

            Graphics2D g = image.createGraphics();

            g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

            g.setColor(param.getBackgroundColor());

            g.fillRect(0, 0, param.getWidth(), param.getHeight());

            g.setFont(param.getFont());

            g.setColor(param.getTextColor());

            FontMetrics metrics = g.getFontMetrics();

            List<String> lines = wrapText(text, metrics, param);

            int y = param.getPaddingTop() + metrics.getAscent();

            for (String line : lines) {

                g.drawString(line, param.getPaddingLeft(), y);

                y += metrics.getHeight() + param.getLineSpacing();
            }

            g.dispose();

            ByteArrayOutputStream output = new ByteArrayOutputStream();

            ImageIO.write(image, "jpg", output);

            logger.info("ekyc textToJpegBase64 end");

            return Base64.getEncoder().encodeToString(output.toByteArray());

        } catch (Exception e) {
            logger.info("ekyc textToJpegBase64 failed");

            throw new RuntimeException("画像作成失敗しました", e);
        }

    }

    private static List<String> wrapText(String text, FontMetrics metrics, ImgBuildParameters param) {

        List<String> result = new ArrayList<>();

        String[] rows = text.split("\n");

        for (String row : rows) {

            if (!param.isAutoWrap()) {

                result.add(row);
                continue;
            }

            StringBuilder line = new StringBuilder();

            for (char c : row.toCharArray()) {
                line.append(c);

                if (metrics.stringWidth(line.toString()) > param.getWidth() - param.getPaddingLeft() - 20) {
                    result.add(line.substring(0, line.length() - 1));
                    line = new StringBuilder();
                    line.append(c);
                }
            }

            if (line.length() != 0) {
                result.add(line.toString());
            }
        }

        return result;
    }

    public static String toJpegDataUrl(String base64) {

        return "data:image/jpeg;base64," + base64;

    }

}

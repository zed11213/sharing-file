package jp.co.jsbank.mobile.bff.common.util;

import java.awt.Color;
import java.awt.Font;

public class ImgBuildParameters {

    // width
    private int width = 600;

    // height
    private int height = 400;

    // font
    private Font font = FontHolderUtils.getFont(18);

    // font color
    private Color textColor = Color.BLACK;

    // background color
    private Color backgroundColor = Color.WHITE;

    // left padding
    private int paddingLeft = 20;

    // toppadding
    private int paddingTop = 20;

    // line space
    private int lineSpacing = 10;

    // auto wrap
    private boolean autoWrap = true;

    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {

        private final ImgBuildParameters param = new ImgBuildParameters();

        public Builder width(int width) {
            param.width = width;
            return this;
        }

        public Builder height(int height) {
            param.height = height;
            return this;
        }

        public Builder font(Font font) {
            param.font = font;
            return this;
        }

        public Builder fontSize(int size) {
            param.font = param.font.deriveFont((float) size);
            return this;
        }

        public Builder textColor(Color color) {
            param.textColor = color;
            return this;
        }

        public Builder backgroundColor(Color color) {
            param.backgroundColor = color;
            return this;
        }

        public Builder paddingLeft(int padding) {
            param.paddingLeft = padding;
            return this;
        }

        public Builder paddingTop(int padding) {
            param.paddingTop = padding;
            return this;
        }

        public Builder lineSpacing(int spacing) {
            param.lineSpacing = spacing;
            return this;
        }

        public Builder autoWrap(boolean autoWrap) {
            param.autoWrap = autoWrap;
            return this;
        }

        public ImgBuildParameters build() {
            return param;
        }
    }

    // getter

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public Font getFont() {
        return font;
    }

    public Color getTextColor() {
        return textColor;
    }

    public Color getBackgroundColor() {
        return backgroundColor;
    }

    public int getPaddingLeft() {
        return paddingLeft;
    }

    public int getPaddingTop() {
        return paddingTop;
    }

    public int getLineSpacing() {
        return lineSpacing;
    }

    public boolean isAutoWrap() {
        return autoWrap;
    }
}

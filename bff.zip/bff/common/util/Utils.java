package jp.co.jsbank.mobile.bff.common.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.Set;
import java.util.HashSet;

import org.apache.commons.lang3.StringUtils;

import jp.co.jsbank.mobile.bff.common.Constant;
import jp.co.jsbank.mobile.bff.common.GetIdByTokenHandler;
import jp.co.jsbank.mobile.bff.common.RequestHeaderContext;
import jp.co.jsbank.mobile.bff.common.builder.ParameterBuilder;
import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import jp.co.jsbank.mobile.bff.common.code.LotteryResultsCode;
import jp.co.jsbank.mobile.bff.dto.aba.LatestReceipDetailsDto;
import jp.co.jsbank.mobile.bff.dto.aba.LotteryResultsDetailsDto;

/**
 * ツールクラス
 */
public class Utils {

	// エラーメッセージ. 形式相違.
	private static final String MBFF_DEF_ERROR_MESSAGE_INVALID_TIMESTAMP_FORMAT = "だめだこりゃ! 期待した形式の時刻文字列を設定してくれんなまし。。。";

	// 時刻形式 ABA応答値に対する形式定義.
	private static final String MBFF_DEF_TIMESTAMP_REGEX_PATTERN = "^([0-9]{4})-([0-9]{2})-([0-9]{2})T([0-9]{2}):([0-9]{2}):([0-9]{2})";

	// 時刻形式 Parse後の時刻組み立て時の形式.
	private static final String MBFF_DEF_TIMESTAMP_FORMAT = "%s-%s-%s %s:%s:%s";
	// 時刻形式 Parse後の時刻組み立て時の形式.
	private static final String MAPP_DEF_TIMESTAMP_FORMAT = "%s-%s-%s %s:%s";

	private static final String BIRTHDAY_FORMAT = "%s-%s-%s";

	// 定期回数 58
	private static final int LOTTERY_TIMES_58 = 58;
	// 定期回数 61
	private static final int LOTTERY_TIMES_61 = 61;
	// 定期回数 63
	private static final int LOTTERY_TIMES_63 = 63;


	/**
	 * ユーザーIDを変更する
	 *
	 * @param parameterDto        リクエストパラメータ
	 * @param getIdByTokenHandler ID取得クラス
	 */
	public static void changeUserid(ParameterBuilder parameterDto, GetIdByTokenHandler getIdByTokenHandler) {
		RequestBodyDto userIDForChange = (RequestBodyDto) parameterDto.getRequestEntity().getBody();
		String userID = userIDForChange.getCommonRequestHeader().getUserID();
		if (!StringUtils.isBlank(userID)) {
            userIDForChange.getCommonRequestHeader().setUserID(getIdByTokenHandler.getIdByToken(userID));
		} else {
            userIDForChange.getCommonRequestHeader().setUserID("sm" + RequestHeaderContext.getInstance().getDeviceId());
		}
	}

	/**
	 * 時刻文字列（ABA応答値）をUnix EpochTimeに変換するメソッド.
	 *
	 * @param str
	 * @param timeZoneStr
	 * @throws ParseException
	 * @throws Exception
	 */
	public static long getEpochTimeFromABATimestmapString(String str, String timeZoneStr)
			throws ParseException, Exception {
		// 正規表現のパターンマッチコンパイルを実施する.
		String patternStr = MBFF_DEF_TIMESTAMP_REGEX_PATTERN;
		Pattern pat = Pattern.compile(patternStr);
		Matcher mat = pat.matcher(str);

		// 一致するかどうかを検査する.
		if (mat.find()) {
			// 正規表現のグループ指定により各値のParse処理を実施.
			String strYYYY = mat.group(1);
			String strMM = mat.group(2);
			String strDD = mat.group(3);
			String strHH = mat.group(4);
			String strMin = mat.group(5);
			String strSS = mat.group(6);

			// 文字列の組み立て.
			String mrgStr = String.format(MBFF_DEF_TIMESTAMP_FORMAT, strYYYY, strMM, strDD, strHH, strMin, strSS);

			// epoch時間への変換処理.
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			sdf.setTimeZone(TimeZone.getTimeZone(timeZoneStr));
			Date lm = sdf.parse(mrgStr);
			return lm.getTime();
		} else {
			String msg = MBFF_DEF_ERROR_MESSAGE_INVALID_TIMESTAMP_FORMAT;
			throw new Exception(msg);
		}
	}
    /**
     * 時刻文字列（ABA応答値）をUnix EpochTimeに変換するメソッド.
     *
     * @param str
     * @param timeZoneStr
     * @throws ParseException
     * @throws Exception
     */
    public static String changeTImeFromABATimestmapString(String str)
            throws ParseException, Exception {
        // 正規表現のパターンマッチコンパイルを実施する.
        String patternStr = MBFF_DEF_TIMESTAMP_REGEX_PATTERN;
        Pattern pat = Pattern.compile(patternStr);
        Matcher mat = pat.matcher(str);

        // 一致するかどうかを検査する.
        if (mat.find()) {
            // 正規表現のグループ指定により各値のParse処理を実施.
            String strYYYY = mat.group(1);
            String strMM = mat.group(2);
            String strDD = mat.group(3);
            String strHH = mat.group(4);
            String strMin = mat.group(5);

            // 文字列の組み立て.
            String mrgStr = String.format(MAPP_DEF_TIMESTAMP_FORMAT, strYYYY, strMM, strDD, strHH, strMin);
            return mrgStr;
        } else {
            String msg = MBFF_DEF_ERROR_MESSAGE_INVALID_TIMESTAMP_FORMAT;
            throw new Exception(msg);
        }
    }


	/**
	 * 抽選結果取得
	 *
	 * @param subNo             サブNo
	 * @param LotteryTimes      抽選回数
	 * @param lotteryNoStart    抽選開始番号
	 * @param lotteryNoEnd      抽選終了番号
	 * @param lotteryResults    抽選結果
	 * @param latestReceiptInfo 最新受領情報
	 * @return
	 */
	public static List<LotteryResultsDetailsDto> getLotteryResult(String subNo, String LotteryTimes,
			String lotteryNoStart, String lotteryNoEnd, List<LotteryResultsDetailsDto> lotteryResults,
			List<LatestReceipDetailsDto> latestReceiptInfo) {

		List<LotteryResultsDetailsDto> resultsDetailsDtoList = new ArrayList<LotteryResultsDetailsDto>();
		// 本抽最大回数
		int authenticTimes = 0;
		// 感謝賞最大回数
		int thanksTimes = 0;
		// 抽選回数
		int lotteryTimes = Integer.valueOf(LotteryTimes);
		// 開始抽選番号
		String start = lotteryNoStart;
		if (StringUtils.isBlank(start) || start.contains("*")) {
			start = "0";
		}
		// 終了抽選番号
		String end = lotteryNoEnd;
		if (StringUtils.isBlank(end) || end.contains("*")) {
			end = start;
		}

		// 本抽当せん本数
		int authenticCount = 0;
		// 感謝賞当せん本数
		int thanksCount = 0;
		// 抽選結果本数
		int resultCount = 0;
		// 最も上位の賞
		String maxLottery = "";
		//当選番号取得2025/08/27　修正start
		// 本抽当せん番号
		Set<String> winningNumbers = new HashSet<>();
		//当選番号取得2025/08/27　修正end

		List<LotteryResultsDetailsDto> subLotteryResults = new ArrayList<LotteryResultsDetailsDto>();

		// 抽選結果明細リスト
		if (lotteryResults != null && lotteryResults.size() > 0) {

			// 本抽当せん、感謝賞当せん本数
			for (LotteryResultsDetailsDto lotteryResultsDetailsDto : lotteryResults) {
				if (lotteryResultsDetailsDto.getSubNumber().equals(subNo)) {
					if (Constant.LOTTERY_TYPE_AUTHENTIC.equals(lotteryResultsDetailsDto.getLotteryType())) {
					    //当選番号取得2025/08/27　修正start
						winningNumbers.add(lotteryResultsDetailsDto.getLotteryNumber());
						//当選番号取得2025/08/27　修正end
						authenticCount += Integer.valueOf(lotteryResultsDetailsDto.getLotteryCount());
					} else {
						thanksCount += Integer.valueOf(lotteryResultsDetailsDto.getLotteryCount());
					}
					subLotteryResults.add(lotteryResultsDetailsDto);
				}
			}

			if (!subLotteryResults.isEmpty()) {
				resultCount = subLotteryResults.size();
				// 最も上位の賞
				List<String> lotteryResultOptList = subLotteryResults.stream()
						.filter(lottery -> Constant.LOTTERY_TYPE_AUTHENTIC.equals(lottery.getLotteryType()))
						.map(LotteryResultsDetailsDto::getLotteryRank).collect(Collectors.toList());
				if (lotteryTimes >= LOTTERY_TIMES_63) {
					if (lotteryResultOptList.contains(LotteryResultsCode.FIRST)) {
						// １等賞
						maxLottery = LotteryResultsCode.FIRST;
					} else if (lotteryResultOptList.contains(LotteryResultsCode.TWO)) {
						// ２等賞
						maxLottery = LotteryResultsCode.TWO;
					} else if (lotteryResultOptList.contains(LotteryResultsCode.SIX)) {
						// コシヒカリ賞
						maxLottery = LotteryResultsCode.SIX;
					} else if (lotteryResultOptList.contains(LotteryResultsCode.THREE)) {
						// ３等賞
						maxLottery = LotteryResultsCode.THREE;
					} else if (lotteryResultOptList.contains(LotteryResultsCode.LevelFOUR)) {
						// 4等賞
						maxLottery = LotteryResultsCode.LevelFOURicon;
					}
				}
				// 定期の抽選回数が61回以後
				else if (lotteryTimes >= LOTTERY_TIMES_61) {
					if (lotteryResultOptList.contains(LotteryResultsCode.BEST)) {
						// ドリーム大賞
						maxLottery = LotteryResultsCode.BEST;
					} else if (lotteryResultOptList.contains(LotteryResultsCode.FIRST)) {
						// １等賞
						maxLottery = LotteryResultsCode.FIRST;
					} else if (lotteryResultOptList.contains(LotteryResultsCode.ANNIVERSARY_80TH)) {
						// 創立８０周年記念特別賞
						maxLottery = LotteryResultsCode.ANNIVERSARY_80TH;
					} else if (lotteryResultOptList.contains(LotteryResultsCode.THANKS_30TH)) {
						// ３０周年感謝賞
						maxLottery = LotteryResultsCode.THANKS_30TH;
					} else if (lotteryResultOptList.contains(LotteryResultsCode.TWO)) {
						// ２等賞
						maxLottery = LotteryResultsCode.TWO;
					} else if (lotteryResultOptList.contains(LotteryResultsCode.FIVE)) {
						// 城南特選グルメ賞
						maxLottery = LotteryResultsCode.FIVE;
					} else if (lotteryResultOptList.contains(LotteryResultsCode.SIX)) {
						// コシヒカリ賞
						maxLottery = LotteryResultsCode.SIX;
					} else if (lotteryResultOptList.contains(LotteryResultsCode.THREE)) {
						// ３等賞
						maxLottery = LotteryResultsCode.THREE;
					}
				} else {
					if (lotteryResultOptList.contains(LotteryResultsCode.BEST)) {
						// ドリーム大賞
						maxLottery = LotteryResultsCode.BEST;
					} else if (lotteryResultOptList.contains(LotteryResultsCode.FIRST)) {
						// １等賞
						maxLottery = LotteryResultsCode.FIRST;
					} else if (lotteryResultOptList.contains(LotteryResultsCode.TWO)) {
						// ２等賞
						maxLottery = LotteryResultsCode.TWO;
					} else if (lotteryResultOptList.contains(LotteryResultsCode.FOUR)) {
						// 被災地復興応援グルメ賞
						maxLottery = LotteryResultsCode.FOUR;
					} else if (lotteryResultOptList.contains(LotteryResultsCode.FIVE)) {
						// 被災地復興応援グルメ賞
						maxLottery = LotteryResultsCode.FOUR;
					} else if (lotteryResultOptList.contains(LotteryResultsCode.SIX)) {
						// コシヒカリ賞
						maxLottery = LotteryResultsCode.SIX;
					} else if (lotteryResultOptList.contains(LotteryResultsCode.THREE)) {
						// ３等賞
						maxLottery = LotteryResultsCode.THREE;
					}
				}
			}
		}

		// 最新受領情報明細リスト
		if (latestReceiptInfo != null && latestReceiptInfo.size() > 0) {
			for (LatestReceipDetailsDto latestReceipDetailsDto : latestReceiptInfo) {
				if (Constant.LOTTERY_TYPE_AUTHENTIC.equals(latestReceipDetailsDto.getLotteryType())) {
					authenticTimes = Integer.valueOf(latestReceipDetailsDto.getLotteryTimes());
				} else {
					thanksTimes = Integer.valueOf(latestReceipDetailsDto.getLotteryTimes());
				}
			}
		}

		LotteryResultsDetailsDto resultsDetailsDto = new LotteryResultsDetailsDto();
		resultsDetailsDto.setLotteryCount("0");

		// 定期の抽選回数が58回以後
		if (lotteryTimes >= LOTTERY_TIMES_58) {
			// 抽選回数＞最新本抽せん受領回数 or 本抽せんがまだ実施されていない場合は「抽せん結果待ち」
			if (authenticTimes == 0 && thanksTimes == 0 || lotteryTimes > authenticTimes) {
				resultsDetailsDto.setLotteryRank(LotteryResultsCode.WAIT);
				resultsDetailsDtoList.add(resultsDetailsDto);
			} else {
				// 抽選結果なし、はずれ
				if (resultCount == 0) {
					resultsDetailsDto.setLotteryRank(LotteryResultsCode.DROP);
					resultsDetailsDtoList.add(resultsDetailsDto);
				}
				// 抽選結果あり
				else {
					// 本抽せんあり、当せん「最も上位の賞」
					if (authenticCount > 0 && StringUtils.isNotBlank(maxLottery)) {
						resultsDetailsDto.setLotteryRank(maxLottery);
						resultsDetailsDto.setLotteryCount(authenticCount == 1 ? "0" : String.valueOf(authenticCount));
						resultsDetailsDtoList.add(resultsDetailsDto);
					}
					// 本抽せんない、はずれ
					else {
						resultsDetailsDto.setLotteryRank(LotteryResultsCode.DROP);
						resultsDetailsDtoList.add(resultsDetailsDto);
					}
				}
			}
		}
		// 抽選回数が58回以前
		else {
			// 抽選回数＞最新本抽せん受領回数 or 本抽せんがまだ実施されていない場合は「抽せん結果待ち」
			if (authenticTimes == 0 && thanksTimes == 0 || lotteryTimes > authenticTimes) {
				resultsDetailsDto.setLotteryRank(LotteryResultsCode.WAIT);
				resultsDetailsDtoList.add(resultsDetailsDto);
			} else {
				// 抽選結果なし
				if (resultCount == 0) {
					// 最新本抽せん受領回数 >= 抽選回数、 最新感謝賞受領回数 < 抽選回数、「感謝賞結果待ち」
					if (authenticTimes >= lotteryTimes && thanksTimes < lotteryTimes) {
						resultsDetailsDto.setLotteryRank(LotteryResultsCode.WAIT_THANKS);
						resultsDetailsDtoList.add(resultsDetailsDto);
					}
					// 最新本抽せん受領回数 >= 抽選回数、 最新感謝賞受領回数 >= 抽選回数、「感謝賞落せん」
					else if (authenticTimes >= lotteryTimes && thanksTimes >= lotteryTimes) {
						resultsDetailsDto.setLotteryRank(LotteryResultsCode.DROP);
						resultsDetailsDtoList.add(resultsDetailsDto);
					}
					// 上記以外
					else {
						// 「抽せん結果待ち」
						resultsDetailsDto.setLotteryRank(LotteryResultsCode.WAIT);
						resultsDetailsDtoList.add(resultsDetailsDto);
					}
				}
				// 抽選結果あり
				else {
					// 最新本抽せん受領回数 >= 抽選回数、 最新感謝賞受領回数 < 抽選回数
					if (authenticTimes >= lotteryTimes && thanksTimes < lotteryTimes) {
						// 単独抽選
						if (end.equals(start)) {
							if (StringUtils.isNotBlank(maxLottery)) {
								// 単独で当せんした場合「最も上位の賞」
								resultsDetailsDto.setLotteryRank(maxLottery);
								resultsDetailsDto.setLotteryCount("0");
								resultsDetailsDtoList.add(resultsDetailsDto);
							} else if (thanksCount != 0) {
								// 「感謝賞結果待ち」
								resultsDetailsDto.setLotteryRank(LotteryResultsCode.WAIT_THANKS);
								resultsDetailsDtoList.add(resultsDetailsDto);
							} else {
								// 落せん
								resultsDetailsDto.setLotteryRank(LotteryResultsCode.DROP);
								resultsDetailsDtoList.add(resultsDetailsDto);
							}
						}
						// 複数抽選
						else {
							int count = Integer.valueOf(end) - Integer.valueOf(start) + 1;
							// すべてが当せんした場合
							//当選番号取得2025/08/27　修正start
							if (winningNumbers.size() == count && thanksCount == 0) {
							// if (resultCount == count && thanksCount == 0) {
							//当選番号取得2025/08/27　修正end
								// 「最も上位の賞」
								resultsDetailsDto.setLotteryRank(maxLottery);
								resultsDetailsDto.setLotteryCount(authenticCount == 1 ? "0" : String.valueOf(authenticCount));
								resultsDetailsDtoList.add(resultsDetailsDto);
							}
							// 本抽せん結果なし、感謝賞結果あり
							else if (authenticCount == 0 && thanksCount != 0) {
								// 「感謝賞結果待ち」
								resultsDetailsDto.setLotteryRank(LotteryResultsCode.WAIT_THANKS);
								resultsDetailsDtoList.add(resultsDetailsDto);
							}
							// 複数で一部が当せんした場合
							else {
								// 「最も上位の賞」
								resultsDetailsDto.setLotteryRank(maxLottery);
								resultsDetailsDto.setLotteryCount((authenticCount + thanksCount) == 1 ? "0" : String.valueOf(authenticCount + thanksCount));
								resultsDetailsDtoList.add(resultsDetailsDto);

								// 「感謝賞抽せん結果待ち」
								resultsDetailsDto = new LotteryResultsDetailsDto();
								resultsDetailsDto.setLotteryCount("0");
								resultsDetailsDto.setLotteryRank(LotteryResultsCode.WAIT_THANKS);
								resultsDetailsDtoList.add(resultsDetailsDto);
							}
						}
					}
					// 最新本抽せん受領回数 >= 抽選回数、 最新感謝賞受領回数 >= 抽選回数
					else if (authenticTimes >= lotteryTimes && thanksTimes >= lotteryTimes) {
						// 単独抽選
						if (end.equals(start)) {
							if (authenticCount != 0) {
								// 単独で当せんした場合「最も上位の賞」
								resultsDetailsDto.setLotteryRank(maxLottery);
								resultsDetailsDto.setLotteryCount("0");
								resultsDetailsDtoList.add(resultsDetailsDto);
							} else {
								// 「感謝賞当せん」
								resultsDetailsDto.setLotteryRank(LotteryResultsCode.WIN_THANKS);
								resultsDetailsDtoList.add(resultsDetailsDto);
							}
						}
						// 複数抽選
						else {
							int count = Integer.valueOf(end) - Integer.valueOf(start) + 1;
							// すべてが当せんした場合
							//当選番号取得2025/08/27　修正start
							if (winningNumbers.size() == count && thanksCount == 0) {
							// if (resultCount == count && thanksCount == 0) {
							//当選番号取得2025/08/27　修正end
								// 「最も上位の賞」
								resultsDetailsDto.setLotteryRank(maxLottery);
								resultsDetailsDto.setLotteryCount((authenticCount + thanksCount) == 1 ? "0" : String.valueOf(authenticCount + thanksCount));
								resultsDetailsDtoList.add(resultsDetailsDto);
							}
							// 本抽せん結果なし、感謝賞結果あり
							else if (authenticCount == 0 && thanksCount != 0) {
								// 「感謝賞当せん」
								resultsDetailsDto.setLotteryRank(LotteryResultsCode.WIN_THANKS);
								resultsDetailsDtoList.add(resultsDetailsDto);
							}
							// 複数で一部が当せんした場合
							else {
								// 「最も上位の賞」
								resultsDetailsDto.setLotteryRank(maxLottery);
								resultsDetailsDto.setLotteryCount((authenticCount + thanksCount) == 1 ? "0" : String.valueOf(authenticCount + thanksCount));
								resultsDetailsDtoList.add(resultsDetailsDto);

								if (thanksCount != 0) {
									// 「感謝賞当せん」
									resultsDetailsDto = new LotteryResultsDetailsDto();
									resultsDetailsDto.setLotteryCount("0");
									resultsDetailsDto.setLotteryRank(LotteryResultsCode.WIN_THANKS);
									resultsDetailsDtoList.add(resultsDetailsDto);
								} else {
									// 「感謝賞落せん」
									resultsDetailsDto = new LotteryResultsDetailsDto();
									resultsDetailsDto.setLotteryCount("0");
									resultsDetailsDto.setLotteryRank(LotteryResultsCode.THANKS_DROP);
									resultsDetailsDtoList.add(resultsDetailsDto);
								}
							}
						}
					}
					// 上記以外
					else {
						// 「感謝賞抽せん結果待ち」
						resultsDetailsDto = new LotteryResultsDetailsDto();
						resultsDetailsDto.setLotteryCount("0");
						resultsDetailsDto.setLotteryRank(LotteryResultsCode.WAIT_THANKS);
						resultsDetailsDtoList.add(resultsDetailsDto);
					}
				}
			}
		}


		return resultsDetailsDtoList;
	}

	public static String formatBirthday(String strYYYY, String strMM, String strDD){
		strMM = strMM.length() == 1 ? "0" + strMM : strMM;
		strDD = strDD.length() == 1 ? "0" + strDD : strDD;
		return String.format(BIRTHDAY_FORMAT, strYYYY, strMM, strDD);
	}

	// 20文字以上の長い名前の法人名の場合、ホストで20文字に切られてしまいます、部分一致でチェックします
	public static boolean isSameName(String nameFromSys, String nameInput) {
		if (nameFromSys == null || nameInput == null) {
			return false;
		}
		return nameInput.toLowerCase().contains(nameFromSys.toLowerCase());
	}
}

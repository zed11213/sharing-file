package jp.co.jsbank.mobile.bff.common.util;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;

/**
 * ツールクラス
 */
public class NullPropertyNamesUtils {

    /**
     * 空文字→NULL変換処理
     *
     * @param source DTO
     */
    @SuppressWarnings("rawtypes")
    public static void setNullPropertyNames(Object source) {
        final BeanWrapper src = new BeanWrapperImpl(source);
        java.beans.PropertyDescriptor[] pds = src.getPropertyDescriptors();

        for (java.beans.PropertyDescriptor pd : pds) {
            Object srcValue = src.getPropertyValue(pd.getName());

            if (pd.getPropertyType().getName().contains("List") || srcValue instanceof List) {

                if (srcValue == null || ((List) srcValue).isEmpty()) {
                    src.setPropertyValue(pd.getName(), null);
                } else {

                    for (Object pbj : (List) srcValue) {
                        setNullPropertyNames(pbj);
                    }
                }

            } else if (srcValue == null || StringUtils.isBlank(srcValue.toString())) {

                src.setPropertyValue(pd.getName(), null);
            }
        }
    }

    /**
     * NULL→空文字変換処理
     *
     * @param source DTO
     */
    @SuppressWarnings("rawtypes")
    public static void setSpacePropertyNames(Object source) {
        final BeanWrapper src = new BeanWrapperImpl(source);
        java.beans.PropertyDescriptor[] pds = src.getPropertyDescriptors();

        for (java.beans.PropertyDescriptor pd : pds) {
            Object srcValue = src.getPropertyValue(pd.getName());

			if (pd.getPropertyType().getName().contains("List") || srcValue instanceof List) {

                if (srcValue == null || ((List) srcValue).isEmpty()) {
                    //src.setPropertyValue(pd.getName(), null);
                } else {

                    for (Object pbj : (List) srcValue) {
                    	setSpacePropertyNames(pbj);
                    }
                }

            } else if (srcValue == null && pd.getPropertyType().getName().contains("String") ) {
                src.setPropertyValue(pd.getName(), "");
            }
        }
    }
}

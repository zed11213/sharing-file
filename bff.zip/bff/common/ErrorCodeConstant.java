package jp.co.jsbank.mobile.bff.common;

/**
 * 定数クラス
 */
public class ErrorCodeConstant {

    /**
     * ログラベル: I
     */
    public static final String LOG_LABLE_I = "I";

    /**
     * ログラベル: W
     */
    public static final String LOG_LABLE_W = "W";

    /**
     * ログラベル: E
     */
    public static final String LOG_LABLE_E = "E";

    /**
     * CSV
     * */
    public static final String E01 = "E01";

    /**
     * PDF
     * */
    public static final String E03 = "E03";

    /**
     * エラーコード: 10000
     */
    public static final String ERROR_CODE_10000 = "10000";

    /**
     * エラーコード: 10001
     */
    public static final String ERROR_CODE_10001 = "10001";

    /**
     * エラーコード: 10022
     */
    public static final String ERROR_CODE_10022 = "10022";

    /**
     * エラーコード: 10031
     */
    public static final String ERROR_CODE_10031 = "10031";

    /**
     * エラーコード: 10032
     */
    public static final String ERROR_CODE_10032 = "10032";

    /**
     * エラーコード: 30010
     */
    public static final String ERROR_CODE_30010 = "30010";

    /**
     * エラーコード: 33293
     */
    public static final String ERROR_CODE_33293 = "33293";

    /**
     * エラーコード: 71002
     */
    public static final String ERROR_CODE_71002 = "71002";

    /**
     * エラーコード: 71007
     */
    public static final String ERROR_CODE_71007 = "71007";

    /**
     * エラーコード: 71008
     */
    public static final String ERROR_CODE_71008 = "71008";

    /**
     * エラーコード: 71010
     */
    public static final String ERROR_CODE_71010 = "71010";

    /**
     * エラーコード: 71013
     */
    public static final String ERROR_CODE_71013 = "71013";

    /**
     * エラーコード: 71017
     */
    public static final String ERROR_CODE_71017 = "71017";

    /**
     * エラーコード: 71018
     */
    public static final String ERROR_CODE_71018 = "71018";

    /**
     * エラーコード: 71019
     */
    public static final String ERROR_CODE_71019 = "71019";

    /**
     * エラーコード: 71020
     */
    public static final String ERROR_CODE_71020 = "71020";

    /**
     * エラーコード: 71021
     */
    public static final String ERROR_CODE_71021 = "71021";

    /**
     * エラーコード: 71022
     */
    public static final String ERROR_CODE_71022 = "71022";

    /**
     * エラーコード: 71023
     */
    public static final String ERROR_CODE_71023 = "71023";

    /**
     * エラーコード: 71024
     */
    public static final String ERROR_CODE_71024 = "71024";

    /**
     * エラーコード: 71025
     */
    public static final String ERROR_CODE_71025 = "71025";

    /**
     * エラーコード: 71026
     */
    public static final String ERROR_CODE_71026 = "71026";

    /**
     * エラーコード: 71027
     */
    public static final String ERROR_CODE_71027 = "71027";

    /**
     * エラーコード: 71028
     */
    public static final String ERROR_CODE_71028 = "71028";

    /**
     * エラーコード: 71029
     */
    public static final String ERROR_CODE_71029 = "71029";

    /**
     * エラーコード: 71030
     */
    public static final String ERROR_CODE_71030 = "71030";

    /**
     * エラーコード: 71032
     */
    public static final String ERROR_CODE_71032 = "71032";

    /**
     * エラーコード: 71033
     */
    public static final String ERROR_CODE_71033 = "71033";

    /**
     * エラーコード: 71034
     */
    public static final String ERROR_CODE_71034 = "71034";

    /**
     * エラーコード: 71041
     */
    public static final String ERROR_CODE_71041 = "71041";

    /**
     * エラーコード：71042
     * */
    public static final String ERROR_CODE_71042 = "71042";

    /**
     * エラーコード: 71200
     */
    public static final String ERROR_CODE_71200 = "71200";

    /**
     * エラーコード: 71201
     */
    public static final String ERROR_CODE_71201 = "71201";

    /**
     * エラーコード: 71202
     */
    public static final String ERROR_CODE_71202 = "71202";

    /**
     * エラーコード: 71205
     */
    public static final String ERROR_CODE_71205 = "71205";

    /**
     * エラーコード: 71206
     */
    public static final String ERROR_CODE_71206 = "71206";

    /**
     * エラーコード: 71207
     */
    public static final String ERROR_CODE_71207 = "71207";

    /**
     * エラーコード: 71210
     */
    public static final String ERROR_CODE_71210 = "71210";

    /**
     * エラーコード: 71302
     */
    public static final String ERROR_CODE_71302 = "71302";

    /**
     * エラーコード: 71303
     */
    public static final String ERROR_CODE_71303 = "71303";

    /**
     * エラーコード: 71304
     */
    public static final String ERROR_CODE_71304 = "71304";

    /**
     * エラーコード: 71305
     */
    public static final String ERROR_CODE_71305 = "71305";

    /**
     * エラーコード: 71306
     */
    public static final String ERROR_CODE_71306 = "71306";

    /**
     * エラーコード: 71307
     */
    public static final String ERROR_CODE_71307 = "71307";

    /**
     * エラーコード: 71308
     */
    public static final String ERROR_CODE_71308 = "71308";

    /**
     * エラーコード: 71309
     */
    public static final String ERROR_CODE_71309 = "71309";

    /**
     * エラーコード: 90000
     */
    public static final String ERROR_CODE_90000 = "90000";

    /**
     * エラーコード: 90001
     */
    public static final String ERROR_CODE_90001 = "90001";

    /**
     * エラーコード: 90002
     */
    public static final String ERROR_CODE_90002 = "90002";

    /**
     * エラーコード: 90003
     */
    public static final String ERROR_CODE_90003 = "90003";

    /**
     * エラーコード: 90004
     */
    public static final String ERROR_CODE_90004 = "90004";

    /**
     * エラーコード: 90005
     */
    public static final String ERROR_CODE_90005 = "90005";

    /**
     * エラーコード: 90006
     */
    public static final String ERROR_CODE_90006 = "90006";

    /**
     * エラーコード: 91000
     */
    public static final String ERROR_CODE_91000 = "91000";

    /**
     * エラーコード: 91001
     */
    public static final String ERROR_CODE_91001 = "91001";

    /**
     * エラーコード: 95000
     */
    public static final String ERROR_CODE_95000 = "95000";

    /**
     * エラーコード: 95001
     */
    public static final String ERROR_CODE_95001 = "95001";

    /**
     * エラーコード: 95002
     */
    public static final String ERROR_CODE_95002 = "95002";

    /**
     * エラーコード: 99999
     */
    public static final String ERROR_CODE_99999 = "99999";

    /**
     * エラーコード: 71100
     */
    public static final String ERROR_CODE_71100 = "71100";

    /**
     * エラーコード: 71101
     */
    public static final String ERROR_CODE_71101 = "71101";

    /**
     * エラーコード: 71102
     */
    public static final String ERROR_CODE_71102 = "71102";

    /**
     * エラーコード: 71103
     */
    public static final String ERROR_CODE_71103 = "71103";

    /**
     * エラーコード: 71001
     */
    public static final String ERROR_CODE_71001 = "71001";

    /**
     * エラーコード: 71000
     */
    public static final String ERROR_CODE_71000 = "71000";

    /**
     * エラーコード: 71004
     */
    public static final String ERROR_CODE_71004 = "71004";

    /**
     * エラーコード: 71005
     */
    public static final String ERROR_CODE_71005 = "71005";

    /**
     * エラーコード: 71006
     */
    public static final String ERROR_CODE_71006 = "71006";

    /**
     * エラーコード: 71031
     */
    public static final String ERROR_CODE_71031 = "71031";

    /**
     * エラーコード: 71003
     */
    public static final String ERROR_CODE_71003 = "71003";

    /**
     * エラーコード: 71208
     */
    public static final String ERROR_CODE_71208 = "71208";

    /**
     * エラーコード: 71209
     */
    public static final String ERROR_CODE_71209 = "71209";

    /**
     * エラーコード: 71212
     */
    public static final String ERROR_CODE_71212 = "71212";

    /**
     * エラーコード: 71213
     */
    public static final String ERROR_CODE_71213 = "71213";
    /**
     * エラーコード: 71217
     */
    public static final String ERROR_CODE_71217 = "71217";

    /**
     * エラーコード: 71218
     */
    public static final String ERROR_CODE_71218 = "71218";
    /**
     * エラーコード: 71400
     */
    public static final String ERROR_CODE_71400 = "71400";

    /**
     * エラーコード: 71044
     */
    public static final String ERROR_CODE_71044 = "71044";

    /**
     * エラーコード: 71047
     */
    public static final String ERROR_CODE_71047 = "71047";

    /**
     * エラーコード: 71048
     */
    public static final String ERROR_CODE_71048 = "71048";

    /**
     * エラーコード: 71049
     */
    public static final String ERROR_CODE_71049 = "71049";

    /**
     * エラーコード: 71050
     */
    public static final String ERROR_CODE_71050 = "71050";

    /**
     * エラーコード: 71051
     */
    public static final String ERROR_CODE_71051 = "71051";

    /**
     * エラーコード: 71052
     */
    public static final String ERROR_CODE_71052 = "71052";

    /**
     * エラーコード: 71053
     */
    public static final String ERROR_CODE_71053 = "71053";

    /**
     * エラーコード: 71054
     */
    public static final String ERROR_CODE_71054 = "71054";

    /**
     * エラーコード: 71055
     */
    public static final String ERROR_CODE_71055 = "71055";

    /**
     * エラーコード: 71061
     */
    public static final String ERROR_CODE_71061 = "71061";

    /**
     * エラーコード: 71062
     */
    public static final String ERROR_CODE_71062 = "71062";

    /**
     * エラーコード: 71063
     */
    public static final String ERROR_CODE_71063 = "71063";

    /**
     * エラーコード: 71401
     */
    public static final String ERROR_CODE_71401 = "71401";

    /**
     * エラーコード: 71402
     */
    public static final String ERROR_CODE_71402 = "71402";
    /**
     * エラーコード: 71406
     */
    public static final String ERROR_CODE_71406 = "71406";
    /**
     * エラーコード: 71407
     */
    public static final String ERROR_CODE_71407 = "71407";
    /**
     * エラーコード: 71408
     */
    public static final String ERROR_CODE_71408 = "71408";
    /**
     * エラーコード: 71410
     */
    public static final String ERROR_CODE_71410 = "71410";

    /**
     * エラーコード: 71412
     */
    public static final String ERROR_CODE_71412 = "71412";

    /**
     * エラーコード: 71211
     */
    public static final String ERROR_CODE_71211 = "71211";

    /**
     * エラーコード: 10021
     */
    public static final String ERROR_CODE_10021 = "10021";

    /**
     * エラーコード: 10023
     */
    public static final String ERROR_CODE_10023 = "10023";

    /**
     * エラーコード: 71058
     */
    public static final String ERROR_CODE_71058 = "71058";

    /**
     * エラーコード: 71066
     */
    public static final String ERROR_CODE_71066 = "71066";

    /**
     * エラーコード: 71067
     */
    public static final String ERROR_CODE_71067 = "71067";

    /**
     * エラーコード: 71068
     */
    public static final String ERROR_CODE_71068 = "71068";

    /**
     * エラーコード: 71069
     */
    public static final String ERROR_CODE_71069 = "71069";

    /**
     * エラーコード: 71070
     */
    public static final String ERROR_CODE_71070 = "71070";

    /**
     * エラーコード: 71071
     */
    public static final String ERROR_CODE_71071 = "71071";

    /**
     * エラーコード: 71404
     */
    public static final String ERROR_CODE_71404 = "71404";

    /**
     * エラーコード: 71215
     */
    public static final String ERROR_CODE_71215 = "71215";

    /**
     * エラーコード: 71219
     */
    public static final String ERROR_CODE_71219 = "71219";

    /**
     * エラーコード: 71220
     */
    public static final String ERROR_CODE_71220 = "71220";

    /**
     * エラーコード: MBOP0004
     */
    public static final String ERROR_CODE_MBOP0004 = "MBOP0004";

    /**
     * エラーコード: MBST0001
     */
    public static final String ERROR_CODE_MBST0001 = "MBST0001";

    /**
     * エラーコード: MBST0002
     */
    public static final String ERROR_CODE_MBST0002 = "MBST0002";

    /**
     * エラーコード: MBST0003
     */
    public static final String ERROR_CODE_MBST0003 = "MBST0003";

    /**
     * エラーコード: MBST0004
     */
    public static final String ERROR_CODE_MBST0004 = "MBST0004";

    /**
     * エラーコード: MBAP0010
     */
    public static final String ERROR_CODE_MBAP0010 = "MBAP0010";

    /**
     * エラーコード: MBAP0011
     */
    public static final String ERROR_CODE_MBAP0011 = "MBAP0011";

    /**
     * エラーコード: MBAP0012
     */
    public static final String ERROR_CODE_MBAP0012 = "MBAP0012";

    /**
     * エラーコード: MBAP0009
     */
    public static final String ERROR_CODE_MBAP0009 = "MBAP0009";

    /**
     * ファイル授受エラーメッセージID : MBFS0002
     */
    public static final String ERROR_CODE_MBFS0002 = "MBFS0002";

    /**
     * ファイル授受エラーメッセージID : MBFS0003
     */
    public static final String ERROR_CODE_MBFS0003 = "MBFS0003";

    /**
     * ファイル授受エラーメッセージID : MBFS0004
     */
    public static final String ERROR_CODE_MBFS0004 = "MBFS0004";
    
    // 以下はBAエラー
    /**
     * BAエラーコード: 90000,BA内部エラー
     */
    public static final String BA_ERROR_CODE_90000 = "90000";

    /**
     * BAエラーコード: 90001,Outboundの呼び出しエラー
     */
    public static final String BA_ERROR_CODE_90001 = "90001";

    /**
     * BAエラーコード: 90003,バックエンドサービス時間外
     */
    public static final String BA_ERROR_CODE_90003 = "90003";

    /**
     * BAエラーコード: 90005,Outbound同時呼出スレッド数エラー
     */
    public static final String BA_ERROR_CODE_90005 = "90005";

    /**
     * BAエラーコード: 90007,バックエンドサービス時間外
     */
    public static final String BA_ERROR_CODE_90007 = "90007";
    
     /**
     * BAエラーコード: 91000,入力パラメーター不正
     */
    public static final String BA_ERROR_CODE_91000 = "91000";

    /**
     * BAエラーコード: 91001,編集処理エラー：COM101
     */
    public static final String BA_ERROR_CODE_91001 = "91001";

    /**
     * BAエラーコード: 91002,編集処理エラー：COM102
     */
    public static final String BA_ERROR_CODE_91002 = "91002";
    
    /**
     * BAエラーコード: 91003,編集処理エラー：COM201
     */
    public static final String BA_ERROR_CODE_91003 = "91003";

    /**
     * BAエラーコード: 91004,編集処理エラー：COM202
     */
    public static final String BA_ERROR_CODE_91004 = "91004";

    /**
     * BAエラーコード: 91005,編集処理エラー：COM203
     */
    public static final String BA_ERROR_CODE_91005 = "91005";

    /**
     * BAエラーコード: 91006,編集処理エラー：COM204
     */
    public static final String BA_ERROR_CODE_91006 = "91006";

    /**
     * BAエラーコード: 91007,編集処理エラー：COM205
     */
    public static final String BA_ERROR_CODE_91007 = "91007";

    /**
     * BAエラーコード: 91008,編集処理エラー：COM206
     */
    public static final String BA_ERROR_CODE_91008 = "91008";

    /**
     * BAエラーコード: 91009,編集処理エラー：COM207
     */
    public static final String BA_ERROR_CODE_91009 = "91009";

    /**
     * BAエラーコード: 91010,編集処理エラー：COM208
     */
    public static final String BA_ERROR_CODE_91010 = "91010";
    
    /**
     * BAエラーコード: 91011,編集処理エラー：COM300
     */
    public static final String BA_ERROR_CODE_91011 = "91011";

    /**
     * BAエラーコード: 91012,編集処理エラー：COM401
     */
    public static final String BA_ERROR_CODE_91012 = "91012";

    /**
     * BAエラーコード: 91013,編集処理エラー：COM402
     */
    public static final String BA_ERROR_CODE_91013 = "91013";

    /**
     * BAエラーコード: 91014,編集処理エラー：COM403
     */
    public static final String BA_ERROR_CODE_91014 = "91014";

    /**
     * BAエラーコード: 91015,編集処理エラー：COM404
     */
    public static final String BA_ERROR_CODE_91015 = "91015";

    /**
     * BAエラーコード: 91016,編集処理エラー：COM405
     */
    public static final String BA_ERROR_CODE_91016 = "91016";
    
    /**
     * BAエラーコード: 91017,編集処理エラー：COM406
     */
    public static final String BA_ERROR_CODE_91017 = "91017";

    /**
     * BAエラーコード: 91018,編集処理エラー：COM408
     */
    public static final String BA_ERROR_CODE_91018 = "91018";

    /**
     * BAエラーコード: 91019,編集処理エラー：COM409
     */
    public static final String BA_ERROR_CODE_91019 = "91019";

    /**
     * BAエラーコード: 91020,編集処理エラー：COM410
     */
    public static final String BA_ERROR_CODE_91020 = "91020";

    /**
     * BAエラーコード: 91021,編集処理エラー：COM412
     */
    public static final String BA_ERROR_CODE_91021 = "91021";

    /**
     * BAエラーコード: 91022,編集処理エラー：COM413
     */
    public static final String BA_ERROR_CODE_91022 = "91022";

    /**
     * BAエラーコード: 91023,編集処理エラー：COM414
     */
    public static final String BA_ERROR_CODE_91023 = "91023";

    /**
     * BAエラーコード: 91024,編集処理エラー：COM416
     */
    public static final String BA_ERROR_CODE_91024 = "91024";

    /**
     * BAエラーコード: 91025,編集処理エラー：COM417
     */
    public static final String BA_ERROR_CODE_91025 = "91025";

    /**
     * BAエラーコード: 91026,編集処理エラー：COM418
     */
    public static final String BA_ERROR_CODE_91026 = "91026";

    /**
     * BAエラーコード: 91027,編集処理エラー：COM419
     */
    public static final String BA_ERROR_CODE_91027 = "91027";

    /**
     * BAエラーコード: 91028,編集処理エラー：COM420
     */
    public static final String BA_ERROR_CODE_91028 = "91028";

    /**
     * BAエラーコード: 91029,編集処理エラー：COM421
     */
    public static final String BA_ERROR_CODE_91029 = "91029";

    /**
     * BAエラーコード: 91030,編集処理エラー：COM422
     */
    public static final String BA_ERROR_CODE_91030 = "91030";

    /**
     * BAエラーコード: 91031,編集処理エラー：COM423
     */
    public static final String BA_ERROR_CODE_91031 = "91031";

    /**
     * BAエラーコード: 91032,編集処理エラー：COM424
     */
    public static final String BA_ERROR_CODE_91032 = "91032";

    /**
     * BAエラーコード: 91033,編集処理エラー：COM425
     */
    public static final String BA_ERROR_CODE_91033 = "91033";

    /**
     * BAエラーコード: 91034,編集処理エラー：COM426
     */
    public static final String BA_ERROR_CODE_91034 = "91034";
    
    /**
     * BAエラーコード: 91035,編集処理エラー：COM427
     */
    public static final String BA_ERROR_CODE_91035 = "91035";

    /**
     * BAエラーコード: 91036,編集処理エラー：予備
     */
    public static final String BA_ERROR_CODE_91036 = "91036";

    /**
     * BAエラーコード: 91037,編集処理エラー：予備
     */
    public static final String BA_ERROR_CODE_91037 = "91037";

    /**
     * BAエラーコード: 91038,編集処理エラー：予備
     */
    public static final String BA_ERROR_CODE_91038 = "91038";

    /**
     * BAエラーコード: 91039,編集処理エラー：予備
     */
    public static final String BA_ERROR_CODE_91039 = "91039";

    /**
     * BAエラーコード: 91040,編集処理エラー：予備
     */
    public static final String BA_ERROR_CODE_91040 = "91040";

    /**
     * BAエラーコード: 91041,編集処理エラー：予備
     */
    public static final String BA_ERROR_CODE_91041 = "91041";

    /**
     * BAエラーコード: 91042,編集処理エラー：予備
     */
    public static final String BA_ERROR_CODE_91042 = "91042";

    /**
     * BAエラーコード: 91043,編集処理エラー：予備
     */
    public static final String BA_ERROR_CODE_91043 = "91043";

    /**
     * BAエラーコード: 91044,編集処理エラー：予備
     */
    public static final String BA_ERROR_CODE_91044 = "91044";

    /**
     * BAエラーコード: 91045,編集処理エラー：予備
     */
    public static final String BA_ERROR_CODE_91045 = "91045";

    /**
     * BAエラーコード: 91046,編集処理エラー：予備
     */
    public static final String BA_ERROR_CODE_91046 = "91046";

    /**
     * BAエラーコード: 91047,編集処理エラー：予備
     */
    public static final String BA_ERROR_CODE_91047 = "91047";

    /**
     * BAエラーコード: 91048,編集処理エラー：予備
     */
    public static final String BA_ERROR_CODE_91048 = "91048";

    /**
     * BAエラーコード: 91049,編集処理エラー：予備
     */
    public static final String BA_ERROR_CODE_91049 = "91049";
    
     /**
     * BAエラーコード: 92000,バックエンドリクエストエラー
     */
    public static final String BA_ERROR_CODE_92000 = "92000";
     /**
     * BAエラーコード: 95000,バックエンドサービス時間外
     */
    public static final String BA_ERROR_CODE_95000 = "95000";

     /**
     * BAエラーコード: 95001,送信リトライオーバー
     */
    public static final String BA_ERROR_CODE_95001 = "95001";

     /**
     * BAエラーコード: 95002,バックエンドタイムアウト
     */
    public static final String BA_ERROR_CODE_95002 = "95002";

     /**
     * BAエラーコード: 95003,流量制限エラー
     */
    public static final String BA_ERROR_CODE_95003 = "95003";

    /**
     * BAエラーコード: 502,口座/CIFが解約済
     */
    public static final String BA_ERROR_CODE_502 = "502";

    /**
     * BAエラーコード: 1564,口座/CIF番号エラー
     */
    public static final String BA_ERROR_CODE_1564 = "1564";

    /**
     * BAエラーコード: 2000,その他の業務エラー
     */
    public static final String BA_ERROR_CODE_2000 = "2000";

    /**
     * BA 正常200応答,利用登録可否,注意コード
     */
    public static final String BA_ERROR_CODE_1050 = "1050";

    /**
     * ekycエラーコードID : MBEK0001
     */
    public static final String EKYC_CODE_MBEK0001 = "MBEK0001";

    /**
     * ekycエラーコードID : MBEK0002
     */
    public static final String EKYC_CODE_MBEK0002 = "MBEK0002";

    /**
     * ekycエラーコードID : MBEK0003
     */
    public static final String EKYC_CODE_MBEK0003 = "MBEK0003";

    /**
     * ekycエラーコードID : MBEK0004
     */
    public static final String EKYC_CODE_MBEK0004 = "MBEK0004";

    /**
     * ekycエラーコードID : MBEK0100
     */
    public static final String EKYC_CODE_MBEK0100 = "MBEK0100";

    /**
     * ekycエラーコードID : MBEK0101
     */
    public static final String EKYC_CODE_MBEK0101 = "MBEK0101";

    /**
     * ekycエラーコードID : MBEK0102
     */
    public static final String EKYC_CODE_MBEK0102 = "MBEK0102";

    /**
     * ekycエラーコードID : MBEK0200
     */
    public static final String EKYC_CODE_MBEK0200 = "MBEK0200";

    /**
     * ekycエラーコードID : MBEK0201
     */
    public static final String EKYC_CODE_MBEK0201 = "MBEK0201";

    /**
     * ekycエラーコードID : MBEK0202
     */
    public static final String EKYC_CODE_MBEK0202 = "MBEK0202";

    /**
     * ekycエラーコードID : MBEK0203
     */
    public static final String EKYC_CODE_MBEK0203 = "MBEK0203";

    /**
     * ekycエラーコードID : MBEK0204
     */
    public static final String EKYC_CODE_MBEK0204 = "MBEK0204";

    /**
     * ekycエラーコードID : MBEK0205
     */
    public static final String EKYC_CODE_MBEK0205 = "MBEK0205";

    /**
     * ekycエラーコードID : MBEK0206
     */
    public static final String EKYC_CODE_MBEK0206 = "MBEK0206";

    /**
     * ekycエラーコードID : MBEK0300
     */
    public static final String EKYC_CODE_MBEK0300 = "MBEK0300";

    /**
     * ekycエラーコードID : MBEK0301
     */
    public static final String EKYC_CODE_MBEK0301 = "MBEK0301";

    /**
     * ekycエラーコードID : MBEK0302
     */
    public static final String EKYC_CODE_MBEK0302 = "MBEK0302";

    /**
     * ekycエラーコードID : MBEK0303
     */
    public static final String EKYC_CODE_MBEK0303 = "MBEK0303";

    /**
     * ekycエラーコードID : MBEK0400
     */
    public static final String EKYC_CODE_MBEK0400 = "MBEK0400";

    /**
     * ekycエラーコードID : MBEK0401
     */
    public static final String EKYC_CODE_MBEK0401 = "MBEK0401";

    /**
     * ekycエラーコードID : MBEK0402
     */
    public static final String EKYC_CODE_MBEK0402 = "MBEK0402";

    /**
     * ekycエラーコードID : MBEK0403
     */
    public static final String EKYC_CODE_MBEK0403 = "MBEK0403";

    /**
     * ekycエラーコードID : MBEK0404
     */
    public static final String EKYC_CODE_MBEK0404 = "MBEK0404";

    /**
     * ekycエラーコードID : MBEK0405
     */
    public static final String EKYC_CODE_MBEK0405 = "MBEK0405";

    /**
     * ekycエラーコードID : MBEK0500
     */
    public static final String EKYC_CODE_MBEK0500 = "MBEK0500";

    /**
     * ekycエラーコードID : MBEK0501
     */
    public static final String EKYC_CODE_MBEK0501 = "MBEK0501";

    /**
     * ekycエラーコードID : MBEK0502
     */
    public static final String EKYC_CODE_MBEK0502 = "MBEK0502";

    /**
     * ekycエラーコードID : MBEK0503
     */
    public static final String EKYC_CODE_MBEK0503 = "MBEK0503";

    /**
     * ekycエラーコードID : MBEK0504
     */
    public static final String EKYC_CODE_MBEK0504 = "MBEK0504";

    /**
     * ekycエラーコードID : MBEK0600
     */
    public static final String EKYC_CODE_MBEK0600 = "MBEK0600";

    /**
     * ekycエラーコードID : MBEK0601
     */
    public static final String EKYC_CODE_MBEK0601 = "MBEK0601";

    /**
     * ekycエラーコードID : MBEK0602
     */
    public static final String EKYC_CODE_MBEK0602 = "MBEK0602";

    /**
     * ekycエラーコードID : MBEK0603
     */
    public static final String EKYC_CODE_MBEK0603 = "MBEK0603";

    /**
     * ekycエラーコードID : MBEK0604
     */
    public static final String EKYC_CODE_MBEK0604 = "MBEK0604";
    
}

package jp.co.jsbank.mobile.bff.common.builder;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;

import jp.co.jsbank.mobile.bff.common.Constant;
import jp.co.jsbank.mobile.bff.common.RequestHeaderContext;
import jp.co.jsbank.mobile.bff.dto.CommonRequestBodyOfHeaderDto;
import lombok.Data;

/**
 * リクエストパラメータコンストラクタ
 */
@Data
public class ParameterBuilder {

    /**
     * 取引ID
     */
    private static final String TRANSACTION_ID = "transactionID";
    /**
     * 取引通番
     */
    private static final String TRANSACTION_SEQ_NO = "transactionSeqNo";
    /**
     * トレースID
     */
    private static final String TRACE_ID = "traceID";
    /**
     * 経路選択情報
     */
    private static final String ROUTING_INFO = "routingInfo";

    /**
     * HttpEntity
     */
    private HttpEntity<Object> requestEntity;

    /**
     * コンストラクタ
     *
     */
    public ParameterBuilder() {

    }

    /**
     * コンストラクタ
     *
     * @param requestDto リクエストDTO
     */
    public ParameterBuilder(Object requestDto) {

        this.requestEntity = new HttpEntity<Object>(requestDto, createCommonRequestHeader());
    }

    /**
     * コンストラクタ
     *
     * @param requestDto リクエストDTO
     */
    public ParameterBuilder(Object requestDto, HttpHeaders requestHeaders) {

        this.requestEntity = new HttpEntity<Object>(requestDto, requestHeaders);
    }

    /**
     * パラメータビルド
     *
     * @param requestDto リクエストDTO
     * @return リクエスト内容
     */
    public static ParameterBuilder build(Object requestDto) {

        if (requestDto instanceof RequestBodyDto) {

            ((RequestBodyDto) requestDto).setCommonRequestHeader(createRequestBody());
        }

        return new ParameterBuilder(requestDto);
    }

    /**
     * パラメータビルド
     *
     * @param requestDto リクエストDTO
     * @return リクエスト内容
     */
    public static ParameterBuilder buildLiquidEkyc(Object requestDto, HttpHeaders requestHeaders) {

        return new ParameterBuilder(requestDto, requestHeaders);
    }

    /**
     * 共通リクエストヘッダー作成
     *
     * @return 共通リクエストヘッダー
     */
    private HttpHeaders createCommonRequestHeader() {

        // ヘッダー設定
        HttpHeaders requestHeaders = new HttpHeaders();

        // 取引ID
        String transactionID = RequestHeaderContext.getInstance().getTransactionID();
        requestHeaders.add(TRANSACTION_ID, transactionID + "-" + System.nanoTime());
        // 取引通番
        requestHeaders.add(TRANSACTION_SEQ_NO, null);
        // トレースID
        requestHeaders.add(TRACE_ID, null);
        // 経路選択情報
        requestHeaders.add(ROUTING_INFO, null);

        return requestHeaders;
    }

    /**
     * 共通リクエストボディ作成
     *
     * @return 共通リクエストボディ
     */
    private static CommonRequestBodyOfHeaderDto createRequestBody() {

        // 金融機関コード
        String bankCode = Constant.FIXED_VALUE_FINANCIAL_CODE;

        // ユーザーID
        String userID = RequestHeaderContext.getInstance().getUserIdToken();

        // アプリケーションID jsbapp01（固定値）
        String applicationID = Constant.FIXED_VALUE_APPLICATION_ID;

        // クライアントID
        String clientId = Constant.FIXED_VALUE_CLIENT_ID;
        String applicationJag = RequestHeaderContext.getInstance().getApplicationId();
        // JAGのapplicationIDがJBA-Retail の場合
        if (applicationJag.equals(Constant.JBA_RETAIL)) {
            // ClientID 04:スマホ(個人向け) ===‘040000’
            clientId = Constant.FIXED_VALUE_CLIENT_ID_FOR_PERSONAL;
        } else if (applicationJag.equals(Constant.JBA_BIZZ)) {
            // ClientID 05:スマホ(法人向け)===‘050000’
            clientId = Constant.FIXED_VALUE_CLIENT_ID_FOR_CORPORATE;
        }

        // 端末ID
        String deviceId = "sm" + RequestHeaderContext.getInstance().getDeviceId().toLowerCase().replaceAll("-", "");
        // 共通リクエスト・ボディ
        CommonRequestBodyOfHeaderDto commonRequestBodyOfHeaderDto = new CommonRequestBodyOfHeaderDto();
        // 金融機関コード設定
        commonRequestBodyOfHeaderDto.setBankCode(bankCode);
        // ユーザーID設定
        commonRequestBodyOfHeaderDto.setUserID(userID);
        // アプリケーションID設定
        commonRequestBodyOfHeaderDto.setApplicationID(applicationID);
        // クライアントID設定
        commonRequestBodyOfHeaderDto.setClientID(clientId);
        // 端末ID設定
        commonRequestBodyOfHeaderDto.setDeviceID(deviceId);

        return commonRequestBodyOfHeaderDto;
    }

}

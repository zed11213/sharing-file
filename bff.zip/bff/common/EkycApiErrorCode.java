package jp.co.jsbank.mobile.bff.common;

public enum EkycApiErrorCode {
    LOCALE_ERROR("LOCAL_ERROR","エラー発生","local error happened",false),
    NET_WORK_ERROR("NET_WORK_ERROR","","",false),
    EKYC_ERROR("EKYC_ERROR", "EKYCエラー発生", "ekyc error happened", false),
    PARAMETER_ERROR_400("400","リクエストパラメータが不正","リクエストパラメータが不正",false),
    APIKEY_ERROR_401("401","認証エラー APIキー不備","API authentication error (Invalid API Key)",false),
    REQUEST_LIMIT_429("429","流量制限","Too many requests",false),
    TIME_OUT_408("408","タイムアウト","time out error",false),
    TIME_OUT_504("504","タイムアウト","time out error",false),
    SYSTEM_ERROR_503("503","システム障害","system error",false),
    SYSTEM_ERROR_500("500","システム障害","system error",false),
    SYSTEM_ERROR_502("502","システム障害","system error",false),
    CE01000_MAINTENANCE("CE01000","メンテナンス中","System in maintenace",false),
    CE00023_API_CAN_NOT_USE("CE00023","事業者設定により利用不可能なAPI","APIs that cannot be used due to business settings",false),
    CE00001_APPLICANT_ID_NOT_FOUND("CE00001","存在しない連携ID","Applicant ID is not found",false),
    CE00002_APPLICANT_ID_IS_USED("CE00002","登録済連携ID","The Applicant ID was already used",false),
    CE00003_APPLICANT_ID_CAN_NOT_USE("CE00003","再申請できないステータス","The application of designated Applicant ID cannot be resubmitted",false),
    CE00004_APPLICANT_ID_UNFINISH("CE00004","本人確認作業未完了","Newest application of designated Applicant ID is still not completed yet",false),
    CE00005_APPLICATION_UNFINISH_OR_EXPIRED("CE00005","本人確認申請が未完了もしくは申請期限切れ","Newest application of Application ID is not still not completed or is expired",false),
    CE00006_APPLICATION_RESULT_FINISH("CE00006","本人確認結果が登録済","Newest application is completed and KYC result is already registered",false),
    CE00007_PHOTO_IS_NOT_DONE("CE00007","画像取得が未実施","The photo collection is not done",false),
    CE00008_APPLICATION_IS_NOT_DONE("CE00008","本人確認申請が未完了","The KYC application is not completed yet",false),
    CE00009_APPLICATION_IS_DOING("CE00009","本人確認作業を実施中","The KYC application is in progress",false),
    CE00011_APPLICATION_EXPIRED("CE00011","本人確認申請が申請期限切る","The KYC application has expired",false),
    CE00012_UNACCEPTABLE_DOCUMENT("CE00012","利用できない本人書類","Unacceptable ID document",false),
    CE00017_OCR_VERIFICATION_NOT_DONE("CE00017","OCRもしくは自動判定処理が未実施","OCR or Verification has not been run",false),
    CE00018_APPLICANT_ID_CAN_NOT_REGISTER("CE00018","申請情報を登録できない連携ID","The application information cannot be registeded to the Applicant ID",false),
    CE00019_DOCUMENT_WITHOUT_VALUE("CE00019","返却値がない本人確認書類エラー","The document with no response value",false),
    CE00026_REGION_CODE_ERROR("CE00026","利用できない対象地域コード","Unacceptable region code",false),
    CE00029_MY_NUMBER_SCAN_UNFINISH("CE00029","個人番号の読み取りが未完了","My number scanning is not completed yet",false),
    CE00030_AUTHENTICITY_METHOD_PHOTO_ERROR("CE00030","利用できない本人容貌撮影における真贋判定方式","Authenticity methods for photographing of personal appeareance that are not available",false),
    CE00032_APPLICATION_INFO_NOT_FOUND("CE00032","申請情報未登録","the application information is not registered yet",false),
    UNKNOWN_ERROR("UNKNOWN", "予想以外のエラー", "other exceptions", false);

    private final String rawCode;
    private final String rawMessage; 
    private final String description;
    private final boolean retryable;

    EkycApiErrorCode(String rawCode, String rawMessage, String description, boolean retryable) {
        this.rawCode = rawCode;
        this.rawMessage = rawMessage;
        this.description = description;
        this.retryable = retryable;
    }

    public String getRawCode() { return rawCode; }
    public String getDescription() { return description; }
    public String getRawMessage() { return rawMessage; }
    public boolean isRetryable() { return retryable; }

    /**
     * 　エラーコード　取得
     */
    public static EkycApiErrorCode fromRawCode(String rawCode) {
        if (rawCode == null || rawCode.trim().isEmpty()) {
            return UNKNOWN_ERROR;
        }
        for (EkycApiErrorCode code : values()) {
            if (code.getRawCode().equalsIgnoreCase(rawCode)) {
                return code;
            }
        }
        return UNKNOWN_ERROR; 
    }

    public static EkycApiErrorCode getSystemError() {
        return SYSTEM_ERROR_500;
    }
    public static EkycApiErrorCode getUnknownError() {
        return UNKNOWN_ERROR;
    }
    public static EkycApiErrorCode getLocaleError() {
        return LOCALE_ERROR;
    }
    public static EkycApiErrorCode getEKycError() {
        return EKYC_ERROR;
    }
}

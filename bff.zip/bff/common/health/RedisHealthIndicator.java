package jp.co.jsbank.mobile.bff.common.health;

/**
 * Redisヘルスインジケーター
 *
 */
//@Component("redisHealthIndicator")
//public class RedisHealthIndicator implements HealthIndicator {
public class RedisHealthIndicator {

//	@Autowired
//	private RedisHandler redisHandler;
//
//	@Override
//	public Health health() {
//
//		try {
//			redisHandler.exists("test");
//			return Health.up().build();
//		} catch (Exception e) {
//			return Health.down().build();
//		}
//	}

}

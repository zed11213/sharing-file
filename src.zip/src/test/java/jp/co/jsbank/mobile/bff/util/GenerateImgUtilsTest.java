
package jp.co.jsbank.mobile.bff.util;

import jp.co.jsbank.mobile.bff.common.util.FontHolderUtils;
import jp.co.jsbank.mobile.bff.common.util.GenerateImgUtils;
import jp.co.jsbank.mobile.bff.common.util.ImgBuildParameters;

import org.junit.jupiter.api.Test;

import java.nio.file.Paths;
import java.nio.file.Files;
import java.util.Base64;
import java.awt.Font;

public class GenerateImgUtilsTest {

    @Test
    public void generateImageTest() throws Exception {

        ImgBuildParameters param = ImgBuildParameters.builder()
                // .fontSize(36)
                // .backgroundColor(Color.WHITE)
                // .textColor(Color.BLACK)
                // .lineSpacing(20)
                .build();

        String text = "こんにちは\n" + "これは画像生成テストです。\n" + "Springで利用可能です。";

        String base64 = GenerateImgUtils.textToJpegBase64(text, param);

        if (base64.contains(",")) {
            base64 = base64.substring(base64.indexOf(",") + 1);
        }

        byte[] imageBytes = Base64.getDecoder().decode(base64);

        Files.write(Paths.get("create.jpg"), imageBytes);

    }

    @Test
    public void loadFonts() throws Exception {
        Font font = FontHolderUtils.getFont(17);
        System.out.println("load local font success");
    }
}

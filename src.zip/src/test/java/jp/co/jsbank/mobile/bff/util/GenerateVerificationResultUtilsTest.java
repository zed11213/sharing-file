package jp.co.jsbank.mobile.bff.util;

import jp.co.jsbank.mobile.bff.dto.liquidekyc.EkycCommonVerificationResultDto;
import jp.co.jsbank.mobile.bff.dto.liquidekyc.EkycIdDocumentInformationResponseDto;
import jp.co.jsbank.mobile.bff.dto.liquidekyc.EkycVerificationJoinedData;
import jp.co.jsbank.mobile.bff.dto.liquidekyc.EkycVerificationResultDto;
import jp.co.jsbank.mobile.bff.dto.liquidekyc.EkycVerificationResultResponseDto;
import jp.co.jsbank.mobile.bff.common.util.GenerateVerificationResultUtils;

import org.junit.jupiter.api.Test;

import java.nio.file.Paths;
import java.nio.file.Files;
import java.util.Base64;

public class GenerateVerificationResultUtilsTest {

    @Test
    public void generateImageTest() throws Exception {

        EkycIdDocumentInformationResponseDto info = new EkycIdDocumentInformationResponseDto();
        info.setAddress("東京都清瀬市旭が丘１－１－１");
        info.setName("公的　花子");
        info.setIdDocumentType("11");
        info.setBirthday("19990401");

        EkycVerificationResultResponseDto result = new EkycVerificationResultResponseDto();
        EkycVerificationResultDto dto = new EkycVerificationResultDto();
        dto.setInjectionAttackVerification("2");
        result.setVerificationResult(dto);

        EkycCommonVerificationResultDto dto1 = new EkycCommonVerificationResultDto();
        dto1.setResult("1");
        result.setReuseFaceVerificationResult(dto1);

        EkycCommonVerificationResultDto dto2 = new EkycCommonVerificationResultDto();
        dto2.setResult("2");
        result.setReuseIdentificationInformationVerificationResult(dto2);

        EkycCommonVerificationResultDto dto3 = new EkycCommonVerificationResultDto();
        dto3.setResult("3");
        result.setWarningListFaceVerificationResult(dto3);

        EkycCommonVerificationResultDto dto4 = new EkycCommonVerificationResultDto();
        dto4.setResult("4");
        result.setWarningListIdentificationInformationVerificationResult(dto4);

        EkycVerificationJoinedData data = new EkycVerificationJoinedData();
        data.setIdDocumentInformation(info);
        data.setVerificationResult(result);

        String base64 = GenerateVerificationResultUtils.createBase64WithVerification(data);
        if (base64.isBlank() || base64 == null) {
            System.err.println("result is null");
            return;
        }

        if (base64.contains(",")) {
            base64 = base64.substring(base64.indexOf(",") + 1);
        }

        byte[] imageBytes = Base64.getDecoder().decode(base64);

        Files.write(Paths.get("create.jpg"), imageBytes);
    }

}

// カード種別：マイナンバーカード
// 氏名：公的 花子
// 生年月日：1999年4月1日
// 住所：東京都清瀬市旭が丘１－１－１
// 取得日：2025年10月01日
// インジェクション攻撃による申請判定結果：NG
// 顔の使い回し判定結果：検知あり（自社・他社データ）
// 本⼈特定事項の使い回し判定結果：検知あり（自社・他社データ）
// 警告リスト（本⼈特定事項）判定結果：検知あり（自社・他社データ）
// 警告リスト（顔）判定結果：検知あり（自社・他社データ）

package jp.co.jsbank.mobile.bff.dto;

import java.util.List;

import lombok.Data;

/**
 * 申込回答閲覧レスボスDTO
 */
@Data
public class ApplicationAnswerViewResponseDto {

    /**
     * お知らせID
     */
    private String anncmntId;

    /**
     * 申込ID
     */
    private String applyId;

    /**
     * タイトル
     */
    private String anncmntTitle;

    /**
     * 作成日時
     */
    private String createDateAndTime;
    
    /**
     * 申込み履歴日付
     */
    private String applicationHistoryDate;
   
    /**
     * 確認メッセージ受信後日付
     */
    private String confirmMessageDate;
    
    /**
     * 非会員フラグ
     */
    private String nonMemberFlg;

    /**
     * CIF番号レスト
     */
    private List<CifInfomationDto> cifNoList;

    /**
     * 顧客ID
     */
    private String customerId;

    /**
     * 利用者ID
     */
    private String userId;

    /**
     * カナ氏名
     */
    private String custNameKana;

    /**
     * 漢字氏名
     */
    private String custNameKanji;

    /**
     * 郵便番号
     */
    private String custZipCode;

    /**
     * カナ住所
     */
    private String custAddressKana;

    /**
     * 住所
     */
    private String custAddress;

    /**
     * 電話番号
     */
    private String custPhone;

    /**
     * メールアドレス
     */
    private String custMail;

    /**
     * 受付フォーマット
     */
    private String receptionFormat;

    /**
     * 店名
     */
    private String branchName;

    /**
     * 画像ファイル
     */
    private String fileStream;
    
    /**
     * ボタン種類 
     */
    private String btnType;
    
    /**
     * ボタンリンク先有無フラグ 
     */
    private String btnLinkFlg;
    
    /**
     * ボタンリンク先URL
     */
    private String btnLinkUrl;

    /**
     * 回答本文
     */
    private String responseMsg;

    /**
     * 申込確認メッセージ
     */
    private String applyConfirmMsg;
    
    /**
     * 画像有無フラグ
     */
    private String imgFlg;

    /**
     * 画像位置
     */
    private String imgVPosition;
    
    /**
     * 会場選択有無フラグ
     */
    private String  venueSelectFlg;
    
    /**
     * 掲載開始日時
     */
    private String anncmntStartDateAndTime;

    /**
     * 生年月日
     */
    private String birthday;

    /**
     * ファイルサービス申込種別
     */
    private String fileServiceApplyType;

    /**
     * リンク先申込ID
     */
    private String linkedApplyId;

    /**
     * ファイルメールアドレス（FS_APPLY_TのMAIL_ADDRESS）
     */
    private String fileMailAddress;

    /**
     * 顧客ID（FS_APPLY_Tから取得）
     */
    private String fileCustomerId;

    /**
     * 支店コード（FS_APPLY_Tから取得）
     */
    private String fileBranchCode;

}

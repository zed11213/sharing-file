package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 抽選結果明細レスポンスDTO
 */
@Data
public class LotteryResultAbaResponseDto {

    /**
     * 共通レスポンス・ヘッダ
     */
    private CommonResponseHeader commonResponseHeader;

    /**
     * 抽選結果明細DTOリスト
     */
    private List<LotteryResultsDetailsDto> lotteryResults;
    
    /**
     * 最新受領情報明細DTOリスト
     */
    private List<LatestReceipDetailsDto> latestReceiptInfo; 
}

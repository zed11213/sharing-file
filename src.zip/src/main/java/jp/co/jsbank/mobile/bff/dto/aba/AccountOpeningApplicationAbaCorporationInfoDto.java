package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import jp.co.jsbank.mobile.bff.dto.BeneficialOwnerDto;
import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import jp.co.jsbank.mobile.bff.dto.IdentityVerificationDocumentsDto;
import jp.co.jsbank.mobile.bff.dto.RepresentativeOfficerDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 口座開設申込情報（法人）ABADTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class AccountOpeningApplicationAbaCorporationInfoDto extends RequestBodyDto {
	
    /**
     * 共通レスポンス・ボディ
     */
    private CommonResponseHeader commonResponseHeader;

    /**
     * 受付番号
     */
    private String receiptNumber;

    /**
     * 顧客ID
     */
    private String customerId;

    /**
     * CIF番号
     */
    private String cifNumber;

    /**
     * 人格区分
     */
    private String personType;

    /**
     * 申込ステータス
     */
    private String applyStatus;

    /**
     * 申請開始日時
     */
    private String applyStartDateTime;

    /**
     * 申請有効期限日時
     */
    private String applyValidDateTime;

    /**
     * 利用停止フラグ
     */
    private String useSuspendFlag;

    /**
     * 取引種別
     */
    private String transactionType;

    /**
     * 会社形態
     */
    private String companyForm;

    /**
     * 会社形態（その他）
     */
    private String companyFormOther;

    /**
     * 会社形態位置
     */
    private String companyFormLocation;

    /**
     * 事業先名（カナ）
     */
    private String businessNameKana;

    /**
     * 事業先名（漢字）
     */
    private String businessNameKanji;

    /**
     * 代表者・役員リスト
     */
    private List<RepresentativeOfficerDto> ceoOfficer;

    /**
     * 代表者氏名カナ（姓）
     */
    private String ceoKanaLast;

    /**
     * 代表者氏名カナ（名）
     */
    private String ceoKanaFirst;

    /**
     * 代表者氏名漢字（姓）
     */
    private String ceoKanjiLast;

    /**
     * 代表者氏名漢字（名）
     */
    private String ceoKanjiFirst;

    /**
     * 代表者生年月日
     */
    private String ceoBirthday;

    /**
     * 代表者郵便番号
     */
    private String ceoZipCode;

    /**
     * 代表者都道府県（カナ）
     */
    private String ceoStateKana;

    /**
     * 代表者都道府県
     */
    private String ceoState;

    /**
     * 代表者市区町村（カナ）
     */
    private String ceoCityKana;

    /**
     * 代表者市区町村
     */
    private String ceoCity;

    /**
     * 代表者丁目（カナ）
     */
    private String ceoStreetKana;

    /**
     * 代表者丁目
     */
    private String ceoStreet;

    /**
     * 代表者番地（カナ）
     */
    private String ceoAddressKana;

    /**
     * 代表者番地
     */
    private String ceoAddress;

    /**
     * 代表者建物名・号室（カナ）
     */
    private String ceoBuildingKana;

    /**
     * 代表者建物名・号室
     */
    private String ceoBuilding;

    /**
     * 実質的支配者リスト
     */
    private List<BeneficialOwnerDto> substantialRuler;

    /**
     * 設立年月日
     */
    private String establishDate;

    /**
     * 資本金
     */
    private String capital;

    /**
     * 従業員人数
     */
    private String numberOfEmployees;

    /**
     * 所在地郵便番号
     */
    private String locationZipCode;

    /**
     * 所在地都道府県（カナ）
     */
    private String locationStateKana;

    /**
     * 所在地都道府県
     */
    private String locationState;

    /**
     * 所在地市区町村（カナ）
     */
    private String locationCityKana;

    /**
     * 所在地市区町村
     */
    private String locationCity;

    /**
     * 所在地丁目（カナ）
     */
    private String locationStreetKana;

    /**
     * 所在地丁目
     */
    private String locationStreet;

    /**
     * 所在地番地（カナ）
     */
    private String locationAddressKana;

    /**
     * 所在地番地
     */
    private String locationAddress;

    /**
     * 建物名・号室（カナ）
     */
    private String buildingRoomKana;

    /**
     * 建物名・号室
     */
    private String buildingRoom;

    /**
     * 本店所在地相違区分
     */
    private String headOfficeClassification;

    /**
     * 本店所在地郵便番号
     */
    private String headOfficeLocZipCode;

    /**
     * 本店所在地都道府県（カナ）
     */
    private String headOfficeLocStateKana;

    /**
     * 本店所在地都道府県
     */
    private String headOfficeLocState;

    /**
     * 本店所在地市区町村（カナ）
     */
    private String headOfficeLocCityKana;

    /**
     * 本店所在地市区町村
     */
    private String headOfficeLocCity;

    /**
     * 本店所在地丁目（カナ）
     */
    private String headOfficeLocStreetKana;

    /**
     * 本店所在地丁目
     */
    private String headOfficeLocStreet;

    /**
     * 本店所在地番地（カナ）
     */
    private String headOfficeLocAddressKana;

    /**
     * 本店所在地番地
     */
    private String headOfficeLocAddress;

    /**
     * 本店建物名・号室（カナ）
     */
    private String headOfficeLocBuildingKana;

    /**
     * 本店建物名・号室
     */
    private String headOfficeLocBuilding;

    /**
     * 電話番号種別１
     */
    private String phoneType1;

    /**
     * 自宅電話番号１（上）
     */
    private String homePhone1Top;

    /**
     * 自宅電話番号１（中）
     */
    private String homePhone1Middle;

    /**
     * 自宅電話番号１（下）
     */
    private String homePhone1Bottom;

    /**
     * 電話番号種別２
     */
    private String phoneType2;

    /**
     * 自宅電話番号２（上）
     */
    private String homePhone2Top;

    /**
     * 自宅電話番号２（中）
     */
    private String homePhone2Middle;

    /**
     * 自宅電話番号２（下）
     */
    private String homePhone2Bottom;

    /**
     * 取引目的
     */
    private String transactPurpose;

    /**
     * 取引目的（その他）
     */
    private String transactPurposeOther;

    /**
     * 取引目的（詳細）
     */
    private String transactPurposeDetail;

    /**
     * 事業内容
     */
    private String businessDescription;

    /**
     * 事業内容（その他）
     */
    private String businessDescriptionOther;

    /**
     * 取扱品目
     */
    private String handingItem;

    /**
     * 主要取引先（仕入）
     */
    private String mainlyTradePurchase;

    /**
     * 主要取引先（販売）
     */
    private String mainlyTradeSale;

    /**
     * 当金庫との取引希望
     */
    private String preferredTrade;

    /**
     * 当金庫との取引希望（その他）
     */
    private String otherBusinessWishes;

    /**
     * 取引のきっかけ
     */
    private String transactionTrigger;

    /**
     * 開設部店コード
     */
    private String openBranchCode;

    /**
     * メールアドレス
     */
    private String emailAddress;

    /**
     * 取引金融機関
     */
    private String financialInstitution;

    /**
     * 取引金融機関（預金状況）
     */
    private String financialInstitutionDepositStatus;

    /**
     * 取引金融機関（貸金状況）
     */
    private String financialInstitutionLoanStatus;

    /**
     * 代表者本人確認書類リスト
     */
    private List<IdentityVerificationDocumentsDto> identityDocuments;

    /**
     * 事業先本人確認書類リスト
     */
    private List<IdentityVerificationDocumentsDto> businessDocuments;
}

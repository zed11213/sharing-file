package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 帳票CSV内容照会_証貸変動金利通知ABAレスポンスDTO
 */
@Data
public class InquireReport013ResponseDto {

    /**
     * 帳票バージョン
     */
    private String formVersion;

    /**
     * 本状作成日
     */
    private String bookCreateDate;

    /**
     * お借入利率の変更前_日付
     */
    private String beforeUpdateDate;

    /**
     * お借入利率の変更前_利率
     */
    private String beforeUpdateRate;

    /**
     * お借入利率の変更後_日付
     */
    private String afterUpdateDate;

    /**
     * お借入利率の変更後_利率
     */
    private String afterUpdateRate;

    /**
     * 変更幅
     */
    private String changeWild;

    /**
     * 今までのお借入利率
     */
    private String nowRate;

    /**
     * 新しいお借入利率
     */
    private String newRate;

    /**
     * 取扱店名
     */
    private String branchKanjiName;

    /**
     * 取扱電話番号
     */
    private String branchPhoneNumber;
}

package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * ICカード発行依頼照会ABAレスボスDTO
 */
@Data
public class ICCardIssuingOrderInquiryAbaResponseDto {
	
    /**
     * 共通レスポンス・ヘッダ
     */
    private CommonResponseHeader commonResponseHeader;
    
}
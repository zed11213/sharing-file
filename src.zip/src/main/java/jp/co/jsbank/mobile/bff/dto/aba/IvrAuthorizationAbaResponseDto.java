package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * IVR認証ABAレスポンスDTO
 */
@Data
public class IvrAuthorizationAbaResponseDto {

    /**
     * ABA応答共通ヘッダー
     */
    private CommonResponseHeader commonResponseHeader;
    
    /**
     * 認証結果
     */
    private String authenticationResult;
}

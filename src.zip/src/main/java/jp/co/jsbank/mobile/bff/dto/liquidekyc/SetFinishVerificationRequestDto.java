package jp.co.jsbank.mobile.bff.dto.liquidekyc;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import lombok.Data;

@Data
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
/**
 *  完了処理
 * SetFinishVerificationRequestDto
 */
public class SetFinishVerificationRequestDto {
    /**
     * 連携ID
     */
     private String applicantId;
}

package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 利用者BFFリクエストDTO
 */
@Data
public class DeleteUserRequestDto {

    /**
     * ステータス
     */
    private String status;
}

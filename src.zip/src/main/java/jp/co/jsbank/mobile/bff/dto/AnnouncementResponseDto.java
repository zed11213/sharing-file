package jp.co.jsbank.mobile.bff.dto;

import java.util.List;

import lombok.Data;

/**
 * お知らせ一覧レスポンスDTO
 */
@Data
public class AnnouncementResponseDto {
	
    /**
     * お知らせ一覧DTOリスト
     */
    private List<AnnouncementDto> anncmntList;
    
    /**
     * 該当件数
     */
    private String dataCount;
}

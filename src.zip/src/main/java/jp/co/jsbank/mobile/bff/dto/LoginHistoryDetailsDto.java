package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * ログイン履歴照会DTO
 */
@Data
public class LoginHistoryDetailsDto {

    /**
     * ログイン日時
     */
    private String loginTs;
    
    /**
     * 利用者ID
     */
    private String userId;

}

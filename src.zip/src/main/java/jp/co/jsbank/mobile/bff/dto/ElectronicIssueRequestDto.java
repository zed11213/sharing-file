package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 電子交付ABAリクエストDTO
 */
@Data
public class ElectronicIssueRequestDto {

    /**
     * 帳票ID
     */
    private String reportId;

    /**
     * 文書種別コード
     */
    private String documentTypeCode;

    /**
     * 交付ステータス
     */
    private String deliveryStatus;

    /**
     * 申込ID
     */
    private String applyId;

    /**
     * お知らせ種別コード
     */
    private String anncmntType;

}

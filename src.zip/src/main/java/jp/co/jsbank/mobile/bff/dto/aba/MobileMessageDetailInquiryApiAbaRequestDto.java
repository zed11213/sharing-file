package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * モバイルメッセージ詳細照会リクエストDTO
 */
@Data
public class MobileMessageDetailInquiryApiAbaRequestDto {
	
	 /**
     * お知らせID
     */
    private String informationId;
    
	 /**
     * バージョン
     */
    private String version;
 }

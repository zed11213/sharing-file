package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 利用口座登録確認情報取得BFFリクエストDTO
 */
@Data
public class UseAccountRegistrationConfirmationRequestDto {

    /**
     * 店番
     */
    private String branchCode;
    
    /**
     * 口座番号
     */
    private String accountNumber;
    
    /**
     * 預金種目
     */
    private String accountType;
    
    /**
     * サブNo
     */
    private String accountSubNumber;
    
}

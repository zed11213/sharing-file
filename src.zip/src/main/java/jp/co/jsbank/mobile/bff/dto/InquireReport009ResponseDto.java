package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 帳票CSV内容照会_総合口座決算案内レスポンスDTO
 */
@Data
public class InquireReport009ResponseDto {
	/**
	 * 帳票バージョン
	 */
	private String formVersion;

	/**
	 * 共通作成日付
	 */
	private String comCreateDate;

	/**
	 * お知らせ文言
	 */
	private String notificationValue;

	/**
	 * 文言１１
	 */
	private String value11;

	/**
	 * 文言２１
	 */
	private String value21;

	/**
	 * 文言３１
	 */
	private String value31;

	/**
	 * 文言３２
	 */
	private String value32;

	/**
	 * 決算日の残高_普通預金
	 */
	private String balanceOnClosingDateOrdinaryDeposit;

	/**
	 * 決算日の残高_お借入
	 */
	private String balanceOnClosingDateBorrowing;

	/**
	 * お利息
	 */
	private String interestAmount;

	/**
	 * お利息の内訳_総合口座
	 */
	private String breakdownOfInterestGeneralAccount;

	/**
	 * お利息の内訳_カードローン
	 */
	private String breakdownOfInterestCardLoan;

	/**
	 * お利息差引後の残高_普通預金
	 */
	private String balanceAfterInterestDeductionOrdinaryDeposit;

	/**
	 * お利息差引後の残高_お借入
	 */
	private String balanceAfterInterestDeductionBorrowing;

	/**
	 * お借入限度超過額
	 */
	private String overBorrowingLimit;

	/**
	 * 取扱店名
	 */
	private String branchKanjiName;

	/**
	 * 取扱電話番号
	 */
	private String branchPhoneNumber;
}

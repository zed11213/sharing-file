
package jp.co.jsbank.mobile.bff.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import org.springframework.beans.factory.annotation.Value;

/**
 * Ekyc SDK client 管理。
 *
 */

@Configuration
public class EkycClientConfig {

    @Value("${liquid_ekyc_connector_api_key}")
    private String liquidApiKey;

    private final String HEADER_EKYC_API_KEY = "X-Ekyc-Api-Key";

    @Bean("ekycSdkClient") 
    public EkycSdkClient ekycSdkClient() {
        return new EkycSdkClient(HEADER_EKYC_API_KEY, liquidApiKey);
    }
}





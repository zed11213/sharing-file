package jp.co.jsbank.mobile.bff.dto;
import lombok.Data;

/**
 * 残高情報DTO
 */
@Data
public class SettingInfosDto {

    /**
     * 設定種別
     */
    private String settingType;

    /**
     * 設定区分
     */
    private String settingDivision;

    /**
     * 設定値
     */
    private String settingContent;

}

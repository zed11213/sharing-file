package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 通帳レス設定ABAリクエストDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class PassbooklesSettingAbaRequestDto extends RequestBodyDto {
    
    /**
     * CIF番号
     */
    private String cifNo;

    /**
     * 店番
     */
    private String branchNumber;
}

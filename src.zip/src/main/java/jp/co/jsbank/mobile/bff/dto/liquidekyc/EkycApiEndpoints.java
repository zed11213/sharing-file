package jp.co.jsbank.mobile.bff.dto.liquidekyc;

import org.springframework.web.util.UriComponentsBuilder;

/**
 * Ekyc API URL 
 */
public final class EkycApiEndpoints {

    private  EkycApiEndpoints()  {}


    /**
     *  トークン取得
     */
    public static final String GET_TOKEN =  "/v1/sdk/applications";

    /**
     * 申請情報登録
     */
    public static final String KYC_REQUEST_INFORMATION =  "/v1/kyc_request_informations";

    /**
     * 画像データ取得
     */
    public static final String GET_PHOTOS =  "/v1/applicants/{applicantId}/photos";

    /**
     * 自動判定結果取得
     */
    public static final String VERIFICATION_RESULTS = "/v1/applicants/{applicantId}/verification_results";

    /**
     * ICカード読取情報取得
     */
    public static final String GET_ID_DOCUMENT_INFORMATION = "/v1/applicants/{applicantId}/id_document_ic_information";

    /**
     * 本人確認登録結果
     */
    public static final String KYC_RESULT =  "/v1/kyc_results";

    /**
     * create the request full url with path and parameters;
     */
    public static final String buildFullUrl(String baseUrl, String path, Object... uriVariables) {
        return UriComponentsBuilder.fromHttpUrl(baseUrl)
                .path(path)
                .buildAndExpand(uriVariables) 
                .toUriString();
    }
}

package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * IVR送信レスポンスDTO
 */
@Data
public class IvrSendingResponseDto {

	/**
	 * 利用者IDトークン
	 *
	 */
	private String userIdToken;

	/**
	 * 顧客IDトークン
	 */
	private String customerIdToken;

	/**
	 * IVRスキップフラグ「1：スキップ、0：スキップしない」
	 */
	private String ivrSkipFlag;
}

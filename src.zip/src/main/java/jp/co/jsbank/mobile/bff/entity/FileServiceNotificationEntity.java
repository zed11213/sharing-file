package jp.co.jsbank.mobile.bff.entity;

import javax.persistence.Column;
import javax.persistence.Table;

import lombok.Data;

/**
 * FS_NOTIFICATION_Tエンティティ
 */
@Data
@Table(name = "FS_NOTIFICATION_T")
public class FileServiceNotificationEntity {

    @Column(name = "BANK_CODE")
    private String bankCode;

    @Column(name = "APPLICATION_ID")
    private String applicationId;
    
    @Column(name = "SERIAL_NUMBER")
    private String serialNumber;

    @Column(name = "QUERY_ID")
    private String queryId;

    @Column(name = "STATUS")
    private String status;
}

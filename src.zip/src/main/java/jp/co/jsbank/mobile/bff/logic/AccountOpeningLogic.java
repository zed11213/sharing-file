package jp.co.jsbank.mobile.bff.logic;

import org.springframework.stereotype.Service;

import jp.co.jsbank.mobile.bff.dto.BranchStoreAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.AccountOpenAppliContentInquiryCorporationAbaReponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.AccountOpenAppliContentInquiryIndividualAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.AccountOpenAppliContentInquiryIndividualAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.AccountOpenAppliContentInquirySelfempAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.AccountOpenAppliContentRegistrationIndividualAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.AccountOpenAppliContentUpdateCorporationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.AccountOpenAppliContentUpdateIndividualAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.AccountOpenAppliContentUpdateSelfempAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.AddressInfomationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.AddressInfomationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.ApplicationCompleteAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.BizAddressInfomationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.BizHomeInfomationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.BizHomeInfomationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.BranchOfficeListInquiryAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CommonHeaderAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.ContractManagementOperationHistoryAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.ContractManagementOperationHistoryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.DepartmentStoreAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.DepartmentStoreAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.HeadOfficeAddressInformationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.IndividualAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.PostalCodeAddressInquiryAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.PostalCodeAddressInquiryAbaResponseDto;

/**
 * 新規口座開設ロジック
 */
@Service
public interface AccountOpeningLogic {

    /**
     * 契約管理操作履歴照会
     *
     * @param requestDto 契約管理操作履歴ABAリクエストDTO
     * @return 契約管理操作履歴情報
     */
    ContractManagementOperationHistoryAbaResponseDto
            contractManagementOperationHistoryInquiry(ContractManagementOperationHistoryAbaRequestDto requestDto);

    /**
     * 口座開設申込内容照会（法人）
     *
     * @param requestDto 口座開設申込内容照会ABAリクエストDTO
     * @return 口座開設申込情報（法人）
     */
    AccountOpenAppliContentInquiryCorporationAbaReponseDto
            accountOpenAppliCorporateInquiry(AccountOpenAppliContentInquiryIndividualAbaRequestDto requestDto);

    /**
     * 口座開設申込内容照会（個人事業主）
     *
     * @param requestDto 口座開設申込内容照会ABAリクエストDTO
     * @return 口座開設申込情報（個人事業者）
     */
    AccountOpenAppliContentInquirySelfempAbaResponseDto accountOpenAppliContentSoleProprietorInquiry(
            AccountOpenAppliContentInquiryIndividualAbaRequestDto requestDto);

    /**
     * 口座開設申込内容照会（個人）
     *
     * @param requestDto 口座開設申込内容照会ABAリクエストDTO
     * @return 口座開設申込情報（個人）
     */
    AccountOpenAppliContentInquiryIndividualAbaResponseDto
            accountOpenAppliContentIndividualInquiry(AccountOpenAppliContentInquiryIndividualAbaRequestDto requestDto);

    /**
     * 口座開設申込内容更新（個人）
     *
     * @param requestDto 口座開設申込情報（個人）ABAリクエストDTO
     * @return 共通レスポンスヘッダー
     */
    CommonHeaderAbaResponseDto
            accountOpenAppliContentIndividualUpdate(AccountOpenAppliContentUpdateIndividualAbaRequestDto requestDto);

    /**
     * 口座開設申込内容更新（法人）
     *
     * @param requestDto 口座開設申込情報（法人）ABAリクエストDTO
     * @return 共通レスポンスヘッダー
     */
    CommonHeaderAbaResponseDto
            accountOpenAppliContentCorporationUpdate(AccountOpenAppliContentUpdateCorporationAbaRequestDto requestDto);

    /**
     * 口座開設申込内容更新（個人事業主）
     *
     * @param requestDto 口座開設申込情報（個人事業主）ABAリクエストDTO
     * @return 共通レスポンスヘッダー
     */
    CommonHeaderAbaResponseDto
            accountOpenAppliContentSelfempUpdate(AccountOpenAppliContentUpdateSelfempAbaRequestDto requestDto);

    /**
     * 営業地区部店一覧照会
     *
     * @param departmentStoreAbaRequestDto 郵便番号
     * @return 部店リストレスポンスDTO
     */
    DepartmentStoreAbaResponseDto
            salesAreaDepartmentStoreInquiry(DepartmentStoreAbaRequestDto departmentStoreAbaRequestDto);

    /**
     * 口座開設申込内登録（個人）
     *
     * @param requestDto 口座開設申込内容登録（個人）ABAリクエストDTO
     * @return 共通レスポンスヘッダー
     */
    IndividualAbaResponseDto accountOpenAppliIndividualContentRegistration(
            AccountOpenAppliContentRegistrationIndividualAbaRequestDto requestDto);

    /**
     * 所在地情報保存
     *
     * @param requestDto 所在地情報保存ABAリクエストDTO
     * @return 共通レスポンス・ボディ
     */
    AddressInfomationAbaResponseDto saveAddressInfomation(AddressInfomationAbaRequestDto requestDto);

    /**
     * 本店所在地情報保存
     *
     * @param abaRequestDto 本店所在地情報ABAリクエストDTO
     * @return 処理結果
     */
    CommonHeaderAbaResponseDto
            saveHeadOfficeAddressInformation(HeadOfficeAddressInformationAbaRequestDto abaRequestDto);

    /**
     * biz所在地情報保存
     *
     * @param abaRequestDto biz所在地情報ABAリクエストDTO
     * @return 処理結果
     */
    CommonHeaderAbaResponseDto saveBizAddressInformation(BizAddressInfomationAbaRequestDto abaRequestDto);

    /**
     * biz自宅情報保存
     *
     * @param abaRequestDto biz自宅情報ABAリクエストDTO
     * @return 共通レスポンス・ボディ
     */
    BizHomeInfomationAbaResponseDto saveBizHomeInformation(BizHomeInfomationAbaRequestDto abaRequestDto);

    /**
     * 申込完了
     *
     * @param abaRequestDto 申込完了ABAリクエストDTO
     * @return 処理結果
     */
    CommonHeaderAbaResponseDto accountOpeningApplicationInformation(ApplicationCompleteAbaRequestDto abaRequestDto);

    /**
     * 郵便番号住所照会
     *
     * @param postalCodeRequestDto 郵便番号住所リクエストDTO
     * @return 郵便番号住所レスポンスDTO
     */
    PostalCodeAddressInquiryAbaResponseDto
            postalCodeAddressInquiry(PostalCodeAddressInquiryAbaRequestDto postalCodeRequestDto);

    /**
     * 営業地区部店一覧照会
     *
     * @param branchOfficeListInquiryAbaRequestDto 支店一覧照会リクエストDTO
     * @return 営業地区部店一覧照会レスポンスDTO
     */
    BranchStoreAbaResponseDto
            branchOfficeListInquiry(BranchOfficeListInquiryAbaRequestDto branchOfficeListInquiryAbaRequestDto);

}

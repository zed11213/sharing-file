package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 利用者属性更新DTO
 */
@Data
public class UserAttributeupdateRequestDto {
	
    /**
     * 設定値
     */
    private String settingContent;
}

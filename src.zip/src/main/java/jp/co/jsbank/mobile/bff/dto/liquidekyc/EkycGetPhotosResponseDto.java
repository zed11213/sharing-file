package jp.co.jsbank.mobile.bff.dto.liquidekyc;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import java.util.List;

import lombok.Data;

/**
 * 画像データ取得したレスポンスDTO
 */
@Data
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class EkycGetPhotosResponseDto {
    /**
     * 顔正面画像
     */
    private EkycCommonPhotoDto faceFrontPhoto; 
    /**
     * 本人確認書類画像
     */
    private List<EkycPhotosInformationDto> idDocumentPhotos;
    
}


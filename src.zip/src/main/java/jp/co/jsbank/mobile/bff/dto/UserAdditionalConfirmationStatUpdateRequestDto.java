package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 利用者追加確認ステータス更新BFFリクエストDTO
 */
@Data
public class UserAdditionalConfirmationStatUpdateRequestDto {

	/**
	 * 顧客ID
	 */
	private String customerId;

	/**
	 * 利用者ID
	 */
	private String userId;

    /**
     * 事業先利用者認証キー
     */
    private String certKey;

	/**
	 * 利用者承認削除区分(0：承認、1：削除)
	 */
	private String userAddDeleteType;

}

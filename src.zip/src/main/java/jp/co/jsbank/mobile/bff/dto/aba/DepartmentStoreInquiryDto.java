package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * 部店照会DTO
 */
@Data
public class DepartmentStoreInquiryDto {

    /**
     * 店番
     */
    private String branchNumber;

    /**
     * 店名（漢字）
     */
    private String branchKanjiName;
}

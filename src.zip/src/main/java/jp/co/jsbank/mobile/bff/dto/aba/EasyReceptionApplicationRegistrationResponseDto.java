package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * かんたん受付申込登録レスボスDTO
 */
@Data
public class EasyReceptionApplicationRegistrationResponseDto {

    /**
     * 共通レスポンス・ヘッダ
     */
    private CommonResponseHeader commonResponseHeader;
    
    /**
     * 申込ID
     */
    private String applyId;

}

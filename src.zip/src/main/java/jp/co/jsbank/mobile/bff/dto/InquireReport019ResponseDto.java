package jp.co.jsbank.mobile.bff.dto;

import java.util.List;

import lombok.Data;

/**
 * 帳票CSV内容照会_融資返済明細表レスポンスDTO
 */
@Data
public class InquireReport019ResponseDto {

    /**
     * 帳票バージョン
     */
    private String formVersion;

    /**
     * 本状作成日
     */
    private String bookCreateDate;

    /**
     * 店番
     */
    private String branchNumber;

    /**
     * 口座番号
     */
    private String accountNumber;

    /**
     * 融資日
     */
    private String loanDate;

    /**
     * 融資額
     */
    private String loanAmount;

    /**
     * 毎回返済分
     */
    private String repaymentAmountForEachPayment;

    /**
     * ボーナス分返済分
     */
    private String bonusRepayment;

    /**
     * 融資期日
     */
    private String efficientLoanDate;

    /**
     * 融資期間
     */
    private String loanPeriod;

    /**
     * 返済日
     */
    private String paymentDate;

    /**
     * 年利率
     */
    private String yearInterest;

    /**
     * 毎回返済額
     */
    private String repaymentAmountEachTime;

    /**
     * ボーナス分返済額
     */
    private String bonusRepaymentAmount;

    /**
     * ボーナス返済月
     */
    private String bonusRepaymentMonth;

    /**
     * 第１回利払日
     */
    private String firstInterestPaymentDate;

    /**
     * 第１回返済予定日
     */
    private String firstExpectedRepaymentDate;

    /**
     * 自動振替口座番号
     */
    private String transferAccountNumber;

    /**
     * お借入金のご返済明細表リスト
     */
    private List<BorrowingRepaymentDto> borrowingRepaymentList;

    /**
     * 取扱店名
     */
    private String branchKanjiName;

    /**
     * 取扱電話番号
     */
    private String branchPhoneNumber;
}

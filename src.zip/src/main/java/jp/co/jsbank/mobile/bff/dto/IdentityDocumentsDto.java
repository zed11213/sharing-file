package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 本人確認書類Dto
 */
@Data
public class IdentityDocumentsDto {

    /**
     * 書類種類
     */
    private String documentsType;
    
    /**
     * エンドポイント
     */
    private String endPoint;
    
    /**
     * バケット
     */
    private String bucket;
 
    /**
     * オブジェクトパス
     */
    private String objectPath;
}

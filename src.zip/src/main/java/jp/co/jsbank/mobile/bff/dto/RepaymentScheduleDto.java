package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * ご返済予定表DTO
 */
@Data
public class RepaymentScheduleDto {

    /**
     * 約定払込年月日
     */
    private String contractPaymentDate;

    /**
     * お払込金額
     */
    private String paymentAmount;

    /**
     * 残高
     */
    private String balance;

    /**
     * お利息
     */
    private String interestAmount;

    /**
     * ボーナス分お払込金額
     */
    private String bonusPaymentAmount;

    /**
     * ボーナス分残高
     */
    private String bonusBalance;

    /**
     * ボーナス分_お利息
     */
    private String bonusInterest;

    /**
     * 合計残高
     */
    private String totalBalance;
}

package jp.co.jsbank.mobile.bff.dto;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.aba.NotificationDepositDetailsDto;
import lombok.Data;

/**
 * 通知預金明細レスポンスDTO
 */
@Data
public class NotificationDepositDetailsResponseDto {

	/**
	 * 口座番号
	 */
	private String accountNumber;

	/**
	 * 店番
	 */
	private String branchNumber;

	/**
	 * 通知預金明細DTOリスト
	 */
	private List<NotificationDepositDetailsDto> noticeDepositList;
}

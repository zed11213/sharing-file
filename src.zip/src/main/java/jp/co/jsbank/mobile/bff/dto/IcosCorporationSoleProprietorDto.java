package jp.co.jsbank.mobile.bff.dto;

import java.util.List;

import lombok.Data;

/**
 * 口座開設申込内容DTO
 */
@Data
public class IcosCorporationSoleProprietorDto {

    /**
     * 受付番号
     */
    private String receiptNumber;
    
    /**
     * 本人確認書類リスト
     */
    private List<IdentityVerificationDocumentsDto> identityDocuments;
}

package jp.co.jsbank.mobile.bff.twilio;

import java.util.Arrays;
import java.util.Collection;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpHeaders;
import org.apache.http.HttpHost;
import org.apache.http.client.RedirectStrategy;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.config.SocketConfig;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultRedirectStrategy;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicHeader;

import com.twilio.Twilio;

public class HttpClientFactory {
    /** クラス名 */
    protected static final String CLASS_NAME = HttpClientFactory.class.getName();

    public static final int CONNECTION_TIMEOUT = 10000;
    public static final int SOCKET_TIMEOUT = 30500;
    public static final RequestConfig DEFAULT_REQUEST_CONFIG = RequestConfig.custom()
            .setConnectTimeout(CONNECTION_TIMEOUT).setSocketTimeout(SOCKET_TIMEOUT).build();
    public static final SocketConfig DEFAULT_SOCKET_CONFIG = SocketConfig.custom().setSoTimeout(SOCKET_TIMEOUT).build();
    private static RedirectStrategy redirectStrategy = new DefaultRedirectStrategy(new String[0]);


    public static RequestConfig createRequestConfig(String twilioProxyServerUri) {
        // クラス名＋メソッド名
        RequestConfig proxyRequestConfig = DEFAULT_REQUEST_CONFIG;
        if (!StringUtils.isBlank(twilioProxyServerUri)) {
            try {
                HttpHost proxyHost = HttpHost.create(twilioProxyServerUri);

                proxyRequestConfig = RequestConfig.custom() // カスタマイズ設定
                        .setConnectTimeout(CONNECTION_TIMEOUT) // コネクション・タイムアウト
                        .setSocketTimeout(SOCKET_TIMEOUT) // ソケット・タイムアウト
                        .setProxy(proxyHost) // プロクシー
                        .build();
            } catch (IllegalArgumentException ex) {
                throw ex;
            }
        }
        return proxyRequestConfig;
    }

    public static CloseableHttpClient buildHttpClient(String twilioProxyServerUri) {
        RequestConfig requestConfig = createRequestConfig(twilioProxyServerUri);
        return buildHttpClient(requestConfig, DEFAULT_SOCKET_CONFIG);
    }

    public static CloseableHttpClient buildHttpClient(RequestConfig requestConfig, SocketConfig socketConfig) {
        Collection<BasicHeader> headers = Arrays.asList(new BasicHeader("X-Twilio-Client", "java-" + Twilio.VERSION),
                new BasicHeader(HttpHeaders.USER_AGENT,
                        "twilio-java/" + Twilio.VERSION + " (" + Twilio.JAVA_VERSION + ")"),
                new BasicHeader(HttpHeaders.ACCEPT, "application/json"),
                new BasicHeader(HttpHeaders.ACCEPT_ENCODING, "utf-8"));

        String googleAppEngineVersion = System.getProperty("com.google.appengine.runtime.version");
        boolean isGoogleAppEngine = googleAppEngineVersion != null && !googleAppEngineVersion.isEmpty();

        org.apache.http.impl.client.HttpClientBuilder clientBuilder = HttpClientBuilder.create();

        if (!isGoogleAppEngine) {
            clientBuilder.useSystemProperties();
        }

        PoolingHttpClientConnectionManager connectionManager = new PoolingHttpClientConnectionManager();
        connectionManager.setDefaultSocketConfig(socketConfig);
        connectionManager.setDefaultMaxPerRoute(10);
        connectionManager.setMaxTotal(10 * 2);

        CloseableHttpClient client = clientBuilder.setConnectionManager(connectionManager)
                .setDefaultRequestConfig(requestConfig) // リクエスト・コンフィグ設定
                .setDefaultHeaders(headers) // ディフォルトヘッダー
                .setRedirectStrategy(redirectStrategy) // レダイレクト
                .build();
        return client;
    }
}
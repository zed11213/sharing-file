package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * メールアドレス登録リクエストDTO
 */
@Data
public class EmailAddressRegistrationResponseDto {

    /**
     * トランザクションコード
     */
    private String transactionCode;

}

package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 入出金明細情報(流動性預金)レスポンスDTO
 */
@Data
public class LiquidityDepositDetailsAbaResponseBody {


    /**
     * 共通レスポンス・ボディ
     */
    private CommonResponseHeader commonResponseBody;

    /**
     * 明細継続フラグ
     */
    private boolean detailContinuationFlag;

    /**
     * 継続明細ID
     */
    private String continuationDetailId;

    /**
     * 入出金明細情報(流動性預金)DTOリスト
     */
    private List<LiquidityDepositDetailsDto> liquidityDepositDetailsDtoList;

}

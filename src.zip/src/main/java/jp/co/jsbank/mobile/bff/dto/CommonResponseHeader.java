package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 共通レスポンスヘッダー
 */
@Data
public class CommonResponseHeader {

    /**
     * エラー・コード
     */
    private String errorCode;

    /**
     * エラー・メッセージ
     */
    private String errorMessage;

    /**
     * ユーザー・カスタマイズ可能フィールド
     */
    private String userString;

    /**
     * ユーザー・カスタマイズ可能マップ
     */
    private Object userMap;
}

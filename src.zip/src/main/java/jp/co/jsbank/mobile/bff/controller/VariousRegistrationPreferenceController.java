package jp.co.jsbank.mobile.bff.controller;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import jp.co.jsbank.mobile.bff.common.JsonResult;
import jp.co.jsbank.mobile.bff.dto.AccountInfoResponseDto;
import jp.co.jsbank.mobile.bff.dto.AccountInformationRequestDto;
import jp.co.jsbank.mobile.bff.dto.AccountInformationResponseDto;
import jp.co.jsbank.mobile.bff.dto.AuthenticationKeyIssuanceResponseDto;
import jp.co.jsbank.mobile.bff.dto.CancellationAccountDeleteRequestDto;
import jp.co.jsbank.mobile.bff.dto.CertificateKeyRequestDto;
import jp.co.jsbank.mobile.bff.dto.CifInfomationResponseDto;
import jp.co.jsbank.mobile.bff.dto.DeleteUseAccountRequestDto;
import jp.co.jsbank.mobile.bff.dto.EmailAddRegistrationRequestDto;
import jp.co.jsbank.mobile.bff.dto.EmailAddressRegistrationResponseDto;
import jp.co.jsbank.mobile.bff.dto.NotificationSettingRequestDto;
import jp.co.jsbank.mobile.bff.dto.NotificationSettingResponseDto;
import jp.co.jsbank.mobile.bff.dto.PassbooklessSettingRequestDto;
import jp.co.jsbank.mobile.bff.dto.PassbooklessSettingResponseDto;
import jp.co.jsbank.mobile.bff.dto.UseAccountRegistrationConfirmationRequestDto;
import jp.co.jsbank.mobile.bff.dto.UseAccountRegistrationRequestDto;
import jp.co.jsbank.mobile.bff.dto.UserAdditionalConfirmationStatUpdateRequestDto;
import jp.co.jsbank.mobile.bff.dto.UserAttributeInquiryConfirmationResponseDto;
import jp.co.jsbank.mobile.bff.dto.UserAttributeupdateRequestDto;
import jp.co.jsbank.mobile.bff.dto.UserInformationDetailsResponseDto;
import jp.co.jsbank.mobile.bff.service.VariousRegistrationPreferenceService;

/**
 * 各種登録設定コントロール
 */
@RestController
public class VariousRegistrationPreferenceController {

    @Resource
    private VariousRegistrationPreferenceService variousRegistrationPreferenceService;

    /**
     * 通知設定情報取得
     *
     * @return 通知設定情報
     */
    @PostMapping(path = "/various-registration-preference/AB1101")
    public String getNotificationSetting() {

        NotificationSettingResponseDto responseDto = variousRegistrationPreferenceService.getNotificationSetting();

        return JsonResult.success(responseDto);
    }

    /**
     * 通知設定情報変更
     *
     * @param requestDto 通知設定BFFリクエストDTO
     * @return JsonResult
     */
    @PutMapping(path = "/various-registration-preference/AB1102")
    public String changeNotificationSettingInfo(@RequestBody NotificationSettingRequestDto requestDto) {

        String result = variousRegistrationPreferenceService.changeNotificationSettingInfo(requestDto);

        return JsonResult.success(result);
    }

    /**
     * 利用口座削除
     *
     * @param requestDto 利用口座登録BFFリクエストDTO
     * @return JsonResult
     */
    @PutMapping(path = "/various-registration-preference/AB1103")
    public String deleteUseAccount(@RequestBody DeleteUseAccountRequestDto requestDto) {

        String result = variousRegistrationPreferenceService.deleteUseAccount(requestDto);

        return JsonResult.success(result);
    }

    /**
     * 利用口座登録
     *
     * @param requestDto 利用口座登録BFFリクエストDTO
     * @return JsonResult
     */
    @PutMapping(path = "/various-registration-preference/AB1104")
    public String useAccountRegistration(@RequestBody UseAccountRegistrationRequestDto requestDto) {

        String result = variousRegistrationPreferenceService.useAccountRegistration(requestDto);

        return JsonResult.success(result);
    }

    /**
     * デザイン取得
     *
     * @return JsonResult
     */
    @PostMapping(path = "/various-registration-preference/AB1105")
    public String getDesignInfomation() {

        String configuredDesign = variousRegistrationPreferenceService.getDesignInfomation();

        return JsonResult.success(configuredDesign);
    }

    /**
     * デザイン更新
     *
     * @param requestDto デザイン更新BFFリクエストDTO
     * @return JsonResult
     */
    @PostMapping(path = "/various-registration-preference/AB1106")
    public String updateDesignInfomation(@RequestBody UserAttributeupdateRequestDto requestDto) {

        String result = variousRegistrationPreferenceService.updateDesignInfomation(requestDto);

        return JsonResult.success(result);
    }

    /**
     * メールアドレス変更
     *
     * @param requestDto メールアドレス変更リクエストDTO
     * @return JsonResult
     */
    @PutMapping(path = "/various-registration-preference/AB1107")
    public String emailAddressChanging(@RequestBody EmailAddRegistrationRequestDto requestDto) {

        EmailAddressRegistrationResponseDto responseDto = variousRegistrationPreferenceService
                .emailAddressChanging(requestDto);

        return JsonResult.success(responseDto);
    }

    /**
     * メールアドレス登録
     *
     * @param requestDto メールアドレス登録BFFリクエストDTO
     * @return JsonResult
     */
    @PostMapping(path = "/various-registration-preference/AB1108")
    public String emailAddressRegistration(@RequestBody EmailAddRegistrationRequestDto requestDto) {

        String result = variousRegistrationPreferenceService.emailAddressRegistration(requestDto);

        return JsonResult.success(result);
    }

    /**
     * 法人利用者情報一覧取得
     *
     * @return 利用者情報
     */
    @PostMapping(path = "/various-registration-preference/AB1109")
    public String getJuridicalPersonUserDetails() {

        // 利用者情報を取得する
        UserInformationDetailsResponseDto responseDto = variousRegistrationPreferenceService
                .getJuridicalPersonUserDetails();
        return JsonResult.success(responseDto);
    }

    /**
     * 利用者登録と認証キー発行
     *
     * @param requestDto 利用者情報
     * @return 認証キー発行情報
     */
    @PostMapping(path = "/various-registration-preference/AB1110")
    public String authenticationKeyIssuance(@RequestBody CertificateKeyRequestDto requestDto) {

        AuthenticationKeyIssuanceResponseDto responseDto = variousRegistrationPreferenceService
                .authenticationKeyIssuance(requestDto);

        return JsonResult.success(responseDto);
    }

    /**
     * 利用者追加確認ステータス更新
     *
     * @param requestDto 利用者追加確認ステータス更新BFFリクエストDTO
     * @return JsonResult
     */
    @PostMapping(path = "/various-registration-preference/AB1111")
    public String userAdditionalConfirmationStatUpdate(
            @RequestBody UserAdditionalConfirmationStatUpdateRequestDto requestDto) {

        String result = variousRegistrationPreferenceService.userAdditionalConfirmationStatUpdate(requestDto);

        return JsonResult.success(result);
    }

    /**
     * 取引停止
     *
     * @return JsonResult
     */
    @PostMapping(path = "/various-registration-preference/AB1112")
    public String tradingStop() {

        String responseDto = variousRegistrationPreferenceService.tradingStop();

        return JsonResult.success(responseDto);
    }

    /**
     * 利用口座登録確認情報取得
     *
     * @param requestDto 利用口座登録確認情報取得BFFリクエストDTO
     * @return 利用口座登録確認情報
     */
    @PostMapping(path = "/various-registration-preference/AB1113")
    public String
            useAccountRegistrationConfirmation(@RequestBody UseAccountRegistrationConfirmationRequestDto requestDto) {
        // 店番
        String branchCode = requestDto.getBranchCode();
        // 口座番号)
        String accountNumber = requestDto.getAccountNumber();
        // 預金種目
        String accountType = requestDto.getAccountType();
        // サブNo
        String accountSubNumber = requestDto.getAccountSubNumber();
        UserAttributeInquiryConfirmationResponseDto result = variousRegistrationPreferenceService
                .getUseAccountRegistrationConfirmation(branchCode, accountNumber, accountType, accountSubNumber);

        return JsonResult.success(result);
    }

    /**
     * CIF情報取得
     *
     * @return CIF情報
     */
    @PostMapping(path = "/various-registration-preference/AB1114")
    public String getCifInfomation() {

        // CIF情報取得
        CifInfomationResponseDto responseDto = variousRegistrationPreferenceService.getCifInfomation();

        return JsonResult.success(responseDto);
    }

    /**
     * 口座情報取得
     *
     * @param requestDto 口座情報取得BFFリクエストDTO
     * @return 口座情報
     */
    @PostMapping(path = "/various-registration-preference/AB1115")
    public String getAccountInformation(@RequestBody AccountInformationRequestDto requestDto) {
        // 店番
        String branchCode = requestDto.getBranchCode();
        // CIF番号
        String cifNo = requestDto.getCifNo();

        // 口座属性照会情報を取得する
        AccountInformationResponseDto responseDto = variousRegistrationPreferenceService
                .getAccountInformation(branchCode, cifNo);

        return JsonResult.success(responseDto);
    }

    /**
     * 通帳レス情報取得
     *
     * @return 通帳レス情報
     */
    @PostMapping(path = "/various-registration-preference/AB1116")
    public String getPassBooklessInformation() {
        PassbooklessSettingResponseDto result = variousRegistrationPreferenceService.getPassBooklessInformation();
        return JsonResult.success(result);
    }

    /**
     * 通帳レス設定
     *
     * @param requestDto 通帳レス情報BFFリクエストDTO
     * @return JsonResult
     */
    @PostMapping(path = "/various-registration-preference/AB1117")
    public String passBooklessSetting(@RequestBody PassbooklessSettingRequestDto requestDto) {
        String result = variousRegistrationPreferenceService.passBooklessSetting(requestDto);
        return JsonResult.success(result);
    }

    /**
     * 解約口座一覧取得
     *
     * @return JsonResult
     */
    @PostMapping(path = "/various-registration-preference/AB1118")
    public String cancellationAccountListAcquisition() {
        List<AccountInfoResponseDto> result = variousRegistrationPreferenceService.cancellationAccountListAcquisition();
        return JsonResult.success(result);
    }

    /**
     * 解約口座删除
     *
     * @param requestDto 解約口座删除リクエストDTOBFFリクエストDTO
     * @return JsonResult
     */
    @PostMapping(path = "/various-registration-preference/AB1119")
    public String cancellationAccountDelete(@RequestBody CancellationAccountDeleteRequestDto requestDto) {
        String result = variousRegistrationPreferenceService.cancellationAccountDelete(requestDto);
        return JsonResult.success(result);
    }
}

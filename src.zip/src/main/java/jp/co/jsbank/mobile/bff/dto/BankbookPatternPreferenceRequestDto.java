package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 通帳パターン設定リクエストDTO
 */
@Data
public class BankbookPatternPreferenceRequestDto {

    /**
     * 通帳パターン
     */
    private String bankbookPattern;
}

package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * デザイン更新BFFリクエストDTO
 */
@Data
public class UpdateDesignInfomationRequestDto {

    /**
     * 設定値
     */
    private String settingContent;
}

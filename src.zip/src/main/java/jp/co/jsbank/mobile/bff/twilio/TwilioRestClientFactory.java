package jp.co.jsbank.mobile.bff.twilio;

import org.apache.http.client.config.RequestConfig;

import com.twilio.http.NetworkHttpClient;
import com.twilio.http.TwilioRestClient;

/**
 * twilio
 */
public class TwilioRestClientFactory {

	/** クラス名 */
	protected static final String CLASS_NAME = TwilioRestClientFactory.class.getName();

	public static final int CONNECTION_TIMEOUT = 10000;
	public static final int SOCKET_TIMEOUT = 30500;

	/**
	 * コンストラクター
	 *
	 */
	public TwilioRestClientFactory() {
	}

	/**
	 * Twilioクライアントを作成
	 *
	 * @param twilioAccountSid アカウントSID
	 * @param twilioAuthToken アカウント・オース（必須）
	 * @param twilioProxyServerUri フォーワード・プロクシURI
	 *
	 * @return Twilioクライアント
	 */
	public TwilioRestClient buildTwilioRestClient(String twilioAccountSid, String twilioAuthToken,
			String twilioProxyServerUri) {

		TwilioRestClient.Builder builder = new TwilioRestClient.Builder(twilioAccountSid, twilioAuthToken);

		RequestConfig requestConfig = HttpClientFactory.createRequestConfig(twilioProxyServerUri);

		NetworkHttpClient httpClient = new NetworkHttpClient(requestConfig);
		builder = builder.httpClient(httpClient);

		final TwilioRestClient restClient = builder.build();
		return restClient;
	}

}

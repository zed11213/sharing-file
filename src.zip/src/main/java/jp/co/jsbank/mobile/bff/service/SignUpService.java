package jp.co.jsbank.mobile.bff.service;

import java.util.List;
import org.springframework.stereotype.Service;
import jp.co.jsbank.mobile.bff.dto.AuthorizationResponseDto;
import jp.co.jsbank.mobile.bff.dto.BankbookPatternPreferenceRequestDto;
import jp.co.jsbank.mobile.bff.dto.BindingNotificationRequestDto;
import jp.co.jsbank.mobile.bff.dto.DepartmentStoreInquiryResponseDto;
import jp.co.jsbank.mobile.bff.dto.EmailAddressAuthorizationRequestDto;
import jp.co.jsbank.mobile.bff.dto.EmailAddressRegistrationRequestDto;
import jp.co.jsbank.mobile.bff.dto.EmailAddressRegistrationResponseDto;
import jp.co.jsbank.mobile.bff.dto.IdentityVerificationRequestDto;
import jp.co.jsbank.mobile.bff.dto.IdentityVerificationResponseDto;
import jp.co.jsbank.mobile.bff.dto.IvrAuthenticationRequestDto;
import jp.co.jsbank.mobile.bff.dto.IvrAuthenticationResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.IvrSendingRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.IvrSendingResponseDto;

/**
 * 初回登録サービス
 */
@Service
public interface SignUpService {

    /**
     * 部店照会リスト取得
     *
     * @return 部店照会リスト
     */
    List<DepartmentStoreInquiryResponseDto> departmentStoreInquiry();

    /**
     * 本人照合
     *
     * @param identityVerificationReq 本人照合リクエストDTO
     * @return 本人照合ResponseDTO
     */
    IdentityVerificationResponseDto identityVerification(IdentityVerificationRequestDto identityVerificationReq);

    /**
     * メールアドレス登録
     *
     * @param requestDto メールアドレス登録リクエストDTO
     * @return 処理結果
     */
    EmailAddressRegistrationResponseDto emailAddressRegistration(EmailAddressRegistrationRequestDto requestDto);

    /**
     * メールアドレス認証
     *
     * @param requestDto メールアドレス認証リクエストDTO
     * @return メールアドレス認証レスポンスDTO
     */
    AuthorizationResponseDto emailAddressAuthorization(EmailAddressAuthorizationRequestDto requestDto);

    /**
     * IVR送信
     *
     * @param requestDto IVR送信リクエストDTO
     * @return 処理結果
     */
    IvrSendingResponseDto ivrSending(IvrSendingRequestDto requestDto);

    /**
     * IVR認証
     *
     * @param requestDto IVR認証リクエストDTO
     * @return [確認ダイアログ]画面表示
     */
    IvrAuthenticationResponseDto ivrAuthentication(IvrAuthenticationRequestDto requestDto);

    /**
     * 通帳パターン設定
     *
     * @param requestDto 通帳パターン設定リクエストDTO
     * @return 処理結果
     */
    String bankbookPatternPreference(BankbookPatternPreferenceRequestDto requestDto);

    /**
     * バインディング
     *
     * @param bindingNotificationRequestDto バインディングリソースDTO
     * @return 処理結果
     */
    String bindingNotification(BindingNotificationRequestDto bindingNotificationRequestDto);

}

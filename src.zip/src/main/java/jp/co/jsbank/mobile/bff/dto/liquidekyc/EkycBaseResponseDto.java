package jp.co.jsbank.mobile.bff.dto.liquidekyc;

import lombok.Data;

@Data
public class EkycBaseResponseDto {
    private String code;
}

package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 所在地情報保存ABAレスポンスDTO
 */
@Data
public class AddressInfomationAbaResponseDto {
    /**
     * 受付番号
     */
    private String receiptNumber;

    /**
     * 共通レスポンスヘッダ
     */
    private CommonResponseHeader commonResponseHeader;
}

package jp.co.jsbank.mobile.bff.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import jp.co.jsbank.mobile.bff.common.exception.EkycClientErrorHandler;
import jp.co.jsbank.mobile.bff.common.exception.GlobalExceptionHandler;
import jp.co.jsbank.mobile.bff.common.exception.RestClientErrorHandler;

import org.apache.http.HttpHost;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import java.security.cert.X509Certificate;

import javax.annotation.PostConstruct;
import javax.net.ssl.SSLContext;
import org.apache.http.HttpHost;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContexts;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * RestTemplateについての配置クラス。
 *
 */
@Configuration
public class RestEkycClientConfig {

    @Autowired
    private MappingJackson2HttpMessageConverter mappingJackson2HttpMessageConverter;

    @Autowired
    private EkycClientErrorHandler ekycClientErrorHandler;

    private Logger logger = LoggerFactory.getLogger(RestEkycClientConfig.class);

    

    /**
     * RestTemplate対象beanを生成する。
     *
     * @return RestTemplate対象
     */
    // @Bean("ekycClient1")
    // public RestTemplate ekycRestTemplate() {
    //     logger.info("ekycRestTemplate1");
    //     HttpHost proxy = new HttpHost(
	// 				"http://dsp-access-2.d-dspcommon.internal",
	// 				1052);
        
    //     CloseableHttpClient httpClient = HttpClients.custom().setProxy(proxy).build();

    //     HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory(httpClient);
    //     factory.setConnectionRequestTimeout(30_000);
    //     factory.setConnectTimeout(30_000);
    //     factory.setReadTimeout(30_000);
    //     factory.setBufferRequestBody(true);

    //     RestTemplate ekycRestTemplate =  new RestTemplate(factory); 
    //     ekycRestTemplate.setErrorHandler(ekycClientErrorHandler);
    //     ekycRestTemplate.getMessageConverters().add(0,mappingJackson2HttpMessageConverter);

    //     return ekycRestTemplate;

    // }

    /**
     * RestTemplate対象beanを生成する。
     *
     * @return RestTemplate対象
     */
    @Bean("ekycClient2")
    @Primary
    public RestTemplate ekycRestTemplate2() {
        logger.info("ekycRestTemplate2");
        try {
            TrustStrategy trustAllStrategy = (X509Certificate[] chain, String authType) -> true;

            SSLContext sslContext = SSLContexts.custom().loadTrustMaterial(null, trustAllStrategy).build();

            SSLConnectionSocketFactory socketFactory =
                    new SSLConnectionSocketFactory(
                        sslContext,
                        new String[] { "TLSv1.2" },
                        null,
                        NoopHostnameVerifier.INSTANCE
                    );

            System.setProperty("jsse.enableSNIExtension", "true");

            // フォワードプロキシ
            HttpHost proxy = new HttpHost(

                    "dsp-access-2.d-dspcommon.internal",//開発環境
    //					"dsp-access-2.p-dspcommon.internal", //本番環境
                    1052,"http");

            CloseableHttpClient httpClient = HttpClients.custom().setSSLSocketFactory(socketFactory).setProxy(proxy)
                    .build();

            HttpComponentsClientHttpRequestFactory factory = new HttpComponentsClientHttpRequestFactory(httpClient);

            factory.setConnectTimeout(10_000);
    //			factory.setReadTimeout(30_000);
            factory.setReadTimeout(10 * 60_000);

            RestTemplate ekycRestTemplate = new RestTemplate(factory);
            return ekycRestTemplate;
        } catch (Exception e) {
            throw new IllegalStateException("DECO RestTemplate 作成失敗", e);
        }
    }

    /**
     * ClientHttpRequestFactoryを生成する。
     *
     * @return ClientHttpRequestFactory対象
     */
    private HttpComponentsClientHttpRequestFactory createSimpleFactory() {

        HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
        // istioで処理、以下設定をコメントする
        // istioで処理、以下設定をコメントする     
        requestFactory.setConnectionRequestTimeout(90000);
        requestFactory.setConnectTimeout(90000);
        requestFactory.setReadTimeout(90000);

        requestFactory.setBufferRequestBody(true);

        return requestFactory;
    }
}

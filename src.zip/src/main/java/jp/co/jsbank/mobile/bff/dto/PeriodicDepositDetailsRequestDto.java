package jp.co.jsbank.mobile.bff.dto;
import lombok.Data;

/**
 * 残高情報DTO
 */
@Data
public class PeriodicDepositDetailsRequestDto {

    /**
     * 店番
     */
    private String branchNumber;

    /**
     * 支店名
     */
    private String branchName;

    /**
     * 科目コード
     */
    private String subjectNameCode;

    /**
     * 科目名
     */
    private String subjectNameValue;

    /**
     * 口座番号
     */
    private String accountNumber;

    /**
     * 資金化残高
     */
    private String fundedBalance;

    /**
     * 残高
     */
    private String balance;
    
    /**
     * 総合口座フラグ
     */
    private String generalAccountFlag;

    /**
     * 総合口座リンク先-預金種目
     */
    private String linkedAccountType;
    
    /**
     * 総合口座リンク先-店番
     */
    private String linkedBranchNumber;

    /**
     * 総合口座リンク先-口座番号
     */
    private String linkedAccountNumber;
    
    /**
     * 総合口座リンク先-サブNo
     */
    private String linkedSubNumber;
}

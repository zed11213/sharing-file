package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * IVR送信ABAレスポンスDTO
 */
@Data
public class IvrSendingAbaResponseDto {
	
	
	 /**
     * 共通レスポンス・ボディ
     */
    private CommonResponseHeader commonResponseHeader;
    
	 /**
     * 認証TRXキー
     */
    private String verifyTRXKey;
    
    
 }

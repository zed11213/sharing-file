package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import jp.co.jsbank.mobile.bff.dto.UserInfoResponseDto;
import lombok.Data;

/**
 * 利用者情報AbaレスポンスDTO
 */
@Data
public class UserInfoAbaResponseDto {
    /**
     * 共通レスポンスヘッダ
     */
    private CommonResponseHeader commonResponseHeader;

    /**
     * 利用者情報レスポンスDTO
     */
    private List<UserInfoResponseDto> userInfoResponseDtoList;

}

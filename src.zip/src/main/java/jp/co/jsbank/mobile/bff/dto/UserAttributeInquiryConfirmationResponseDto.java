package jp.co.jsbank.mobile.bff.dto;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.aba.CifAttributeQueryInfomationDto;
import lombok.Data;

/**
 * 利用口座登録確認レスボスDTO
 */
@Data
public class UserAttributeInquiryConfirmationResponseDto {

    /**
     * 利用口座情報DTO
     */
    private List<UserAttributeDto> accountInfo;
    
    /**
     * CIF情報取得
     */
    private List<CifAttributeQueryInfomationDto> cifInfomationDtoList;
    
    /**
     * 通帳レス設定状態
     */
    private String passbookLessSettingStatus;
}

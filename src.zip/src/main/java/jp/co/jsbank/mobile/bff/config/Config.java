package jp.co.jsbank.mobile.bff.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * CONFIG クラス
 */
@Component
public class Config {

	// JAG Secret Key (AES Secret / 任意文字16文字, 128bit).
	// 例. "--JAG--GATEWAY--"
	private static String secretKey;
	// JAG Client Secret Key (AES SALT / 任意文字).
	// 例. "--CLI-SECRET-KEY--";
	private static String salt;
	// iOS個人バージョン
	private static String iosRetailVersion;
	// iOS法人バージョン
	private static String iosBizzVersion;
	// Android個人バージョン
	private static String androidRetailVersion;
	// Android法人バージョン
	private static String androidBizzVersion;
	// モード
	private static String active;

	@Value("${secret-key}")
	public void setSecretKey(String secretKey) {
		Config.secretKey = secretKey;
	}

	public static String getSecretKey() {
		return secretKey;
	}

	@Value("${salt}")
	public void setSalt(String salt) {
		Config.salt = salt;
	}

	public static String getSalt() {
		return salt;
	}

	@Value("${ios_retail_version}")
	public void setIosRetailVersion(String iosRetailVersion) {
		Config.iosRetailVersion = iosRetailVersion;
	}

	public static String getIosRetailVersion() {
		return iosRetailVersion;
	}

	@Value("${ios_bizz_version}")
	public  void setIosBizzVersion(String iosBizzVersion) {
		Config.iosBizzVersion = iosBizzVersion;
	}

	public static String getIosBizzVersion() {
		return iosBizzVersion;
	}

	@Value("${android_retail_version}")
	public  void setAndroidRetailVersion(String androidRetailVersion) {
		Config.androidRetailVersion = androidRetailVersion;
	}

	public static String getAndroidRetailVersion() {
		return androidRetailVersion;
	}

	@Value("${android_bizz_version}")
	public  void setAndroidBizzVersion(String androidBizzVersion) {
		Config.androidBizzVersion = androidBizzVersion;
	}

	public static String getAndroidBizzVersion() {
		return androidBizzVersion;
	}

	@Value("${spring.profiles.active}")
	public  void setActive(String active) {
		Config.active = active;
	}

	public static String getActive() {
		return active;
	}

}

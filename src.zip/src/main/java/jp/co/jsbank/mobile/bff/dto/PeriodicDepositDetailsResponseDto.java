package jp.co.jsbank.mobile.bff.dto;

import java.util.List;

import lombok.Data;

/**
 * 定期積金明細レスポンスDTO
 */
@Data
public class PeriodicDepositDetailsResponseDto {
    /**
     * 定期積金明細DTOリスト
     */
    private List<PeriodicTimeDepositDetailsDto> cumulativeDepositDetails;

}

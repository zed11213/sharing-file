package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 帳票CSV内容照会_財形年金預金受取案内レスポンスDTO
 */
@Data
public class InquireReport012ResponseDto {

    /**
     * 帳票バージョン
     */
    private String formVersion;

    /**
     * 本状作成日
     */
    private String bookCreateDate;

    /**
     * ご入金日
     */
    private String depositDate;

    /**
     * お受取り額
     */
    private String receivedAmount;

    /**
     * 最終お受取り日
     */
    private String lastBeneficiaryDate;

    /**
     * ご入金口座番号
     */
    private String depositAccountNumber;

    /**
     * 取扱店名
     */
    private String branchKanjiName;

    /**
     * 取扱電話番号
     */
    private String branchPhoneNumber;
}

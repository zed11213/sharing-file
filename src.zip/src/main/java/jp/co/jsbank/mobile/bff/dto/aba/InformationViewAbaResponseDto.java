package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * お知らせ閲覧ABAレスポンスDTO
 */
@Data
public class InformationViewAbaResponseDto {
	
    /**
     * 共通レスポンスヘッダ
     */
    private CommonResponseHeader commonResponseHeader;

}

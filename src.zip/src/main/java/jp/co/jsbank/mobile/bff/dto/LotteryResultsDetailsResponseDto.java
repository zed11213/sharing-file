package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 抽選結果明細DTO
 */
@Data
public class LotteryResultsDetailsResponseDto {

    /**
     * サブNO
     */
    private String subNumber;

    /**
     * 回次
     */
    private String lotteryTimes;

    /**
     * 抽選区分
     */
    private String lotteryType;

    /**
     * 取扱組
     */
    private String lotterySet;

    /**
     * 等級
     */
    private String lotteryRank;

    /**
     * 当選番号
     */
    private String lotteryNumber;

    /**
     * 当選本数
     */
    private String lotteryCount;

    /**
     * 当選金額
     */
    private String lotteryAmount;

    /**
     * 抽選結果受領済みフラグ
     */
    private String lotteryResultReceivedFlag;
}

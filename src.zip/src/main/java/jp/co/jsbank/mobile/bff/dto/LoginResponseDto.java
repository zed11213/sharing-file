package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * ログイン認証レスボスDTO
 */
@Data
public class LoginResponseDto {

    /**
     * 認証トークン
     */
    private String authenticationToken;

    /**
     * 認証有効期間
     */
    private String authenticationEffectivePeriod;
}

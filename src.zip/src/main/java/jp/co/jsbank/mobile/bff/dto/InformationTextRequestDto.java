package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * お知らせ本文取得リクエストDTO
 */
@Data
public class InformationTextRequestDto {

    /**
     * お知らせID
     */
    private String anncmntId;
    
    /**
     * 文書種別ID
     */
    private String documentTypeId;
    
    /**
     * お知らせ種別ID
     */
    private String anncmntTypeId;
}

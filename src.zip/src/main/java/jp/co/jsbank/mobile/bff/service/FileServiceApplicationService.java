package jp.co.jsbank.mobile.bff.service;

import jp.co.jsbank.mobile.bff.entity.FileServiceApplicationEntity;

public interface FileServiceApplicationService {
    
    /**
     * トークンIDを登録する
     *
     * @param fileServiceApplicationEntity TOKEN_MAPPINGエンティティ
     * @return トークンID
     */
    String insertFileServiceApplication(FileServiceApplicationEntity fileServiceApplicationEntity);

    /**
     * トークンIDを検索する
     *
     * @param applyId トークン
     * @return トークンID
     */
    FileServiceApplicationEntity selectByApplyId(String applyId);

    Boolean checkExistByApplyId(String applyId);

    /**
     * CIF番号と支店コードで検索する
     *
     * @param cifNo CIF番号
     * @param branchCode 支店コード
     * @return FileServiceApplicationEntity
     */
    FileServiceApplicationEntity selectByCifNoAndBranchCode(String cifNo, String branchCode);

    /**
     * 顧客idで検索する
     *
     * @param customerId 顧客id
     * @return FileServiceApplicationEntity
     */
    FileServiceApplicationEntity selectByCustomerId(String customerId);

    /**
     * APPLY_IDでメールアドレスを更新する
     *
     * @param applyId 申込ID
     * @param mailAddress メールアドレス
     */
    void updateMailAddressByApplyId(String applyId, String mailAddress);
}

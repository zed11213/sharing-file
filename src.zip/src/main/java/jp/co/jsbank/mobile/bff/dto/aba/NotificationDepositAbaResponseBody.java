package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 通知預金明細レスポンスDTO
 */
@Data
public class NotificationDepositAbaResponseBody {


    /**
     * 共通レスポンス・ボディ
     */
    private CommonResponseHeader commonResponseBody;
    
    /**
     * 通知預金明細DTOリスト
     */
    private List<NotificationDepositDetailsDto> notificationDepositDetailsDtoList;

}

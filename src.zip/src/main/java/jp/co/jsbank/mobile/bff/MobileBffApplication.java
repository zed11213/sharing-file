package jp.co.jsbank.mobile.bff;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * SpringBootApplicationクラス
 */
@SpringBootApplication
public class MobileBffApplication {

    /**
     * SpringBootApplication
     * 
     * @param args パラメータ
     */
    public static void main(String[] args) {
        SpringApplication.run(MobileBffApplication.class, args);
    }

}

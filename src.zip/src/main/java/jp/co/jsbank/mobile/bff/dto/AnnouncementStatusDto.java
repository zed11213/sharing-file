package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/** お知らせステータス */
@Data
public class AnnouncementStatusDto {

    /**
     * お知らせステータス
     */
    private String anncmntStatus;
}

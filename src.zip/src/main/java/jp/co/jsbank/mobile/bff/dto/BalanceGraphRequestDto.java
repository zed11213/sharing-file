package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 収支グラフ情報ABAリクエストDTO
 */
@Data
public class BalanceGraphRequestDto {

    /**
     * 口座番号
     */
    private String accountNumber;

    /**
     * 店番
     */
    private String branchNumber;

}

package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * トランザクションIDの取得リクエストDTO
 */
@Data
public class JagBodyTrxGetIdRequestDto {

    /**
     * 共通リクエスト・ヘッダ
     */
    private JagBodyCommonRequestHeader commonRequestHeader;

}

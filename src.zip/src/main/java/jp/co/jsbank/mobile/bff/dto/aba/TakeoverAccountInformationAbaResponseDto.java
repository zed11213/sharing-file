package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 口座情報ABAレスボスDTO
 */
@Data
public class TakeoverAccountInformationAbaResponseDto {

    /**
     * 共通レスポンス・ヘッダ
     */
    private CommonResponseHeader commonResponseHeader;

    /**
     * レスポンス・ボディ
     */
    private TakeoverAccountInformationAbaResponseBody takeoverAccountInformationAbaResponseBody;
}

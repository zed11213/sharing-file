package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 収支情報BFFレスポンスDTO
 */
@Data
public class BalanceGraphResponseDto {

    /**
     * 収支年月
     */
    private String balanceMonth;

    /**
     * 入金額
     */
    private String depositAmount;

    /**
     * 出金額
     */
    private String investedAmount;
    
    /**
     * 月残高
     */
    private String monthlyBalance;

}

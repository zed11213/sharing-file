package jp.co.jsbank.mobile.bff.dto;

import java.util.List;

import lombok.Data;

/**
 *  帳票CSV内容照会_融資期日案内レスポンスDTO
 */
@Data
public class InquireReport010ResponseDto {
	
    /**
     * 帳票バージョン
     */
    private String formVersion;

    /**
     * 作成日
     */
    private String createDate;

    /**
     * 融資期日明細表リスト
     */
    private List<LoanDateDto> loanDateList;

    /**
     * 取扱店名
     */
    private String branchKanjiName;

    /**
     * 取扱電話番号
     */
    private String branchPhoneNumber;
}

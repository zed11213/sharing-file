package jp.co.jsbank.mobile.bff.common;

/**
 * 画面IDクラス
 */
public class ScreenIdConstant {

    /**
     * 画面ID : MBOP0601
     */
    public static final String SCREEN_ID_MBOP0601 = "MBOP0601";

    /**
     * 画面ID : MBOP0604
     */
    public static final String SCREEN_ID_MBOP0604 = "MBOP0604";
    /**
     * 画面ID : MBOP0608
     */
    public static final String SCREEN_ID_MBOP0608 = "MBOP0608";
    /**
     * 画面ID : MBOP0609
     */
    public static final String SCREEN_ID_MBOP0609 = "MBOP0609";
    /**
     * 画面ID : MBOP0610
     */
    public static final String SCREEN_ID_MBOP0610 = "MBOP0610";

    /**
     * 画面ID : MBOP0611
     */
    public static final String SCREEN_ID_MBOP0611 = "MBOP0611";

    /**
     * 画面ID : MBOP0612
     */
    public static final String SCREEN_ID_MBOP0612 = "MBOP0612";

    /**
     * 画面ID : MBOP0613
     */
    public static final String SCREEN_ID_MBOP0613 = "MBOP0613";

    /**
     * 画面ID : MBSU0302
     */
    public static final String SCREEN_ID_MBSU0302 = "MBSU0302";

    /**
     * 画面ID : MBSU0304
     */
    public static final String SCREEN_ID_MBSU0304 = "MBSU0304";


    /**
     * 画面ID : MBSU0308
     */
    public static final String SCREEN_ID_MBSU0308 = "MBSU0308";

    /**
     * 画面ID : MBSU0501
     */
    public static final String SCREEN_ID_MBSU0501 = "MBSU0501";

    /**
     * 画面ID : MBCO0201
     */
    public static final String SCREEN_ID_MBCO0201 = "MBCO0201";

    /**
     * 画面ID : MBST0401
     */
    public static final String SCREEN_ID_MBST0401 = "MBST0401";

    /**
     * 画面ID : MBSU0502
     */
    public static final String SCREEN_ID_MBSU0502 = "MBSU0502";

    /**
     * 画面ID : MBCO0202
     */
    public static final String SCREEN_ID_MBCO0202 = "MBCO0202";

    /**
     * 画面ID : MBSU0601
     */
    public static final String SCREEN_ID_MBSU0601 = "MBSU0601";

    /**
     * 画面ID : MBCO0301
     */
    public static final String SCREEN_ID_MBCO0301 = "MBCO0301";

    /**
     * 画面ID : MBSU0602
     */
    public static final String SCREEN_ID_MBSU0602 = "MBSU0602";

    /**
     * 画面ID : MBCO0302
     */
    public static final String SCREEN_ID_MBCO0302 = "MBCO0302";

    /**
     * 画面ID : MBSU0305
     */
    public static final String SCREEN_ID_MBSU0305 = "MBSU0305";

    /**
     * 画面ID : MBSU0306
     */
    public static final String SCREEN_ID_MBSU0306 = "MBSU0306";

    /**
     * 画面ID : MBCC0501
     */
    public static final String SCREEN_ID_MBCC0501 = "MBCC0501";

    /**
     * 画面ID : MBOP0602
     */
    public static final String SCREEN_ID_MBOP0602 = "MBOP0602";

    /**
     * 画面ID : MBST0402
     */
    public static final String SCREEN_ID_MBST0402 = "MBST0402";

    /**
     * 画面ID : MBDP1201
     */
    public static final String SCREEN_ID_MBDP1201 = "MBDP1201";

    /**
     * 画面ID : MBRC0202
     */
    public static final String SCREEN_ID_MBRC0202 = "MBRC0202";

    /**
     * 画面ID : MBST0802
     */
    public static final String SCREEN_ID_MBST0802 = "MBST0802";

}

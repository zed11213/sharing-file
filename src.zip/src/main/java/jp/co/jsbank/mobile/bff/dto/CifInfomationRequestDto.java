package jp.co.jsbank.mobile.bff.dto;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * CIF情報取得リクエストDTO
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class CifInfomationRequestDto extends RequestBodyDto {

    /**
     * 顧客ID
     */
    private String customerId;

}

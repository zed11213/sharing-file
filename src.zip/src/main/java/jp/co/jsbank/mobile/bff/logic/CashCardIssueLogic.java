package jp.co.jsbank.mobile.bff.logic;

import org.springframework.stereotype.Service;

import jp.co.jsbank.mobile.bff.dto.aba.AuthAccountInfoAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.AuthAccountInfoAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CcIssuingApplicationCompleteAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CcIssuingApplicationCompleteAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CcIssuingApplicationContentInquiryAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CcIssuingApplicationContentRegistrationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CcIssuingApplicationContentRegistrationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CcIssuingApplicationContentUpdateAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CcIssuingApplicationContentUpdateAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CcIssuingApplicationInformationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.ICCardIssuingOrderInquiryAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.ICCardIssuingOrderInquiryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.SavingsAccountsAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.SavingsAccountsAbaResponseDto;

/**
 * キャッシュカード発行ロジック
 */
@Service
public interface CashCardIssueLogic {

    /**
     * [CC発行申込内容登録]API呼出
     *
     * @param abaRequestDto CC発行申込内容登録登録リクエストDTO
     *
     * @return CC発行申込内容登録レスボスDTO
     */
    CcIssuingApplicationContentRegistrationAbaResponseDto contractMmanagementOperationHistoryRegistration(
            CcIssuingApplicationContentRegistrationAbaRequestDto abaRequestDto);

    /**
     * [CC発行申込内容更新]API呼出
     *
     * @param abaRequestDto CC発行申込内容更新リクエストDTO
     *
     * @return CC発行申込情報レスポンスDTO
     */
    CcIssuingApplicationContentUpdateAbaResponseDto
    ccIssuingApplicationContentUpdate(CcIssuingApplicationContentUpdateAbaRequestDto abaRequestDto);

    /**
     * [CC発行申込完了]API呼出
     *
     * @param abaRequestDto CC発行申込完了リクエストDTO
     *
     * @return CC発行申込完了レスポンスDTO
     */

    CcIssuingApplicationCompleteAbaResponseDto
            ccIssuingApplicationComplete(CcIssuingApplicationCompleteAbaRequestDto abaRequestDto);

    /**
     * [CC発行申込内容照会]API呼出
     *
     * @param abaRequestDto CC発行申込内容照会ABAクエストDTO
     * @return CC発行申込内容照会ResponseDTO
     */
    CcIssuingApplicationInformationAbaResponseDto
            ccIssuingApplicationInformation(CcIssuingApplicationContentInquiryAbaRequestDto abaRequestDto);

    /**
     * [ICカード発行依頼照会]API呼出
     *
     * @param abaRequestDto ICカード発行依頼照会ABAクエストDTO
     * @return ICカード発行依頼照会ResponseDTO
     */
    ICCardIssuingOrderInquiryAbaResponseDto
            ccPasswordIbPasswordSetting(ICCardIssuingOrderInquiryAbaRequestDto abaRequestDto);

    /**
     * 口座情報認証情報取得
     *
     * @param abaRequestDto 口座情報認証リクエストDTO
     * @return 口座情報認証ABAレスボスDTO
     */
    AuthAccountInfoAbaResponseDto authAccountInfo(AuthAccountInfoAbaRequestDto abaRequestDto);

    // 2025/01/24 共同化ため バンキングアプリでのチェック項目の確認（注意コード等）対応 satart
    /**
     * 残高照会（普通預金）
     *
     * @param abaRequestDto 残高照会（普通預金）BAリクエストDTO
     */
    SavingsAccountsAbaResponseDto ordinarydepositBalanceGet(SavingsAccountsAbaRequestDto baRequestDto);

    // 2025/01/24 共同化ため バンキングアプリでのチェック項目の確認（注意コード等）対応 end

}

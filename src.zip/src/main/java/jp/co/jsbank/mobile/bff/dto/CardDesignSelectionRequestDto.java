package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * カードデザイン選択BFFリクエストDTO
 */
@Data
public class CardDesignSelectionRequestDto {

	/**
	 * 受付番号
	 */
	private String receptionNumber;

	/**
	 * 更新パターン
	 */
	private String updateType;

	/**
	 * 人格区分
	 */
	private String personType;

	/**
	 * キャッシュカード種類
	 */
	private String cashCardType;

}

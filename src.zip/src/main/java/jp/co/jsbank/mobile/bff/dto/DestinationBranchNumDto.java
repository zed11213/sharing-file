package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 送信先支店番号Dto
 * */
@Data
public class DestinationBranchNumDto {

    /**
     * 送信先支店番号
     * */
    private String destinationBranchNum;
}

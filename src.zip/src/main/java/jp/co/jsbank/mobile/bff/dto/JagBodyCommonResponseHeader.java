package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;


/**
 * 城南信用金庫バンキングアプリ
 * JAG(ABA)応答共通ヘッダー.
 *
 * 補足:
 * JAGが提供するBizMS(業務MS)機能における共通的な応答ヘッダーを定義したもの.
 * 基本はABAにて定義されている応答共通ヘッダーを採用するが、一部項目は永久的に未使用となるため、それら不要項目を除外して再定義したもの.
 * 背景）大半の業務MSはABAにて提供されているため、各利用側での負担軽減のためABAにて定義されている当該応答共通ヘッダーに従うものとする.
 *
 * History:
 * 2022.05.10  Manabu Hanzaike  初版.
 *
 * @author Manabu Hanzaike - mhanz@jp.ibm.com
 *
 */
@Data
public class JagBodyCommonResponseHeader {
	private String errorCode;

	private String errorMessage;
}

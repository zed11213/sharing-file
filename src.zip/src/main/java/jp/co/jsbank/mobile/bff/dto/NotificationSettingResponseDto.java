package jp.co.jsbank.mobile.bff.dto;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.aba.SettingInfoDto;
import lombok.Data;

/**
 * 通知設定BFFレスボスDTO
 */
@Data
public class NotificationSettingResponseDto {

    /**
     * 設定情報DTOリスト
     */
    private List<SettingInfoDto> settingInfos;
}

package jp.co.jsbank.mobile.bff.service;

public interface FileServiceRequestService {
    
    /**
     * CIF番号と支店コードで検索する
     *
     * @param cifNo CIF番号
     * @param branchCode 支店コード
     * @return FileServiceApplicationEntity
     */
    void updateStatusByApplyId(String applyId, String status);
}

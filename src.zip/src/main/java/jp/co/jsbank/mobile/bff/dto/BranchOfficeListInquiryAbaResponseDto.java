package jp.co.jsbank.mobile.bff.dto;

import java.util.List;

import lombok.Data;

/**
 * 営業地区部店一覧照会レスポンスDTO
 */
@Data
public class BranchOfficeListInquiryAbaResponseDto {

    /**
     * 共通レスポンス・ヘッダ
     */
    private CommonResponseHeader commonResponseHeader;
    
    /**
     * 支店一覧照会
     */
    private List<DepartmentStoreListResponseDto> departmentStoreListResponseDtoList;

    /**
     * 候补FLG
     */
    private String alternateFlg;
    
}

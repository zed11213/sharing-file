package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * CIF情報DTO
 */
@Data
public class CifInfomationDto {

    /**
     * CIF番号
     */
    private String cifNo;

    /**
     * 通帳レス設定状態
     */
    private String passbookLessSettingStatus;

    /**
     * 初回登録フラグ
     */
    private String registerFlg;

    /**
     * 店番
     */
    private String branchCode;

    /**
     * 解約フラグ
     */
    private String dissolutionFlg;

    /**
     * ホストエラーコード
     */
    private String hostErrorCode;

}

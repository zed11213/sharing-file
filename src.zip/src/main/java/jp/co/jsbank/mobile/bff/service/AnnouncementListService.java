package jp.co.jsbank.mobile.bff.service;

import org.springframework.stereotype.Service;

import jp.co.jsbank.mobile.bff.dto.AnnouncementRequestDto;
import jp.co.jsbank.mobile.bff.dto.AnnouncementResponseDto;
import jp.co.jsbank.mobile.bff.dto.InformationTextResponseDto;
import jp.co.jsbank.mobile.bff.dto.UpdateAnnouncementRequestDto;

/**
 * お知らせ一覧サービス
 */
@Service
public interface AnnouncementListService {

    /**
     * お知らせ一覧取得
     *
     * @param requestDto お知らせ一覧リクエストDTO
     * @return お知らせ一覧レスポンスDTO
     */
    AnnouncementResponseDto getAnnouncementList(AnnouncementRequestDto requestDto);

    /**
     * お知らせ本文取得
     *
     * @param anncmntId お知らせID
     * @param anncmntTypeId お知らせ種別ID
     * @param documentTypeId 文書種別ID
     * @param anncmntStatus お知らせステータス
     * @return お知らせ一覧レスポンスDTO
     */
    InformationTextResponseDto getInformationText(String anncmntId, String anncmntTypeId, String documentTypeId,
            String anncmntStatus);

    /**
     * お知らせ一覧更新
     *
     * @param requestDto 顧客による個別確認リクエストDTO
     * @return 処理結果
     */
    String updateAnnouncementList(UpdateAnnouncementRequestDto requestDto);
}

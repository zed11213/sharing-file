package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 本店所在地情報ABAリクエストDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class HeadOfficeAddressInformationAbaRequestDto extends RequestBodyDto {

    /**
     * 受付番号
     */
    private String receiptNumber;

    /**
     * 所在地郵便番号
     */
    private String locationZipCode;

    /**
     * 所在地都道府県（カナ）
     */
    private String locationPrefectureKana;

    /**
     * 所在地都道府県
     */
    private String locationPrefecture;

    /**
     * 所在地市区町村（カナ）
     */
    private String locationCityKana;

    /**
     * 所在地市区町村
     */
    private String locationCity;

    /**
     * 所在地丁目（カナ）
     */
    private String locationStreetKana;

    /**
     * 所在地丁目
     */
    private String locationStreet;

    /**
     * 所在地番地（カナ）
     */
    private String locationAddressKana;

    /**
     * 所在地番地
     */
    private String locationAddress;

    /**
     * 所在地建物名・号室（カナ）
     */
    private String locationBuildingRoomKana;

    /**
     * 所在地建物名・号室
     */
    private String locationBuildingRoom;

    /**
     * 画面ID
     */
    private String pageId;

    /**
     * 更新パターン
     */
    private String updateType;
}

package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * メールアドレス登録ABAリクエストDTO
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class UserElementUpdateAbaRequestDto extends RequestBodyDto  {

    /**
     * 利用者ID
     */
    private String userId;

    /**
     * メールアドレス
     */
    private String emailAddress;
    
}

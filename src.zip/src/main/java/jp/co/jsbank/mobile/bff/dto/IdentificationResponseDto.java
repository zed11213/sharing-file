package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 本人確認レスポンスDTO
 */
@Data
public class IdentificationResponseDto {

    /**
     * 受付番号
     */
    private String receptionNumber;

    /**
     * 電話番号１
     */

    private String phoneNumber1;

    /**
     * 電話番号２
     */
    private String phoneNumber2;

    /**
     * 電話番号３
     */
    private String phoneNumber3;

    /**
     * 本人カード仮発行
     */
    private String cardDummyIssue;

	/**
	 * 番地
	 */
	private String addrDetail3;

	/**
	 * 住所方書（カナ）
	 */
	private String addressDetailKana;

}

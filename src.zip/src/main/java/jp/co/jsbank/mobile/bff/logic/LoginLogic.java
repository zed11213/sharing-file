package jp.co.jsbank.mobile.bff.logic;

import org.springframework.stereotype.Service;

import jp.co.jsbank.mobile.bff.dto.aba.UserAttributeInquiryAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.UserAttributeInquiryAbaResponseDto;

/**
 * ログインロジック
 */
@Service
public interface LoginLogic {

    /**
     * 利用者属性照会
     *
     * @param abaRequestDto 利用者属性照会ABAリクエストDTO
     * @return 利用者属性照会ABAレスボスDTO
     * 
     */
    UserAttributeInquiryAbaResponseDto userAttributeInquiry(UserAttributeInquiryAbaRequestDto abaRequestDto);
}

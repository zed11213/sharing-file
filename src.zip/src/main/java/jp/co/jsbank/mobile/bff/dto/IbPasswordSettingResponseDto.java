package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * IBパスワード設定BFFリクエストDTO
 */
@Data
public class IbPasswordSettingResponseDto {

    /**
     * IBパスワード
     */
    private String ibPassword;
    
    /**
     * CC暗証番号
     */
    private String ccPassword;
    
}
package jp.co.jsbank.mobile.bff.dto.liquidekyc;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import lombok.Data;

/**
 * 本人確認結果登録リクエストDTO
 * ステータスコードのみ返却される
 */
@Data
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class EkycKycResultRequestDto {
    
    /**
     * 連携Id
     */
    private String applicantId;

    /**
     * 本人確認結果　
     * 導入事事業者様側で申請データに対して本人確認した結果
     * 0：OK
     * 1：NG
     */
    private String kycResult;

    /**
     * 機微情報の有無を指定する。
     * false: なし
     * true: あり
     * 本人確認（へ方式）の場合、falseを指定する
     * 公的個人認証を利用する場合、falseを指定する
     */
    private Boolean hasSensitiveInfo;
}

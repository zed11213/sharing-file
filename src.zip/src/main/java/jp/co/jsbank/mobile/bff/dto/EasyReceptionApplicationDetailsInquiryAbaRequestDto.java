package jp.co.jsbank.mobile.bff.dto;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * かんたん受付申込詳細照会ABAリクエストDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class EasyReceptionApplicationDetailsInquiryAbaRequestDto extends RequestBodyDto {

    /**
     * お知らせID
     */
    private String anncmntId;

    /**
     * 申込ID
     */
    private String applyId;

}

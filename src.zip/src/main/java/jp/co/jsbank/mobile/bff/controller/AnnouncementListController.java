package jp.co.jsbank.mobile.bff.controller;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import jp.co.jsbank.mobile.bff.common.JsonResult;
import jp.co.jsbank.mobile.bff.common.code.ConfirmFlgCode;
import jp.co.jsbank.mobile.bff.common.code.ReadFlgCode;
import jp.co.jsbank.mobile.bff.dto.AnnouncementRequestDto;
import jp.co.jsbank.mobile.bff.dto.AnnouncementResponseDto;
import jp.co.jsbank.mobile.bff.dto.InformationTextResponseDto;
import jp.co.jsbank.mobile.bff.dto.UpdateAnnouncementRequestDto;
import jp.co.jsbank.mobile.bff.service.AnnouncementListService;

/**
 * お知らせ一覧
 */
@RestController
public class AnnouncementListController {

    @Resource
    private AnnouncementListService announcementListService;

    /**
     * お知らせ一覧取得
     *
     * @param requestDto お知らせ一覧リクエストDTO
     * @return 処理結果
     */
    @PostMapping(path = "/announcement-list/AB1001")
    public String getAnnouncementList(@RequestBody AnnouncementRequestDto requestDto) {

        // お知らせ一覧を取得する
        AnnouncementResponseDto responseDto = announcementListService.getAnnouncementList(requestDto);

        return JsonResult.success(responseDto);
    }

    /**
     * お知らせ本文取得
     *
     * @param announcementRequestDto お知らせ本文取得リクエストDTO
     * @return 処理結果
     */
    @PostMapping(path = "/announcement-list/AB1002")
    public String getInformationText(@RequestBody AnnouncementRequestDto announcementRequestDto) {

        String anncmntId = announcementRequestDto.getAnncmntId();
        String anncmntTypeId = announcementRequestDto.getAnncmntType();

        String documentTypeId = announcementRequestDto.getDocumentType();

        String anncmntStatus = announcementRequestDto.getAnncmntStatus();
        // お知らせ本文DTOを取得する
        InformationTextResponseDto result = announcementListService.getInformationText(anncmntId, anncmntTypeId,
                documentTypeId, anncmntStatus);
        UpdateAnnouncementRequestDto requestDto = new UpdateAnnouncementRequestDto();
        // お知らせID設定
        requestDto.setAnncmntId(anncmntId);
        requestDto.setApplyId(announcementRequestDto.getApplyId());
        // お知らせ種別ID設定
        requestDto.setAnncmntType(anncmntTypeId);
        // 文書種別ID設定
        requestDto.setDocumentType(documentTypeId);
        // 既読フラグ設定
        requestDto.setReadFlg(ReadFlgCode.READED);

        // お知らせ一覧更新
        announcementListService.updateAnnouncementList(requestDto);

        return JsonResult.success(result);

    }

    /**
     * スター/お気に入り押下処理
     *
     * @param requestDto お知らせ一覧更新リクエストDTO
     * @return 処理結果
     */
    @PostMapping(path = "/announcement-list/AB1003")
    public String saveStarAndFavorite(@RequestBody UpdateAnnouncementRequestDto requestDto) {

        // 処理結果
        String result = announcementListService.updateAnnouncementList(requestDto);

        return JsonResult.success(result);
    }

    /**
     * 顧客による個別確認
     *
     * @param requestDto お知らせ一覧更新リクエストDTO
     * @return 処理結果
     */
    @PostMapping(path = "/announcement-list/AB1004")
    public String individualConfirmationCustomer(@RequestBody UpdateAnnouncementRequestDto requestDto) {
        // 個別確認フラグ
        requestDto.setConfirmFlg(ConfirmFlgCode.CONFIRMATION);
        // 処理結果
        String result = announcementListService.updateAnnouncementList(requestDto);

        return JsonResult.success(result);
    }
}

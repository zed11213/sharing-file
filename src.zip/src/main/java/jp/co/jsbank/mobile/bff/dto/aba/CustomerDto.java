package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * ｶﾅ氏名情報DTO
 */
@Data
public class CustomerDto {

    /**
     * カナ氏名
     */
    private String customerName;

    /**
     * 漢字氏名
     */
    private String customerKanjiName;

    /**
     * 生年月日
     */
    private String birthday;

    /**
     * CIF番号
     */
    private String cifNumber;

    /**
     * 預金種目１
     */
    private String accountType1;

    /**
     * 店番１
     */
    private String branchNumber1;

    /**
     * 口座番号１
     */
    private String accountNumber1;

    /**
     * 預金種目２
     */
    private String accountType2;

    /**
     * 店番２
     */
    private String branchNumber2;

    /**
     * 口座番号２
     */
    private String accountNumber2;

    /**
     * 預金種目３
     */
    private String accountType3;

    /**
     * 店番３
     */
    private String branchNumber3;

    /**
     * 口座番号３
     */
    private String accountNumber3;

    /**
     * 預金種目４
     */
    private String accountType4;

    /**
     * 店番４
     */
    private String branchNumber4;

    /**
     * 口座番号４
     */
    private String accountNumber4;

    /**
     * 預金種目５
     */
    private String accountType5;

    /**
     * 店番５
     */
    private String branchNumber5;

    /**
     * 口座番号５
     */
    private String accountNumber5;
}

package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * IVR送信リクエストDTO
 */
@Data
public class IvrSendingRequestDto {

    /**
     * 電話番号
     */
    private String phoneNumber;

    /**
     * 人格区分
     */
    private String personType;

    /**
     * 更新パターン
     */
    private String updateType;

    /**
     * CIF番号
     */
    private String cifNumber;

    /**
     * 店番
     */
    private String branchNumber;

    /**
     * 依頼番号
     */
    private String requestNo;
}

package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * バインディング リソースDTO
 */
@Data
public class BindingNotificationRequestDto {

	/**
	 * アイデンティティ
	 */
	private String identity;

	/**
	 * アドレス
	 */
	private String address;
}

package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * お知らせ種別IDで案内照会リクエストDTO
 */
@Data
public class GuidanceInquiryInformationTypeIdResponseDto {
    /**
     * 種類
     */
    private String type;

    /**
     * 案内ステータス
     */
    private String guidanceStatus;

    /**
     * 公開中
     */
    private String open;

    /**
     * 非会員受付有無
     */
    private String hasNonMemberReception;

    /**
     * 掲載開始日時(日付)
     */
    private String publicateStartDate;

    /**
     * 掲載開始日時(時間)
     */
    private String publicateStartTime;

    /**
     * 掲載終了日時(日付)
     */
    private String publicateEndDate;

    /**
     * 掲載終了日時(時間)
     */
    private String publicateEndTime;

}

package jp.co.jsbank.mobile.bff.dto.liquidekyc;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import lombok.Data;
/**
 * 公的個人認証
 * EkycJpikIdentificationResultDto
 */
@Data
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class EkycJpikIdentificationResultDto {

    /**
     * 確認結果当該APIによる情報取得は申請完了後のみ実施可能であるため、確認結果は一律trueとなる
     */
    private Boolean valid;

    /**
     * PFPF事業者本人確認対象利用者識別番号
     */
    private String uid;

     /**
     * 確認日時　日本標準時刻
     */
    private String asof;

     /**
     * 有効開始時刻
     */
    private String notBefore;

     /**
     * 有効終了時刻
     */
    private String notAfter;

     /**
     * 発行主体電子署名を生成した署名用証明書発行者の識別名
     */
    private String issuerDn;

     /**
     * 電子署名識別子
     */
    private String signatureId;


}

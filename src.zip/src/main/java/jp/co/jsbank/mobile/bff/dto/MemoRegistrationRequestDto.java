package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 明細概要メモ登録BFFリクエストDTO
 */
@Data
public class MemoRegistrationRequestDto {


    /**
     * 顧客ID
     */
    private String customerId;

    /**
     * 店番
     */
    private String branchNumber;

    /**
     * 口座番号
     */
    private String accountNumber;
    
    /**
     * 預金種目
     */
    private String accountType;
    
    /**
     * 明細ID
     */
    private String detailId;

    /**
     * メモ
     */
    private String memo;
}

package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 申込完了リクエストDTO
 */
@Data
public class AccountOpeningApplicationRequstDto {

    /**
     * 人格区分
     */
    private String personType;

    /**
     * 受付番号
     */
    private String receiptNumber;

    /**
     * 申込日
     */
    private String applicationDate;
}

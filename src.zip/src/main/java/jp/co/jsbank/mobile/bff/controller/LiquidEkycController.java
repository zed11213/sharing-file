package jp.co.jsbank.mobile.bff.controller;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import jp.co.jsbank.mobile.bff.common.JsonResult;
import jp.co.jsbank.mobile.bff.dto.liquidekyc.EkycFinishVerificationRequestDto;
import jp.co.jsbank.mobile.bff.dto.liquidekyc.GetTokenRequestDTO;
import jp.co.jsbank.mobile.bff.dto.liquidekyc.GetTokenResponseDTO;
import jp.co.jsbank.mobile.bff.service.LiquidEkycService;

/**
 * LIQUID EKYCコントロール
 */
@RestController
public class LiquidEkycController {

	@Resource
    private LiquidEkycService liquidEkycService;
	
	private Logger logger = LoggerFactory.getLogger(LiquidEkycController.class);
	/**
	 * ekyc
	 *
	 * @return JsonResult
	 */
	@PostMapping("/ekyc/AB1201")
	public String getEkycToken(@RequestBody GetTokenRequestDTO requestDto) {
		logger.info("ekyc getToken start");
		GetTokenResponseDTO result = liquidEkycService.getToken(requestDto);
		logger.info("ekyc result applicantId:" + result.getApplicantId());
		logger.info("ekyc result token:" + result.getToken());
		logger.info("ekyc getToken end");
		return JsonResult.success(result);
	}

	@PostMapping("ekyc/AB1202")
	public String setFinishVerificationWithJpki(@RequestBody EkycFinishVerificationRequestDto requestDto) {
		logger.info("ekyc set finish jpki start");

		String result = liquidEkycService.setFinishVerificationWithJpki(requestDto);
		logger.info("ekyc AB1202 result={}", result);
		logger.info("ekyc set finish jpki end");
		return JsonResult.success(result);
	}

	@PostMapping("ekyc/AB1203")
	public String setFinishVerificationWithHe(@RequestBody EkycFinishVerificationRequestDto requestDto) {
		logger.info("ekyc set finish he start");

		String result = liquidEkycService.setFinishVerificationWithHe(requestDto);
		logger.info("ekyc AB1203 result={}", result);
		logger.info("ekyc set finish he end");
		return JsonResult.success(result);
	}

}

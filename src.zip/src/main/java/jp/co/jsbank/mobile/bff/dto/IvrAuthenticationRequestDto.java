package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * IVR認証リクエストDTO
 */
@Data
public class IvrAuthenticationRequestDto {

    /**
     * 受付番号
     */
    private String receiptNumber;

    /**
     * 電話番号
     */
    private String phoneNumber;

    /**
     * IVROTP
     */
    private String ivrOtp;

    /**
     * 更新パターン
     */
    private String updateType;
    
    /**
     * 人格区分
     */
    private String personType;   
    
    /**
     * 依頼番号
     */
    private String requestNo;
    
}

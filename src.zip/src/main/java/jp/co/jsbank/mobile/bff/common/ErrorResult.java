package jp.co.jsbank.mobile.bff.common;

import lombok.Data;

/**
 * エラークラス
 */
@Data
public class ErrorResult {
    
    /** エラーコード */
    private String errorCode;

    /** エラーメッセージ */
    private String errorMessage;
}

package jp.co.jsbank.mobile.bff.dto;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.aba.SettingInfoDto;
import lombok.Data;

/**
 * 利用者属性更新リクエストDTO
 */
@Data
public class UpdateUserAttributeRequestDto {

    /**
     * 利用者区分
     */
    private String userType;

    /**
     * ステータス
     */
    private String status;

    /**
     * 漢字氏名
     */
    private String customerKanjiName;

    /**
     * カナ氏名
     */
    private String customerName;

    /**
     * 所属
     */
    private String division;

    /**
     * メールアドレス
     */
    private String mailAddress;

    /**
     * 事業先利用者認証キー
     */
    private String certKey;
    
    /**
     * 設定情報DTOリスト
     */
    private List<SettingInfoDto> settingInfos;

    /**
     * 照会時最終更新日時
     */
    private String updateDatetime;
}

package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 申込完了メール送信レスポンスDTO
 */
@Data
public class ApplicationCompleteEmailSendingAbaResponseDto {
	
	
	 /**
     * 共通レスポンス・ボディ
     */
    private CommonResponseHeader commonResponseHeader;
    
    /**
     * 受付番号
     */
    private String receptionNumber;
    
 }

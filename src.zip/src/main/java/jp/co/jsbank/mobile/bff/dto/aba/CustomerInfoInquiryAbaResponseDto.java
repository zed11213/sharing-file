package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 顧客情報照会(仮称)ABAリクエストDTO
 */
@Data
public class CustomerInfoInquiryAbaResponseDto {
	
	 /**
     * 共通レスポンス・ボディ
     */
    private CommonResponseHeader commonResponseBody;

    /**
     * CIF番号リスト
     */
    private List<CifNumberResponseDto> cifNumberResponseDtoList;
    
}

package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 預金残高照会ABAリクエストDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class SavingsAccountsAbaRequestDto extends RequestBodyDto {

    /**
     * 店番
     */
    private String branchNumber;

    /**
     * 口座番号
     */
    private String accountNumber;

    /**
     * 預金種目
     */
    private String accountType;

}

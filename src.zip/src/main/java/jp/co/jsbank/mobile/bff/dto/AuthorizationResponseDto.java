package jp.co.jsbank.mobile.bff.dto;

import java.util.List;

import lombok.Data;

/**
 * 認証レスポンスDTO
 */
@Data
public class AuthorizationResponseDto {

    /**
     * 電話番号リスト
     */
    private List<String> phoneNumberList;
}

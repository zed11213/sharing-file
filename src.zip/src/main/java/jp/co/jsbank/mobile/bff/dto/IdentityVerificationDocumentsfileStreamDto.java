package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 本人確認書類DTO
 */
@Data
public class IdentityVerificationDocumentsfileStreamDto {

    /**
     * 書類種類
     */
    private String documentsType;

    /**
     * 画像ファイル
     */
    private String fileStream;

    /**
     * ファイル名
     */
    private String fileName;

}

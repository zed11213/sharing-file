package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 所在地情報保存ABAレスポンスDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class AddressInfomationAbaRequestDto extends RequestBodyDto {

    /**
     * 申込ステータス
     */
    private String applyStatus;

    /**
     * 郵便番号
     */
    private String zipCode;

    /**
     * 都道府県（カナ）
     */
    private String prefectureKana;

    /**
     * 都道府県
     */
    private String prefecture;

    /**
     * 市区町村（カナ）
     */
    private String cityKana;

    /**
     * 市区町村
     */
    private String city;

    /**
     * 丁目（カナ）
     */
    private String addrDetail2Kana;

    /**
     * 丁目
     */
    private String addrDetail2;

    /**
     * 番地（カナ）
     */
    private String addrDetail3Kana;

    /**
     * 番地
     */
    private String addrDetail3;

    /**
     * 建物名・号室（カナ）
     */
    private String buildingRoomKana;

    /**
     * 建物名・号室
     */
    private String buildingRoom;

    /**
     * 所在地相違区分
     */
    private String locationClassification;
    /**
     * 所在地郵便番号
     */
    private String locationZipCode;

    /**
     * 所在地都道府県（カナ）
     */
    private String locationPrefectureKana;

    /**
     * 所在地都道府県
     */
    private String locationPrefecture;

    /**
     * 所在地市区町村（カナ）
     */
    private String locationCityKana;

    /**
     * 所在地市区町村
     */
    private String locationCity;

    /**
     * 所在地丁目（カナ）
     */
    private String locationStreetKana;

    /**
     * 所在地丁目
     */
    private String locationStreet;

    /**
     * 所在地番地（カナ）
     */
    private String locationAddressKana;

    /**
     * 所在地番地
     */
    private String locationAddress;

    /**
     * 所在地建物名・号室（カナ）
     */
    private String locationBuildingRoomKana;

    /**
     * 所在地建物名・号室
     */
    private String locationBuildingRoom;

    /**
     * 画面ID
     */
    private String pageId;

}

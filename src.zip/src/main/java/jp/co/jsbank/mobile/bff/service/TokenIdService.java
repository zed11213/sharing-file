package jp.co.jsbank.mobile.bff.service;

import org.springframework.stereotype.Service;

import jp.co.jsbank.mobile.bff.entity.TokenIdEntity;

/**
 * トークンサービス
 */
@Service
public interface TokenIdService {

    /**
     * トークンIDを登録する
     *
     * @param tokenIdEntity TOKEN_MAPPINGエンティティ
     * @return トークンID
     */
    String insertIdAndToken(TokenIdEntity tokenIdEntity);

    /**
     * トークンIDを検索する
     *
     * @param token トークン
     * @return トークンID
     */
    String selectIdByToken(String token);

}

package jp.co.jsbank.mobile.bff.dto.aba;
import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 *  契約管理操作履歴照会ABAレスボスDTO
 */     
@Data
public class ContractManagementOperationHistoryInquiryAbaResponseDto {
	

	/**
	 * 共通レスポンス・ボディ
	 */
	private CommonResponseHeader commonResponseHeader;
	
	/**
	 * 受付番号
	 * */
	private String receiptNumber;
	
	/**
	 * 人格コード
	 */
	private String personCode;
	
}
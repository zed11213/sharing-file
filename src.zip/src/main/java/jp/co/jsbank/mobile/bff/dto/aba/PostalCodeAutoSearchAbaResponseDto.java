package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 郵便番号の自動検索ABAレスボスDto
 */
@Data
public class PostalCodeAutoSearchAbaResponseDto {
	
    /**
     * 共通レスポンス・ボディ
     */
    private CommonResponseHeader commonResponseHeader;
	
	/**
     * 都道府県
     */
    private String prefectures;

    /**
     * 市区町村
     */
    private String city;

    /**
     * 丁目
     */
    private String chome;

    /**
     * 都道府県（カナ）
     */
    private String prefecturesKana;

    /**
     * 市区町村（カナ）
     */
    private String cityKana;
    
    /**
     * 丁目（半角）
     */
    private String chomeHalfwidth;
    
    /**
     * 町漢字
     */
    private String addrDetail1;
    
    /**
     * 町カナ
     */
    private String addrdetail1Kana;

}

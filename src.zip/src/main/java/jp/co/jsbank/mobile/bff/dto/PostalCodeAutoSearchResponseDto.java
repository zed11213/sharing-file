package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 郵便番号の自動検索レスポンスDTO
 */
@Data
public class PostalCodeAutoSearchResponseDto {

    /**
     * 地区コード
     */
    private String addressCode;

    /**
     * 都道府県漢字
     */
    private String prefecture;

    /**
     * 市区町村漢字
     */
    private String city;

    /**
     * 町漢字
     */
    private String addrDetail1;

    /**
     * 丁目漢字
     */
    private String addrDetail2;

    /**
     * 都道府県カナ
     */
    private String prefectureKana;

    /**
     * 市区町村カナ
     */
    private String cityKana;

    /**
     * 町カナ
     */
    private String addrdetail1Kana;

    /**
     * 丁目カナ
     */
    private String addrdetail2Kana;

    /**
     * 郵便番号
     */
    private String zipCode;

    /**
     * 住所漢字丁目あり
     */
    private String address;

    /**
     * 住所カナ丁目あり
     */
    private String addressKana;

    /**
     * 住所漢字丁目なし
     */
    private String addressNashi;

    /**
     * 住所カナ丁目なし
     */
    private String addressKanaNashi;
}

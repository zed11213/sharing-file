package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * 契約管理操作履歴登録ABAリクエストDTO
 */
@Data
public class ContractManagementOperationHistoryRegistrationAbaRequestDto {

    /**
     * 受付番号
     */
    private String receiptNumber;
    
    /**
     * 人格区分
     */
    private String personType;
    
    /**
     * 画面ID
     */
    private String pageId;

}

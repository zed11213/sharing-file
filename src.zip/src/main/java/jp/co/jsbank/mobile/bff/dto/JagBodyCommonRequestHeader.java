package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * JAG共通リクエスト・ヘッダ
 */
@Data
public class JagBodyCommonRequestHeader {

    /**
     * 金融機関コード
     */
    private String bankCode;

    /**
     * ユーザーID
     */
    private String userID;
    
    /**
     * アプリケーションID
     */
    private String applicationID;
    
    /**
     * クライアントID
     */
    private String clientID;
    
    /**
     * 端末ID
     */
    private String deviceID;
}

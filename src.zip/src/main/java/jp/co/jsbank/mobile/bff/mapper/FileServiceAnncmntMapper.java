package jp.co.jsbank.mobile.bff.mapper;

import org.apache.ibatis.annotations.Mapper;

import jp.co.jsbank.mobile.bff.entity.FileServiceAnncmntEntity;

@Mapper
public interface FileServiceAnncmntMapper {
    /**
     * IDを検索する
     *
     * @param ID id
     * @return 申し込むお知らせエンティティ
     */
    FileServiceAnncmntEntity selectByAnncmntId(String anncmntId);
}

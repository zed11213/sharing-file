package jp.co.jsbank.mobile.bff.dto;

import java.util.List;

import lombok.Data;

/**
 * 帳票CSV内容照会_定期預金（自継）大口定期利息計算レスポンスDTO
 */
@Data
public class InquireReport006ResponseDto {
	
    /**
     * 帳票バージョン
     */
    private String formVersion;

    /**
     * 本状作成日
     */
    private String bookCreateDate;

    /**
     * 自動継続定期預金お利息計算明細表リスト
     */
    private List<AutomaticRenewalTimeDepositInterestCalculationDto> automaticRenewalTimeDepositInterestCalculationList;

    /**
     * 取扱店名
     */
    private String branchKanjiName;

    /**
     * 取扱電話番号
     */
    private String branchPhoneNumber;
}

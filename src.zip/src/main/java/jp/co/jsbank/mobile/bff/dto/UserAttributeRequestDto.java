package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 利用者属性情報
 */
@Data
public class UserAttributeRequestDto {

	/**
	 * 事業先利用者認証キー
	 */
	private String certKey;
	
}

package jp.co.jsbank.mobile.bff.mapper;

import org.apache.ibatis.annotations.Mapper;

import jp.co.jsbank.mobile.bff.entity.TokenIdEntity;

/**
 * トークンマッパー
 */
@Mapper
public interface TokenIdMapper {

    /**
     * トークンIDを検索する
     *
     * @param tokenId トークンID
     * @return ID
     */
    String selectIdByToken(String tokenId);

    /**
     * トークンIDを追加する
     *
     * @param tokenIdEntity トークンIDエンティティ
     */
    void insertIdAndToken(TokenIdEntity tokenIdEntity);

    /**
     * IDを検索する
     *
     * @param ID id
     * @return トークン
     */
    String selectTokenByID(String id);

    /**
     * テストデータ取得
     *
     * @param id ID
     * @param apiName API名
     * @return JSON
     */
    String selectIdTestData(String userId, String apiPath);
}

package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 利用口座登録BFFリクエストDTO
 */
@Data
public class UseAccountRegistrationRequestDto {

    /**
     * 店番
     */
    private String branchCode;

    /**
     * 登録口座番号
     */
    private String registerAccountNumber;

    /**
     * 預金種目
     */
    private String accountType;

    /**
     * 通帳レス設定状態[１：実施、そのた：実施しない]
     */
    private String passbookLessSettingStatus;

    /**
     * 初回登録フラグ
     */
    private String registerFlg;

    /**
     * サブNo
     */
    private String subNo;

}

package jp.co.jsbank.mobile.bff.dto.liquidekyc;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import lombok.Data;

/**
 * 自動判定結果取得の真贋確認 結果
 * EkycFacePhotoResponseDto
 */

@Data
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class EkycVerificationResultDto {
    /**
     * 顔真贋確認結果
     * 容貌真贋判定タイプ = アクティブ判定の場合
）
     */
    private String faceVerification;
    
    /**
     * 顔真贋確認スコア
     * 
     * 容貌真贋判定タイプ = アクティブ判定の場合
     * 顔の一致度を示す数字であり、数字が大きいほうが一致度が高い。
     * 範囲は、-1,000～1,000となる
     * 
     * 容貌真贋判定タイプ =　パッシブ判判定の場合：null
     * 
     */
    private String faceVerificationScore;
    
    /**
     * 顔写真照合結果
     * 本人確認書類の顔写真と顔「正面」画像の同一致判定処理の結果
     */
    private String facePhotoVerification;

    /**
     * 顔写真照合結果スコア
     * 顔の一致度を示す数字であり、数字が大きいほうが一致度が高い。
     * 範囲は、-1,000～1,000となる。
     */
    private int facePhotoVerificationScore;
    
    /**
     * 書類真贋確認結果
     * 書類真贋判定なしの場合：null
     * 書類真贋判定タイプ=パッシブ判定の場合：本人確認書類「表面」画像の真贋判定結果
     * 
     */
    private String idDocumentVerification;

    /**
     * 書類真贋確認結果スコア
     * 
     * 書類真贋判定なしの場合：null
     * 
     * 書類真贋判定タイプ=パッシブ判定の場合：
     * 本人確認書類の真正性（本物）を示す数値であり、数字が大きいほど真正（本物）となる。
     * 範囲は、0～1となる。小数点第3位まで返却。
     */
    private int idDocumentVerificationScore;

    /**
     * インジェクション攻撃判定結果
     * マスタコード表参照
     */
    private String injectionAttackVerification;
}

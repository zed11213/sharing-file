package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * IBパスワード設定BFFリクエストDTO
 */
@Data
public class IbPasswordSettingRequestDto {

    /**
     * 受付番号
     */
    private String receptionNumber;

    /**
     * IBパスワード
     */
    private String ibPassword;

    /**
     * CC暗証番号
     */
    private String ccPassword;

    /**
     * 人格区分
     */
    private String personalityKubun;

    /**
     * 更新パターン
     */
    private String updateType;
}

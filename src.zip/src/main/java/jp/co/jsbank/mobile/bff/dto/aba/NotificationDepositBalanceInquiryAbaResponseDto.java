package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 通知預金明細レスポンスDTO
 */
@Data
public class NotificationDepositBalanceInquiryAbaResponseDto {

    /**
     * 共通レスポンス・ヘッダ
     */
    private CommonResponseHeader commonResponseHeader;

    /**
     * CIF番号
     */
    private String cifNumber;

    /**
     * 預金種目
     */
    private String accountType;

    /**
     * 店番
     */
    private String branchNumber;

    /**
     * 口座番号
     */
    private String accountNumber;

    /**
     * サブNo
     */
    private String accountSubNumber;

    /**
     * 課税区分
     */
    private String taxClassCode;

    /**
     * 課税区分（文言）
     */
    private String taxClassName;

    /**
     * 契約日
     */
    private String contractDate;

    /**
     * 当初契約日
     */
    private String initialContractDate;

    /**
     * 元帳残高
     */
    private String balanceOfLedger;

    /**
     * 当初金額
     */
    private String startAmount;

    /**
     * 利率
     */
    private String interestRate;

}

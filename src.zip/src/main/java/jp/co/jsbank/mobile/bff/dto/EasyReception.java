package jp.co.jsbank.mobile.bff.dto;
import lombok.Data;

/**
 * かんたん受付DTO
 */
@Data
public class EasyReception {

	/**
     * お知らせID
     */
    private String anncmntId;
    
	/**
     * タイトル
     */
    private String anncmntTitle;
    
	/**
     * 作成日時
     */
    private String createDateAndTime;
    
	/**
     * 受付案内ステータス
     */
    private String receptionGuideStatus;
    
	/**
     * 受付案内種類
     */
    private String receptionGuideType;
    
	/**
     * 掲載開始日時
     */
    private String anncmntStartTime;
    
	/**
     * 掲載終了日時
     */
    private String anncmntEndTime;
    
	/**
     * 非会員受付有無フラグ
     */
    private String nonMemberAplyFlg;
    
	/**
     * 判定結果
     */
    private String judgementResult;

}

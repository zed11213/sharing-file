package jp.co.jsbank.mobile.bff.dto.liquidekyc;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import lombok.Data;

@Data
/**
 * 画像データ取得の顔正面画像
 * EkycFacePhotoResponseDto
 */
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class EkycCommonPhotoDto {
    
    /**
     * 顔正面　画像ファイル名
     */
    private String fileName;

    /**
     * 顔正面　画像データ　Base64
     */
    private String image;
    
}

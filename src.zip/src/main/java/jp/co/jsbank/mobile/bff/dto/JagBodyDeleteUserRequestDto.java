package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * ユーザー削除リクエストDTO
 */
@Data
public class JagBodyDeleteUserRequestDto {

    /**
     * 共通リクエスト・ヘッダ
     */
    private JagBodyCommonRequestHeader commonRequestHeader;

    /**
     * JBAID
     */
    private String jagJbaId;
    
    /**
     * ユーザーID
     */
    private String jagUserId;
  
}

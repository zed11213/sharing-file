package jp.co.jsbank.mobile.bff.dto;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.aba.CifAttributeQueryInfomationDto;
import lombok.Data;

/**
 * 通帳レス情報BFFリクエストDTO
 */
@Data
public class PassbooklessSettingRequestDto {

    /**
     * CIF情報取得
     */
    private List<CifAttributeQueryInfomationDto> cifInfomationDtoList;
}

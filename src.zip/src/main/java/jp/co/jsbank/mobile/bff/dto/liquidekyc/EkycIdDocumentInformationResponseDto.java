package jp.co.jsbank.mobile.bff.dto.liquidekyc;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import java.util.List;

import lombok.Data;

/**
 * ICカード読取情報取得結果
 * EkycIdDocumentInformationResponseDto
 */

@Data
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class EkycIdDocumentInformationResponseDto {
    
    /**
     * 本人確認書類コード
     */
    private String idDocumentType;

    /**
     * 券面顔写真：ICカードに保存されていた顔写真
     */
    private EkycCommonPhotoDto idFacePhoto;
   
    /**
     * 氏名
     */
    private String name;

    /**
     * 旧氏名
     */
    private String previousName;

    /**
     * 通称名　免許証に記載されている場合
     */
    private String aliasName;

    /**
     * 氏名　全角（カナ）
     */
    private String nameKana;
    
    /**
     *　氏名　半角（カナ） 
     */
    private String nameHalfWidthKana;

    /**
     * 生年月日　西歴
     */
    private String birthday;

    /**
     * 住所
     */
    private String address;

    /**
     * 住所　都道府県　有償オプション
     */
    private String addressPref;

     /**
     * 住所　市区町村　有償オプション
     */
    private String addressCity;

     /**
     * 住所　有償オプション　
     */
    private String addressOther;

     /**
     * 本人確認書類番号
     */
    private String idNumber;

     /**
     * 有効期限　西歴
     */
    private String expireDate;

     /**
     * 性別　免許証：null マイナンバーカード：マスタコード参照
     */
    private String sex;

     /**
     * 氏名の外字画像配列　最大７枚
     */
    private List<EkycCommonPhotoDto> nameExternalCharacters;

    /**
     * 旧氏名の外字画像配列　最大７枚
     */
    private List<EkycCommonPhotoDto> previousNameExternalCharacters;

    /**
     * 住所の外字画像配列　最大７枚
     */
    private List<EkycCommonPhotoDto> addressExternalCharacters;

    /**
     * 通称名の外字画像配列 最大７枚
     */
    private List<EkycCommonPhotoDto> aliasNameExternalCharacters;

    /**
     * 公的個人認証
     */
    private EkycJpikIdentificationResultDto jpkiIdentificationResult;

    /**
     * 郵便番号
     */
    private String zipCode;

    /**
     * 氏名変更フラグ　
     * 免許証：
     * ０：変更なし
     * １：変更あり
     * 他：null
     */
    private String nameChanged;

    /**
     * 住所変更フラグ　
     * 免許証：
     * ０：変更なし
     * １：変更あり
     * 他：null
     */
    private String addressChanged;

    /**
     * 日本人外国人判定　
     * 免許証、マイナンバーカード：
     * １：日本人
     * ２：外国人
     * 他：null
     */
    private String japaneseForeignerJudgment;

     /**
     *  国外転出有無
     * マイナンバーカード：
     * 0：不明
     * 1：なし
     * 2：あり
     * 他：null
     */
    private String  isMovedAbroad;

     /**
     *  国外転出予定日
     * マイナンバーカードのみ
     * 他：null
     */
    private String plannedAbroadMoveDate;

    /**
     * マイナ免許証免許情報記録番号
     * マイナンバーカード（＋免許情報）のみ
     */
    private String myNaDriversLicenseRecordNumber;

    /**
     * マイナ免許証免許有効期間末日
     * マイナンバーカード（＋免許情報）のみ
     */
    private String myNaDriversLicenseExpireDate;


    /**
     * マイナ免許証免許券面顔写真
     * マイナンバーカード（＋免許情報）のみ
     */
    private EkycCommonPhotoDto myNaDriversLicenseFacePhoto;
    
}


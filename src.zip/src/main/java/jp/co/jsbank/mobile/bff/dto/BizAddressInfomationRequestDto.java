package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * biz所在地情報リクエストDTO
 */
@Data
public class BizAddressInfomationRequestDto {
    /**
     * 受付番号
     */
    private String receiptNumber;

    /**
     * 所在地郵便番号
     */
    private String locationZipCode;

    /**
     * 所在地都道府県（カナ）
     */
    private String locationPrefectureKana;

    /**
     * 所在地都道府県
     */
    private String locationPrefecture;

    /**
     * 所在地市区町村（カナ）
     */
    private String locationCityKana;

    /**
     * 所在地市区町村
     */
    private String locationCity;

    /**
     * 所在地丁目（カナ）
     */
    private String locationStreetKana;

    /**
     * 所在地丁目
     */
    private String locationStreet;

    /**
     * 所在地番地（カナ）
     */
    private String locationAddressKana;

    /**
     * 所在地番地
     */
    private String locationAddress;

    /**
     * 建物名・号室（カナ）
     */
    private String locationBuildingRoomKana;

    /**
     * 建物名・号室
     */
    private String locationBuildingRoom;
    /**
     * 本店所在地相違区分
     */
    private String headOfficeClassification;

    /**
     * 本店所在地都道府県（カナ）
     */
    private String headOfficeLocPrefectureKana;

    /**
     * 本店所在地都道府県
     */
    private String headOfficeLocPrefecture;

    /**
     * 本店所在地市区町村（カナ）
     */
    private String headOfficeLocCityKana;

    /**
     * 本店所在地市区町村
     */
    private String headOfficeLocCity;

    /**
     * 本店所在地丁目（カナ）
     */
    private String headOfficeLocStreetKana;

    /**
     * 本店所在地丁目
     */
    private String headOfficeLocStreet;

    /**
     * 本店所在地番地（カナ）
     */
    private String headOfficeLocAddressKana;

    /**
     * 本店所在地番地
     */
    private String headOfficeLocAddress;

    /**
     * 本店所在地建物名・号室（カナ）
     */
    private String headOfficeLocBuildingRoomKana;

    /**
     * 本店所在地建物名・号室
     */
    private String headOfficeLocBuildingRoom;
    /**
     * 画面ID
     */
    private String pageId;

    /**
     * 本店所在地郵便番号
     */
    private String headOfficeLocZipCode;

    /**
     * 更新パターン
     */
    private String updateType;
}

package jp.co.jsbank.mobile.bff.dto;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.aba.ApplyIdDto;
import lombok.Data;

/**
 * かんたん受付回答DTO
 */
@Data
public class ReceptionAnswerDataDto {

    /**
     * 回答ID
     */
    private String responseId;

    /**
     * 作成日時
     */
    private String createDateAndTime;

    /**
     * 回答本文
     */
    private String responseMsg;

    /**
     * 回答画像有無フラグ
     */
    private String resImgFlg;

    /**
     * 回答画像位置
     */
    private String resImgVPosition;

    /**
     * 回答画像バケット名PUB
     */
    private String resImgBucketPub;

    /**
     * 回答画像バケット名PVT
     */
    private String resImgBucketPvt;

    /**
     * 回答画像ファイル名
     */
    private String resImgFilename;

    /**
     * ボタン種類
     */
    private String btnType;

    /**
     * ボタンリンク先有無フラグ
     */
    private String btnLinkFlg;

    /**
     * ボタンリンク先URL
     */
    private String btnLinkUrl;

    /**
     * 簡易受付結果
     */
    private String simpleReceptionResult;

    /**
     * 回答先申込IDリスト
     */
    private List<ApplyIdDto> applyIdList;

    /**
     * 回答方法種別
     */
    private String responseMethodType;

    /**
     * 回答ステータス
     */
    private String responseStatus;

    /**
     * 更新タイムスタンプ(排他用)
     */
    private String updateTs;

    /**
     * 公開フラグ
     */
    private String publicFlg;

    /**
     * 公開中フラグ
     */
    private String releasedFlg;
}

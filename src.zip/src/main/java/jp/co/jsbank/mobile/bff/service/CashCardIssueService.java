package jp.co.jsbank.mobile.bff.service;

import org.springframework.stereotype.Service;

import jp.co.jsbank.mobile.bff.dto.CardDesignSelectionRequestDto;
import jp.co.jsbank.mobile.bff.dto.CcIssuingRequestDto;
import jp.co.jsbank.mobile.bff.dto.CcPasswordIbPasswordSettingRequestDto;
import jp.co.jsbank.mobile.bff.dto.EmailAddressAuthorizationRequestDto;
import jp.co.jsbank.mobile.bff.dto.IdentificationRequestDto;
import jp.co.jsbank.mobile.bff.dto.IdentificationResponseDto;
import jp.co.jsbank.mobile.bff.dto.IvrAuthenticationRequestDto;
import jp.co.jsbank.mobile.bff.dto.IvrAuthenticationResponseDto;

/**
 * キャッシュカード発行サービス
 */
@Service
public interface CashCardIssueService {

    /**
     * CC暗証番号・IBパスワード設定処理
     *
     * @param requestDto CC暗証番号・IBパスワード設定リクエストDTO
     * @return 処理結果
     * @throws Exception 異常
     */
    String ccPasswordIbPasswordSetting(CcPasswordIbPasswordSettingRequestDto requestDto) throws Exception;

    /**
     * カードデザイン選択
     *
     * @param requestDto カードデザイン選択リクエストDTO
     *
     * @return receptionNumber 受付番号
     */
    String cardDesignSelection(CardDesignSelectionRequestDto requestDto);

    /**
     * CC発行依頼
     *
     * @param requestDto CC発行依頼リクエストDTO
     *
     * @return receptionNumber 受付番号
     */
    String getCcIssuing(CcIssuingRequestDto requestDto);

    /**
     * 本人確認
     *
     * @param requestDto 本人確認リクエストDTO
     * @return 処理結果
     */
    IdentificationResponseDto identityVerification(IdentificationRequestDto requestDto);

    /**
     * メールアドレス認証
     *
     * @param requestDto メールアドレス認証リクエストDTO
     * @return 処理結果
     */
    String emailAddressAuthorization(EmailAddressAuthorizationRequestDto requestDto);

    /**
     * IVR認証
     *
     * @param requestDto IVR認証リクエストDTO
     * @return [確認ダイアログ]画面表示
     */
    IvrAuthenticationResponseDto ivrAuthentication(IvrAuthenticationRequestDto requestDto);

}

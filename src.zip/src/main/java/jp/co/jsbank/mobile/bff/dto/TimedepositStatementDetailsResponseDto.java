package jp.co.jsbank.mobile.bff.dto;

import java.util.List;

import lombok.Data;

/**
 * 定期預金明細情報レスポンスDTO
 */
@Data
public class TimedepositStatementDetailsResponseDto {

    /**
     * リストリスト
     */
    private  List<TimeDepositDetailsResponseDto> timeDepositDetailsResponseDtoList;

    /**
     * 抽選結果リスト
     */
    private  List<LotteryResultsDetailsResponseDto> lotteryResultsDetailsResponseDto;
    
}

package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * ログイン履歴レスポンスDTO
 */
@Data
public class LoginHistoryResponseDto {

    /**
     * ログイン日時
     */
    private String loginTs;

    /**
     * トークン発行済フラグ
     */
    private String tokenFlg;
}

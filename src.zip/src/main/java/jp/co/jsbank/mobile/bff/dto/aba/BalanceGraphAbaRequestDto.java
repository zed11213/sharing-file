package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 収支グラフ情報ABAリクエストDTO
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class BalanceGraphAbaRequestDto extends RequestBodyDto {

    /**
     * 口座番号
     */
    private String accountNumber;

    /**
     * 店番
     */
    private String branchNumber;

    /**
     * 顧客ID
     */
    private String customerId;
    
    /**
     * 預金種目
     */
    private String accountType;
}

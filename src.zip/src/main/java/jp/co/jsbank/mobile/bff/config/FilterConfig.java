package jp.co.jsbank.mobile.bff.config;

import javax.servlet.DispatcherType;

import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import jp.co.jsbank.mobile.bff.config.filter.ParamsFilter;

/**
 * フィルタ構成クラス
 */
@Configuration
public class FilterConfig {

    /**
     * フィルタ構成
     * 
     * @return フィルタ
     */
    @Bean
    public FilterRegistrationBean<ParamsFilter> parmsFilterRegistration() {
        FilterRegistrationBean<ParamsFilter> registration = new FilterRegistrationBean<ParamsFilter>();
        registration.setDispatcherTypes(DispatcherType.REQUEST);
        registration.setFilter(new ParamsFilter());
        registration.addUrlPatterns("/*");
        return registration;
    }

}

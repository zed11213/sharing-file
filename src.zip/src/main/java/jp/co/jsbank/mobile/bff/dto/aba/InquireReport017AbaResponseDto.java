package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 帳票CSV内容照会_貸金庫使用料期日案内ABAレスポンスDTO
 */
@Data
public class InquireReport017AbaResponseDto {

    /**
     * 共通レスポンスヘッダ
     */
    private CommonResponseHeader commonResponseHeader;

    /**
     * 帳票バージョン
     */
    private String formVersion;

    /**
     * 作成日
     */
    private String createDate;

    /**
     * 契約番号
     */
    private String contractNumber;

    /**
     * 契約番号_種別
     */
    private String contractNumberKind;
    
    /**
     * 契約番号_種類
     */
    private String contractNumberType;
    
    /**
     * 使用料期日
     */
    private String usageFeeDueDate;

    /**
     * 使用料
     */
    private String usageFee;

    /**
     * 振替日
     */
    private String transferDate;

    /**
     * ご指定預金口座科目名
     */
    private String specifiedDepositAccountName;
    
    /**
     * ご指定預金口座番号
     */
    private String specifiedDepositAccountNumber;
    
    /**
     * 取扱店名
     */
    private String branchKanjiName;

    /**
     * 取扱電話番号
     */
    private String branchPhoneNumber;
}

package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import jp.co.jsbank.mobile.bff.dto.TimeDepositDateDto;
import lombok.Data;

/**
 * 帳票CSV内容照会_定期預金（自由金利）期日案内ABAレスポンスDTO
 */
@Data
public class InquireReport007AbaResponseDto {
	
    /**
     * 共通レスポンスヘッダ
     */
    private CommonResponseHeader commonResponseHeader;

    /**
     * 帳票バージョン
     */
    private String formVersion;

    /**
     * 本状作成日
     */
    private String bookCreateDate;

    /**
     * 定期預金等期日明細表リスト
     */
    private List<TimeDepositDateDto> timeDepositDateList;

    /**
     * マル優申告限度額
     */
    private String declarationLimitAmount;

    /**
     * ご利用額(預金)
     */
    private String usageAmount;

    /**
     * 取扱店名
     */
    private String branchKanjiName;

    /**
     * 取扱電話番号
     */
    private String branchPhoneNumber;
}

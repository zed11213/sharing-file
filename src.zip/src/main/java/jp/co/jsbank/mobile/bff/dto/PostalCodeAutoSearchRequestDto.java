package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 郵便番号の自動検索リクエストDTO
 */
@Data
public class PostalCodeAutoSearchRequestDto {

    /**
     * 郵便番号
     */
    private String postalCode;
    
}

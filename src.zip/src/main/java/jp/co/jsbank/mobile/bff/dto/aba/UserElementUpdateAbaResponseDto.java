package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * メールアドレス認証AbaレスポンスDTO
 */
@Data
public class UserElementUpdateAbaResponseDto {
	
	
	 /**
     * 共通レスポンス・ボディ
     */
    private CommonResponseHeader commonResponseHeader;   
    
 }

package jp.co.jsbank.mobile.bff.dto;

import java.util.List;

import lombok.Data;

/**
 * 口座開設申込内容照会（個人）DTO
 */
@Data
public class AccountOpenAppliIndividualInfoDto {

    /**
     * 受付番号
     */
    private String receiptNumber;

    /**
     * CIF番号
     */
    private String cifNumber;

    /**
     * 申込ステータス
     */
    private String applyStatus;

    /**
     * キャッシュカード種類
     */
    private String cashCardType;

    /**
     * 人格区分
     */
    private String personType;

    /**
     * 取引種別
     */
    private String transactionType;

    /**
     * 申込日
     */
    private String applicationDate;

    /**
     * 申請開始日時
     */
    private String applyStartDateTime;

    /**
     * 申請有効期限日時
     */
    private String applyValidDateTime;

    /**
     * バージョン
     */
    private String version;

    /**
     * カナ氏名（姓）
     */
    private String customerLastName;

    /**
     * カナ氏名（名）
     */
    private String customerFirstName;

    /**
     * 氏名漢字（姓）
     */
    private String customerKanjiLastName;

    /**
     * 氏名漢字（名）
     */
    private String customerKanjiFirstName;

    /**
     * 性別
     */
    private String gender;

    /**
     * 性別回答有無
     */
    private String genderAnswer;

    /**
     * 生年月日
     */
    private String birthday;

    /**
     * 郵便番号
     */
    private String zipCode;

    /**
     * 地区コード
     */
    private String addressCode;

    /**
     * 地区コード（枝番）
     */
    private String addressCodeBranchNumber;

    /**
     * 都道府県（カナ）
     */
    private String prefectureKana;

    /**
     * 都道府県
     */
    private String prefecture;

    /**
     * 市区町村（カナ）
     */
    private String cityKana;

    /**
     * 市区町村
     */
    private String city;

    /**
     * 丁目（カナ）
     */
    private String addrDetail2Kana;

    /**
     * 丁目
     */
    private String addrDetail2;

    /**
     * 番地（カナ）
     */
    private String addrDetail3Kana;

    /**
     * 番地
     */
    private String addrDetail3;

    /**
     * 建物名・号室（カナ）
     */
    private String buildingRoomKana;

    /**
     * 建物名・号室
     */
    private String buildingRoom;

    /**
     * 電話番号１種別
     */
    private String phoneType1;

    /**
     * 電話番号１（上）
     */
    private String phoneNumOneFirst;

    /**
     * 電話番号１（中）
     */
    private String phoneNumOneMid;

    /**
     * 電話番号１（下）
     */
    private String phoneNumOneLast;

    /**
     * 電話番号２種別
     */
    private String phoneType2;

    /**
     * 電話番号２（上）
     */
    private String phoneNumTwoFirst;

    /**
     * 電話番号２（中）
     */
    private String phoneNumTwoMid;

    /**
     * 電話番号２（下）
     */
    private String phoneNumTwoLast;

    /**
     * 職業
     */
    private String occupation;

    /**
     * 職業（その他）
     */
    private String occupationOther;

    /**
     * 取引目的
     */
    private String transactPurpose;

    /**
     * 取引目的（その他）
     */
    private String transactPurposeOther;

    /**
     * 取引のきっかけ
     */
    private String transactionTrigger;

    /**
     * 店番
     */
    private String branchNumber;

    /**
     * 預金種目
     */
    private String accountType;

    /**
     * 口座番号
     */
    private String accountNumber;

    /**
     * サブNo
     */
    private String accountSubNumber;

    /**
     * 勤務先名
     */
    private String wpName;

    /**
     * 勤務先郵便番号
     */
    private String wpZipCode;

    /**
     * 勤務先都道府県
     */
    private String wpPrefecture;

    /**
     * 勤務先市区町村
     */
    private String wpCity;

    /**
     * 勤務先丁目
     */
    private String wpStreet;

    /**
     * 勤務先番地
     */
    private String wpAddress;

    /**
     * 勤務先建物名・号室
     */
    private String wpBuilding;

    /**
     * 勤務先電話番号種別
     */
    private String wpPhoneType;

    /**
     * 勤務先電話番号（上）
     */
    private String wpPhoneFirst;

    /**
     * 勤務先電話番号（中）
     */
    private String wpPhoneMid;

    /**
     * 勤務先電話番号（下）
     */
    private String wpPhoneLast;

    /**
     * 学校名
     */
    private String schName;

    /**
     * 学校郵便番号
     */
    private String schZipCode;

    /**
     * 学校都道府県
     */
    private String schPrefectures;

    /**
     * 学校市区町村
     */
    private String schCity;

    /**
     * 学校丁目
     */
    private String schStreet;

    /**
     * 学校番地
     */
    private String schAddress;

    /**
     * 学校建物名・号室
     */
    private String schBuilding;

    /**
     * 学校電話番号（電話区分）
     */
    private String schPhoneNumberType;

    /**
     * 学校電話番号（上）
     */
    private String schPhoneNumberFirst;

    /**
     * 学校電話番号（中）
     */
    private String schPhoneNumberMid;

    /**
     * 学校電話番号（下）
     */
    private String schPhoneNumberLast;

    /**
     * メールアドレス
     */
    private String emailAddress;

    /**
     * 開設店番
     */
    private String openBranchNumber;

    /**
     * 他店開設希望理由
     */
    private String reasonToOpenAccAnotherBranch;

    /**
     * 他店開設希望理由（その他）
     */
    private String reasonToOpenAccAnotherBranchOther;

    /**
     * eKYC確認結果
     */
    private String ekycResult;

    /**
     * 本人確認書類リスト
     */
    private List<IdentityVerificationDocumentsfileStreamDto> identityDocuments;

 // 2025/01/29 共同化ため実質的支配者の電話番号start
    /**
     * 業種
     */
    private String category;

    /**
     * 業務内容（名称）
     */
    private String businessContentName;

    /**
     * 業務内容その他
     */
    private String businessContentOtherDescribeAnswer;

    /**
     * 役職（名称）
     */
    private String pstnName;

    /**
     * 役職その他記述回答
     */
    private String pstnOtherDescribeAnswer;

    /**
     * 年収
     */
    private String annualIncome;

    /**
     * 取引原資（名称）
     */
    private String transOriginalCapitalName;

    /**
     * 取引原資その他
     */
    private String transOriginalCapitalOtherDescribeAnswer;


    /**
     * 毎月の取引金額
     */
    private String monthlyTransAmountName;

    /**
     *取引頻度
     */
    private String transFrequencyName;

    /**
     * ２００万超の現金取引予定
     */
    private String twoMillionMoreCashTransScheduled;

    /**
     * ２００万超取引理由
     */
    private String twoMillionMoreTransReason;

    /**
     * ２００万超取引頻度
     */
    private String twoMillionMoreTransFrequencyName;

    /**
     * ２００万超取引金額
     */
    private String twoMillionMoreTransAmountName;

    /**
     * 上場／非上場
     */
    private String playOrNotPlay;

    /**
     * IB暗証番号
     */
    private String ibPinCode;
    // 2025/01/29 共同化ため実質的支配者の電話番号end
}

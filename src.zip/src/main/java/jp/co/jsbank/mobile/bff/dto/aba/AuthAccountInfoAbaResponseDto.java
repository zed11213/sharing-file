package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 口座情報認証ABAレスボスDTO
 */
@Data
public class AuthAccountInfoAbaResponseDto {

	/**
	 * ABA応答共通ヘッダー
	 */
	private CommonResponseHeader commonResponseHeader;

	/**
	 * CIF番号
	 */
	private String cifNumber;

	/**
	 * 性別
	 */
	private String gender;

	/**
	 * 郵便番号
	 */
	private String zipCode;

	/**
	 * 地区コード
	 */
	private String addressCode;

	/**
	 * 住所
	 */
	private String address;

	/**
	 * 番地
	 */
	private String addrDetail3;

	/**
	 * 住所方書（カナ）
	 */
	private String addressDetailKana;

	/**
	 * 住所方書
	 */
	private String addressDetail;

	/**
	 * 電話番号1
	 */
	private String phoneNumber1;

	/**
	 * 電話番号2
	 */
	private String phoneNumber2;

	/**
	 * 電話番号3
	 */
	private String phoneNumber3;

	/**
	 * 人格コード
	 */
	private String personCode;

	/**
	 * カナ氏名
	 */
	private String customerName;

	/**
	 * 漢字氏名
	 */
	private String customerKanjiName;

}

package jp.co.jsbank.mobile.bff.mapper;

import org.apache.ibatis.annotations.Mapper;

import jp.co.jsbank.mobile.bff.entity.FileServiceNotificationEntity;

@Mapper
public interface FileServiceNotificationMapper {

    /**
     * シリアルナンバーと利用確認IDで検索する
     *
     * @param serialNumber シリアルナンバー
     * @param queryId 利用確認ID
     * @return FileServiceNotificationEntity
     */
    FileServiceNotificationEntity selectBySerialNumberAndQueryId(String serialNumber, String queryId);
}

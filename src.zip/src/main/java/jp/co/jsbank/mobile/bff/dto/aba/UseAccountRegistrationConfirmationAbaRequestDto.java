package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 利用口座登録ABAリクエストDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class UseAccountRegistrationConfirmationAbaRequestDto extends RequestBodyDto {
    
    /**
     * 店番
     */
    private String branchCode;

    /**
     * 口座番号
     */
    private String accountNumber;

    /**
     * 預金種目
     */
    private String accountType;

}

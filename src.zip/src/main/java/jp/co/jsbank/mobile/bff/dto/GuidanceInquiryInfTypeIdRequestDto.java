package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * お知らせ種別IDで案内照会リクエストDTO
 */
@Data
public class GuidanceInquiryInfTypeIdRequestDto {

    /**
     * お知らせID
     */
    private String anncmntId;
    
    /**
     * 受付案内ステータス
     */
    private String receptionGuideStatus;
}

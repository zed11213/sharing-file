package jp.co.jsbank.mobile.bff.dto;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.aba.CifNumberDto;
import lombok.Data;

/**
 * お知らせ一覧DTO
 */
@Data
public class AnnouncementDto {

    /**
     * お知らせ種別コード
     */
    private String anncmntType;

    /**
     * 文書種別コード
     */
    private String documentType;

    /**
     * メッセージ内容種別
     */
    private String mobileMsgType;

    /**
     * お知らせID
     */
    private String anncmntId;

    /**
     * 申込ID
     */
    private String applyId;

    /**
     * 顧客ID
     */
    private String customerId;

    /**
     * CIF番号リスト
     */
    private List<CifInfomationDto> cifNoList;

    /**
     * CIF番号情報リスト
     */
    private List<CifNumberDto> cifNumberList;

    /**
     * 受付案内種類
     */
    private String receptionGuideType;

    /**
     * 掲載開始日時
     */
    private String anncmntStartDateAndTime;

    /**
     * 掲載終了日時
     */
    private String anncmntEndDateAndTime;

    /**
     * 作成日時
     */
    private String createTs;

    /**
     * 公開日時
     */
    private String anncmntDateAndTime;

    /**
     * お知らせタイトル
     */
    private String anncmntTitle;

    /**
     * 店番
     */
    private String branchCode;

    /**
     * 口座番号
     */
    private String accountNumber;

    /**
     * 預金種目
     */
    private String accountType;

    /**
     * お気に入りフラグ
     */
    private String bookmarkFlg;

    /**
     * 既読フラグ
     */
    private String readFlag;

    /**
     * 個別確認結果フラグ
     */
    private String confirmFlg;

    /**
     * 帳票最終ダウンロード日時
     */
    private String reportLastDlTs;

    /**
     * カナ氏名
     */
    private String customerName;

    /**
     * 漢字氏名
     */
    private String customerKanjiName;

    /**
     * 生（設立）年月日
     */
    private String birthday;

    /**
     * 人格区分
     */
    private String personCode;
}

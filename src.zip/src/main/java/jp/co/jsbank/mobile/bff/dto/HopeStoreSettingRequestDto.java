package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 希望店設定BFFリクエストDTO
 */
@Data
public class HopeStoreSettingRequestDto {

    /**
     * 受付番号
     */
    private String receptionNumber;

    /**
     * 人格区分
     */
    private String personType;

    /**
     * 希望部店
     */
    private String hopeDepartmentStore;

    /**
     * 他店開設希望理由
     */
    private String reasonToOpenAccAnotherBranch;

    /**
     * 他店開設希望理由（その他）
     */
    private String reasonToOpenAccAnotherBranchOther;

    /**
     * 更新パターン
     */
    private String updateType;
}

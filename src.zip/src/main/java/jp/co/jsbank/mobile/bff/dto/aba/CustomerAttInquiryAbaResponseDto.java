package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 顧客属性照会AbaレスポンスDTO
 */
@Data
public class CustomerAttInquiryAbaResponseDto {
	
	
	 /**
     * 共通レスポンス・ボディ
     */
    private CommonResponseHeader commonResponseHeader;
    
	 /**
     * 電話番号
     */
    private String phoneNuumber;
 }

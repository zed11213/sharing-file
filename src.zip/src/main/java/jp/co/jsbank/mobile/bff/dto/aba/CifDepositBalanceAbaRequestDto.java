package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * CIF預金残高一覧照会リクエストDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class CifDepositBalanceAbaRequestDto extends RequestBodyDto {

    /**
     * CIF番号
     */
    private String cifNumber;

    /**
     * 店番
     */
    private String branchNumber;

}

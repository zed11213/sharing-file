package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 城南信用金庫バンキングアプリ.
 * TRXID取得 / 応答電文.
 *
 * History:
 * 2022.02.20  Manabu Hanzaike  初版.
 *
 * @author Manabu Hanziake - mhanz@jp.ibm.com
 *
 */
@Data
public class JagBodyTrxGetIdResponse {
	private JagBodyCommonResponseHeader commonResponseHeader;

	private String jagTrxId;
}
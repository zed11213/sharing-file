package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 普通預金口座情報DTO
 */
@Data
public class OrdinaryDepositAccountInformationDto {

    /**
     * 預金種目
     */
    private String accountType;

    /**
     * 店番
     */
    private String accountBranchNumber;

    /**
     * 口座番号
     */
    private String accountNumber;
}

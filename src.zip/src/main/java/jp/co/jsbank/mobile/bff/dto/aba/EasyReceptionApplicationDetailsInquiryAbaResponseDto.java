package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * かんたん受付申込詳細照会ABAレスボスDTO
 */
@Data
public class EasyReceptionApplicationDetailsInquiryAbaResponseDto {

    /**
     * 共通レスポンス・ボディ
     */
    private CommonResponseHeader commonResponseHeader;

    /**
     * お知らせID
     */
    private String anncmntId;

    /**
     * 申込ID
     */
    private String applyId;

    /**
     * タイトル
     */
    private String anncmntTitle;

    /**
     * 作成日時
     */
    private String createDateAndTime;

    /**
     * 非会員フラグ
     */
    private String nonMemberFlg;

    /**
     * CIF番号レスト
     */
    private List<CifNumberDto> cifNoList;

    /**
     * 顧客ID
     */
    private String customerId;

    /**
     * 利用者ID
     */
    private String userId;

    /**
     * カナ氏名
     */
    private String custNameKana;

    /**
     * 漢字氏名
     */
    private String custNameKanji;

    /**
     * 郵便番号
     */
    private String custZipCode;

    /**
     * カナ住所
     */
    private String custAddressKana;

    /**
     * 住所
     */
    private String custAddress;

    /**
     * 電話番号
     */
    private String custPhone;

    /**
     * メールアドレス
     */
    private String custMail;

    /**
     * 受付フォーマット
     */
    private String receptionFormat;

    /**
     * 窓口支店番号
     */
    private String contactBranchNum;
    
    /**
     * 会場選択有無フラグ
     */
    private String  venueSelectFlg;
}

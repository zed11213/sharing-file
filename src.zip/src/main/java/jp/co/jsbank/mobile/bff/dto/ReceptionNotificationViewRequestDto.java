package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 受付通知閲覧リクエストDTO
 */
@Data
public class ReceptionNotificationViewRequestDto {

    /**
     * お知らせID
     */
    private String anncmntId;

    /**
     * 申込ID
     */
    private String applicationId;
}

package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import jp.co.jsbank.mobile.bff.dto.OrdinaryDepositAccountInformationDto;
import lombok.Data;
import lombok.EqualsAndHashCode;
/**
 * CIF照会ABAレスポンスDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class CifInquiryAbaResponseDto extends RequestBodyDto {

    /**
     * 共通レスポンス・ヘッダ
     */
    private CommonResponseHeader commonResponseHeader;

    /**
     * CIF番号
     */
    private String cifNumber;

    /**
     * 世帯主
     */
    private String houseHolder;

    /**
     * 性別
     */
    private String gender;

    /**
     * 性別（文言）
     */
    private String genderValue;

    /**
     * 生年月日
     */
    private String birthday;

    /**
     * 人格コード
     */
    private String personCode;

    /**
     * 人格コード（文言）
     */
    private String personValue;

    /**
     * 業種
     */
    private String category;

    /**
     * 業種（文言）
     */
    private String categoryValue;

    /**
     * 担当者コード
     */
    private String contactPersonCode;

    /**
     * 会員区分
     */
    private String memberCategory;

    /**
     * 会員番号
     */
    private String memberNumber;

    /**
     * 本人死亡日
     */
    private String deathDate;

    /**
     * 注意コード1
     */
    private String cautionIndicationCode1;

    /**
     * 注意コード2
     */
    private String cautionIndicationCode2;

    /**
     * 注意コード3
     */
    private String cautionIndicationCode3;

    /**
     * 職業
     */
    private String occupation;

    /**
     * 職業（文言）
     */
    private String occupationValue;

    /**
     * 取引目的
     */
    private String transactPurpose;

    /**
     * 取引目的（文言）
     */
    private String transactPurposeValue;

    /**
     * 国
     */
    private String nationality;

    /**
     * 国（文言）
     */
    private String nationalityValue;

    /**
     * 税法上の居住国
     */
    private String countryForTaxPurposes;

    /**
     * 税法上の居住国（文言）
     */
    private String countryForTaxPurposesValue;

    /**
     * FATCA報告区分
     */
    private String fatcaReportCategory;

    /**
     * FATCA報告区分（文言）
     */
    private String fatcaReportCategoryValue;

    /**
     * 郵便番号
     */
    private String zipCode;

    /**
     * 地区コード
     */
    private String addressCode;

    /**
     * 住所
     */
    private String address;

    /**
     * 番地
     */
    private String addrDetail3;

    /**
     * 住所方書（カナ）
     */
    private String addressDetailKana;

    /**
     * 住所方書
     */
    private String addressDetail;

    /**
     * 電話番号１
     */
    private String phoneNumber1;

    /**
     * 電話番号２
     */
    private String phoneNumber2;

    /**
     * カナ氏名
     */
    private String customerName;

    /**
     * 漢字氏名
     */
    private String customerKanjiName;

    /**
     * 通帳レス設定状態
     */
    private String passbookLessSettingStatus;

    /**
     * 本人死亡
     */
    private String death;

    /**
     * 為替連動禁止
     */
    private String depositInterlockingProhibited;

    /**
     * マネーロンダリング該当
     */
    private String moneyLaundering;

    /**
     * 店番
     */
    private String branchNumber;

    /**
     * 共通本人確認区分
     */
    private String commonSelfConfirm;

    /**
     * 共通本人確認区分（文言）
     */
    private String commonSelfConfirmValue;

    /**
     * 居住者区分
     */
    private String residentClassification;

    /**
     * CIR開設日
     */
    private String openingDate;

    /**
     * 代表者名（漢字）
     */
    private String representativeName;

    /**
     * 印鑑レス
     */
    private String noSeal;

    /**
     * アプリ口座有無
     */
    private String appAccount;

    /**
     * バンキングアプリ登録
     */
    private String bankingAppRegister;

    /**
     * バンキングアプリ停止
     */
    private String bankingAppStopping;

    /**
     * 共通印設定
     */
    private String commonSeal;

    /**
     * 普通預金口座情報
     */
    private List<OrdinaryDepositAccountInformationDto> accountInfo;

    /**
     * 口座開設可否
     */
    private String accountOpeningJudgement;

    /**
     * 口座開設可否（文言）
     */
    private String accountOpeningJudgementValue;
}

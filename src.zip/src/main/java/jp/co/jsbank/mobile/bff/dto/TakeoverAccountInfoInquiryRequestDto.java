package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 引継ぎ口座情報照会BFFリクエストDTO
 */
@Data
public class TakeoverAccountInfoInquiryRequestDto {

	/**
     * キャッシュカード暗証番号
     */
    private String cashCardPassword;
}

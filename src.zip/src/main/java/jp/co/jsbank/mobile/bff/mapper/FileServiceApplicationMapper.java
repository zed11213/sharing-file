package jp.co.jsbank.mobile.bff.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import jp.co.jsbank.mobile.bff.entity.FileServiceApplicationEntity;

@Mapper
public interface FileServiceApplicationMapper {

    /**
     * 申し込むデータ保存
     *
     * @param fileServiceApplicationEntity 申し込むデータエンティティ
     */
    void insertFileServiceApplication(FileServiceApplicationEntity fileServiceApplicationEntity);

    /**
     * IDを検索する
     *
     * @param ID id
     * @return トークン
     */
    FileServiceApplicationEntity selectByApplyId(String applyId);

    /**
     * CIF番号と支店コードで検索する
     *
     * @param cifNo CIF番号
     * @param branchCode 支店コード
     * @return FileServiceApplicationEntity
     */
    FileServiceApplicationEntity selectByCifNoAndBranchCode(String cifNo, String branchCode);

    /**
     * 顧客idで検索する
     *
     * @param customerId 顧客id
     * @return FileServiceApplicationEntity
     */
    FileServiceApplicationEntity selectByCustomerId(String customerId);

    /**
     * APPLY_IDでメールアドレスを更新する
     *
     * @param applyId 申込ID
     * @param mailAddress メールアドレス
     */
    void updateMailAddressByApplyId(@Param("applyId") String applyId, @Param("mailAddress") String mailAddress);
}

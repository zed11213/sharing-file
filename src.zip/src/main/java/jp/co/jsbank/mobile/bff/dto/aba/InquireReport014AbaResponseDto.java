package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import jp.co.jsbank.mobile.bff.dto.ContractPaymentDto;
import jp.co.jsbank.mobile.bff.dto.RepaymentScheduleDto;
import lombok.Data;

/**
 * 帳票CSV内容照会_借入返済通知ABAレスポンスDTO
 */
@Data
public class InquireReport014AbaResponseDto {
	
    /**
     * 共通レスポンスヘッダ
     */
    private CommonResponseHeader commonResponseHeader;

    /**
     * 帳票バージョン
     */
    private String formVersion;

    /**
     * 本状作成日
     */
    private String bookCreateDate;

    /**
     * 現在お借入残高
     */
    private String borrowingBalance;

    /**
     * 内毎月分残高
     */
    private String monthlyBalance;

    /**
     * 内ボーナス分残高
     */
    private String balanceForBonus;

    /**
     * 新しい毎回返済額
     */
    private String repaymentAmountForEachPayment;

    /**
     * ご返済日
     */
    private String repaymentDate;

    /**
     * 新しいボーナス返済額
     */
    private String newBonusRepaymentAmount;

    /**
     * ボーナス返済月１
     */
    private String bonusRepaymentMonth1;

    /**
     * ボーナス返済月２
     */
    private String bonusRepaymentMonth2;
    
    /**
     * 期日
     */
    private String expiryDate;

    /**
     * 作成日
     */
    private String createdDate;

    /**
     * お借入日
     */
    private String borrowingDate;

    /**
     * 利率変更幅(B)-(A)
     */
    private String rateChangeRange;

    /**
     * (B)新しい利率
     */
    private String newRate;

    /**
     * (B)新しい利率_年月日現在
     */
    private String newRateDate;

    /**
     * (A)今迄の利率
     */
    private String nowRate;

    /**
     * (A)今迄の利率_年月日現在
     */
    private String nowRateDate;

    /**
     * 約定払込リスト
     */
    private List<ContractPaymentDto> contractPaymentList;

    /**
     * ご返済予定表リスト
     */
    private List<RepaymentScheduleDto> repaymentScheduleList;

    /**
     * 取扱店名
     */
    private String branchKanjiName;

    /**
     * 取扱電話番号
     */
    private String branchPhoneNumber;
}

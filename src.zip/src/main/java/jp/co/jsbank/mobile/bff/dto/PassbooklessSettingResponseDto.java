package jp.co.jsbank.mobile.bff.dto;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.aba.CifAttributeQueryInfomationDto;
import lombok.Data;

/**
 * 通帳レス情報取得レスポンスDTO
 */
@Data
public class PassbooklessSettingResponseDto {

    /**
     * 利用口座情報DTO
     */
    private List<UserAttributeDto> accountInfo;

    /**
     * CIF情報取得
     */
    private List<CifAttributeQueryInfomationDto> cifInfomationDtoList;
}

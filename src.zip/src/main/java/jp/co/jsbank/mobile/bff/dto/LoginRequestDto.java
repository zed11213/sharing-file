package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * ログイン認証リクエストDTO
 */
@Data
public class LoginRequestDto {

    /**
     * 初回ログインフラグ
     */
    private String loginFlg;
}

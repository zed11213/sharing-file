package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 帳票CSV内容照会_借入終了案内レスポンスDTO
 */
@Data
public class InquireReport008ResponseDto {

	/**
	 * 帳票バージョン
	 */
	private String formVersion;

	/**
	 * 共通作成日付
	 */
	private String comCreateDate;

	/**
	 * 取扱店名
	 */
	private String branchKanjiName;

	/**
	 * 取扱電話番号
	 */
	private String branchPhoneNumber;

	/**
	 * 作成通番
	 */
	private String createSeqNo;

	/**
	 * 発行区分
	 */
	private String issueType;

	/**
	 * 完済日
	 */
	private String liquidationDate;
}

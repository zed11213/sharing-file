package jp.co.jsbank.mobile.bff.logic;

import org.springframework.stereotype.Service;

import jp.co.jsbank.mobile.bff.dto.BranchStoreAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.EasyReceptionApplicationDetailsInquiryAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.EasyReceptionGuideDetailedInquiryAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.BranchOfficeListInquiryAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.EasyReceptionAnswerDetailInquiryAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.EasyReceptionAnswerDetailInquiryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.EasyReceptionApplicationDetailsInquiryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.EasyReceptionApplicationRegistrationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.EasyReceptionApplicationRegistrationResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.GuidanceInquiryInfTypeIdAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.ReceptionInformationListInquiry;
import jp.co.jsbank.mobile.bff.dto.aba.ReceptionInformationListInquiryResponseDto;

/**
 * かんたん受付ロジック
 */
@Service
public interface EasyReceptionLogic {

    /**
     * かんたん受付案内詳細照会
     *
     * @param abaRequestDto かんたん受付案内詳細照会ABAリクエストDTO
     * @return かんたん受付案内詳細照会ABAリクエストDTO
     */
    GuidanceInquiryInfTypeIdAbaResponseDto
            easyReceptionGuideDetailedInquiry(EasyReceptionGuideDetailedInquiryAbaRequestDto abaRequestDto);

    /**
     * かんたん受付申込登録
     *
     * @param abaRequestDto かんたん受付申込登録ABAリクエストDTO
     * @return かんたん受付申込登録レスボスDTO
     */
    EasyReceptionApplicationRegistrationResponseDto
            easyReceptionApplicationRegistration(EasyReceptionApplicationRegistrationAbaRequestDto abaRequestDto);

    /**
     * かんたん受付申込詳細照会
     *
     * @param abaRequestDto かんたん受付申込詳細照会ABAリクエストDTO
     * @return かんたん受付申込詳細照会ABAレスボスDTO
     */
    EasyReceptionApplicationDetailsInquiryAbaResponseDto
            easyReceptionApplicationDetailsInquiry(EasyReceptionApplicationDetailsInquiryAbaRequestDto abaRequestDto);

    /**
     * 部店一覧照会
     *
     * @param abaRequestDto 支店一覧照会リクエストDTO
     * 
     * @return 支店一覧ABAレスポンスDTO
     */
    BranchStoreAbaResponseDto branchOfficeListInquiry(BranchOfficeListInquiryAbaRequestDto abaRequestDto);

    /**
     * かんたん受付回答詳細照会
     *
     * @param abaRequestDto かんたん受付回答詳細照会ABAリクエストDTO
     * @return かんたん受付回答詳細照会ABAレスボスDTO
     */
    EasyReceptionAnswerDetailInquiryAbaResponseDto
            easyReceptionAnswerDetailInquiry(EasyReceptionAnswerDetailInquiryAbaRequestDto abaRequestDto);

    /**
     * かんたん受付案内一覧照会
     *
     * @param abaRequestDto かんたん受付案内一覧照会ABAリクエストDTO
     * @return かんたん受付案内一覧照会リクエストDTO
     */
    ReceptionInformationListInquiryResponseDto
            receptionInformationListInquiry(ReceptionInformationListInquiry abaRequestDto);
}

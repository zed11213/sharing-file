package jp.co.jsbank.mobile.bff.dto;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.aba.LatestReceipDetailsDto;
import jp.co.jsbank.mobile.bff.dto.aba.LotteryResultsDetailsDto;
import lombok.Data;

/**
 * 抽選結果明細レスポンスDTO
 */
@Data
public class LotteryResultResponseDto {

    /**
     * 共通レスポンス・ヘッダ
     */
    private CommonResponseHeader commonResponseHeader;

    /**
     * 抽選結果明細DTOリスト
     */
    private List<LotteryResultsDetailsDto> lotteryResults;
    
    /**
     * 最新受領情報明細DTOリスト
     */
    private List<LatestReceipDetailsDto> latestReceiptInfo; 
}

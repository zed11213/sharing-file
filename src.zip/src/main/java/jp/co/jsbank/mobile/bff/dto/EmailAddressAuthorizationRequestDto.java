package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * メールアドレス認証リクエストDTO
 */
@Data
public class EmailAddressAuthorizationRequestDto {

    /**
     * メールアドレス
     */
    private String emailAddress;

    /**
     * メールOTP
     */
    private String mailOtp;

    /**
     * 依頼番号
     */
    private String requestNo;

    /**
     * 受付番号
     */
    private String receiptNumber;

    /**
     * 認証キー
     */
    private String authCode;

    /**
     * 人格区分
     */
    private String personType;

    /**
     * 更新パターン
     */
    private String updateType;

}

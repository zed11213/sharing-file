package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * メールアドレス認証AbaリクエストDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class EmailAddressAuthorizationAbaRequestDto extends RequestBodyDto {

	/**
	 * 受付番号
	 */
	private String receiptNumber;

	/**
	 * メールアドレス
	 */
	private String emailAddress;

	/**
	 * メールOTP
	 */
	private String mailOTP;

	/**
	 * 画面ID
	 */
	private String pageId;

	/**
	 * 更新パターン
	 */
	private String updateType;

}

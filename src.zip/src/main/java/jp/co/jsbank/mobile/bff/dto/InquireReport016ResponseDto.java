package jp.co.jsbank.mobile.bff.dto;

import java.util.List;

import lombok.Data;

/**
 * 帳票CSV内容照会_当座勘定照合表兼当座勘定決算通知レスポンスDTO
 */
@Data
public class InquireReport016ResponseDto {

    /**
     * 帳票バージョン
     */
    private String formVersion;

    /**
     * 作成日
     */
    private String createDate;

    /**
     * 当座勘定明細表リスト
     */
    private List<CurrentAccountDto> currentAccountList;

    /**
     * 取扱店名
     */
    private String branchKanjiName;

    /**
     * 取扱電話番号
     */
    private String branchPhoneNumber;
}

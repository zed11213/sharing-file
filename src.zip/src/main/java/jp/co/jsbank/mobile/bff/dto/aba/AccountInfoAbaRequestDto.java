package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 残高情報取得リクエストDTO
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class AccountInfoAbaRequestDto extends RequestBodyDto {

    /**
     * CIF番号
     */
    private String cifNo;

    /**
     * 顧客ID
     */
    private String customerId;

    /**
     * 店番
     */
    private String branchCode;

}

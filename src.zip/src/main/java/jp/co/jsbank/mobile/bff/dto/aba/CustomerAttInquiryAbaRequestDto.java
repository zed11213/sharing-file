package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * 顧客属性照会リクエストDTO
 */
@Data
public class CustomerAttInquiryAbaRequestDto {

    /**
     * CIF番号設定
     */
    private String cifNuumber;

}

package jp.co.jsbank.mobile.bff.service;

import org.springframework.stereotype.Service;

import jp.co.jsbank.mobile.bff.dto.ElectronicIssueRequestDto;
import jp.co.jsbank.mobile.bff.dto.InformationViewResponseDto;

/**
 * 電子交付サービス
 */
@Service
public interface ElectronicIssueService {

	/**
	 * お知らせ閲覧
	 *
	 * @param requestDto 電子交付ABAリクエストDTO
	 * @return お知らせ閲覧レスポンスDTO
	 */
	InformationViewResponseDto informationView(ElectronicIssueRequestDto requestDto);

	/**
	 * 帳票PDFダウンロード
	 *
	 * @param requestDto 電子交付ABAリクエストDTO
	 * @return 帳票PDFファイル
	 */
	Object reportPdfDownload(ElectronicIssueRequestDto requestDto);

}

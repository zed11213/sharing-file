package jp.co.jsbank.mobile.bff.dto;

import java.util.List;

import lombok.Data;

/**
 * 帳票CSV内容照会_定期預金（懸賞金付）期日案内レスポンスDTO
 */
@Data
public class InquireReport002ResponseDto {

    /**
     * 帳票バージョン
     */
    private String formVersion;

    /**
     * 本状作成日
     */
    private String bookCreateDate;

    /**
     * スーパードリーム期日明細表リスト
     */
    private List<SuperDreamDateDto> superDreamDateList;

    /**
     * マル優申告限度額
     */
    private String declarationLimitAmount;

    /**
     * ご利用額(預金)
     */
    private String usageAmount;

    /**
     * 取扱店名
     */
    private String branchKanjiName;

    /**
     * 取扱電話番号
     */
    private String branchPhoneNumber;

    /**
     * 共通店番
     */
    private String comBranchNo;

    /**
     * 共通口座番
     */
    private String comAccountNo;
}

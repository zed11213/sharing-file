package jp.co.jsbank.mobile.bff.service;

import org.springframework.stereotype.Service;

import jp.co.jsbank.mobile.bff.dto.liquidekyc.GetTokenRequestDTO;
import jp.co.jsbank.mobile.bff.dto.liquidekyc.GetTokenResponseDTO;
import jp.co.jsbank.mobile.bff.dto.liquidekyc.EkycFinishVerificationRequestDto;
import jp.co.jsbank.mobile.bff.dto.liquidekyc.EkycGetPhotosResponseDto;
import jp.co.jsbank.mobile.bff.dto.liquidekyc.EkycRequestInformationRequestDto;
import jp.co.jsbank.mobile.bff.dto.liquidekyc.EkycRequestInformationResponseDto;
import jp.co.jsbank.mobile.bff.dto.liquidekyc.EkycVerificationResultResponseDto;
import jp.co.jsbank.mobile.bff.dto.liquidekyc.EkycIdDocumentInformationResponseDto;
import jp.co.jsbank.mobile.bff.dto.liquidekyc.EkycKycResultRequestDto;

/**
 * Ekycサービス
 */
@Service
public interface LiquidEkycService {

    /**
     * トークンIDを検索する
     *
     * @param token トークン
     * @return トークンID
     */
    GetTokenResponseDTO getToken(GetTokenRequestDTO requestDTO);

    String setFinishVerificationWithJpki(EkycFinishVerificationRequestDto finishVerification);

    String setFinishVerificationWithHe(EkycFinishVerificationRequestDto finishVerification);
}

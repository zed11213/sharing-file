package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 営業地区部店一覧照会BFFリクエストDTO
 */
@Data
public class SalesAreaDepartmentStoreInquiryRequestDto {

    /**
     * 郵便番号
     */
    private String zipCode;
}

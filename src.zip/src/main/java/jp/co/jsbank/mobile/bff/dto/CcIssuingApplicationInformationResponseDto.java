package jp.co.jsbank.mobile.bff.dto;

import java.util.List;

import lombok.Data;

/**
 * CC発行申込内容照会レスポンスDTO
 */
@Data
public class CcIssuingApplicationInformationResponseDto {

    /**
     * 画面ID
     */
    private String screenId;

    /**
     * 受付番号
     */
    private String receiptNumber;

    /**
     * CIF番号
     */
    private String cifNumber;

    /**
     * 申込ステータス
     */
    private String applyStatus;

    /**
     * キャッシュカード種類
     */
    private String cashcardType;

    /**
     * 取引種別
     */
    private String transactionType;

    /**
     * 人格コード
     */
    private String personCode;

    /**
     * 申込日
     */
    private String applicationDate;

    /**
     * 申請開始日時
     */
    private String applyStartDateTime;

    /**
     * 申請有効期限日時
     */
    private String applyValidDateTime;

    /**
     * 利用停止フラグ
     */
    private String useSuspendFlag;

    /**
     * バージョン
     */
    private String version;

    /**
     * カナ氏名（姓）
     */
    private String customerLastName;

    /**
     * カナ氏名（名）
     */
    private String customerFirstName;

    /**
     * 漢字氏名（姓）
     */
    private String customerKanjiLastName;

    /**
     * 漢字氏名（名））
     */
    private String customerKanjiFirstName;

    /**
     * 生年月日
     */
    private String birthday;

    /**
     * 郵便番号
     */
    private String zipCode;

    /**
     * 取引目的
     */
    private String transactionPurpose;

    /**
     * 取引目的（その他）
     */
    private String transactPurposeOther;

    /**
     * 職業
     */
    private String occupation;

    /**
     * 職業（その他）
     */
    private String occupationOther;

    /**
     * 預金種目
     */
    private String accountType;
    /**
     * 店番
     */
    private String branchNumber;

    /**
     * メールアドレス
     */
    private String emailAddress;

    /**
     * 口座番号
     */
    private String accountNumber;

    /**
     * eKYC本人確認結果
     */
    private String ekycResult;

    /**
     * 本人確認書類リスト
     */
    private List<IdentityVerificationDocumentsDto> ceoIdentityDocuments;
}

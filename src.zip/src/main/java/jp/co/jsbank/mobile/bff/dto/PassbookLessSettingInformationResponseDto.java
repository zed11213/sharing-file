package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 通帳レス設定情報レスボスDTO
 */
@Data
public class PassbookLessSettingInformationResponseDto {

    /**
     * CIF番号
     */
    private String cifNumber;

    /**
     * 通帳レス設定状態
     */
    private String passbookLessSettingStatus;

    /**
     * 初回登録フラグ
     */
    private String registerFlg;

    /**
     * 店番
     */
    private String branchCode;
}

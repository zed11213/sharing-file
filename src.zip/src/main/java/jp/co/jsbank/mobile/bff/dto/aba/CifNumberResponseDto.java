package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * CIF番号Dto
 */
@Data
public class CifNumberResponseDto {
	
    /**
     * CIF番号
     */
    private String cifNo;

}

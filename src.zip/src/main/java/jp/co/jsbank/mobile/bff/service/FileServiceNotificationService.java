package jp.co.jsbank.mobile.bff.service;

import jp.co.jsbank.mobile.bff.entity.FileServiceNotificationEntity;

public interface FileServiceNotificationService {
    /**
     * シリアルナンバーと利用確認IDで検索する
     *
     * @param serialNumber シリアルナンバー
     * @param queryId 利用確認ID
     * @return FileServiceNotificationEntity
     */
    FileServiceNotificationEntity selectBySerialNumberAndQueryId(String serialNumber, String queryId);
}

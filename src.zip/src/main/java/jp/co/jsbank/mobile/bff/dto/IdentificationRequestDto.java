package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 本人確認リクエストDTO
 */
@Data
public class IdentificationRequestDto {

    /**
     * 店番
     */
    private String branchNumber;

    /**
     * 口座番号
     */
    private String accountNumber;

    /**
     * CIF番号
     */
    private String cifNumber;

    /**
     * カナ氏名（名）
     */
    private String customerFirstName;

    /**
     * カナ氏名（姓）
     */
    private String customerLastName;

    /**
     * 漢字氏名（姓）
     */
    private String customerKanjiLastName;

    /**
     * 漢字氏名（名）
     */
    private String customerKanjiFirstName;

    /**
     * 生年月日
     */
    private String birthday;

    /**
     * 郵便番号
     */
    private String zipCode;

    /**
     * 職業
     */
    private String occupation;

    /**
     * 職業（その他）
     */
    private String occupationOther;

    /**
     * 取引目的
     */
    private String transactPurpose;

    /**
     * 取引目的（その他）
     */
    private String transactPurposeOther;

    /**
     * 預金種目
     */
    private String accountType;

    /**
     * CC暗証番号
     */
    private String ccPinCode;

    /**
     * 取引種別
     */
    private String transactionType;

    /**
     * 受付番号
     */
    private String receiptNumber;

    /**
     * 画面ID
     */
    private String pageId;

    /**
     * 更新パターン
     */
    private String updateType;

}

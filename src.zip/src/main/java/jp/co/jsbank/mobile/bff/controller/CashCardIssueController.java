package jp.co.jsbank.mobile.bff.controller;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import jp.co.jsbank.mobile.bff.common.JsonResult;
import jp.co.jsbank.mobile.bff.dto.CardDesignSelectionRequestDto;
import jp.co.jsbank.mobile.bff.dto.CcIssuingRequestDto;
import jp.co.jsbank.mobile.bff.dto.CcPasswordIbPasswordSettingRequestDto;
import jp.co.jsbank.mobile.bff.dto.EmailAddressAuthorizationRequestDto;
import jp.co.jsbank.mobile.bff.dto.IdentificationRequestDto;
import jp.co.jsbank.mobile.bff.dto.IdentificationResponseDto;
import jp.co.jsbank.mobile.bff.dto.IvrAuthenticationRequestDto;
import jp.co.jsbank.mobile.bff.dto.IvrAuthenticationResponseDto;
import jp.co.jsbank.mobile.bff.service.CashCardIssueService;

/**
 * キャッシュカード発行コントロール
 */
@RestController
public class CashCardIssueController {

    @Resource
    private CashCardIssueService cashcardIssueService;

    /**
     * CC暗証番号
     *
     * @param requestDto CC暗証番号・IBパスワード設定BFFリクエストDTO
     * @return 処理結果
     */

    @PostMapping(path = "/cashcard-issue/AB0802")
    public String ccPasswordIbPasswordSetting(@RequestBody CcPasswordIbPasswordSettingRequestDto requestDto)
            throws Exception {

        String result = cashcardIssueService.ccPasswordIbPasswordSetting(requestDto);

        return JsonResult.success(result);
    }

    /**
     * カードデザイン選択
     *
     * @param requestDto カードデザイン選択リクエストDTO
     * @return 処理結果
     */

    @PostMapping(path = "/cashcard-issue/AB0803")
    public String cardDesignSelection(@RequestBody CardDesignSelectionRequestDto requestDto) {

        String response = cashcardIssueService.cardDesignSelection(requestDto);

        return JsonResult.success(response);
    }

    /**
     * CC発行依頼
     *
     * @param requestDto CC発行依頼リクエストDTO
     * @return 処理結果
     */

    @PostMapping(path = "/cashcard-issue/AB0804")
    public String getCcIssuing(@RequestBody CcIssuingRequestDto requestDto) {

        String response = cashcardIssueService.getCcIssuing(requestDto);

        return JsonResult.success(response);
    }

    /**
     * 本人確認
     *
     * @param requestDto 本人確認リクエストDTO
     * @return JsonResult
     */
    @PostMapping(path = "/cashcard-issue/AB0805")
    public String identityVerification(@RequestBody IdentificationRequestDto requestDto) {
        IdentificationResponseDto responseDto = cashcardIssueService.identityVerification(requestDto);
        return JsonResult.success(responseDto);
    }

    /**
     * メールアドレス認証
     *
     * @param requestDto メールアドレス認証リクエストDTO
     * @return JsonResult
     */
    @PostMapping(path = "/cashcard-issue/AB0807")
    public String emailAddressAuthorization(@RequestBody EmailAddressAuthorizationRequestDto requestDto) {
        String result = cashcardIssueService.emailAddressAuthorization(requestDto);
        return JsonResult.success(result);
    }

    /**
     * IVR認証
     *
     * @param requestDto IVR認証リクエストDTO
     * @return JsonResult
     */
    @PostMapping(path = "/cashcard-issue/AB0808")
    public String ivrAuthentication(@RequestBody IvrAuthenticationRequestDto requestDto) {
    	IvrAuthenticationResponseDto result = cashcardIssueService.ivrAuthentication(requestDto);
        return JsonResult.success(result);
    }
}

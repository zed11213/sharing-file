package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import jp.co.jsbank.mobile.bff.dto.BeneficialOwnerDto;
import jp.co.jsbank.mobile.bff.dto.IdentityVerificationDocumentsDto;
import jp.co.jsbank.mobile.bff.dto.RepresentativeOfficerDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 口座開設申込内容更新（法人）ABAリクエストDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class AccountOpenAppliContentUpdateCorporationAbaRequestDto extends RequestBodyDto  {

    /**
     * 受付番号
     */
    private String receiptNumber;

    /**
     * CIF番号
     */
    private String cifNumber;

    /**
     * 申込ステータス
     */
    private String applyStatus;

    /**
     * 会社形態
     */
    private String companyForm;

    /**
     * 会社形態（その他）
     */
    private String companyFormOther;

    /**
     * 会社形態位置
     */
    private String companyFormLocation;

    /**
     * 事業先名（カナ）
     */
    private String businessNameKana;

    /**
     * 事業先名（漢字）
     */
    private String businessNameKanji;

    /**
     * 設立年月日
     */
    private String establishDate;

    /**
     * 資本金
     */
    private String capital;

    /**
     * 従業員人数
     */
    private String numberOfEmployees;

    /**
     * 事業先電話番号種別
     */
    private String businessPhoneType;

    /**
     * 事業先電話番号（上）
     */
    private String businessPhoneNumFirst;

    /**
     * 事業先電話番号（中）
     */
    private String businessPhoneNumMid;

    /**
     * 事業先電話番号（下）
     */
    private String businessPhoneNumLast;

    /**
     * 所在地郵便番号
     */
    private String locationZipCode;

    /**
     * 所在地都道府県（カナ）
     */
    private String locationPrefectureKana;

    /**
     * 所在地都道府県
     */
    private String locationPrefecture;

    /**
     * 所在地市区町村（カナ）
     */
    private String locationCityKana;

    /**
     * 所在地市区町村
     */
    private String locationCity;

    /**
     * 所在地丁目（カナ）
     */
    private String locationStreetKana;

    /**
     * 所在地丁目
     */
    private String locationStreet;

    /**
     * 所在地番地（カナ）
     */
    private String locationAddressKana;

    /**
     * 所在地番地
     */
    private String locationAddress;

    /**
     * 所在地建物名・号室（カナ）
     */
    private String locationBuildingRoomKana;

    /**
     * 所在地建物名・号室
     */
    private String locationBuildingRoom;

    /**
     * 本店所在地相違区分
     */
    private String headOfficeClassification;

    /**
     * 本店所在地郵便番号
     */
    private String headOfficeLocZipCode;

    /**
     * 本店所在地都道府県（カナ）
     */
    private String headOfficeLocPrefectureKana;

    /**
     * 本店所在地都道府県
     */
    private String headOfficeLocPrefecture;

    /**
     * 本店所在地市区町村（カナ）
     */
    private String headOfficeLocCityKana;

    /**
     * 本店所在地市区町村
     */
    private String headOfficeLocCity;

    /**
     * 本店所在地丁目（カナ）
     */
    private String headOfficeLocStreetKana;

    /**
     * 本店所在地丁目
     */
    private String headOfficeLocStreet;

    /**
     * 本店所在地番地（カナ）
     */
    private String headOfficeLocAddressKana;

    /**
     * 本店所在地番地
     */
    private String headOfficeLocAddress;

    /**
     * 本店所在地建物名・号室（カナ）
     */
    private String headOfficeLocBuildingRoomKana;

    /**
     * 本店所在地建物名・号室
     */
    private String headOfficeLocBuildingRoom;

    /**
     * 代表者・役員リスト
     */
    private List<RepresentativeOfficerDto> ceoOfficer;

    /**
     * 実質的支配者リスト
     */
    private List<BeneficialOwnerDto> substantialRuler;

    /**
     * 取引目的
     */
    private String transactPurpose;

    /**
     * 取引目的（その他）
     */
    private String transactPurposeOther;

    /**
     * 取引目的（詳細）
     */
    private String transactPurposeDetail;

    /**
     * 事業内容
     */
    private String businessDescription;

    /**
     * 事業内容（その他）
     */
    private String businessDescriptionOther;

    /**
     * 取扱品目
     */
    private String handingItem;

    /**
     * 主要取引先（仕入）
     */
    private String mainlyTradePurchase;

    /**
     * 主要取引先（販売）
     */
    private String mainlyTradeSale;

    /**
     * 当金庫との取引希望
     */
    private String preferredTrade;

    /**
     * 当金庫との取引希望（その他）
     */
    private String otherBusinessWishes;

    /**
     * 取引のきっかけ
     */
    private String transactionTrigger;

    /**
     * 取引金融機関
     */
    private String financialInstitution;

    /**
     * 取引金融機関（預金状況）
     */
    private String financialInstitutionDepositStatus;

    /**
     * 取引金融機関（貸金状況）
     */
    private String financialInstitutionLoanStatus;

    /**
     * メールアドレス
     */
    private String emailAddress;

    /**
     * 開設店番
     */
    private String openBranchNumber;

    /**
     * eKYC本人確認結果
     */
    private String ekycResult;

    /**
     * 代表者本人確認書類リスト
     */
    private List<IdentityVerificationDocumentsDto> ceoIdentityDocuments;

    /**
     * 事業先本人確認書類リスト
     */
    private List<IdentityVerificationDocumentsDto> businessDocuments;

    /**
     * 画面ID
     */
    private String pageId;

    /**
     * 更新パターン
     */
    private String updateType;
}

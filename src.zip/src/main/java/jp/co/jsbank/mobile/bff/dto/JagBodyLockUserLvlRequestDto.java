package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * ユーザー無効化有効化設定リクエストDTO
 */
@Data
public class JagBodyLockUserLvlRequestDto {

    /**
     * 共通リクエスト・ヘッダ
     */
    private JagBodyCommonRequestHeader commonRequestHeader;

	/**
	 * JBAID
	 */
	private String jagJbaId;

	/**
	 * 実際のIDを指定しているかどうかを設定する項目. 0: トークン値（デフォルト）, 1: 実際の値.
	 * isReadIdが未指定の場合はデフォルト0(トークン値)が指定されたものとする.
	 */
	private int jagIsReal;

	/**
	 * 設定するロック状態. 0: アンロック状態, 1: ロック状態. doLockが未指定の場合はデフォルト0(UNLOCK）を指定されたものとする.
	 */
	private int jagDoLock;

}

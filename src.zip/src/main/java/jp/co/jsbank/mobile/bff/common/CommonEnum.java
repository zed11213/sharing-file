package jp.co.jsbank.mobile.bff.common;

import jp.co.jsbank.mobile.bff.common.exception.BaseErrorInfo;

/**
 * エラー定数クラス
 */
public enum CommonEnum implements BaseErrorInfo {

    // エラーコード
    SUCCESS(200, "正常応答"),
    BUSINESS_ERROR(401, "業務エラー応答"),
    SYSTEM_ERROR(500, "システムエラー応答"),
    
    // エラー情報定義
    BODY_NOT_MATCH(501, "要求されたデータフォーマットが一致しません!"),
    PARAM_NOT_MATCH(403, "要求値が正しくありません。"),
    NOT_FOUND(404, "ご指定いただいた期間には照会可能な明細はありません。");

    /** エラーコード */
    private Integer resultCode;

    /** エラーメッセージ */
    private String resultMsg;

    /**
     * コンストラクト
     * 
     * @param resultCode コード
     * @param resultMsg メッセージ
     */
    CommonEnum(Integer resultCode, String resultMsg) {
        this.resultCode = resultCode;
        this.resultMsg = resultMsg;
    }

    @Override
    public Integer getResultCode() {
        return resultCode;
    }

    @Override
    public String getResultMsg() {
        return resultMsg;
    }
}

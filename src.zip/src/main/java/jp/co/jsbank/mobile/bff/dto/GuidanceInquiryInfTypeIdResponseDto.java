package jp.co.jsbank.mobile.bff.dto;

import java.util.List;

import lombok.Data;

/**
 * かんたん受付案内一覧照会レスボスDTO
 */
@Data
public class GuidanceInquiryInfTypeIdResponseDto {

    /**
     * かんたん受付案内DTOリスト
     */
    private List<ReceptionGuideDto> receptionGuideList;

    /**
     * 該当件数
     */
    private String dataCount;
}

package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * 定期預金残高照会DTO
 */
@Data
public class FixedTermFixedBalanceDto {

    /**
     * 口座番号（ハイフン付き）
     */
    private String accountNoWithHyphen;

    /**
     * 口座番号
     */
    private String accountNumber;

    /**
     * 定積種類
     */
    private String fixedTypeCode;

    /**
     * 定積種類（文言）
     */
    private String fixedTypeCodeName;

    /**
     * 期間
     */
    private String periodCode;

    /**
     * 回数
     */
    private String numberOfTimes;

    /**
     * 振替日・集金日
     */
    private String transferDate;

    /**
     * 課税区分
     */
    private String taxClassCode;

    /**
     * 課税区分（文言）
     */
    private String taxClassName;

    /**
     * 最終掛込日
     */
    private String lastPaymentDate;

    /**
     * 契約日
     */
    private String contractDate;

    /**
     * 満期日
     */
    private String maturityDate;

    /**
     * 元帳残高
     */
    private String balanceOfLedger;

    /**
     * 振替口座番号（ハイフン付き）
     */
    private String transferAccountNoWithHyphen;

    /**
     * 振替口座番号
     */
    private String transferAccountNumber;

    /**
     * 契約額
     */
    private String agreementAmount;

    /**
     * 振替金額
     */
    private String transferAmount;

    /**
     * 掛金額
     */
    private String amount;

    /**
     * ボーナス掛金額
     */
    private String bonusAmount;

    /**
     * 利率
     */
    private String interestRate;

    /**
     * CIF番号（ハイフン付き）
     */
    private String cifNoWithHyphen;

    /**
     * CIF番号
     */
    private String cifNo;

}

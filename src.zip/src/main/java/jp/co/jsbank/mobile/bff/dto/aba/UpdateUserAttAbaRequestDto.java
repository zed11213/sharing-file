package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * 利用者属性更新AbaリクエストDTO
 */
@Data
public class UpdateUserAttAbaRequestDto {

    /**
     * 利用者ID
     */
    private String userId;

    /**
     * 確認ステータス
     */
    private String confirmationStatus;
}

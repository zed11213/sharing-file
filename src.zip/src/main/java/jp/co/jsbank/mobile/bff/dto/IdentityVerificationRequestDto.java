package jp.co.jsbank.mobile.bff.dto;


import lombok.Data;

/**
 * 本人照合リクエストDTO
 */
@Data
public class IdentityVerificationRequestDto {

    /**
     * 本人区分
     */
    private String personType;

    /**
     * 店番
     */
    private String branchCode;

    /**
     * 口座番号
     */
    private String accountNumber;

    /**
     * カナ氏名（姓）
     */
    private String customerLastName;

    /**
     * カナ氏名（名）
     */
    private String customerFirstName;

    /**
     * 漢字氏名（姓）
     */
    private String customerKanjiLastName;

    /**
     * 漢字氏名（名）
     */
    private String customerKanjiFirstName;

    /**
     * 生年月日
     */
    private String birthDay;

    /**
     * 郵便番号
     */
    private String zipCode;

    /**
     * CC暗証番号
     */
    private String ccPinCode;

    /**
     * 所属
     */
    private String divisionCode;

    /**
     * 認証キー
     */
    private String authCode;

    /**
     * デバイスID
     */
    private String deviceId;

    /**
     * 利用者区分
     */
    private String userType;

    /**
     * 預金種目
     */
    private String accountType;
}

package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 抽選結果情報リクエストDTO
 */
@Data
public class LotteryResultRequestDto {

    /**
     * 口座番号
     */
    private String accountNumber;

    /**
     * 店番
     */
    private String branchNumber;

    /**
     * 回次
     */
    private String lotteryTimes;
    
    /**
     * 取扱組
     */
    private String lotterySet;
}

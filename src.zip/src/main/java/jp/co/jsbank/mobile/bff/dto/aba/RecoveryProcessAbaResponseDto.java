package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.CcIssuingApplicationInformationResponseDto;
import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 復元処理レスポンスDTO
 */
@Data
public class RecoveryProcessAbaResponseDto {

    /**
     * 共通レスポンス・ボディ
     */
    private CommonResponseHeader commonResponseHeader;

    /**
     * 入出金明細情報(流動性預金)DTOリスト
     */
    private List<CcIssuingApplicationInformationResponseDto> ccIssuingApplicationInformationResponseDtoList;

}

package jp.co.jsbank.mobile.bff.dto;

import java.util.List;

import lombok.Data;

/**
 * 口座開設申込情報（個人）DTO
 */
@Data
public class AccountOpeningApplicationIndividualInfoDto {

    /**
     * 受付番号
     */
    private String receiptNumber;

    /**
     * 顧客ID
     */
    private String customerId;

    /**
     * CIF番号
     */
    private String cifNumber;

    /**
     * 人格区分
     */
    private String personType;

    /**
     * 申込ステータス
     */
    private String applyStatus;

    /**
     * 申請開始日時
     */
    private String applyStartDateTime;

    /**
     * 申請有効期限日時
     */
    private String applyValidDateTime;

    /**
     * 利用停止フラグ
     */
    private String useSuspendFlag;

    /**
     * 取引種別
     */
    private String transactionType;

    /**
     * 氏名カナ（姓）
     */
    private String nameKanaLast;

    /**
     * 氏名カナ（名）
     */
    private String nameKannFirst;

    /**
     * 氏名漢字（姓）
     */
    private String nameKanjiLast;

    /**
     * 氏名漢字（名）
     */
    private String nameKanjiFirst;

    /**
     * 生年月日
     */
    private String birthday;

    /**
     * 性別
     */
    private String gender;

    /**
     * 自宅郵便番号
     */
    private String homeZipCode;

    /**
     * 自宅都道府県（カナ）
     */
    private String homeStateKana;

    /**
     * 自宅都道府県
     */
    private String homeState;

    /**
     * 自宅市区町村（カナ）
     */
    private String homeCityKana;

    /**
     * 自宅市区町村
     */
    private String homeCity;

    /**
     * 自宅丁目（カナ）
     */
    private String homeStreetKana;

    /**
     * 自宅丁目
     */
    private String homeStreet;

    /**
     * 自宅番地（カナ）
     */
    private String homeAddressKana;

    /**
     * 自宅番地
     */
    private String homeAddress;

    /**
     * 自宅建物名・号室（カナ）
     */
    private String homeBuildingKana;

    /**
     * 自宅建物名・号室
     */
    private String homeBuilding;

    /**
     * 地区コード
     */
    private String districtCode;

    /**
     * 地区コード-枝番
     */
    private String districtCodeBranchNumber;

    /**
     * 地区コード-番地
     */
    private String districtCodeAddress;

    /**
     * 住所方書（漢字）
     */
    private String addressKanji;

    /**
     * 住所方書（カナ）
     */
    private String addressKana;

    /**
     * 電話番号種別１
     */
    private String phoneType1;

    /**
     * 自宅電話番号１（上）
     */
    private String homePhone1Top;

    /**
     * 自宅電話番号１（中）
     */
    private String homePhone1Middle;

    /**
     * 自宅電話番号１（下）
     */
    private String homePhone1Bottom;

    /**
     * 電話番号種別２
     */
    private String phoneType2;

    /**
     * 自宅電話番号２（上）
     */
    private String homePhone2Top;

    /**
     * 自宅電話番号２（中）
     */
    private String homePhone2Middle;

    /**
     * 自宅電話番号２（下）
     */
    private String homePhone2Bottom;

    /**
     * 取引目的
     */
    private String transactPurpose;

    /**
     * 取引目的（その他）
     */
    private String transactPurposeOther;

    /**
     * 職業
     */
    private String occupation;

    /**
     * 職業（その他）
     */

    private String occupationOther;
    /**
     * 店番
     */
    private String branchNumber;

    /**
     * 口座番号
     */
    private String accountNumber;

    /**
     * 勤務先名（カナ）
     */
    private String wpNameKana;

    /**
     * 勤務先名/学校名
     */
    private String wpName;

    /**
     * 勤務先郵便番号/学校郵便番号
     */
    private String wpZipCode;

    /**
     * 勤務先都道府県（カナ）
     */
    private String wpStateKana;

    /**
     * 勤務先都道府県/学校都道府県
     */
    private String wpState;

    /**
     * 勤務先市区町村（カナ）
     */
    private String wpCityKana;

    /**
     * 勤務先市区町村/学校市区町村
     */
    private String wpCity;

    /**
     * 勤務先丁目（カナ）
     */
    private String wpStreetKana;

    /**
     * 勤務先丁目/学校先丁目
     */
    private String wpStreet;

    /**
     * 勤務先番地（カナ）
     */
    private String wpAddressKana;

    /**
     * 勤務先番地/学校番地
     */
    private String wpAddress;

    /**
     * 勤務先建物名・号室（カナ）
     */
    private String wpBuildingKana;

    /**
     * 勤務先建物名・号室/学校建物名・号室
     */
    private String wpBuilding;

    /**
     * 勤務先電話番号種別/学校電話番号種別
     */
    private String wpPhoneType;

    /**
     * 勤務先電話番号（上）/学校電話番号（上）
     */
    private String wpPhoneTop;

    /**
     * 勤務先電話番号（中）/学校電話番号（中）
     */
    private String wpPhoneMiddle;

    /**
     * 勤務先電話番号（下）/学校電話番号（下）
     */
    private String wpPhoneBottom;

    /**
     * 取引のきっかけ
     */
    private String transactionTrigger;

    /**
     * 科目(定期預金/定期積金)
     */
    private String accountType;

    /**
     * 定期・定積口座番号
     */
    private String fixedDepositAccountNumber;

    /**
     * 開設部店コード
     */
    private String openBranchCode;

    /**
     * メールアドレス
     */
    private String emailAddress;

    /**
     * eKYC確認結果
     */
    private String ekycResult;

    /**
     * 本人確認書類リスト
     */
    private List<IdentityVerificationDocumentsDto> identityDocuments;

    /**
     * 本人確認書類URL
     */
    private String identityVerificationDocumentsUrl;
}

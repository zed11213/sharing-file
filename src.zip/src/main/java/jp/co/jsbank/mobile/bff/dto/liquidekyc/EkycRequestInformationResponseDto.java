package jp.co.jsbank.mobile.bff.dto.liquidekyc;
import lombok.Data;

/**
 * 本人確認完了レスポンスDTO
 */
@Data
public class EkycRequestInformationResponseDto {

    private String code;
}
/**
 * 存在しない連携IDエラー（CE00001）
 * 本人確認作業が未完了（CE00004）
 * 本人確認結果が登録済（CE00006）
 * 本人確認申請が未完了（CE00008）
 * 本人確認申請が申請期限切れ（URL有効期限切れ）（CE00011）
 * 申請情報を登録できない連携ID（CE00018）
 * システムエラー
 */


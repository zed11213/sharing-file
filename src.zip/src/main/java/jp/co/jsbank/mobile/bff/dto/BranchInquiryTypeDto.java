package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/** 照会店舗タイプDTO */
@Data
public class BranchInquiryTypeDto {

    /**
     * 照会店舗タイプ
     */
    private String branchInquiryType;
}

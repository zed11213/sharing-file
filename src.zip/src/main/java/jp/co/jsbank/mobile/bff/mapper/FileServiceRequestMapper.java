package jp.co.jsbank.mobile.bff.mapper;

import org.apache.ibatis.annotations.Mapper;


@Mapper
public interface FileServiceRequestMapper {

    /**
     * applyIdでstatusを更新する
     *
     * @param applyId 申込Id
     * @param status 承認依頼状態
     * @return 件数
     */
    int updateStatusByApplyId(String applyId, String status);
}

package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * TCC確定またはキャンセル
 */
@Data
public class JagBodyTrxConfirmOrCancelRequestDto {

    /**
     * jagDoキャンセル
     */
    private int jagDoCancel;

    /**
     * トランザクションID
     */
    private String jagTrxId;

}

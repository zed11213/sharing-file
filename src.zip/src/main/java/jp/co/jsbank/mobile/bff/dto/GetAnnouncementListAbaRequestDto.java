package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * お知らせ一覧取得リクエストDTO
 */
@Data
public class GetAnnouncementListAbaRequestDto {
    /**
     * お知らせ種別ID
     */
    private String informationTypeId;

    /**
     * 重要フラグ
     */
    private String importantFlag;

    /**
     * お気に入りフラグ
     */
    private String favoriteFlag;
    
    /**
     * 既読フラグ
     */
    private String readFlag;
    
    /**
     * 期間FROM
     */
    private String periodFrom;
    
    /**
     * 期間TO
     */
    private String periodTo;
    
    /**
     * ソート順
     */
    private String sortOrder;
    
}

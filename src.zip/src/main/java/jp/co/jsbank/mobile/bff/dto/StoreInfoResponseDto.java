package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 全部店情報レスボスDTO
 */
@Data
public class StoreInfoResponseDto {

    /**
     * 店名
     */
    private String departmentStoreName;

    /**
     * 部店コード
     */
    private String departmentStoreCode;
}

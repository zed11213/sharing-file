package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 帳票CSV内容照会_自動送金取扱終了案内ABAレスポンスDTO
 */
@Data
public class InquireReport011AbaResponseDto {

	/**
	 * 共通レスポンスヘッダ
	 */
	private CommonResponseHeader commonResponseHeader;

	/**
	 * 帳票バージョン
	 */
	private String formVersion;

	/**
	 * 本状作成日
	 */
	private String bookCreateDate;

	/**
	 * 振込方式区分
	 */
	private String remittanceMethodFlag;

	/**
	 * 契約日
	 */
	private String contractDate;

	/**
	 * 開始年月
	 */
	private String startYearMonth;

	/**
	 * 終了年月
	 */
	private String endYearMonth;
	/**
	 * 預金種目
	 */
	private String depositTypeName;

	/**
	 * 振込指定口座
	 */
	private String accountNumber;

	/**
	 * 振込先銀行名
	 */
	private String bankName;

	/**
	 * 振込先支店名
	 */
	private String branchName;

	/**
	 * 登録番号
	 */
	private String registerNumber;

	/**
	 * 受取人名
	 */
	private String beneficiaryName;

	/**
	 * 振込内容
	 */
	private String remittanceMessage;

	/**
	 * 期限
	 */
	private String deadLine;

	/**
	 * 新開始日
	 */
	private String newStartDate;

	/**
	 * 振込日(毎月)
	 */
	private String remittanceDate;

	/**
	 * 振込金額(毎月)
	 */
	private String remittanceAmount;

	/**
	 * 振込月１
	 */
	private String remittanceMonth1;

	/**
	 * 振込金額(特定月)１
	 */
	private String remittanceAmountSpeMonth1;

	/**
	 * 振込月２
	 */
	private String remittanceMonth2;

	/**
	 * 振込金額(特定月)２
	 */
	private String remittanceAmountSpeMonth2;

	/**
	 * 引落指定口座
	 */
	private String withdrawalAccountNumber;

	/**
	 * 固定休日送金１１
	 */
	private String definiteHolidayRemittance11;

	/**
	 * 固定休日送金１２
	 */
	private String definiteHolidayRemittance12;

	/**
	 * 出金科目
	 */
	private String paymentSubjectNameValue;

	/**
	 * 出金口座番号
	 */
	private String paymentAccountNumber;

	/**
	 * 不定休日送金
	 */
	private String indefiniteHolidayRemittance;

	/**
	 * 一月振込日
	 */
	private String remittanceDate1;

	/**
	 * 一月お振込金額
	 */
	private String remittanceAmount1;

	/**
	 * 二月振込日
	 */
	private String remittanceDate2;

	/**
	 * 二月お振込金額
	 */
	private String remittanceAmount2;

	/**
	 * 三月振込日
	 */
	private String remittanceDate3;

	/**
	 * 三月お振込金額
	 */
	private String remittanceAmount3;

	/**
	 * 四月振込日
	 */
	private String remittanceDate4;

	/**
	 * 四月お振込金額
	 */
	private String remittanceAmount4;

	/**
	 * 五月振込日
	 */
	private String remittanceDate5;

	/**
	 * 五月お振込金額
	 */
	private String remittanceAmount5;

	/**
	 * 六月振込日
	 */
	private String remittanceDate6;

	/**
	 * 六月お振込金額
	 */
	private String remittanceAmount6;

	/**
	 * 七月振込日
	 */
	private String remittanceDate7;

	/**
	 * 七月お振込金額
	 */
	private String remittanceAmount7;

	/**
	 * 八月振込日
	 */
	private String remittanceDate8;

	/**
	 * 八月お振込金額
	 */
	private String remittanceAmount8;

	/**
	 * 九月振込日
	 */
	private String remittanceDate9;

	/**
	 * 九月お振込金額
	 */
	private String remittanceAmount9;
	/**
	 * 十月振込日
	 */
	private String remittanceDate10;

	/**
	 * 十月お振込金額
	 */
	private String remittanceAmount10;

	/**
	 * 十一月振込日
	 */
	private String remittanceDate11;

	/**
	 * 十一月お振込金額
	 */
	private String remittanceAmount11;

	/**
	 * 十二月振込日
	 */
	private String remittanceDate12;

	/**
	 * 十二月お振込金額
	 */
	private String remittanceAmount12;

	/**
	 * 取扱店名
	 */
	private String branchKanjiName;

	/**
	 * 取扱電話番号
	 */
	private String branchPhoneNumber;

}

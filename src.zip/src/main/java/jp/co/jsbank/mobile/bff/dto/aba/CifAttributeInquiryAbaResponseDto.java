package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 *  CIF属性照会ABAレスボスDTO
 */
@Data
public class CifAttributeInquiryAbaResponseDto {
    /**
     * 利用者属性情報
     */
    private UserAttributeInfoDto userAttributeInfo;

    /**
     * 顧客属性情報
     */
    private Object customerAttributeInfo;

    /**
     * CIF属性情報
     */
    private Object cifAttributeInfo;
}

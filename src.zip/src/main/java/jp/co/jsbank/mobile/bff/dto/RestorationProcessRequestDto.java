package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 復元処理リクエストDTO
 */
@Data
public class RestorationProcessRequestDto {

    /**
     * 受付番号
     */
    private String receiptNumber;

}

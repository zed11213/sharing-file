package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 受付案内閲覧リクエストDTO
 */
@Data
public class ReceptionInformationViewRequestDto {

    /**
     * お知らせID
     */
    private String anncmntId;

    /**
     * 申込ID
     */
    private String applyId;

    /**
     * お知らせ種別コード
     */
    private String anncmntType;

    /**
     * 文書種別コード
     */
    private String documentType;

}

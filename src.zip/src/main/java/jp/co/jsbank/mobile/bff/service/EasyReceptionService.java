package jp.co.jsbank.mobile.bff.service;

import org.springframework.stereotype.Service;

import jp.co.jsbank.mobile.bff.dto.ApplicationAnswerViewResponseDto;
import jp.co.jsbank.mobile.bff.dto.EasyRegistrationScreenAcquisitionResponseDto;
import jp.co.jsbank.mobile.bff.dto.EasyRegistrationScreenInputInfoSendingRequestDto;
import jp.co.jsbank.mobile.bff.dto.GuidanceInquiryInfTypeIdResponseDto;
import jp.co.jsbank.mobile.bff.dto.ReceptionInformationViewRequestDto;
import jp.co.jsbank.mobile.bff.dto.ReceptionInformationViewResponseDto;
import jp.co.jsbank.mobile.bff.dto.ReceptionNotificationViewResponseDto;

/**
 * かんたん受付サービス
 */
@Service
public interface EasyReceptionService {

    /**
     * かんたん受付申込一覧照会
     *
     * @return かんたん受付案内一覧照会レスボスDTO
     */
    GuidanceInquiryInfTypeIdResponseDto guidanceInquiryInformationTypeId();

    /**
     * かんたん登録画面取得
     *
     * @return かんたん登録画面取得レスボスDTO
     */
    EasyRegistrationScreenAcquisitionResponseDto easyRegistrationScreenAcquisition();

    /**
     * 受付通知閲覧
     *
     * @param anncmntId お知らせID
     * @param applicationId 申込ID
     * @return 受付通知閲覧レスポンスDTO
     */
    ReceptionNotificationViewResponseDto receptionNotificationView(String anncmntId, String applicationId);

    /**
     * かんたん登録画面入力情報送信
     *
     * @param easyRegistrationScreenInputInfoSendingRequestDto かんたん登録画面入力情報送信リクエストDTO
     *
     * @return 処理結果
     */
    String easyRegistrationScreenInputInfoSending(
            EasyRegistrationScreenInputInfoSendingRequestDto easyRegistrationScreenInputInfoSendingRequestDto);

    /**
     * 受付案内閲覧
     *
     * @param requestDto 受付案内閲覧リクエストDTO
     * @return 受付案内閲覧レスボスDTO
     */
    ReceptionInformationViewResponseDto receptionInformationView(ReceptionInformationViewRequestDto requestDto);

    /**
     * 申込回答閲覧
     *
     * @param requestDto 受付案内閲覧リクエストDTO
     * @return 申込回答閲覧レスボスDTO
     */
    ApplicationAnswerViewResponseDto applicationAnswerView(ReceptionInformationViewRequestDto requestDto);

}

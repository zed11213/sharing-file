package jp.co.jsbank.mobile.bff.dto;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * かんたん受付案内詳細照会ABAリクエストDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class EasyReceptionGuideDetailedInquiryAbaRequestDto extends RequestBodyDto {

    /**
     * お知らせID
     */
    private String anncmntId;

    /**
     * 受付案内ステータス
     */
    private String receptionGuideStatus;

    /**
     * 公開中フラグ
     */
    private String releasedFlg;
}

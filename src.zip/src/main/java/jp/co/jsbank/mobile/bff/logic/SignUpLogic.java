package jp.co.jsbank.mobile.bff.logic;

import org.springframework.stereotype.Service;

import jp.co.jsbank.mobile.bff.dto.BranchStoreAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.JagBodyLinkAuthUserRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.AuthAccountInfoAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.AuthAccountInfoAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.AuthenticationKeyVerificationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.AuthenticationKeyVerificationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.BranchOfficeListInquiryAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CifInfoInquiryAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CifInquiryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CommonHeaderAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CustomerAttributeInquiryAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CustomerAttributeInquiryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CustomerInquiryInformationAbaDto;
import jp.co.jsbank.mobile.bff.dto.aba.CustomerRegistrationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CustomerRegistrationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CustomerRegistrationInfoInquiryAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CustomerRegistrationInformationAbaDto;
import jp.co.jsbank.mobile.bff.dto.aba.CustomerRegistrationInformationUpdateAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CustomerUpdateInformationAbaDto;
import jp.co.jsbank.mobile.bff.dto.aba.EmailAddressAuthorizationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.EmailAddressAuthorizationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.EmailAddressRegistrationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.EmailAddressRegistrationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.IvrAuthorizationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.IvrAuthorizationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.IvrAuthorizationSkipInfoInquiryAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.IvrAuthorizationSkipInfoInquiryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.IvrAuthorizationSkipInfoUpdateAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.IvrSendingAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.KanaNameInquiryAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.KanaNameInquiryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.LoginHistoryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.RegistloginHistoryAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.UserAttributeInquiryAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.UserAttributeInquiryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.UserAttributeRegistrationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.UserAttributeUpdateAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.UserDataAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.ba.*;

/**
 * 初回登録ロジック
 */
@Service
public interface SignUpLogic {

    /**
     * 部店照会リスト取得
     *
     * @param abaRequestDto
     *
     * @return 部店照会リスト
     */
    BranchStoreAbaResponseDto departmentStoreInquiry(BranchOfficeListInquiryAbaRequestDto abaRequestDto);

    /**
     * 口座情報認証情報取得
     *
     * @param abaRequestDto 口座情報認証リクエストDTO
     * @return 口座情報認証ABAレスボスDTO
     */
    AuthAccountInfoAbaResponseDto authAccountInfo(AuthAccountInfoAbaRequestDto abaRequestDto);

    /**
     * 顧客情報登録
     *
     * @param abaRequestDto 顧客情報登録リクエストDTO
     * @return 共通レスポンス・ヘッダ
     */
    CustomerRegistrationInformationUpdateAbaResponseDto
            customerInformationRegistration(CustomerRegistrationInformationAbaDto abaRequestDto);

    /**
     * 利用者属性更新
     *
     * @param abaRequestDto 利用者属性更新ABAリクエストDTO
     * @param deviceId 端末ID
     * @return 共通レスポンス・ヘッダ
     */
    CommonHeaderAbaResponseDto userAttributeUpdate(UserAttributeUpdateAbaRequestDto abaRequestDto, String deviceId);

    /**
     * メールアドレス登録
     *
     * @param abaRequestDto メールアドレス登録ABAリクエストDTO
     * @return 共通レスポンス・ヘッダ
     */
    EmailAddressRegistrationAbaResponseDto
            emailAddressRegistration(EmailAddressRegistrationAbaRequestDto abaRequestDto);

    /**
     * IVR送信
     *
     * @param abaRequestDto IVR送信ABAリクエストDTO
     * @return IVR送信ABAレスポンスDTO
     */
    CommonHeaderAbaResponseDto ivrSending(IvrSendingAbaRequestDto abaRequestDto);

    /**
     * IVR認証
     *
     * @param abaRequestDto IVR認証ABAリクエストDTO
     * @return IVR認証ABAレスポンスDTO
     */
    IvrAuthorizationAbaResponseDto ivrAuthorization(IvrAuthorizationAbaRequestDto abaRequestDto);

    /**
     * CIF情報照会
     *
     * @param abaRequestDto CIF情報照会ABAリクエストDTO
     * @return CIF情報照会ABAレスポンスDTO
     */
    CifInquiryAbaResponseDto cifInfoInquiry(CifInfoInquiryAbaRequestDto abaRequestDto);

    /**
     * メールアドレス認証
     *
     * @param abaRequestDto メールアドレス認証ABAリクエストDTO
     * @return 認証済メールアドレスABAレスポンスDTO
     */
    EmailAddressAuthorizationAbaResponseDto
            emailAddressAuthorization(EmailAddressAuthorizationAbaRequestDto abaRequestDto);

    /**
     * IVR認証スキップ情報照会
     *
     * @param abaRequestDto IVR認証スキップ情報照会ABAリクエストDTO
     * @return IVR認証スキップ情報照会ABAレスポンスDTO
     */
    IvrAuthorizationSkipInfoInquiryAbaResponseDto
            ivrAuthorizationSkipInfoInquiry(IvrAuthorizationSkipInfoInquiryAbaRequestDto abaRequestDto);

    /**
     * 顧客属性照会
     *
     * @param abaRequestDto 顧客属性照会リクエストDTO
     * @return 顧客属性照会ABAレスポンスDTO
     */
    CustomerAttributeInquiryAbaResponseDto customerAttInquiry(CustomerAttributeInquiryAbaRequestDto abaRequestDto);

    /**
     * 認証キー検証
     *
     * @param abaRequestDto 認証キー検証ABAリクエストDTO
     * @return 認証キー検証ABAレスポンスDTO
     *
     */
    AuthenticationKeyVerificationAbaResponseDto
            authenticationKeyVerification(AuthenticationKeyVerificationAbaRequestDto abaRequestDto);

    /**
     * 利用者属性登録
     *
     * @param abaRequestDto 利用者情報ABAレスボスDto
     * @return 利用者属性登録ABAレスボスDTO
     *
     */
    UserAttributeRegistrationAbaResponseDto userAttributeRegistration(UserDataAbaRequestDto abaRequestDto);

    /**
     * 利用者属性照会
     *
     * @param abaRequestDto 利用者属性照会ABAリクエストDTO
     * @return 利用者属性照会ABAレスボスDTO
     *
     */
    UserAttributeInquiryAbaResponseDto userAttributeInquiry(UserAttributeInquiryAbaRequestDto abaRequestDto);

    /**
     * IVR認証スキップ情報更新
     *
     * @param abaRequestDto IVR認証スキップ情報更新ABAリクエストDTO
     * @return 共通レスポンス・ヘッダ
     */
    CommonHeaderAbaResponseDto
            ivrAuthorizationSkipInfoUpdate(IvrAuthorizationSkipInfoUpdateAbaRequestDto abaRequestDto);

    /**
     * ID端末とJBAIDの紐づけ
     *
     * @param abaRequestDto 端末とJBAIDの紐づけリクエストDTO
     */
    void linkingDeviceAndJbaId(JagBodyLinkAuthUserRequestDto abaRequestDto);

    /**
     * 顧客登録情報照会
     *
     * @param abaRequestDto 顧客登録情報更新ABAリクエストDTO
     * @return 顧客登録情報更新ABAレスポンスDTO
     */
    CustomerInquiryInformationAbaDto
            customerRegistrationInformationInquiry(CustomerRegistrationInfoInquiryAbaRequestDto abaRequestDto);

    /**
     * 顧客登録
     *
     * @param abaRequestDto 顧客登録ABAリクエストDTO
     * @return 顧客登録ABAレスポンスDTO
     */
    CustomerRegistrationAbaResponseDto customerRegistration(CustomerRegistrationAbaRequestDto abaRequestDto);

    /**
     * カナ氏名照会
     *
     * @param abaRequestDto カナ氏名照会ABAリクエストDTO
     * @return カナ氏名照会ABAレスポンスDTO
     */
    KanaNameInquiryAbaResponseDto kanaNameInquiry(KanaNameInquiryAbaRequestDto abaRequestDto);

    /**
     * 顧客登録情報更新
     *
     * @param customerUpdateInformationAbaDto 顧客登録情報更新ABAリクエストDTO
     * @return 顧客登録情報更新ABAレスポンスDTO
     */
    CustomerRegistrationInformationUpdateAbaResponseDto
            customerRegistrationInformationUpdate(CustomerUpdateInformationAbaDto customerUpdateInformationAbaDto);

    /**
     * ログイン履歴登録
     *
     * @param abaRequestDto ログイン履歴登録ABAリクエストDTO
     */
    void registLoginHistory(RegistloginHistoryAbaRequestDto abaRequestDto);
    
    /**
     *ログイン履歴照会
     *
     * @param baRequestDto ログイン履歴登録ABAリクエストDTO
     * @return ログイン履歴照会ABAレスポンスDTO
     */
    LoginHistoryAbaResponseDto loginHistoryInquiry(RegistloginHistoryAbaRequestDto abaRequestDto);

    /**
     *残高照会（定期預金）(BA)
     *
     * @param baRequestDto 残高照会（定期預金）BAリクエストDTO
     * @return 残高照会（定期預金）BAレスポンスDTO
     */
    FixedTermDepositBalanceBaResponseDto baGetFixedTermDepositBalance(FixedTermDepositBalanceBaRequestDto baRequestDto);

    /**
     *残高照会（定期積金）(BA)
     *
     * @param baRequestDto 残高照会（定期積金）BAリクエストDTO
     * @return 残高照会（定期積金）BAレスポンスDTO
     */
    FixedInstallmentTimeDepositBalanceBaResponseDto baGetFixedInstallmentTimeDepositBalance(FixedInstallmentTimeDepositBalanceBaRequestDto baRequestDto);

    /**
     *個別フロー CIF照会（モバイル用）(BA)
     *
     * @param baRequestDto 個別フロー CIF照会（モバイル用）BAリクエストDTO
     * @return 個別フロー CIF照会（モバイル用）BAレスポンスDTO
     */
    CifInquiryBaResponseDto baCifInquiry(CifInquiryBaRequestDto baRequestDto);

    /**
     *1.32.利用登録可否チェック(BA)
     *
     * @param baRequestDto 1.32.利用登録可否チェックBAリクエストDTO
     * @return 1.32.利用登録可否チェック BAレスポンスDTO
     */
    CustomersCifBankingapplRegisterCheckBaResponseDto baRegisterCheck(CustomersCifBankingapplRegisterCheckBaRequestDto baRequestDto);
}

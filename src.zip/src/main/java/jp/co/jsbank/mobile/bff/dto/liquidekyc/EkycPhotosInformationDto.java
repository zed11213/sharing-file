package jp.co.jsbank.mobile.bff.dto.liquidekyc;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import lombok.Data;

@Data
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class EkycPhotosInformationDto {
    /**
     * 画像ファイル名
     */
    private String fileName;

    /**
     * 本人確認書類コード
     */
    private String idDocumentType;

    /**
     * 画像種別
     * 01：表面（パスポート以外）
     * 02：裏面（パスポート以外）
     * 03：斜め（パスポート以外）
     * 01：顔写真ページ（パスポート）
     * 02：所持人記入欄ページ（パスポート）
     * 03：顔写真ページ 厚み（パスポート）
     */
    private String photoType;

    /**
     * マスキング済　
     * false：マスキングなし　
     * true：マスキングあり
     */
    private Boolean isMasked;

    /**
     * マスキング処理中
     * マスク処理は本人確認完了後から実施されます。本フラグの状態は、本人確認完了後に確認すること
     * 本人確認完了前：false
     * 本人確認完了後かつマスク処理実施中：true
     * 本人確認完了後かつマスク処理完了後：false
     */
    private Boolean isWaitingMasked;

    /**
     * 画像データ　Base64
     */
    private String image;
    
}

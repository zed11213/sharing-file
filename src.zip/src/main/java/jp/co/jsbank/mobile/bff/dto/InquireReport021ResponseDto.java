package jp.co.jsbank.mobile.bff.dto;

import java.util.List;

import lombok.Data;

/**
 * 帳票CSV内容照会_財産形成預金残高通知書レスポンスDTO
 */
@Data
public class InquireReport021ResponseDto {

	/**
	 * 帳票バージョン
	 */
	private String formVersion;

	/**
	 * 作成日
	 */
	private String createDate;

	/**
	 * お名前
	 */
	private String name;

	/**
	 * 勤務先
	 */
	private String dutyFirst;

	/**
	 * 財産形成預金残高通知明細表リスト
	 */
	private List<PropertyFormationDepositBalanceNotificationDto> propertyFormationDepositBalanceNotificationList;

	/**
	 * 合計_明細件数
	 */
	private String totalNumber;

	/**
	 * 合計_残高金額
	 */
	private String totalAmount;

	/**
	 * 取扱店名
	 */
	private String branchKanjiName;

	/**
	 * 取扱電話番号
	 */
	private String branchPhoneNumber;
}

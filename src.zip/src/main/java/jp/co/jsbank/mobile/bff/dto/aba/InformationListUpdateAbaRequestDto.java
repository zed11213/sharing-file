package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * お知らせ一覧更新ABAリクエストDTO
 */
@Data
public class InformationListUpdateAbaRequestDto {

	/**
	 * 利用者ID
	 */
	private String userId;

	/**
	 * お知らせ種別ID
	 */
	private String informationTypeId;

	/**
	 * 文書種別ID
	 */
	private String documentType;

	/**
	 * お知らせID
	 */
	private String informationId;

	/**
	 * 申込ID
	 */
	private String applyId;

	/**
	 * メール送信結果
	 */
	private String mailSendResult;

	/**
	 * PUSH送信結果
	 */
	private String pushSendResult;

	/**
	 * 既読フラグ
	 */
	private String readFlag;

	/**
	 * お気に入りフラグ
	 */
	private String favoriteFlag;
	
    /**
     * スターフラグ
     */
    private String starFlag;
}

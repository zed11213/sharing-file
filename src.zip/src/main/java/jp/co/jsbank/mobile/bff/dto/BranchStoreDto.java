package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 支店DTO
 */
@Data
public class BranchStoreDto {

    /**
     * 金融機関コード
     */
    private String bankCode;

    /**
     * 店番
     */
    private String branchNumber;

    /**
     * 店名（漢字）
     */
    private String branchKanjiName;

    /**
     * 所属部門区分
     */
    private String divisionType;

    /**
     * 照会店舗タイプ
     */
    private String branchInquiryType;

    /**
     * 郵便番号
     */
    private String zipCode;

    /**
     * 住所
     */
    private String branchKanjiAddress;

    /**
     * 電話番号
     */
    private String phoneNumber;

    /**
     * 店舗案内
     */
    private String branchGuide;

    /**
     * 緯度
     */
    private String latitude;

    /**
     * 経度
     */
    private String longitude;

    /**
     * 表示グループ名
     */
    private String displayGroupName;

    /**
     * 表示順
     */
    private String displayOrder;
}

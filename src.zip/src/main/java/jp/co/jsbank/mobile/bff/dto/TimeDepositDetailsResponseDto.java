package jp.co.jsbank.mobile.bff.dto;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.aba.LatestReceipDetailsDto;
import jp.co.jsbank.mobile.bff.dto.aba.LotteryResultsDetailsDto;
import lombok.Data;

/**
 * 定期預金明細レスポンスDTO
 */
@Data
public class TimeDepositDetailsResponseDto {

    /**
     * 明細ID
     */
    private String detailId;

    /**
     * サブNO
     */
    private String subNo;

    /**
     * 種類（コード）
     */
    private String typeCode;

    /**
     * 元帳残高
     */
    private String balanceOfLedger;

    /**
     * 利率
     */
    private String interestRate;

    /**
     * 課税区分（文言）
     */
    private String taxClassName;

    /**
     * 満期日
     */
    private String maturityDate;

    /**
     * 期間（月数)
     */
    private String periodCodeValue;

    /**
     * 利息受取方法
     */
    private String interestReceivingMethod;

    /**
     * 懸賞金区分（文言）
     */
    private String rewardAmountTypeValue;

    /**
     * 利息受取預金種目
     */
    private String interestReceiveAccountType;

    /**
     * 利息受取口座番号
     */
    private String irAccountNumber;

    /**
     * 契約日
     */
    private String contractDate;

    /**
     * お取引区分
     */
    private String transactionClassification;

    /**
     * 明細概要メモ
     */
    private String memo;

    /**
     * 抽選回数
     */
    private String lotteryTimes;

    /**
     * 取扱組
     */
    private String handlingGroup;

    /**
     * 開始抽選番号
     */
    private String lotteryNoStart;

    /**
     * 終了抽選番号
     */
    private String lotteryNoEnd;

    /**
     * 抽選日
     */
    private String lotteryDate;

    /**
     * 店番
     */
    private String branchNumber;

    /**
     * 当初金額
     */
    private String startAmount;

    /**
     * スーパードリーム等スーパー定期種類
     */
    private String superRegularType;

    /**
     * 総合口座フラグ
     */
    private String generalAccountFlag;

    /**
     * 抽選結果リスト
     */
    private List<LotteryResultsDetailsDto> lotteryResults;

    /**
     * 最新受領情報リスト
     */
    private List<LatestReceipDetailsDto> latestReceiptInfo;
}

package jp.co.jsbank.mobile.bff.dto.liquidekyc;

import lombok.Data;
@Data
public class EkycKycResultResponseDto {
    private String code;
}

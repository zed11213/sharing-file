package jp.co.jsbank.mobile.bff.logic;

import org.springframework.stereotype.Service;

import jp.co.jsbank.mobile.bff.dto.JagBodyDeleteUserRequestDto;
import jp.co.jsbank.mobile.bff.dto.JagBodyLockUserLvlRequestDto;
import jp.co.jsbank.mobile.bff.dto.JagBodyTrxConfirmOrCancelRequestDto;
import jp.co.jsbank.mobile.bff.dto.JagBodyTrxGetIdRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.AccountInformationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.AccountInformationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.AccountRegistrationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.AuthenticationKeyIssuanceAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.BalanceOfDepositAccountsAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.BranchDetailDisplayAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.BranchDetailDisplayAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CancellationAccountDeleteAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CertificateKeyAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CifDepositBalanceAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CifDepositBalanceAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CifInfomationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CifInfomationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CommonHeaderAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CurrentAccountAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.DeleteUseAccountAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.DeleteUserAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.DepositsAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.EmailAddAuthorizationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.EmailAddAuthorizationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.EmailAddressRegistrationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.EmailAddressRegistrationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.NotificationDepositBalanceInquiryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.PassbooklesSettingAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.RegularProvidentFundAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.SavingsAccountsAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.SavingsAccountsAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.StopTradingAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.TaxReserveDepositAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.UseAccountRegistrationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.UserAttributeInquiryAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.UserAttributeInquiryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.UserAttributeRegistrationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.UserAttributeUpdateAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.UserInformationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.UserSettingDetailsAbaResponseDto;

/**
 * 各種登録設定ロジック
 */
@Service
public interface VariousRegistrationPreferenceLogic {

    /**
     * 利用口座削除
     *
     * @param abaRequestDto 利用口座削除ABAリクエストDTO
     */
    void cancellationAccountDelete(CancellationAccountDeleteAbaRequestDto abaRequestDto);

    /**
     * 利用口座削除
     *
     * @param abaRequestDto 通知設定ABAリクエストDTO
     * @return 処理結果
     */
    CommonHeaderAbaResponseDto deleteUseAccount(DeleteUseAccountAbaRequestDto abaRequestDto);

    /**
     * メールアドレス認証
     *
     * @param abaRequestDto メールアドレス認証ABAリクエストDTO
     * @return 共通レスポンスヘッダー
     */
    EmailAddAuthorizationAbaResponseDto emailAddAuthorizationAba(EmailAddAuthorizationAbaRequestDto abaRequestDto);

    /**
     * 取引停止
     *
     * @param abaRequestDto 取引停止情報ABAリクエストDTO
     * @return 共通レスポンスヘッダー
     */
    CommonHeaderAbaResponseDto stopTrading(StopTradingAbaRequestDto abaRequestDto);

    /**
     * 利用者追加確認ステータス更新
     *
     * @param abaRequestDto 利用者情報ABAリクエストDTO
     * @return 共通レスポンスヘッダー
     */
    UserAttributeRegistrationAbaResponseDto userInformationAba(UserInformationAbaRequestDto abaRequestDto);

    /**
     * 認証キー発行
     *
     * @param certificateKeyAbaRequestDto 利用者情報ABAレスボスDto
     * @return 認証キー発行AbaレスポンスDTO
     */
    AuthenticationKeyIssuanceAbaResponseDto
            authenticationKeyIssuanceAba(CertificateKeyAbaRequestDto certificateKeyAbaRequestDto);

    /**
     * 利用者属性更新
     *
     * @param abaRequestDto デザイン更新ABAリクエストDTO
     * @param deviceId 端末ID
     * @return 共通レスポンスヘッダー
     */
    CommonHeaderAbaResponseDto updateUserAttribute(UserAttributeUpdateAbaRequestDto abaRequestDto, String deviceId);

    /**
     * 法人利用者情報一覧取得
     *
     * @param abaRequestDto 利用者属性照会ABAリクエストDTO
     * @return 共通レスポンスヘッダー
     */
    UserSettingDetailsAbaResponseDto getJuridicalPersonUserDetails(UserAttributeInquiryAbaRequestDto abaRequestDto);

    /**
     * CIF情報取得
     *
     * @param abaRequestDto CIF属性照会ABAリクエストDTO
     *
     * @return 処理結果
     */
    CifInfomationAbaResponseDto getCifInfomation(CifInfomationAbaRequestDto abaRequestDto);

    /**
     * 口座情報取得
     *
     * @param abaRequestDto 口座情報リクエストDTO
     * @return 処理結果
     */
    AccountInformationAbaResponseDto getAccountInformation(AccountInformationAbaRequestDto abaRequestDto);

    /**
     * 普通預金残高情報取得
     *
     * @param abaRequestDto 預金残高照会ABAリクエストDTO
     *
     * @return 処理結果
     */
    SavingsAccountsAbaResponseDto getSavingsAccountsInfomation(SavingsAccountsAbaRequestDto abaRequestDto);

    /**
     * 定期預金残高情報取得
     *
     * @param abaRequestDto 預金残高照会ABAリクエストDTO
     *
     * @return 処理結果
     */
    DepositsAbaResponseDto getDepositsInfomation(BalanceOfDepositAccountsAbaRequestDto abaRequestDto);

    /**
     * 定期積金残高情報取得
     *
     * @param abaRequestDto 預金残高照会ABAリクエストDTO
     *
     * @return 処理結果
     */
    RegularProvidentFundAbaResponseDto
            getRegularProvidentFundInfomation(BalanceOfDepositAccountsAbaRequestDto abaRequestDto);

    /**
     * 納税準備預金残高情報取得
     *
     * @param abaRequestDto 預金残高照会ABAリクエストDTO
     *
     * @return 処理結果
     */
    TaxReserveDepositAbaResponseDto getTaxReserveDepositInfomation(SavingsAccountsAbaRequestDto abaRequestDto);

    /**
     * 当座預金残高情報取得
     *
     * @param abaRequestDto 預金残高照会ABAリクエストDTO
     *
     * @return 処理結果
     */
    CurrentAccountAbaResponseDto getCurrentAccountInfomation(SavingsAccountsAbaRequestDto abaRequestDto);

    /**
     * 通知預金残高情報取得
     *
     * @param abaRequestDto 預金残高照会ABAリクエストDTO
     *
     * @return 処理結果
     */
    NotificationDepositBalanceInquiryAbaResponseDto
            getNotificationDepositInfomation(BalanceOfDepositAccountsAbaRequestDto abaRequestDto);

    /**
     * CIF預金残高一覧情報取得
     *
     * @param abaRequestDto CIF預金残高一覧照会リクエストDTO
     *
     * @return 処理結果
     */
    CifDepositBalanceAbaResponseDto getCifDepositBalanceInfomation(CifDepositBalanceAbaRequestDto abaRequestDto);

    /**
     * 支店詳細情報取得
     *
     * @param abaRequestDto 支店詳細照会リクエストDTO
     *
     * @return 処理結果
     */
    BranchDetailDisplayAbaResponseDto getBranchDetailDisplayInfomation(BranchDetailDisplayAbaRequestDto abaRequestDto);

    /**
     * 利用口座登録
     *
     * @param abaRequestDto 利用口座登録ABAリクエストDTO
     * @return 処理結果
     */
    AccountRegistrationAbaResponseDto accountRegistration(UseAccountRegistrationAbaRequestDto abaRequestDto);

    /**
     * CIF情報取得
     *
     * @param requestDto CIF情報取得リクエストDTO
     * @return CIF情報取得レスポンスDTO
     */
    CifInfomationAbaResponseDto getGifInfomation(CifInfomationAbaRequestDto requestDto);

    /**
     * 通帳レス設定
     *
     * @param requestDto 通帳レス設定ABAリクエストDTO
     * @return 共通レスポンスヘッダー
     */
    CommonHeaderAbaResponseDto passBooklessSetting(PassbooklesSettingAbaRequestDto requestDto);

    /**
     * 通知設定情報取得
     *
     * @param abaRequestDto 利用者属性照会ABAリクエストDTO
     * @return 通知設定情報レスポンスDTO
     */
    UserAttributeInquiryAbaResponseDto getNotificationSetting(UserAttributeInquiryAbaRequestDto abaRequestDto);

    /**
     * メールアドレス登録
     *
     * @param abaRequestDto メールアドレス登録ABAリクエストDTO
     * @return 共通レスポンスヘッダー
     */
    EmailAddressRegistrationAbaResponseDto emailAddChangingAba(EmailAddressRegistrationAbaRequestDto abaRequestDto);

    /**
     * デザイン取得
     *
     * @param abaRequestDto 利用者属性照会ABAリクエストDTO
     * @return 設定済みデザイン情報
     */
    UserAttributeInquiryAbaResponseDto getDesignInfomation(UserAttributeInquiryAbaRequestDto abaRequestDto);

    /**
     * 利用者削除
     *
     * @param abaRequestDto 利用者削除ABAリクエストDTO
     * @return 共通レスポンスヘッダー
     */
    CommonHeaderAbaResponseDto userInformationDelete(DeleteUserAbaRequestDto abaRequestDto);

    /**
     * トランザクションID取得
     *
     * @param abaRequestDto トランザクションID取得リクエストDTO
     * @return トランザクションID
     */
    String getJagTrxId(JagBodyTrxGetIdRequestDto abaRequestDto);

    /**
     * ユーザー削除
     *
     * @param abaRequestDto ユーザー削除リクエストDTO
     */
    void userDelete(JagBodyDeleteUserRequestDto abaRequestDto);

    /**
     * ユーザー無効化有効化設定
     *
     * @param abaRequestDto ユーザー無効化有効化設定リクエストDTO
     */
    void userDisableValidationSettings(JagBodyLockUserLvlRequestDto abaRequestDto);

    /**
     * TCC確定またはキャンセル
     *
     * @param abaRequestDto TCC確定またはキャンセルリクエストDTO
     */
    void tccDeterminationCancellation(JagBodyTrxConfirmOrCancelRequestDto abaRequestDto);


}

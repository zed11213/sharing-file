package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 共通リクエスト・ボディ
 */
@Data
public class CommonRequestBody {

    /**
     * 金融機関コード
     */
    private String bankCode;

    /**
     * ユーザーID
     */
    private String userID;
    
    /**
     * ユーザーID(ログ出力用)
     */
    private String userIDForLogging;
    
    /**
     * アプリケーションID
     */
    private String applicationID;
    
    /**
     * クライアントID
     */
    private String clientID;
    
    /**
     * 端末ID
     */
    private String deviceID;
    
    /**
     * ユーザー・カスタマイズ可能フィールド
     */
    private String userString;
    
    /**
     * ユーザー・カスタマイズ可能マップ
     */
    private String userMap;
}

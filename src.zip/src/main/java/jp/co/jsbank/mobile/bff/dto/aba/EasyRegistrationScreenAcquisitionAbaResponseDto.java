package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * かんたん登録画面取得AbaレスボスDTO
 */
@Data
public class EasyRegistrationScreenAcquisitionAbaResponseDto {
	
	 /**
     * 共通レスポンス・ボディ
     */
    private CommonResponseHeader commonResponseHeader;
    
    /**
     * 顧客属性情報
     */
    private List<CustomerAttributeInfoDto> customerList;
}

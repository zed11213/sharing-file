package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 口座開設申込内容DTO
 */
@Data
public class IcosIndividualDto {

    /**
     * 氏名漢字（姓）
     */
    private String nameKanjiLast;

    /**
     * 氏名漢字（名）
     */
    private String nameKanjiFirst;

    /**
     * 生年月日
     */
    private String birthday;

    /**
     * 都道府県
     */
    private String prefecture;

    /**
     * 市区町村
     */
    private String city;

    /**
     * 町域
     */
    private String addrDetail2;
}

package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import jp.co.jsbank.mobile.bff.dto.BranchInquiryTypeDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 支店一覧照会リクエストDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class BranchOfficeListInquiryAbaRequestDto extends RequestBodyDto {

    /**
     * 金融機関コード
     */
    private String bankCodeForSearch;

    /**
     * 店番
     */
    private String branchNumber;

    /**
     * 住所(検索キー)
     */
    private String address;

    /**
     * 表示順序オプション
     */
    private String orderOption;

    /**
     * 照会店舗タイプリスト
     */
    private List<BranchInquiryTypeDto> branchInquiryTypeList;
}

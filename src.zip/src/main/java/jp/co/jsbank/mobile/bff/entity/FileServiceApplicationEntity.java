package jp.co.jsbank.mobile.bff.entity;

import javax.persistence.Column;
import javax.persistence.Table;

import lombok.Data;

/**
 * FS_APPLY_Tエンティティ
 */
@Data
@Table(name = "FS_APPLY_T")
public class FileServiceApplicationEntity {

    @Column(name = "BANK_CODE")
    private String bankCode;

    @Column(name = "BRANCH_CODE")
    private String branchCode;

    @Column(name = "APPLICATION_ID")
    private String applicationId;

    @Column(name = "APPLY_ID")
    private String applyId;

    @Column(name = "CIF_NO")
    private String cifNo;

    @Column(name = "CUSTOMER_ID")
    private String customerId;

    @Column(name = "CUSTOMER_NAME")
    private String customerName;

    @Column(name = "MAIL_ADDRESS")
    private String mailAddress;

    @Column(name = "BIRTHDAY")
    private String birthday;

    @Column(name = "CREATE_TS")
    private String createTs;

    @Column(name = "UPDATE_TS")
    private String updateTs;

    @Column(name = "STATUS")
    private String status;

    @Column(name = "SERIAL_NUMBER")
    private String serialNumber;

    @Column(name = "EXTERNAL_AGREEMENT_ID")
    private String externalAgreementId;

    @Column(name = "FILE_SERVICE_APPLY_TYPE")
    private String fileServiceApplyType;

    @Column(name = "LINKED_APPLY_ID")
    private String linkedApplyId;
}

package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

import java.util.List;

/**
 * 口座属性照会ABAレスボスDto
 */
@Data
public class AccountAttributeInquiryAbaResponseDto {
    /**
     * 利用者属性情報
     */
    private UserAttributeInfoDto userAttributeInfo;

    /**
     * 顧客属性情報
     */
    private Object customerAttributeInfo;

    /**
     * CIF属性情報
     */
    private Object cifAttributeInfo;

    /**
     * 口座属性情報リスト
     */
    private List<Object> accountAttributeInfoList;

}

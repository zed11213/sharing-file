package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * CC暗証番号・IBパスワード設定BFFリクエストDTO
 */
@Data
public class CcPasswordIbPasswordSettingRequestDto {

    /**
     * 受付番号
     */
    private String receptionNumber;
    
    /**
     * CC暗証番号
     */
    private String ccPassword;
    
    /**
     * 人格区分
     */
    private String personalityKubun;  
    
    /**
     * 更新パターン
     */
    private String updateType;
}
package jp.co.jsbank.mobile.bff.dto.liquidekyc;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import lombok.Data;

/**
 * 本人確認完了リクエストDTO
 */
@Data
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class EkycRequestInformationRequestDto {
    /**
    * 連携ID
    */
    private String applicantId;
    /**
     * 氏名　姓 
    */
    private String lastName;
    /**
     *  氏名　名
    */
    private String firstName;
    /**
     *  氏名　ミドルネーム 
    */
    private String middleName;
    /**
     *  氏名　姓　カナ 
    */
    private String lastNameKana;
    /**
     *  氏名　名  カナ
    */
    private String firstNameKana;
    /**
     *  氏名　ミドルネーム 　カナ
    */
    private String middleNameKana;
    /**
     * 生年月日　存在しない日付、1900年1月1日以前は、不正な生年月日（システムエラー）と判定する
     */
    private String birthday;
    /**
     * 国籍  ISO 3166-1 alpha-2　利用　"jp"
     */
    private String nationality;
    /**
     * 性別　マスタコード表参照
     */
    private String sex;
    /**
     * 郵便番号　2~9桁の英数字
     */
    private String zipCode;
    /**
     * 電話番号 ハイフンなし　10桁 or　11桁
     */
    private String phoneNumber;
    /**
     * 住所が分かれていない場合は住所1のみを設定、分かれている場合は都道府県などを設定
     */
    private String address1;
    /**
     * 住所2　住所が分かれている場合、市区町村などを設定
     */
    private String address2;
    /**
     * 住所3　住所が分かれている場合、町域などを設定
     */
    private String address3;
    /**
     * 住所4　住所が分かれている場合、町域以降などを設定
     */
    private String address4;
    /**
     * 本人確認書類番号　運転免許証：数字のみの想定
     */
    private String idNumber;
    
}

package jp.co.jsbank.mobile.bff.logic;

import org.springframework.stereotype.Service;

import jp.co.jsbank.mobile.bff.dto.aba.AccountInfoAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.AccountInfoAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.BalanceGraphAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.BalanceGraphAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CifInfomationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CifInfomationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CommonHeaderAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.LiquidityDepositDetailsAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.LiquidityDepositDetailsAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.LotteryResultAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.LotteryResultAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.MemoRegistrationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.NotificationDepositAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.NotificationDepositDetailsAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.PeriodicDepositDetailsAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.PeriodicDepositDetailsAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.TimeDepositDetailsAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.TimeDepositDetailsAbaResponseDto;

/**
 * 電子通帳ロジック
 */
@Service
public interface ElectronicPassbookLogic {

    /**
     * CIF情報取得
     *
     * @param requestDto CIF情報取得リクエストDTO
     * @return CIF情報取得レスポンスDTO
     */
    CifInfomationAbaResponseDto getGifInfomation(CifInfomationAbaRequestDto requestDto);

    /**
     * 残高情報照会
     *
     * @param requestDto 残高情報取得リクエストDTO
     * @return 残高情報照会レスポンスDTO
     */
    AccountInfoAbaResponseDto balanceInformationInquiry(AccountInfoAbaRequestDto requestDto);

    /**
     * 入出金明細取得(流動性預金)
     *
     * @param requestDto 入出金明細(流動性預金)リクエストDTO
     * @return 入出金明細情報
     */
    LiquidityDepositDetailsAbaResponseDto getIiquidityDepositDetails(LiquidityDepositDetailsAbaRequestDto requestDto);

    /**
     * 定期預金明細取得
     *
     * @param requestDto 定期預金明細リクエストDTO
     * @return 定期預金明細情報
     */
    TimeDepositDetailsAbaResponseDto getTimeDepositDetails(TimeDepositDetailsAbaRequestDto requestDto);

    /**
     * 定期積金明細取得
     *
     * @param requestDto 定期積金明細リクエストDTO
     * @return 定期積金明細情報
     */
    PeriodicDepositDetailsAbaResponseDto getPeriodicDepositDetails(PeriodicDepositDetailsAbaRequestDto requestDto);

    /**
     * 通知預金明細取得
     *
     * @param requestDto 通知預金明細リクエストDTO
     * @return 通知預金明細情報
     */
    NotificationDepositAbaResponseDto getNotificationDepositDetails(NotificationDepositDetailsAbaRequestDto requestDto);

    /**
     * 概要欄メモ登録
     *
     * @param requestDto 概要欄メモ登録ABAリクエストDTO
     * @return 処理結果
     */
    CommonHeaderAbaResponseDto overviewFieldMemoRegistration(MemoRegistrationAbaRequestDto requestDto);

    /**
     * 収支グラフ情報取得
     *
     * @param requestDto 収支グラフ情報ABAリクエストDTO
     * @return 収支情報
     */
    BalanceGraphAbaResponseDto getBalanceGraphInfomation(BalanceGraphAbaRequestDto requestDto);

	/**
	 * 抽選結果情報取得
	 *
	 * @param requestDto 抽選結果情報ABAリクエストDTO
	 * @return 抽選結果
	 */
	LotteryResultAbaResponseDto getLotteryResultInfomation(LotteryResultAbaRequestDto requestDto);
}

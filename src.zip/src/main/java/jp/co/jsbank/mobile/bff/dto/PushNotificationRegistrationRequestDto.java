package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * プッシュ通知登録リクエストDTO
 */
@Data
public class PushNotificationRegistrationRequestDto {

    /**
     * プッシュ通知設定値
     */
    private String settingContent;

    /**
     * OS種類
     */
    private String osType;
}

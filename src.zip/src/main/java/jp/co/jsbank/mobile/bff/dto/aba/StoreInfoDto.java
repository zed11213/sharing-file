package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * 部店照会DTO
 */
@Data
public class StoreInfoDto {

    /**
     * 店名
     */
    private String departmentStoreName;

    /**
     * 部店コード
     */
    private String departmentStoreCode;
}

package jp.co.jsbank.mobile.bff.dto;

import java.util.List;

import lombok.Data;

/**
 * 利用口座登録レスボスDTO
 */
@Data
public class UserAttributeInquiryResponseDto {

    /**
     * 口座情報DTO
     */
    private List<AccountInfosDto> accountInfo;
    
    /**
     * 店名（漢字）
     */
    private String branchKanjiName;
}

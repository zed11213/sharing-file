package jp.co.jsbank.mobile.bff.service;

import org.springframework.stereotype.Service;

import jp.co.jsbank.mobile.bff.dto.LoginHistoryResponseDto;
import jp.co.jsbank.mobile.bff.dto.LoginRequestDto;

/**
 * ログインサービス
 */
@Service
public interface LoginService {

    /**
     * ログイン認証
     *
     * @return ステータス
     */
    LoginHistoryResponseDto loginAuthentication(LoginRequestDto requestDto);
}

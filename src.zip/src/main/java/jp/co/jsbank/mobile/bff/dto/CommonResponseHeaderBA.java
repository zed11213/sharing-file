package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 共通レスポンスヘッダー(BA)
 */
@Data
public class CommonResponseHeaderBA {

    /**
     * アクション・コード
     */
    private String actionCode;

    /**
     * エラー・コード
     */
    private String errorCode;

    /**
     * バックエンド・エラー・コード
     */
    private String backendErrorCode;

    /**
     * エラー・メッセージ
     */
    private String backendErrorMessage;

    /**
     * ユーザー・カスタマイズ可能フィールド
     */
    private String userString;

    /**
     * ユーザー・カスタマイズ可能マップ
     */
    private Object userMap;
}

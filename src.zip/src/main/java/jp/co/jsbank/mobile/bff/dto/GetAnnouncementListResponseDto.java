package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * お知らせ一覧取得DtoレスポンスDTO
 */
@Data
public class GetAnnouncementListResponseDto {
	
	/**
	 * 利用者ID
	 */
	private String userId;
	
	/**
	 * お知らせ種別ID
	 */
	private String informationTypeId;
	
	/**
	 * 文書種別ID
	 */
	private String documentType;
	
	/**
	 * お知らせID
	 */
	private String informationId;
	
	/**
	 * 申込ID
	 */
	private String applyId;
	
	/**
	 * お知らせタイトル
	 */
	private String informationTitle;
	
	/**
	 * 通知日時
	 */
	private String noticeDateTime;
	
	/**
	 * 既読フラグ
	 */
	private String readFlag;
	
	/**
	 * お気に入りフラグ
	 */
	private String favoriteFlag;
	
}

package jp.co.jsbank.mobile.bff.dto;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.aba.AccountInfomationDto;
import lombok.Data;

/**
 * かんたん登録画面取得レスボスDTO
 */
@Data
public class EasyRegistrationScreenAcquisitionResponseDto {

    /**
     * 利用者ID
     */
    private String userId;

    /**
     * CIF情報リスト
     */
    private List<CifCustomerInfomationDto> cifNoList;

    /**
     * 口座情報リスト
     */
    private List<AccountInfomationDto> accountList;

    /**
     * 人格区分
     */
    private String personCode;

    /**
     * 漢字氏名
     */
    private String customerKanjiName;

    /**
     * カナ氏名
     */
    private String customerName;

    /**
     * 生（設立）年月日
     */
    private String dateOfBirth;

    /**
     * 郵便番号
     */
    private String zipNo;

    /**
     * 住所
     */
    private String address;

    /**
     * 電話番号
     */
    private String phoneNumber;

    /**
     * 電話番号1
     */
    private String phoneNumber1;

    /**
     * 電話番号２
     * */
    private String phoneNumber2;

    /**
     * 電話番号３
     * */
    private String phoneNumber3;

    /**
     * 顧客ID
     */
    private String customerId;

    /**
     * 性別
     */
    private String gender;

    /**
     * ステータス
     */
    private String status;

    /**
     * 停止日時
     */
    private String stopDate;

    /**
     * 利用停止再開理由
     */
    private String reason;

    /**
     * メールアドレス
     */
    private String mailAddress;

    /**
     * 初回登録日時
     */
    private String firstLoginDate;

    /**
     * 通帳レスフラグ
     */
    private String lessFlg;

    /**
     * 住所ｶﾅ
     */
    private String addressKana;
}

package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 顧客登録情報照会ABAリクエストDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class CustomerRegistrationInfoInquiryAbaRequestDto extends RequestBodyDto {

    /**
     * 依頼番号
     */
    private String requestNo;
}

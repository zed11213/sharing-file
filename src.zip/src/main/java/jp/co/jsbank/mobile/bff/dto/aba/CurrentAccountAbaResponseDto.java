package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 当座預金残高情報取得照会AbaレスポンスDTO
 */
@Data
public class CurrentAccountAbaResponseDto {
    /**
     * 共通レスポンス・ボディ
     */
    private CommonResponseHeader commonResponseHeader;

    /**
     * CIF番号
     */
    private String cifNumber;
    
    /**
     * 預金種目
     */
    private String accountType;

    /**
     * 店番
     */
    private String branchNumber;

    /**
     * 口座番号
     */
    private String accountNumber;

    /**
     * 元帳残高
     */
    private String balanceOfLedger;

    /**
     * 資金化残高
     */
    private String fundedBalance;

}

package jp.co.jsbank.mobile.bff.dto;

import java.util.List;

import lombok.Data;

/**
 * 受付通知閲覧レスポンスDTO
 */
@Data
public class ReceptionNotificationViewResponseDto {

    /**
     * お知らせID
     */
    private String anncmntId;
    
    /**
     * 申込ID
     */
    private String applyId;
    
    /**
     * タイトル
     */
    private String anncmntTitle;
    
    /**
     * 作成日時
     */
    private String createDateAndTime;
    
    /**
     * 非会員フラグ
     */
    private String nonMemberFlg;
    
    /**
     * CIF番号リスト
     */
    private List<CifInfomationDto> cifNoList;
    
    /**
     * 顧客ID
     */
    private String customerId;
    
    /**
     * 利用者ID
     */
    private String userId;
    
    /**
     * カナ氏名
     */
    private String custNameKana;
    
    /**
     * 漢字氏名
     */
    private String custNameKanji;
    
    /**
     * 郵便番号
     */
    private String custZipCode;
    
    /**
     * カナ住所
     */
    private String custAddressKana;
    /**
     * 住所
     */
    private String custAddress;
    
    /**
     * 電話番号
     */
    private String custPhone;
    
    /**
     * メールアドレス
     */
    private String custMail;
    
    /**
     * 受付フォーマット
     */
    private String receptionFormat;
    
    /**
     * 店名
     */
    private String branchName;
}

package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * CC発行依頼BFFリクエストDTO
 */
@Data
public class CcIssuingRequestDto {

    /**
     * 受付番号
     */
    private String receptionNumber;
    
    /**
     * 申込日
     */
    private String applicationDate;

}

package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 顧客情報登録ABAレスボスDTO
 */
@Data
public class CustomerRegistrationAbaResponseDto {

    /**
     * ABA応答共通ヘッダー
     */
    private CommonResponseHeader commonResponseHeader;

    /**
     * 顧客ID
     */
    private String customerId;

    /**
     * 利用者ID
     */
    private String userId;
}

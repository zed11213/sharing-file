package jp.co.jsbank.mobile.bff.dto;
import java.util.List;

import lombok.Data;

/**
 * 利用者情報レスポンスDTO
 */
@Data
public class UserInformationDetailsResponseDto {
    
    /**
     * 利用者情報DTOリスト
     */
    private List<UserInformationDetailsDto> userInfoList;  
}

package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * IVR認証レスポンスDTO
 */
@Data
public class IvrAuthenticationResponseDto {

    /**
     * 認証結果
     */
    private String authenticationResult;

    /**
     * 顧客ID
     */
    private String customerId;

    /**
     * 利用者ID
     */
    private String userId;
}

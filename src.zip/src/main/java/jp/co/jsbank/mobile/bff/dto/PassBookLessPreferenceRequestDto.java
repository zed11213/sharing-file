package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 通帳レス設定情報リクエストDTO
 */
@Data
public class PassBookLessPreferenceRequestDto {

    /**
     * 顧客ID
     */
    private String customerId;
}

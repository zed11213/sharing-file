package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 定期預金残高照会AbaレスポンスDTO
 */
@Data
public class DepositsAbaResponseDto {
    /**
     * 共通レスポンス・ボディ
     */
    private CommonResponseHeader commonResponseHeader;

    /**
     * CIF番号
     */
    private String cifNumber;

    /**
     * 預金種目
     */
    private String accountType;

    /**
     * 店番
     */
    private String branchNumber;

    /**
     * 口座番号
     */
    private String accountNumber;

    /**
     * サブNo
     */
    private String accountSubNumber;

    /**
     * 回数
     */
    private String numberOfTimes;

    /**
     * 利率
     */
    private String interestRate;

    /**
     * 課税区分
     */
    private String taxClassCode;

    /**
     * 課税区分（文言）
     */
    private String taxClassName;

    /**
     * 契約日
     */
    private String contractDate;

    /**
     * 満期日
     */
    private String maturityDate;

    /**
     * 元帳残高
     */
    private String balanceOfLedger;

    /**
     * 利息受取方法
     */
    private String interestReceivingMethod;

    /**
     * 利息受取預金種目
     */
    private String interestReceiveAccountType;

    /**
     * 利息受取店番
     */
    private String interestReceiveBranchNumber;

    /**
     * 利息受取口座番号
     */
    private String irAccountNumber;

    /**
     * 当初金額
     */
    private String startAmount;

    /**
     * スーパードリーム等スーパー定期種類
     */
    private String superRegularType;

    /**
     * 懸賞金区分
     */
    private String rewardAmountTypeCode;

    /**
     * 懸賞金区分（文言）
     */
    private String rewardAmountTypeValue;

    /**
     * 抽選回数
     */
    private String lotteryTimes;

    /**
     * 取扱組
     */
    private String handlingGroup;

    /**
     * 開始抽選番号
     */
    private String lotteryNoStart;

    /**
     * 終了抽選番号
     */
    private String lotteryNoEnd;

    /**
     * 抽選日
     */
    private String lotteryDate;

    /**
     * お取引区分
     */
    private String transactionClassification;

}

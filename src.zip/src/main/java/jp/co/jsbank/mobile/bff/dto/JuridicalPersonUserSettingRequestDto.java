package jp.co.jsbank.mobile.bff.dto;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 法人利用者情報BFFリクエストDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class JuridicalPersonUserSettingRequestDto  extends RequestBodyDto {

    /**
     * JBAID
     */
    private String jbaid;
}

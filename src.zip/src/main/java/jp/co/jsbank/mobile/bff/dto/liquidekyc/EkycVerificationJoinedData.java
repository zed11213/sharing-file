package jp.co.jsbank.mobile.bff.dto.liquidekyc;

import java.util.Objects;

import lombok.Data;

@Data
public class EkycVerificationJoinedData {
    //from app 
    private  EkycRequestInformationRequestDto requestInformation;
    
    private  EkycGetPhotosResponseDto photos;

    private  EkycVerificationResultResponseDto  verificationResult;

    private  EkycIdDocumentInformationResponseDto idDocumentInformation;

    public EkycVerificationJoinedData() {}

    public EkycVerificationJoinedData(EkycRequestInformationRequestDto requestInformation,
        EkycGetPhotosResponseDto photos,
        EkycVerificationResultResponseDto  verificationResult,
        EkycIdDocumentInformationResponseDto idDocumentInformation){
            this.requestInformation = requestInformation;
            this.photos = photos;
            this.verificationResult = verificationResult;
            this.idDocumentInformation = idDocumentInformation;
        }
    public Boolean photoIsExist() {
         return  Objects.nonNull(this.photos) 
         && Objects.nonNull(this.requestInformation) 
         && !this.photos.getFaceFrontPhoto().getImage().isEmpty();
    }

    public Boolean idDocumentInformationIsExist() {
        return  Objects.nonNull(this.idDocumentInformation) 
         && Objects.nonNull(this.requestInformation);
    }

}



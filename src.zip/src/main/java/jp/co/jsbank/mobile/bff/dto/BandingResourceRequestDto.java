package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * プッシュ通知バインディングリクエストDTO
 */
@Data
public class BandingResourceRequestDto {

    /**
     * 認証トークン
     */
    private String authToken;
}

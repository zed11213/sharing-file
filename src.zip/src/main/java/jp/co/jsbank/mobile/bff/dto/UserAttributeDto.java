package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 口座情報DTO
 */
@Data
public class UserAttributeDto {

    /**
     * 科目名
     */
    private String subjectNameValue;

    /**
     * 店番
     */
    private String branchNumber;

    /**
     * 店名（漢字）
     */
    private String branchKanjiName;

    /**
     * 口座番号
     */
    private String accountNumber;

}

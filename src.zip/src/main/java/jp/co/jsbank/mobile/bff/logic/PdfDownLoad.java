package jp.co.jsbank.mobile.bff.logic;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.ClientHttpRequest;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.stereotype.Service;
import org.springframework.util.StreamUtils;
import org.springframework.web.client.RequestCallback;
import org.springframework.web.client.ResponseExtractor;

import com.alibaba.fastjson.JSON;

import jp.co.jsbank.mobile.bff.config.RestClientConfig;

/**
 * PDFファイルクラス
 */
@Service
public class PdfDownLoad {

    @Autowired
    RestClientConfig restClientConfig;

    /**
     * PDFファイルを取得する
     * 
     * @param url ファイルURL
     * @param method POST
     * @param entity entity
     * @return 処理結果
     */
    public ResponseEntity<Object> getPdfFile(String url, HttpMethod method, HttpEntity<Object> entity) {
        ResponseEntity<Object> roleResponseEntity = restClientConfig.simpleRestTemplate().execute(url, method,
                new RequestCallback() {
                    @Override
                    public void doWithRequest(ClientHttpRequest request) throws IOException {
                        request.getHeaders().addAll(entity.getHeaders());
                        request.getHeaders().add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
                        byte[] requestBodyBytes = JSON.toJSONBytes(entity.getBody());
                        request.getBody().write(requestBodyBytes);
                    }
                }, new ResponseExtractor<ResponseEntity<Object>>() {
                    @SuppressWarnings("deprecation")
                    @Override
                    public ResponseEntity<Object> extractData(ClientHttpResponse response) throws IOException {
                        HttpStatus status = response.getStatusCode();
                        HttpHeaders headers = response.getHeaders();

                        MediaType contentType = response.getHeaders().getContentType();
                        byte[] bytes = new byte[0];
                        if (response.getBody() != null) {
                            bytes = StreamUtils.copyToByteArray(response.getBody());
                        }
                        if (status.is2xxSuccessful()) {
                            if (MediaType.APPLICATION_OCTET_STREAM.equals(contentType)
                                    || MediaType.APPLICATION_PDF.equals(contentType)) {
                                return new ResponseEntity<>(new ByteArrayResource(bytes), headers, status);
                            }
                        } else {
                            if (MediaType.APPLICATION_JSON.equals(contentType)
                                    || MediaType.APPLICATION_JSON_UTF8.equals(contentType)) {
                                return new ResponseEntity<>(new String(bytes, StandardCharsets.UTF_8), headers, status);
                            }
                        }
                        String responseBody = new String(bytes, StandardCharsets.UTF_8);
                        // Libertyシステム例外
                        throw new RuntimeException("システムエラーが発生しました： " + contentType + ", ボディ部：" + responseBody);
                    }
                });
        return roleResponseEntity;
    }
}

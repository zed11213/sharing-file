package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * メールアドレス変更リクエストDTO
 */
@Data
public class EmailAddUpdateRequestDto {

    /**
     * メールアドレス
     */
    private String emailAddress;

    /**
     * 処理区分
     */
    private String processType;
}

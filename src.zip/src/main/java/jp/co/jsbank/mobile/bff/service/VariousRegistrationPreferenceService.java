package jp.co.jsbank.mobile.bff.service;

import java.util.List;

import org.springframework.stereotype.Service;

import jp.co.jsbank.mobile.bff.dto.AccountInfoResponseDto;
import jp.co.jsbank.mobile.bff.dto.AccountInformationResponseDto;
import jp.co.jsbank.mobile.bff.dto.AuthenticationKeyIssuanceResponseDto;
import jp.co.jsbank.mobile.bff.dto.CancellationAccountDeleteRequestDto;
import jp.co.jsbank.mobile.bff.dto.CertificateKeyRequestDto;
import jp.co.jsbank.mobile.bff.dto.CifInfomationResponseDto;
import jp.co.jsbank.mobile.bff.dto.DeleteUseAccountRequestDto;
import jp.co.jsbank.mobile.bff.dto.EmailAddRegistrationRequestDto;
import jp.co.jsbank.mobile.bff.dto.EmailAddressRegistrationResponseDto;
import jp.co.jsbank.mobile.bff.dto.NotificationSettingRequestDto;
import jp.co.jsbank.mobile.bff.dto.NotificationSettingResponseDto;
import jp.co.jsbank.mobile.bff.dto.PassbooklessSettingRequestDto;
import jp.co.jsbank.mobile.bff.dto.PassbooklessSettingResponseDto;
import jp.co.jsbank.mobile.bff.dto.UseAccountRegistrationRequestDto;
import jp.co.jsbank.mobile.bff.dto.UserAdditionalConfirmationStatUpdateRequestDto;
import jp.co.jsbank.mobile.bff.dto.UserAttributeInquiryConfirmationResponseDto;
import jp.co.jsbank.mobile.bff.dto.UserAttributeupdateRequestDto;
import jp.co.jsbank.mobile.bff.dto.UserInformationDetailsResponseDto;

/**
 * 各種登録設定サービス
 */
@Service
public interface VariousRegistrationPreferenceService {

    /**
     * 解約口座一覧取得
     *
     * @return 処理結果
     */
    List<AccountInfoResponseDto> cancellationAccountListAcquisition();

    /**
     * 解約口座删除
     *
     * @param requestDto 解約口座删除リクエストDTOBFFリクエストDTO
     * @return 処理結果
     */
    String cancellationAccountDelete(CancellationAccountDeleteRequestDto requestDto);

    /**
     * 通知設定情報変更
     *
     * @param requestDto 通知設定BFFリクエストDTO
     * @return 処理結果
     */
    String changeNotificationSettingInfo(NotificationSettingRequestDto requestDto);

    /**
     * 利用口座削除
     *
     * @param requestDto 通知設定BFFリクエストDTO
     * @return 処理結果
     */
    String deleteUseAccount(DeleteUseAccountRequestDto requestDto);

    /**
     * メールアドレス登録
     *
     * @param requestDto メールアドレス登録BFFリクエストDTO
     * @return 処理結果
     */
    String emailAddressRegistration(EmailAddRegistrationRequestDto requestDto);

    /**
     * 取引停止
     *
     * @return 利用者情報レスポンスDTOリスト
     */
    String tradingStop();

    /**
     * 利用者追加確認ステータス更新
     *
     * @param requestDto 利用者追加確認ステータス更新BFFリクエストDTO
     * @return 処理結果
     */
    String userAdditionalConfirmationStatUpdate(UserAdditionalConfirmationStatUpdateRequestDto requestDto);

    /**
     * 法人利用者情報一覧取得
     *
     * @return 処理結果
     */
    UserInformationDetailsResponseDto getJuridicalPersonUserDetails();

    /**
     * CIF情報取得
     *
     * @return 処理結果
     */
    CifInfomationResponseDto getCifInfomation();

    /**
     * 口座情報取得
     *
     * @param branchCode 店番
     * @param cifNumber CIF番号
     * @return 処理結果
     */
    AccountInformationResponseDto getAccountInformation(String branchCode, String cifNumber);

    /**
     * 利用口座登録
     *
     * @param requestDto 利用口座登録BFFリクエストDTO
     * @return 処理結果
     */
    String useAccountRegistration(UseAccountRegistrationRequestDto requestDto);

    /**
     * 利用口座登録確認情報取得
     *
     * @param branchCode 店番
     * @param accountNumber 口座番号
     * @param accountType 預金種目
     * @param accountSubNumber サブNo
     * @return 処理結果
     */
    UserAttributeInquiryConfirmationResponseDto getUseAccountRegistrationConfirmation(String branchCode,
            String accountNumber, String accountType, String accountSubNumber);

    /**
     * 通帳レス情報取得
     *
     * @return 処理結果
     */
    PassbooklessSettingResponseDto getPassBooklessInformation();

    /**
     * 通帳レス設定
     *
     * @param requestDto 通帳レス情報BFFリクエストDTO
     * @return 処理結果
     */
    String passBooklessSetting(PassbooklessSettingRequestDto requestDto);

    /**
     * メールアドレス変更
     *
     * @param requestDto メールアドレス変更リクエストDTO
     * @return 処理結果
     */
    EmailAddressRegistrationResponseDto emailAddressChanging(EmailAddRegistrationRequestDto requestDto);

    /**
     * 認証キー発行
     *
     * @param requestDto 認証キー発行BFFリクエストDTO
     * @return 認証キー
     */
    AuthenticationKeyIssuanceResponseDto authenticationKeyIssuance(CertificateKeyRequestDto requestDto);

    /**
     * デザイン更新
     *
     * @param requestDto デザイン更新BFFリクエストDTO
     * @return 処理結果
     */
    String updateDesignInfomation(UserAttributeupdateRequestDto requestDto);

    /**
     * 通知設定情報取得
     *
     * @return 通知設定情報
     */
    NotificationSettingResponseDto getNotificationSetting();

    /**
     * デザイン取得
     *
     * @return 設定値
     */
    String getDesignInfomation();

}

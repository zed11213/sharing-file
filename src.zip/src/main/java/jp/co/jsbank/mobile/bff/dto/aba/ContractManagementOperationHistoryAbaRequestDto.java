package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 契約管理操作履歴ABAリクエストDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class ContractManagementOperationHistoryAbaRequestDto extends RequestBodyDto {

    /**
     * 受付番号
     */
    private String receiptNumber;

}

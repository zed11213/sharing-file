package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 案内照会リクエストDTO
 */
@Data
public class GuidanceInquiryRequestDto {

    /**
     * 申込ステータス
     */
    private String applicationStatus;
    
    /**
     * お知らせID
     */
    private String informationId;
    
}

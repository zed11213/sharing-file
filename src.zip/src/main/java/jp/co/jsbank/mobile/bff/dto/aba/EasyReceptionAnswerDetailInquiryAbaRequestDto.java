package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * かんたん受付回答詳細照会ABAリクエストDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class EasyReceptionAnswerDetailInquiryAbaRequestDto extends RequestBodyDto {

    /**
     * お知らせID
     */
    private String anncmntId;

    /**
     * 申込ID
     */
    private String applyId;

    /**
     * 回答ID
     */
    private String responseId;

    /**
     * 公開中フラグ
     */
    private String releasedFlg;
}

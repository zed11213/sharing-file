package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 申込完了リクエストDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class ApplicationCompleteAbaRequestDto extends RequestBodyDto {

    /**
     * 受付番号
     */
    private String receiptNumber;

    /**
     * 人格コード
     */
    private String personCode;

    /**
     * 申込日
     */
    private String applicationDate;

    /**
     * 画面ID
     */
    private String pageId;
}

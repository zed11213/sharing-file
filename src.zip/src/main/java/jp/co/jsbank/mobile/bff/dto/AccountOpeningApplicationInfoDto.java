package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 口座開設申込情報DTO
 */
@Data
public class AccountOpeningApplicationInfoDto {

    /**
     * 画面ID
     */
    private String screenId;
    
    /**
     * 人格区分
     */
    private String personType;
    
    /**
     * 口座開設申込内容照会（個人）DTO
     */
    private AccountOpenAppliIndividualInfoDto individual;
    
    /**
     * 口座開設申込情報（法人）DTO
     */
    private AccountOpenAppliCorporationInfoDto corporation;
    
    /**
     * 口座開設申込情報（個人事業主）DTO
     */
    private AccountOpenAppliSelfempInfoDto soleProprietor;
    
}

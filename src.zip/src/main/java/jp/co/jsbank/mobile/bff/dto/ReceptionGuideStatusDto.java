package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 受付案内ステータスDto
 */
@Data
public class ReceptionGuideStatusDto {

    /**
     * 受付案内ステータス
     */
    private String receptionGuideStatus;
}

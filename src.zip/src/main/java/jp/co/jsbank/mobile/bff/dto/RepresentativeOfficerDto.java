package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 代表者・役員DTO
 */
@Data
public class RepresentativeOfficerDto {

    /**
     * 役員役職
     */
    private String position;

    /**
     * 役員氏名カナ（姓）
     */
    private String officerLastName;

    /**
     * 役員氏名カナ（名）
     */
    private String officerFirstName;

    /**
     * 役員氏名漢字（姓）
     */
    private String officerKanjiLastName;

    /**
     * 役員氏名漢字（名）
     */
    private String officerKanjiFirstName;

    /**
     * 役員生年月日
     */
    private String officerBirthday;

    /**
     * 役員郵便番号                                                   
     */
    private String officerZipCode;

    /**
     * 役員都道府県（カナ）                                                  
     */
    private String officerPrefectureKana;

    /**
     * 役員都道府県                                                  
     */
    private String officerPrefecture;

    /**
     * 役員市区町村（カナ）                                                  
     */
    private String officerCityKana;

    /**
     * 役員市区町村                                                  
     */
    private String officerCity;

    /**
     * 役員丁目（カナ）                                                    
     */
    private String officerStreetKana;

    /**
     * 役員丁目                                                    
     */
    private String officerStreet;

    /**
     * 役員番地（カナ）                                                    
     */
    private String officerAddressKana;

    /**
     * 役員番地                                                    
     */
    private String officerAddress;

    /**
     * 役員建物名・号室（カナ）                                                    
     */
    private String officerBuildingKana;

    /**
     * 役員建物名・号室                                                    
     */
    private String officerBuilding;

    /**
     * 役員電話番号種別
     */
    private String officerPhoneType;

    /**
     * 役員電話番号（上）
     */
    private String officerPhoneNumOneFirst;

    /**
     * 役員電話番号（中）
     */
    private String officerPhoneNumOneMid;

    /**
     * 役員電話番号（下）
     * 
     */
    private String officerPhoneNumOneLast;
}

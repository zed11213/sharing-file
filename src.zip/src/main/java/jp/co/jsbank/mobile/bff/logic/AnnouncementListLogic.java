package jp.co.jsbank.mobile.bff.logic;

import org.springframework.stereotype.Service;

import jp.co.jsbank.mobile.bff.dto.aba.AnnouncementAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.AnnouncementAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CommonHeaderAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.MobileMessageInquiryAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.MobileMessageInquiryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.UpdateAnnouncementListAbaRequestDto;

/**
 * お知らせ一覧ロジック
 */
@Service
public interface AnnouncementListLogic {

    /**
     * お知らせ一覧参照
     *
     * @param abaRequestDto お知らせ一覧取得ABAリクエストDTO
     * @return 処理結果
     */
    AnnouncementAbaResponseDto getAnnouncementList(AnnouncementAbaRequestDto abaRequestDto);

    /**
     * モバイルメッセージ詳細照会
     *
     * @param abaRequestDto お知らせ本文取得リクエストDTO
     * @return abaRequestDto
     */
    MobileMessageInquiryAbaResponseDto mobileMessageInquiry(MobileMessageInquiryAbaRequestDto abaRequestDto);

    /**
     * お知らせ一覧更新
     *
     * @param abaRequestDto お知らせ一覧更新ABAリクエストDTO
     * @return 処理結果
     */
    CommonHeaderAbaResponseDto updateAnnouncementList(UpdateAnnouncementListAbaRequestDto abaRequestDto);

}

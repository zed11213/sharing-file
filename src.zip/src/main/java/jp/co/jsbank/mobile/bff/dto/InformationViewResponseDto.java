package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * お知らせ閲覧レスポンスDTO
 */
@Data
public class InformationViewResponseDto {

    /**
     * 文書種別コード
     */
    private String documentTypeCode;
    
    /**
     * 帳票CSV内容照会_定期預金利息計算（懸賞金付）（自継）
     */
    private InquireReport001ResponseDto inquireReport001;
    
    /**
     * 帳票CSV内容照会_定期預金（懸賞金付）期日案内
     */
    private InquireReport002ResponseDto inquireReport002;

    /**
     * 帳票CSV内容照会_定期積金満期案内
     */
    private InquireReport003ResponseDto inquireReport003;
    
    /**
     * 帳票CSV内容照会_定期預金期日案内
     */
    private InquireReport004ResponseDto inquireReport004;
    
    /**
     * 帳票CSV内容照会_定期預金（自継）利息計算
     */
    private InquireReport005ResponseDto inquireReport005;
    
    /**
     * 帳票CSV内容照会_定期預金（自継）大口定期利息計算
     */
    private InquireReport006ResponseDto inquireReport006;
    
    /**
     * 帳票CSV内容照会_定期預金（自由金利）期日案内
     */
    private InquireReport007ResponseDto inquireReport007;
    
    /**
     * 帳票CSV内容照会_借入終了案内
     */
    private InquireReport008ResponseDto inquireReport008;
    
    /**
     * 帳票CSV内容照会_総合口座決算案内
     */
    private InquireReport009ResponseDto inquireReport009;
    
    /**
     * 帳票CSV内容照会_融資期日案内
     */
    private InquireReport010ResponseDto inquireReport010;
    
    /**
     * 帳票CSV内容照会_自動送金取扱終了案内
     */
    private InquireReport011ResponseDto inquireReport011;
    
    /**
     * 帳票CSV内容照会_財形年金預金受取案内
     */
    private InquireReport012ResponseDto inquireReport012;
    
    /**
     * 帳票CSV内容照会_証貸変動金利通知
     */
    private InquireReport013ResponseDto inquireReport013;
    
    /**
     * 帳票CSV内容照会_借入返済通知
     */
    private InquireReport014ResponseDto inquireReport014;
    
    /**
     * 帳票CSV内容照会_当座勘定照合表
     */
    private InquireReport015ResponseDto inquireReport015;
    
    /**
     * 帳票CSV内容照会_当座勘定照合表兼当座勘定決算通知
     */
    private InquireReport016ResponseDto inquireReport016;
    
    /**
     * 帳票CSV内容照会_貸金庫使用料期日案内
     */
    private InquireReport017ResponseDto inquireReport017;
    
    /**
     * 帳票CSV内容照会_割引手形計算明細表
     */
    private InquireReport018ResponseDto inquireReport018;
    
    /**
     * 帳票CSV内容照会_融資返済明細表
     */
    private InquireReport019ResponseDto inquireReport019;
    
    /**
     * 帳票CSV内容照会_財産形成預金残高通知書
     */
    private InquireReport021ResponseDto inquireReport021;

}

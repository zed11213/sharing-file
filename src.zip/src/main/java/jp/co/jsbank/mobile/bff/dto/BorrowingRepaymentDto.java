package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * スーパードリーム期日明細表DTO
 */
@Data
public class BorrowingRepaymentDto {

    /**
     * 約定払込年月日
     */
    private String contractPaymentDate;

    /**
     * 払込金額_元金
     */
    private String paymentAmount;

    /**
     * 払込金額_利息
     */
    private String paymentAmountInterest;

    /**
     * 残高
     */
    private String balance;

    /**
     * ボーナス分払込金額_元金
     */
    private String bonusPaymentAmount;

    /**
     * ボーナス分払込金額_利息
     */
    private String bonusPaymentAmountInterest;

    /**
     * ボーナス分残高
     */
    private String bonusBalance;

    /**
     * 合計残高
     */
    private String totalBalance;

    /**
     * 備考
     */
    private String remark;
}

package jp.co.jsbank.mobile.bff.dto.liquidekyc;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

import java.util.List;
import lombok.Data;

/**
 * 自動判定結果取得の判定結果
 * EkycCommonVerificationResultDto
 */

@Data
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
public class EkycCommonVerificationResultDto {
    /**
     * 判定結果
     */
    private String result;

    /**
     * 連携IDリスト
     */
    private List<String> applicant_ids;

}

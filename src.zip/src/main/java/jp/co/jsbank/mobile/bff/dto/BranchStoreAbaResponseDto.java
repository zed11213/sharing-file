package jp.co.jsbank.mobile.bff.dto;

import java.util.List;

import lombok.Data;

/**
 * 支店一覧ABAレスポンスDTO
 */
@Data
public class BranchStoreAbaResponseDto {

    /**
     * 共通レスポンス・ヘッダ
     */
    private CommonResponseHeader commonResponseHeader;

    /**
     * 支店照会件数
     */
    private String branchInquiryCount;

    /**
     * 支店一覧照会
     */
    private List<BranchStoreDto> branchList;
}

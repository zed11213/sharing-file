package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * 申込完了メール送信リクエストDTO
 */
@Data
public class ApplicationCompleteEmailSendingAbaRequestDto {
    
    /**
     * メールアドレス
     */
    private String emailAddress;
    
    /**
     * お知らせ内容
     */
    private String newsDetail;
    
 }

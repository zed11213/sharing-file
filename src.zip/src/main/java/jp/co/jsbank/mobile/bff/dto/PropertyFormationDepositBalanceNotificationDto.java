package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 財産形成預金残高通知明細表DTO
 */
@Data
public class PropertyFormationDepositBalanceNotificationDto {

    /**
     * ご預金種類
     */
    private String depositType;

    /**
     * 口座番号
     */
    private String accountNumber;

    /**
     * 満期日
     */
    private String maturityDate;

    /**
     * 期間
     */
    private String period;

    /**
     * 回数
     */
    private String numberOfTimes;

    /**
     * 現在残高
     */
    private String currentAmount;

    /**
     * 非課税限度額
     */
    private String nonTaxableLimit;
}

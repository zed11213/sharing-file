package jp.co.jsbank.mobile.bff.service;

import jp.co.jsbank.mobile.bff.entity.FileServiceAnncmntEntity;

public interface FileServiceAnncmntService {
    
    /**
     * お知らせIDを検索する
     *
     * @param anncmntId お知らせ
     * @return お知らせID
     */
    FileServiceAnncmntEntity selectByAnncmntId(String anncmntId);

    Boolean checkExistByAnncmntId(String anncmntId);
}

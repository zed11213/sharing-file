package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * CC発行申込完了リクエストDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class CcIssuingApplicationCompleteAbaRequestDto extends RequestBodyDto {

    /**
     * 受付番号
     */
    private String receiptNumber;

    /**
     * 申込日
     */
    private String applicationDate;

    /**
     * 画面ID
     */
    private String pageId;

}

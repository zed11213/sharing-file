package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 実質的支配者DTO
 */
@Data
public class BeneficialOwnerDto {

    /**
     * 支配者カナ氏名（姓）
     */
    private String rulerLastName;

    /**
     * 支配者カナ氏名（名）
     */
    private String rulerFirstName;

    /**
     * 支配者氏名漢字（姓）
     */
    private String rulerKanjiLastName;

    /**
     * 支配者氏名漢字（名）
     */
    private String rulerKanjiFirstName;

    /**
     * 支配者生年月日
     */
    private String rulerBirthday;

    /**
     * 支配者郵便番号
     */
    private String rulerZipCode;

    /**
     * 支配者都道府県（カナ）
     */
    private String rulerPrefectureKana;

    /**
     * 支配者都道府県
     */
    private String rulerPrefecture;

    /**
     * 支配者市区町村（カナ）
     */
    private String rulerCityKana;

    /**
     * 支配者市区町村
     */
    private String rulerCity;

    /**
     * 支配者丁目（カナ）
     */
    private String rulerStreetKana;

    /**
     * 支配者丁目
     */
    private String rulerStreet;

    /**
     * 支配者番地（カナ）
     */
    private String rulerAddressKana;

    /**
     * 支配者番地
     */
    private String rulerAddress;

    /**
     * 支配者建物名・号室（カナ）
     */
    private String rulerBuildingKana;

    /**
     * 支配者建物名・号室
     */
    private String rulerBuilding;

    // 2025/01/29 共同化ため実質的支配者の電話番号 start
    /**
     * 実質的支配者電話種別
     */
    private String rulerPhoneType;

    /**
     * 実質的支配者電話番号
     */
    private String rulerPhoneNumFirst;

    /**
     * 実質的支配者電話番号
     */
    private String rulerPhoneNumMid;

    /**
     * 実質的支配者電話番号
     */
    private String rulerPhoneNumLast;

    // 2025/01/29 共同化ため実質的支配者の電話番号 end
}

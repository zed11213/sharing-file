package jp.co.jsbank.mobile.bff.common;

public enum EkycIdDocumentTypeCode {
    // へ方式　　運転免許証
    HeDriverLicenseOld("11", BffDocumentType.DRIVER_LICENSE),
    HeDriverLicenseNew("00011", BffDocumentType.MYNUMBERCARD),
    // へ方式　マイナンバーカード
    HeMynumberCardOld("12", BffDocumentType.MYNUMBERCARD),
    HeMynumberCardNew("00012", BffDocumentType.MYNUMBERCARD),
    // 公的個人認証
    WaMynumberCardOld("42", BffDocumentType.MYNUMBERCARD),
    WaMynumberCardNew("00042", BffDocumentType.MYNUMBERCARD),

    WaMynumberCardMyNumber("04023", BffDocumentType.MYNUMBERCARD),
    WaMynumberCardFace("04022", BffDocumentType.MYNUMBERCARD),
    WaMynumberCardFaceMyNumber("07023", BffDocumentType.MYNUMBERCARD),

    // ト方式
    ToDriverLicenseOld("51", BffDocumentType.DRIVER_LICENSE),
    ToDriverLicenseNew("00051", BffDocumentType.DRIVER_LICENSE),
    ToMynumberCardOld("52", BffDocumentType.MYNUMBERCARD),
    ToMynumberCardNew("53", BffDocumentType.MYNUMBERCARD),

    // チ方式

    ChiDriverLicenseOld("61",BffDocumentType.DRIVER_LICENSE),
    ChiDriverLicenseNew("00061",BffDocumentType.DRIVER_LICENSE),
    ChiMynumberCardOld("62", BffDocumentType.MYNUMBERCARD),
    ChiMynumberCardNew("00062", BffDocumentType.MYNUMBERCARD),
    GlobalFaceDriverLicense("11001", BffDocumentType.DRIVER_LICENSE),
    GlobalFaceMynumberCard("11002", BffDocumentType.MYNUMBERCARD);

    public enum BffDocumentType  {
        
        DRIVER_LICENSE("01","運転免許証"),
        MYNUMBERCARD("02","マイナンバーカード");

        private final String code;
        private final String name;

        BffDocumentType(String code, String name) {
            this.code = code;
            this.name = name;
        }
        public String getCode() {
            return this.code;
        }
        public String getName() {
            return this.name;
        }
    }


    private final String ekycCode;
    private final BffDocumentType documentType;

    EkycIdDocumentTypeCode(String ekycCode,BffDocumentType documentType) {
        this.ekycCode = ekycCode;
        this.documentType =  documentType;
    }

    public String getValue() {
        return this.ekycCode;
    }

    public BffDocumentType getDocumentType() {
        return this.documentType;
    }

    public static EkycIdDocumentTypeCode fromValue(String value) {
        for (EkycIdDocumentTypeCode e : EkycIdDocumentTypeCode.values()) {
            if (e.getValue().equals(value)) {
                return e;
            }
        }
        throw new IllegalArgumentException("未対応の書類コード: " + value);
    }

     public static BffDocumentType getBffDocumentType(String value) {
        for (EkycIdDocumentTypeCode e : EkycIdDocumentTypeCode.values()) {
            if (e.getValue().equals(value)) {
                return e.getDocumentType();
            }
        }
        throw new IllegalArgumentException("未対応の書類コード: " + value);
    }
    // 書類コード変換
    public static String convertToBffDocumentCodeFromEkycDocumentCode(String ekycCode) {
        BffDocumentType documentType = EkycIdDocumentTypeCode.getBffDocumentType(ekycCode);
        return documentType.getCode();

    }



}

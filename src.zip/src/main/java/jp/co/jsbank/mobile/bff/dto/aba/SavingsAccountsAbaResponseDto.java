package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 利用口座登録照会AbaレスポンスDTO
 */
@Data
public class SavingsAccountsAbaResponseDto {
    /**
     * 共通レスポンス・ボディ
     */
    private CommonResponseHeader commonResponseHeader;

    /**
     * CIF番号
     */
    private String cifNumber;

    /**
     * 預金種目
     */
    private String accountType;

    /**
     * 店番
     */
    private String branchNumber;

    /**
     * 口座番号
     */
    private String accountNumber;

    /**
     * 元帳残高
     */
    private String balanceOfLedger;

    /**
     * 資金化残高
     */
    private String fundedBalance;

    /**
     * 本人カード発行区分
     */
    private String cardIssueType;

    /**
     * 本人カード仮発行
     */
    private String cardDummyIssue;

}

package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 当座勘定明細表DTO
 */
@Data
public class CurrentAccountDto {

	/**
	 * 取引年月日
	 */
	private String transactionDate;

	/**
	 * 入出金
	 */
	private String depositsAndWithdrawals;

	/**
	 * 種類
	 */
	private String type;

	/**
	 * 取扱
	 */
	private String handling;

	/**
	 * 振込人名
	 */
	private String transferPersonName;

	/**
	 * 交換
	 */
	private String exchange;

	/**
	 * 手形番号
	 */
	private String billNumber;

	/**
	 * お支払額
	 */
	private String paymentAmount;

	/**
	 * ご入金額
	 */
	private String depositAmount;

	/**
	 * 差引残高
	 */
	private String deductionBalance;
}

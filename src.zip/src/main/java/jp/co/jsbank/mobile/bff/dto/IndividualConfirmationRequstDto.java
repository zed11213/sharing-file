package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 個別確認リクエストDTO
 */
@Data
public class IndividualConfirmationRequstDto {

    /**
     * お知らせ種別ID
     */
    private String informationTypeId;

    /**
     * 文書種別ID
     */
    private String documentType;
    
    /**
     * お知らせID
     */
    private String informationId;

}

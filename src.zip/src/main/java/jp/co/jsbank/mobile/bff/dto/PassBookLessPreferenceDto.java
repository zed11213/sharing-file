package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 通帳レス設定情報リクエストDTO
 */
@Data
public class PassBookLessPreferenceDto {

    /**
     * CIF番号
     */
    private String cifNumber;

    /**
     * 店番
     */
    private String branchCode;
}

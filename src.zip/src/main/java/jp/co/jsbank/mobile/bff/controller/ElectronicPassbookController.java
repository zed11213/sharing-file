package jp.co.jsbank.mobile.bff.controller;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import jp.co.jsbank.mobile.bff.common.JsonResult;
import jp.co.jsbank.mobile.bff.dto.AccountAndBalanceInfoResponseDto;
import jp.co.jsbank.mobile.bff.dto.BalanceGraphResponseDto;
import jp.co.jsbank.mobile.bff.dto.GetDetailsRequestDto;
import jp.co.jsbank.mobile.bff.dto.IiquidityDepositDetailsRequestDto;
import jp.co.jsbank.mobile.bff.dto.LiquidityDepositDetailsResponseDto;
import jp.co.jsbank.mobile.bff.dto.MemoRegistrationRequestDto;
import jp.co.jsbank.mobile.bff.dto.NotificationDepositDetailsResponseDto;
import jp.co.jsbank.mobile.bff.dto.PeriodicDepositDetailsResponseDto;
import jp.co.jsbank.mobile.bff.dto.TimeDepositDetailsResponseDto;
import jp.co.jsbank.mobile.bff.service.ElectronicPassbookService;

/**
 * 電子通帳コントロール
 */
@RestController
public class ElectronicPassbookController {

    @Resource
    private ElectronicPassbookService electronicPassbookService;

    /**
     * 口座一覧と各口座の残高情報取得
     *
     * @return 口座一覧と各口座の残高情報
     */
    @PostMapping(path = "/e-passbook/AB0401")
    public String getAccountListAndBalanceInformation() {

        // 口座一覧と各口座の残高情報取得
        AccountAndBalanceInfoResponseDto responseDto = electronicPassbookService.getAccountListAndBalanceInformation();

        return JsonResult.success(responseDto);
    }

    /**
     * 入出金明細取得(流動性預金)
     *
     * @param iiquidityDepositDetailsRequestDto 入出金明細取得(流動性預金)リクエストDTO
     * @return 入出金明細情報
     */
    @PostMapping(path = "/e-passbook/AB0402")
    public String getIiquidityDepositDetails(@RequestBody IiquidityDepositDetailsRequestDto iiquidityDepositDetailsRequestDto) {

        // 明細継続フラグ
        String detailContinuationFlag = iiquidityDepositDetailsRequestDto.getDetailContinuationFlag();

        // 開始明細ID
        String detailIdFrom = iiquidityDepositDetailsRequestDto.getDetailIdFrom();

        // 最大検索件数
        String maxInquiryCount = iiquidityDepositDetailsRequestDto.getMaxInquiryCount();

        // 預金種目
        String accountType = iiquidityDepositDetailsRequestDto.getAccountType();

        // 店番
        String branchNumber = iiquidityDepositDetailsRequestDto.getBranchNumber();

        // 口座番号設定
        String accountNumber = iiquidityDepositDetailsRequestDto.getAccountNumber();

        // 照会開始年月日設定
        String dateOfInquiryFrom = iiquidityDepositDetailsRequestDto.getDateOfInquiryFrom();

        // 照会終了年月日設定
        String dateOfInquiryTo = iiquidityDepositDetailsRequestDto.getDateOfInquiryTo();

        // 流動性口座の入出金明細を取得する
        LiquidityDepositDetailsResponseDto responseDto = electronicPassbookService.getIiquidityDepositDetails(
                detailContinuationFlag, detailIdFrom, maxInquiryCount, accountType, branchNumber, accountNumber,
                dateOfInquiryFrom, dateOfInquiryTo);

        return JsonResult.success(responseDto);
    }

    /**
     * 定期預金明細取得
     *
     * @param timeDepositDetailsRequestDto 定期預金明細取得リクエストDTO
     * @return 定期預金明細情報
     */
    @PostMapping(path = "/e-passbook/AB0403")
    public String getTimeDepositDetails(@RequestBody GetDetailsRequestDto timeDepositDetailsRequestDto) {
        String accountNumber = timeDepositDetailsRequestDto.getAccountNumber();
        String branchNumber = timeDepositDetailsRequestDto.getBranchNumber();
        String cifNumber = timeDepositDetailsRequestDto.getCifNumber();

        // 定期預金明細取得を取得する
        List<TimeDepositDetailsResponseDto> responseDto = electronicPassbookService.getTimeDepositDetails(accountNumber,
                branchNumber, cifNumber);

        return JsonResult.success(responseDto);
    }

    /**
     * 定期積金明細取得
     *
     * @param timeDepositDetailsRequestDto 定期預金明細取得リクエストDTO
     * @return 定期預金明細情報
     */
    @PostMapping(path = "/e-passbook/AB0404")
    public String getPeriodicDepositDetails(@RequestBody GetDetailsRequestDto timeDepositDetailsRequestDto) {

        // 口座番号
        String accountNumber = timeDepositDetailsRequestDto.getAccountNumber();
        // 店番
        String branchNumber = timeDepositDetailsRequestDto.getBranchNumber();
        // CIF番号
        String cifNumber = timeDepositDetailsRequestDto.getCifNumber();
        // 定期積金明細を取得する
        PeriodicDepositDetailsResponseDto responseDto = electronicPassbookService
                .getPeriodicDepositDetails(accountNumber, branchNumber, cifNumber);

        return JsonResult.success(responseDto);
    }

    /**
     * 通知預金明細取得
     *
     * @param notificationDepositDetailsRequestDto 通知預金明細取得リクエストDTO
     * @return 通知預金明細情報
     */
    @PostMapping(path = "/e-passbook/AB0405")
    public String getNotificationDepositDetails(@RequestBody GetDetailsRequestDto notificationDepositDetailsRequestDto) {
        // 口座番号
        String accountNumber = notificationDepositDetailsRequestDto.getAccountNumber();
        // 店番
        String branchNumber = notificationDepositDetailsRequestDto.getBranchNumber();
        // CIF番号
        String cifNumber = notificationDepositDetailsRequestDto.getCifNumber();

        // 通知預金明細を取得する
        NotificationDepositDetailsResponseDto responseDto = electronicPassbookService
                .getNotificationDepositDetails(accountNumber, branchNumber, cifNumber);

        return JsonResult.success(responseDto);
    }

    /**
     * 概要欄メモ登録
     *
     * @param requestDto 明細概要メモ登録リクエストDTO
     * @return 処理結果
     */
    @PutMapping(path = "/e-passbook/AB0406")
    public String overviewFieldMemoRegistration(@RequestBody MemoRegistrationRequestDto requestDto) {

        // 概要欄メモ登録
        String result = electronicPassbookService.overviewFieldMemoRegistration(requestDto);

        return JsonResult.success(result);
    }

    /**
     * 収支グラフ表示値取得
     *
     * @param balanceGraphDisplayValueRequestDto 収支グラフ表示値取得リクエストDTO
     * @return 収支情報
     */
    @PostMapping(path = "/e-passbook/AB0407")
    public String getBalanceGraphDisplayValue(@RequestBody GetDetailsRequestDto balanceGraphDisplayValueRequestDto) {

        // 口座番号
        String accountNumber = balanceGraphDisplayValueRequestDto.getAccountNumber();
        // 店番
        String branchNumber = balanceGraphDisplayValueRequestDto.getBranchNumber();
        // 預金種目
        String accountType = balanceGraphDisplayValueRequestDto.getAccountType();

        // 収支グラフ表示値取得
        List<BalanceGraphResponseDto> responseDto = electronicPassbookService.getBalanceGraphDisplayValue(accountNumber,
                branchNumber,accountType);

        return JsonResult.success(responseDto);
    }

}

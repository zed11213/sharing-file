package jp.co.jsbank.mobile.bff.entity;

import javax.persistence.Column;
import javax.persistence.Table;

import lombok.Data;

/**
 * FS_ANNCMNT_Tエンティティ
 */
@Data
@Table(name = "FS_ANNCMNT_T")
public class FileServiceAnncmntEntity {

    @Column(name = "ANNCMNT_ID")
    private String anncmntId;

    @Column(name = "CREATE_TS")
    private String createTs;

    @Column(name = "UPDATE_TS")
    private String updateTs;
}

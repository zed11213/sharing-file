package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * ログインリクエストDTO
 */
@Data
public class LoginAbaRequestDto {

    /**
     * JBAID
     */
    private String jbaid;

    /**
     * パスワード
     */
    private String password;
}

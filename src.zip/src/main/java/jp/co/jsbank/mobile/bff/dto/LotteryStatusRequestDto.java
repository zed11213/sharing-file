package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 抽選状態BFFリクエストDTO
 */
@Data
public class LotteryStatusRequestDto {

    /**
     * 明細ID
     */
    private String detailId;
    
    /**
     * 抽選状態
     */
    private String status;
}

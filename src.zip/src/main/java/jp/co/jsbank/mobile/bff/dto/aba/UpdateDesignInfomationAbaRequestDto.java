package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * デザイン更新ABAリクエストDTO
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class UpdateDesignInfomationAbaRequestDto extends RequestBodyDto {

    /**
     * 利用者ID
     */
    private String userId;
    
    /**
     * 設定種別
     */
    private String settingType;
    
    /**
     * 設定値
     */
    private String settingContent;
}

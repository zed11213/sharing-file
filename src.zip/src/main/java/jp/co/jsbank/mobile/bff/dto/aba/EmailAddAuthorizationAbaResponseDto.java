package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * メールアドレス認証AbaレスポンスDTO
 */
@Data
public class EmailAddAuthorizationAbaResponseDto {
	
	
	 /**
     * 共通レスポンス・ボディ
     */
    private CommonResponseHeader commonResponseHeader;   
    
    /**
     * 認証結果
     */
    private String authenticationResult;
    
    /**
     * メールアドレス
     */
    private String emailAddress;
    
 }

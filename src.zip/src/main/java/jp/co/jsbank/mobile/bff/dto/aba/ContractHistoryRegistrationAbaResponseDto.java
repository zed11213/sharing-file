package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * 契約管理操作履歴登録ABAレスボスDTO
 */
@Data
public class ContractHistoryRegistrationAbaResponseDto {
    /**
     * JBAID
     */
    private String jbaid;


    /**
     * 利用者ID
     */
    private String userId;
}

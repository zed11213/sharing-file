package jp.co.jsbank.mobile.bff.controller.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.fasterxml.jackson.databind.ObjectMapper;

import jp.co.jsbank.mobile.bff.controller.SignUpController;
import jp.co.jsbank.mobile.bff.dto.BankbookPatternPreferenceRequestDto;
import jp.co.jsbank.mobile.bff.dto.DepartmentStoreInquiryResponseDto;
import jp.co.jsbank.mobile.bff.dto.EmailAddressAuthorizationRequestDto;
import jp.co.jsbank.mobile.bff.dto.EmailAddressRegistrationRequestDto;
import jp.co.jsbank.mobile.bff.dto.IdentityVerificationRequestDto;
import jp.co.jsbank.mobile.bff.dto.IdentityVerificationResponseDto;
import jp.co.jsbank.mobile.bff.dto.IvrAuthenticationRequestDto;
import jp.co.jsbank.mobile.bff.dto.PassBookLessPreferenceRequestDto;
import jp.co.jsbank.mobile.bff.dto.PassbookLessSettingInformationResponseDto;
import jp.co.jsbank.mobile.bff.dto.PushNotificationRegistrationRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.IvrSendingRequestDto;
import jp.co.jsbank.mobile.bff.service.SignUpService;

/**
 * 初回登録コントロールテスト
 */
@RunWith(SpringRunner.class)
@AutoConfigureMockMvc
@SpringBootTest(classes = SignUpController.class)
@EnableWebMvc
public class SignUpControllerTest {

    @Autowired
    private MockMvc mvc;

    @MockBean
    private SignUpService signUpService;

    /**
     * テストメソッド： emailAddressRegistration(/sign-up/AB0101)（正常系）</br>
     * 
     * テスト条件：</br>
     * ①なし</br>
     * 
     * テスト結果：</br>
     * ①JsonResultのstatusCodeは「200」が設定されている</br>
     * ②JsonResultのresultDtoは「OK」が設定されている</br>
     */
    @Test
    public void testEmailAddressRegistration() throws Exception {

        Mockito.when(signUpService.emailAddressRegistration(Mockito.any(EmailAddressRegistrationRequestDto.class)))
                .thenReturn("OK");

        // テストを呼び出す
        MvcResult result = mvc.perform(
                post("/sign-up/AB0101").accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(new EmailAddressRegistrationRequestDto())))
                .andReturn();

        String responseContent = result.getResponse().getContentAsString();

        JSONObject resultJson = new JSONObject(responseContent);

        // テスト結果
        assertEquals("200", resultJson.get("statusCode").toString());
        assertEquals("OK", resultJson.get("resultDto").toString());
    }

    /**
     * テストメソッド： emailAddressAuthorization(/sign-up/AB0102)（正常系）</br>
     * 
     * テスト条件：</br>
     * ①なし</br>
     * 
     * テスト結果：</br>
     * ①JsonResultのstatusCodeは「200」が設定されている</br>
     * ②JsonResultのresultDto[0]は「test1」が設定されている</br>
     * ③JsonResultのresultDto[1]は「test2」が設定されている</br>
     */
    @Test
    public void testEmailAddressAuthorization() throws Exception {

        List<String> resultData = new ArrayList<String>();
        resultData.add("test1");
        resultData.add("test2");
        Mockito.when(signUpService.emailAddressAuthorization(Mockito.any(EmailAddressAuthorizationRequestDto.class)))
                .thenReturn(resultData);

        // テストを呼び出す
        MvcResult result = mvc.perform(
                post("/sign-up/AB0102").accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(new EmailAddressAuthorizationRequestDto())))
                .andReturn();

        String responseContent = result.getResponse().getContentAsString();

        JSONObject resultJson = new JSONObject(responseContent);

        // テスト結果
        assertEquals("200", resultJson.get("statusCode").toString());
        assertEquals("test1", resultJson.getJSONArray("resultDto").get(0));
        assertEquals("test2", resultJson.getJSONArray("resultDto").get(1));
    }

    /**
     * テストメソッド： identityVerification(/sign-up/AB0103)（正常系）</br>
     * 
     * テスト条件：</br>
     * ①なし</br>
     * 
     * テスト結果：</br>
     * ①JsonResultのstatusCodeは「200」が設定されている</br>
     * ②JsonResultのJBAIDが正しく設定されている</br>
     * ③JsonResultの利用者IDが正しく設定されている</br>
     */
    @Test
    public void testIdentityVerification() throws Exception {

        IdentityVerificationResponseDto responseDto = new IdentityVerificationResponseDto();
        responseDto.setJbaId("jbaId");
        responseDto.setUserId("userId");
        Mockito.when(signUpService.identityVerification(Mockito.any(IdentityVerificationRequestDto.class)))
                .thenReturn(responseDto);

        // テストを呼び出す
        MvcResult result = mvc.perform(post("/sign-up/AB0103").accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON).content(asJsonString(new IdentityVerificationRequestDto())))
                .andReturn();

        String responseContent = result.getResponse().getContentAsString();

        JSONObject resultJson = new JSONObject(responseContent);

        // テスト結果
        assertEquals("200", resultJson.get("statusCode").toString());
        assertEquals("jbaId", resultJson.getJSONObject("resultDto").get("jbaId"));
        assertEquals("userId", resultJson.getJSONObject("resultDto").get("userId"));
    }

    /**
     * テストメソッド： ivrSending(/sign-up/AB0105)（正常系）</br>
     * 
     * テスト条件：</br>
     * ①なし</br>
     * 
     * テスト結果：</br>
     * ①JsonResultのstatusCodeは「200」が設定されている</br>
     * ②JsonResultのresultDtoは「OK」が設定されている</br>
     */
    @Test
    public void testIvrSending() throws Exception {

        Mockito.when(signUpService.ivrSending(Mockito.any(IvrSendingRequestDto.class))).thenReturn("OK");

        // テストを呼び出す
        MvcResult result = mvc.perform(post("/sign-up/AB0105").accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON).content(asJsonString(new IdentityVerificationRequestDto())))
                .andReturn();

        String responseContent = result.getResponse().getContentAsString();

        JSONObject resultJson = new JSONObject(responseContent);

        // テスト結果
        assertEquals("200", resultJson.get("statusCode").toString());
        assertEquals("OK", resultJson.get("resultDto").toString());
    }

    /**
     * テストメソッド： ivrAuthentication(/sign-up/AB0106)（正常系）</br>
     * 
     * テスト条件：</br>
     * ①なし</br>
     * 
     * テスト結果：</br>
     * ①JsonResultのstatusCodeは「200」が設定されている</br>
     * ②JsonResultのresultDtoは「OK」が設定されている</br>
     */
    @Test
    public void testIvrAuthentication() throws Exception {

        Mockito.when(signUpService.ivrAuthentication(Mockito.any(IvrAuthenticationRequestDto.class))).thenReturn("OK");

        // テストを呼び出す
        MvcResult result = mvc.perform(post("/sign-up/AB0106").accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON).content(asJsonString(new IvrAuthenticationRequestDto())))
                .andReturn();

        String responseContent = result.getResponse().getContentAsString();

        JSONObject resultJson = new JSONObject(responseContent);

        // テスト結果
        assertEquals("200", resultJson.get("statusCode").toString());
        assertEquals("OK", resultJson.get("resultDto").toString());
    }

    /**
     * テストメソッド： departmentStoreInquiry(/sign-up/AB0112)（正常系）</br>
     * 
     * テスト条件：</br>
     * ①なし</br>
     * 
     * テスト結果：</br>
     * ①JsonResultのstatusCodeは「200」が設定されている</br>
     * ②JsonResultの店名が正しく設定されている</br>
     * ③JsonResultの部店コードが正しく設定されている</br>
     */
    @Test
    public void testDepartmentStoreInquiry() throws Exception {

        DepartmentStoreInquiryResponseDto dto = new DepartmentStoreInquiryResponseDto();
        List<DepartmentStoreInquiryResponseDto> butenInquiryLIst = new ArrayList<>();
        butenInquiryLIst.add(dto);
        Mockito.when(signUpService.departmentStoreInquiry()).thenReturn(butenInquiryLIst);

        // テストを呼び出す
        MvcResult result = mvc.perform(
                get("/sign-up/AB0112").accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON))
                .andReturn();

        String responseContent = result.getResponse().getContentAsString();

        JSONObject resultJson = new JSONObject(responseContent);

        // テスト結果
        assertEquals("200", resultJson.get("statusCode").toString());
        assertEquals("0001", resultJson.getJSONArray("resultDto").getJSONObject(0).get("branchCode"));
        assertEquals("store", resultJson.getJSONArray("resultDto").getJSONObject(0).get("branchKanjiName"));
    }

    /**
     * テストメソッド： updateUserAttribute(/sign-up/AB0113)（正常系）</br>
     * 
     * テスト条件：</br>
     * ①なし</br>
     * 
     * テスト結果：</br>
     * ①JsonResultのstatusCodeは「200」が設定されている</br>
     * ②JsonResultのresultDtoは「OK」が設定されている</br>
     */
    @Test
    public void testUpdateUserAttribute() throws Exception {

        Mockito.when(signUpService.updateUserAttribute()).thenReturn("OK");

        // テストを呼び出す
        MvcResult result = mvc.perform(get("/sign-up/AB0113").accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON)).andReturn();

        String responseContent = result.getResponse().getContentAsString();

        JSONObject resultJson = new JSONObject(responseContent);

        // テスト結果
        assertEquals("200", resultJson.get("statusCode").toString());
        assertEquals("OK", resultJson.get("resultDto").toString());
    }

    /**
     * テストメソッド： pushNotificationRegistration(/sign-up/AB0119)（正常系）</br>
     * 
     * テスト条件：</br>
     * ①なし</br>
     * 
     * テスト結果：</br>
     * ①JsonResultのstatusCodeは「200」が設定されている</br>
     * ②JsonResultのresultDtoは「OK」が設定されている</br>
     */
    @Test
    public void testPushNotificationRegistration() throws Exception {

        Mockito.when(
                signUpService.pushNotificationRegistration(Mockito.any(PushNotificationRegistrationRequestDto.class)))
                .thenReturn("OK");

        // テストを呼び出す
        MvcResult result = mvc.perform(
                post("/sign-up/AB0119").accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(new PushNotificationRegistrationRequestDto())))
                .andReturn();

        String responseContent = result.getResponse().getContentAsString();

        JSONObject resultJson = new JSONObject(responseContent);

        // テスト結果
        assertEquals("200", resultJson.get("statusCode").toString());
        assertEquals("OK", resultJson.get("resultDto").toString());
    }

    /**
     * テストメソッド： bankbookPatternPreference(/sign-up/AB0120)（正常系）</br>
     * 
     * テスト条件：</br>
     * ①なし</br>
     * 
     * テスト結果：</br>
     * ①JsonResultのstatusCodeは「200」が設定されている</br>
     * ②JsonResultのresultDtoは「OK」が設定されている</br>
     */
    @Test
    public void testBankbookPatternPreference() throws Exception {

        Mockito.when(signUpService.bankbookPatternPreference(Mockito.any(BankbookPatternPreferenceRequestDto.class)))
                .thenReturn("OK");

        // テストを呼び出す
        MvcResult result = mvc.perform(
                post("/sign-up/AB0120").accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON)
                        .content(asJsonString(new BankbookPatternPreferenceRequestDto())))
                .andReturn();

        String responseContent = result.getResponse().getContentAsString();

        JSONObject resultJson = new JSONObject(responseContent);

        // テスト結果
        assertEquals("200", resultJson.get("statusCode").toString());
        assertEquals("OK", resultJson.get("resultDto").toString());
    }

    /**
     * テストメソッド： cifBankBookLessSettingInfoAcquisition(/sign-up/AB0121)（正常系）</br>
     * 
     * テスト条件：</br>
     * ①なし</br>
     * 
     * テスト結果：</br>
     * ①JsonResultのstatusCodeは「200」が設定されている</br>
     * ②JsonResultの店名が正しく設定されている</br>
     * ③JsonResultの部店コードが正しく設定されている</br>
     */
    @Test
    public void testCifBankBookLessSettingInfoAcquisition() throws Exception {

        PassbookLessSettingInformationResponseDto dto = new PassbookLessSettingInformationResponseDto();
        dto.setBranchCode("0001");
        dto.setCifNumber("001");
        dto.setPassbookLessSettingStatus("01");
        dto.setRegisterFlg("0");
        List<PassbookLessSettingInformationResponseDto> dtoLIst = new ArrayList<>();
        dtoLIst.add(dto);
        Mockito.when(signUpService.getPassbookLessSettingInformation()).thenReturn(dtoLIst);

        // テストを呼び出す
        MvcResult result = mvc.perform(
                get("/sign-up/AB0121").accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON))
                .andReturn();

        String responseContent = result.getResponse().getContentAsString();

        JSONObject resultJson = new JSONObject(responseContent);

        // テスト結果
        assertEquals("200", resultJson.get("statusCode").toString());
        assertEquals("0001", resultJson.getJSONArray("resultDto").getJSONObject(0).get("branchCode"));
        assertEquals("001", resultJson.getJSONArray("resultDto").getJSONObject(0).get("cifNumber"));
        assertEquals("01", resultJson.getJSONArray("resultDto").getJSONObject(0).get("passbookLessSettingStatus"));
        assertEquals("0", resultJson.getJSONArray("resultDto").getJSONObject(0).get("registerFlg"));
    }

    /**
     * テストメソッド： bankBookLessPreference(/sign-up/AB0122)（正常系）</br>
     * 
     * テスト条件：</br>
     * ①なし</br>
     * 
     * テスト結果：</br>
     * ①JsonResultのstatusCodeは「200」が設定されている</br>
     * ②JsonResultのresultDtoは「OK」が設定されている</br>
     */
    @Test
    public void testBankBookLessPreference() throws Exception {

        Mockito.when(signUpService.bankBookLessPreference(Mockito.any(PassBookLessPreferenceRequestDto.class)))
                .thenReturn("OK");

        // テストを呼び出す
        MvcResult result = mvc.perform(post("/sign-up/AB0122").accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON).content(asJsonString(new PassBookLessPreferenceRequestDto())))
                .andReturn();

        String responseContent = result.getResponse().getContentAsString();

        JSONObject resultJson = new JSONObject(responseContent);

        // テスト結果
        assertEquals("200", resultJson.get("statusCode").toString());
        assertEquals("OK", resultJson.get("resultDto").toString());
    }

    /**
     * JSONへ変換する</br>
     * 
     * @param パラメータDTO
     * @return JSON
     */
    private static String asJsonString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}

# 城南信用金庫BFFAPI 
以下、各APIのcurlによるSTUB起動例です.
## 初回登録

## AB0112 部店照会.
````
curl -i -X GET \
	 http://docker-jsbank-bff-service-jsbank-bff.mycluster-jp-tok-1-430553-06f3cfc58a58986a2f2ce380e01e4d99-0000.jp-tok.containers.appdomain.cloud/sign-up/AB0112
	 -H "Content-type: application/json" \
	 -d @- <<EOF
header:{
	"transactionID":"20220124223001000-ec470830bc9c430d808aa0e0964b35ea",
	"applicationId":"JBA-Retail",
	"deviceId":"751379d32843460090a4905b742a0d0d",
	"userIdToken":"userId",
	"jbaIdToken":"jbaId",
	"accessToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"refreshToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"version":"1.0.1",
	"os":"ios",
	"screenID":"MBLG0101",
	"eventID":"E01"
}

Response:{
	
    [{"departmentStoreName","departmentStoreCode"}]
	
}

EOF
````

## AB0103 本人照合.
````
curl -i -X POST \
	 http://docker-jsbank-bff-service-jsbank-bff.mycluster-jp-tok-1-430553-06f3cfc58a58986a2f2ce380e01e4d99-0000.jp-tok.containers.appdomain.cloud/sign-up/AB0103
	 -H "Content-type: application/json" \
	 -d @- <<EOF
header:{
	"transactionID":"20220124223001000-ec470830bc9c430d808aa0e0964b35ea",
	"applicationId":"JBA-Retail",
	"deviceId":"751379d32843460090a4905b742a0d0d",
	"userIdToken":"userId",
	"jbaIdToken":"jbaId",
	"accessToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"refreshToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"version":"1.0.1",
	"os":"ios",
	"screenID":"MBLG0101",
	"eventID":"E01"
}
{
    "shopId":"1344",
    "accountNumber":"4167030",
    "kanaName":"ガガガ",
    "birthDay":"19940325",
    "postCode":"1750082",
    "cashCardPassword":"0325"
}

Response:{
	
    "jbaId":"c80746e14540425d8b1b982b0c2fa949",
	"userId":"751379d32843460090a4905b742a0d0d"
	
}
EOF
````

## AB0113 利用者属性更新.
````
curl -i -X POST \
	 http://docker-jsbank-bff-service-jsbank-bff.mycluster-jp-tok-1-430553-06f3cfc58a58986a2f2ce380e01e4d99-0000.jp-tok.containers.appdomain.cloud/sign-up/AB0113
	 -H "Content-type: application/json" \
	 -d @- <<EOF
header:{
	"transactionID":"20220124223001000-ec470830bc9c430d808aa0e0964b35ea",
	"applicationId":"JBA-Retail",
	"deviceId":"751379d32843460090a4905b742a0d0d",
	"userIdToken":"userId",
	"jbaIdToken":"jbaId",
	"accessToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"refreshToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"version":"1.0.1",
	"os":"ios",
	"screenID":"MBLG0101",
	"eventID":"E01"
}
Response:{
	
    "result":"ok"
	
}
EOF
````

## AB0101 メールアドレス登録.
````
curl -i -X POST \
	 http://docker-jsbank-bff-service-jsbank-bff.mycluster-jp-tok-1-430553-06f3cfc58a58986a2f2ce380e01e4d99-0000.jp-tok.containers.appdomain.cloud/sign-up/AB0101
	 -H "Content-type: application/json" \
	 -d @- <<EOF
header:{
	"transactionID":"20220124223001000-ec470830bc9c430d808aa0e0964b35ea",
	"applicationId":"JBA-Retail",
	"deviceId":"751379d32843460090a4905b742a0d0d",
	"userIdToken":"userId",
	"jbaIdToken":"jbaId",
	"accessToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"refreshToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"version":"1.0.1",
	"os":"ios",
	"screenID":"MBLG0101",
	"eventID":"E01"
}
{
    "receptionNumber":"706249306",
 	"emailAddress":"122623777＠qq.com",
 	"processKubun":"01"
}
Response:{
	
    "result":"ok"
	
}
EOF
````

## AB0102 メールアドレス認証.
````
curl -i -X POST \
	 http://docker-jsbank-bff-service-jsbank-bff.mycluster-jp-tok-1-430553-06f3cfc58a58986a2f2ce380e01e4d99-0000.jp-tok.containers.appdomain.cloud/sign-up/AB0102
	 -H "Content-type: application/json" \
	 -d @- <<EOF
header:{
	"transactionID":"20220124223001000-ec470830bc9c430d808aa0e0964b35ea",
	"applicationId":"JBA-Retail",
	"deviceId":"751379d32843460090a4905b742a0d0d",
	"userIdToken":"userId",
	"jbaIdToken":"jbaId",
	"accessToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"refreshToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"version":"1.0.1",
	"os":"ios",
	"screenID":"MBLG0101",
	"eventID":"E01"
}
{
	"receptionNumber":"706249306",
	"personalityKubun":"02",
	"otp":"ab011",
	"screenID":"MBLG0101"
}
Response:{
	
    "result":"ok"
	
}
EOF
````

## AB0105 IVR送信.
````
curl -i -X POST \
	 http://docker-jsbank-bff-service-jsbank-bff.mycluster-jp-tok-1-430553-06f3cfc58a58986a2f2ce380e01e4d99-0000.jp-tok.containers.appdomain.cloud/sign-up/AB0105
	 -H "Content-type: application/json" \
	 -d @- <<EOF
header:{
	"transactionID":"20220124223001000-ec470830bc9c430d808aa0e0964b35ea",
	"applicationId":"JBA-Retail",
	"deviceId":"751379d32843460090a4905b742a0d0d",
	"userIdToken":"userId",
	"jbaIdToken":"jbaId",
	"accessToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"refreshToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"version":"1.0.1",
	"os":"ios",
	"screenID":"MBLG0101",
	"eventID":"E01"
}
{
    "phoneNumber": "18842543062"
}
Response:{
	
    "result":"ok"
	
}
EOF
````

## AB0106 IVR認証.
````
curl -i -X POST \
	 http://docker-jsbank-bff-service-jsbank-bff.mycluster-jp-tok-1-430553-06f3cfc58a58986a2f2ce380e01e4d99-0000.jp-tok.containers.appdomain.cloud/sign-up/AB0106
	 -H "Content-type: application/json" \
	 -d @- <<EOF
header:{
	"transactionID":"20220124223001000-ec470830bc9c430d808aa0e0964b35ea",
	"applicationId":"JBA-Retail",
	"deviceId":"751379d32843460090a4905b742a0d0d",
	"userIdToken":"userId",
	"jbaIdToken":"jbaId",
	"accessToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"refreshToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"version":"1.0.1",
	"os":"ios",
	"screenID":"MBLG0101",
	"eventID":"E01"
}
{
	"otp":"ab011",
}
Response:{
	
    "result":"ok"
	
}
EOF
````

## AB0119 プッシュ通知登録.
````
curl -i -X POST \
	 http://docker-jsbank-bff-service-jsbank-bff.mycluster-jp-tok-1-430553-06f3cfc58a58986a2f2ce380e01e4d99-0000.jp-tok.containers.appdomain.cloud/sign-up/AB0119
	 -H "Content-type: application/json" \
	 -d @- <<EOF
header:{
	"transactionID":"20220124223001000-ec470830bc9c430d808aa0e0964b35ea",
	"applicationId":"JBA-Retail",
	"deviceId":"751379d32843460090a4905b742a0d0d",
	"userIdToken":"userId",
	"jbaIdToken":"jbaId",
	"accessToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"refreshToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"version":"1.0.1",
	"os":"ios",
	"screenID":"MBLG0101",
	"eventID":"E01"
}
{
	"osType":"02"
	"deviceToken":01

}
Response:{
	
    "result":"ok"
	
}
EOF
````

## AB0120 通帳パターン設定.
````
curl -i -X POST \
	 http://docker-jsbank-bff-service-jsbank-bff.mycluster-jp-tok-1-430553-06f3cfc58a58986a2f2ce380e01e4d99-0000.jp-tok.containers.appdomain.cloud/sign-up/AB0120
	 -H "Content-type: application/json" \
	 -d @- <<EOF
header:{
	"transactionID":"20220124223001000-ec470830bc9c430d808aa0e0964b35ea",
	"applicationId":"JBA-Retail",
	"deviceId":"751379d32843460090a4905b742a0d0d",
	"userIdToken":"userId",
	"jbaIdToken":"jbaId",
	"accessToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"refreshToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"version":"1.0.1",
	"os":"ios",
	"screenID":"MBLG0101",
	"eventID":"E01"
}
{
	"bankbookPattern":"111",
	"userId":"c80746e14540425d8b1b982b0c2fa949"

}
Response:{
	
    "result":"ok"
	
}
EOF
````

## AB0121 CIF毎の通帳レス設定情報取得.
````
curl -i -X POST \
	 http://docker-jsbank-bff-service-jsbank-bff.mycluster-jp-tok-1-430553-06f3cfc58a58986a2f2ce380e01e4d99-0000.jp-tok.containers.appdomain.cloud/sign-up/AB0121
	 -H "Content-type: application/json" \
	 -d @- <<EOF
header:{
	"transactionID":"20220124223001000-ec470830bc9c430d808aa0e0964b35ea",
	"applicationId":"JBA-Retail",
	"deviceId":"751379d32843460090a4905b742a0d0d",
	"userIdToken":"userId",
	"jbaIdToken":"jbaId",
	"accessToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"refreshToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"version":"1.0.1",
	"os":"ios",
	"screenID":"MBLG0101",
	"eventID":"E01"

}

{
		"jbaId":"c80746e14540425d8b1b982b0c2fa949"

}


Response:{

    {
    "statusCode": 200,
    "resultDto": {
        "transactionID": "0325",
        "transactionSeqNo": "HGVQBVBBVJABVOIUQHOVBQIUGVIQBVIAUO",
        "traceID": "0256",
        "routingInfo": "jhcvuVCBAVBIGIbcuVIALVNJKAVUAVNCKABJV"
    }
}
	
}
EOF
````

## AB0122 CIF毎の通帳レス設定情報取得.
````
curl -i -X POST \
	 http://docker-jsbank-bff-service-jsbank-bff.mycluster-jp-tok-1-430553-06f3cfc58a58986a2f2ce380e01e4d99-0000.jp-tok.containers.appdomain.cloud/sign-up/AB0122
	 -H "Content-type: application/json" \
	 -d @- <<EOF
header:{
	"transactionID":"20220124223001000-ec470830bc9c430d808aa0e0964b35ea",
	"applicationId":"JBA-Retail",
	"deviceId":"751379d32843460090a4905b742a0d0d",
	"userIdToken":"userId",
	"jbaIdToken":"jbaId",
	"accessToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"refreshToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"version":"1.0.1",
	"os":"ios",
	"screenID":"MBLG0101",
	"eventID":"E01"

}
{
		"cifNumber":"c80746e14540425d8b1b982b0c2fa949"

}
Response:{
	
    "result":"ok"
	
}
EOF
````




## 電子通帳

## AB0401 口座一覧と各口座の残高情報取得.
````
curl -i -X GET \
	 http://docker-jsbank-bff-service-jsbank-bff.mycluster-jp-tok-1-430553-06f3cfc58a58986a2f2ce380e01e4d99-0000.jp-tok.containers.appdomain.cloud/e-passbook/AB0401
	 -H "Content-type: application/json" \
	 -d @- <<EOF
header:{
	"transactionID":"20220124223001000-ec470830bc9c430d808aa0e0964b35ea",
	"applicationId":"JBA-Retail",
	"deviceId":"751379d32843460090a4905b742a0d0d",
	"userIdToken":"userId",
	"jbaIdToken":"jbaId",
	"accessToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"refreshToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"version":"1.0.1",
	"os":"ios",
	"screenID":"MBLG0101",
	"eventID":"E01"
}
Response:{
    "code": 200,
    "data": {
        "balanceInfomationResponseDtoList": [
            {
                "storeNumber": "001",
                "branchName": "五反田",
                "subjectsCode": "01",
                "subjectsName": "普通預金",
                "bankAccountNumber": "123456",
                "balance": "10000"
            }
        ],
        "subjectTotalBalance": {
            "01": "10000"
        },
        "allAccountsTotalBalance": "10000"
    }	
}
EOF
````

## AB0402 入出金明細取得(流動性預金).
````
curl -i -X GET \
	 http://docker-jsbank-bff-service-jsbank-bff.mycluster-jp-tok-1-430553-06f3cfc58a58986a2f2ce380e01e4d99-0000.jp-tok.containers.appdomain.cloud/e-passbook/AB0402
	 -H "Content-type: application/json" \
	 -d @- <<EOF
header:{
	"transactionID":"20220124223001000-ec470830bc9c430d808aa0e0964b35ea",
	"applicationId":"JBA-Retail",
	"deviceId":"751379d32843460090a4905b742a0d0d",
	"userIdToken":"userId",
	"jbaIdToken":"jbaId",
	"accessToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"refreshToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"version":"1.0.1",
	"os":"ios",
	"screenID":"MBLG0101",
	"eventID":"E01"
}
{
	"accountNumber":"706249306",
	"dateOfInquiryFrom":"19940721",
	"dateOfInquiryTo":"20220721"
}
Response:{
    "code": 200,
    "data": [
        {
            "amountType": "01",
            "balance": "10,000",
            "billNumber": "12345",
            "branchNumber": "001",
            "depositAmount": "20,000",
            "detailId": "0000001",
            "handling": "取扱",
            "memo": "TestTestTestTestTest",
            "transactionDate": "2022/03/14",
            "transactionSymbol": "123456",
            "typePartner": "typePartner",
            "withdrawalAmount": "30,000"
        },
        {
            "amountType": "02",
            "balance": "10,000",
            "billNumber": "12345",
            "branchNumber": "001",
            "depositAmount": "20,000",
            "detailId": "0000001",
            "handling": "取扱",
            "memo": "TestTestTestTestTest",
            "transactionDate": "2022/03/14",
            "transactionSymbol": "123456",
            "typePartner": "typePartner",
            "withdrawalAmount": "30,000"
        }
    ]
}
EOF
````

## AB0403 定期預金明細取得.
````
curl -i -X GET \
	 http://docker-jsbank-bff-service-jsbank-bff.mycluster-jp-tok-1-430553-06f3cfc58a58986a2f2ce380e01e4d99-0000.jp-tok.containers.appdomain.cloud/e-passbook/AB0403
	 -H "Content-type: application/json" \
	 -d @- <<EOF
header:{
	"transactionID":"20220124223001000-ec470830bc9c430d808aa0e0964b35ea",
	"applicationId":"JBA-Retail",
	"deviceId":"751379d32843460090a4905b742a0d0d",
	"userIdToken":"userId",
	"jbaIdToken":"jbaId",
	"accessToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"refreshToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"version":"1.0.1",
	"os":"ios",
	"screenID":"MBLG0101",
	"eventID":"E01"
}
{
	"accountNumber":"117062493061"
}
Response:{
    "code": 200,
    "data": [
        {
            "amountOfUse": "10,000",
            "depositAmount": "20,000",
            "detailId": "1000001",
            "handlingOfInterestAndPrizeMoney": "30,000",
            "interestAccountNumber": "2001",
            "interestAccountType": "科目",
            "interestRate": "30%",
            "lotteryDate": "2022/03/08",
            "lotteryNumber": "00001",
            "lotteryResult": "結果",
            "maruReportLimit": "500,000",
            "maturityDate": "2022/03/09",
            "moreLotteryInfomation": "抽選補足情報",
            "periodCodeValue": "期間（文言）",
            "principal": "40,000",
            "raisedTimes": "1",
            "taxClass": "02",
            "typeCodeValue": "種類（文言）",
            "inquiryDate": "2022/03/21",
            "amount": "10000",
            "ledgerBalance": "50000",
            "intermediateInterestPaymentDate": "2022/03/22",
            "intermediateInterestTate": "2022/03/23",
            "memo": "メモ"
        }
    ]
}
EOF
````

## AB0404 定期積金明細取得.
````
curl -i -X GET \
	 http://docker-jsbank-bff-service-jsbank-bff.mycluster-jp-tok-1-430553-06f3cfc58a58986a2f2ce380e01e4d99-0000.jp-tok.containers.appdomain.cloud/e-passbook/AB0404
	 -H "Content-type: application/json" \
	 -d @- <<EOF
header:{
	"transactionID":"20220124223001000-ec470830bc9c430d808aa0e0964b35ea",
	"applicationId":"JBA-Retail",
	"deviceId":"751379d32843460090a4905b742a0d0d",
	"userIdToken":"userId",
	"jbaIdToken":"jbaId",
	"accessToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"refreshToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"version":"1.0.1",
	"os":"ios",
	"screenID":"MBLG0101",
	"eventID":"E01"
}
{
	"accountNumber":"117062493061"
}
Response:{
    "code": 200,
    "data": [
        {
            "annualYield": "2",
            "contractDate": "2022/03/13",
            "contractPeriod": "2022/03/14",
            "dreamFlag": "01",
            "maturityDate": "2022/03/15",
            "monthlyPremium": "10,000",
            "paymentContractAmount": "20,000",
            "paymentDay": "2022/03/16",
            "payupAmount": "30,000",
            "principal": "30,001",
            "taxClass": "03",
            "termDepositStatus": "04",
            "totalPremium": "40,001"
        }
    ]
}
EOF
````

## AB0405 通知預金明細取得.
````
curl -i -X GET \
	 http://docker-jsbank-bff-service-jsbank-bff.mycluster-jp-tok-1-430553-06f3cfc58a58986a2f2ce380e01e4d99-0000.jp-tok.containers.appdomain.cloud/e-passbook/AB0405
	 -H "Content-type: application/json" \
	 -d @- <<EOF
header:{
	"transactionID":"20220124223001000-ec470830bc9c430d808aa0e0964b35ea",
	"applicationId":"JBA-Retail",
	"deviceId":"751379d32843460090a4905b742a0d0d",
	"userIdToken":"userId",
	"jbaIdToken":"jbaId",
	"accessToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"refreshToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"version":"1.0.1",
	"os":"ios",
	"screenID":"MBLG0101",
	"eventID":"E01"
}
{
	"accountNumber":"117062493061"
}
Response:{
    "code": 200,
    "data": [
        {
            "acceptanceDate": "2022/03/14",
            "defermentPeriod": "期間",
            "detailId": "00000001",
            "interest": "20%",
            "taxClass": "03",
            "termDepositDate": "2022/03/15"
        }
    ]
}
EOF
````

## AB0406 概要欄メモ登録.
````
curl -i -X POST \
	 http://docker-jsbank-bff-service-jsbank-bff.mycluster-jp-tok-1-430553-06f3cfc58a58986a2f2ce380e01e4d99-0000.jp-tok.containers.appdomain.cloud/e-passbook/AB0406
	 -H "Content-type: application/json" \
	 -d @- <<EOF
header:{
	"transactionID":"20220124223001000-ec470830bc9c430d808aa0e0964b35ea",
	"applicationId":"JBA-Retail",
	"deviceId":"751379d32843460090a4905b742a0d0d",
	"userIdToken":"userId",
	"jbaIdToken":"jbaId",
	"accessToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"refreshToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"version":"1.0.1",
	"os":"ios",
	"screenID":"MBLG0101",
	"eventID":"E01"
}
{
	"memo":"がさんの転送",
	"transactionDetailNo":"20220124223001000-ec470830bc9c430d909aa0e0964b35ea"
}
Response:{
	
    "result":"ok"
	
}
EOF
````

## AB0407 収支グラフ表示値取得.
````
curl -i -X POST \
	 http://docker-jsbank-bff-service-jsbank-bff.mycluster-jp-tok-1-430553-06f3cfc58a58986a2f2ce380e01e4d99-0000.jp-tok.containers.appdomain.cloud/e-passbook/AB0407
	 -H "Content-type: application/json" \
	 -d @- <<EOF
header:{
	"transactionID":"20220124223001000-ec470830bc9c430d808aa0e0964b35ea",
	"applicationId":"JBA-Retail",
	"deviceId":"751379d32843460090a4905b742a0d0d",
	"userIdToken":"userId",
	"jbaIdToken":"jbaId",
	"accessToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"refreshToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"version":"1.0.1",
	"os":"ios",
	"screenID":"MBLG0101",
	"eventID":"E01"
}
{
	"accountNumber":"117062493061"

}
Response:{
    "code": 200,
    "data": [
        {
            "balanceMonth": "2022/03/14",
            "depositAmount": "10,000",
            "investedAmount": "20,000"
        }
    ]
}
EOF
````




## 口座開設

## AB0701 復元処理.
````
curl -i -X GET \
	 http://docker-jsbank-bff-service-jsbank-bff.mycluster-jp-tok-1-430553-06f3cfc58a58986a2f2ce380e01e4d99-0000.jp-tok.containers.appdomain.cloud/account-opening/AB0701
	 -H "Content-type: application/json" \
	 -d @- <<EOF
header:{
	"transactionID":"20220124223001000-ec470830bc9c430d808aa0e0964b35ea",
	"applicationId":"JBA-Retail",
	"deviceId":"751379d32843460090a4905b742a0d0d",
	"userIdToken":"userId",
	"jbaIdToken":"jbaId",
	"accessToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"refreshToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"version":"1.0.1",
	"os":"ios",
	"screenID":"MBLG0101",
	"eventID":"E01"
}
{
	"accountNumber":"117062493061"

}
Response:{
    "statusCode": 200,
    "resultDto": {
        "screenId": "page0001",
        "personType": "8",
        "individual": {
            "receiptNumber": "0001",
            "customerId": "123000",
            "cifNumber": "01",
            "personType": "8",
            "applyStatus": "01",
            "applyStartDateTime": "2022/03/17",
            "applyValidDateTime": "2055/01/01",
            "useSuspendFlag": "1",
            "transactionType": "01",
            "nameKanaLast": "ハニュ",
            "nameKannFirst": "ユヅル",
            "nameKanjiLast": "羽生",
            "nameKanjiFirst": "結弦",
            "birthday": "1980/09/12",
            "gender": "01",
            "homeZipCode": "100-12345",
            "homeStateKana": "トウキョウト",
            "homeState": "東京都",
            "homeCityKana": "カブキチョウ",
            "homeCity": "歌舞伎町",
            "homeStreetKana": "タカシマダイラニチョウメ２６",
            "homeStreet": "高島平二丁目２６",
            "homeAddressKana": "２６バン",
            "homeAddress": "26番",
            "homeBuildingKana": "５－８１０号室",
            "homeBuilding": "５－８１０号室",
            "districtCode": "119",
            "districtCodeBranchNumber": "01",
            "districtCodeAddress": "26番",
            "addressKanji": "高島平二丁目２６",
            "addressKana": "タカシマダイラニチョウメ２６",
            "phoneType1": "01",
            "homePhone1Top": "011",
            "homePhone1Middle": "2345",
            "homePhone1Bottom": "7890",
            "phoneType2": "02",
            "homePhone2Top": "090",
            "homePhone2Middle": "1234",
            "homePhone2Bottom": "5678",
            "transactPurpose": "01",
            "transactPurposeOther": "02",
            "occupation": "01",
            "occupationOther": "02",
            "wpNameKana": "KIMO",
            "wpName": "気持ち",
            "wpZipCode": "100-1234",
            "wpStateKana": "タカシマダイラニチョウメ２６",
            "wpState": "高島平二丁目２６",
            "wpCityKana": "カブキチョウ",
            "wpCity": "歌舞伎町",
            "wpStreetKana": "タカシマダイラニチョウメ２６",
            "wpStreet": "高島平二丁目２６",
            "wpAddressKana": "２６バン",
            "wpAddress": "２６番",
            "wpBuildingKana": "２－１２－２",
            "wpBuilding": "２－１２－２",
            "wpPhoneType": "01",
            "wpPhoneTop": "100",
            "wpPhoneMiddle": "2345",
            "wpPhoneBottom": "6789",
            "transactionTrigger": "01",
            "accountType": "01",
            "fixedDepositAccountNumber": "0012",
            "openBranchCode": "02",
            "emailAddress": "testData@test.com",
            "ekycResult": "OK",
            "identityDocuments": null
        },
        "corporation": null,
        "soleProprietor": null
    }
}
EOF
````

## AB0702 ICOSへ本人確認書類格納.
````
curl -i -X PUT \
	 http://docker-jsbank-bff-service-jsbank-bff.mycluster-jp-tok-1-430553-06f3cfc58a58986a2f2ce380e01e4d99-0000.jp-tok.containers.appdomain.cloud/account-opening/AB0702
	 -H "Content-type: application/json" \
	 -d @- <<EOF
header:{
	"transactionID":"20220124223001000-ec470830bc9c430d808aa0e0964b35ea",
	"applicationId":"JBA-Retail",
	"deviceId":"751379d32843460090a4905b742a0d0d",
	"userIdToken":"userId",
	"jbaIdToken":"jbaId",
	"accessToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"refreshToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"version":"1.0.1",
	"os":"ios",
	"screenID":"MBLG0101",
	"eventID":"E01"
}
{
	"personType":"8",
	"receiptNumber":"MBLG0101",
	"fileStreams":[{"documentsType":"1"},{"fileName":"AB07"},{"fileStream":"AB017"}]
	"individual"{
　　　　　　　　　　"nameKanjiLast":"賀",
　　　　　　　　　　"nameKanjiFirst":"志懐",
　　　　　　　　　　"birthday":"19940101",
　　　　　　　　　　"addressKanji":"東京都"
	　　　}
}
Response:{
	"statusCode": 200,
    "result":"ok"
	
}
EOF
````

## AB0703 お勤め先情報入力
````
curl -i -X POST \
	 http://docker-jsbank-bff-service-jsbank-bff.mycluster-jp-tok-1-430553-06f3cfc58a58986a2f2ce380e01e4d99-0000.jp-tok.containers.appdomain.cloud/account-opening/AB0703
	 -H "Content-type: application/json" \
	 -d @- <<EOF
header:{
	"transactionID":"20220124223001000-ec470830bc9c430d808aa0e0964b35ea",
	"applicationId":"JBA-Retail",
	"deviceId":"751379d32843460090a4905b742a0d0d",
	"userIdToken":"userId",
	"jbaIdToken":"jbaId",
	"accessToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"refreshToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"version":"1.0.1",
	"os":"ios",
	"screenID":"MBLG0101",
	"eventID":"E01"
}
{
	"personType":"8",
	"receiptNumber":"MBLG0101",
	"accountType":"1",
	"fixedAccountNumber":"1144524785",
	"regularAccountNumber":"88548548965896",
	"AccountOpeningApplicationIndividualInfoDto":"",
	"AccountOpeningApplicationCorporationInfoDto":"",
	"AccountOpeningApplicationBusinessOwnerInfoDto":""

}
Response:{
	
    "result":"ok"
	
}
EOF
````

## AB0704 学校情報入力
````
curl -i -X POST \
	 http://docker-jsbank-bff-service-jsbank-bff.mycluster-jp-tok-1-430553-06f3cfc58a58986a2f2ce380e01e4d99-0000.jp-tok.containers.appdomain.cloud/account-opening/AB0704
	 -H "Content-type: application/json" \
	 -d @- <<EOF
header:{
	"transactionID":"20220124223001000-ec470830bc9c430d808aa0e0964b35ea",
	"applicationId":"JBA-Retail",
	"deviceId":"751379d32843460090a4905b742a0d0d",
	"userIdToken":"userId",
	"jbaIdToken":"jbaId",
	"accessToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"refreshToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"version":"1.0.1",
	"os":"ios",
	"screenID":"MBLG0101",
	"eventID":"E01"
}
{
	"personType":"8",
	"receiptNumber":"MBLG0101",
	"accountType":"1",
	"fixedAccountNumber":"1144524785",
	"regularAccountNumber":"88548548965896",
	"AccountOpeningApplicationIndividualInfoDto":"",
	"AccountOpeningApplicationCorporationInfoDto":"",
	"AccountOpeningApplicationBusinessOwnerInfoDto":""

}
Response:{
	
    "result":"ok"
	
}
EOF
````

## AB0705 口座開設申込内容照会（個人）.
````
curl -i -X GET \
	 http://docker-jsbank-bff-service-jsbank-bff.mycluster-jp-tok-1-430553-06f3cfc58a58986a2f2ce380e01e4d99-0000.jp-tok.containers.appdomain.cloud/account-opening/AB0705
	 -H "Content-type: application/json" \
	 -d @- <<EOF
header:{
	"transactionID":"20220124223001000-ec470830bc9c430d808aa0e0964b35ea",
	"applicationId":"JBA-Retail",
	"deviceId":"751379d32843460090a4905b742a0d0d",
	"userIdToken":"userId",
	"jbaIdToken":"jbaId",
	"accessToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"refreshToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"version":"1.0.1",
	"os":"ios",
	"screenID":"MBLG0101",
	"eventID":"E01"
}
{
	"receiptNumber":"117062493061",
	"personType":"02"

}
Response:{
    "statusCode": 200,
    "resultDto": {
        "receiptNumber": null,
        "customerId": null,
        "cifNumber": null,
        "personType": null,
        "applyStatus": null,
        "applyStartDateTime": null,
        "applyValidDateTime": null,
        "useSuspendFlag": null,
        "transactionType": null,
        "nameKanaLast": null,
        "nameKannFirst": null,
        "nameKanjiLast": null,
        "nameKanjiFirst": null,
        "birthday": null,
        "gender": null,
        "homeZipCode": null,
        "homeStateKana": null,
        "homeState": null,
        "homeCityKana": null,
        "homeCity": null,
        "homeStreetKana": null,
        "homeStreet": null,
        "homeAddressKana": null,
        "homeAddress": null,
        "homeBuildingKana": null,
        "homeBuilding": null,
        "districtCode": null,
        "districtCodeBranchNumber": null,
        "districtCodeAddress": null,
        "addressKanji": null,
        "addressKana": null,
        "phoneType1": null,
        "homePhone1Top": null,
        "homePhone1Middle": null,
        "homePhone1Bottom": null,
        "phoneType2": null,
        "homePhone2Top": null,
        "homePhone2Middle": null,
        "homePhone2Bottom": null,
        "transactPurpose": null,
        "transactPurposeOther": null,
        "occupation": null,
        "occupationOther": null,
        "wpNameKana": null,
        "wpName": null,
        "wpZipCode": null,
        "wpStateKana": null,
        "wpState": null,
        "wpCityKana": null,
        "wpCity": null,
        "wpStreetKana": null,
        "wpStreet": null,
        "wpAddressKana": null,
        "wpAddress": null,
        "wpBuildingKana": null,
        "wpBuilding": null,
        "wpPhoneType": null,
        "wpPhoneTop": null,
        "wpPhoneMiddle": null,
        "wpPhoneBottom": null,
        "transactionTrigger": null,
        "accountType": null,
        "fixedDepositAccountNumber": null,
        "openBranchCode": null,
        "emailAddress": null,
        "ekycResult": null,
        "identityDocuments": null
    }
}
EOF
````

## AB0706 お客様情報入力.
````
curl -i -X POST \
	 http://docker-jsbank-bff-service-jsbank-bff.mycluster-jp-tok-1-430553-06f3cfc58a58986a2f2ce380e01e4d99-0000.jp-tok.containers.appdomain.cloud/account-opening/AB0706
	 -H "Content-type: application/json" \
	 -d @- <<EOF
header:{
	"transactionID":"20220124223001000-ec470830bc9c430d808aa0e0964b35ea",
	"applicationId":"JBA-Retail",
	"deviceId":"751379d32843460090a4905b742a0d0d",
	"userIdToken":"userId",
	"jbaIdToken":"jbaId",
	"accessToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"refreshToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"version":"1.0.1",
	"os":"ios",
	"screenID":"MBLG0101",
	"eventID":"E01"
}
{
	"personType":"8",
	"pageId":"MBLG0101"
	"receiptNumber":"117062493061",
	"AccountOpeningApplicationIndividualInfoDto ":"",
    "AccountOpeningApplicationCorporationInfoDto  ":"",
    "AccountOpeningApplicationBusinessOwnerInfoDto  ":""
}
Response:{
	
    "result":"ok"
	
}
EOF
````

## AB0707 お勤め先情報入力.
````
curl -i -X POST \
	 http://docker-jsbank-bff-service-jsbank-bff.mycluster-jp-tok-1-430553-06f3cfc58a58986a2f2ce380e01e4d99-0000.jp-tok.containers.appdomain.cloud/account-opening/AB0707
	 -H "Content-type: application/json" \
	 -d @- <<EOF
header:{
	"transactionID":"20220124223001000-ec470830bc9c430d808aa0e0964b35ea",
	"applicationId":"JBA-Retail",
	"deviceId":"751379d32843460090a4905b742a0d0d",
	"userIdToken":"userId",
	"jbaIdToken":"jbaId",
	"accessToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"refreshToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"version":"1.0.1",
	"os":"ios",
	"screenID":"MBLG0101",
	"eventID":"E01"
}
{
	"personType":"8",
	"screenId":"MBLG0101",
	"receiptNumber":"117062493061",
	"accountType":"1",
	"regularAccountNumber":"117333493061",
	"fixedAccountNumber":"117062654061",
	"AccountOpeningApplicationIndividualInfoDto ":"",
    "AccountOpeningApplicationCorporationInfoDto  ":"",
    "AccountOpeningApplicationBusinessOwnerInfoDto  ":""
}
Response:{
	
    "result":"ok"
	
}
EOF
````

## AB0708 営業地区部店一覧照会.
````
curl -i -X GET \
	 http://docker-jsbank-bff-service-jsbank-bff.mycluster-jp-tok-1-430553-06f3cfc58a58986a2f2ce380e01e4d99-0000.jp-tok.containers.appdomain.cloud/account-opening/AB0708
	 -H "Content-type: application/json" \
	 -d @- <<EOF
header:{
	"transactionID":"20220124223001000-ec470830bc9c430d808aa0e0964b35ea",
	"applicationId":"JBA-Retail",
	"deviceId":"751379d32843460090a4905b742a0d0d",
	"userIdToken":"userId",
	"jbaIdToken":"jbaId",
	"accessToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"refreshToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"version":"1.0.1",
	"os":"ios",
	"screenID":"MBLG0101",
	"eventID":"E01"
}
{
	"personType":"8",
	"processType":"02",
	"receiptNumber":"117062493061",
}
Response:{
    "statusCode": 200,
    "resultDto": [
        {
            "branchCode": "001",
            "priorityFlag": "0",
            "momentumFlag": "1",
            "branchKanjiName": "五反田",
            "branchKanaName": "ｺﾞﾊﾝ",
            "branchZipCode": "1234-5678",
            "branchState": "東京都",
            "branchCity": "歌舞伎町",
            "branchStreet": "高島平二丁目２６",
            "branchAddress": "26番",
            "branchBuilding": "５－８１０号室"
        }
    ]
}
EOF
````

## AB0709 希望店設定.
````
curl -i -X GET \
	 http://docker-jsbank-bff-service-jsbank-bff.mycluster-jp-tok-1-430553-06f3cfc58a58986a2f2ce380e01e4d99-0000.jp-tok.containers.appdomain.cloud/account-opening/AB0709
	 -H "Content-type: application/json" \
	 -d @- <<EOF
header:{
	"transactionID":"20220124223001000-ec470830bc9c430d808aa0e0964b35ea",
	"applicationId":"JBA-Retail",
	"deviceId":"751379d32843460090a4905b742a0d0d",
	"userIdToken":"userId",
	"jbaIdToken":"jbaId",
	"accessToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"refreshToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"version":"1.0.1",
	"os":"ios",
	"screenID":"MBLG0101",
	"eventID":"E01"
}
{
	"personType":"8",
	"hopeDepartmentStore":"02",
	"receiptNumber":"117062493061",
	"screenID":"MBLG0101"
}
Response:{
	
    "result":"ok"
	
}
EOF
````

## AB0710 郵便番号の自動検索.
````
curl -i -X POST \
	 http://docker-jsbank-bff-service-jsbank-bff.mycluster-jp-tok-1-430553-06f3cfc58a58986a2f2ce380e01e4d99-0000.jp-tok.containers.appdomain.cloud/account-opening/AB0710
	 -H "Content-type: application/json" \
	 -d @- <<EOF
header:{
	"transactionID":"20220124223001000-ec470830bc9c430d808aa0e0964b35ea",
	"applicationId":"JBA-Retail",
	"deviceId":"751379d32843460090a4905b742a0d0d",
	"userIdToken":"userId",
	"jbaIdToken":"jbaId",
	"accessToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"refreshToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"version":"1.0.1",
	"os":"ios",
	"screenID":"MBLG0101",
	"eventID":"E01"
}
{
	"postalCode":"100086023"

}
Response:{
    "statusCode": 200,
    "resultDto": {
        "prefectures": "東京都",
        "city": "品川区西五反田",
        "chome": "7",
        "prefecturesKana": "トウキョウ",
        "cityKana": "シナカワくニシゴタンダ",
        "chomeHalfwidth": "7"
    }
}
EOF
````

## AB0711 IBパスワード設定.
````
curl -i -X POST \
	 http://docker-jsbank-bff-service-jsbank-bff.mycluster-jp-tok-1-430553-06f3cfc58a58986a2f2ce380e01e4d99-0000.jp-tok.containers.appdomain.cloud/account-opening/AB0711
	 -H "Content-type: application/json" \
	 -d @- <<EOF
header:{
	"transactionID":"20220124223001000-ec470830bc9c430d808aa0e0964b35ea",
	"applicationId":"JBA-Retail",
	"deviceId":"751379d32843460090a4905b742a0d0d",
	"userIdToken":"userId",
	"jbaIdToken":"jbaId",
	"accessToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"refreshToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"version":"1.0.1",
	"os":"ios",
	"screenID":"MBLG0101",
	"eventID":"E01"
}
{
	"receptionNumber":"100086023",
	"ibPassword":"BGNBJK8921862164",
	"ccPassword":"XkqFhdPLyepGQ5QQEm7cVA==",
	"personalityKubun":"1"
}
Response:{

    {
    "statusCode": 200,
    "resultDto": {
        "ibPassword": "0143",
    }
}
}
EOF
````

## AB0712 メールアドレス登録.
````
curl -i -X POST \
	 http://docker-jsbank-bff-service-jsbank-bff.mycluster-jp-tok-1-430553-06f3cfc58a58986a2f2ce380e01e4d99-0000.jp-tok.containers.appdomain.cloud/account-opening/AB0712
	 -H "Content-type: application/json" \
	 -d @- <<EOF
header:{
	"transactionID":"20220124223001000-ec470830bc9c430d808aa0e0964b35ea",
	"applicationId":"JBA-Retail",
	"deviceId":"751379d32843460090a4905b742a0d0d",
	"userIdToken":"userId",
	"jbaIdToken":"jbaId",
	"accessToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"refreshToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"version":"1.0.1",
	"os":"ios",
	"screenID":"MBLG0101",
	"eventID":"E01"
}
{
	"receptionNumber":"10651990086023",
	"emailAddress":"東京都",
	"processKubun":"1"
}
Response:{
    "statusCode": 200,
    "resultDto": "OK"
}
EOF
````

## AB0713 メールアドレス認証.
````
curl -i -X POST \
	 http://docker-jsbank-bff-service-jsbank-bff.mycluster-jp-tok-1-430553-06f3cfc58a58986a2f2ce380e01e4d99-0000.jp-tok.containers.appdomain.cloud/account-opening/AB0713
	 -H "Content-type: application/json" \
	 -d @- <<EOF
header:{
	"transactionID":"20220124223001000-ec470830bc9c430d808aa0e0964b35ea",
	"applicationId":"JBA-Retail",
	"deviceId":"751379d32843460090a4905b742a0d0d",
	"userIdToken":"userId",
	"jbaIdToken":"jbaId",
	"accessToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"refreshToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"version":"1.0.1",
	"os":"ios",
	"screenID":"MBLG0101",
	"eventID":"E01"
}
{
	"receptionNumber":"10651990086023",
	"personType":"1",
	"otp":"CHBUCHQ5848",
	"verifyTRXKey":"KAJNCIBQIBICQBIVKJKJNIJ",
	"cifNumber":"119915179575"
}
Response:{
    "statusCode": 200,
    "resultDto": "OK"
}
EOF
````

## AB0714 IVR送信.
````
curl -i -X POST \
	 http://docker-jsbank-bff-service-jsbank-bff.mycluster-jp-tok-1-430553-06f3cfc58a58986a2f2ce380e01e4d99-0000.jp-tok.containers.appdomain.cloud/account-opening/AB0714
	 -H "Content-type: application/json" \
	 -d @- <<EOF
header:{
	"transactionID":"20220124223001000-ec470830bc9c430d808aa0e0964b35ea",
	"applicationId":"JBA-Retail",
	"deviceId":"751379d32843460090a4905b742a0d0d",
	"userIdToken":"userId",
	"jbaIdToken":"jbaId",
	"accessToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"refreshToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"version":"1.0.1",
	"os":"ios",
	"screenID":"MBLG0101",
	"eventID":"E01"
}
{
	"receptionNumber":"10651990086023",
	"phoneNumber":"18842514632"
}
Response:{
    "statusCode": 200,
    "resultDto": "OK"
}
EOF
````

## AB0715 IVR認証.
````
curl -i -X POST \
	 http://docker-jsbank-bff-service-jsbank-bff.mycluster-jp-tok-1-430553-06f3cfc58a58986a2f2ce380e01e4d99-0000.jp-tok.containers.appdomain.cloud/account-opening/AB0715
	 -H "Content-type: application/json" \
	 -d @- <<EOF
header:{
	"transactionID":"20220124223001000-ec470830bc9c430d808aa0e0964b35ea",
	"applicationId":"JBA-Retail",
	"deviceId":"751379d32843460090a4905b742a0d0d",
	"userIdToken":"userId",
	"jbaIdToken":"jbaId",
	"accessToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"refreshToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"version":"1.0.1",
	"os":"ios",
	"screenID":"MBLG0101",
	"eventID":"E01"
}
{
	"nameKanjiLast":"ガ",
	"nameKanjiFirst":"シカイ",
	"nameKanaLast":"賀",
	"nameKannFirst":"志懐",
	"birthday":"19940101",
	"zipCode":"1008006",
	"occupation":"先生",
	"occupationOther":"社会福祉法人",
	"transactPurposeOther":"加インタ",
	"transactPurpose":"書かかかかあか",
	"accountType":"01",
	"branchNumber":"0001",
	"accountNumber":"1234564865"
}
Response:{
    "statusCode": 200,
    "resultDto": "OK"
}
EOF
````

## AB0716 所在地情報保存.
````
curl -i -X POST \
	 http://docker-jsbank-bff-service-jsbank-bff.mycluster-jp-tok-1-430553-06f3cfc58a58986a2f2ce380e01e4d99-0000.jp-tok.containers.appdomain.cloud/account-opening/AB0716
	 -H "Content-type: application/json" \
	 -d @- <<EOF
header:{
	"transactionID":"20220124223001000-ec470830bc9c430d808aa0e0964b35ea",
	"applicationId":"JBA-Retail",
	"deviceId":"751379d32843460090a4905b742a0d0d",
	"userIdToken":"userId",
	"jbaIdToken":"jbaId",
	"accessToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"refreshToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"version":"1.0.1",
	"os":"ios",
	"screenID":"MBLG0101",
	"eventID":"E01"
}
{
	"otp":"VCSQJCJQCK61",
}
Response:{
    "statusCode": 200,
    "resultDto": "OK"
}
EOF
````

## AB0717 本店所在地情報保存.
````
curl -i -X POST \
	 http://docker-jsbank-bff-service-jsbank-bff.mycluster-jp-tok-1-430553-06f3cfc58a58986a2f2ce380e01e4d99-0000.jp-tok.containers.appdomain.cloud/account-opening/AB0717
	 -H "Content-type: application/json" \
	 -d @- <<EOF
header:{
	"transactionID":"20220124223001000-ec470830bc9c430d808aa0e0964b35ea",
	"applicationId":"JBA-Retail",
	"deviceId":"751379d32843460090a4905b742a0d0d",
	"userIdToken":"userId",
	"jbaIdToken":"jbaId",
	"accessToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"refreshToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"version":"1.0.1",
	"os":"ios",
	"screenID":"MBLG0101",
	"eventID":"E01"
}
{
	"otp":"VCSQJCJQCK61",
}
Response:{
    "statusCode": 200,
    "resultDto": "OK"
}
EOF
````

## AB0718 biz自宅情報保存.
````
curl -i -X POST \
	 http://docker-jsbank-bff-service-jsbank-bff.mycluster-jp-tok-1-430553-06f3cfc58a58986a2f2ce380e01e4d99-0000.jp-tok.containers.appdomain.cloud/account-opening/AB0718
	 -H "Content-type: application/json" \
	 -d @- <<EOF
header:{
	"transactionID":"20220124223001000-ec470830bc9c430d808aa0e0964b35ea",
	"applicationId":"JBA-Retail",
	"deviceId":"751379d32843460090a4905b742a0d0d",
	"userIdToken":"userId",
	"jbaIdToken":"jbaId",
	"accessToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"refreshToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"version":"1.0.1",
	"os":"ios",
	"screenID":"MBLG0101",
	"eventID":"E01"
}
{
	"otp":"VCSQJCJQCK61",
}
Response:{
    "statusCode": 200,
    "resultDto": "OK"
}
EOF
````

## AB0719 biz所在地情報保存.
````
curl -i -X POST \
	 http://docker-jsbank-bff-service-jsbank-bff.mycluster-jp-tok-1-430553-06f3cfc58a58986a2f2ce380e01e4d99-0000.jp-tok.containers.appdomain.cloud/account-opening/AB0719
	 -H "Content-type: application/json" \
	 -d @- <<EOF
header:{
	"transactionID":"20220124223001000-ec470830bc9c430d808aa0e0964b35ea",
	"applicationId":"JBA-Retail",
	"deviceId":"751379d32843460090a4905b742a0d0d",
	"userIdToken":"userId",
	"jbaIdToken":"jbaId",
	"accessToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"refreshToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"version":"1.0.1",
	"os":"ios",
	"screenID":"MBLG0101",
	"eventID":"E01"
}
{
	"otp":"VCSQJCJQCK61",
}
Response:{
    "statusCode": 200,
    "resultDto": "OK"
}
EOF
````

## キャッシュカード発行.

## AB0801 復元処理.
````
curl -i -X GET \
	 http://docker-jsbank-bff-service-jsbank-bff.mycluster-jp-tok-1-430553-06f3cfc58a58986a2f2ce380e01e4d99-0000.jp-tok.containers.appdomain.cloud/account-opening/AB0801
	 -H "Content-type: application/json" \
	 -d @- <<EOF
header:{
	"transactionID":"20220124223001000-ec470830bc9c430d808aa0e0964b35ea",
	"applicationId":"JBA-Retail",
	"deviceId":"751379d32843460090a4905b742a0d0d",
	"userIdToken":"userId",
	"jbaIdToken":"jbaId",
	"accessToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"refreshToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"version":"1.0.1",
	"os":"ios",
	"screenID":"MBLG0101",
	"eventID":"E01"
}
{

	"receiptNumber":"117062493061"
	
}
Response:{
    "statusCode": 200,
    "resultDto": {
        "screenId": "MBLG0101",
        "cccIssuingApplicationInformationDto": {
            "receiptNumber": "706249306",
            "customerId": "751379d32843460090a4905b742a0d0d",
            "userID": "c80746e14540425d8b1b982b0c2fa949",
            "cifNumber": "E01",
            "personalityFlag": "01",
            "applyStatus": "申込受付",
            "applyStartDateTime": "19940222",
            "applyValidDateTime": "20220522",
            "useSuspendFlag": "02",
            "transactionType": "01",
            "employeeKanaLast": "ガ",
            "employeeKanaFirst": "シカイ",
            "employeeKanjiLast": "賀",
            "employeeKanjiFirst": "志懐",
            "dateOfBirth": "20010911",
            "homeZipCode": "10086",
            "emailAddress": "12266485@qq.com",
            "branchCode": "02",
            "accountNumber": "7062466",
            "transactionPurpose": "あるるるるるるるるるるるるるるう",
            "transactPurposeOther": "なししししししししいっしっししししし",
            "occupation": "医師",
            "occupationOther": "先生",
            "cashcardType": "01",
            "ccPinCode": "198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
            "ekycResult": "ture",
            "identityDocumentsDtoList": null
        }
    }
}
EOF
````

## AB0803 CC暗証番号.
````
curl -i -X POST \
	 http://docker-jsbank-bff-service-jsbank-bff.mycluster-jp-tok-1-430553-06f3cfc58a58986a2f2ce380e01e4d99-0000.jp-tok.containers.appdomain.cloud/account-opening/AB0803
	 -H "Content-type: application/json" \
	 -d @- <<EOF
header:{
	"transactionID":"20220124223001000-ec470830bc9c430d808aa0e0964b35ea",
	"applicationId":"JBA-Retail",
	"deviceId":"751379d32843460090a4905b742a0d0d",
	"userIdToken":"userId",
	"jbaIdToken":"jbaId",
	"accessToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"refreshToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"version":"1.0.1",
	"os":"ios",
	"screenID":"MBLG0101",
	"eventID":"E01"
}
{

	"receiptNumber":"117062493061",
	"ccPassword":"IFUQBIQBHH0WJBWRON6549165199CVHAV",
	"customerId":"03325",
	"personalityKubun":"02",
	"screenId":"MBLG0101"
	
}
Response:{

    "identityDocumentsDtoList": null
    
}
EOF
````

## AB0805 カードデザイン選択.
````
curl -i -X POST \
	 http://docker-jsbank-bff-service-jsbank-bff.mycluster-jp-tok-1-430553-06f3cfc58a58986a2f2ce380e01e4d99-0000.jp-tok.containers.appdomain.cloud/account-opening/AB0805
	 -H "Content-type: application/json" \
	 -d @- <<EOF
header:{
	"transactionID":"20220124223001000-ec470830bc9c430d808aa0e0964b35ea",
	"applicationId":"JBA-Retail",
	"deviceId":"751379d32843460090a4905b742a0d0d",
	"userIdToken":"userId",
	"jbaIdToken":"jbaId",
	"accessToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"refreshToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"version":"1.0.1",
	"os":"ios",
	"screenID":"MBLG0101",
	"eventID":"E01"
}
{

	"receiptNumber":"117062493061",
	"customerId":"03325",
	"personalityKubun":"02",
	"designId":"02",
	"screenId":"MBLG0101"
	
}
Response:{

    {
    "statusCode": 200,
    "resultDto": null
}
}
EOF
````

## AB0806 CC発行依頼.
````
curl -i -X POST \
	 http://docker-jsbank-bff-service-jsbank-bff.mycluster-jp-tok-1-430553-06f3cfc58a58986a2f2ce380e01e4d99-0000.jp-tok.containers.appdomain.cloud/account-opening/AB0806
	 -H "Content-type: application/json" \
	 -d @- <<EOF
header:{
	"transactionID":"20220124223001000-ec470830bc9c430d808aa0e0964b35ea",
	"applicationId":"JBA-Retail",
	"deviceId":"751379d32843460090a4905b742a0d0d",
	"userIdToken":"userId",
	"jbaIdToken":"jbaId",
	"accessToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"refreshToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"version":"1.0.1",
	"os":"ios",
	"screenID":"MBLG0101",
	"eventID":"E01"
}
{

	"receiptNumber":"117062493061",
	"customerId":"03325",
	"applicationDate":"20220202",
	"personalityKubun":"02",
	"screenId":"MBLG0101"
	
}
Response:{

    {
    "statusCode": 200,
    "resultDto": null
}
}
EOF
````

## AB0807 メールアドレス認証.
````
curl -i -X POST \
	 http://docker-jsbank-bff-service-jsbank-bff.mycluster-jp-tok-1-430553-06f3cfc58a58986a2f2ce380e01e4d99-0000.jp-tok.containers.appdomain.cloud/account-opening/AB0807
	 -H "Content-type: application/json" \
	 -d @- <<EOF
header:{
	"transactionID":"20220124223001000-ec470830bc9c430d808aa0e0964b35ea",
	"applicationId":"JBA-Retail",
	"deviceId":"751379d32843460090a4905b742a0d0d",
	"userIdToken":"userId",
	"jbaIdToken":"jbaId",
	"accessToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"refreshToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"version":"1.0.1",
	"os":"ios",
	"screenID":"MBLG0101",
	"eventID":"E01"
}
{

	"receiptNumber":"117062493061",
	"personType":"1",
	"OTP":"20220202",
	"verifyTRXKey":"HBALKBafafFfavavKBAKBKB",
	"cifNumber":"1234564865"
	
}
Response:{

    {
    "statusCode": 200,
    "resultDto": null
}
}
EOF
````

## AB0808 IVR認証.
````
curl -i -X POST \
	 http://docker-jsbank-bff-service-jsbank-bff.mycluster-jp-tok-1-430553-06f3cfc58a58986a2f2ce380e01e4d99-0000.jp-tok.containers.appdomain.cloud/account-opening/AB0808
	 -H "Content-type: application/json" \
	 -d @- <<EOF
header:{
	"transactionID":"20220124223001000-ec470830bc9c430d808aa0e0964b35ea",
	"applicationId":"JBA-Retail",
	"deviceId":"751379d32843460090a4905b742a0d0d",
	"userIdToken":"userId",
	"jbaIdToken":"jbaId",
	"accessToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"refreshToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"version":"1.0.1",
	"os":"ios",
	"screenID":"MBLG0101",
	"eventID":"E01"
}
{

	"nameKanjiLast":"ガ",
	"nameKanjiFirst":"シカイ",
	"nameKanaLast":"賀",
	"nameKannFirst":"志懐",
	"birthday":"19940101",
	"zipCode":"1008006",
	"occupation":"先生",
	"occupationOther":"社会福祉法人",
	"transactPurposeOther":"加インタ",
	"transactPurpose":"書かかかかあか",
	"accountType":"01",
	"branchNumber":"0001",
	"accountNumber":"1234564865"
	
}
Response:{

    {
    "statusCode": 200,
    "resultDto": null
}
}
EOF
````

## AB0809 本人確認.
````
curl -i -X POST \
	 http://docker-jsbank-bff-service-jsbank-bff.mycluster-jp-tok-1-430553-06f3cfc58a58986a2f2ce380e01e4d99-0000.jp-tok.containers.appdomain.cloud/account-opening/AB0809
	 -H "Content-type: application/json" \
	 -d @- <<EOF
header:{
	"transactionID":"20220124223001000-ec470830bc9c430d808aa0e0964b35ea",
	"applicationId":"JBA-Retail",
	"deviceId":"751379d32843460090a4905b742a0d0d",
	"userIdToken":"userId",
	"jbaIdToken":"jbaId",
	"accessToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"refreshToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"version":"1.0.1",
	"os":"ios",
	"screenID":"MBLG0101",
	"eventID":"E01"
}
{

	"nameKanjiLast":"ガ",
	"nameKanjiFirst":"シカイ",
	"nameKanaLast":"賀",
	"nameKannFirst":"志懐",
	"birthday":"19940101",
	"zipCode":"1008006",
	"occupation":"先生",
	"occupationOther":"社会福祉法人",
	"transactPurposeOther":"加インタ",
	"transactPurpose":"書かかかかあか",
	"accountType":"01",
	"branchNumber":"0001",
	"accountNumber":"1234564865"
	
}
Response:{

    {
    "statusCode": 200,
    "resultDto": null
}
}
EOF
````



## 電子交付コントロール.

## AB0501 お知らせ閲覧.
````
curl -i -X GET \
	 http://docker-jsbank-bff-service-jsbank-bff.mycluster-jp-tok-1-430553-06f3cfc58a58986a2f2ce380e01e4d99-0000.jp-tok.containers.appdomain.cloud/account-opening/AB0501
	 -H "Content-type: application/json" \
	 -d @- <<EOF
header:{
	"transactionID":"20220124223001000-ec470830bc9c430d808aa0e0964b35ea",
	"applicationId":"JBA-Retail",
	"deviceId":"751379d32843460090a4905b742a0d0d",
	"userIdToken":"userId",
	"jbaIdToken":"jbaId",
	"accessToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"refreshToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"version":"1.0.1",
	"os":"ios",
	"screenID":"MBLG0101",
	"eventID":"E01"
}
{

	"reportId":"JJNJNOVANO1145454514421",
	"reportPatternId":"AHBUQBVHQUVQHOVNQIBVONV596"
	
}
Response:{

    {
    "statusCode": 200,
    "resultDto": null
}
}
EOF
````

## AB0502 帳票PDFダウンロード.
````
curl -i -X GET \
	 http://docker-jsbank-bff-service-jsbank-bff.mycluster-jp-tok-1-430553-06f3cfc58a58986a2f2ce380e01e4d99-0000.jp-tok.containers.appdomain.cloud/account-opening/AB0502
	 -H "Content-type: application/json" \
	 -d @- <<EOF
header:{
	"transactionID":"20220124223001000-ec470830bc9c430d808aa0e0964b35ea",
	"applicationId":"JBA-Retail",
	"deviceId":"751379d32843460090a4905b742a0d0d",
	"userIdToken":"userId",
	"jbaIdToken":"jbaId",
	"accessToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"refreshToken":"198be4d7f6b01b0e9166cc1fe21ff81aefb7117aa51d3862671aba999fb7320c",
	"version":"1.0.1",
	"os":"ios",
	"screenID":"MBLG0101",
	"eventID":"E01"
}
{

	"reportId":"JJNJNOVANO1145454514421",
	"reportPatternId":"AHBUQBVHQUVQHOVNQIBVONV596"
	
}
Response:{

    {
    "statusCode": 200,
    "resultDto": null
}
}
EOF
````

#!/bin/bash
#
# 城南信用金バンキングアプリ
# IBM Cloud / RedHat OpenShift デプロイツール.
#
# CICDツール: 
#   通称: ebifly (エビフライ)
#
# History:
# 2022.02.12  Manabu Hanzaike  初版.
#
# Author  Manabu Hanzaike  -  mhanz@jp.ibm.com.
#
# 各プロジェクトにあわせて、以下の変数を編集してください.

# DOCKER定義.
JBA_PRJHOME="/d/jsbank-mobile-bff/mobile-bff"

# 基本名.
JBA_NAME="docker-jsbank-bff"

# DOCKER定義.
JBA_DOCKER_NAME=${JBA_NAME}
JBA_DOCKER_IMAGE_NAME=${JBA_DOCKER_NAME}-image
JBA_DOCKER_CONTAINER_NAME=${JBA_DOCKER_NAME}-container
JBA_PORT=8080

# OC定義.
JBA_OC_PRJNAME="jsbank-bff"
JBA_OC_BUILD_CONFIG_NAME=${JBA_NAME}
JBA_OC_DEPLOYMENT_NAME=${JBA_NAME}
JBA_OC_SERVICE_NAME=${JBA_NAME}-service


#----------------------------------------------------------------
# 引数の処理.
if [ $# -ne 1 ]; then
	echo "えびふらいツール.  author Manabu Hanzaike - mhanz@jp.ibm.com."
	echo
	echo "引数が指定されていませでした."
	echo "$0 <command>"
	echo "  command:"
	echo "    docker: dockerイメージの生成などを行う."
	echo "    build: ocにおいて build を実施する."
	echo "    newapp: oc new-app ${JBA_OC_DEPLOYMENT_NAME} を実施する."
	echo "    expose: ocにおいて new-app と expose を行う."
	echo "    delprj: oc delete prject ${JBA_NAME} を実施する."
	exit 1
fi
mode=$1

#----------------------------------------------------------------
# ディレクトリ移動
cmd="cd ${JBA_PRJHOME}"
echo "${cmd}"
cd ${JBA_PRJHOME}
pwd

#----------------------------------------------------------------
####################################
# Dockerモード.
####################################
if [[ $mode =~ docker ]]; then
	#
	# maven clean を実施する.
	#
	echo "####### start maven clean."
	cmd="${JBA_PRJHOME}/mvnw clean"
	echo ${cmd}
	eval ${cmd}
	echo
	echo

	# packageを生成する.
	#
	echo "####### start maven package."
	cmd="${JBA_PRJHOME}/mvnw package"
	echo ${cmd}
	eval ${cmd}
	echo
	echo

	# dockerイメージの作成.
	#
	echo "####### start create docker images."
	cmd="docker build -t ${JBA_DOCKER_IMAGE_NAME} ${JBA_PRJHOME}"
	echo ${cmd}
	eval ${cmd}
	echo
	echo

	# docker稼働.
	#
	echo "####### create command for docker run."
	echo "docker rm -f ${JBA_DOCKER_CONTAINER_NAME}"
	echo "docker run --name ${JBA_DOCKER_CONTAINER_NAME} -p 127.0.0.1:${JBA_PORT}:${JBA_PORT} ${JBA_DOCKER_IMAGE_NAME}"
	echo
	echo
fi

####################################
# oc-build.
####################################
if [[ $mode =~ build ]]; then

	#
	# 現在のprojectを確認する. [project]
	#
	echo "##### 現在のプロジェクトを確認します."
	oc project
	echo
	echo

	#
	# Buildを開始します. [build]
	#
	echo "##### BUILD を開始します. project=${JBA_OC_PRJNAME}"
	cmd="oc start-build ${JBA_OC_BUILD_CONFIG_NAME} --from-dir=."
	echo ${cmd}
	eval ${cmd}
	echo
	echo

	#sleepTime=30
	#echo ".... イメージがregistoryに登録されるのをしばし待ちます... sleep時間=${sleepTime}[sec].";
	#sleep ${sleepTime};

fi

####################################
# expose.
####################################
if [[ $mode =~ expose ]]; then
	#
	# deplymentを公開する. [expose deployment]
	#
	echo "##### deploymentを公開します."
	cmd="oc expose deployment ${JBA_OC_DEPLOYMENT_NAME} --name ${JBA_OC_SERVICE_NAME} --port=${JBA_PORT}"
	echo ${cmd}
	eval ${cmd}
	echo
	echo

	#
	# serviceを公開する. [expose service]
	#
	echo "##### serviceを公開します."
	cmd="oc expose service ${JBA_OC_SERVICE_NAME}"
	echo ${cmd}
	eval ${cmd}
	echo
	echo

	# 結果を表示する.
	eval "oc get all"

fi


####################################
# newapp
####################################
if [[ $mode =~ newapp ]]; then
	#
	# 新しい APP を生成します. [new-app]
	#
	echo "##### 新しい APP を生成します."
	echo "##### 必要なコマンドを echo 表示します. 最後は自分でコマンド打鍵してください."
	cmd="oc new-app ${JBA_OC_DEPLOYMENT_NAME}"
	echo ${cmd}
	echo
	echo
fi


####################################
# delprj.
####################################
if [[ $mode =~ delprj ]]; then
	#
	# project を delete する. [delete project]
	#
	echo "##### prject を delete します. "
	echo "##### 必要なコマンドを echo 表示します. 最後は自分でコマンド打鍵してください."
	cmd="oc delete project ${JBA_OC_PRJNAME}"
	echo ${cmd}
	echo
	echo
fi

exit 0

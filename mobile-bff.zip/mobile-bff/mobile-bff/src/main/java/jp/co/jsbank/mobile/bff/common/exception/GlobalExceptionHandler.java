package jp.co.jsbank.mobile.bff.common.exception;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import jp.co.jsbank.mobile.bff.common.Constant;
import jp.co.jsbank.mobile.bff.common.ErrorCodeConstant;
import jp.co.jsbank.mobile.bff.common.ErrorResult;
import jp.co.jsbank.mobile.bff.common.MessageIdConstant;
import jp.co.jsbank.mobile.bff.common.RequestHeaderContext;
import jp.co.jsbank.mobile.bff.common.ScreenIdConstant;
import jp.co.jsbank.mobile.bff.common.util.MessageUtils;

/**
 * グローバル異常解析器
 */
@RestControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

    private Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    /**
     * エラーハンドリング(400)
     * 
     * @param ex データなし例外
     * @param request Webリクエスト
     * @return エラー結果
     */
    @ExceptionHandler(BadRequestException.class)
    public ResponseEntity<Object> badRequestExceptionHandler(BadRequestException ex, WebRequest request) {

        // エラークラス
        ErrorResult errorResult = new ErrorResult();

        // 画面ID取得
        String screenId = RequestHeaderContext.getInstance().getScreenId();

        switch (ex.getCode()) {

            case ErrorCodeConstant.ERROR_CODE_10000:
            case ErrorCodeConstant.ERROR_CODE_10001:
            case ErrorCodeConstant.ERROR_CODE_91000:
                // エラー結果作成
                errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP0102,
                        MessageIdConstant.MESSAGE_ID_MBAP0102, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
                // ログ出力
                logger.error(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP0102));
                // HTTP応答ステータス(500)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);
            case ErrorCodeConstant.ERROR_CODE_71200:

                if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBOP0601)
                        || StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBOP0604)
                        || StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBOP0610)
                        || StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBOP0611)
                        || StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBOP0612)
                        || StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBOP0613)) {

                    // エラー結果作成
                    errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1200,
                            MessageIdConstant.MESSAGE_ID_MBAP1200, ErrorCodeConstant.LOG_LABLE_W, ex.getCode());
                    // ログ出力
                    logger.warn(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1200));
                    // HTTP応答ステータス(418)
                    return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);
                } else {

                    // エラー結果作成
                    errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1200,
                            MessageIdConstant.MESSAGE_ID_MBAP1200, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
                    // ログ出力
                    logger.error(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1200));
                    // HTTP応答ステータス(500)
                    return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR,
                            request);
                }
            case ErrorCodeConstant.ERROR_CODE_71030:

                if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0302)
                        || StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0304)
                        || StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0308)
                        || StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBCC0501)) {
                    // エラー結果作成
                    errorResult = createErrorResult(MessageIdConstant.MESSAGE_ID_MBAP1030);
                    // ログ出力
                    logger.info(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1030));
                }

                // HTTP応答ステータス(418)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);
            case ErrorCodeConstant.ERROR_CODE_71029:

                if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0302)
                        || StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0304)
                        || StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0308)
                        || StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBCC0501)) {
                    // エラー結果作成
                    errorResult = createErrorResult(MessageIdConstant.MESSAGE_ID_MBAP1029);
                    // ログ出力
                    logger.info(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1029));
                }

                // HTTP応答ステータス(418)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);
            case ErrorCodeConstant.ERROR_CODE_71032:

                if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0302)
                        || StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0304)
                        || StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0308)
                        || StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBCC0501)) {
                    // エラー結果作成
                    errorResult = createErrorResult(MessageIdConstant.MESSAGE_ID_MBAP1032);
                    // ログ出力
                    logger.info(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1032));
                }

                // HTTP応答ステータス(418)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);
            case ErrorCodeConstant.ERROR_CODE_71033:

                if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0302)
                        || StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0304)
                        || StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0308)
                        || StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBCC0501)) {
                    // エラー結果作成
                    errorResult = createErrorResult(MessageIdConstant.MESSAGE_ID_MBAP1033);
                    // ログ出力
                    logger.info(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1033));
                }

                // HTTP応答ステータス(418)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);
            case ErrorCodeConstant.ERROR_CODE_71206:
                // エラー結果作成
                errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1206,
                        MessageIdConstant.MESSAGE_ID_MBAP1206, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
                // ログ出力
                logger.error(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1206));
                // HTTP応答ステータス(500)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);

            case ErrorCodeConstant.ERROR_CODE_71103:
                // エラー結果作成
                errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1103,
                        MessageIdConstant.MESSAGE_ID_MBAP1103, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
                // ログ出力
                logger.error(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1206));

                // HTTP応答ステータス(500)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);
            case ErrorCodeConstant.ERROR_CODE_71034:

                if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0302)
                        || StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0304)
                        || StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0308)
                        || StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBCC0501)) {
                    // エラー結果作成
                    errorResult = createErrorResult(MessageIdConstant.MESSAGE_ID_MBAP1034);
                    // ログ出力
                    logger.info(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1034));
                }

                // HTTP応答ステータス(418)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);
            case ErrorCodeConstant.ERROR_CODE_71027:

                if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0302)
                        || StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0304)
                        || StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0308)
                        || StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0502)
                        || StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBCO0202)
                        || StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0602)
                        || StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBCO0302)
                        || StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0305)
                        || StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBCC0501)
                        || StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBST0402)) {
                    // エラー結果作成
                    errorResult = createErrorResult(MessageIdConstant.MESSAGE_ID_MBAP1027);
                    // ログ出力
                    logger.info(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1027));
                }

                // HTTP応答ステータス(418)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);
            case ErrorCodeConstant.ERROR_CODE_71028:

                if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0302)
                        || StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0304)
                        || StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0308)
                        || StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBCC0501)) {
                    // エラー結果作成
                    errorResult = createErrorResult(MessageIdConstant.MESSAGE_ID_MBAP1028);
                    // ログ出力
                    logger.info(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1028));
                }

                // HTTP応答ステータス(418)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);
            case ErrorCodeConstant.ERROR_CODE_71207:
                // エラー結果作成
                errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1207,
                        MessageIdConstant.MESSAGE_ID_MBAP1207, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
                // ログ出力
                logger.error(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1207));

                // HTTP応答ステータス(400)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);
            case ErrorCodeConstant.ERROR_CODE_71202:
                // エラー結果作成
                errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1202,
                        MessageIdConstant.MESSAGE_ID_MBAP1202, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
                // ログ出力
                logger.error(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1202));

                // HTTP応答ステータス(500)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);
            case ErrorCodeConstant.ERROR_CODE_71210:
                // エラー結果作成
                errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1210,
                        MessageIdConstant.MESSAGE_ID_MBAP1210, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
                // ログ出力
                logger.error(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1210));

                // HTTP応答ステータス(500)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);
            case ErrorCodeConstant.ERROR_CODE_71013:

                if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0501)
                        || StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBCO0201)
                        || StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBST0401)) {
                    // エラー結果作成
                    errorResult = createErrorResult(MessageIdConstant.MESSAGE_ID_MBAP1013);
                    // ログ出力
                    logger.info(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1013));
                }

                // HTTP応答ステータス(418)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);
            case ErrorCodeConstant.ERROR_CODE_71008:

                if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0502)
                        || StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBCO0202)) {
                    // エラー結果作成
                    errorResult = createErrorResult(MessageIdConstant.MESSAGE_ID_MBAP1008);
                    // ログ出力
                    logger.info(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1008));
                }

                // HTTP応答ステータス(418)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);
            case ErrorCodeConstant.ERROR_CODE_71020:

                if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0502)
                        || StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBCO0202)) {
                    // エラー結果作成
                    errorResult = createErrorResult(MessageIdConstant.MESSAGE_ID_MBAP1020);
                    // ログ出力
                    logger.info(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1020));
                }

                // HTTP応答ステータス(418)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);
            case ErrorCodeConstant.ERROR_CODE_71021:

                if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0502)
                        || StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBCO0202)
                        || StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBST0402)) {
                    // エラー結果作成
                    errorResult = createErrorResult(MessageIdConstant.MESSAGE_ID_MBAP1021);
                    // ログ出力
                    logger.info(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1021));
         
                }
                // HTTP応答ステータス(418)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);
            case ErrorCodeConstant.ERROR_CODE_71022:

                if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0502)
                        || StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBCO0202)
                        || StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBST0402)) {
                    // エラー結果作成
                    errorResult = createErrorResult(MessageIdConstant.MESSAGE_ID_MBAP1022);
                    // ログ出力
                    logger.info(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1022));

                }
                // HTTP応答ステータス(418)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);
            case ErrorCodeConstant.ERROR_CODE_71201:
                // エラー結果作成
                errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1021,
                        MessageIdConstant.MESSAGE_ID_MBAP1021, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
                // ログ出力
                logger.error(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1021));
                // HTTP応答ステータス(500)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);

            case ErrorCodeConstant.ERROR_CODE_71205:
                // エラー結果作成
                errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1205,
                        MessageIdConstant.MESSAGE_ID_MBAP1205, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
                // ログ出力
                logger.error(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1205));
                // HTTP応答ステータス(500)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);

            case ErrorCodeConstant.ERROR_CODE_71002:

                if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0502)
                        || StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBCO0202)) {
                    // エラー結果作成
                    errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1002,
                            MessageIdConstant.MESSAGE_ID_MBAP1002, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
                    // ログ出力
                    logger.error(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1002));

                }
                // HTTP応答ステータス(400)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);

            case ErrorCodeConstant.ERROR_CODE_71009:

                if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0601)
                        || StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBCO0301)) {
                    // エラー結果作成
                    errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1009,
                            MessageIdConstant.MESSAGE_ID_MBAP1009, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
                    // ログ出力
                    logger.error(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1009));

                }

                // HTTP応答ステータス(418)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);
            case ErrorCodeConstant.ERROR_CODE_71026:

                if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0601)
                        || StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBCO0301)) {
                    // エラー結果作成
                    errorResult = createErrorResult(MessageIdConstant.MESSAGE_ID_MBAP1026);
                    // ログ出力
                    logger.warn(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1026));

                }
                // HTTP応答ステータス(418)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);

            case ErrorCodeConstant.ERROR_CODE_71007:

                if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0602)
                        || StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBCO0302)) {
                    // エラー結果作成
                    errorResult = createErrorResult(MessageIdConstant.MESSAGE_ID_MBAP1007);
                    // ログ出力
                    logger.error(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1007));

                }
                // HTTP応答ステータス(418)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);

            case ErrorCodeConstant.ERROR_CODE_71018:

                if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0602)
                        || StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBCO0302)) {
                    // エラー結果作成
                    errorResult = createErrorResult(MessageIdConstant.MESSAGE_ID_MBAP1018);
                    // ログ出力
                    logger.info(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1018));

                }
                // HTTP応答ステータス(418)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);

            case ErrorCodeConstant.ERROR_CODE_71017:

                if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0602)
                        || StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBCO0302)) {
                    // エラー結果作成
                    errorResult = createErrorResult(MessageIdConstant.MESSAGE_ID_MBAP1017);
                    // ログ出力
                    logger.info(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1017));

                }
                // HTTP応答ステータス(418)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);

            case ErrorCodeConstant.ERROR_CODE_71019:

                if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0602)
                        || StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBCO0302)) {
                    // エラー結果作成
                    errorResult = createErrorResult(MessageIdConstant.MESSAGE_ID_MBAP1019);
                    // ログ出力
                    logger.info(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1019));

                }

                // HTTP応答ステータス(418)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);
            case ErrorCodeConstant.ERROR_CODE_71010:

                if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0305)) {
                    // エラー結果作成
                    errorResult = createErrorResult(MessageIdConstant.MESSAGE_ID_MBAP1010);
                    // ログ出力
                    logger.info(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1010));

                }

                // HTTP応答ステータス(418)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);
            case ErrorCodeConstant.ERROR_CODE_71023:

                if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0305)) {
                    // エラー結果作成
                    errorResult = createErrorResult(MessageIdConstant.MESSAGE_ID_MBAP1023);
                    // ログ出力
                    logger.info(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1023));

                }
                // HTTP応答ステータス(418)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);

            case ErrorCodeConstant.ERROR_CODE_71024:

                if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0305)) {
                    // エラー結果作成
                    errorResult = createErrorResult(MessageIdConstant.MESSAGE_ID_MBAP1024);
                    // ログ出力
                    logger.info(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1024));

                }
                // HTTP応答ステータス(418)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);

            case ErrorCodeConstant.ERROR_CODE_71025:

                if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0305)) {
                    // エラー結果作成
                    errorResult = createErrorResult(MessageIdConstant.MESSAGE_ID_MBAP1025);
                    // ログ出力
                    logger.info(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1025));

                }
                // HTTP応答ステータス(418)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);

            case ErrorCodeConstant.ERROR_CODE_71208:
                // エラー結果作成
                errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1208,
                        MessageIdConstant.MESSAGE_ID_MBAP1208, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
                // ログ出力
                logger.error(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1208));
                // HTTP応答ステータス(500)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);

            case ErrorCodeConstant.ERROR_CODE_71100:
                // エラー結果作成
                errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1100,
                        MessageIdConstant.MESSAGE_ID_MBAP1100, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
                // ログ出力
                logger.error(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1100));
                // HTTP応答ステータス(500)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);

            case ErrorCodeConstant.ERROR_CODE_71101:
                // エラー結果作成
                errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1101,
                        MessageIdConstant.MESSAGE_ID_MBAP1101, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
                // ログ出力
                logger.error(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1101));
                // HTTP応答ステータス(500)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);

            case ErrorCodeConstant.ERROR_CODE_71102:
                // エラー結果作成
                errorResult = createErrorResult(MessageIdConstant.MESSAGE_ID_MBAP1102);
                // ログ出力
                logger.error(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1102));
                // HTTP応答ステータス(400)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);

            case ErrorCodeConstant.ERROR_CODE_71011:
                // エラー結果作成
                errorResult = createErrorResult(MessageIdConstant.MESSAGE_ID_MBAP1011);
                // ログ出力
                logger.info(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1011));
                // HTTP応答ステータス(400)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);

            case ErrorCodeConstant.ERROR_CODE_71001:
                // エラー結果作成
                errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1001, ex.getCode());
                // ログ出力
               logger.error(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1001));
                // HTTP応答ステータス(418)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);

            case ErrorCodeConstant.ERROR_CODE_71000:
                // エラー結果作成
                errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1000, ex.getCode());
                // ログ出力
                logger.error(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1000));
                // HTTP応答ステータス(500)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);

            case ErrorCodeConstant.ERROR_CODE_71014:
                // エラー結果作成
                errorResult = createErrorResult(MessageIdConstant.MESSAGE_ID_MBAP1014);
                // ログ出力
                logger.info(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1014));
                // HTTP応答ステータス(400)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);

            case ErrorCodeConstant.ERROR_CODE_71015:
                // エラー結果作成
                errorResult = createErrorResult(MessageIdConstant.MESSAGE_ID_MBAP1015);
                // ログ出力
                logger.info(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1015));
                // HTTP応答ステータス(400)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);

            case ErrorCodeConstant.ERROR_CODE_71016:
                // エラー結果作成
                errorResult = createErrorResult(MessageIdConstant.MESSAGE_ID_MBAP1016);
                // ログ出力
                logger.info(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1016));
                // HTTP応答ステータス(400)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);

            case ErrorCodeConstant.ERROR_CODE_71004:
                // エラー結果作成
                errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1004, ex.getCode());
                // ログ出力
                logger.error(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1004));
                // HTTP応答ステータス(500)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);

            case ErrorCodeConstant.ERROR_CODE_71005:
                // エラー結果作成
                errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1005, ex.getCode());
                // ログ出力
                logger.error(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1005));
                // HTTP応答ステータス(500)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);

            case ErrorCodeConstant.ERROR_CODE_71006:
                // エラー結果作成
                errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1006, ex.getCode());
                // ログ出力
                logger.error(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1006));
                // HTTP応答ステータス(500)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);

            case ErrorCodeConstant.ERROR_CODE_71031:

                if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBOP0602)) {
                    // エラー結果作成
                    errorResult = createErrorResult(MessageIdConstant.MESSAGE_ID_MBAP1031);
                    // ログ出力
                    logger.info(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1031));

                }
                // HTTP応答ステータス(418)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);

            case ErrorCodeConstant.ERROR_CODE_71003:
                // エラー結果作成
                errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1003, ex.getCode());
                // ログ出力
                logger.error(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1006));
                // HTTP応答ステータス(500)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);

            case ErrorCodeConstant.ERROR_CODE_71306:
                // エラー結果作成
                errorResult = createErrorResult(MessageIdConstant.MESSAGE_ID_MBAP1306);
                // ログ出力
                logger.error(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1306));
                // HTTP応答ステータス(400)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);

            case ErrorCodeConstant.ERROR_CODE_71307:
                // エラー結果作成
                errorResult = createErrorResult(MessageIdConstant.MESSAGE_ID_MBAP1307);
                // ログ出力
                logger.error(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1307));
                // HTTP応答ステータス(400)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);

            case ErrorCodeConstant.ERROR_CODE_71308:
                // エラー結果作成
                errorResult = createErrorResult(MessageIdConstant.MESSAGE_ID_MBAP1308);
                // ログ出力
                logger.error(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1308));
                // HTTP応答ステータス(400)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);

            case ErrorCodeConstant.ERROR_CODE_71309:
                // エラー結果作成
                errorResult = createErrorResult(MessageIdConstant.MESSAGE_ID_MBAP1309);
                // ログ出力
                logger.error(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1309));
                // HTTP応答ステータス(400)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);

            case ErrorCodeConstant.ERROR_CODE_71400:
                // エラー結果作成
                errorResult = createErrorResult(MessageIdConstant.MESSAGE_ID_MBAP1400);
                // ログ出力
                logger.error(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1400));
                // HTTP応答ステータス(400)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);
            case ErrorCodeConstant.ERROR_CODE_71044:

                    // エラー結果作成
                    errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1044,
                            MessageIdConstant.MESSAGE_ID_MBAP1044, ErrorCodeConstant.LOG_LABLE_I, ex.getCode());
                    // ログ出力
                    logger.error(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1044));

                // HTTP応答ステータス(418)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);
            case ErrorCodeConstant.ERROR_CODE_71209:
                // エラー結果作成
                errorResult = createErrorResult(MessageIdConstant.MESSAGE_ID_MBAP1209);
                // ログ出力
                logger.error(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1209));
                // HTTP応答ステータス(400)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);

            case ErrorCodeConstant.ERROR_CODE_71212:
                // エラー結果作成
                errorResult = createErrorResult(MessageIdConstant.MESSAGE_ID_MBAP1212);
                // ログ出力
                logger.error(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1212));
                // HTTP応答ステータス(400)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.BAD_REQUEST, request);

            case "MBOP0003":
                // エラー結果作成
                errorResult = createErrorResult(MessageIdConstant.MESSAGE_ID_MBOP0003);
                // ログ出力
                logger.error(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBOP0003));
                // HTTP応答ステータス(418)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);

            default:
                // エラーコード設定
                errorResult.setErrorCode(MessageIdConstant.MESSAGE_ID_MBAP0001);
                // エラーメッセージ設定
                errorResult.setErrorMessage(MessageUtils.getMessageText(MessageIdConstant.MESSAGE_ID_MBAP0001));
                logger.error(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP0001));

        }

        return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.OK, request);
    }

    /**
     * エラーハンドリング(500)
     * 
     * @param ex データなし例外
     * @param request Webリクエスト
     * @return エラー結果
     */
    @ExceptionHandler(InternalServerErrorException.class)
    public ResponseEntity<Object> internalServerErrorExceptionHandler(InternalServerErrorException ex,
            WebRequest request) {

        // エラークラス
        ErrorResult errorResult = new ErrorResult();

        // 画面ID取得
        String screenId = RequestHeaderContext.getInstance().getScreenId();

        switch (ex.getCode()) {
            case ErrorCodeConstant.ERROR_CODE_10022:
            case ErrorCodeConstant.ERROR_CODE_10031:
            case ErrorCodeConstant.ERROR_CODE_10032:
            case ErrorCodeConstant.ERROR_CODE_30010:
            case ErrorCodeConstant.ERROR_CODE_33293:
            case ErrorCodeConstant.ERROR_CODE_90000:
            case ErrorCodeConstant.ERROR_CODE_90002:
            case ErrorCodeConstant.ERROR_CODE_90003:
            case ErrorCodeConstant.ERROR_CODE_90004:
            case ErrorCodeConstant.ERROR_CODE_90005:
            case ErrorCodeConstant.ERROR_CODE_95001:
            case ErrorCodeConstant.ERROR_CODE_99999:
                // エラー結果作成
                errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP0101,
                        MessageIdConstant.MESSAGE_ID_MBAP0101, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
                // ログ出力
                logger.error(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP0101));
                // HTTP応答ステータス(500)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);

            case ErrorCodeConstant.ERROR_CODE_91001:
            case ErrorCodeConstant.ERROR_CODE_90006:
                // エラー結果作成
                errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP0102,
                        MessageIdConstant.MESSAGE_ID_MBAP0101, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
                // ログ出力
                logger.error(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP0102));
                // HTTP応答ステータス(500)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);

            case ErrorCodeConstant.ERROR_CODE_90001:
                // エラー結果作成
                errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP0103,
                        MessageIdConstant.MESSAGE_ID_MBAP0103, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
                // ログ出力
                logger.error(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP0103));
                // HTTP応答ステータス(503)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.SERVICE_UNAVAILABLE, request);

            case ErrorCodeConstant.ERROR_CODE_95002:
                // エラー結果作成
                errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP0104,
                        MessageIdConstant.MESSAGE_ID_MBAP0104, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
                // ログ出力
                logger.error(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP0104));
                // HTTP応答ステータス(503)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.SERVICE_UNAVAILABLE, request);

            case ErrorCodeConstant.ERROR_CODE_71040:

                if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0601)
                        || StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBCO0301)) {
                    // エラー結果作成
                    errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1040,
                            MessageIdConstant.MESSAGE_ID_MBAP1040, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
                    // ログ出力
                    logger.error(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1040));

                }

                // HTTP応答ステータス(418)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);
            case ErrorCodeConstant.ERROR_CODE_71041:

                if (StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBSU0601)
                        || StringUtils.equals(screenId, ScreenIdConstant.SCREEN_ID_MBCO0301)) {
                    // エラー結果作成
                    errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP1041,
                            MessageIdConstant.MESSAGE_ID_MBAP1041, ErrorCodeConstant.LOG_LABLE_E, ex.getCode());
                    // ログ出力
                    logger.error(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1041));

                }
                // HTTP応答ステータス(418)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);

            case ErrorCodeConstant.ERROR_CODE_71302:
                // エラー結果作成
                errorResult = createErrorResult(MessageIdConstant.MESSAGE_ID_MBAP1302);
                // ログ出力
                logger.error(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1302));
                // HTTP応答ステータス(418)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);

            case ErrorCodeConstant.ERROR_CODE_71303:
                // エラー結果作成
                errorResult = createErrorResult(MessageIdConstant.MESSAGE_ID_MBAP1303);
                // ログ出力
                logger.error(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1303));
                // HTTP応答ステータス(418)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.I_AM_A_TEAPOT, request);

            case ErrorCodeConstant.ERROR_CODE_71304:
                // エラー結果作成
                errorResult = createErrorResult(MessageIdConstant.MESSAGE_ID_MBAP1304);
                // ログ出力
                logger.error(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1304));
                // HTTP応答ステータス(500)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);

            case ErrorCodeConstant.ERROR_CODE_71305:
                // エラー結果作成
                errorResult = createErrorResult(MessageIdConstant.MESSAGE_ID_MBAP1305);
                // ログ出力
                logger.error(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP1305));
                // HTTP応答ステータス(500)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);

            default:

                // エラー結果作成
                errorResult = createErrorResult(MessageIdConstant.MESSAGE_ID_MBAP0012);
                // ログ出力
                logger.error(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP0012));
                // HTTP応答ステータス(500)
                return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.INTERNAL_SERVER_ERROR, request);

        }
    }

    /**
     * エラーハンドリング(401)
     * 
     * @param ex データなし例外
     * @param request Webリクエスト
     * @return エラー結果
     */
    @ExceptionHandler(UnauthorizedException.class)
    public ResponseEntity<Object> unauthorizedExceptionHandler(UnauthorizedException ex, WebRequest request) {

        // // エラー結果作成
        // ErrorResult errorResult = createErrorResult(MessageIdConstant.MESSAGE_ID_MBAP0003);
        // // ログ出力
        // logger.error(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP0003));
        //
        // return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.OK, request);

        return null;
    }

    /**
     * エラーハンドリング(403)
     * 
     * @param ex バリエーション例外
     * @param request Webリクエスト
     * @return エラー結果
     */
    @ExceptionHandler(ForbiddenException.class)
    public ResponseEntity<Object> forbiddenExceptionHandler(ForbiddenException ex, WebRequest request) {

        // エラー結果作成
        ErrorResult errorResult = createErrorResult(MessageIdConstant.MESSAGE_ID_MBAP0004);
        // ログ出力
        logger.error(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP0004));

        return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.OK, request);
    }

    /**
     * エラーハンドリング(404)
     * 
     * @param ex バリエーション例外
     * @param request Webリクエスト
     * @return エラー結果
     */
    @ExceptionHandler(NotFoundException.class)
    public ResponseEntity<Object> notFoundExceptionHandler(NotFoundException ex, WebRequest request) {

        // // エラー結果作成
        // ErrorResult errorResult = createErrorResult(MessageIdConstant.MESSAGE_ID_MBAP0005);
        // // ログ出力
        // logger.error(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP0005));
        //
        // return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.OK, request);
        return null;
    }

    /**
     * エラーハンドリング(426)
     * 
     * @param ex バリエーション例外
     * @param request Webリクエスト
     * @return エラー結果
     */
    @ExceptionHandler(UpgradeRequiredException.class)
    public ResponseEntity<Object> upgradeRequiredExceptionHandler(UpgradeRequiredException ex, WebRequest request) {

        // エラー結果作成
        ErrorResult errorResult = createErrorResult(MessageIdConstant.MESSAGE_ID_MBAP0006);
        // ログ出力
        logger.error(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP0006));

        return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.OK, request);
    }

    /**
     * エラーハンドリング(429)
     * 
     * @param ex バリエーション例外
     * @param request Webリクエスト
     * @return エラー結果
     */
    @ExceptionHandler(TooManyRequestsException.class)
    public ResponseEntity<Object> tooManyRequestsExceptionHandler(TooManyRequestsException ex, WebRequest request) {

        // エラー結果作成
        ErrorResult errorResult = createErrorResult(MessageIdConstant.MESSAGE_ID_MBAP0007);
        // ログ出力
        logger.error(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP0007));

        return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.TOO_MANY_REQUESTS, request);
    }

    /**
     * エラーハンドリング(503)
     * 
     * @param ex バリエーション例外
     * @param request Webリクエスト
     * @return エラー結果
     */
    @ExceptionHandler(ServiceUnavailableException.class)
    public ResponseEntity<Object> serviceUnavailableExceptionHandler(ServiceUnavailableException ex,
            WebRequest request) {

        // エラー結果作成
        ErrorResult errorResult = createErrorResultWithErrorCode(MessageIdConstant.MESSAGE_ID_MBAP0103,
                MessageIdConstant.MESSAGE_ID_MBAP0103, ErrorCodeConstant.LOG_LABLE_E,
                ErrorCodeConstant.ERROR_CODE_95000);
        // ログ出力
        logger.error(splicingLogInfo(ex, MessageIdConstant.MESSAGE_ID_MBAP0103));

        return super.handleExceptionInternal(ex, errorResult, null, HttpStatus.OK, request);
    }

    /**
     * エラー結果作成
     * 
     * @param messageId メッセージID
     * @return エラー結果
     */
    private ErrorResult createErrorResult(String messageId) {

        // エラークラス
        ErrorResult errorResult = new ErrorResult();

        // エラーコード設定
        errorResult.setErrorCode(messageId);
        // エラーメッセージ設定
        errorResult.setErrorMessage(MessageUtils.getMessageText(messageId));

        return errorResult;
    }

    /**
     * エラー結果作成
     * 
     * @param messageId メッセージID
     * @param errorCode エラーコード
     * @return エラー結果
     */
    private ErrorResult createErrorResultWithErrorCode(String messageId, String... errorCode) {

        // エラークラス
        ErrorResult errorResult = new ErrorResult();

        // エラーコード設定
        errorResult.setErrorCode(messageId);
        // エラーメッセージ設定
        errorResult.setErrorMessage(MessageUtils.getMessageText(messageId, errorCode));

        return errorResult;
    }

    /**
     * メッセージ内容
     *
     * @param ex 例外
     * @param msgId メッセージID
     * @return メッセージ
     */
    private String splicingLogInfo(Exception ex, String msgId) {
        // メッセージフォーマット
        StringBuffer logInfos = new StringBuffer();

        SimpleDateFormat sdf = new SimpleDateFormat();
        sdf.applyPattern(Constant.CURRENT_TIMESTAMP);

        // ログ出力時のタイムスタンプ
        logInfos.append(sdf.format(new Date())).append(Constant.EMPTY_SYMBOL);
        // 固定 SYSTEM
        logInfos.append(Constant.SYSTEM).append(Constant.EMPTY_SYMBOL);
        // メッセージID
        logInfos.append(msgId).append(Constant.EMPTY_SYMBOL);
        // ログレベル
        logInfos.append("ログレベル").append(Constant.EMPTY_SYMBOL);
        // AIFログレベル
        logInfos.append("AIFログレベル").append(Constant.EMPTY_SYMBOL);
        // 取引ID
        String transactionID = RequestHeaderContext.getInstance().getTransactionID();
        logInfos.append(transactionID).append(Constant.EMPTY_SYMBOL);

        return logInfos.toString();
    }

    /**
     * SpringBoot内で用意されている例外については、ResponseEntityExceptionHandlerクラスで例外ごとに
     * 専用のメソッドが用意されているのでそれをオーバーライドする
     */
    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
            HttpHeaders headers, HttpStatus status, WebRequest request) {
        return super.handleExceptionInternal(ex, "MethodArgumentNotValidException", null,
                HttpStatus.INTERNAL_SERVER_ERROR, request);
    }

    /**
     * すべての例外をキャッチする
     * 
     * @param ex バリエーション例外
     * @param request Webリクエスト
     * @return エラー結果
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<Object> handleAllException(Exception ex, WebRequest request) {

        return super.handleExceptionInternal(ex, ex.getMessage(), null, HttpStatus.INTERNAL_SERVER_ERROR, request);
    }

    /**
     * すべてのハンドリングに共通する処理を挟みたい場合はオーバーライドする
     */
    @Override
    protected ResponseEntity<Object> handleExceptionInternal(Exception ex, Object body, HttpHeaders headers,
            HttpStatus status, WebRequest request) {

        // 任意の処理
        return super.handleExceptionInternal(ex, body, headers, status, request);
    }
}

package jp.co.jsbank.mobile.bff.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.jsbank.mobile.bff.common.Constant;
import jp.co.jsbank.mobile.bff.common.GetIdByTokenHandler;
import jp.co.jsbank.mobile.bff.common.RequestHeaderContext;
import jp.co.jsbank.mobile.bff.common.code.SettingTypeCode;
import jp.co.jsbank.mobile.bff.common.code.UserStatusCode;
import jp.co.jsbank.mobile.bff.common.code.UserTypeCode;
import jp.co.jsbank.mobile.bff.common.redis.RedisHandler;
import jp.co.jsbank.mobile.bff.common.util.HashHelper;
import jp.co.jsbank.mobile.bff.dto.BankbookPatternPreferenceRequestDto;
import jp.co.jsbank.mobile.bff.dto.DepartmentStoreInquiryResponseDto;
import jp.co.jsbank.mobile.bff.dto.EmailAddressAuthorizationRequestDto;
import jp.co.jsbank.mobile.bff.dto.EmailAddressRegistrationRequestDto;
import jp.co.jsbank.mobile.bff.dto.IdentityVerificationRequestDto;
import jp.co.jsbank.mobile.bff.dto.IdentityVerificationResponseDto;
import jp.co.jsbank.mobile.bff.dto.IvrAuthenticationRequestDto;
import jp.co.jsbank.mobile.bff.dto.JagBodyLinkAuthUserRequestDto;
import jp.co.jsbank.mobile.bff.dto.PassBookLessPreferenceRequestDto;
import jp.co.jsbank.mobile.bff.dto.PushNotificationRegistrationRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.AuthAccountInfoAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.AuthAccountInfoAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.AuthenticationKeyVerificationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.AuthenticationKeyVerificationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.BankBookLessPreferenceAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CifNumberDto;
import jp.co.jsbank.mobile.bff.dto.aba.CommonHeaderAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CustomerAttributeInfoDto;
import jp.co.jsbank.mobile.bff.dto.aba.CustomerAttributeInquiryAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CustomerAttributeInquiryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CustomerInformationRegistrationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CustomerInformationRegistrationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.DepartmentStoreInquiryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.DepartmentStoreInquiryDto;
import jp.co.jsbank.mobile.bff.dto.aba.EmailAddressAuthorizationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.EmailAddressAuthorizationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.EmailAddressRegistrationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.EmailAddressRegistrationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.IvrAuthorizationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.IvrAuthorizationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.IvrAuthorizationSkipInfoInquiryAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.IvrAuthorizationSkipInfoInquiryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.IvrAuthorizationSkipInfoUpdateAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.IvrSendingAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.IvrSendingAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.IvrSendingRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.SettingInfoDto;
import jp.co.jsbank.mobile.bff.dto.aba.UpdateUserAttributeAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.UserAttributeRegistrationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.UserDataAbaRequestDto;
import jp.co.jsbank.mobile.bff.entity.TokenIdEntity;
import jp.co.jsbank.mobile.bff.logic.SignUpLogic;
import jp.co.jsbank.mobile.bff.service.SignUpService;
import jp.co.jsbank.mobile.bff.service.TokenIdService;

/**
 * 初回登録サービス実装クラス
 */
@Service
public class SignUpServiceImpl implements SignUpService {

    @Resource
    private SignUpLogic signUpLogic;

    @Autowired
    private RedisHandler redisHandler;

    @Resource
    private TokenIdService tokenIdService;

    @Autowired
    private GetIdByTokenHandler getIdByTokenHandler;

    /**
     * 部店照会リスト取得
     *
     * @return 部店照会リスト
     */
    @Override
    public List<DepartmentStoreInquiryResponseDto> departmentStoreInquiry() {

        // 部店照会リスト取得
        DepartmentStoreInquiryAbaResponseDto responseDto = signUpLogic.departmentStoreInquiry();

        // 部店照会DTOリスト
        List<DepartmentStoreInquiryDto> departmentStoreInquiryDtoList = responseDto.getBranchList();

        // 部店照会レスポンスDTOリスト
        List<DepartmentStoreInquiryResponseDto> responseList = new ArrayList<>();

        // 部店照会DTOリストの繰り返し
        if (departmentStoreInquiryDtoList != null && departmentStoreInquiryDtoList.size() > 0) {

            for (DepartmentStoreInquiryDto departmentStoreInquiryDto : departmentStoreInquiryDtoList) {

                // 部店照会レスポンスDTO
                DepartmentStoreInquiryResponseDto departmentStoreInquiryResponseDto = new DepartmentStoreInquiryResponseDto();

                BeanUtils.copyProperties(departmentStoreInquiryDto, departmentStoreInquiryResponseDto);

                responseList.add(departmentStoreInquiryResponseDto);
            }
        }

        return responseList;

    }

    /**
     * 本人照合
     *
     * @param identityVerificationReq 本人照合リクエストDTO
     * @return 本人照合レスポンスDTO
     */
    @Override
    public IdentityVerificationResponseDto
            identityVerification(IdentityVerificationRequestDto identityVerificationReq) {

        // 本人照合レスボスDTO
        IdentityVerificationResponseDto responseDto = new IdentityVerificationResponseDto();

        // 事業性利用者の場合
        if (StringUtils.isNotEmpty(identityVerificationReq.getAuthCode())) {

            // 認証キー検証ABAリクエストDTO
            AuthenticationKeyVerificationAbaRequestDto abaRequestDto = new AuthenticationKeyVerificationAbaRequestDto();
            // 所属設定
            abaRequestDto.setDivisionCode(identityVerificationReq.getDivisionCode());
            // 利用者認証キー設定
            abaRequestDto.setUserAuthCode(identityVerificationReq.getAuthCode());
            // デバイスID設定
            abaRequestDto.setDeviceId(identityVerificationReq.getDeviceId());
            // カナ氏名（名）
            abaRequestDto.setCustomerFirstName(identityVerificationReq.getCustomerName());
            // 漢字氏名（名）
            abaRequestDto.setCustomerKanjiFirstName(identityVerificationReq.getCustomerKanjiName());
            // デバイスID設定
            abaRequestDto.setDeviceId(identityVerificationReq.getDeviceId());
            // 「認証キー検証」API呼出
            AuthenticationKeyVerificationAbaResponseDto authAbaResponseDto = signUpLogic
                    .authenticationKeyVerification(abaRequestDto);

            // 利用者情報ABAレスボスDto
            UserDataAbaRequestDto userDataAbaRequestDto = new UserDataAbaRequestDto();
            // 顧客ID設定
            userDataAbaRequestDto.setCustomerId(authAbaResponseDto.getCustomerId());
            // 利用者区分設定
            userDataAbaRequestDto.setUserType(UserTypeCode.BUSINESS_USER);
            // ステータス設定
            userDataAbaRequestDto.setStatus(UserStatusCode.NORMAL);
            // 漢字氏名設定
            userDataAbaRequestDto.setCustomerKanjiName(identityVerificationReq.getCustomerKanjiName());
            // カナ氏名設定
            userDataAbaRequestDto.setCustomerName(identityVerificationReq.getCustomerName());
            // 所属設定
            userDataAbaRequestDto.setDivision(identityVerificationReq.getDivisionCode());
            // 事業先利用者認証キー設定
            userDataAbaRequestDto.setCertKey(identityVerificationReq.getAuthCode());
            // 「利用者属性登録」API呼出
            UserAttributeRegistrationAbaResponseDto registrationAbaResponseDto = signUpLogic
                    .userAttributeRegistration(userDataAbaRequestDto);

            responseDto.setCustomerId(authAbaResponseDto.getCustomerId());
            responseDto.setUserId(registrationAbaResponseDto.getUserId());
        } else {

            // 口座情報認証リクエストDTO
            AuthAccountInfoAbaRequestDto authAccountReDto = new AuthAccountInfoAbaRequestDto();
            // 店番設定
            authAccountReDto.setBranchNumber(identityVerificationReq.getBranchCode());
            // 口座番号設定
            authAccountReDto.setAccountNumber(identityVerificationReq.getAccountNumber());
            // カナ氏名設定
            authAccountReDto.setCustomerLastName(identityVerificationReq.getCustomerName());
            // 生年月日設定
            authAccountReDto.setBirthDay(identityVerificationReq.getBirthDay());
            // 郵便番号設定
            authAccountReDto.setCcPinCode(identityVerificationReq.getCcPinCode());
            // CC暗証番号設定
            authAccountReDto.setZipCode(identityVerificationReq.getZipCode());

            // 「口座情報認証情報取得」API呼出
            AuthAccountInfoAbaResponseDto authAccountResponseDto = signUpLogic.authAccountInfo(authAccountReDto);

            // 顧客情報登録リクエストDTO
            CustomerInformationRegistrationAbaRequestDto customerInfoRegAbaReqDto = new CustomerInformationRegistrationAbaRequestDto();
            // CIF番号設定
            customerInfoRegAbaReqDto.setCifNo(authAccountResponseDto.getCifNumber());
            // 人格区分設定
            customerInfoRegAbaReqDto.setPersonCode(identityVerificationReq.getPersonType());
            // 店番設定
            customerInfoRegAbaReqDto.setBranchCode(identityVerificationReq.getBranchCode());
            // 口座番号設定
            customerInfoRegAbaReqDto.setAccountNumber(identityVerificationReq.getAccountNumber());
            // カナ氏名設定
            customerInfoRegAbaReqDto.setCustomerName(identityVerificationReq.getCustomerName());
            // 生年月日設定
            customerInfoRegAbaReqDto.setBirthday(identityVerificationReq.getBirthDay());
            // 郵便番号設定
            customerInfoRegAbaReqDto.setZipCode(identityVerificationReq.getZipCode());
            // 利用者認証キ設定
            customerInfoRegAbaReqDto.setCertKey(identityVerificationReq.getCcPinCode());

            // 「顧客情報登録」API呼出
            CustomerInformationRegistrationAbaResponseDto abaResponseDto = signUpLogic
                    .customerInformationRegistration(customerInfoRegAbaReqDto);

            // uuid生成
            String uuid = UUID.randomUUID().toString().replace("-", "");

            // 顧客IDトークン化
            String customerIdToken = HashHelper.cryptoHash(abaResponseDto.getCustomerId(), uuid);
            // TOKEN_MAPPINGエンティティ
            TokenIdEntity customerTokenIdEntity = new TokenIdEntity();
            // ID設定
            customerTokenIdEntity.setId(abaResponseDto.getCustomerId());
            // TOKENID設定
            customerTokenIdEntity.setTokenId(customerIdToken);
            // DBの顧客ID追加
            tokenIdService.insertIdAndToken(customerTokenIdEntity);
            // redisの顧客ID設定
            redisHandler.set(customerIdToken, abaResponseDto.getCustomerId());

            // 利用者IDトークン化
            String userIdToken = HashHelper.cryptoHash(abaResponseDto.getUserId(), uuid);
            // TOKEN_MAPPINGエンティティ
            TokenIdEntity userTokenIdEntity = new TokenIdEntity();
            // ID設定
            userTokenIdEntity.setId(abaResponseDto.getUserId());
            // TOKENID設定
            userTokenIdEntity.setTokenId(userIdToken);
            // DBの利用者ID追加
            tokenIdService.insertIdAndToken(userTokenIdEntity);
            // redisの利用者ID設定
            redisHandler.set(userIdToken, abaResponseDto.getUserId());

            // 顧客ID設定
            responseDto.setCustomerId(customerIdToken);
            // 利用者ID設定
            responseDto.setUserId(userIdToken);
            // CIF番号設定
            responseDto.setCifNo(abaResponseDto.getCifNo());
        }

        return responseDto;
    }

    /**
     * 利用者属性更新
     *
     * @param requestDto 利用者属性更新リクエストDTO
     * @return 処理結果
     */
    @Override
    public String updateUserAttribute() {

        // TODO 利用者IDトークン取得する
        String userIdToken = RequestHeaderContext.getInstance().getUserIdToken();

        // 利用者属性更新ABAリクエストDTO
        UpdateUserAttributeAbaRequestDto abaRequestDto = new UpdateUserAttributeAbaRequestDto();
        // 利用者ID設定
        abaRequestDto.setUserId(getIdByTokenHandler.getIdByToken(userIdToken));
        // ステータス設定
        abaRequestDto.setStatus(UserStatusCode.NORMAL);
        // 利用者属性更新
        CommonHeaderAbaResponseDto abaResponseDto = signUpLogic.updateUserAttribute(abaRequestDto);

        return Constant.OK;
    }

    /**
     * メールアドレス登録
     *
     * @param requestDto メールアドレス登録リクエストDTO
     * @return 処理結果
     */
    @Override
    public String emailAddressRegistration(EmailAddressRegistrationRequestDto requestDto) {

        // メールアドレス登録ABAリクエストDTO
        EmailAddressRegistrationAbaRequestDto abaRequestDto = new EmailAddressRegistrationAbaRequestDto();

        // 利用者IDトークン取得する
        String userIdToken = RequestHeaderContext.getInstance().getUserIdToken();

        // if (!redisHandler.exists(userIdToken)) {
        // // エラー戻る
        // throw new InternalServerErrorException(Constant.REDIS);
        // }

        // 利用者ID設定
        abaRequestDto.setUserId(getIdByTokenHandler.getIdByToken(userIdToken));
        // メールアドレス設定
        abaRequestDto.setEmailAddress(requestDto.getEmailAddress());
        // 処理区分設定
        abaRequestDto.setProcessType(requestDto.getProcessKubun());

        // メールアドレス登録
        EmailAddressRegistrationAbaResponseDto abaResponseDto = signUpLogic.emailAddressRegistration(abaRequestDto);

        // 認証TRXキー
        String verifyTRXKey = abaResponseDto.getVerifyTRXKey();

        return verifyTRXKey;
    }

    /**
     * メールアドレス認証
     *
     * @param requestDto メールアドレス認証リクエストDTO
     * @return 処理結果
     */
    @Override
    public List<String> emailAddressAuthorization(EmailAddressAuthorizationRequestDto requestDto) {
        // 利用者IDトークン取得する
        String userIdToken = RequestHeaderContext.getInstance().getUserIdToken();

        // JBAIDトークン取得する
        String jbaIdToken = RequestHeaderContext.getInstance().getJbaIdToken();
        // if (!redisHandler.exists(userIdToken)) {
        // // エラー戻る
        // throw new InternalServerErrorException(Constant.REDIS);
        // }

        String deviceId = RequestHeaderContext.getInstance().getDeviceId();

        // メールアドレス認証リクエストDTO
        EmailAddressAuthorizationAbaRequestDto emailAddressAuthorizationAbaRequestDto = new EmailAddressAuthorizationAbaRequestDto();
        // 受付番号設定
        emailAddressAuthorizationAbaRequestDto.setReceiptNumber(requestDto.getReceptionNumber());
        // メールOTP設定
        emailAddressAuthorizationAbaRequestDto.setMailOTP(requestDto.getOtp());
        // 利用者ID設定
        emailAddressAuthorizationAbaRequestDto.setUserId(deviceId);
        // 認証TRXキー設定
        emailAddressAuthorizationAbaRequestDto.setVerifyTRXKey(requestDto.getVerifyTRXKey());
        // メールアドレス認証
        EmailAddressAuthorizationAbaResponseDto emailAddressAuthorizationAbaResponseDto = signUpLogic
                .emailAddressAuthorization(emailAddressAuthorizationAbaRequestDto);

        // 利用者属性更新AbaRequestDto
        UpdateUserAttributeAbaRequestDto updateUserAttributeAbaRequestDto = new UpdateUserAttributeAbaRequestDto();
        // メールアドレス設定
        updateUserAttributeAbaRequestDto.setMailAddress(emailAddressAuthorizationAbaResponseDto.getEmailAddress());
        // 利用者ID設定
        updateUserAttributeAbaRequestDto.setUserId(deviceId);
        // 利用者属性更新
        CommonHeaderAbaResponseDto userAttributeUpdateAbaResponseDto = signUpLogic
                .updateUserAttribute(updateUserAttributeAbaRequestDto);

        // IVR認証スキップ情報照会ABAリクエストDTO
        IvrAuthorizationSkipInfoInquiryAbaRequestDto ivrAuthorizationSkipInfoInquiryAbaRequestDto = new IvrAuthorizationSkipInfoInquiryAbaRequestDto();
        // CIF番号設定
        ivrAuthorizationSkipInfoInquiryAbaRequestDto.setCifNumber(requestDto.getCifNumber());
        // IVR認証スキップ情報照会
        IvrAuthorizationSkipInfoInquiryAbaResponseDto ivrAuthorizationSkipInfoInquiryAbaResponseDto = signUpLogic
                .ivrAuthorizationSkipInfoInquiry(ivrAuthorizationSkipInfoInquiryAbaRequestDto);

        List<String> phoneNuumberList = new ArrayList<>();

        if (StringUtils.equals(ivrAuthorizationSkipInfoInquiryAbaResponseDto.getIvrSkipFlag(), "0")) {

            // 顧客属性照会ABAリクエストDTO
            CustomerAttributeInquiryAbaRequestDto customerAttributeInquiryAbaRequestDto = new CustomerAttributeInquiryAbaRequestDto();
            // CIF番号DTO
            CifNumberDto cifNumberDto = new CifNumberDto();
            // CIF番号設定
            cifNumberDto.setCifNo(requestDto.getCifNumber());
            // CIF番号リスト設定
            customerAttributeInquiryAbaRequestDto.setCifNoList(Arrays.asList(cifNumberDto));
            // 顧客属性照会
            CustomerAttributeInquiryAbaResponseDto customerAttInquiryAbaResponseDto = signUpLogic
                    .customerAttInquiry(customerAttributeInquiryAbaRequestDto);

            for (CustomerAttributeInfoDto customerDto : customerAttInquiryAbaResponseDto.getCustomerList()) {

                phoneNuumberList.add(customerDto.getPhoneNumber());
            }
        } else {

            // IVR認証スキップ情報更新ABAリクエストDTO
            IvrAuthorizationSkipInfoUpdateAbaRequestDto ivrAuthorizationSkipInfoUpdateAbaRequestDto = new IvrAuthorizationSkipInfoUpdateAbaRequestDto();
            // CIF番号設定
            ivrAuthorizationSkipInfoInquiryAbaRequestDto.setCifNumber(requestDto.getCifNumber());
            // CIF番号設定
            ivrAuthorizationSkipInfoUpdateAbaRequestDto.setUsedFlag("1");
            // IVR認証スキップ情報更新
            CommonHeaderAbaResponseDto commonHeaderAbaResponseDto = signUpLogic
                    .ivrAuthorizationSkipInfoUpdate(ivrAuthorizationSkipInfoUpdateAbaRequestDto);

            // 端末とJBAIDの紐づけリクエストDTO
            JagBodyLinkAuthUserRequestDto jagRequestDto = new JagBodyLinkAuthUserRequestDto();
            // デバイスID設定
            jagRequestDto.setJagDeviceId(RequestHeaderContext.getInstance().getDeviceId());
            // アプリケーションID設定
            jagRequestDto.setJagApplicationId(RequestHeaderContext.getInstance().getApplicationId());
            // JBAID設定
            jagRequestDto.setJagJbaId(jbaIdToken);
            // 利用者ID設定
            jagRequestDto.setJagUserId(userIdToken);
            // jagDoLink設定
            jagRequestDto.setJagDoLink(1);
            // トランザクションID設定
            jagRequestDto.setJagTrxId(RequestHeaderContext.getInstance().getTransactionID());
            // TRX種別設定
            jagRequestDto.setJagTrxType("JAG-NRM");

            // 端末とJBAIDの紐づけ
            signUpLogic.linkingDeviceAndJbaId(jagRequestDto);
        }

        return phoneNuumberList;
    }

    /**
     * IVR送信
     *
     * @param requestDto IVR送信リクエストDTO
     * @return 認証TRXキー
     */
    @Override
    public String ivrSending(IvrSendingRequestDto requestDto) {

        // 利用者IDトークン取得する
        String userIdToken = RequestHeaderContext.getInstance().getUserIdToken();

        // if (!redisHandler.exists(userIdToken)) {
        // // エラー戻る
        // throw new InternalServerErrorException(Constant.REDIS);
        // }

        // IVR送信ABAリクエストDTO
        IvrSendingAbaRequestDto abaRequestDto = new IvrSendingAbaRequestDto();
        // 受付番号設定
        abaRequestDto.setReceiptNumber(requestDto.getReceiptNumber());
        // 電話番号設定
        abaRequestDto.setPhoneNumber(requestDto.getPhoneNumber());
        // 利用者ID
        abaRequestDto.setUserId(getIdByTokenHandler.getIdByToken(userIdToken));
        // IVR送信
        IvrSendingAbaResponseDto ivrSendingAbaResponseDto = signUpLogic.ivrSending(abaRequestDto);

        return ivrSendingAbaResponseDto.getVerifyTRXKey();
    }

    /**
     * IVR認証
     *
     * @param requestDto IVR認証リクエストDTO
     * @return [確認ダイアログ]画面表示
     */
    @Override
    public String ivrAuthentication(IvrAuthenticationRequestDto requestDto) {

        // JBAIDトークン取得する
        String jbaIdToken = RequestHeaderContext.getInstance().getJbaIdToken();
        // 利用者IDトークン取得する
        String userIdToken = RequestHeaderContext.getInstance().getUserIdToken();

        // if (!redisHandler.exists(userIdToken)) {
        // // エラー戻る
        // throw new InternalServerErrorException(Constant.REDIS);
        // }

        // IVR認証ABAリクエストDTO
        IvrAuthorizationAbaRequestDto abaRequestDto = new IvrAuthorizationAbaRequestDto();
        // 利用者ID設定
        abaRequestDto.setUserId(getIdByTokenHandler.getIdByToken(userIdToken));
        // 認証TRXキー設定
        abaRequestDto.setVerifyTRXKey(requestDto.getVerifyTRXKey());
        // ivrOTP設定
        abaRequestDto.setIvrOTP(requestDto.getIvrOTP());
        // IVR認証
        IvrAuthorizationAbaResponseDto ivrAuthorizationAbaResponseDto = signUpLogic.ivrAuthorization(abaRequestDto);

        // 端末とJBAIDの紐づけリクエストDTO
        JagBodyLinkAuthUserRequestDto jagRequestDto = new JagBodyLinkAuthUserRequestDto();
        // デバイスID設定
        jagRequestDto.setJagDeviceId(RequestHeaderContext.getInstance().getDeviceId());
        // アプリケーションID設定
        jagRequestDto.setJagApplicationId(RequestHeaderContext.getInstance().getApplicationId());
        // JBAID設定
        jagRequestDto.setJagJbaId(jbaIdToken);
        // 利用者ID設定
        jagRequestDto.setJagUserId(userIdToken);
        // jagDoLink設定
        jagRequestDto.setJagDoLink(1);
        // トランザクションID設定
        jagRequestDto.setJagTrxId(RequestHeaderContext.getInstance().getTransactionID());
        // TRX種別設定
        jagRequestDto.setJagTrxType("JAG-NRM");

        // 端末とJBAIDの紐づけ
        signUpLogic.linkingDeviceAndJbaId(jagRequestDto);

        return Constant.OK;
    }

    /**
     * プッシュ通知登録
     *
     * @param requestDto プッシュ通知登録リクエストDTO
     * @return 処理結果
     */
    @Override
    public String pushNotificationRegistration(PushNotificationRegistrationRequestDto requestDto) {

        // 利用者IDトークン取得する
        String userIdToken = RequestHeaderContext.getInstance().getUserIdToken();

        // 利用者属性更新ABAリクエストDTO
        UpdateUserAttributeAbaRequestDto abaRequestDto = new UpdateUserAttributeAbaRequestDto();
        // 利用者ID設定
        abaRequestDto.setUserId(getIdByTokenHandler.getIdByToken(userIdToken));
        // 設定情報DTO
        SettingInfoDto settingInfoDto = new SettingInfoDto();
        // Push通知設定
        settingInfoDto.setSettingType(SettingTypeCode.PUSH_NOTIFICATION_SETTINGS);
        // 設定値設定
        settingInfoDto.setSettingContent(requestDto.getSettingContent());
        abaRequestDto.setSettingInfos(Arrays.asList(settingInfoDto));
        // OS設定
        abaRequestDto.setOperatingSystem(requestDto.getOsType());
        // 利用者属性更新
        signUpLogic.updateUserAttribute(abaRequestDto);

        return Constant.OK;
    }

    /**
     * 通帳パターン設定
     *
     * @param requestDto 通帳パターン設定リクエストDTO
     * @return 処理結果
     */
    @Override
    public String bankbookPatternPreference(BankbookPatternPreferenceRequestDto requestDto) {

        // 利用者IDトークン取得する
        String userIdToken = RequestHeaderContext.getInstance().getUserIdToken();

        // 利用者属性更新ABAリクエストDTO
        UpdateUserAttributeAbaRequestDto abaRequestDto = new UpdateUserAttributeAbaRequestDto();
        // 利用者ID設定
        abaRequestDto.setUserId(getIdByTokenHandler.getIdByToken(userIdToken));
        // 設定情報DTO
        SettingInfoDto settingInfoDto = new SettingInfoDto();
        // Push通知設定
        settingInfoDto.setSettingType(SettingTypeCode.PASSBOOK_PATTERN_SETTING);
        // 設定値設定
        settingInfoDto.setSettingContent(requestDto.getBankbookPattern());
        abaRequestDto.setSettingInfos(Arrays.asList(settingInfoDto));
        // 利用者属性更新
        signUpLogic.updateUserAttribute(abaRequestDto);

        return Constant.OK;
    }

    /**
     * 通帳レス設定
     *
     * @param requestDto 通帳レス設定リクエストDTO
     * @return 処理結果
     */
    @Override
    public String bankBookLessPreference(PassBookLessPreferenceRequestDto requestDto) {

        // 通帳レス設定情報ABAリクエストDTO
        BankBookLessPreferenceAbaRequestDto abaRequestDto = new BankBookLessPreferenceAbaRequestDto();
        // CIF番号設定
        abaRequestDto.setCifNumber(requestDto.getCifNumber());
        // 店番設定
        abaRequestDto.setBranchCode(requestDto.getBranchCode());

        // 通帳レス設定
        signUpLogic.bankBookLessPreference(abaRequestDto);

        return Constant.OK;
    }
}

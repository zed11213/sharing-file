package jp.co.jsbank.mobile.bff.logic.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import jp.co.jsbank.mobile.bff.common.builder.ParameterBuilder;
import jp.co.jsbank.mobile.bff.config.RestClientConfig;
import jp.co.jsbank.mobile.bff.dto.JagBodyLinkAuthUserRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.AuthAccountInfoAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.AuthAccountInfoAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.AuthenticationKeyVerificationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.AuthenticationKeyVerificationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.BankBookLessPreferenceAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CifInfoInquiryAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CifInfoInquiryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CifInfomationDto;
import jp.co.jsbank.mobile.bff.dto.aba.CommonHeaderAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CustomerAttributeInfoDto;
import jp.co.jsbank.mobile.bff.dto.aba.CustomerAttributeInquiryAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CustomerAttributeInquiryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CustomerInformationRegistrationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CustomerInformationRegistrationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.DepartmentStoreInquiryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.DepartmentStoreInquiryDto;
import jp.co.jsbank.mobile.bff.dto.aba.EmailAddressAuthorizationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.EmailAddressAuthorizationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.EmailAddressRegistrationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.EmailAddressRegistrationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.IvrAuthorizationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.IvrAuthorizationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.IvrAuthorizationSkipInfoInquiryAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.IvrAuthorizationSkipInfoInquiryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.IvrAuthorizationSkipInfoUpdateAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.IvrSendingAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.IvrSendingAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.UpdateUserAttributeAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.UserAttributeInfoDto;
import jp.co.jsbank.mobile.bff.dto.aba.UserAttributeInquiryAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.UserAttributeInquiryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.UserAttributeRegistrationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.UserDataAbaRequestDto;
import jp.co.jsbank.mobile.bff.logic.SignUpLogic;

/**
 * 初回登録ロジック実装クラス
 */
@Service
public class SignUpLogicImpl implements SignUpLogic {

    @Autowired
    RestClientConfig restClientConfig;

    /**
     * 部店照会リスト取得
     *
     * @return 部店照会ABAリクエストDTO
     */
    @Override
    public DepartmentStoreInquiryAbaResponseDto departmentStoreInquiry() {

        // リクエストパラメータ設定
        ParameterBuilder parameterDto = ParameterBuilder.build(null);

        // // 「部店照会」APIを呼び出す
        // RestTemplate restTemplate = restClientConfig.simpleRestTemplate();
        //
        // // 照会結果
        // DepartmentStoreInquiryAbaResponseDto abaResponseDto = restTemplate.postForObject(
        // "/v1.4.3/hQ/branch/list/inquiry", parameterDto.getRequestEntity(),
        // DepartmentStoreInquiryAbaResponseDto.class);
        // return abaResponseDto;

        DepartmentStoreInquiryAbaResponseDto departmentStoreInquiryAbaResponseDto = new DepartmentStoreInquiryAbaResponseDto();

        // 部店照会DTOList
        List<DepartmentStoreInquiryDto> departmentStoreInquiryDtoList = new ArrayList<>();
        // 部店照会DTO
        DepartmentStoreInquiryDto departmentStoreInquiryDto = new DepartmentStoreInquiryDto();
        departmentStoreInquiryDto.setBranchKanjiName("大井支店");
        departmentStoreInquiryDto.setBranchNumber("002");
        departmentStoreInquiryDtoList.add(departmentStoreInquiryDto);
        departmentStoreInquiryDto = new DepartmentStoreInquiryDto();
        departmentStoreInquiryDto.setBranchKanjiName("大森支店");
        departmentStoreInquiryDto.setBranchNumber("003");
        departmentStoreInquiryDtoList.add(departmentStoreInquiryDto);
        departmentStoreInquiryDto = new DepartmentStoreInquiryDto();
        departmentStoreInquiryDto.setBranchKanjiName("入新井支店");
        departmentStoreInquiryDto.setBranchNumber("004");
        departmentStoreInquiryDtoList.add(departmentStoreInquiryDto);
        departmentStoreInquiryDto = new DepartmentStoreInquiryDto();
        departmentStoreInquiryDto.setBranchKanjiName("馬込支店");
        departmentStoreInquiryDto.setBranchNumber("005");
        departmentStoreInquiryDtoList.add(departmentStoreInquiryDto);
        departmentStoreInquiryDto = new DepartmentStoreInquiryDto();
        departmentStoreInquiryDto.setBranchKanjiName("池上支店");
        departmentStoreInquiryDto.setBranchNumber("006");
        departmentStoreInquiryDtoList.add(departmentStoreInquiryDto);
        departmentStoreInquiryDto = new DepartmentStoreInquiryDto();
        departmentStoreInquiryDto.setBranchKanjiName("蒲田支店");
        departmentStoreInquiryDto.setBranchNumber("007");
        departmentStoreInquiryDtoList.add(departmentStoreInquiryDto);
        departmentStoreInquiryDto = new DepartmentStoreInquiryDto();
        departmentStoreInquiryDto.setBranchKanjiName("六郷支店");
        departmentStoreInquiryDto.setBranchNumber("008");
        departmentStoreInquiryDtoList.add(departmentStoreInquiryDto);
        departmentStoreInquiryDto = new DepartmentStoreInquiryDto();
        departmentStoreInquiryDto.setBranchKanjiName("矢口支店");
        departmentStoreInquiryDto.setBranchNumber("009");
        departmentStoreInquiryDtoList.add(departmentStoreInquiryDto);
        departmentStoreInquiryDto = new DepartmentStoreInquiryDto();
        departmentStoreInquiryDto.setBranchKanjiName("羽田支店");
        departmentStoreInquiryDto.setBranchNumber("010");
        departmentStoreInquiryDtoList.add(departmentStoreInquiryDto);
        departmentStoreInquiryDto = new DepartmentStoreInquiryDto();
        departmentStoreInquiryDto.setBranchKanjiName("荏原支店");
        departmentStoreInquiryDto.setBranchNumber("011");
        departmentStoreInquiryDtoList.add(departmentStoreInquiryDto);

        // 部店照会AbaレスポンDTO
        departmentStoreInquiryAbaResponseDto.setBranchList(departmentStoreInquiryDtoList);
        return departmentStoreInquiryAbaResponseDto;

    }

    /**
     * 口座情報認証情報取得
     *
     * @param abaRequestDto 口座情報認証ABAリクエストDTO
     * @return 口座情報認証ABAレスボスDto
     */
    @Override
    public AuthAccountInfoAbaResponseDto authAccountInfo(AuthAccountInfoAbaRequestDto abaRequestDto) {

        // リクエストパラメータ設定
        ParameterBuilder parameterDto = ParameterBuilder.build(abaRequestDto);
        //
        // // 「口座情報認証」API呼出
        // RestTemplate restTemplate = restClientConfig.simpleRestTemplate();
        // AuthAccountInfoAbaResponseDto responseDto = restTemplate.postForObject("/v1.4.3/accountInfo/auth",
        // parameterDto.getRequestEntity(), AuthAccountInfoAbaResponseDto.class);
        //
        // return responseDto;

        AuthAccountInfoAbaResponseDto responseDto = new AuthAccountInfoAbaResponseDto();
        responseDto.setAuthenticationResult("認証結果");
        responseDto.setCifNumber("CIF番号");

        return responseDto;
    }

    /**
     * 顧客情報登録
     *
     * @param abaRequestDto 顧客情報登録ABAリクエストDTO
     * @return 顧客情報登録ABAレスボスDTO
     */
    @Override
    public CustomerInformationRegistrationAbaResponseDto
            customerInformationRegistration(CustomerInformationRegistrationAbaRequestDto abaRequestDto) {

        ParameterBuilder parameterDto = ParameterBuilder.build(abaRequestDto);

        // // 「顧客情報登録」API呼出
        // RestTemplate restTemplate = restClientConfig.simpleRestTemplate();
        // CustomerInformationRegistrationAbaResponseDto responseDto = restTemplate.postForObject(
        // "/v1.4.3/customer/registration", parameterDto.getRequestEntity(),
        // CustomerInformationRegistrationAbaResponseDto.class);
        CustomerInformationRegistrationAbaResponseDto responseDto = new CustomerInformationRegistrationAbaResponseDto();

        responseDto.setCifNo("48892117845612");
        responseDto.setCustomerId(UUID.randomUUID().toString().replace("-", ""));
        responseDto.setUserId(UUID.randomUUID().toString().replace("-", ""));

        return responseDto;
    }

    /**
     * 利用者属性更新
     *
     * @param abaRequestDto 利用者属性更新ABAリクエストDTO
     * @return 共通レスポンス・ヘッダ
     */
    public CommonHeaderAbaResponseDto updateUserAttribute(UpdateUserAttributeAbaRequestDto abaRequestDto) {

        ParameterBuilder parameterDto = ParameterBuilder.build(abaRequestDto);

        // // 「利用者属性更新」API呼出
        // RestTemplate restTemplate = restClientConfig.simpleRestTemplate();
        // CommonHeaderAbaResponseDto responseDto = restTemplate.postForObject("/customer/v1.3.0/userinfo/update",
        // parameterDto.getRequestEntity(), CommonHeaderAbaResponseDto.class);

        CommonHeaderAbaResponseDto responseDto = new CommonHeaderAbaResponseDto();

        return responseDto;
    }

    /**
     * メールアドレス登録
     *
     * @param abaRequestDto メールアドレス登録リクエストDTO
     * @return メールアドレス登録ABAレスポンスDTO
     */
    @Override
    public EmailAddressRegistrationAbaResponseDto
            emailAddressRegistration(EmailAddressRegistrationAbaRequestDto abaRequestDto) {

        ParameterBuilder parameterDto = ParameterBuilder.build(abaRequestDto);

        // // 「メールアドレス登録」API呼出
        // RestTemplate restTemplate = restClientConfig.simpleRestTemplate();
        // EmailAddressRegistrationAbaResponseDto responseDto = restTemplate.postForObject(
        // "/v1.4.3/mailAddress/registration", parameterDto.getRequestEntity(),
        // EmailAddressRegistrationAbaResponseDto.class);
        EmailAddressRegistrationAbaResponseDto responseDto = new EmailAddressRegistrationAbaResponseDto();

        responseDto.setVerifyTRXKey("BAHHSJDK8529958");

        return responseDto;
    }

    /**
     * IVR送信
     *
     * @param abaRequestDto IVR送信リクエストDTO
     * @return IVR送信ABAレスポンスDTO
     */
    @Override
    public IvrSendingAbaResponseDto ivrSending(IvrSendingAbaRequestDto abaRequestDto) {

        ParameterBuilder parameterDto = ParameterBuilder.build(abaRequestDto);

        // // 「メールアドレス登録」API呼出
        // RestTemplate restTemplate = restClientConfig.simpleRestTemplate();
        // IvrSendingAbaResponseDto responseDto = restTemplate.postForObject("/v1.4.3/ivr/send",
        // parameterDto.getRequestEntity(), IvrSendingAbaResponseDto.class);

        IvrSendingAbaResponseDto responseDto = new IvrSendingAbaResponseDto();

        responseDto.setVerifyTRXKey("BAHHSJDK8529958");
        return responseDto;
    }

    /**
     * IVR認証
     *
     * @param abaRequestDto IVR認証ABAリクエストDTO
     * @return IVR認証ABAレスポンスDTO
     */
    @Override
    public IvrAuthorizationAbaResponseDto ivrAuthorization(IvrAuthorizationAbaRequestDto abaRequestDto) {

        // ParameterBuilder parameterDto = ParameterBuilder.build(abaRequestDto);
        //
        // // 「メールアドレス登録」API呼出
        // RestTemplate restTemplate = restClientConfig.simpleRestTemplate();
        // IvrAuthorizationAbaResponseDto responseDto = restTemplate.postForObject("/v1.4.3/ivr/auth",
        // parameterDto.getRequestEntity(), IvrAuthorizationAbaResponseDto.class);

        IvrAuthorizationAbaResponseDto responseDto = new IvrAuthorizationAbaResponseDto();

        responseDto.setAuthenticationResult("OK");
        ;
        return responseDto;
    }

    /**
     * CIF情報照会
     *
     * @param abaRequestDto CIF情報照会ABAリクエストDTO
     * @return CIF情報照会ABAレスポンスDTO
     */
    @Override
    public CifInfoInquiryAbaResponseDto cifInfoInquiry(CifInfoInquiryAbaRequestDto abaRequestDto) {

        ParameterBuilder parameterDto = ParameterBuilder.build(abaRequestDto);

        // // 「メールアドレス登録」API呼出
        // RestTemplate restTemplate = restClientConfig.simpleRestTemplate();
        // CifInfoInquiryAbaResponseDto responseDto = restTemplate.postForObject("/customer/v1.3.0/ciflist/inquiry",
        // parameterDto.getRequestEntity(), CifInfoInquiryAbaResponseDto.class);

        List<CifInfomationDto> cifList = new ArrayList<CifInfomationDto>();

        CifInfomationDto dto = new CifInfomationDto();
        dto.setBranchCode("0001");
        dto.setCifNumber("001");

        cifList.add(dto);
        CifInfoInquiryAbaResponseDto responseDto = new CifInfoInquiryAbaResponseDto();
        responseDto.setCifList(cifList);

        return responseDto;
    }

    /**
     * 通帳レス設定
     *
     * @param requestDto 通帳レス設定リクエストDTO
     * @return 共通レスポンス・ヘッダ
     */
    @Override
    public CommonHeaderAbaResponseDto bankBookLessPreference(BankBookLessPreferenceAbaRequestDto requestDto) {

        ParameterBuilder parameterDto = ParameterBuilder.build(requestDto);

        // // 「メールアドレス登録」API呼出
        // RestTemplate restTemplate = restClientConfig.simpleRestTemplate();
        // CommonHeaderAbaResponseDto responseDto = restTemplate.postForObject("/v1.4.3/passbookless/registration",
        // parameterDto.getRequestEntity(), CommonHeaderAbaResponseDto.class);
        CommonHeaderAbaResponseDto responseDto = new CommonHeaderAbaResponseDto();

        return responseDto;
    }

    /**
     * メールアドレス認証
     *
     * @param abaRequestDto メールアドレス認証AbaリクエストDTO
     * @return 認証済メールアドレスABAレスポンスDTO
     */
    @Override
    public EmailAddressAuthorizationAbaResponseDto
            emailAddressAuthorization(EmailAddressAuthorizationAbaRequestDto abaRequestDto) {

        ParameterBuilder parameterDto = ParameterBuilder.build(abaRequestDto);

        // // 「メールアドレス登録」API呼出
        // RestTemplate restTemplate = restClientConfig.simpleRestTemplate();
        // EmailAddressAuthorizationAbaResponseDto responseDto = restTemplate.postForObject("/v1.4.3/mailAddress/auth",
        // parameterDto.getRequestEntity(), EmailAddressAuthorizationAbaResponseDto.class);

        EmailAddressAuthorizationAbaResponseDto responseDto = new EmailAddressAuthorizationAbaResponseDto();

        responseDto.setEmailAddress("1226288888@qq.com");
        return responseDto;
    }

    /**
     * IVR認証スキップ情報照会
     *
     * @param abaRequestDto IVR認証スキップ情報照会ABAリクエストDTO
     * @return IVR認証スキップ情報照会ABAレスポンスDTO
     */
    @Override
    public IvrAuthorizationSkipInfoInquiryAbaResponseDto
            ivrAuthorizationSkipInfoInquiry(IvrAuthorizationSkipInfoInquiryAbaRequestDto abaRequestDto) {

        ParameterBuilder parameterDto = ParameterBuilder.build(abaRequestDto);

        // // 「メールアドレス登録」API呼出
        // RestTemplate restTemplate = restClientConfig.simpleRestTemplate();
        // IvrAuthorizationSkipInfoInquiryAbaResponseDto responseDto = restTemplate.postForObject(
        // "/v1.4.3/ivrAuthSkip/info/inquiry", parameterDto.getRequestEntity(),
        // IvrAuthorizationSkipInfoInquiryAbaResponseDto.class);

        IvrAuthorizationSkipInfoInquiryAbaResponseDto responseDto = new IvrAuthorizationSkipInfoInquiryAbaResponseDto();
        // CIF番号
        responseDto.setCifNumber("6519116599164916516489");
        // 有効期間From
        responseDto.setExpireDateFrom("20220202");
        // 有効期間To
        responseDto.setExpireDateTo("20220402");
        // IVRスキップフラグ
        responseDto.setIvrSkipFlag("0");
        // 使用済みフラグ
        responseDto.setUsedFlag("1");

        return responseDto;
    }

    /**
     * 顧客属性照会
     * 
     * @param abaRequestDto 顧客属性照会ABAリクエストDTO
     * @return 顧客属性照会ABAレスポンスDTO
     */
    @Override
    public CustomerAttributeInquiryAbaResponseDto
            customerAttInquiry(CustomerAttributeInquiryAbaRequestDto abaRequestDto) {

        CustomerAttributeInquiryAbaResponseDto responseDto = new CustomerAttributeInquiryAbaResponseDto();

        List<CustomerAttributeInfoDto> customerList = new ArrayList<CustomerAttributeInfoDto>();
        CustomerAttributeInfoDto customerAttributeInfoDto = new CustomerAttributeInfoDto();
        customerAttributeInfoDto.setAddress("東京都");
        customerAttributeInfoDto.setPhoneNumber("08043280815");
        customerAttributeInfoDto.setCustomerId("10086");
        customerAttributeInfoDto.setCustomerKanjiName("田中 鳴門");
        customerAttributeInfoDto.setCustomerName("ﾀﾅｶ ﾅﾙﾄ");
        customerAttributeInfoDto.setDateOfBirth("19940505");
        customerAttributeInfoDto.setZipNo("12345678");
        customerList.add(customerAttributeInfoDto);

        responseDto.setCustomerList(customerList);

        return responseDto;
    }

    /**
     * 認証キー検証
     *
     * @param abaRequestDto 認証キー検証ABAリクエストDTO
     * @return 認証キー検証ABAレスポンスDTO
     * 
     */
    @Override
    public AuthenticationKeyVerificationAbaResponseDto
            authenticationKeyVerification(AuthenticationKeyVerificationAbaRequestDto abaRequestDto) {

        // リクエストパラメータ設定
        ParameterBuilder parameterDto = ParameterBuilder.build(abaRequestDto);

        // // 「認証キー検証」APIを呼び出す
        // RestTemplate restTemplate = restClientConfig.simpleRestTemplate();
        //
        // // 認証結果
        // AuthenticationKeyVerificationAbaResponseDto abaResponseDto = restTemplate.postForObject(
        // "/v1.4.3/authKey/verify", parameterDto.getRequestEntity(),
        // AuthenticationKeyVerificationAbaResponseDto.class);

        AuthenticationKeyVerificationAbaResponseDto abaResponseDto = new AuthenticationKeyVerificationAbaResponseDto();
        abaResponseDto.setCustomerId("10086");

        return abaResponseDto;
    }

    /**
     * 利用者属性登録
     *
     * @param abaRequestDto 利用者情報ABAレスボスDto
     * @return 利用者属性登録ABAレスボスDTO
     * 
     */
    @Override
    public UserAttributeRegistrationAbaResponseDto userAttributeRegistration(UserDataAbaRequestDto abaRequestDto) {

        // リクエストパラメータ設定
        ParameterBuilder parameterDto = ParameterBuilder.build(abaRequestDto);

        // // 「利用者属性登録」APIを呼び出す
        // RestTemplate restTemplate = restClientConfig.simpleRestTemplate();
        //
        // UserAttributeRegistrationAbaResponseDto abaResponseDto =
        // restTemplate.postForObject("/v1.4.3/user/registration",
        // parameterDto.getRequestEntity(), UserAttributeRegistrationAbaResponseDto.class);

        UserAttributeRegistrationAbaResponseDto abaResponseDto = new UserAttributeRegistrationAbaResponseDto();
        abaResponseDto.setUserId("100001");

        return abaResponseDto;
    }

    /**
     * 利用者属性照会
     *
     * @param abaRequestDto 利用者属性照会ABAリクエストDTO
     * @return 利用者属性照会ABAレスボスDTO
     * 
     */
    @Override
    public UserAttributeInquiryAbaResponseDto userAttributeInquiry(UserAttributeInquiryAbaRequestDto abaRequestDto) {

        // リクエストパラメータ設定
        ParameterBuilder parameterDto = ParameterBuilder.build(abaRequestDto);

        // // 「利用者属性登録」APIを呼び出す
        // RestTemplate restTemplate = restClientConfig.simpleRestTemplate();
        //
        // UserAttributeInquiryAbaResponseDto abaResponseDto = restTemplate.postForObject("/v1.4.3/userAttr/inquiry",
        // parameterDto.getRequestEntity(), UserAttributeInquiryAbaResponseDto.class);

        UserAttributeInquiryAbaResponseDto abaResponseDto = new UserAttributeInquiryAbaResponseDto();
        List<UserAttributeInfoDto> userInfoList = new ArrayList<UserAttributeInfoDto>();

        UserAttributeInfoDto userAttributeInfoDto = new UserAttributeInfoDto();

        userAttributeInfoDto.setCustomerKanjiName("賀");
        userAttributeInfoDto.setDeviceId("122.136.110.17");
        userInfoList.add(userAttributeInfoDto);

        abaResponseDto.setUserInfoList(userInfoList);
        return abaResponseDto;
    }

    /**
     * IVR認証スキップ情報更新
     * 
     * @param abaRequestDto IVR認証スキップ情報更新ABAリクエストDTO
     * @return 共通レスポンス・ヘッダ
     */
    @Override
    public CommonHeaderAbaResponseDto
            ivrAuthorizationSkipInfoUpdate(IvrAuthorizationSkipInfoUpdateAbaRequestDto abaRequestDto) {

        // // リクエストパラメータ設定
        // ParameterBuilder parameterDto = ParameterBuilder.build(abaRequestDto);
        //
        // // 「利用者属性登録」APIを呼び出す
        // RestTemplate restTemplate = restClientConfig.simpleRestTemplate();
        //
        // CommonHeaderAbaResponseDto abaResponseDto = restTemplate.postForObject("/v1.4.3/ivrAuthSkip/update",
        // parameterDto.getRequestEntity(), CommonHeaderAbaResponseDto.class);

        CommonHeaderAbaResponseDto abaResponseDto = new CommonHeaderAbaResponseDto();

        return abaResponseDto;
    }

    /**
     * ID端末とJBAIDの紐づけ
     * 
     * @param requestDto 端末とJBAIDの紐づけリクエストDTO
     */
    @Override
    public void linkingDeviceAndJbaId(JagBodyLinkAuthUserRequestDto requestDto) {

        // 「端末とJBAIDの紐づけ」APIを呼び出す
        RestTemplate restTemplate = restClientConfig.simpleRestTemplate();

        // String url = Constant.GATEWAY_BASE_URL.concat("/v1.4.3/ivrAuthSkip/update");
        String url = "http://jag-gateway-pri-service-ops-jag-gateway-pri.mycluster-jp-tok-1-430553-06f3cfc58a58986a2f2ce380e01e4d99-0000.jp-tok.containers.appdomain.cloud/jag/az0931";
        restTemplate.postForEntity(url, requestDto, null);
    }
}

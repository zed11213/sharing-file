package jp.co.jsbank.mobile.bff.dto;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.aba.LotteryResultsDetailsDto;
import lombok.Data;

/**
 * 帳票CSV内容照会_定期預金利息計算（懸賞金付）（自継）ABAレスポンスDTO
 */
@Data
public class InquireReport001ResponseDto {

	/**
	 * 帳票バージョン
	 */
	private String formVersion;

	/**
	 * 本状作成日
	 */
	private String bookCreateDate;

	/**
	 * 開始日
	 */
	private String startDate;

	/**
	 * 終了日
	 */
	private String endDate;

	/**
	 * スーパードリームお利息計算明細表リスト
	 */
	private List<SuperDreamInterestRateDto> superDreamInterestRateList;
	
	/**
	 * 抽選結果リスト
	 */
	private List<LotteryResultsDetailsDto> lotteryResultsDetailsResponseList;	
	
	/**
	 * マル優申告限度額
	 */
	private String declarationLimitAmount;

	/**
	 * ご利用額(預金)
	 */
	private String usageAmount;

	/**
	 * 取扱店名
	 */
	private String branchKanjiName;

	/**
	 * 取扱電話番号
	 */
	private String branchPhoneNumber;
	
    /**
     * 共通店番
     */
    private String comBranchNo;

    /**
     * 共通口座番
     */
    private String comAccountNo;
}

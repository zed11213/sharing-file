package jp.co.jsbank.mobile.bff.common.icos;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.Base64;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ibm.cloud.objectstorage.HttpMethod;
import com.ibm.cloud.objectstorage.services.s3.AmazonS3;
import com.ibm.cloud.objectstorage.services.s3.model.GeneratePresignedUrlRequest;
import com.ibm.cloud.objectstorage.services.s3.model.ObjectMetadata;
import com.ibm.cloud.objectstorage.services.s3.model.PutObjectRequest;
import com.ibm.cloud.objectstorage.services.s3.model.S3Object;

/**
 * Icos処理クラス
 */
@Component
public class IcosHandler {

    @Autowired
    private AmazonS3 cosClient;

    // KEY PROTECT
    private static String bucketName = "jag-poc-bucket-helo";

    /**
     * バケットにファイルを追加する
     * 
     * @param fileName ファイル名
     * @param fileStream ファイルストリーム
     */
    public void addFile(String fileName, String fileStream) {

        byte[] decodedBytes = Base64.getDecoder().decode(fileStream);

        InputStream input = new ByteArrayInputStream(decodedBytes);

        ObjectMetadata om = new ObjectMetadata();

        // ICOSへのファイルアップロードを実施.
        PutObjectRequest por = new PutObjectRequest(bucketName, fileName, input, om);
        cosClient.putObject(por);
    }

    /**
     * URLを取得する
     * 
     * @param fileName ファイル名
     * @return URL
     */
    public String getUrl(String fileName) {

        // 署名有効期限までの時間1week
        long signExpiration = 604800000;
        // 署名有効期限
        Date expiration = new Date();
        long msec = expiration.getTime() + signExpiration;
        expiration.setTime(msec);

        GeneratePresignedUrlRequest generatePresignedUrlRequest = new GeneratePresignedUrlRequest(bucketName, fileName);
        generatePresignedUrlRequest.setMethod(HttpMethod.GET);
        generatePresignedUrlRequest.setExpiration(expiration);
        String url = cosClient.generatePresignedUrl(generatePresignedUrlRequest).toString();

        return url;
    }

    /**
     * バケットにファイルを取得する
     *
     * @param fileName ファイル名
     * @return fileStream
     */
    public InputStream getFile(String fileName) {

        S3Object file = cosClient.getObject(bucketName, fileName);
        InputStream fileStream = file.getObjectContent();

        return fileStream;
    }
}

package jp.co.jsbank.mobile.bff.dto;

import jp.co.jsbank.mobile.bff.dto.aba.CcIssuingApplicationInformationAbaDto;
import lombok.Data;

/**
 * CC発行申込情報レスポンスDTO
 */
@Data
public class CcIssuingApplicationInformationResponseDto {
	
	/**
	 * 画面ID
	 */
	private String screenId;
	
    /**
     * CC発行申込情報DTOリスト
     */
    private CcIssuingApplicationInformationAbaDto CcIssuingApplicationInformationDto;
}
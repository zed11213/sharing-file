package jp.co.jsbank.mobile.bff.logic.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.jsbank.mobile.bff.common.builder.ParameterBuilder;
import jp.co.jsbank.mobile.bff.config.RestClientConfig;
import jp.co.jsbank.mobile.bff.dto.aba.AuthAccountInfoAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.AuthAccountInfoAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CcIssuingApplicationCompleteAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CcIssuingApplicationCompleteAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CcIssuingApplicationContentRegistrationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CcIssuingApplicationContentRegistrationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CcIssuingApplicationContentUpdateAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CcIssuingApplicationContentUpdateAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CcIssuingApplicationInformationAbaDto;
import jp.co.jsbank.mobile.bff.dto.aba.CcIssuingApplicationInformationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.ContractManagementOperationHistoryInquiryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.RecoveryProcessAbaRequestDto;
import jp.co.jsbank.mobile.bff.logic.CashCardIssueLogic;

/**
 * キャッシュカード発行ロジック実装クラス
 */
@Service
public class CashCardIssueLogicImpl implements CashCardIssueLogic {

	@Autowired
	RestClientConfig restClientConfig;

	/**
	 * [契約管理操作履歴照会]API呼出
	 *
	 * @param requestDto 復元処理リクエストDTO
	 * @return 契約管理操作履歴照会ResponseDTO
	 */
	@Override
	public ContractManagementOperationHistoryInquiryAbaResponseDto contractManagementOperationHistoryInquiry(
			RecoveryProcessAbaRequestDto abaRequestDto) {
		// リクエストパラメータ
		ParameterBuilder parameterDto = ParameterBuilder.build(abaRequestDto);

		// 照会結果
		ContractManagementOperationHistoryInquiryAbaResponseDto abaResponseDto = new ContractManagementOperationHistoryInquiryAbaResponseDto();
		abaResponseDto.setPersonalityKubun("1");
		return abaResponseDto;
	}

	/**
	 * [CC発行申込内容照会]API呼出
	 *
	 * @param requestDto 復元処理リクエストDTO
	 * @return CC発行申込内容照会ResponseDTO
	 */
	@Override
	public CcIssuingApplicationInformationAbaResponseDto ccIssuingApplicationInformation(
			RecoveryProcessAbaRequestDto abaRequestDto) {
		// リクエストパラメータ
		ParameterBuilder parameterDto = ParameterBuilder.build(abaRequestDto);

		// 照会結果
		CcIssuingApplicationInformationAbaResponseDto abaResponseDto = new CcIssuingApplicationInformationAbaResponseDto();
		CcIssuingApplicationInformationAbaDto cccIssuingApplicationInformationAbaDto = new CcIssuingApplicationInformationAbaDto();
		cccIssuingApplicationInformationAbaDto.setAccountNumber("88954654");
		cccIssuingApplicationInformationAbaDto.setAccountType("1");
		abaResponseDto.setCcIssuingApplicationInformationDto(cccIssuingApplicationInformationAbaDto);
		return abaResponseDto;
	}

	/**
	 * [CC発行申込内容更新]API呼出
	 *
	 * @param requestDto CC発行申込内容更新リクエストDTO
	 * 
	 * @return CC発行申込情報
	 */
	@Override
	public CcIssuingApplicationContentUpdateAbaResponseDto ccIssuingApplicationContentUpdate(
			CcIssuingApplicationContentUpdateAbaRequestDto ccIssuingApplicationContentUpdateAbaRequestDto) {
		// リクエストパラメータ
		ParameterBuilder parameterDto = ParameterBuilder.build(ccIssuingApplicationContentUpdateAbaRequestDto);

		// 照会結果
		CcIssuingApplicationContentUpdateAbaResponseDto abaResponseDto = new CcIssuingApplicationContentUpdateAbaResponseDto();
		abaResponseDto.setCommonResponseBody(null);
		return abaResponseDto;
	}

	/**
	 * [CC発行申込内容登録]API呼出
	 *
	 * @param requestDto CC発行申込内容登録リクエストDTO
	 * @return CC発行申込内容登録レスボスDTO
	 */
	@Override
	public CcIssuingApplicationContentRegistrationAbaResponseDto contractMmanagementOperationHistoryRegistration(
			CcIssuingApplicationContentRegistrationAbaRequestDto abaRequestDto) {
		// リクエストパラメータ
		ParameterBuilder parameterDto = ParameterBuilder.build(abaRequestDto);

		// 照会結果
		CcIssuingApplicationContentRegistrationAbaResponseDto abaResponseDto = new CcIssuingApplicationContentRegistrationAbaResponseDto();
		abaResponseDto.setReceptionNumber("458949199919");
		return abaResponseDto;
	}

	/**
	 * [CC発行申込完了]API呼出
	 *
	 * @param requestDto CC発行申込完了リクエストDTO
	 * @return CC発行申込完了情報
	 */
	@Override
	public CcIssuingApplicationCompleteAbaResponseDto ccIssuingApplicationComplete(
			CcIssuingApplicationCompleteAbaRequestDto requestDto) {
		// リクエストパラメータ
		ParameterBuilder parameterDto = ParameterBuilder.build(requestDto);

		// 照会結果
		CcIssuingApplicationCompleteAbaResponseDto abaResponseDto = new CcIssuingApplicationCompleteAbaResponseDto();
		abaResponseDto.setCommonResponseBody(null);
		return abaResponseDto;
	}

	/**
	 * 口座情報認証取得
	 *
	 * @param abaRequestDto 口座情報認証リクエストDTO
	 * @return 口座情報認証ABAレスボスDTO
	 */
	@Override
	public AuthAccountInfoAbaResponseDto authAccountInfo(AuthAccountInfoAbaRequestDto authAccountReDto) {
		// リクエストパラメータ
		ParameterBuilder parameterDto = ParameterBuilder.build(authAccountReDto);

		// 照会結果
		AuthAccountInfoAbaResponseDto abaResponseDto = new AuthAccountInfoAbaResponseDto();
		abaResponseDto.setCifNumber("9594785455621");
		return abaResponseDto;
	}

}

package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 認証キー検証ABAレスポンスDTO
 */
@Data
public class AuthenticationKeyVerificationAbaResponseDto {

    /**
     * 共通レスポンスヘッダ
     */
    private CommonResponseHeader commonResponseHeader;

    /**
     * 顧客ID
     */
    private String customerId;
}

package jp.co.jsbank.mobile.bff.common.builder;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;

import jp.co.jsbank.mobile.bff.common.Constant;
import jp.co.jsbank.mobile.bff.common.RequestHeaderContext;
import jp.co.jsbank.mobile.bff.dto.CommonRequestBodyOfHeaderDto;
import lombok.Data;

/**
 * リクエストパラメータコンストラクタ
 */
@Data
public class ParameterBuilder {

    /**
     * HttpEntity
     */
    private HttpEntity<Object> requestEntity;

    /**
     * コンストラクタ
     * 
     */
    public ParameterBuilder() {
        
    }
    /**
     * コンストラクタ
     * 
     * @param requestDto リクエストDTO
     */
    public ParameterBuilder(Object requestDto) {

        this.requestEntity = new HttpEntity<Object>(requestDto, createCommonRequestHeader());
    }

    /**
     * パラメータビルド
     * 
     * @param requestDto リクエストDTO
     * @return リクエスト内容
     */
    public static ParameterBuilder build(Object requestDto) {

        if (requestDto instanceof RequestBodyDto) {

            ((RequestBodyDto) requestDto).setCommonRequestHeader(createRequestBody());
        }

        return new ParameterBuilder(requestDto);
    }

    /**
     * 共通リクエストヘッダー作成
     * 
     * @return 共通リクエストヘッダー
     */
    private HttpHeaders createCommonRequestHeader() {

        // ヘッダー設定
        HttpHeaders requestHeaders = new HttpHeaders();

        // 取引ID取得
        String transactionID = RequestHeaderContext.getInstance().getTransactionID();

        // 取引ID設定
        requestHeaders.add("transactionID", transactionID);

        return requestHeaders;
    }

    /**
     * 共通リクエストボディ作成
     * 
     * @param requestDto リクエストDTO
     * @return 共通リクエストボディ
     */
    private static CommonRequestBodyOfHeaderDto createRequestBody() {

        // 金融機関コード
        String bankCode = Constant.FIXED_VALUE_FINANCIAL_CODE;
        // ユーザーID
        String userID = RequestHeaderContext.getInstance().getUserIdToken();
        // アプリケーションID
        String applicationID = RequestHeaderContext.getInstance().getApplicationId();
        // クライアントID
        String clientId = Constant.FIXED_VALUE_CLIENT_ID;
        // 端末ID
        String deviceId = RequestHeaderContext.getInstance().getDeviceId();

        // 共通リクエスト・ボディ
        CommonRequestBodyOfHeaderDto commonRequestBodyOfHeaderDto = new CommonRequestBodyOfHeaderDto();
        // 金融機関コード設定
        commonRequestBodyOfHeaderDto.setBankCode(bankCode);
        // ユーザーID設定
        commonRequestBodyOfHeaderDto.setUserID(userID);
        // アプリケーションID設定
        commonRequestBodyOfHeaderDto.setApplicationID(applicationID);
        // クライアントID設定
        commonRequestBodyOfHeaderDto.setClientID(clientId);
        // 端末ID設定
        commonRequestBodyOfHeaderDto.setDeviceID(deviceId);

        return commonRequestBodyOfHeaderDto;
    }

}

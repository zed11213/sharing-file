package jp.co.jsbank.mobile.bff.controller;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jp.co.jsbank.mobile.bff.common.JsonResult;
import jp.co.jsbank.mobile.bff.dto.CardDesignSelectionRequestDto;
import jp.co.jsbank.mobile.bff.dto.CcIssuingApplicationInformationResponseDto;
import jp.co.jsbank.mobile.bff.dto.CcIssuingRequestDto;
import jp.co.jsbank.mobile.bff.dto.CcPasswordIbPasswordSettingRequestDto;
import jp.co.jsbank.mobile.bff.dto.EmailAddressAuthorizationRequestDto;
import jp.co.jsbank.mobile.bff.dto.IdentificationRequestDto;
import jp.co.jsbank.mobile.bff.dto.IvrAuthenticationRequestDto;
import jp.co.jsbank.mobile.bff.service.CashCardIssueService;

/**
 * キャッシュカード発行コントロール
 */
@RestController
public class CashCardIssueController {

	@Resource
	private CashCardIssueService cashcardIssueService;

	// private Logger logger =
	// LoggerFactory.getLogger(CashCardIssueController.class);

	/**
	 * 復元処理
	 *
	 * @param receptionNumber 受付番号
	 * @return CC発行申込情報
	 */

	@GetMapping(path = "/cashcard-issue/AB0801")
	public JsonResult getRecoveryProcess(@RequestParam String receptionNumber) {

		CcIssuingApplicationInformationResponseDto responseDto = cashcardIssueService
				.getRecoveryProcess(receptionNumber);

		return JsonResult.success(responseDto);
	}

	/**
	 * CC暗証番号
	 *
	 * @param requestDto CC暗証番号・IBパスワード設定BFFリクエストDTO
	 * 
	 * 
	 * @return 処理結果
	 * @throws Exception 
	 */

	@PostMapping(path = "/cashcard-issue/AB0802")
	public JsonResult ccPasswordIbPasswordSetting(@RequestBody CcPasswordIbPasswordSettingRequestDto requestDto) throws Exception {

		String result = cashcardIssueService.ccPasswordIbPasswordSetting(requestDto);

		return JsonResult.success(result);
	}

	/**
	 * カードデザイン選択
	 *
	 * @param requestDto カードデザイン選択リクエストDTO
	 * @return 処理結果
	 */

	@PostMapping(path = "/cashcard-issue/AB0803")
	public JsonResult cardDesignSelection(@RequestBody CardDesignSelectionRequestDto requestDto) {

		String response = cashcardIssueService.cardDesignSelection(requestDto);

		return JsonResult.success(response);
	}

	/**
	 * CC発行依頼
	 *
	 * @param requestDto CC発行依頼リクエストDTO
	 * @return 処理結果
	 */

	@PostMapping(path = "/cashcard-issue/AB0804")
	public JsonResult getCcIssuing(@RequestBody CcIssuingRequestDto requestDto) {

		String response = cashcardIssueService.getCcIssuing(requestDto);

		return JsonResult.success(response);
	}

	/**
	 * 本人確認
	 *
	 * @param requestDto 本人確認リクエストDTO
	 * @return JsonResult
	 */
	@PostMapping(path = "/cashcard-issue/AB0805")
	public JsonResult identityVerification(@RequestBody IdentificationRequestDto requestDto) {
		String result = cashcardIssueService.identityVerification(requestDto);
		return JsonResult.success(result);
	}
	

    /**
     * メールアドレス認証
     *
     * @param requestDto メールアドレス認証リクエストDTO
     * @return JsonResult
     */
    @PostMapping(path = "/cashcard-issue/AB0807")
    public JsonResult emailAddressAuthorization(@RequestBody EmailAddressAuthorizationRequestDto requestDto) {
        List<String> result = cashcardIssueService.emailAddressAuthorization(requestDto);
        return JsonResult.success(result);
    }

    /**
     * IVR認証
     *
     * @param requestDto IVR認証リクエストDTO
     * @return JsonResult
     */
    @PostMapping(path = "/cashcard-issue/AB0808")
    public JsonResult ivrAuthentication(@RequestBody IvrAuthenticationRequestDto requestDto) {
        String result = cashcardIssueService.ivrAuthentication(requestDto);
        return JsonResult.success(result);
    }

    /**
     * IVR確認
     *
     * @param requestDto IVR確認リクエストDTO
     * @return JsonResult
     */
    @PostMapping(path = "/cashcard-issue/AB0809")
    public JsonResult identityVerification(IvrAuthenticationRequestDto requestDto) {
        String result = cashcardIssueService.identityVerification(requestDto);
        return JsonResult.success(result);
    }
}

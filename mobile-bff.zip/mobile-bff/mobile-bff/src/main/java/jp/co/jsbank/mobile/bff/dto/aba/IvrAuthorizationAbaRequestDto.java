package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * IVR認証ABAリクエストDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class IvrAuthorizationAbaRequestDto extends RequestBodyDto {

    /**
     * 利用者ID
     */
    private String userId;

    /**
     * 受付番号
     */
    private String receiptNumber;

    /**
     * OTP
     */
    private String ivrOTP;

    /**
     * 認証TRXキー
     */
    private String verifyTRXKey;
}

package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 利用口座削除ABAリクエストDTO
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class DeleteUseAccountAbaRequestDto  extends RequestBodyDto {

    /**
     * 顧客ID
     */
    private String customerId;

    /**
     * CIF番号
     */
    private String cifNo;

}

package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * 定期預金明細DTO
 */
@Data
public class TimeDepositDetailsDto {

	/**
	 * 明細ID
	 */
	private String detailId;

	/**
	 * サブNO
	 */
	private String subNumber;

	/**
	 * 種類（コード）
	 */
	private String typeCode;

	/**
	 * 元帳残高
	 */
	private String balanceOfLedger;

	/**
	 * 利率
	 */
	private String interestRate;

	/**
	 * 課税区分（文言）
	 */
	private String taxClassName;

	/**
	 * 満期日
	 */
	private String maturityDate;

	/**
	 * 期間（月数)
	 */
	private String periodCodeValue;

	/**
	 * 利息受取方法
	 */
	private String interestReceivingMethod;

	/**
	 * 懸賞金区分（文言）
	 */
	private String rewardAmountTypeValue;

	/**
	 * 利息受取預金種目
	 */
	private String interestReceiveAccountType;

	/**
	 * 利息受取口座番号
	 */
	private String irAccountNumber;

	/**
	 * 契約日
	 */
	private String contractDate;

	/**
	 * お取引区分
	 */
	private String transactionClassification;

	/**
	 * 明細概要メモ
	 */
	private String memo;

	/**
	 * 抽選回数
	 */
	private String lotteryTimes;

	/**
	 * 取扱組
	 */
	private String handlingGroup;

	/**
	 * 開始抽選番号
	 */
	private String lotteryNoStart;

	/**
	 * 終了抽選番号
	 */
	private String lotteryNoEnd;

	/**
	 * 抽選日
	 */
	private String lotteryDate;

	/**
	 * 店番
	 */
	private String branchNumber;

	/**
	 * 当初金額
	 */
	private String startAmoun;

	/**
	 * スーパードリーム等スーパー定期種類
	 */
	private String superRegularType;

}

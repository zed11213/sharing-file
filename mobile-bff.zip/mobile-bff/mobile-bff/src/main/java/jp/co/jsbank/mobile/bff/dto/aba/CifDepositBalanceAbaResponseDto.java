package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.AccountInfosDto;
import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * CIF預金残高一覧照会レスポンスDTO
 */
@Data
public class CifDepositBalanceAbaResponseDto {

    /**
     * 共通レスポンス・ヘッダ
     */
    private CommonResponseHeader commonResponseHeader;
    
    /**
     * 口座情報DTO
     */
    private List<AccountInfosDto> accountInfo;
}

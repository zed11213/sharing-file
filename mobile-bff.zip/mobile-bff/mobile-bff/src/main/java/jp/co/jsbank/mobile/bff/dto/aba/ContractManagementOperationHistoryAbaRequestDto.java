package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * 契約管理操作履歴ABAリクエストDTO
 */
@Data
public class ContractManagementOperationHistoryAbaRequestDto {

    /**
     * 受付番号
     */
    private String receiptNumber;

}

package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * かんたん受付回答詳細照会ABAリクエストDTO
 */
@Data
public class EasyReceptionAnswerDetailInquiryAbaRequestDto {

    /**
     * お知らせID
     */
    private String anncmntId;

    /**
     * 申込ID
     */
    private String applyId;

    /**
     * 回答ID
     */
    private String responseId;
}

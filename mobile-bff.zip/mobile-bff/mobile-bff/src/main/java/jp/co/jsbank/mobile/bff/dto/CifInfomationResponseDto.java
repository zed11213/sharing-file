package jp.co.jsbank.mobile.bff.dto;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.aba.CifInfomationDto;
import lombok.Data;

/**
 * CIF情報取得レスポンスDTO
 */
@Data
public class CifInfomationResponseDto {
    
    /**
     * CIF情報DTOリスト
     */
    private List<CifInfomationDto> cifInfomationDtoList;

}

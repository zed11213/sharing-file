package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 実質的支配者DTO
 */
@Data
public class BeneficialOwnerDto {

    /**
     * 支配者氏名カナ（姓）
     */
    private String rulerKanaLast;

    /**
     * 支配者氏名カナ（名）
     */
    private String rulerKanaFirst;

    /**
     * 支配者氏名漢字（姓）
     */
    private String rulerKanjiLast;

    /**
     * 支配者氏名漢字（名）
     */
    private String rulerKanjiFirst;

    /**
     * 支配者生年月日
     */
    private String rulerBirth;

    /**
     * 支配者郵便番号
     */
    private String rulerZipCode;

    /**
     * 支配者都道府県（カナ）
     */
    private String rulerStateKana;

    /**
     * 支配者都道府県
     */
    private String rulerState;

    /**
     * 支配者市区町村（カナ）
     */
    private String rulerCityKana;

    /**
     * 支配者市区町村
     */
    private String rulerCity;

    /**
     * 支配者丁目（カナ）
     */
    private String rulerStreetKana;

    /**
     * 支配者丁目
     */
    private String rulerStreet;

    /**
     * 支配者番地（カナ）
     */
    private String rulerAddressKana;

    /**
     * 支配者番地
     */
    private String rulerAddress;

    /**
     * 支配者建物名・号室（カナ）
     */
    private String rulerBuildingKana;

    /**
     * 支配者建物名・号室
     */
    private String rulerBuilding;

}

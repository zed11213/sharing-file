package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 端末とJBAIDの紐づけリクエストDTO
 */
@Data
public class JagBodyLinkAuthUserRequestDto {

    /**
     * デバイスID
     */
    private String jagDeviceId;

    /**
     * アプリケーションID
     */
    private String jagApplicationId;

    /**
     * JBAID
     */
    private String jagJbaId;

    /**
     * USERID
     */
    private String jagUserId;

    /**
     * LINK or UNLINK. 0: UNLINK(紐づけ解除), 1: LINK(紐づる), 9: UNLINK FORCE(強制リンク解除).
     * 2022.04.14 Manabu Hanzaike.
     * jagDoLink=0では、JBAID, USERIDの一致を検査すること.
     * jagDoLink=9では、JBAID, USERIDの検査は不要で即時でリンク解除とする.
     */
    private int jagDoLink;

    /**
     * TRX種別. JAG-TCC: TCCによるTRX補償, JAG-NRM: 即時反映(TRX補償なし)
     */
    private String jagTrxType;

    /**
     * トランザクションID
     */
    private String jagTrxId;

}

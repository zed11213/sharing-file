package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 口座情報リクエストDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class AccountInformationAbaRequestDto extends RequestBodyDto  {

    /**
     * CIF番号
     */
    private String cifNumber;

    /**
     * 店番
     */
    private String branchCode;

    /**
     * 顧客ID
     */
    private String customerId;
}

package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import jp.co.jsbank.mobile.bff.dto.DepartmentStoreDto;
import lombok.Data;

/**
 * 部店リストレスポンスDTO
 */
@Data
public class DepartmentStoreAbaResponseDto {

    /**
     * 共通レスポンス・ヘッダ
     */
    private CommonResponseHeader commonResponseHeader;

    /**
     * レスポンス・ボディ
     */
    private List<DepartmentStoreDto> branchListByBusArea;
}

package jp.co.jsbank.mobile.bff.logic.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.codec.binary.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.jsbank.mobile.bff.config.RestClientConfig;
import jp.co.jsbank.mobile.bff.dto.AccountInformationDto;
import jp.co.jsbank.mobile.bff.dto.AccountInfosDto;
import jp.co.jsbank.mobile.bff.dto.UserInformationDetailsDto;
import jp.co.jsbank.mobile.bff.dto.aba.AccountInformationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.AccountInformationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.AccountRegistrationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.AuthenticationKeyIssuanceAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.BranchDetailDisplayAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.BranchDetailDisplayAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CifDepositBalanceAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CifDepositBalanceAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CifInfomationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CifInfomationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CifInfomationDto;
import jp.co.jsbank.mobile.bff.dto.aba.CommonHeaderAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CurrentAccountAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.DeleteUseAccountAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.DepositsAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.EmailAddAuthorizationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.EmailAddChangingAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.NotificationDepositBalanceInquiryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.NotificationSettingAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.NotificationSettingAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.PassbooklesSettingAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.RegularProvidentFundAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.SavingsAccountsAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.SettingInfoDto;
import jp.co.jsbank.mobile.bff.dto.aba.StopTradingAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.TaxReserveDepositAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.UpdateDesignInfomationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.UseAccountRegistrationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.UseAccountRegistrationConfirmationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.UserAttributeInfoDto;
import jp.co.jsbank.mobile.bff.dto.aba.UserAttributeInquiryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.UserDataAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.UserElementUpdateAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.UserInformationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.UserSettingDetailsAbaResponseDto;
import jp.co.jsbank.mobile.bff.logic.VariousRegistrationPreferenceLogic;

/**
 * 各種登録設定ロジック実装クラス
 */
@Service
public class VariousRegistrationPreferenceLogicImpl implements VariousRegistrationPreferenceLogic {

    @Autowired
    RestClientConfig restClientConfig;

    /**
     * 通知設定情報取得
     *
     * @param userId 利用者ID
     * @return 通知設定情報レスポンスDTO
     */
    @Override
    public NotificationSettingAbaResponseDto getNotificationSetting(String userId) {

        // // TODO リクエストパラメータ
        // ParameterBuilder parameterDto = ParameterBuilder.build(userId);
        //
        // // CIF情報取得APIを呼び出す
        // RestTemplate restTemplate = restClientConfig.simpleRestTemplate();
        // CifInfomationAbaResponseDto response = restTemplate.getForObject("/customer/v1.3.0/userinfo/inquiry",
        // CifInfomationAbaResponseDto.class, parameterDto);
        List<SettingInfoDto> list = new ArrayList<>();
        // Dummyデータ
        SettingInfoDto settingInfoDto = new SettingInfoDto();
        settingInfoDto.setSettingType("01");
        settingInfoDto.setSettingDivision("00");
        settingInfoDto.setSettingContent("1");

        SettingInfoDto settingInfoDto2 = new SettingInfoDto();
        settingInfoDto2.setSettingType("02");
        settingInfoDto2.setSettingDivision("01");
        settingInfoDto2.setSettingContent("2");
        list.add(settingInfoDto);
        list.add(settingInfoDto2);

        NotificationSettingAbaResponseDto responseDto = new NotificationSettingAbaResponseDto();
        responseDto.setSettingInfos(list);

        return responseDto;
    }

    /**
     * 通知設定情報変更
     *
     * @param abaRequestDto 通知設定ABAリクエストDTO
     * @return 共通レスポンスヘッダー
     */
    @Override
    public CommonHeaderAbaResponseDto
            changeNotificationSettingresultnfo(NotificationSettingAbaRequestDto abaRequestDto) {

        // // TODO リクエストパラメータ
        // ParameterBuilder parameterDto = ParameterBuilder.build(abaRequestDto);
        //
        // // CIF情報取得APIを呼び出す
        // RestTemplate restTemplate = restClientConfig.simpleRestTemplate();
        // CommonResponseHeader response = restTemplate.getForObject("/customer/v1.3.0/userinfo/update",
        // CommonResponseHeader.class, parameterDto);

        // Dummyデータ
        return new CommonHeaderAbaResponseDto();
    }

    /**
     * 利用口座削除
     *
     * @param abaRequestDto 通知設定ABAリクエストDTO
     * @return 処理結果
     */
    @Override
    public CommonHeaderAbaResponseDto deleteUseAccount(DeleteUseAccountAbaRequestDto abaRequestDto) {

        // // TODO リクエストパラメータ
        // ParameterBuilder parameterDto = ParameterBuilder.build(abaRequestDto);
        //
        // // CIF情報取得APIを呼び出す
        // RestTemplate restTemplate = restClientConfig.simpleRestTemplate();
        // CommonResponseHeader response = restTemplate.getForObject("/customer/v1.3.0/userinfo/update",
        // CommonResponseHeader.class, parameterDto);

        // Dummyデータ
        return new CommonHeaderAbaResponseDto();
    }

    /**
     * デザイン取得
     *
     * @param userId 利用者ID
     * @return 設定済みデザイン情報
     */
    @Override
    public UserAttributeInquiryAbaResponseDto getDesignInfomation(String userId) {

        // // TODO リクエストパラメータ
        // ParameterBuilder parameterDto = ParameterBuilder.build(userId);
        //
        // // CIF情報取得APIを呼び出す
        // RestTemplate restTemplate = restClientConfig.simpleRestTemplate();
        // CommonResponseHeader response = restTemplate.getForObject("/customer/v1.3.0/userinfo/update",
        // CommonResponseHeader.class, parameterDto);

        // TODO dummyデータ
        SettingInfoDto infoDto = new SettingInfoDto();
        infoDto.setSettingType("03");
        infoDto.setSettingContent("0");

        UserAttributeInfoDto dto = new UserAttributeInfoDto();
        dto.setSettingInfos(Arrays.asList(infoDto));
        UserAttributeInquiryAbaResponseDto response = new UserAttributeInquiryAbaResponseDto();
        response.setUserInfoList(Arrays.asList(dto));

        return response;
    }

    /**
     * メールアドレス登録
     *
     * @param abaRequestDto メールアドレス登録ABAリクエストDTO
     * @return メールアドレス登録AbaレスポンスDTO
     */
    @Override
    public CommonHeaderAbaResponseDto emailAddChangingAba(EmailAddChangingAbaRequestDto abaRequestDto) {
        // // TODO リクエストパラメータ
        // ParameterBuilder parameterDto = ParameterBuilder.build(abaRequestDto);

        // EmailAddChangingAbaResponseDto responseDto = new EmailAddChangingAbaResponseDto();
        //
        // responseDto.setConfirmationCode("1");
        // responseDto.setNoVerifyTRXKey("02");
        return new CommonHeaderAbaResponseDto();
    }

    /**
     * メールアドレス認証
     *
     * @param abaRequestDto メールアドレス認証ABAリクエストDTO
     * @return メールアドレス認証AbaレスポンスDTO
     */
    @Override
    public CommonHeaderAbaResponseDto emailAddAuthorizationAba(EmailAddAuthorizationAbaRequestDto abaRequestDto) {
        // // TODO リクエストパラメータ
        // ParameterBuilder parameterDto = ParameterBuilder.build(abaRequestDto)
        return new CommonHeaderAbaResponseDto();
    }

    /**
     * 利用者属性更新
     *
     * @param userElementUpdateAbaRequestDto メールアドレス登録ABAリクエストDTO
     * @return メールアドレス認証AbaレスポンスDTO
     */
    @Override
    public CommonHeaderAbaResponseDto
            userElementUpdateAba(UserElementUpdateAbaRequestDto userElementUpdateAbaRequestDto) {
        // TODO 自動生成されたメソッド・スタブ

        // // TODO リクエストパラメータ
        // ParameterBuilder parameterDto = ParameterBuilder.build(userElementUpdateAbaRequestDto);

        return new CommonHeaderAbaResponseDto();
    }

    /**
     * 利用者属性更新
     *
     * @param userInformationAbaRequestDto 利用者情報ABAリクエストDTO
     * @return 利用者情報AbaレスポンスDTO
     */
    @Override
    public CommonHeaderAbaResponseDto userInformationAba(UserInformationAbaRequestDto userInformationAbaRequestDto) {
        // TODO リクエストパラメータ
        // ParameterBuilder parameterDto = ParameterBuilder.build(userInformationAbaRequestDto);

        return new CommonHeaderAbaResponseDto();
    }

    /**
     * 認証キー発行
     *
     * @param userDataAbaRequestDto 利用者情報ABAレスボスDto
     * @return 認証キー発行AbaレスポンスDTO
     */
    @Override
    public AuthenticationKeyIssuanceAbaResponseDto
            authenticationKeyIssuanceAba(UserDataAbaRequestDto userDataAbaRequestDto) {
        // TODO リクエストパラメータ
        // ParameterBuilder parameterDto = ParameterBuilder.build(userInformationAbaRequestDto);

        AuthenticationKeyIssuanceAbaResponseDto authenticationKeyIssuanceAbaResponseDto = new AuthenticationKeyIssuanceAbaResponseDto();

        authenticationKeyIssuanceAbaResponseDto.setAuthenticationKey("619874198164");
        authenticationKeyIssuanceAbaResponseDto.setExpiryDateTime("2013-11-17T11:59:22+08:00");

        return authenticationKeyIssuanceAbaResponseDto;
    }

    /**
     * デザイン更新
     *
     * @param abaRequestDto デザイン更新ABAリクエストDTO
     * @return 処理結果
     */
    @Override
    public CommonHeaderAbaResponseDto updateDesignInfomation(UpdateDesignInfomationAbaRequestDto abaRequestDto) {

        // TODO リクエストパラメータ
        // ParameterBuilder parameterDto = ParameterBuilder.build(abaRequestDto);

        return new CommonHeaderAbaResponseDto();
    }

    /**
     * 法人利用者情報一覧取得
     *
     * @param jbaIdToken JBAID
     * @return 利用者情報
     */
    public UserSettingDetailsAbaResponseDto getJuridicalPersonUserDetails(String jbaIdToken) {
        // Dummyデータ
        UserInformationDetailsDto dto1 = new UserInformationDetailsDto();
        /**
         * 顧客ID
         */
        dto1.setCustomerId("751379d32843460090a4905b742a0d0d");

        /**
         * 利用者ID
         */
        dto1.setUserId("a2C4e6G8i9K1m3O50000");

        /**
         * 利用者区分
         */
        dto1.setUserType("0");

        /**
         * ステータス
         */
        dto1.setStatus("0");

        /**
         * 漢字氏名
         */
        dto1.setCustomerKanjiName("羽生");

        /**
         * カナ氏名
         */
        dto1.setCustomerName("ハニュ");

        /**
         * 所属
         */
        dto1.setDivision("BC01");

        /**
         * メールアドレス
         */
        dto1.setMailAddress("122623777＠qq.com");

        /**
         * 事業先利用者認証キー
         */
        dto1.setCertKey("619874198164");
        // /**
        // * 設定情報DTOリスト
        // */
        // List<SettingInfoDto> list1 = new ArrayList<>();
        //
        // SettingInfoDto settingInfoDto1 = new SettingInfoDto();
        // settingInfoDto1.setSettingType("03");
        // settingInfoDto1.setSettingDivision("00");
        // settingInfoDto1.setSettingContent("1");
        // list1.add(settingInfoDto1);
        // dto1.setSettingInfos(list1);

        UserInformationDetailsDto dto2 = new UserInformationDetailsDto();
        /**
         * 顧客ID
         */
        dto2.setCustomerId("851379d32843460090a4905b742a0d0d");

        /**
         * 利用者ID
         */
        dto2.setUserId("a2C4e6G8i9K1m3O50000");

        /**
         * 利用者区分
         */
        dto2.setUserType("2");

        /**
         * ステータス
         */
        dto2.setStatus("1");

        /**
         * 漢字氏名
         */
        dto2.setCustomerKanjiName("結弦");

        /**
         * カナ氏名
         */
        dto2.setCustomerName("ユヅル");

        /**
         * 所属
         */
        dto2.setDivision("BC02");

        /**
         * メールアドレス
         */
        dto2.setMailAddress("1766665555@163.com");

        /**
         * 事業先利用者認証キー
         */
        dto2.setCertKey("619874198165");
        UserInformationDetailsDto dto3 = new UserInformationDetailsDto();
        /**
         * 顧客ID
         */
        dto3.setCustomerId("851379d32843460090a4905b742a0d0d");

        /**
         * 利用者ID
         */
        dto3.setUserId("a2C4e6G8i9K1m3O50000");

        /**
         * 利用者区分
         */
        dto3.setUserType("2");

        /**
         * ステータス
         */
        dto3.setStatus("2");

        /**
         * 漢字氏名
         */
        dto3.setCustomerKanjiName("結弦");

        /**
         * カナ氏名
         */
        dto3.setCustomerName("ユヅル");

        /**
         * 所属
         */
        dto3.setDivision("BC02");

        /**
         * メールアドレス
         */
        dto3.setMailAddress("1766665555@163.com");

        /**
         * 事業先利用者認証キー
         */
        dto3.setCertKey("619874198165");

        List<UserInformationDetailsDto> list = new ArrayList<>();

        list.add(dto1);
        list.add(dto2);
        list.add(dto3);

        UserSettingDetailsAbaResponseDto response = new UserSettingDetailsAbaResponseDto();
        response.setUserInfoList(list);

        return response;
    }

    /**
     * CIF情報取得
     *
     * @return CIF情報
     */
    @Override
    public CifInfomationAbaResponseDto getCifInfomation(CifInfomationAbaRequestDto requestDto) {
        // Dummyデータ
        List<CifInfomationDto> dtoList = new ArrayList<CifInfomationDto>();
        CifInfomationDto dto1 = new CifInfomationDto();

        // CIF番号
        dto1.setCifNumber("001");
        // 通帳レス設定状態
        dto1.setPassbookLessSettingStatus("0");
        // 初回登録フラグ
        dto1.setRegisterFlg("0");
        // 店番
        dto1.setBranchCode("001");

        CifInfomationDto dto2 = new CifInfomationDto();

        // CIF番号
        dto2.setCifNumber("002");
        // 初回登録フラグ
        dto2.setRegisterFlg("0");
        // 店番
        dto2.setBranchCode("002");
        // 通帳レス設定状態
        dto2.setPassbookLessSettingStatus("0");
        CifInfomationDto dto3 = new CifInfomationDto();

        // CIF番号
        dto3.setCifNumber("003");
        // 初回登録フラグ
        dto3.setRegisterFlg("0");
        // 店番
        dto3.setBranchCode("003");
        // 通帳レス設定状態
        dto3.setPassbookLessSettingStatus("0");
        CifInfomationDto dto4 = new CifInfomationDto();

        // CIF番号
        dto4.setCifNumber("004");
        // 初回登録フラグ
        dto4.setRegisterFlg("0");
        // 店番
        dto4.setBranchCode("004");
        // 通帳レス設定状態
        dto4.setPassbookLessSettingStatus("0");
        CifInfomationDto dto5 = new CifInfomationDto();

        // CIF番号
        dto5.setCifNumber("005");
        // 初回登録フラグ
        dto5.setRegisterFlg("0");
        // 店番
        dto5.setBranchCode("005");
        // 通帳レス設定状態
        dto5.setPassbookLessSettingStatus("0");
        CifInfomationDto dto6 = new CifInfomationDto();

        // CIF番号
        dto6.setCifNumber("006");
        // 初回登録フラグ
        dto6.setRegisterFlg("0");
        // 店番
        dto6.setBranchCode("006");
        // 通帳レス設定状態
        dto6.setPassbookLessSettingStatus("0");
        CifInfomationDto dto7 = new CifInfomationDto();
        // CIF番号
        dto7.setCifNumber("007");
        // 通帳レス設定状態
        dto7.setPassbookLessSettingStatus("0");
        // 初回登録フラグ
        dto7.setRegisterFlg("0");
        // 店番
        dto7.setBranchCode("001");

        CifInfomationDto dto8 = new CifInfomationDto();

        // CIF番号
        dto8.setCifNumber("008");
        // 通帳レス設定状態
        dto8.setPassbookLessSettingStatus("0");
        // 初回登録フラグ
        dto8.setRegisterFlg("0");
        // 店番
        dto8.setBranchCode("002");

        CifInfomationDto dto9 = new CifInfomationDto();

        // CIF番号
        dto9.setCifNumber("009");
        // 通帳レス設定状態
        dto9.setPassbookLessSettingStatus("0");
        // 初回登録フラグ
        dto9.setRegisterFlg("0");
        // 店番
        dto9.setBranchCode("003");

        CifInfomationDto dto10 = new CifInfomationDto();

        // CIF番号
        dto10.setCifNumber("010");
        // 通帳レス設定状態
        dto10.setPassbookLessSettingStatus("0");
        // 初回登録フラグ
        dto10.setRegisterFlg("0");
        // 店番
        dto10.setBranchCode("004");

        CifInfomationDto dto11 = new CifInfomationDto();

        // CIF番号
        dto11.setCifNumber("011");
        // 通帳レス設定状態
        dto11.setPassbookLessSettingStatus("0");
        // 初回登録フラグ
        dto11.setRegisterFlg("0");
        // 店番
        dto11.setBranchCode("005");

        CifInfomationDto dto12 = new CifInfomationDto();

        // CIF番号
        dto12.setCifNumber("012");
        // 通帳レス設定状態
        dto12.setPassbookLessSettingStatus("0");
        // 初回登録フラグ
        dto12.setRegisterFlg("0");
        // 店番
        dto12.setBranchCode("006");

        dtoList.add(dto1);
        dtoList.add(dto2);
        dtoList.add(dto3);
        dtoList.add(dto4);
        dtoList.add(dto5);
        dtoList.add(dto6);
        dtoList.add(dto7);
        dtoList.add(dto8);
        dtoList.add(dto9);
        dtoList.add(dto10);
        dtoList.add(dto11);
        dtoList.add(dto12);

        dtoList.add(dto1);
        dtoList.add(dto2);
        dtoList.add(dto3);
        dtoList.add(dto4);
        dtoList.add(dto5);
        dtoList.add(dto6);
        dtoList.add(dto7);
        dtoList.add(dto8);
        dtoList.add(dto9);
        dtoList.add(dto10);
        dtoList.add(dto11);
        dtoList.add(dto12);

        CifInfomationAbaResponseDto response = new CifInfomationAbaResponseDto();
        response.setCifInfomationDtoList(dtoList);
        return response;
    }

    /**
     * 口座情報取得
     *
     * @param branchCode 店番
     * @param cifNumber CIF番号
     * @return 口座情報
     */
    @Override
    public AccountInformationAbaResponseDto getAccountInformation(AccountInformationAbaRequestDto requestDto) {
        // Dummyデータ
        AccountInformationDto dto1 = new AccountInformationDto();
        AccountInformationDto dto2 = new AccountInformationDto();
        List<AccountInformationDto> dtoList = new ArrayList<AccountInformationDto>();
        /**
         * 口座番号
         */
        dto1.setAccountNumber("123456");

        /**
         * 科目名
         */
        dto1.setSubjectNameValue("普通預金");

        /**
         * 口座番号
         */
        dto2.setAccountNumber("123459");

        /**
         * 科目名
         */
        dto2.setSubjectNameValue("当座預金");
        dtoList.add(dto1);
        dtoList.add(dto2);
        AccountInformationAbaResponseDto responseDto = new AccountInformationAbaResponseDto();
        responseDto.setAccountInformationList(dtoList);
        return responseDto;
    }

    /**
     * 普通預金残高情報取得
     * 
     * @param UseAccountRegistrationConfirmationAbaRequestDto
     *
     * @return 処理結果
     */
    @Override
    public SavingsAccountsAbaResponseDto
            getSavingsAccountsInfomation(UseAccountRegistrationConfirmationAbaRequestDto abaRequestDto) {
        SavingsAccountsAbaResponseDto responseDto = new SavingsAccountsAbaResponseDto();
        responseDto.setCifNumber("001");
        return responseDto;
    }

    /**
     * 通知預金残高情報取得
     * 
     * @param UseAccountRegistrationConfirmationAbaRequestDto
     *
     * @return 処理結果
     */
    @Override
    public NotificationDepositBalanceInquiryAbaResponseDto
            getNotificationDepositInfomation(UseAccountRegistrationConfirmationAbaRequestDto abaRequestDto) {
        NotificationDepositBalanceInquiryAbaResponseDto responseDto = new NotificationDepositBalanceInquiryAbaResponseDto();
        responseDto.setCifNumber("002");
        return responseDto;
    }

    /**
     * 定期預金残高情報取得
     * 
     * @param UseAccountRegistrationConfirmationAbaRequestDto
     *
     * @return 処理結果
     */
    @Override
    public DepositsAbaResponseDto getDepositsInfomation(UseAccountRegistrationConfirmationAbaRequestDto abaRequestDto) {
        DepositsAbaResponseDto responseDto = new DepositsAbaResponseDto();
        responseDto.setCifNumber("003");
        return responseDto;
    }

    /**
     * 定期積金残高情報取得
     * 
     * @param UseAccountRegistrationConfirmationAbaRequestDto
     *
     * @return 処理結果
     */
    @Override
    public RegularProvidentFundAbaResponseDto
            getRegularProvidentFundInfomation(UseAccountRegistrationConfirmationAbaRequestDto abaRequestDto) {
        RegularProvidentFundAbaResponseDto responseDto = new RegularProvidentFundAbaResponseDto();
        responseDto.setCifNumber("004");
        return responseDto;
    }

    /**
     * 納税準備預金残高情報取得
     * 
     * @param UseAccountRegistrationConfirmationAbaRequestDto
     *
     * @return 処理結果
     */
    @Override
    public TaxReserveDepositAbaResponseDto
            getTaxReserveDepositInfomation(UseAccountRegistrationConfirmationAbaRequestDto abaRequestDto) {
        TaxReserveDepositAbaResponseDto responseDto = new TaxReserveDepositAbaResponseDto();
        responseDto.setCifNumber("005");
        return responseDto;
    }

    /**
     * 当座預金残高情報取得
     * 
     * @param UseAccountRegistrationConfirmationAbaRequestDto
     *
     * @return 処理結果
     */
    @Override
    public CurrentAccountAbaResponseDto
            getCurrentAccountInfomation(UseAccountRegistrationConfirmationAbaRequestDto abaRequestDto) {
        CurrentAccountAbaResponseDto responseDto = new CurrentAccountAbaResponseDto();
        responseDto.setCifNumber("006");
        return responseDto;
    }

    /**
     * CIF預金残高一覧情報取得
     * 
     * @param CifDepositBalanceAbaRequestDto
     *
     * @return 処理結果
     */
    @Override
    public CifDepositBalanceAbaResponseDto
            getCifDepositBalanceInfomation(CifDepositBalanceAbaRequestDto abaRequestDto) {
        CifDepositBalanceAbaResponseDto responseDto = new CifDepositBalanceAbaResponseDto();
        AccountInfosDto dto = new AccountInfosDto();
        AccountInfosDto dto2 = new AccountInfosDto();
        List<AccountInfosDto> dtoList = new ArrayList<AccountInfosDto>();
        /**
         * 科目名
         */
        dto.setSubjectNameValue("普通預金");

        /**
         * 店番
         */
        dto.setBranchNumber("001");

        /**
         * 口座番号
         */
        dto.setAccountNumber("123456");

        /**
         * 科目名
         */
        dto2.setSubjectNameValue("当座預金");

        /**
         * 店番
         */
        dto2.setBranchNumber("002");
        /**
         * 口座番号
         */
        dto2.setAccountNumber("123457");
        // if (StringUtils.equals(abaRequestDto.getCifNumber(), "001")) {
        //
        // /**
        // * 科目名
        // */
        // dto.setSubjectNameValue("普通預金");
        //
        // /**
        // * 店番
        // */
        // dto.setBranchNumber("001");
        //
        // /**
        // * 口座番号
        // */
        // dto.setAccountNumber("123456");
        //
        // /**
        // * 科目名
        // */
        // dto2.setSubjectNameValue("当座預金");
        //
        // /**
        // * 店番
        // */
        // dto2.setBranchNumber("002");
        // /**
        // * 口座番号
        // */
        // dto2.setAccountNumber("123457");
        //
        // } else if (StringUtils.equals(abaRequestDto.getCifNumber(), "002")) {
        //
        // /**
        // * 科目名
        // */
        // dto.setSubjectNameValue("当座預金");
        //
        // /**
        // * 店番
        // */
        // dto.setBranchNumber("002");
        // /**
        // * 口座番号
        // */
        // dto.setAccountNumber("123458");
        //
        // /**
        // * 科目名
        // */
        // dto2.setSubjectNameValue("通知預金");
        //
        // /**
        // * 店番
        // */
        // dto2.setBranchNumber("003");
        // /**
        // * 口座番号
        // */
        // dto2.setAccountNumber("123459");
        //
        // } else if (StringUtils.equals(abaRequestDto.getCifNumber(), "003")) {
        //
        // /**
        // * 科目名
        // */
        // dto.setSubjectNameValue("通知預金");
        //
        // /**
        // * 店番
        // */
        // dto.setBranchNumber("003");
        // /**
        // * 口座番号
        // */
        // dto.setAccountNumber("123410");
        //
        // /**
        // * 科目名
        // */
        // dto2.setSubjectNameValue("納税準備預金");
        //
        // /**
        // * 店番
        // */
        // dto2.setBranchNumber("004");
        // /**
        // * 口座番号
        // */
        // dto2.setAccountNumber("113456");
        //
        // } else if (StringUtils.equals(abaRequestDto.getCifNumber(), "004")) {
        //
        // /**
        // * 科目名
        // */
        // dto.setSubjectNameValue("納税準備預金");
        //
        // /**
        // * 店番
        // */
        // dto.setBranchNumber("004");
        //
        // /**
        // * 口座番号
        // */
        // dto.setAccountNumber("12340013");
        //
        // /**
        // * 科目名
        // */
        // dto2.setSubjectNameValue("定期預金");
        //
        // /**
        // * 店番
        // */
        // dto2.setBranchNumber("005");
        //
        // /**
        // * 口座番号
        // */
        // dto2.setAccountNumber("123414");
        //
        // } else if (StringUtils.equals(abaRequestDto.getCifNumber(), "005")) {
        //
        // /**
        // * 科目名
        // */
        // dto.setSubjectNameValue("定期預金");
        //
        // /**
        // * 店番
        // */
        // dto.setBranchNumber("005");
        //
        // /**
        // * 口座番号
        // */
        // dto.setAccountNumber("123417");
        //
        // /**
        // * 科目名
        // */
        // dto2.setSubjectNameValue("定期積金");
        //
        // /**
        // * 店番
        // */
        // dto2.setBranchNumber("006");
        //
        // /**
        // * 口座番号
        // */
        // dto.setAccountNumber("123418");
        //
        // } else if (StringUtils.equals(abaRequestDto.getCifNumber(), "006")) {
        //
        // /**
        // * 科目名
        // */
        // dto.setSubjectNameValue("定期積金");
        //
        // /**
        // * 店番
        // */
        // dto.setBranchNumber("006");
        // /**
        // * 口座番号
        // */
        // dto.setAccountNumber("123419");
        //
        // } else if (StringUtils.equals(abaRequestDto.getCifNumber(), "007")) {
        //
        // /**
        // * 科目名
        // */
        // dto.setSubjectNameValue("普通預金");
        //
        // /**
        // * 店番
        // */
        // dto.setBranchNumber("007");
        // /**
        // * 口座番号
        // */
        // dto.setAccountNumber("1234510");
        //
        // } else if (StringUtils.equals(abaRequestDto.getCifNumber(), "008")) {
        //
        // /**
        // * 科目名
        // */
        // dto.setSubjectNameValue("納税準備預金");
        //
        // /**
        // * 店番
        // */
        // dto.setBranchNumber("008");
        // /**
        // * 口座番号
        // */
        // dto.setAccountNumber("123411");
        //
        // } else if (StringUtils.equals(abaRequestDto.getCifNumber(), "009")) {
        //
        // /**
        // * 科目名
        // */
        // dto.setSubjectNameValue("定期預金");
        // /**
        // * 店番
        // */
        // dto.setBranchNumber("009");
        // /**
        // * 口座番号
        // */
        // dto.setAccountNumber("123412");
        //
        // } else if (StringUtils.equals(abaRequestDto.getCifNumber(), "010")) {
        //
        // /**
        // * 科目名
        // */
        // dto.setSubjectNameValue("定期積金");
        // /**
        // * 店番
        // */
        // dto.setBranchNumber("010");
        // /**
        // * 口座番号
        // */
        // dto.setAccountNumber("123416");
        // } else if (StringUtils.equals(abaRequestDto.getCifNumber(), "011")) {
        //
        // /**
        // * 科目名
        // */
        // dto.setSubjectNameValue("納税準備預金");
        //
        // /**
        // * 店番
        // */
        // dto.setBranchNumber("011");
        // /**
        // * 口座番号
        // */
        // dto.setAccountNumber("123418");
        //
        // } else if (StringUtils.equals(abaRequestDto.getCifNumber(), "012")) {
        //
        // /**
        // * 科目名
        // */
        // dto.setSubjectNameValue("定期積金");
        // /**
        // * 店番
        // */
        // dto.setBranchNumber("012");
        // /**
        // * 口座番号
        // */
        // dto.setAccountNumber("11444");
        // }

        dtoList.add(dto);
        dtoList.add(dto2);
        responseDto.setAccountInfo(dtoList);
        return responseDto;
    }

    /**
     * 支店詳細情報取得
     * 
     * @param BranchDetailDisplayAbaRequestDto
     *
     * @return 処理結果
     */
    @Override
    public BranchDetailDisplayAbaResponseDto
            getBranchDetailDisplayInfomation(BranchDetailDisplayAbaRequestDto abaRequestDto) {
        BranchDetailDisplayAbaResponseDto responseDto = new BranchDetailDisplayAbaResponseDto();
        String branchNumber = abaRequestDto.getBranchNumber();
        if (StringUtils.equals(branchNumber, "001")) {
            /**
             * 店名（漢字）
             */
            responseDto.setBranchKanjiName("五反田");
        } else if (StringUtils.equals(branchNumber, "002")) {
            /**
             * 店名（漢字）
             */
            responseDto.setBranchKanjiName("五反田2");
        } else if (StringUtils.equals(branchNumber, "003")) {
            /**
             * 店名（漢字）
             */
            responseDto.setBranchKanjiName("五反田3");
        } else if (StringUtils.equals(branchNumber, "004")) {
            /**
             * 店名（漢字）
             */
            responseDto.setBranchKanjiName("五反田4");
        } else if (StringUtils.equals(branchNumber, "005")) {

            /**
             * 店名（漢字）
             */
            responseDto.setBranchKanjiName("五反田5");
        } else if (StringUtils.equals(branchNumber, "006")) {
            /**
             * 店名（漢字）
             */
            responseDto.setBranchKanjiName("五反田6");
        } else if (StringUtils.equals(branchNumber, "007")) {
            /**
             * 店名（漢字）
             */
            responseDto.setBranchKanjiName("五反田7");
        } else if (StringUtils.equals(branchNumber, "008")) {
            /**
             * 店名（漢字）
             */
            responseDto.setBranchKanjiName("五反田8");
        } else if (StringUtils.equals(branchNumber, "009")) {
            /**
             * 店名（漢字）
             */
            responseDto.setBranchKanjiName("五反田9");
        } else if (StringUtils.equals(branchNumber, "010")) {
            /**
             * 店名（漢字）
             */
            responseDto.setBranchKanjiName("五反田10");
        } else if (StringUtils.equals(branchNumber, "011")) {
            /**
             * 店名（漢字）
             */
            responseDto.setBranchKanjiName("五反田11");
        } else if (StringUtils.equals(branchNumber, "012")) {
            /**
             * 店名（漢字）
             */
            responseDto.setBranchKanjiName("五反田12");
        }
        return responseDto;
    }

    /**
     * 利用口座登録情報取得
     *
     * @param UseAccountRegistrationAbaRequestDto
     * @return 処理結果
     */
    @Override
    public AccountRegistrationAbaResponseDto getCifInformation(UseAccountRegistrationAbaRequestDto requestDto) {
        AccountRegistrationAbaResponseDto responseDto = new AccountRegistrationAbaResponseDto();
        // CIF番号
        responseDto.setCifNumber("001");
        return responseDto;
    }

    /**
     * CIF情報取得
     *
     * @param requestDto CIF情報取得リクエストDTO
     * @return CIF情報取得レスポンスDTO
     */
    @Override
    public CifInfomationAbaResponseDto getGifInfomation(CifInfomationAbaRequestDto requestDto) {
        CifInfomationAbaResponseDto responseDto = new CifInfomationAbaResponseDto();
        // Dummyデータ
        List<CifInfomationDto> dtoList = new ArrayList<CifInfomationDto>();
        CifInfomationDto dto1 = new CifInfomationDto();

        // CIF番号
        dto1.setCifNumber("001");
        // 通帳レス設定状態
        dto1.setPassbookLessSettingStatus("0");
        // 初回登録フラグ
        dto1.setRegisterFlg("0");
        // 店番
        dto1.setBranchCode("001");

        CifInfomationDto dto2 = new CifInfomationDto();

        // CIF番号
        dto2.setCifNumber("001");
        // 初回登録フラグ
        dto2.setRegisterFlg("0");
        // 店番
        dto2.setBranchCode("002");
        // 通帳レス設定状態
        dto2.setPassbookLessSettingStatus("0");
        CifInfomationDto dto3 = new CifInfomationDto();

        // CIF番号
        dto3.setCifNumber("003");
        // 初回登録フラグ
        dto3.setRegisterFlg("0");
        // 店番
        dto3.setBranchCode("003");
        // 通帳レス設定状態
        dto3.setPassbookLessSettingStatus("0");
        CifInfomationDto dto4 = new CifInfomationDto();

        // CIF番号
        dto4.setCifNumber("004");
        // 初回登録フラグ
        dto4.setRegisterFlg("0");
        // 店番
        dto4.setBranchCode("004");
        // 通帳レス設定状態
        dto4.setPassbookLessSettingStatus("0");
        CifInfomationDto dto5 = new CifInfomationDto();

        // CIF番号
        dto5.setCifNumber("005");
        // 初回登録フラグ
        dto5.setRegisterFlg("0");
        // 店番
        dto5.setBranchCode("005");
        // 通帳レス設定状態
        dto5.setPassbookLessSettingStatus("0");
        CifInfomationDto dto6 = new CifInfomationDto();

        // CIF番号
        dto6.setCifNumber("006");
        // 初回登録フラグ
        dto6.setRegisterFlg("0");
        // 店番
        dto6.setBranchCode("006");
        // 通帳レス設定状態
        dto6.setPassbookLessSettingStatus("0");
        CifInfomationDto dto7 = new CifInfomationDto();
        // CIF番号
        dto7.setCifNumber("007");
        // 通帳レス設定状態
        dto7.setPassbookLessSettingStatus("0");
        // 初回登録フラグ
        dto7.setRegisterFlg("0");
        // 店番
        dto7.setBranchCode("001");

        CifInfomationDto dto8 = new CifInfomationDto();

        // CIF番号
        dto8.setCifNumber("008");
        // 通帳レス設定状態
        dto8.setPassbookLessSettingStatus("0");
        // 初回登録フラグ
        dto8.setRegisterFlg("0");
        // 店番
        dto8.setBranchCode("002");

        CifInfomationDto dto9 = new CifInfomationDto();

        // CIF番号
        dto9.setCifNumber("009");
        // 通帳レス設定状態
        dto9.setPassbookLessSettingStatus("0");
        // 初回登録フラグ
        dto9.setRegisterFlg("0");
        // 店番
        dto9.setBranchCode("003");

        CifInfomationDto dto10 = new CifInfomationDto();

        // CIF番号
        dto10.setCifNumber("010");
        // 通帳レス設定状態
        dto10.setPassbookLessSettingStatus("0");
        // 初回登録フラグ
        dto10.setRegisterFlg("0");
        // 店番
        dto10.setBranchCode("004");

        CifInfomationDto dto11 = new CifInfomationDto();

        // CIF番号
        dto11.setCifNumber("011");
        // 通帳レス設定状態
        dto11.setPassbookLessSettingStatus("0");
        // 初回登録フラグ
        dto11.setRegisterFlg("0");
        // 店番
        dto11.setBranchCode("005");

        CifInfomationDto dto12 = new CifInfomationDto();

        // CIF番号
        dto12.setCifNumber("012");
        // 通帳レス設定状態
        dto12.setPassbookLessSettingStatus("0");
        // 初回登録フラグ
        dto12.setRegisterFlg("0");
        // 店番
        dto12.setBranchCode("006");

        dtoList.add(dto1);
        dtoList.add(dto2);
        dtoList.add(dto3);
        dtoList.add(dto4);
        dtoList.add(dto5);
        dtoList.add(dto6);
        dtoList.add(dto7);
        dtoList.add(dto8);
        dtoList.add(dto9);
        dtoList.add(dto10);
        dtoList.add(dto11);
        dtoList.add(dto12);

        responseDto.setCifInfomationDtoList(dtoList);
        return responseDto;
    }

    /**
     * 通帳レス設定
     *
     * @param requestDto 通帳レス設定ABAリクエストDTO
     * @return 通帳レス設定ABAレスポンスDTO
     */
    @Override
    public CommonHeaderAbaResponseDto getPassbooklessSettingInformation(PassbooklesSettingAbaRequestDto requestDto) {
        return new CommonHeaderAbaResponseDto();
    }

    /**
     * 取引停止
     *
     * @return 処理結果
     */
    @Override
    public CommonHeaderAbaResponseDto stopTrading(StopTradingAbaRequestDto abaRequestDto) {

        return new CommonHeaderAbaResponseDto();
    }
}

package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * メールアドレス認証AbaリクエストDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class EmailAddressAuthorizationAbaRequestDto extends RequestBodyDto {

    /**
     * 利用者ID
     */
    private String userId;
    
    /**
     * 認証TRXキー
     */
    private String verifyTRXKey;
    
    /**
     * 受付番号
     */
    private String receiptNumber;
    
    /**
     * メールOTP 
     */
    private String mailOTP;
    
    /**
     * 画面ID
     */
    private String pageId;
    
    /**
     * メールアドレス
     */
    private String emailAddress;
    
}

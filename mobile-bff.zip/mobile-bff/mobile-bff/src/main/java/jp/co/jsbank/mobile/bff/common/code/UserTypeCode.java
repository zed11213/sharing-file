package jp.co.jsbank.mobile.bff.common.code;

/**
 * 利用者区分コード
 */
public class UserTypeCode {

    /**
     * 個人
     */
    public static final String INDIVIDUAL = "0";
    
    /**
     * 事業先代表者
     */
    public static final String BUSINESS_REPRESENTATIVE = "1";
    /**
     * 事業先利用者
     */
    public static final String BUSINESS_USER = "2"; 
}

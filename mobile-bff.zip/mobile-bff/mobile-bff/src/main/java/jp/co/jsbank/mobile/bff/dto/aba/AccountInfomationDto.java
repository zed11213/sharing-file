package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * 口座情報DTO
 */
@Data
public class AccountInfomationDto {

    /**
     * 店番
     */
    private String branchCode;

    /**
     * 口座番号
     */
    private String accountNumber;

    /**
     * 預金種目
     */
    private String accountType;

    /**
     * 初回登録フラグ
     */
    private String firstLoginFlag;
}

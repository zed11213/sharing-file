package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 定期積金満期明細表DTO
 */
@Data
public class PeriodicDepositMaturityDto {

    /**
     * お積立ての種類
     */
    private String typeOfReserve;

    /**
     * 口座番号
     */
    private String accountNumber;

    /**
     * ご契約金額
     */
    private String contractAmount;

    /**
     * お積立残高
     */
    private String reserveBalance;

    /**
     * 満期日
     */
    private String maturityDate;

    /**
     * 期間年
     */
    private String periodYear;
    
    /**
     * 期間月
     */
    private String periodMonth;
    
    /**
     * 税区分
     */
    private String taxType;
    
    /**
     * 星
     */
    private String star;


}

package jp.co.jsbank.mobile.bff.common.redis;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import jp.co.jsbank.mobile.bff.common.Constant;
import jp.co.jsbank.mobile.bff.common.exception.InternalServerErrorException;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

/**
 * Redis処理クラス
 */
@Component
public class RedisHandler {

    @Autowired
    private JedisPool jedisPool;

    private Jedis jedis;

    private Logger logger = LoggerFactory.getLogger(RedisHandler.class);

    /**
     * キーが存在するかどうかを判断する
     *
     * @param key redisキー
     * @return boolean
     */
    public boolean exists(String key) {
        boolean exists = false;

        try {
            jedis = jedisPool.getResource();
            exists = jedis.exists(key);
        } catch (Exception e) {
            logger.error("Redisが存在しない。");
            throw new InternalServerErrorException(Constant.EMPTY);
        } finally {
            jedis.close();
        }

        return exists;
    }

    /**
     * キー対応レコードの削除
     *
     * @param keys redisキー
     * @return レコード数
     */
    public long del(String... keys) {
        long count = 0;
        try {
            jedis = jedisPool.getResource();
            count = jedis.del(keys);
        } catch (Exception e) {
            logger.error("Redisが存在しない。");
            throw new InternalServerErrorException(Constant.EMPTY);
        } finally {
            jedis.close();
        }
        return count;
    }

    /**
     * 指定keyのデータの取得
     *
     * @param key redisキー
     * @return redis値
     */
    public String get(String key) {
        String value = null;
        try {

            jedis = jedisPool.getResource();
            value = jedis.get(key);
        } catch (Exception e) {
            logger.error("Redisが存在しない。");
            throw new InternalServerErrorException(Constant.EMPTY);
        } finally {
            jedis.close();
        }
        return value;
    }

    /**
     * レコードの追加
     *
     * @param key redisキー
     * @param value redis値
     * @return redis設定値
     */
    public String set(String key, String value) {
        String state = null;
        try {

            jedis = jedisPool.getResource();
            state = jedis.set(key, value);
        } catch (Exception e) {
            logger.error("Redisが存在しない。");
            throw new InternalServerErrorException(Constant.EMPTY);
        } finally {
            jedis.close();
        }
        return state;
    }
}

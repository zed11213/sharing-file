package jp.co.jsbank.mobile.bff.common;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.jsbank.mobile.bff.common.exception.InternalServerErrorException;
import jp.co.jsbank.mobile.bff.common.redis.RedisHandler;
import jp.co.jsbank.mobile.bff.service.TokenIdService;

/**
 * ID取得クラス
 */
@Service
public class GetIdByTokenHandler {

    @Autowired
    private RedisHandler redisHandler;

    @Autowired
    private TokenIdService tokenIdService;

    /**
     * コンストラクタ
     */
    private GetIdByTokenHandler() {
        super();
    }

    /**
     * ID取得
     *
     * @param tokenId トークンID
     * @return ID
     */
    public String getIdByToken(String tokenId) {

        // redisのIDが存在の場合
        if (redisHandler.exists(tokenId)) {

            return redisHandler.get(tokenId);
        }

        // DBのIDが存在の場合
        String id = tokenIdService.selectIdByToken(tokenId);

        if (StringUtils.isNoneBlank(id)) {

            return id;
        }

        // エラー戻る
        throw new InternalServerErrorException(Constant.EMPTY);
    }
}

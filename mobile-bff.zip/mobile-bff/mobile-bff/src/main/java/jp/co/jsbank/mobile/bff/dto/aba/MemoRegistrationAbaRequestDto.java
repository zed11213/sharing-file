package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 概要欄メモ登録ABAリクエストDTO
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class MemoRegistrationAbaRequestDto extends RequestBodyDto {

    /**
     * 顧客ID
     */
    private String customerId;

    /**
     * 店番
     */
    private String branchNumber;

    /**
     * 口座番号
     */
    private String accountNumber;

    /**
     * 明細ID
     */
    private String transactionDetailNo;

    /**
     * メモ
     */
    private String memo;
}

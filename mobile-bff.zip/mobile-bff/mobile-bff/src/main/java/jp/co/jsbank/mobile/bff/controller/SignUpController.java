package jp.co.jsbank.mobile.bff.controller;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import jp.co.jsbank.mobile.bff.common.JsonResult;
import jp.co.jsbank.mobile.bff.dto.BankbookPatternPreferenceRequestDto;
import jp.co.jsbank.mobile.bff.dto.DepartmentStoreInquiryResponseDto;
import jp.co.jsbank.mobile.bff.dto.EmailAddressAuthorizationRequestDto;
import jp.co.jsbank.mobile.bff.dto.EmailAddressRegistrationRequestDto;
import jp.co.jsbank.mobile.bff.dto.IdentityVerificationRequestDto;
import jp.co.jsbank.mobile.bff.dto.IdentityVerificationResponseDto;
import jp.co.jsbank.mobile.bff.dto.IvrAuthenticationRequestDto;
import jp.co.jsbank.mobile.bff.dto.PassBookLessPreferenceRequestDto;
import jp.co.jsbank.mobile.bff.dto.PushNotificationRegistrationRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.IvrSendingRequestDto;
import jp.co.jsbank.mobile.bff.service.SignUpService;

/**
 * 初回登録コントロール
 */
@RestController
public class SignUpController {

    @Resource
    private SignUpService signUpService;

    // private Logger logger = LoggerFactory.getLogger(SignUpController.class);

    /**
     * メールアドレス登録
     *
     * @param requestDto メールアドレス登録リクエストDTO
     * @return JsonResult
     */
    @PostMapping(path = "/sign-up/AB0101")
    public JsonResult emailAddressRegistration(@RequestBody EmailAddressRegistrationRequestDto requestDto) {
        String result = signUpService.emailAddressRegistration(requestDto);
        return JsonResult.success(result);
    }

    /**
     * メールアドレス認証
     *
     * @param requestDto メールアドレス認証リクエストDTO
     * @return JsonResult
     */
    @PostMapping(path = "/sign-up/AB0102")
    public JsonResult emailAddressAuthorization(@RequestBody EmailAddressAuthorizationRequestDto requestDto) {
        List<String> result = signUpService.emailAddressAuthorization(requestDto);
        return JsonResult.success(result);
    }

    /**
     * 本人照合
     *
     * @param identityVerificationReq 本人照合リクエストDTO
     * @return JsonResult
     */
    @PostMapping(path = "/sign-up/AB0103")
    public JsonResult identityVerification(@RequestBody IdentityVerificationRequestDto identityVerificationReq) {
        IdentityVerificationResponseDto responseDto = signUpService.identityVerification(identityVerificationReq);
        return JsonResult.success(responseDto);
    }

    /**
     * IVR送信
     *
     * @param requestDto IVR送信リクエストDTO
     * @return JsonResult
     */
    @PostMapping(path = "/sign-up/AB0105")
    public JsonResult ivrSending(@RequestBody IvrSendingRequestDto requestDto) {
        String result = signUpService.ivrSending(requestDto);
        return JsonResult.success(result);
    }

    /**
     * IVR認証
     *
     * @param requestDto IVR認証リクエストDTO
     * @return JsonResult
     */
    @PostMapping(path = "/sign-up/AB0106")
    public JsonResult ivrAuthentication(@RequestBody IvrAuthenticationRequestDto requestDto) {
        String result = signUpService.ivrAuthentication(requestDto);
        return JsonResult.success(result);
    }

    /**
     * 部店照会
     *
     * @return 処理結果
     */
    @GetMapping(path = "/sign-up/AB0112")
    public JsonResult departmentStoreInquiry() {

        List<DepartmentStoreInquiryResponseDto> butenInquiryLIst = signUpService.departmentStoreInquiry();

        return JsonResult.success(butenInquiryLIst);
    }

    /**
     * 利用者属性更新
     * 
     * @param requestDto 利用者属性更新リクエストDTO
     * @return JsonResult
     */
    @PutMapping(path = "/sign-up/AB0113")
    public JsonResult updateUserAttribute() {
        String result = signUpService.updateUserAttribute();
        return JsonResult.success(result);
    }

    /**
     * プッシュ通知登録
     *
     * @param requestDto プッシュ通知登録リクエストDTO
     * @return JsonResult
     */
    @PostMapping(path = "/sign-up/AB0119")
    public JsonResult pushNotificationRegistration(@RequestBody PushNotificationRegistrationRequestDto requestDto) {
        String result = signUpService.pushNotificationRegistration(requestDto);
        return JsonResult.success(result);
    }

    /**
     * 通帳パターン設定
     *
     * @param requestDto 通帳パターン設定リクエストDTO
     * @return JsonResult
     */
    @PostMapping(path = "/sign-up/AB0120")
    public JsonResult bankbookPatternPreference(@RequestBody BankbookPatternPreferenceRequestDto requestDto) {
        String result = signUpService.bankbookPatternPreference(requestDto);
        return JsonResult.success(result);
    }

    /**
     * 通帳レス設定
     *
     * @param requestDto 通帳レス設定情報リクエストDTO
     * @return JsonResult
     */
    @PostMapping(path = "/sign-up/AB0122")
    public JsonResult bankBookLessPreference(@RequestBody PassBookLessPreferenceRequestDto requestDto) {
        String result = signUpService.bankBookLessPreference(requestDto);
        return JsonResult.success(result);
    }
}

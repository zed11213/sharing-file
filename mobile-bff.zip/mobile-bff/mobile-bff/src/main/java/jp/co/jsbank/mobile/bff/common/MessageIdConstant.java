package jp.co.jsbank.mobile.bff.common;

public class MessageIdConstant {

    /**
     * エラーメッセージID : MBAP0001
     */
    public static final String MESSAGE_ID_MBAP0001 = "MBAP0001";

    /**
     * エラーメッセージID : MBAP0004
     */
    public static final String MESSAGE_ID_MBAP0004 = "MBAP0004";

    /**
     * エラーメッセージID : MBAP0006
     */
    public static final String MESSAGE_ID_MBAP0006 = "MBAP0006";

    /**
     * エラーメッセージID : MBAP0007
     */
    public static final String MESSAGE_ID_MBAP0007 = "MBAP0007";

    /**
     * エラーメッセージID : MBAP0008
     */
    public static final String MESSAGE_ID_MBAP0008 = "MBAP0008";

    /**
     * エラーメッセージID : MBAP0009
     */
    public static final String MESSAGE_ID_MBAP0009 = "MBAP0009";

    /**
     * エラーメッセージID : MBAP0010
     */
    public static final String MESSAGE_ID_MBAP0010 = "MBAP0010";

    /**
     * エラーメッセージID : MBAP0011
     */
    public static final String MESSAGE_ID_MBAP0011 = "MBAP0011";
    
    /**
     * エラーメッセージID : MBAP0012
     */
    public static final String MESSAGE_ID_MBAP0012 = "MBAP0012";

    /**
     * エラーメッセージID : MBAP0101
     */
    public static final String MESSAGE_ID_MBAP0101 = "MBAP0101";

    /**
     * エラーメッセージID : MBAP0102
     */
    public static final String MESSAGE_ID_MBAP0102 = "MBAP0102";

    /**
     * エラーメッセージID : MBAP0103
     */
    public static final String MESSAGE_ID_MBAP0103 = "MBAP0103";

    /**
     * エラーメッセージID : MBAP0104
     */
    public static final String MESSAGE_ID_MBAP0104 = "MBAP0104";
 
    /**
     * エラーメッセージID : MBAP1000
     */
    public static final String MESSAGE_ID_MBAP1000 = "MBAP1000"; 
    
    /**
     * エラーメッセージID : MBAP1001
     */
    public static final String MESSAGE_ID_MBAP1001 = "MBAP1001";
    
    /**
     * エラーメッセージID : MBAP1003
     */
    public static final String MESSAGE_ID_MBAP1003 = "MBAP1003"; 
    
    /**
     * エラーメッセージID : MBAP1004
     */
    public static final String MESSAGE_ID_MBAP1004 = "MBAP1004";
    
    /**
     * エラーメッセージID : MBAP1005
     */
    public static final String MESSAGE_ID_MBAP1005 = "MBAP1005";
    
    /**
     * エラーメッセージID : MBAP1006
     */
    public static final String MESSAGE_ID_MBAP1006 = "MBAP1006";   
    
    /**
     * エラーメッセージID : MBAP1008
     */
    public static final String MESSAGE_ID_MBAP1008 = "MBAP1008";   
    
    /**
     * エラーメッセージID : MBAP1010
     */
    public static final String MESSAGE_ID_MBAP1010 = "MBAP1010"; 
    
    /**
     * エラーメッセージID : MBAP1011
     */
    public static final String MESSAGE_ID_MBAP1011 = "MBAP1011"; 
    
    /**
     * エラーメッセージID : MBAP1014
     */
    public static final String MESSAGE_ID_MBAP1014 = "MBAP1014";   
    
    /**
     * エラーメッセージID : MBAP1013
     */
    public static final String MESSAGE_ID_MBAP1013 = "MBAP1013";   
    
    /**
     * エラーメッセージID : MBAP1015
     */
    public static final String MESSAGE_ID_MBAP1015 = "MBAP1015";  
    
    /**
     * エラーメッセージID : MBAP1016
     */
    public static final String MESSAGE_ID_MBAP1016 = "MBAP1016"; 
    
    /**
     * エラーメッセージID : MBAP1017
     */
    public static final String MESSAGE_ID_MBAP1017 = "MBAP1017";   
    
    /**
     * エラーメッセージID : MBAP1018
     */
    public static final String MESSAGE_ID_MBAP1018 = "MBAP1018";  
    
    /**
     * エラーメッセージID : MBAP1019
     */
    public static final String MESSAGE_ID_MBAP1019 = "MBAP1019"; 
    
    /**
     * エラーメッセージID : MBAP1020
     */
    public static final String MESSAGE_ID_MBAP1020 = "MBAP1020"; 
    
    /**
     * エラーメッセージID : MBAP1021
     */
    public static final String MESSAGE_ID_MBAP1021 = "MBAP1021"; 

    /**
     * エラーメッセージID : MBAP1022
     */
    public static final String MESSAGE_ID_MBAP1022 = "MBAP1022"; 
    
    /**
     * エラーメッセージID : MBAP1023
     */
    public static final String MESSAGE_ID_MBAP1023 = "MBAP1023"; 
    
    /**
     * エラーメッセージID : MBAP1024
     */
    public static final String MESSAGE_ID_MBAP1024 = "MBAP1024";   
    
    /**
     * エラーメッセージID : MBAP1025
     */
    public static final String MESSAGE_ID_MBAP1025 = "MBAP1025";  
    
    /**
     * エラーメッセージID : MBAP1026
     */
    public static final String MESSAGE_ID_MBAP1026 = "MBAP1026";     
      
    /**
     * エラーメッセージID : MBAP1027
     */
    public static final String MESSAGE_ID_MBAP1027 = "MBAP1027";    
    
    /**
     * エラーメッセージID : MBAP1028
     */
    public static final String MESSAGE_ID_MBAP1028 = "MBAP1028";   
    /**
     * エラーメッセージID : MBAP1029
     */
    public static final String MESSAGE_ID_MBAP1029 = "MBAP1029";
    
    /**
     * エラーメッセージID : MBAP1030
     */
    public static final String MESSAGE_ID_MBAP1030 = "MBAP1030";
    
    /**
     * エラーメッセージID : MBAP1031
     */
    public static final String MESSAGE_ID_MBAP1031 = "MBAP1031";    
    
    /**
     * エラーメッセージID : MBAP1032
     */
    public static final String MESSAGE_ID_MBAP1032 = "MBAP1032";
    
    /**
     * エラーメッセージID : MBAP1033
     */
    public static final String MESSAGE_ID_MBAP1033 = "MBAP1033";
    
    /**
     * エラーメッセージID : MBAP1034
     */
    public static final String MESSAGE_ID_MBAP1034 = "MBAP1034"; 

    /**
     * エラーメッセージID : MBAP1040
     */
    public static final String MESSAGE_ID_MBAP1040 = "MBAP1040"; 
    
    /**
     * エラーメッセージID : MBAP1041
     */
    public static final String MESSAGE_ID_MBAP1041 = "MBAP1041";   
 
    /**
     * エラーメッセージID : MBAP1100
     */
    public static final String MESSAGE_ID_MBAP1100 = "MBAP1100";  

    /**
     * エラーメッセージID : MBAP1101
     */
    public static final String MESSAGE_ID_MBAP1101 = "MBAP1101"; 
    
    /**
     * エラーメッセージID : MBAP1102
     */
    public static final String MESSAGE_ID_MBAP1102 = "MBAP1102"; 
    
    
    /**
     * エラーメッセージID : MBAP1103
     */
    public static final String MESSAGE_ID_MBAP1103 = "MBAP1103";  
    
    /**
     * エラーメッセージID : MBAP1200
     */
    public static final String MESSAGE_ID_MBAP1200 = "MBAP1200";

    /**
     * エラーメッセージID : MBAP1201
     */
    public static final String MESSAGE_ID_MBAP1201 = "MBAP1201";
    
    /**
     * エラーメッセージID : MBAP1202
     */
    public static final String MESSAGE_ID_MBAP1202 = "MBAP1202"; 
    
    /**
     * エラーメッセージID : MBAP1205
     */
    public static final String MESSAGE_ID_MBAP1205 = "MBAP1205";     
    
    /**
     * エラーメッセージID : MBAP1206
     */
    public static final String MESSAGE_ID_MBAP1206 = "MBAP1206";  
    
    /**
     * エラーメッセージID : MBAP1207
     */
    public static final String MESSAGE_ID_MBAP1207 = "MBAP1207"; 
 
    /**
     * エラーメッセージID : MBAP1208
     */
    public static final String MESSAGE_ID_MBAP1208 = "MBAP1208"; 
    
    /**
     * エラーメッセージID : MBAP1209
     */
    public static final String MESSAGE_ID_MBAP1209 = "MBAP1209"; 
    
    /**
     * エラーメッセージID : MBAP1210
     */
    public static final String MESSAGE_ID_MBAP1210 = "MBAP1210";   
    
    /**
     * エラーメッセージID : MBAP1212
     */
    public static final String MESSAGE_ID_MBAP1212 = "MBAP1212"; 
    
    /**
     * エラーメッセージID : MBAP1302
     */
    public static final String MESSAGE_ID_MBAP1302 = "MBAP1302";  
    
    /**
     * エラーメッセージID : MBAP1303
     */
    public static final String MESSAGE_ID_MBAP1303 = "MBAP1303";    
 
    /**
     * エラーメッセージID : MBAP1304
     */
    public static final String MESSAGE_ID_MBAP1304= "MBAP1304"; 
    
    /**
     * エラーメッセージID : MBAP1305
     */
    public static final String MESSAGE_ID_MBAP1305 = "MBAP1305"; 
    
    /**
     * エラーメッセージID : MBAP1306
     */
    public static final String MESSAGE_ID_MBAP1306 = "MBAP1306"; 
    
    /**
     * エラーメッセージID : MBAP1307
     */
    public static final String MESSAGE_ID_MBAP1307 = "MBAP1307";
 
    /**
     * エラーメッセージID : MBAP1308
     */
    public static final String MESSAGE_ID_MBAP1308 = "MBAP1308";
    
    /**
     * エラーメッセージID : MBAP1309
     */
    public static final String MESSAGE_ID_MBAP1309 = "MBAP1309";
    
    /**
     * エラーメッセージID : MBAP1400
     */
    public static final String MESSAGE_ID_MBAP1400 = "MBAP1400";
    
    /**
     * エラーメッセージID : MBAP1007
     */
    public static final String MESSAGE_ID_MBAP1007 = "MBAP1007"; 
    
    /**
     * エラーメッセージID : MBAP1002
     */
    public static final String MESSAGE_ID_MBAP1002 = "MBAP1002";  
    
    /**
     * エラーメッセージID : MBAP1009
     */
    public static final String MESSAGE_ID_MBAP1009 = "MBAP1009";  
   
    /**
     * エラーメッセージID : MBOP0003
     */
    public static final String MESSAGE_ID_MBOP0003 = "MBOP0003";   
    
    /**
     * エラーメッセージID : MBSU0001
     */
    public static final String MESSAGE_ID_MBSU0001 = "MBSU0001";
    
    /**
     * エラーメッセージID : MBAP1044
     */
    public static final String MESSAGE_ID_MBAP1044 = "MBAP1044";   

}

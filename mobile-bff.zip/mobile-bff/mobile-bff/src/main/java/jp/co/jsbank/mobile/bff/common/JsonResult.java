package jp.co.jsbank.mobile.bff.common;

import lombok.Data;

/**
 * 結果データクラス
 */
@Data
public class JsonResult {
    /**
     * レスポンスコード
     */
    private Integer statusCode;

    /**
     * レスポンス結果
     */
    private Object resultDto;

    /**
     * 正常に戻りました
     * 
     * @param data データ
     * @return JsonResult
     */
    public static JsonResult success(Object data) {
        JsonResult result = new JsonResult();
        result.setStatusCode(CommonEnum.SUCCESS.getResultCode());
        result.setResultDto(data);
        return result;
    }

    /**
     * 異常に戻りました
     * 
     * @param code コード
     * @param data データ
     * @return JsonResult
     */
    public static JsonResult error(Integer code, Object data) {
        JsonResult result = new JsonResult();
        result.setStatusCode(code);
        result.setResultDto(data);
        return result;
    }
}

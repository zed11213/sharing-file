package jp.co.jsbank.mobile.bff.common.exception;

/**
 * データなし例外。
 *
 */
public class ServiceUnavailableException extends BusinessException {

    private static final long serialVersionUID = -1L;

    /**
     * ServiceUnavailableExceptionのコンスタント。
     * 
     * @param errorCode エラーコード
     */
    public ServiceUnavailableException() {
        super("503");
    }
}

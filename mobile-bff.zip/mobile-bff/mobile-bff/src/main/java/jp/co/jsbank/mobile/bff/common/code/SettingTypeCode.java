package jp.co.jsbank.mobile.bff.common.code;

/**
 * 設定種別コード
 */
public class SettingTypeCode {

    /**
     * メール通知設定
     */
    public static final String EMAIL_NOTIFICATION_SETTINGS = "01";
    
    /**
     * Push通知設定
     */
    public static final String PUSH_NOTIFICATION_SETTINGS = "02";
    
    /**
     * 通帳パターン設定
     */
    public static final String PASSBOOK_PATTERN_SETTING = "03";
}

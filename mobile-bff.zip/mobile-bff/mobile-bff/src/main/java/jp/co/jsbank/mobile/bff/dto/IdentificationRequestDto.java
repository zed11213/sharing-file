package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 本人確認リクエストDTO
 */
@Data
public class IdentificationRequestDto {

    /**
     * 店番
     */
    private String branchNumber;

    /**
     * 口座番号
     */
    private String accountNumber;

    /**
     * カナ氏名
     */
    private String customerName;
    
    /**
     * 生年月日
     */
    private String birthday;
    
    /**
     * 郵便番号
     */
    private String zipCode;
    
    /**
     * CC暗証番号
     */
    private String ccPinCode;
    

    /**
     * 取引種別
     */
    private String transactionType;
    
    /**
     * 受付番号
     */
    private String receptionNumber;
    
    /**
     * 氏名
     */
    private String fullName;
    
    /**
     * 都道府県
     */
    private String prefectures;
    
    /**
     * 住所
     */
    private String address;
    
    /**
     * 住所カナ
     */
    private String addressKana;
}

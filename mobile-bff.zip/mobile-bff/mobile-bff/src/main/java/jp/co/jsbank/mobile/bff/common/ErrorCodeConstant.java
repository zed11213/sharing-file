package jp.co.jsbank.mobile.bff.common;

/**
 * 定数クラス
 */
public class ErrorCodeConstant {

    /**
     * ログラベル: I
     */
    public static final String LOG_LABLE_I = "I";
    
    /**
     * ログラベル: W
     */
    public static final String LOG_LABLE_W = "W";
    
    /**
     * ログラベル: E
     */
    public static final String LOG_LABLE_E = "E";
    
    /**
     * エラーコード: 10000
     */
    public static final String ERROR_CODE_10000 = "10000";

    /**
     * エラーコード: 10001
     */
    public static final String ERROR_CODE_10001 = "10001";

    /**
     * エラーコード: 10022
     */
    public static final String ERROR_CODE_10022 = "10022";

    /**
     * エラーコード: 10031
     */
    public static final String ERROR_CODE_10031 = "10031";

    /**
     * エラーコード: 10032
     */
    public static final String ERROR_CODE_10032 = "10032";

    /**
     * エラーコード: 30010
     */
    public static final String ERROR_CODE_30010 = "30010";

    /**
     * エラーコード: 33293
     */
    public static final String ERROR_CODE_33293 = "33293";

    /**
     * エラーコード: 71002
     */
    public static final String ERROR_CODE_71002 = "71002";

    /**
     * エラーコード: 71007
     */
    public static final String ERROR_CODE_71007 = "71007";

    /**
     * エラーコード: 71008
     */
    public static final String ERROR_CODE_71008 = "71008";

    /**
     * エラーコード: 71009
     */
    public static final String ERROR_CODE_71009 = "71009";

    /**
     * エラーコード: 71010
     */
    public static final String ERROR_CODE_71010 = "71010";

    /**
     * エラーコード: 71013
     */
    public static final String ERROR_CODE_71013 = "71013";

    /**
     * エラーコード: 71017
     */
    public static final String ERROR_CODE_71017 = "71017";

    /**
     * エラーコード: 71018
     */
    public static final String ERROR_CODE_71018 = "71018";

    /**
     * エラーコード: 71019
     */
    public static final String ERROR_CODE_71019 = "71019";

    /**
     * エラーコード: 71020
     */
    public static final String ERROR_CODE_71020 = "71020";

    /**
     * エラーコード: 71021
     */
    public static final String ERROR_CODE_71021 = "71021";

    /**
     * エラーコード: 71022
     */
    public static final String ERROR_CODE_71022 = "71022";

    /**
     * エラーコード: 71023
     */
    public static final String ERROR_CODE_71023 = "71023";

    /**
     * エラーコード: 71024
     */
    public static final String ERROR_CODE_71024 = "71024";

    /**
     * エラーコード: 71025
     */
    public static final String ERROR_CODE_71025 = "71025";

    /**
     * エラーコード: 71026
     */
    public static final String ERROR_CODE_71026 = "71026";

    /**
     * エラーコード: 71027
     */
    public static final String ERROR_CODE_71027 = "71027";

    /**
     * エラーコード: 71028
     */
    public static final String ERROR_CODE_71028 = "71028";

    /**
     * エラーコード: 71029
     */
    public static final String ERROR_CODE_71029 = "71029";

    /**
     * エラーコード: 71030
     */
    public static final String ERROR_CODE_71030 = "71030";

    /**
     * エラーコード: 71032
     */
    public static final String ERROR_CODE_71032 = "71032";

    /**
     * エラーコード: 71033
     */
    public static final String ERROR_CODE_71033 = "71033";

    /**
     * エラーコード: 71034
     */
    public static final String ERROR_CODE_71034 = "71034";

    /**
     * エラーコード: 71040
     */
    public static final String ERROR_CODE_71040 = "71040";

    /**
     * エラーコード: 71041
     */
    public static final String ERROR_CODE_71041 = "71041";

    /**
     * エラーコード: 71200
     */
    public static final String ERROR_CODE_71200 = "71200";

    /**
     * エラーコード: 71201
     */
    public static final String ERROR_CODE_71201 = "71201";

    /**
     * エラーコード: 71202
     */
    public static final String ERROR_CODE_71202 = "71202";

    /**
     * エラーコード: 71205
     */
    public static final String ERROR_CODE_71205 = "71205";

    /**
     * エラーコード: 71206
     */
    public static final String ERROR_CODE_71206 = "71206";

    /**
     * エラーコード: 71207
     */
    public static final String ERROR_CODE_71207 = "71207";

    /**
     * エラーコード: 71210
     */
    public static final String ERROR_CODE_71210 = "71210";

    /**
     * エラーコード: 71302
     */
    public static final String ERROR_CODE_71302 = "71302";

    /**
     * エラーコード: 71303
     */
    public static final String ERROR_CODE_71303 = "71303";

    /**
     * エラーコード: 71304
     */
    public static final String ERROR_CODE_71304 = "71304";

    /**
     * エラーコード: 71305
     */
    public static final String ERROR_CODE_71305 = "71305";

    /**
     * エラーコード: 71306
     */
    public static final String ERROR_CODE_71306 = "71306";

    /**
     * エラーコード: 71307
     */
    public static final String ERROR_CODE_71307 = "71307";

    /**
     * エラーコード: 71308
     */
    public static final String ERROR_CODE_71308 = "71308";

    /**
     * エラーコード: 71309
     */
    public static final String ERROR_CODE_71309 = "71309";

    /**
     * エラーコード: 90000
     */
    public static final String ERROR_CODE_90000 = "90000";

    /**
     * エラーコード: 90001
     */
    public static final String ERROR_CODE_90001 = "90001";

    /**
     * エラーコード: 90002
     */
    public static final String ERROR_CODE_90002 = "90002";

    /**
     * エラーコード: 90003
     */
    public static final String ERROR_CODE_90003 = "90003";

    /**
     * エラーコード: 90004
     */
    public static final String ERROR_CODE_90004 = "90004";

    /**
     * エラーコード: 90005
     */
    public static final String ERROR_CODE_90005 = "90005";

    /**
     * エラーコード: 90006
     */
    public static final String ERROR_CODE_90006 = "90006";

    /**
     * エラーコード: 91000
     */
    public static final String ERROR_CODE_91000 = "91000";

    /**
     * エラーコード: 91001
     */
    public static final String ERROR_CODE_91001 = "91001";

    /**
     * エラーコード: 95000
     */
    public static final String ERROR_CODE_95000 = "95000";

    /**
     * エラーコード: 95001
     */
    public static final String ERROR_CODE_95001 = "95001";

    /**
     * エラーコード: 95002
     */
    public static final String ERROR_CODE_95002 = "95002";

    /**
     * エラーコード: 99999
     */
    public static final String ERROR_CODE_99999 = "99999";
    
    /**
     * エラーコード: 71100
     */
    public static final String ERROR_CODE_71100 = "71100";

    /**
     * エラーコード: 71101
     */
    public static final String ERROR_CODE_71101 = "71101";
    
    /**
     * エラーコード: 71102
     */
    public static final String ERROR_CODE_71102 = "71102";
    
    /**
     * エラーコード: 71103
     */
    public static final String ERROR_CODE_71103 = "71103";

    /**
     * エラーコード: 71011
     */
    public static final String ERROR_CODE_71011 = "71011";

    /**
     * エラーコード: 71001
     */
    public static final String ERROR_CODE_71001 = "71001";

    /**
     * エラーコード: 71000
     */
    public static final String ERROR_CODE_71000 = "71000";

    /**
     * エラーコード: 71014
     */
    public static final String ERROR_CODE_71014 = "71014";

    /**
     * エラーコード: 71015
     */
    public static final String ERROR_CODE_71015 = "71015";

    /**
     * エラーコード: 71016
     */
    public static final String ERROR_CODE_71016 = "71016";

    /**
     * エラーコード: 71004
     */
    public static final String ERROR_CODE_71004 = "71004";

    /**
     * エラーコード: 71005
     */
    public static final String ERROR_CODE_71005 = "71005";

    /**
     * エラーコード: 71006
     */
    public static final String ERROR_CODE_71006 = "71006";

    /**
     * エラーコード: 71031
     */
    public static final String ERROR_CODE_71031 = "71031";

    /**
     * エラーコード: 71003
     */
    public static final String ERROR_CODE_71003 = "71003";
    
    /**
     * エラーコード: 71208
     */
    public static final String ERROR_CODE_71208 = "71208";
    
    /**
     * エラーコード: 71209
     */
    public static final String ERROR_CODE_71209 = "71209";

    /**
     * エラーコード: 71212
     */
    public static final String ERROR_CODE_71212 = "71212";
    
    /**
     * エラーコード: 71400
     */
    public static final String ERROR_CODE_71400 = "71400";
    
    /**
     * エラーコード: 71044
     */
    public static final String ERROR_CODE_71044 = "71044";
}

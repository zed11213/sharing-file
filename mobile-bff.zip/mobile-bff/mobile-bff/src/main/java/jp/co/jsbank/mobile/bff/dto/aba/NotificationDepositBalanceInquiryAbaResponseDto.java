package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 通知預金明細レスポンスDTO
 */
@Data
public class NotificationDepositBalanceInquiryAbaResponseDto {

    /**
     * 共通レスポンス・ヘッダ
     */
    private CommonResponseHeader commonResponseHeader;

    /**
     * CIF番号
     */
    private String cifNumber;

}

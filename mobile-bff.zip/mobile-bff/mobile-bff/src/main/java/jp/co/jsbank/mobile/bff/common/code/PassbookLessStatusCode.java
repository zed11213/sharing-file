package jp.co.jsbank.mobile.bff.common.code;

/**
 * 通帳レス設定状態
 */
public class PassbookLessStatusCode {

    /**
     * 未設定
     */
    public static final String NOT_SET = "0";

    /**
     * 設定済
     */
    public static final String SET = "1";  

}

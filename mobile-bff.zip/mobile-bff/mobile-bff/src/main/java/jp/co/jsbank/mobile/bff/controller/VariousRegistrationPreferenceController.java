package jp.co.jsbank.mobile.bff.controller;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jp.co.jsbank.mobile.bff.common.JsonResult;
import jp.co.jsbank.mobile.bff.dto.AccountInformationResponseDto;
import jp.co.jsbank.mobile.bff.dto.AuthenticationKeyIssuanceResponseDto;
import jp.co.jsbank.mobile.bff.dto.CifInfomationResponseDto;
import jp.co.jsbank.mobile.bff.dto.DeleteUseAccountRequestDto;
import jp.co.jsbank.mobile.bff.dto.EmailAddRegistrationRequestDto;
import jp.co.jsbank.mobile.bff.dto.EmailAddUpdateRequestDto;
import jp.co.jsbank.mobile.bff.dto.NotificationSettingRequestDto;
import jp.co.jsbank.mobile.bff.dto.NotificationSettingResponseDto;
import jp.co.jsbank.mobile.bff.dto.PassbooklessSettingRequestDto;
import jp.co.jsbank.mobile.bff.dto.PassbooklessSettingResponseDto;
import jp.co.jsbank.mobile.bff.dto.UpdateDesignInfomationRequestDto;
import jp.co.jsbank.mobile.bff.dto.UseAccountRegistrationRequestDto;
import jp.co.jsbank.mobile.bff.dto.UserAdditionalConfirmationStatUpdateRequestDto;
import jp.co.jsbank.mobile.bff.dto.UserAttributeInquiryConfirmationResponseDto;
import jp.co.jsbank.mobile.bff.dto.UserInfo;
import jp.co.jsbank.mobile.bff.dto.UserInformationDetailsResponseDto;
import jp.co.jsbank.mobile.bff.service.VariousRegistrationPreferenceService;

/**
 * 各種登録設定コントロール
 */
@RestController
public class VariousRegistrationPreferenceController {

    @Resource
    private VariousRegistrationPreferenceService variousRegistrationPreferenceService;

    // private Logger logger =
    // LoggerFactory.getLogger(CashCardIssueController.class);Number

    /**
     * 通知設定情報取得
     *
     * @return 通知設定情報
     */
    @GetMapping(path = "/various-registration-preference/AB1101")
    public JsonResult getNotificationSetting() {

        NotificationSettingResponseDto responseDto = variousRegistrationPreferenceService.getNotificationSetting();

        return JsonResult.success(responseDto);
    }

    /**
     * 通知設定情報変更
     *
     * @param requestDto 通知設定BFFリクエストDTO
     * @return JsonResult
     */
    @PutMapping(path = "/various-registration-preference/AB1102")
    public JsonResult changeNotificationSettingInfo(@RequestBody NotificationSettingRequestDto requestDto) {

        String result = variousRegistrationPreferenceService.changeNotificationSettingInfo(requestDto);

        return JsonResult.success(result);
    }

    /**
     * 利用口座削除
     *
     * @param requestDto 利用口座登録BFFリクエストDTO
     * @return JsonResult
     */
    @PutMapping(path = "/various-registration-preference/AB1103")
    public JsonResult deleteUseAccount(@RequestBody DeleteUseAccountRequestDto requestDto) {

        String result = variousRegistrationPreferenceService.deleteUseAccount(requestDto);

        return JsonResult.success(result);
    }

    /**
     * 利用口座登録
     *
     * @param requestDto 利用口座登録BFFリクエストDTO
     * @return JsonResult
     */
    @PutMapping(path = "/various-registration-preference/AB1104")
    public JsonResult useAccountRegistration(@RequestBody UseAccountRegistrationRequestDto requestDto) {

        String result = variousRegistrationPreferenceService.useAccountRegistration(requestDto);

        return JsonResult.success(result);
    }

    /**
     * デザイン取得
     *
     * @return JsonResult
     */
    @GetMapping(path = "/various-registration-preference/AB1105")
    public JsonResult getDesignInfomation() {

        String configuredDesign = variousRegistrationPreferenceService.getDesignInfomation();

        return JsonResult.success(configuredDesign);
    }

    /**
     * デザイン更新
     *
     * @param requestDto デザイン更新BFFリクエストDTO
     * @return JsonResult
     */
    @PostMapping(path = "/various-registration-preference/AB1106")
    public JsonResult updateDesignInfomation(@RequestBody UpdateDesignInfomationRequestDto requestDto) {

        String result = variousRegistrationPreferenceService.updateDesignInfomation(requestDto);

        return JsonResult.success(result);
    }

    /**
     * メールアドレス変更
     *
     * @param requestDto メールアドレス変更リクエストDTO
     * @return JsonResult
     */
    @PutMapping(path = "/various-registration-preference/AB1107")
    public JsonResult emailAddressChanging(@RequestBody EmailAddUpdateRequestDto requestDto) {

        String responseDto = variousRegistrationPreferenceService.emailAddressChanging(requestDto);

        return JsonResult.success(responseDto);
    }

    /**
     * メールアドレス登録
     *
     * @param requestDto メールアドレス登録BFFリクエストDTO
     * @return JsonResult
     */
    @PostMapping(path = "/various-registration-preference/AB1108")
    public JsonResult emailAddressRegistration(@RequestBody EmailAddRegistrationRequestDto requestDto) {

        String result = variousRegistrationPreferenceService.emailAddressRegistration(requestDto);

        return JsonResult.success(result);
    }

    /**
     * 法人利用者情報一覧取得
     *
     * @return 利用者情報
     */
    @GetMapping(path = "/various-registration-preference/AB1109")
    public JsonResult getJuridicalPersonUserDetails() {

        // 利用者情報を取得する
        UserInformationDetailsResponseDto responseDto = variousRegistrationPreferenceService
                .getJuridicalPersonUserDetails();
        return JsonResult.success(responseDto);
    }

    /**
     * 認証キー発行
     * 
     * @param requestDto 利用者情報
     * @return 認証キー発行情報
     */
    @PostMapping(path = "/various-registration-preference/AB1110")
    public JsonResult authenticationKeyIssuance(@RequestBody UserInfo requestDto) {

        AuthenticationKeyIssuanceResponseDto responseDto = variousRegistrationPreferenceService
                .authenticationKeyIssuance(requestDto);

        return JsonResult.success(responseDto);
    }

    /**
     * 利用者追加確認ステータス更新
     * 
     * @param requestDto 利用者追加確認ステータス更新BFFリクエストDTO
     * @return JsonResult
     */
    @PostMapping(path = "/various-registration-preference/AB1111")
    public JsonResult userAdditionalConfirmationStatUpdate(
            @RequestBody UserAdditionalConfirmationStatUpdateRequestDto requestDto) {

        String result = variousRegistrationPreferenceService.userAdditionalConfirmationStatUpdate(requestDto);

        return JsonResult.success(result);
    }

    /**
     * 取引停止
     *
     * @return JsonResult
     */
    @PostMapping(path = "/various-registration-preference/AB1112")
    public JsonResult tradingStop() {

        String responseDto = variousRegistrationPreferenceService.tradingStop();

        return JsonResult.success(responseDto);
    }

    /**
     * 利用口座登録確認情報取得
     *
     * @param branchCode 店番
     * @param accountNumber 口座番号
     * @param accountType 預金種目
     * @return 利用口座登録確認情報
     */
    @GetMapping(path = "/various-registration-preference/AB1113")
    public JsonResult useAccountRegistrationConfirmation(@RequestParam String branchCode,
            @RequestParam String accountNumber, @RequestParam String accountType) {

        UserAttributeInquiryConfirmationResponseDto result = variousRegistrationPreferenceService
                .getUseAccountRegistrationConfirmation(branchCode, accountNumber, accountType);

        return JsonResult.success(result);
    }

    /**
     * CIF情報取得
     *
     * @return CIF情報
     */
    @GetMapping(path = "/various-registration-preference/AB1114")
    public JsonResult getCifInfomation() {

        // CIF情報取得
        CifInfomationResponseDto responseDto = variousRegistrationPreferenceService.getCifInfomation();

        return JsonResult.success(responseDto);
    }

    /**
     * 口座情報取得
     *
     * @param branchCode 店番
     * @param cifNumber CIF番号
     * @return 口座情報
     */
    @GetMapping(path = "/various-registration-preference/AB1115")
    public JsonResult getAccountInformation(@RequestParam String branchCode, @RequestParam String cifNumber) {

        // 口座情報取得を取得する
        AccountInformationResponseDto responseDto = variousRegistrationPreferenceService
                .getAccountInformation(branchCode, cifNumber);

        return JsonResult.success(responseDto);
    }

    /**
     * 通帳レス情報取得
     *
     * @return 通帳レス情報
     */
    @GetMapping(path = "/various-registration-preference/AB1116")
    public JsonResult getPassBooklessInformation() {
        PassbooklessSettingResponseDto result = variousRegistrationPreferenceService.getPassBooklessInformation();
        return JsonResult.success(result);
    }

    /**
     * 通帳レス設定
     *
     * @return JsonResult
     */
    @PostMapping(path = "/various-registration-preference/AB1117")
    public JsonResult passBooklessSetting(@RequestBody PassbooklessSettingRequestDto requestDto) {
        String result = variousRegistrationPreferenceService.passBooklessSetting(requestDto);
        return JsonResult.success(result);
    }
}

package jp.co.jsbank.mobile.bff.dto;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.aba.CifNumberDto;
import lombok.Data;

/**
 * 申込回答閲覧レスボスDTO
 */
@Data
public class ApplicationAnswerViewResponseDto {

    /**
     * お知らせID
     */
    private String anncmntId;

    /**
     * 申込ID
     */
    private String applyId;

    /**
     * タイトル
     */
    private String anncmntTitle;

    /**
     * 作成日時
     */
    private String createDateAndTime;

    /**
     * 非会員フラグ
     */
    private String nonMemberFlg;

    /**
     * CIF番号レスト
     */
    private List<CifNumberDto> cifNoList;

    /**
     * 顧客ID
     */
    private String customerId;

    /**
     * 利用者ID
     */
    private String userId;

    /**
     * カナ氏名
     */
    private String custNameKana;

    /**
     * 漢字氏名
     */
    private String custNameKanji;

    /**
     * 郵便番号
     */
    private String custZipCode;

    /**
     * カナ住所
     */
    private String custAddressKana;

    /**
     * 住所
     */
    private String custAddress;

    /**
     * 電話番号
     */
    private String custPhone;

    /**
     * メールアドレス
     */
    private String custMail;

    /**
     * 受付フォーマット
     */
    private String receptionFormat;

    /**
     * 店名
     */
    private String branchName;

    /**
     * 画像ファイル
     */
    private String fileStream;
    
    /**
     * ボタン種類 
     */
    private String btnType;
    
    /**
     * ボタンリンク先有無フラグ 
     */
    private String btnLinkFlg;
    
    /**
     * ボタンリンク先URL
     */
    private String btnLinkUrl;

    /**
     * 回答本文
     */
    private String responseMsg;

    /**
     * 申込確認メッセージ
     */
    private String applyConfirmMsg;
}

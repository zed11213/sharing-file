package jp.co.jsbank.mobile.bff.logic.impl;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.jsbank.mobile.bff.config.RestClientConfig;
import jp.co.jsbank.mobile.bff.dto.aba.AuthenticationKeyVerificationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.AuthenticationKeyVerificationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.SettingInfoDto;
import jp.co.jsbank.mobile.bff.dto.aba.UserAttributeInfoDto;
import jp.co.jsbank.mobile.bff.dto.aba.UserAttributeInquiryAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.UserAttributeInquiryAbaResponseDto;
import jp.co.jsbank.mobile.bff.logic.LoginLogic;

/**
 * ログインロジック実装クラス
 */
@Service
public class LoginLogicImpl implements LoginLogic {

    @Autowired
    RestClientConfig restClientConfig;

    /**
     * 利用者属性照会
     *
     * @param abaRequestDto 利用者属性照会ABAリクエストDTO
     * @return 利用者属性照会ABAレスボスDTO
     * 
     */
    @Override
    public UserAttributeInquiryAbaResponseDto userAttributeInquiry(UserAttributeInquiryAbaRequestDto abaRequestDto) {

        // // リクエストパラメータ設定
        // ParameterBuilder parameterDto = ParameterBuilder.build(abaRequestDto);
        //
        // // 「利用者属性登録」APIを呼び出す
        // RestTemplate restTemplate = restClientConfig.simpleRestTemplate();
        //
        // UserAttributeInquiryAbaResponseDto abaResponseDto = restTemplate.postForObject("/v1.4.3/userAttr/inquiry",
        // parameterDto, UserAttributeInquiryAbaResponseDto.class);

        // TODO dummyデータ
        SettingInfoDto infoDto = new SettingInfoDto();
        infoDto.setSettingType("03");
        infoDto.setSettingContent("0");

        UserAttributeInfoDto dto = new UserAttributeInfoDto();
        dto.setCustomerId("0001");
        dto.setStatus("0");
        dto.setSettingInfos(Arrays.asList(infoDto));
        UserAttributeInquiryAbaResponseDto response = new UserAttributeInquiryAbaResponseDto();
        response.setUserInfoList(Arrays.asList(dto));

        return response;
    }

    /**
     * 認証キー検証
     *
     * @param abaRequestDto 認証キー検証ABAリクエストDTO
     * @return 認証キー検証ABAレスポンスDTO
     * 
     */
    @Override
    public AuthenticationKeyVerificationAbaResponseDto
            authenticationKeyVerification(AuthenticationKeyVerificationAbaRequestDto abaRequestDto) {

        // リクエストパラメータ設定
        // ParameterBuilder parameterDto = ParameterBuilder.build(abaRequestDto);
        //
        // // 「認証キー検証」APIを呼び出す
        // RestTemplate restTemplate = restClientConfig.simpleRestTemplate();
        //
        // // 認証結果
        // AuthenticationKeyVerificationAbaResponseDto abaResponseDto = restTemplate.postForObject(
        // "/v1.4.3/authKey/verify", parameterDto, AuthenticationKeyVerificationAbaResponseDto.class);

        AuthenticationKeyVerificationAbaResponseDto res = new AuthenticationKeyVerificationAbaResponseDto();
        res.setCustomerId("0001");

        return res;
    }
}

package jp.co.jsbank.mobile.bff.service;

import org.springframework.stereotype.Service;

import jp.co.jsbank.mobile.bff.dto.AuthenticationKeyVerificationRequestDto;

/**
 * ログインサービス
 */
@Service
public interface LoginService {

    /**
     * ログイン認証
     *
     * @return ステータス
     */
    String loginAuthentication();

    /**
     * 認証キー検証
     *
     * @param requestDto 認証キー検証リクエストDTO
     * @return 顧客ID
     */
    String authenticationKeyVerification(AuthenticationKeyVerificationRequestDto requestDto);
}

package jp.co.jsbank.mobile.bff.common.code;

/**
 * 店番・店舗名コード
 */
public class BranchCode {

    /**
     * 営業部本店
     */
    public static final String SALES_DEPARTMENT_HEAD_OFFICE = "001";

    /**
     * 品川支店 
     */
    public static final String SHINAGAWA_BRANCH = "002";

    /**
     * 大井支店
     */
    public static final String OI_BRANCH = "003";

    /**
     * 大森支店
     */
    public static final String OMORI_BRANCH = "004";

    /**
     * 入新井支店
     */
    public static final String IRIARAI_BRANCH = "005";

    /**
     * 馬込支店
     */
    public static final String MAGOME_BRANCH = "006";

    /**
     * 池上支店
     */
    public static final String IKEGAMI_BRANCH = "007";

    /**
     * 蒲田支店
     */
    public static final String KAMATA_BRANCH = "008";

    /**
     *  六郷支店
     */
    public static final String ROKUGO_BRANCH = "009";

    /**
     * 矢口支店
     */
    public static final String YAGUCHI_BRANCH = "010";

    /**
     * 羽田支店
     */
    public static final String HANEDA_BRANCH = "011";

    /**
     * 荏原支店
     */
    public static final String EBARA_BRANCH = "012";
    
    /**
     * 碑衾支店
     */
    public static final String MONUMENT_BRANCH = "013";
    
    /**
     * 駒沢支店
     */
    public static final String KOMAZAWA_BRANCH = "014";
   
    /**
     * 砧支店
     */
    public static final String KINUTA_BRANCH = "015";
    
    /**
     * 奥沢支店
     */
    public static final String OKUSAWA_BRANCH = "016";
   
    /**
     * 大岡山支店
     */
    public static final String OOKAYAMA_BRANCH = "017";
    
    /**
     * 玉川支店
     */
    public static final String TAMAGAWA_BRANCH = "018";
   
    /**
     * 目黒支店
     */
    public static final String MEGURO_BRANCH = "019";
    
    /**
     * 自由ヶ丘支店
     */
    public static final String JIYUGAOKA_BRANCH = "020";
    
    /**
     * 神田支店
     */
    public static final String KANDA_BRANCH = "021";
    
    /**
     * 新橋支店
     */
    public static final String SHIMBASHI_BRANCH = "022";
    
    /**
     * 九段支店
     */
    public static final String KUDAN_BRANCH = "023";
    
    /**
     * 雪ヶ谷支店
     */
    public static final String YUKIGAYA_BRANCH = "024";
    
    /**
     * 渋谷支店
     */
    public static final String SHIBUYA_BRANCH = "025";
    
    /**
     * 青山支店
     */
    public static final String AOYAMA_Branch = "026";
    
    /**
     * 経堂支店
     */
    public static final String KYODO_BRANCH = "028";
   
    /**
     * 世田谷支店
     */
    public static final String SETAGAYA_BRANCH = "029";
    
    /**
     * 銀座支店
     */
    public static final String GINZA_BRANCH = "030";
    
    /**
     * 三宿支店
     */
    public static final String MISHUKU_BRANCH = "031";
    
    /**
     * 蓮沼支店
     */
    public static final String HASUNUMA_BRANCH = "032";
   
    /**
     * 中野支店
     */
    public static final String NAKANO_BRANCH = "033";
    
    /**
     * 瀬田支店
     */
    public static final String SETA_BRANCH = "034";
    
    /**
     * 狛江支店
     */
    public static final String KOMAE_BRANCH = "035";
   
    /**
     * 高円寺支店
     */
    public static final String KOENJI_BRANCH = "036";
   
    /**
     * 溝ノ口支店
     */
    public static final String MIZONOKUCHI_BRANCH = "037";
    
    /**
     * 生田支店
     */
    public static final String IKUTA_BRANCH = "038";
    
    /**
     * 綱島支店
     */
    public static final String TSUNASHIMA_BRANCH = "039";
    
    /**
     * 宮前平支店
     */
    public static final String MIYAMAEDAIRA_BRANCH = "040";
    
    /**
     * 元住吉支店
     */
    public static final String FORMER_SUMIYOSHI_BRANCH = "041";
    
    /**
     * 原町田支店
     */
    public static final String HARAMACHIDA_BRANCH = "043";
    
    /**
     * 天王町支店
     */
    public static final String TENNOCHO_BRANCH = "044";
    
    /**
     * 鶴見支店
     */
    public static final String TSURUMI_BRANCH = "045";
    
    /**
     * 六角橋支店
     */
    public static final String ROKUKAKUBASHI_BRANCH = "046";
    
    /**
     * 大和支店
     */
    public static final String YAMATO_BRANCH = "047";
    
     /**
     * 小机支店
     */
    public static final String SMALL_DESK_BRANCH = "048";
    
    /**
     * 厚木支店
     */
    public static final String ATSUGI_BRANCH = "049";
    
    /**
     * 相武台支店
     */
    public static final String SOBUDAI_BRANCH = "050";
    
    /**
     * 荏田支店
     */
    public static final String EDA_BRANCH = "051";
   
    /**
     * 稲城支店
     */
    public static final String INAGI_BRANCH = "052";
   
    /**
     * すずかけ台支店
     */
    public static final String SUZUKAKEDAI_BRANCH = "053";
   
    /**
     * 淵野辺支店
     */
    public static final String FUCHINOBE_BRANCH = "054";
    
    /**
     * 田奈支店
     */
    public static final String TANA_BRANCH = "055";
    
    /**
     * 上星川支店
     */
    public static final String KAMIHOSHIKAWA_BRANCH = "056";
   
    /**
     * 中原支店
     */
    public static final String NAKAHARA_BRANCH = "057";
    
    /**
     * 相模大塚支店
     */
    public static final String SAGAMI_OTSUKA_BRANCH = "058";
    
    /**
     * 日吉下田支店
     */
    public static final String HIYOSHI_SHIMODA_BRANCH = "059";
    
     /**
     * 祖師谷支店
     */
    public static final String SOSHIGAYA_BRANCH = "060";
   
    /**
     * 蒲田本町支店
     */
    public static final String KAMATAHONCHO_BRANCH = "061";
    
    /**
     * 大崎支店
     */
    public static final String OSAKI_BRANCH = "062";
    
    /**
     * 横浜支店
     */
    public static final String YOKOHAMA_BRANCH = "063";
    
    /**
     * 川和支店
     */
    public static final String KAWAWA_BRANCH = "064";
   
    /**
     * 海老名支店
     */
    public static final String EBINA_BRANCH = "065";
    
     /**
     * 小山田支店
     */
    public static final String OYAMADA_BRANCH = "066";
    
    /**
     * 中央林間支店
     */
    public static final String  CHUO_RINKAN_BRANCH="067";
   
    /**
     * たまプラーザ支店
     */
    public static final String TAMAPLAZA_BRANCH = "068";
   
    /**
     * 深沢支店
     */
    public static final String FUKASAWA_BRANCH = "069";
   
    /**
     * 新横浜支店
     */
    public static final String  SHIN_YOKOHAMA_BRANCH="070";
    
    /**
     * 今宿支店
     */
    public static final String IMAJUKU_BRANCH = "071";
    
     /**
     * 用賀支店
     */
    public static final String YOGA_BRANCH = "072";
    
    /**
     * 西大井支店
     */
    public static final String NISHIOI_BRANCH = "073";
   
    /**
     * 鷺沼支店
     */
    public static final String SAGINUMA_BRANCH = "074";
   
    /**
     * 玉川学園支店
     */
    public static final String TAMAGAWA_GAKUEN_BRANCH = "075";
   
    /**
     * 立会川支店
     */
    public static final String TACHIAIGAWA_BRANCH = "076";
    
    /**
     * 等々力支店
     */
    public static final String TODOROKI_BRANCH = "077";
   
    /**
     * 大田文化の森支店
     */
    public static final String DAEJEON_BUNKA_NO_MORI_BRANCH = "078";
   
    /**
     * 瀬谷支店
     */
    public static final String SEYA_BRANCH = "079";
   
    /**
     * 久が原支店
     */
    public static final String KUGAHARA_BRANCH = "080";
    
    /**
     * 碑文谷支店
     */
    public static final String HIMONYA_BRANCH = "081";
   
    /**
     * 本町田支店
     */
    public static final String HONMACHIDA_BRANCH = "082";
    
    /**
     * 湘南台支店
     */
    public static final String SHONANDAI_BRANCH = "083";
   
    /**
     * 桜上水支店
     */
    public static final String SAKURAJOSUI_BRANCH = "084";
   
    /**
     * 仲町台支店
     */
    public static final String NAKAMACHIDAI_BRANCH = "085";
    
    /**
     * しらうめＪネット支店
     */
    public static final String SHIRAUME_J_NET_BRANCH = "090";
    
    /**
     * 本部（役員室）
     */
    public static final String HEADQUARTERS_EXECUTIVE_OFFICE      ="200";
    
    /**
     * 本部（監事室）
     */
    public static final String  HEADQUARTERS_AUDITOR_OFFICE      ="210";

    /**
     * コンプラ統轄部
     */
    public static final String COMPLIANCE_DEPARTMENT_ = "300";
    
    /**
     * 未来システム戦略室
     */
    public static final String FUTURE_SYSTEM_STRATEGY_OFFICE = "320";
   
    /**
     * 人事部
     */
    public static final String HUMAN_RESOURCES_DEPARTMENT = "340";
   
    /**
     * 人財育成部
     */
    public static final String HUMAN_RESOURCES_DEVELOPMENT_DEPARTMENT = "350";
    
    /**
     * 監査部
     */
    public static final String AUDIT_DEPARTMENT = "360";
    
    /**
     * 資産査定監査部
     */
    public static final String ASSET_ASSESSMENT_AUDIT_DEPARTMENT = "370";
     
      /**
     * 企画部
     */
    public static final String PLANNING_DEPARTMENT_ = "380";
    
    /**
     * 総務部
     */
    public static final String GENERAL_AFFAIRS_DEPARTMENT = "400";
   
     /**
     * 管財部
     */
    public static final String ADMINISTRATION_DEPARTMENT = "410";
    
    /**
     * お客様応援部
     */
    public static final String CUSTOMER_SUPPORT_DEPARTMENT = "520";
    
    /**
     * 地域発展支援部
     */
    public static final String REGIONAL_DEVELOPMENT_SUPPORT_DEPARTMENT = "530";
    
    /**
     * 未来創造部
     */
    public static final String FUTURE_CREATION_DEPARTMENT = "535";
   
    /**
     * 融資第一部
     */
    public static final String LOAN_PART_ONE = "540";
    
    /**
     * 融資第二部
     */
    public static final String LOAN_PART_TWO = "545";
    
    /**
     * 企業経営サポート部
     */
    public static final String CORPORATE_MANAGEMENT_SUPPORT_DEPARTMENT = "548";
    
    /**
     * 事業承継支援部
     */
    public static final String BUSINESS_SUCCESSION_SUPPORT_DEPARTMENT = "549";
   
    /**
     * 融資管理課
     */
    public static final String LOAN_MANAGEMENT_DIVISION = "550";

    /**
     * 事務本部(庶務課)
     */
    public static final String OFFICE_HEADQUARTERS_GENERAL_AFFAIRS_DIVISION      ="555";

    /**
     * 事務統轄部
     */
    public static final String ADMINISTRATIVE_ADMINISTRATION = "560";
    
    /**
     * システム部
     */
    public static final String SYSTEM_DEPARTMENT = "570";
   
    /**
     * 融資債権集中管理部
     */
    public static final String LOAN_RECEIVABLES_CENTRALIZED_MANAGEMENT_DEPARTMENT = "574";
    
    /**
     * 事務集中部
     */
    public static final String OFFICE_CONCENTRATION_DEPARTMEN = "576";
    
    /**
     * 決済業務部
     */
    public static final String SETTLEMENT_BUSINESS_DEPARTMENT = "577";
    
    /**
     * 市場運用部
     */
    public static final String MARKET_MANAGEMENT_DEPARTMENT = "580";
   
    /**
     * 主計課
     */
    public static final String ACCOUNTING_DIVISION = "600";
    
    /**
     * リスク統轄部
     */
    public static final String RISK_ADMINISTRATION = "610";
    
    /**
     * 城南情報サービス
     */
    public static final String JONAN_INFORMATION_SERVICE = "710";
   
    /**
     * みなみ商事（ＪＢＳ）
     */
    public static final String MINAMI_SHOJI_JBS = "720";
    
    /**
     * みなみ商事（不動産）
     */
    public static final String MINAMI_SHOJI_REAL_ESTATE = "721";
    
    /**
     * みなみ商事（保険）
     */
    public static final String MINAMI_SHOJI_INSURANCE = "722";
    
    /**
     * 城南不動産サービス
     */
    public static final String JONAN_REAL_ESTATE_SERVICE_ = "730";
    
    /**
     * 城南ワーカーズコープ
     */
    public static final String JONAN_WORKERS_CORP = "740";
}

package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 融資期日明細表DTO
 */
@Data
public class LoanDateDto {

    /**
     * ご融資科目
     */
    private String loanItems;

    /**
     * ご融資番号
     */
    private String loanNumber;

    /**
     * ご返済期日
     */
    private String repaymentDate;

    /**
     * ご融資年月日
     */
    private String loanDate;

    /**
     * ご融資金の現在高
     */
    private String currentAmountOfLoan;
    
    /**
     * 文言０１
     */
    private String value01;
    
    /**
     * 文言０２
     */
    private String value02;
    
    /**
     * 文言０３
     */
    private String value03;

}

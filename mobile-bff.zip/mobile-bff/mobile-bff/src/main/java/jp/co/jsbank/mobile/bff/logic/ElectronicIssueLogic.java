package jp.co.jsbank.mobile.bff.logic;

import org.springframework.stereotype.Service;

import jp.co.jsbank.mobile.bff.dto.aba.CreateReportPdfAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.ElectronicIssueAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport001AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport002AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport003AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport004AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport005AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport006AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport007AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport008AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport009AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport010AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport011AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport012AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport013AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport014AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport015AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport016AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport017AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport018AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport019AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport021AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.LotteryResultAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.LotteryResultAbaResponseDto;

/**
 * 電子交付ロジック
 */
@Service
public interface ElectronicIssueLogic {

    /**
     * 帳票CSV内容照会_定期預金利息計算（懸賞金付）（自継）
     *
     * @param requestDto 電子交付ABAリクエストDTO
     * @return 定期預金利息計算（懸賞金付）（自継）
     */
    InquireReport001AbaResponseDto abaInquireReportCsv001(ElectronicIssueAbaRequestDto requestDto);

    /**
     * 帳票CSV内容照会_定期預金（懸賞金付）期日案内
     *
     * @param requestDto 電子交付ABAリクエストDTO
     * @return お知らせ閲覧レスポンスDTO
     */
    InquireReport002AbaResponseDto abaInquireReportCsv002(ElectronicIssueAbaRequestDto requestDto);

    /**
     * 帳票CSV内容照会_定期積金満期案内
     *
     * @param requestDto 電子交付ABAリクエストDTO
     * @return お知らせ閲覧レスポンスDTO
     */
    InquireReport003AbaResponseDto abaInquireReportCsv003(ElectronicIssueAbaRequestDto requestDto);

    /**
     * 帳票CSV内容照会_定期預金期日案内
     *
     * @param requestDto 電子交付ABAリクエストDTO
     * @return お知らせ閲覧レスポンスDTO
     */
    InquireReport004AbaResponseDto abaInquireReportCsv004(ElectronicIssueAbaRequestDto requestDto);

    /**
     * 帳票CSV内容照会_定期預金（自継）利息計算
     *
     * @param requestDto 電子交付ABAリクエストDTO
     * @return お知らせ閲覧レスポンスDTO
     */
    InquireReport005AbaResponseDto abaInquireReportCsv005(ElectronicIssueAbaRequestDto requestDto);

    /**
     * 帳票CSV内容照会_定期預金（自継）大口定期利息計算
     *
     * @param requestDto 電子交付ABAリクエストDTO
     * @return お知らせ閲覧レスポンスDTO
     */
    InquireReport006AbaResponseDto abaInquireReportCsv006(ElectronicIssueAbaRequestDto requestDto);

    /**
     * 帳票CSV内容照会_定期預金（自由金利）期日案内
     *
     * @param requestDto 電子交付ABAリクエストDTO
     * @return お知らせ閲覧レスポンスDTO
     */
    InquireReport007AbaResponseDto abaInquireReportCsv007(ElectronicIssueAbaRequestDto requestDto);

    /**
     * 帳票CSV内容照会_借入終了案内
     *
     * @param requestDto 電子交付ABAリクエストDTO
     * @return お知らせ閲覧レスポンスDTO
     */
    InquireReport008AbaResponseDto abaInquireReportCsv008(ElectronicIssueAbaRequestDto requestDto);

    /**
     * 帳票CSV内容照会_総合口座決算案内
     *
     * @param requestDto 電子交付ABAリクエストDTO
     * @return お知らせ閲覧レスポンスDTO
     */
    InquireReport009AbaResponseDto abaInquireReportCsv009(ElectronicIssueAbaRequestDto requestDto);

    /**
     * 帳票CSV内容照会_融資期日案内
     *
     * @param requestDto 電子交付ABAリクエストDTO
     * @return お知らせ閲覧レスポンスDTO
     */
    InquireReport010AbaResponseDto abaInquireReportCsv010(ElectronicIssueAbaRequestDto requestDto);

    /**
     * 帳票CSV内容照会_自動送金取扱終了案内
     *
     * @param requestDto 電子交付ABAリクエストDTO
     * @return お知らせ閲覧レスポンスDTO
     */
    InquireReport011AbaResponseDto abaInquireReportCsv011(ElectronicIssueAbaRequestDto requestDto);

    /**
     * 帳票CSV内容照会_財形年金預金受取案内
     *
     * @param requestDto 電子交付ABAリクエストDTO
     * @return お知らせ閲覧レスポンスDTO
     */
    InquireReport012AbaResponseDto abaInquireReportCsv012(ElectronicIssueAbaRequestDto requestDto);

    /**
     * 帳票CSV内容照会_証貸変動金利通知
     *
     * @param requestDto 電子交付ABAリクエストDTO
     * @return お知らせ閲覧レスポンスDTO
     */
    InquireReport013AbaResponseDto abaInquireReportCsv013(ElectronicIssueAbaRequestDto requestDto);

    /**
     * 帳票CSV内容照会_借入返済通知
     *
     * @param requestDto 電子交付ABAリクエストDTO
     * @return お知らせ閲覧レスポンスDTO
     */
    InquireReport014AbaResponseDto abaInquireReportCsv014(ElectronicIssueAbaRequestDto requestDto);

    /**
     * 帳票CSV内容照会_当座勘定照合表
     *
     * @param requestDto 電子交付ABAリクエストDTO
     * @return お知らせ閲覧レスポンスDTO
     */
    InquireReport015AbaResponseDto abaInquireReportCsv015(ElectronicIssueAbaRequestDto requestDto);

    /**
     * 帳票CSV内容照会_当座勘定照合表兼当座勘定決算通知
     *
     * @param requestDto 電子交付ABAリクエストDTO
     * @return お知らせ閲覧レスポンスDTO
     */
    InquireReport016AbaResponseDto abaInquireReportCsv016(ElectronicIssueAbaRequestDto requestDto);

    /**
     * 帳票CSV内容照会_貸金庫使用料期日案内
     *
     * @param requestDto 電子交付ABAリクエストDTO
     * @return お知らせ閲覧レスポンスDTO
     */
    InquireReport017AbaResponseDto abaInquireReportCsv017(ElectronicIssueAbaRequestDto requestDto);

    /**
     * 帳票CSV内容照会_割引手形計算明細表
     *
     * @param requestDto 電子交付ABAリクエストDTO
     * @return お知らせ閲覧レスポンスDTO
     */
    InquireReport018AbaResponseDto abaInquireReportCsv018(ElectronicIssueAbaRequestDto requestDto);

    /**
     * 帳票CSV内容照会_融資返済明細表
     *
     * @param requestDto 電子交付ABAリクエストDTO
     * @return お知らせ閲覧レスポンスDTO
     */
    InquireReport019AbaResponseDto abaInquireReportCsv019(ElectronicIssueAbaRequestDto requestDto);

    /**
     * 帳票CSV内容照会_財産形成預金残高通知書
     *
     * @param requestDto 電子交付ABAリクエストDTO
     * @return お知らせ閲覧レスポンスDTO
     */
    InquireReport021AbaResponseDto abaInquireReportCsv021(ElectronicIssueAbaRequestDto requestDto);

    /**
     * 電子交付物（PDF）照会
     *
     * @param requestDto 電子交付ABAリクエストDTO
     * @return 帳票PDF出力ABAレスポンスDTO

     */
    CreateReportPdfAbaResponseDto abaCreateReportPdf(ElectronicIssueAbaRequestDto requestDto);

	/**
	 * 抽選結果情報取得
	 *
	 * @param lotteryResultabaRequestDto 抽選結果情報ABAリクエストDTO
	 * @return 抽選結果
	 */
	LotteryResultAbaResponseDto getLotteryResultInfomation(LotteryResultAbaRequestDto requestDto);
}

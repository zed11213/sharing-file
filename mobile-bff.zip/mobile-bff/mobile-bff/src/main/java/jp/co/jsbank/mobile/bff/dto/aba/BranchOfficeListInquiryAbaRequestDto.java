package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import lombok.Data;

/**
 * 支店一覧照会リクエストDTO
 */
@Data
public class BranchOfficeListInquiryAbaRequestDto {

    /**
     * 金融機関コード
     */
    private String bankCode;
    
    /**
     * 店番
     */
    private String branchNumber;
    
    /**
     * 住所(検索キー)
     */
    private String address;
    
    /**
     * 表示順序オプション
     */
    private String orderOption;
    
    /**
     * 照会店舗タイプリスト
     */
    private List<String> branchInquiryTypeList;
}

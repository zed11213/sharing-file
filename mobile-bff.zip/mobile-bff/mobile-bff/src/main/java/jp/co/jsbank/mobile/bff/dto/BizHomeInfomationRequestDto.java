package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * biz自宅情報リクエストDTO
 */
@Data
public class BizHomeInfomationRequestDto {

    /**
     * 自宅郵便番号
     */
    private String homeZipCode;

    /**
     * 自宅都道府県（カナ）
     */
    private String homeStateKana;

    /**
     * 自宅都道府県
     */
    private String homeState;

    /**
     * 自宅市区町村（カナ）
     */
    private String homeCityKana;

    /**
     * 自宅市区町村
     */
    private String homeCity;

    /**
     * 自宅丁目（カナ）
     */
    private String homeStreetKana;

    /**
     * 自宅丁目
     */
    private String homeStreet;

    /**
     * 自宅番地（カナ）
     */
    private String homeAddressKana;

    /**
     * 自宅番地
     */
    private String homeAddress;

    /**
     * 自宅建物名・号室（カナ）
     */
    private String homeBuildingKana;

    /**
     * 自宅建物名・号室
     */
    private String homeBuilding;

}

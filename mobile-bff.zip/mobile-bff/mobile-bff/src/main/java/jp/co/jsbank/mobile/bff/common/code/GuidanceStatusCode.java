package jp.co.jsbank.mobile.bff.common.code;

/**
 * 案内ステータスコード
 */
public class GuidanceStatusCode {

    /**
     * TODO 公開中
     */
    public static final String IN_PUBLISHING = "01";
    
    /**
     * TODO 公開中
     */
    public static final String RESET_APPROVAL_WAITING = "02";
    
    /**
     * TODO 回答公開中
     */
    public static final String IN_ANSWER_RELEASE = "03";
}

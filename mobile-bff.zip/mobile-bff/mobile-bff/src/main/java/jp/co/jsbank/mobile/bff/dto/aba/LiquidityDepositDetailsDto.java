package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * 入出金明細情報(流動性預金)DTO
 */
@Data
public class LiquidityDepositDetailsDto {

    /**
     * 明細ID
     */
    private String detailId;

    /**
     * 取引店番
     */
    private String branchNumber;

    /**
     * 取引記号1
     */
    private String handling1;
    
    /**
     * 取引記号2
     */
    private String handling2;
    
    /**
     * 取引記号3
     */
    private String handling3;
    
    /**
     * 取引記号4
     */
    private String handling4;

    /**
     * 切手手形種類番号
     */
    private String billNumber;

    /**
     * 取引日
     */
    private String transactionDate;

    /**
     * 起算日
     */
    private String startingDate;

    /**
     * 概要
     */
    private String descriptionKanji;

    /**
     * 摘要文言カナ
     */
    private String descriptionKana;

    /**
     * 入金額
     */
    private String depositAmount;

    /**
     * 支払額
     */
    private String withdrawalAmount;

    /**
     * 取引後残高
     */
    private String balance;

    /**
     * 明細概要メモ
     */
    private String memo;

}

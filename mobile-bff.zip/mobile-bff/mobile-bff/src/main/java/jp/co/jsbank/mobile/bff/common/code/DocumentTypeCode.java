package jp.co.jsbank.mobile.bff.common.code;

/**
 * 文書種別コード
 */
public class DocumentTypeCode {

	/**
	 * 文書種別(01)
	 */
	public static final String DOCUMENTTYPE_01 = "01";

	/**
	 * 文書種別(02)
	 */
	public static final String DOCUMENTTYPE_02 = "02";

	/**
	 * 文書種別(03)
	 */
	public static final String DOCUMENTTYPE_03 = "03";

	/**
	 * 文書種別(04)
	 */
	public static final String DOCUMENTTYPE_04 = "04";

	/**
	 * 文書種別(05)
	 */
	public static final String DOCUMENTTYPE_05 = "05";

	/**
	 * 文書種別(06)
	 */
	public static final String DOCUMENTTYPE_06 = "06";

	/**
	 * 文書種別(07)
	 */
	public static final String DOCUMENTTYPE_07 = "07";
	
	/**
	 * 文書種別(08)
	 */
	public static final String DOCUMENTTYPE_08 = "08";

	/**
	 * 文書種別(09)
	 */
	public static final String DOCUMENTTYPE_09 = "09";

	/**
	 * 文書種別(10)
	 */
	public static final String DOCUMENTTYPE_10 = "10";
    
	/**
	 * 文書種別(11)
	 */
	public static final String DOCUMENTTYPE_11 = "11";
    
	/**
	 * 文書種別(12)
	 */
	public static final String DOCUMENTTYPE_12 = "12";

	/**
	 * 文書種別(13)
	 */
	public static final String DOCUMENTTYPE_13 = "13";

	/**
	 * 文書種別(14)
	 */
	public static final String DOCUMENTTYPE_14 = "14";

	/**
	 * 文書種別(15)
	 */
	public static final String DOCUMENTTYPE_15 = "15";

	/**
	 * 文書種別(16)
	 */
	public static final String DOCUMENTTYPE_16 = "16";

	/**
	 * 文書種別(17)
	 */
	public static final String DOCUMENTTYPE_17 = "17";

	/**
	 * 文書種別(18)
	 */
	public static final String DOCUMENTTYPE_18 = "18";
    
	/**
	 * 文書種別(19)
	 */
	public static final String DOCUMENTTYPE_19 = "19";

    /**
     * 文書種別(21)
     */
    public static final String DOCUMENTTYPE_21 = "21";
    
}

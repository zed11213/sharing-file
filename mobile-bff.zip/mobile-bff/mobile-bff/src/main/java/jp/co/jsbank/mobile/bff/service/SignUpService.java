package jp.co.jsbank.mobile.bff.service;

import java.util.List;

import org.springframework.stereotype.Service;

import jp.co.jsbank.mobile.bff.dto.BankbookPatternPreferenceRequestDto;
import jp.co.jsbank.mobile.bff.dto.DepartmentStoreInquiryResponseDto;
import jp.co.jsbank.mobile.bff.dto.EmailAddressAuthorizationRequestDto;
import jp.co.jsbank.mobile.bff.dto.EmailAddressRegistrationRequestDto;
import jp.co.jsbank.mobile.bff.dto.IdentityVerificationRequestDto;
import jp.co.jsbank.mobile.bff.dto.IdentityVerificationResponseDto;
import jp.co.jsbank.mobile.bff.dto.IvrAuthenticationRequestDto;
import jp.co.jsbank.mobile.bff.dto.PassBookLessPreferenceRequestDto;
import jp.co.jsbank.mobile.bff.dto.PushNotificationRegistrationRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.IvrSendingRequestDto;

/**
 * 初回登録サービス
 */
@Service
public interface SignUpService {

    /**
     * 部店照会リスト取得
     *
     * @return 部店照会リスト
     */
    List<DepartmentStoreInquiryResponseDto> departmentStoreInquiry();

    /**
     * 本人照合
     *
     * @param identityVerificationReq 本人照合リクエストDTO
     * @return 本人照合ResponseDTO
     */
    IdentityVerificationResponseDto identityVerification(IdentityVerificationRequestDto identityVerificationReq);

    /**
     * 利用者属性更新
     * 
     * @param requestDto 利用者属性更新リクエストDTO
     * @return 処理結果
     */
    String updateUserAttribute();

    /**
     * メールアドレス登録
     *
     * @param requestDto メールアドレス登録リクエストDTO
     * @return 処理結果
     */
    String emailAddressRegistration(EmailAddressRegistrationRequestDto requestDto);

    /**
     * メールアドレス認証
     *
     * @param requestDto メールアドレス認証リクエストDTO
     * @return 電話番号
     */
    List<String> emailAddressAuthorization(EmailAddressAuthorizationRequestDto requestDto);

    /**
     * IVR送信
     *
     * @param requestDto IVR送信リクエストDTO
     * @return 処理結果
     */
    String ivrSending(IvrSendingRequestDto requestDto);

    /**
     * IVR認証
     *
     * @param requestDto IVR認証リクエストDTO
     * @return [確認ダイアログ]画面表示
     */
    String ivrAuthentication(IvrAuthenticationRequestDto requestDto);

    /**
     * プッシュ通知登録
     *
     * @param requestDto プッシュ通知登録リクエストDTO
     * @return 処理結果
     */
    String pushNotificationRegistration(PushNotificationRegistrationRequestDto requestDto);

    /**
     * 通帳パターン設定
     *
     * @param requestDto 通帳パターン設定リクエストDTO
     * @return 処理結果
     */
    String bankbookPatternPreference(BankbookPatternPreferenceRequestDto requestDto);

    /**
     * 通帳レス設定
     *
     * @param requestDto 通帳レス設定
     * @return 処理結果
     */
    String bankBookLessPreference(PassBookLessPreferenceRequestDto requestDto);
}

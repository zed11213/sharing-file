package jp.co.jsbank.mobile.bff.config;

/**
 * CONFIG クラス
 */
public class Config {
}

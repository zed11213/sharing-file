package jp.co.jsbank.mobile.bff.config;

import java.sql.*;

public class DB2Test {
    /** Db2 on cloud: ユーザー名. */
    private static String JBA_DB2_USER = "6b3f8fca";  // 6b3f8fca

    /** Db2 on cloud: パスワード. */
    private static String JBA_DB2_PASSWORD = "J4Hq3xEiZ92r6zn7"; // J4Hq3xEiZ92r6zn7

    /** Db2 on cloud: ホスト名. */
    private static String JBA_DB2_HOSTNAME = "098360c5-ca26-40f6-b6d3-3826651d019e.bs2ipmbt0ifld8rdc9u0.private.databases.appdomain.cloud";

    /** Db2 on cloud: ポート番号. */
    private static int    JBA_DB2_PORT = 32040;

    /** Db2 on cloud: DB名. */
    private static String JBA_DB2_DBNAME = "bludb";

    /** Db2 on cloud: JDBC Driver Class名. */
    private static String JBA_DB2_DRIVER_CLSNAME = "com.ibm.db2.jcc.DB2Driver";

    /**
     * メインメソッド.
     * @param args
     * @throws Exception
     * @throws ClassNotFoundException
     */
    public static void main(String[] args) throws ClassNotFoundException, Exception {
        // Db2 on cloud 接続.
        db2Connect();
    }

    /**
     * Db2 on cloude接続.
     * @throws ClassNotFoundException
     * @throws Exception
     */
    private static void db2Connect() throws ClassNotFoundException, Exception {

        //        "password": "J4Hq3xEiZ92r6zn7",
        //        "username": "6b3f8fca"
        //        "hostname": "098360c5-ca26-40f6-b6d3-3826651d019e.bs2ipmbt0ifld8rdc9u0.private.databases.appdomain.cloud",
        //        "port": 32040
        //	      "database": "bludb",


        //JDBCドライバーをロードする
        System.out.println("class.forNameを実施.");
        Class.forName(JBA_DB2_DRIVER_CLSNAME);    //JDBCドライバクラス名

        // 接続URLを生成する.
        boolean flg = false;
        Connection conn = null;
        if (flg) {
            // URLを生成.
            String db2ConnectionUrl = String.format("jdbc:db2://%s:%d/%s"
                    , JBA_DB2_HOSTNAME
                    , JBA_DB2_PORT
                    , JBA_DB2_DBNAME);
            System.out.println("接続URL="+db2ConnectionUrl);

            //コネクションを取得する
            System.out.println("Db2の接続を実施.");
            conn = DriverManager.getConnection(db2ConnectionUrl, JBA_DB2_USER, JBA_DB2_PASSWORD);
            System.out.println("無事接続できたっす.");

        }
        else {
            //			String url = "jdbc:db2://098360c5-ca26-40f6-b6d3-3826651d019e.bs2ipmbt0ifld8rdc9u0.private.databases.appdomain.cloud:32040/bludb:user=%s;password=%s;sslConnection=true;";
            // String url = "jdbc:db2://098360c5-ca26-40f6-b6d3-3826651d019e.bs2ipmbt0ifld8rdc9u0.private.databases.appdomain.cloud:32040/bludb:user=%s;password=%s;sslConnection=false;";
            String url2= "jdbc:db2://098360c5-ca26-40f6-b6d3-3826651d019e.bs2ipmbt0ifld8rdc9u0.databases.appdomain.cloud:32040/bludb:user=%s;password=%s;sslConnection=true;";
            String db2ConnectionUrl = String.format(url2, JBA_DB2_USER, JBA_DB2_PASSWORD);
            System.out.println("接続URL="+db2ConnectionUrl);

            System.out.println("Db2の接続を実施.");
            conn = DriverManager.getConnection(db2ConnectionUrl);
            System.out.println("無事接続できたっす.");


            // 実行するSQL文とパラメータを指定する
//            String sql = "select id, name, address from test_table";
            String sql = "select * from t_test";
            PreparedStatement stmt = conn.prepareStatement(sql);

            // SELECTを実行する
            ResultSet rs = stmt.executeQuery();

            ResultSetMetaData metaData = rs.getMetaData();
            for (int i = 1; i < metaData.getColumnCount(); ++i)  {
                System.out.println(metaData.getColumnLabel(i));
            }



            // 取得した結果を全件出力する
            while(rs.next()){
                System.out.println("id" + rs.getInt("id"));
                System.out.println("name" + rs.getString("name"));
//                System.out.println("address" + rs.getString("address"));
//                System.out.println("TEL" + rs.getString("TEL"));
//                System.out.println("CREATED_AT" + rs.getString("CREATED_AT"));
//                System.out.println("DELETED_AT" + rs.getString("DELETED_AT"));
            }
            stmt.close();

        }

        //オートコミットをオフにする（任意）
        conn.setAutoCommit(false);    //デフォルトはオンになっています

        //
        //	}catch(Exception ex){
        //		// 例外発生時の処理
        //		ex.printStackTrace();  //エラー内容をコンソールに出力する
        //
        //	}finally{
        //		// クローズ処理
        //		if(rs != null) rs.close();
        //		if(prpStmt != null) prpStmt.close();
        //		if(conn != null) conn.close();

        conn.close();
    }
}

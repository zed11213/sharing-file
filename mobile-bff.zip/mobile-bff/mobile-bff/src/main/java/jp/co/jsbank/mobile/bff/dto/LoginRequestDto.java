package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * ログイン認証リクエストDTO
 */
@Data
public class LoginRequestDto {

    /**
     * パスワード
     */
    private String password;
}

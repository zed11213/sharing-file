package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * かんたん受付案内詳細照会ABAリクエストDTO
 */
@Data
public class EasyReceptionGuideDetailedInquiryAbaRequestDto {

    /**
     * お知らせID
     */
    private String anncmntId;

    /**
     * 受付案内ステータス
     */
    private String receptionGuideStatus;
}

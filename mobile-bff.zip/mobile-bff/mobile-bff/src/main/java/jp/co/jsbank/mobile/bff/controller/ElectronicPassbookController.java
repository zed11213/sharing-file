package jp.co.jsbank.mobile.bff.controller;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jp.co.jsbank.mobile.bff.common.JsonResult;
import jp.co.jsbank.mobile.bff.dto.AccountAndBalanceInfoResponseDto;
import jp.co.jsbank.mobile.bff.dto.BalanceGraphResponseDto;
import jp.co.jsbank.mobile.bff.dto.LiquidityDepositDetailsResponseDto;
import jp.co.jsbank.mobile.bff.dto.LotteryStatusRequestDto;
import jp.co.jsbank.mobile.bff.dto.MemoRegistrationRequestDto;
import jp.co.jsbank.mobile.bff.dto.NotificationDepositDetailsResponseDto;
import jp.co.jsbank.mobile.bff.dto.PeriodicDepositDetailsResponseDto;
import jp.co.jsbank.mobile.bff.dto.TimeDepositDetailsResponseDto;
import jp.co.jsbank.mobile.bff.service.ElectronicPassbookService;

/**
 * 電子通帳コントロール
 */
@RestController
public class ElectronicPassbookController {

    @Resource
    private ElectronicPassbookService electronicPassbookService;

    // private Logger logger =
    // LoggerFactory.getLogger(ElectronicPassbookController.class);

    /**
     * 口座一覧と各口座の残高情報取得
     *
     * @return 口座一覧と各口座の残高情報
     */
    @GetMapping(path = "/e-passbook/AB0401")
    public JsonResult getAccountListAndBalanceInformation() {

        // 口座一覧と各口座の残高情報取得
        AccountAndBalanceInfoResponseDto responseDto = electronicPassbookService.getAccountListAndBalanceInformation();

        return JsonResult.success(responseDto);
    }

    /**
     * 入出金明細取得(流動性預金)
     * 
     * @Param String detailContinuationFlag 明細継続フラグ
     * @Param String detailIdFrom 開始明細ID
     * @Param String maxInquiryCount最大検索件数
     * @Param String accountType 預金種目
     * @Param String branchNumber 店番
     * @param accountNumber 口座番号
     * @param dateOfInquiryFrom 照会開始年月日
     * @param dateOfInquiryTo 照会終了年月日
     * @return 入出金明細情報
     */
    @GetMapping(path = "/e-passbook/AB0402")
    public JsonResult getIiquidityDepositDetails(@RequestParam String detailContinuationFlag,
            @RequestParam String detailIdFrom, @RequestParam String maxInquiryCount, @RequestParam String accountType,
            @RequestParam String branchNumber, @RequestParam String accountNumber,
            @RequestParam String dateOfInquiryFrom, @RequestParam String dateOfInquiryTo) {

        // 流動性口座の入出金明細を取得する
        LiquidityDepositDetailsResponseDto responseDto = electronicPassbookService.getIiquidityDepositDetails(
                detailContinuationFlag, detailIdFrom, maxInquiryCount, accountType, branchNumber, accountNumber,
                dateOfInquiryFrom, dateOfInquiryTo);

        return JsonResult.success(responseDto);
    }

    /**
     * 定期預金明細取得
     *
     * @param accountNumber 口座番号
     * @param branchNumber 店番
     * @param cifNumber CIF番号
     * @return 定期預金明細情報
     */
    @GetMapping(path = "/e-passbook/AB0403")
    public JsonResult getTimeDepositDetails(@RequestParam String accountNumber, @RequestParam String branchNumber,
            @RequestParam String cifNumber) {

        // 定期預金明細取得を取得する
        List<TimeDepositDetailsResponseDto> responseDto = electronicPassbookService.getTimeDepositDetails(accountNumber,
                branchNumber, cifNumber);

        return JsonResult.success(responseDto);
    }

    /**
     * 定期積金明細取得
     *
     * @param accountNumber 口座番号
     * @param branchNumber 店番
     * @param cifNumber CIF番号
     * @return 定期積金明細情報
     */
    @GetMapping(path = "/e-passbook/AB0404")
    public JsonResult getPeriodicDepositDetails(@RequestParam String accountNumber, @RequestParam String branchNumber,
            @RequestParam String cifNumber) {

        // 定期積金明細を取得する
        PeriodicDepositDetailsResponseDto responseDto = electronicPassbookService
                .getPeriodicDepositDetails(accountNumber, branchNumber, cifNumber);

        return JsonResult.success(responseDto);
    }

    /**
     * 通知預金明細取得
     *
     * @param accountNumber 口座番号
     * @param branchNumber 店番
     * @param cifNumber CIF番号
     * @return 通知預金明細情報
     */
    @GetMapping(path = "/e-passbook/AB0405")
    public JsonResult getNotificationDepositDetails(@RequestParam String accountNumber,
            @RequestParam String branchNumber, @RequestParam String cifNumber) {

        // 通知預金明細を取得する
        NotificationDepositDetailsResponseDto responseDto = electronicPassbookService
                .getNotificationDepositDetails(accountNumber, branchNumber, cifNumber);

        return JsonResult.success(responseDto);
    }

    /**
     * 概要欄メモ登録
     *
     * @param requestDto 明細概要メモ登録リクエストDTO
     * @return 処理結果
     */
    @PutMapping(path = "/e-passbook/AB0406")
    public JsonResult overviewFieldMemoRegistration(@RequestBody MemoRegistrationRequestDto requestDto) {

        // 概要欄メモ登録
        String result = electronicPassbookService.overviewFieldMemoRegistration(requestDto);

        return JsonResult.success(result);
    }

    /**
     * 収支グラフ表示値取得
     *
     * @param accountNumber 口座番号
     * @param branchNumber 店番
     * @return 収支情報
     */
    @GetMapping(path = "/e-passbook/AB0407")
    public JsonResult getBalanceGraphDisplayValue(@RequestParam String accountNumber,
            @RequestParam String branchNumber) {

        // 収支グラフ表示値取得
        List<BalanceGraphResponseDto> responseDto = electronicPassbookService.getBalanceGraphDisplayValue(accountNumber,
                branchNumber);

        return JsonResult.success(responseDto);
    }

    /**
     * 抽選状態更新
     *
     * @param requestDto 抽選状態BFFリクエストDTO
     * @return 処理結果
     */
    @PutMapping(path = "/e-passbook/AB0408")
    public JsonResult lotteryStatusUpdate(@RequestBody LotteryStatusRequestDto requestDto) {

        // 抽選状態取得
        String responseDto = electronicPassbookService.lotteryStatusUpdate(requestDto);

        return JsonResult.success(responseDto);
    }
}

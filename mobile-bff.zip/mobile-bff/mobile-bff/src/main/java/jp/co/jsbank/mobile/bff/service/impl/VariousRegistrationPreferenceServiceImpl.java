package jp.co.jsbank.mobile.bff.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.jsbank.mobile.bff.common.Constant;
import jp.co.jsbank.mobile.bff.common.GetIdByTokenHandler;
import jp.co.jsbank.mobile.bff.common.RequestHeaderContext;
import jp.co.jsbank.mobile.bff.common.code.AccountTypeCode;
import jp.co.jsbank.mobile.bff.common.code.PassbookLessStatusCode;
import jp.co.jsbank.mobile.bff.common.code.SettingTypeCode;
import jp.co.jsbank.mobile.bff.dto.AccountInformationResponseDto;
import jp.co.jsbank.mobile.bff.dto.AccountInfosDto;
import jp.co.jsbank.mobile.bff.dto.AuthenticationKeyIssuanceResponseDto;
import jp.co.jsbank.mobile.bff.dto.CifInfomationResponseDto;
import jp.co.jsbank.mobile.bff.dto.DeleteUseAccountRequestDto;
import jp.co.jsbank.mobile.bff.dto.DepositBalanceInquiryResponseDto;
import jp.co.jsbank.mobile.bff.dto.EmailAddRegistrationRequestDto;
import jp.co.jsbank.mobile.bff.dto.EmailAddUpdateRequestDto;
import jp.co.jsbank.mobile.bff.dto.JuridicalPersonUserSettingRequestDto;
import jp.co.jsbank.mobile.bff.dto.NotificationSettingRequestDto;
import jp.co.jsbank.mobile.bff.dto.NotificationSettingResponseDto;
import jp.co.jsbank.mobile.bff.dto.PassbooklessSettingRequestDto;
import jp.co.jsbank.mobile.bff.dto.PassbooklessSettingResponseDto;
import jp.co.jsbank.mobile.bff.dto.UpdateDesignInfomationRequestDto;
import jp.co.jsbank.mobile.bff.dto.UseAccountRegistrationRequestDto;
import jp.co.jsbank.mobile.bff.dto.UserAdditionalConfirmationStatUpdateRequestDto;
import jp.co.jsbank.mobile.bff.dto.UserAttributeDto;
import jp.co.jsbank.mobile.bff.dto.UserAttributeInquiryConfirmationResponseDto;
import jp.co.jsbank.mobile.bff.dto.UserInfo;
import jp.co.jsbank.mobile.bff.dto.UserInformationDetailsDto;
import jp.co.jsbank.mobile.bff.dto.UserInformationDetailsResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.AccountInformationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.AccountInformationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.AccountRegistrationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.AuthenticationKeyIssuanceAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.BranchDetailDisplayAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.BranchDetailDisplayAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CifAttributeQueryInfomationDto;
import jp.co.jsbank.mobile.bff.dto.aba.CifDepositBalanceAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CifDepositBalanceAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CifInfomationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CifInfomationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CifInfomationDto;
import jp.co.jsbank.mobile.bff.dto.aba.CommonHeaderAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CurrentAccountAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.DeleteUseAccountAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.DepositsAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.EmailAddAuthorizationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.EmailAddChangingAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.NotificationDepositBalanceInquiryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.NotificationSettingAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.NotificationSettingAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.PassbooklesSettingAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.RegularProvidentFundAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.SavingsAccountsAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.SettingInfoDto;
import jp.co.jsbank.mobile.bff.dto.aba.StopTradingAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.TaxReserveDepositAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.UpdateDesignInfomationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.UseAccountRegistrationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.UseAccountRegistrationConfirmationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.UserAttributeInfoDto;
import jp.co.jsbank.mobile.bff.dto.aba.UserAttributeInquiryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.UserDataAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.UserElementUpdateAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.UserInformationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.UserSettingDetailsAbaResponseDto;
import jp.co.jsbank.mobile.bff.logic.VariousRegistrationPreferenceLogic;
import jp.co.jsbank.mobile.bff.service.VariousRegistrationPreferenceService;

/**
 * 各種登録設定サービス実装クラス
 */
@Service
public class VariousRegistrationPreferenceServiceImpl implements VariousRegistrationPreferenceService {

    /**
     * 各種登録設定ロジック
     */
    @Resource
    private VariousRegistrationPreferenceLogic variousRegistrationPreferenceLogic;

    @Autowired
    private GetIdByTokenHandler getIdByTokenHandler;

    /**
     * 通知設定情報取得
     *
     * @return 通知設定情報
     */
    @Override
    public NotificationSettingResponseDto getNotificationSetting() {

        // 利用者IDトークン取得する
        String userIdToken = RequestHeaderContext.getInstance().getUserIdToken();

        // redisから利用者IDを取得する
        String userId = getIdByTokenHandler.getIdByToken(userIdToken);

        // 通知設定情報取得
        NotificationSettingAbaResponseDto abaResponseDto = variousRegistrationPreferenceLogic
                .getNotificationSetting(userId);

        NotificationSettingResponseDto responseDto = new NotificationSettingResponseDto();
        if (Objects.nonNull(abaResponseDto.getSettingInfos()) && abaResponseDto.getSettingInfos().size() > 0) {

            // 利用者情報DTOリスト
            List<SettingInfoDto> userInfoList = abaResponseDto.getSettingInfos();

            responseDto.setSettingInfos(userInfoList);
        }

        return responseDto;
    }

    /**
     * 通知設定情報変更
     *
     * @param requestDto 通知設定BFFリクエストDTO
     * @return 処理結果
     */
    @Override
    public String changeNotificationSettingInfo(NotificationSettingRequestDto requestDto) {

        // 利用者IDトークン取得する
        String userIdToken = RequestHeaderContext.getInstance().getUserIdToken();

        // redisから利用者IDを取得する
        String userId = getIdByTokenHandler.getIdByToken(userIdToken);

        // 通知設定情報ABAリクエストDTO
        NotificationSettingAbaRequestDto abaRequestDto = new NotificationSettingAbaRequestDto();
        // 利用者ID設定
        abaRequestDto.setUserId(userId);

        // 設定情報DTO
        SettingInfoDto settingInfo = new SettingInfoDto();
        BeanUtils.copyProperties(requestDto, settingInfo);

        // 設定情報DTOリスト
        List<SettingInfoDto> settingInfos = new ArrayList<>();
        settingInfos.add(settingInfo);
        // 設定情報DTOリスト設定
        abaRequestDto.setSettingInfos(settingInfos);

        // 通知設定情報変更
        CommonHeaderAbaResponseDto result = variousRegistrationPreferenceLogic
                .changeNotificationSettingresultnfo(abaRequestDto);

        return "OK";
    }

    /**
     * メールアドレス変更
     *
     * @param requestDto メールアドレス変更リクエストDTO
     * @return 処理結果
     */
    @Override
    public String emailAddressChanging(EmailAddUpdateRequestDto requestDto) {

        // メールアドレス変更ABAリクエストDTO
        EmailAddChangingAbaRequestDto abaRequestDto = new EmailAddChangingAbaRequestDto();
        // 処理区分設定
        abaRequestDto.setProcessType(requestDto.getProcessType());
        // メールアドレス設定
        abaRequestDto.setEmailAddress(requestDto.getEmailAddress());

        // メールアドレス変更Aba
        CommonHeaderAbaResponseDto abaresponseDto = variousRegistrationPreferenceLogic
                .emailAddChangingAba(abaRequestDto);

        return "OK";
    }

    /**
     * メールアドレス登録
     *
     * @param requestDto メールアドレス認証BFFリクエストDTO
     * @return 処理結果
     */
    @Override
    public String emailAddressRegistration(EmailAddRegistrationRequestDto requestDto) {

        // 利用者IDトークン取得する
        String userIdToken = RequestHeaderContext.getInstance().getUserIdToken();

        // redisから利用者IDを取得する
        String userId = getIdByTokenHandler.getIdByToken(userIdToken);
        // 画面ID
        String screenId = RequestHeaderContext.getInstance().getScreenId();
        // メールアドレス認証ABAリクエストDTO
        EmailAddAuthorizationAbaRequestDto abaRequestDto = new EmailAddAuthorizationAbaRequestDto();

        // メールアドレス
        abaRequestDto.setEmailAddress(requestDto.getEmailAddress());

        // 受付番号
        abaRequestDto.setReceiptNumber(requestDto.getReceiptNumber());

        // メールOTP
        abaRequestDto.setMailOTP(requestDto.getMailOTP());

        // 更新パターン
        abaRequestDto.setUpdateType(requestDto.getUpdateType());

        // 画面ID
        abaRequestDto.setPageId(screenId);

        // メールアドレス認証ABA
        CommonHeaderAbaResponseDto abaresponseDto = variousRegistrationPreferenceLogic
                .emailAddAuthorizationAba(abaRequestDto);

        // 利用者属性更新ABAリクエストDTO
        UserElementUpdateAbaRequestDto userElementUpdateAbaRequestDto = new UserElementUpdateAbaRequestDto();
        // 利用者ID設定
        userElementUpdateAbaRequestDto.setUserId(userId);
        // メールアドレス設定
        userElementUpdateAbaRequestDto.setEmailAddress(requestDto.getEmailAddress());
        // 利用者属性更新Aba
        CommonHeaderAbaResponseDto userElementUpdateAbaResponseDto = variousRegistrationPreferenceLogic
                .userElementUpdateAba(userElementUpdateAbaRequestDto);

        return "OK";
    }

    /**
     * 取引停止
     *
     * @return 利用者情報レスポンスDTOリスト
     */
    @Override
    public String tradingStop() {

        // 利用者IDトークン取得する
        String userIdToken = RequestHeaderContext.getInstance().getUserIdToken();

        // redisから利用者IDを取得する
        String userId = getIdByTokenHandler.getIdByToken(userIdToken);

        // 利用者IDトークン取得する
        String jbaIdToken = RequestHeaderContext.getInstance().getJbaIdToken();

        // redisから利用者IDを取得する
        String jbaId = getIdByTokenHandler.getIdByToken(jbaIdToken);
        // 取引停止情報ABAリクエストDTO
        StopTradingAbaRequestDto stopTradingAbaRequestDto = new StopTradingAbaRequestDto();
        // 利用者ID設定
        stopTradingAbaRequestDto.setUserId(userId);
        // 顧客ID
        stopTradingAbaRequestDto.setCustomerId(jbaId);
        // 利用者情報Aba
        CommonHeaderAbaResponseDto abaResponseDto = variousRegistrationPreferenceLogic
                .stopTrading(stopTradingAbaRequestDto);

        return "OK";
    }

    /**
     * 利用者追加確認ステータス更新
     * 
     * @param requestDto 利用者追加確認ステータス更新BFFリクエストDTO
     * @return 処理結果
     */
    @Override
    public String userAdditionalConfirmationStatUpdate(UserAdditionalConfirmationStatUpdateRequestDto requestDto) {

        // 利用者情報AbaレスポンスDTO
        UserInformationAbaRequestDto userInformationAbaRequestDto = new UserInformationAbaRequestDto();
        // 利用者ID設定
        userInformationAbaRequestDto.setUserId(requestDto.getUserId());
        // 利用者区分
        userInformationAbaRequestDto.setUserType(requestDto.getUserType());
        // 漢字氏名
        userInformationAbaRequestDto.setCustomerKanjiName(requestDto.getCustomerKanjiName());
        // カナ氏名
        userInformationAbaRequestDto.setCustomerName(requestDto.getCustomerName());
        // 所属
        userInformationAbaRequestDto.setDivision(requestDto.getDivision());

        // 確認ステータス
        userInformationAbaRequestDto.setStatus(requestDto.getStatus());
        // 利用者情報ABA
        CommonHeaderAbaResponseDto userInfomationAbaResponseDto = variousRegistrationPreferenceLogic
                .userInformationAba(userInformationAbaRequestDto);

        return "OK";
    }

    /**
     * 認証キー発行
     * 
     * @param requestDto 利用者情報
     * @return 認証キー
     */
    @Override
    public AuthenticationKeyIssuanceResponseDto authenticationKeyIssuance(UserInfo requestDto) {
        // 利用者情報ABAレスボスDto
        UserDataAbaRequestDto userDataAbaRequestDto = new UserDataAbaRequestDto();

        BeanUtils.copyProperties(requestDto, userDataAbaRequestDto);

        // 利用者IDトークン取得する
        String jbaIdToken = RequestHeaderContext.getInstance().getJbaIdToken();

        // redisから利用者IDを取得する
        String jbaId = getIdByTokenHandler.getIdByToken(jbaIdToken);

        // JBAID設定
        userDataAbaRequestDto.setJbaId(jbaId);

        // 認証キー発行Aba
        AuthenticationKeyIssuanceAbaResponseDto authenticationKeyIssuanceAbaResponseDto = variousRegistrationPreferenceLogic
                .authenticationKeyIssuanceAba(userDataAbaRequestDto);

        // 認証キー設定
        AuthenticationKeyIssuanceResponseDto responseDto = new AuthenticationKeyIssuanceResponseDto();
        responseDto.setAuthenticationKey(authenticationKeyIssuanceAbaResponseDto.getAuthenticationKey());
        responseDto.setExpiryDateTime(authenticationKeyIssuanceAbaResponseDto.getExpiryDateTime());

        return responseDto;
    }

    /**
     * 利用口座登録確認情利用口座登録報取得
     *
     * @param branchCode 店番
     * @param accountNumber 口座番号
     * @param accountType 預金種目
     * @return 処理結果
     */
    @Override
    public UserAttributeInquiryConfirmationResponseDto getUseAccountRegistrationConfirmation(String branchCode,
            String accountNumber, String accountType) {
        // ABAのエンドユーザーログインを認証する
        String jbaIdToken = RequestHeaderContext.getInstance().getJbaIdToken();

        // redisから利用者IDを取得する
        String jbaId = getIdByTokenHandler.getIdByToken(jbaIdToken);
        // 利用口座登録ABAリクエストDTO
        UseAccountRegistrationConfirmationAbaRequestDto abaRequestDto = new UseAccountRegistrationConfirmationAbaRequestDto();

        // 店番
        abaRequestDto.setBranchCode(branchCode);

        // 口座番号
        abaRequestDto.setAccountNumber(accountNumber);

        // 預金種目
        abaRequestDto.setAccountType(accountType);
        DepositBalanceInquiryResponseDto depositBalanceInquiryResponseDto = new DepositBalanceInquiryResponseDto();
        // 普通預金
        if (StringUtils.equals(accountType, AccountTypeCode.SAVING_ACCOUNTS)) {
            // 普通預金残高照会AbaレスポンスDTO
            SavingsAccountsAbaResponseDto abaResponseDto = variousRegistrationPreferenceLogic
                    .getSavingsAccountsInfomation(abaRequestDto);

            BeanUtils.copyProperties(abaResponseDto, depositBalanceInquiryResponseDto);

        } else if (StringUtils.equals(accountType, AccountTypeCode.FIXED_TERM_DEPOSIT)) {
            // 定期預金残高照会AbaレスポンスDTO
            DepositsAbaResponseDto abaResponseDto = variousRegistrationPreferenceLogic
                    .getDepositsInfomation(abaRequestDto);

            BeanUtils.copyProperties(abaResponseDto, depositBalanceInquiryResponseDto);
        } else if (StringUtils.equals(accountType, AccountTypeCode.FIXED_TERM_FIXED)) {
            // 定期積金残高照会AbaレスポンスDTO
            RegularProvidentFundAbaResponseDto abaResponseDto = variousRegistrationPreferenceLogic
                    .getRegularProvidentFundInfomation(abaRequestDto);

            BeanUtils.copyProperties(abaResponseDto, depositBalanceInquiryResponseDto);
        } else if (StringUtils.equals(accountType, AccountTypeCode.TAX_PAYMENT_DEPOSIT)) {
            // 納税準備預金残高照会AbaレスポンスDTO
            TaxReserveDepositAbaResponseDto abaResponseDto = variousRegistrationPreferenceLogic
                    .getTaxReserveDepositInfomation(abaRequestDto);

            BeanUtils.copyProperties(abaResponseDto, depositBalanceInquiryResponseDto);
        } else if (StringUtils.equals(accountType, AccountTypeCode.CURRENT_ACCOUNT)) {
            // 当座預金残高照会AbaレスポンスDTO
            CurrentAccountAbaResponseDto abaResponseDto = variousRegistrationPreferenceLogic
                    .getCurrentAccountInfomation(abaRequestDto);

            BeanUtils.copyProperties(abaResponseDto, depositBalanceInquiryResponseDto);
        } else if (StringUtils.equals(accountType, AccountTypeCode.NOTIFICATION_DEPOSIT)) {
            // 通知預金残高照会AbaレスポンスDTO
            NotificationDepositBalanceInquiryAbaResponseDto abaResponseDto = variousRegistrationPreferenceLogic
                    .getNotificationDepositInfomation(abaRequestDto);

            BeanUtils.copyProperties(abaResponseDto, depositBalanceInquiryResponseDto);
        }
        // CIF情報取得リクエストDTO
        CifInfomationAbaRequestDto cifInfomationAbaRequestDto = new CifInfomationAbaRequestDto();
        // 顧客ID設定
        cifInfomationAbaRequestDto.setCustomerId(jbaId);

        // CIF情報取得
        CifInfomationAbaResponseDto cifInfomationAbaResponseDto = variousRegistrationPreferenceLogic
                .getGifInfomation(cifInfomationAbaRequestDto);
        // CIF番号
        String cifNumber = depositBalanceInquiryResponseDto.getCifNumber();
        // 利用口座登録レスボスDTO
        UserAttributeInquiryConfirmationResponseDto userAttributeInquiryResponseDto = new UserAttributeInquiryConfirmationResponseDto();
        if (cifInfomationAbaResponseDto.getCifInfomationDtoList() != null
                && cifInfomationAbaResponseDto.getCifInfomationDtoList().size() > 0) {

            for (CifInfomationDto cifInfomationDto : cifInfomationAbaResponseDto.getCifInfomationDtoList()) {

                // 店番設定
                String passbookLessSettingStatus = cifInfomationDto.getPassbookLessSettingStatus();

                if (StringUtils.equals(cifNumber, cifInfomationDto.getCifNumber())
                        && StringUtils.equals(passbookLessSettingStatus, PassbookLessStatusCode.NOT_SET)) {
                    // CIF預金残高一覧照会リクエストDTO
                    CifDepositBalanceAbaRequestDto cifDepositBalanceAbaRequestDto = new CifDepositBalanceAbaRequestDto();
                    // CIF番号
                    cifDepositBalanceAbaRequestDto.setCifNumber(cifNumber);

                    // CIF預金残高一覧照会レスポンスDTO
                    CifDepositBalanceAbaResponseDto cifDepositBalanceAbaResponseDto = variousRegistrationPreferenceLogic
                            .getCifDepositBalanceInfomation(cifDepositBalanceAbaRequestDto);

                    // 口座情報リスト
                    List<UserAttributeDto> userAttributeList = new ArrayList<>();

                    List<AccountInfosDto> accountInfosList = cifDepositBalanceAbaResponseDto.getAccountInfo();
                    if (accountInfosList != null && accountInfosList.size() > 0) {
                        for (AccountInfosDto infoResponseDto : accountInfosList) {
                            // 支店詳細照会リクエストDTO
                            BranchDetailDisplayAbaRequestDto branchDetailDisplayAbaRequestDto = new BranchDetailDisplayAbaRequestDto();
                            branchDetailDisplayAbaRequestDto.setBranchNumber(infoResponseDto.getBranchNumber());
                            // 金融機関コードに「1344」を設定する
                            branchDetailDisplayAbaRequestDto.setBankCode(Constant.FIXED_VALUE_FINANCIAL_CODE);
                            BranchDetailDisplayAbaResponseDto branchDetailDisplayAbaResponseDto = variousRegistrationPreferenceLogic
                                    .getBranchDetailDisplayInfomation(branchDetailDisplayAbaRequestDto);
                            // 口座情報DTO
                            UserAttributeDto userAttributeDto = new UserAttributeDto();
                            userAttributeDto.setBranchNumber(infoResponseDto.getBranchNumber());
                            userAttributeDto.setBranchKanjiName(branchDetailDisplayAbaResponseDto.getBranchKanjiName());
                            userAttributeDto.setSubjectNameValue(infoResponseDto.getSubjectNameValue());
                            userAttributeDto.setAccountNumber(infoResponseDto.getAccountNumber());
                            userAttributeList.add(userAttributeDto);
                        }
                    }

                    // CIF情報リスト
                    List<CifAttributeQueryInfomationDto> cifAttributeQueryDtoList = new ArrayList<>();

                    // CIF情報DTO
                    CifAttributeQueryInfomationDto cifAttributeQueryInfomationDto = new CifAttributeQueryInfomationDto();

                    cifAttributeQueryInfomationDto.setBranchCode(userAttributeList.get(0).getBranchNumber());
                    cifAttributeQueryInfomationDto.setCifNo(cifNumber);
                    // 利用口座登録リスト設定
                    userAttributeInquiryResponseDto.setAccountInfo(userAttributeList);
                    // CIFリスト設定
                    cifAttributeQueryDtoList.add(cifAttributeQueryInfomationDto);
                    userAttributeInquiryResponseDto.setCifInfomationDtoList(cifAttributeQueryDtoList);
                    // 通帳リストレス設定状態設定
                    userAttributeInquiryResponseDto
                            .setPassbookLessSettingStatus(cifInfomationDto.getPassbookLessSettingStatus());

                }
            }
        }

        return userAttributeInquiryResponseDto;
    }

    /**
     * 利用口座削除
     *
     * @param requestDto 通知設定BFFリクエストDTO
     * @return 処理結果
     */
    @Override
    public String deleteUseAccount(DeleteUseAccountRequestDto requestDto) {

        // ABAのエンドユーザーログインを認証する
        String jbaIdToken = RequestHeaderContext.getInstance().getJbaIdToken();

        // redisから利用者IDを取得する
        String jbaId = getIdByTokenHandler.getIdByToken(jbaIdToken);
        // 利用口座削除ABAリクエストDTO
        DeleteUseAccountAbaRequestDto abaRequestDto = new DeleteUseAccountAbaRequestDto();
        // 顧客ID設定
        abaRequestDto.setCustomerId(jbaId);
        abaRequestDto.setCifNo(requestDto.getCifNumber());

        // 利用口座削除
        CommonHeaderAbaResponseDto response = variousRegistrationPreferenceLogic.deleteUseAccount(abaRequestDto);

        return "OK";
    }

    /**
     * デザイン取得
     *
     * @return 設定値
     */
    @Override
    public String getDesignInfomation() {

        // 利用者IDトークン取得する
        String userIdToken = RequestHeaderContext.getInstance().getUserIdToken();

        // redisから利用者IDを取得する
        String userId = getIdByTokenHandler.getIdByToken(userIdToken);

        // 設定済みデザイン情報取得
        UserAttributeInquiryAbaResponseDto abaResponseDto = variousRegistrationPreferenceLogic
                .getDesignInfomation(userId);

        // 設定情報DTOリスト
        List<SettingInfoDto> settingInfos = null;

        List<UserAttributeInfoDto> userAttributeInfos = abaResponseDto.getUserInfoList();
        if (Objects.nonNull(userAttributeInfos) && userAttributeInfos.size() > 0) {

            settingInfos = userAttributeInfos.get(0).getSettingInfos();
        }

        // 設定情報DTO
        SettingInfoDto settingInfoDto = null;
        if (Objects.nonNull(settingInfos) && settingInfos.size() > 0) {

            settingInfoDto = settingInfos.stream()
                    .filter(val -> SettingTypeCode.PASSBOOK_PATTERN_SETTING.equals(val.getSettingType())).findAny()
                    .orElse(null);
        }

        // 設定値
        String settingContent = "1";

        if (Objects.nonNull(settingInfoDto)) {

            settingContent = settingInfoDto.getSettingContent();
        }

        return settingContent;
    }

    /**
     * デザイン更新
     *
     * @param requestDto デザイン更新BFFリクエストDTO
     * @return 処理結果
     */
    @Override
    public String updateDesignInfomation(UpdateDesignInfomationRequestDto requestDto) {

        // 利用者IDトークン取得する
        String userIdToken = RequestHeaderContext.getInstance().getUserIdToken();

        // redisから利用者IDを取得する
        String userId = getIdByTokenHandler.getIdByToken(userIdToken);

        // デザイン更新ABAリクエストDTO
        UpdateDesignInfomationAbaRequestDto abaRequestDto = new UpdateDesignInfomationAbaRequestDto();
        // 利用者ID設定
        abaRequestDto.setUserId(userId);
        // 設定種別設定
        abaRequestDto.setSettingType(SettingTypeCode.PASSBOOK_PATTERN_SETTING);
        // 設定内容設定
        abaRequestDto.setSettingContent(requestDto.getSettingContent());

        // デザイン更新
        CommonHeaderAbaResponseDto response = variousRegistrationPreferenceLogic.updateDesignInfomation(abaRequestDto);

        return "OK";
    }

    /**
     * 法人利用者情報一覧取得
     *
     * @param jbaIdToken JBAID
     * @return 処理結果
     */
    @Override
    public UserInformationDetailsResponseDto getJuridicalPersonUserDetails() {
        // ABAのエンドユーザーログインを認証する
        String jbaIdToken = RequestHeaderContext.getInstance().getJbaIdToken();

        // redisから利用者IDを取得する
        String jbaId = getIdByTokenHandler.getIdByToken(jbaIdToken);

        // 法人利用者情報取得リクエストDTO
        JuridicalPersonUserSettingRequestDto juridicalPersonUserSettingRequestDto = new JuridicalPersonUserSettingRequestDto();
        // JBAID設定
        juridicalPersonUserSettingRequestDto.setJbaid(jbaId);

        // 法人利用者情報取得ABAリクエストDTO
        UserSettingDetailsAbaResponseDto abaResponseDto = new UserSettingDetailsAbaResponseDto();

        // 利用者情報照会APIを呼び出し
        abaResponseDto = variousRegistrationPreferenceLogic.getJuridicalPersonUserDetails(jbaId);

        // 利用者情報レスポンスDTOリスト
        UserInformationDetailsResponseDto responseDto = new UserInformationDetailsResponseDto();

        // 利用者情報DTOリスト
        List<UserInformationDetailsDto> userInformationDetailsDto = abaResponseDto.getUserInfoList();

        responseDto.setUserInfoList(userInformationDetailsDto);
        return responseDto;
    }

    /**
     * CIF情報取得
     *
     * @return CIF情報
     */
    @Override
    public CifInfomationResponseDto getCifInfomation() {
        // ABAのエンドユーザーログインを認証する
        String jbaIdToken = RequestHeaderContext.getInstance().getJbaIdToken();

        // redisから利用者IDを取得する
        String jbaId = getIdByTokenHandler.getIdByToken(jbaIdToken);

        // CIF情報取得リクエストDTO
        CifInfomationAbaRequestDto cifInfomationAbaRequestDto = new CifInfomationAbaRequestDto();
        // 顧客ID設定
        cifInfomationAbaRequestDto.setCustomerId(jbaId);
        // CIF情報取得
        CifInfomationAbaResponseDto abaResponseDto = variousRegistrationPreferenceLogic
                .getCifInfomation(cifInfomationAbaRequestDto);
        List<CifInfomationDto> cifInfomationList = abaResponseDto.getCifInfomationDtoList();
        CifInfomationResponseDto responseDto = new CifInfomationResponseDto();
        if (cifInfomationList != null && cifInfomationList.size() > 0) {

            for (CifInfomationDto cifInfomationDto : cifInfomationList) {
                // 支店詳細照会リクエストDTO
                BranchDetailDisplayAbaRequestDto branchDetailDisplayAbaRequestDto = new BranchDetailDisplayAbaRequestDto();
                branchDetailDisplayAbaRequestDto.setBranchNumber(cifInfomationDto.getBranchCode());
                // 金融機関コードに「1344」を設定する
                branchDetailDisplayAbaRequestDto.setBankCode(Constant.FIXED_VALUE_FINANCIAL_CODE);
                BranchDetailDisplayAbaResponseDto branchDetailDisplayAbaResponseDto = variousRegistrationPreferenceLogic
                        .getBranchDetailDisplayInfomation(branchDetailDisplayAbaRequestDto);
                cifInfomationDto.setBranchKanjiName(branchDetailDisplayAbaResponseDto.getBranchKanjiName());
            }
        }

        responseDto.setCifInfomationDtoList(abaResponseDto.getCifInfomationDtoList());
        return responseDto;
    }

    /**
     * 口座情報取得
     *
     * @param branchCode 店番
     * @param cifNumber CIF番号
     * @return 口座情報
     */
    @Override
    public AccountInformationResponseDto getAccountInformation(String branchCode, String cifNumber) {
        // ABAのエンドユーザーログインを認証する
        String jbaIdToken = RequestHeaderContext.getInstance().getJbaIdToken();

        // redisから利用者IDを取得する
        String jbaId = getIdByTokenHandler.getIdByToken(jbaIdToken);

        // 口座情報取得リクエストDTO
        AccountInformationAbaRequestDto requestDto = new AccountInformationAbaRequestDto();
        // 顧客ID設定
        requestDto.setCustomerId(jbaId);
        // CIF番号
        requestDto.setCifNumber(cifNumber);
        // 店番
        requestDto.setBranchCode(branchCode);

        // 口座情報取得
        AccountInformationAbaResponseDto abaResponseDto = variousRegistrationPreferenceLogic
                .getAccountInformation(requestDto);
        AccountInformationResponseDto responseDto = new AccountInformationResponseDto();
        responseDto.setAccountInformationList(abaResponseDto.getAccountInformationList());
        return responseDto;
    }

    /**
     * 利用口座登録
     *
     * @param requestDto 利用口座登録BFFリクエストDTO
     * @return 処理結果
     */
    @Override
    public String useAccountRegistration(UseAccountRegistrationRequestDto requestDto) {
        // ABAのエンドユーザーログインを認証する
        String jbaIdToken = RequestHeaderContext.getInstance().getJbaIdToken();

        // redisから利用者IDを取得する
        String jbaId = getIdByTokenHandler.getIdByToken(jbaIdToken);

        // 利用口座登録ABAリクエストDTO
        UseAccountRegistrationAbaRequestDto abaRequestDto = new UseAccountRegistrationAbaRequestDto();

        // 顧客ID
        abaRequestDto.setCustomerId(jbaId);

        // 店番
        abaRequestDto.setBranchCode(requestDto.getBranchCode());

        // 登録口座番号
        abaRequestDto.setRegisterAccountNumber(requestDto.getRegisterAccountNumber());

        // 預金種目
        abaRequestDto.setAccountType(requestDto.getAccountType());

        // 初回登録フラグ
        abaRequestDto.setRegisterFlg(requestDto.getRegisterFlg());

        // サブNo
        abaRequestDto.setSubNo(requestDto.getSubNo());

        // 利用口座登録AbaレスポンスDTO
        AccountRegistrationAbaResponseDto accountRegistrationAbaResponseDto = variousRegistrationPreferenceLogic
                .getCifInformation(abaRequestDto);

        // 通帳レス設定状態
        String passbookLessSettingStatus = requestDto.getPassbookLessSettingStatus();
        if (StringUtils.equals(passbookLessSettingStatus, PassbookLessStatusCode.NOT_SET)) {
            // 通帳レス設定ABAリクエストDTO
            PassbooklesSettingAbaRequestDto passbooklesSettingAbaRequestDto = new PassbooklesSettingAbaRequestDto();
            // CIF番号
            passbooklesSettingAbaRequestDto.setCifNo(accountRegistrationAbaResponseDto.getCifNumber());
            // 店番
            passbooklesSettingAbaRequestDto.setBranchNumber(requestDto.getBranchCode());

            // 通帳レス設定ABAレスポンスDTO
            CommonHeaderAbaResponseDto abaResponseDto = variousRegistrationPreferenceLogic
                    .getPassbooklessSettingInformation(passbooklesSettingAbaRequestDto);
        }

        return "OK";
    }

    /**
     * 通帳レス情報取得
     *
     * @return 処理結果
     */
    @Override
    public PassbooklessSettingResponseDto getPassBooklessInformation() {
        // ABAのエンドユーザーログインを認証する
        String jbaIdToken = RequestHeaderContext.getInstance().getJbaIdToken();

        // redisから利用者IDを取得する
        String jbaId = getIdByTokenHandler.getIdByToken(jbaIdToken);

        // CIF情報取得リクエストDTO
        CifInfomationAbaRequestDto cifInfomationAbaRequestDto = new CifInfomationAbaRequestDto();
        // 顧客ID設定
        cifInfomationAbaRequestDto.setCustomerId(jbaId);

        // CIF情報取得
        CifInfomationAbaResponseDto cifInfomationAbaResponseDto = variousRegistrationPreferenceLogic
                .getGifInfomation(cifInfomationAbaRequestDto);

        // 口座情報リスト
        List<UserAttributeDto> userAttributeList = new ArrayList<>();
        // 通帳レス情報取得レスボスDTO
        PassbooklessSettingResponseDto passbooklessSettingResponseDto = new PassbooklessSettingResponseDto();
        if (cifInfomationAbaResponseDto.getCifInfomationDtoList() != null
                && cifInfomationAbaResponseDto.getCifInfomationDtoList().size() > 0) {
            List<CifAttributeQueryInfomationDto> cifInfomationDtoList = new ArrayList<>();
            for (CifInfomationDto cifInfomationDto : cifInfomationAbaResponseDto.getCifInfomationDtoList()) {
                CifAttributeQueryInfomationDto cifAttributeQueryInfomationDto = new CifAttributeQueryInfomationDto();
                // CIF預金残高一覧照会リクエストDTO
                CifDepositBalanceAbaRequestDto cifDepositBalanceAbaRequestDto = new CifDepositBalanceAbaRequestDto();
                // CIF番号
                cifDepositBalanceAbaRequestDto.setCifNumber(cifInfomationDto.getCifNumber());

                // CIF預金残高一覧照会レスポンスDTO
                CifDepositBalanceAbaResponseDto cifDepositBalanceAbaResponseDto = variousRegistrationPreferenceLogic
                        .getCifDepositBalanceInfomation(cifDepositBalanceAbaRequestDto);

                // 通帳レス設定状態設定
                String passbookLessSettingStatus = cifInfomationDto.getPassbookLessSettingStatus();

                if (StringUtils.equals(passbookLessSettingStatus, PassbookLessStatusCode.NOT_SET)) {
                    List<AccountInfosDto> accountInfosList = cifDepositBalanceAbaResponseDto.getAccountInfo();
                    if (accountInfosList != null && accountInfosList.size() > 0) {
                        for (AccountInfosDto infoResponseDto : accountInfosList) {
                            // 支店詳細照会リクエストDTO
                            BranchDetailDisplayAbaRequestDto branchDetailDisplayAbaRequestDto = new BranchDetailDisplayAbaRequestDto();
                            branchDetailDisplayAbaRequestDto.setBranchNumber(infoResponseDto.getBranchNumber());
                            // 金融機関コードに「1344」を設定する
                            branchDetailDisplayAbaRequestDto.setBankCode(Constant.FIXED_VALUE_FINANCIAL_CODE);
                            BranchDetailDisplayAbaResponseDto branchDetailDisplayAbaResponseDto = variousRegistrationPreferenceLogic
                                    .getBranchDetailDisplayInfomation(branchDetailDisplayAbaRequestDto);
                            // 口座情報DTO
                            UserAttributeDto userAttributeDto = new UserAttributeDto();
                            userAttributeDto.setBranchNumber(infoResponseDto.getBranchNumber());
                            userAttributeDto.setBranchKanjiName(branchDetailDisplayAbaResponseDto.getBranchKanjiName());
                            userAttributeDto.setSubjectNameValue(infoResponseDto.getSubjectNameValue());
                            userAttributeDto.setAccountNumber(infoResponseDto.getAccountNumber());
                            userAttributeList.add(userAttributeDto);

                        }
                    }
                    // 利用口座登録リスト設定
                    passbooklessSettingResponseDto.setAccountInfo(userAttributeList);

                }
                cifAttributeQueryInfomationDto.setCifNo(cifInfomationDto.getCifNumber());
                cifAttributeQueryInfomationDto.setBranchCode(cifInfomationDto.getBranchCode());
                cifInfomationDtoList.add(cifAttributeQueryInfomationDto);
            }
            // CIF情報リスト
            passbooklessSettingResponseDto.setCifInfomationDtoList(cifInfomationDtoList);
        }

        return passbooklessSettingResponseDto;
    }

    /**
     * 通帳レス設定
     *
     * @return 処理結果
     */
    @Override
    public String passBooklessSetting(PassbooklessSettingRequestDto requestDto) {

        List<CifAttributeQueryInfomationDto> cifInfomationDtoList = requestDto.getCifInfomationDtoList();

        if (cifInfomationDtoList != null && cifInfomationDtoList.size() > 0) {

            for (CifAttributeQueryInfomationDto cifInfomationDto : cifInfomationDtoList) {

                // 通帳レス設定ABAリクエストDTO
                PassbooklesSettingAbaRequestDto passbooklesSettingAbaRequestDto = new PassbooklesSettingAbaRequestDto();
                // CIF番号
                passbooklesSettingAbaRequestDto.setCifNo(cifInfomationDto.getCifNo());
                // 店番
                passbooklesSettingAbaRequestDto.setBranchNumber(cifInfomationDto.getBranchCode());

                // 通帳レス設定ABAレスポンスDTO
                CommonHeaderAbaResponseDto abaResponseDto = variousRegistrationPreferenceLogic
                        .getPassbooklessSettingInformation(passbooklesSettingAbaRequestDto);
            }
        }
        return "OK";
    }
}

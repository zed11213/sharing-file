package jp.co.jsbank.mobile.bff.common.exception;

/**
 * データなし例外。
 *
 */
public class InternalServerErrorException extends BusinessException {

	private static final long serialVersionUID = -1L;

	/**
	 * InternalServerErrorExceptionのコンスタント。
	 * 
	 * @param errorCode エラーコード
	 */
	public InternalServerErrorException(String errorCode) {
		super(errorCode);
	}
}

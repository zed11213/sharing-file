package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 電子交付ABAリクエストDTO
 */
@Data
public class ElectronicIssueRequestDto{

	/**
	 * 帳票ID
	 */
	private String reportId;

	/**
	 * 文書種別コード
	 */
	private String documentTypeCode;

}

package jp.co.jsbank.mobile.bff.common.code;

/**
 * アプリメッセージスのステータスコード
 */
public class MobilelMsgStatusCode {

    /**
     * 一時保存
     */
    public static final String TEMPORARILY_SAVED = "01";

    /**
     * 公開承認待ち
     */
    public static final String WAITING_FOR_PUBLICATION_APPROVAL = "02";

    /**
     * 公開許可
     */
    public static final String PERMISSION_TO_PUBLISH = "03";

    /**
     * 公開中
     */
    public static final String NOW_OPEN = "04";

    /**
     * 公開許可取消承認待ち
     */
    public static final String WAITING_FOR_APPROVAL_TO_REVOKE_PUBLICATION_PERMISSION = "05";

    /**
     * 公開許可取消承認
     */
    public static final String APPROVAL_FOR_REVOCATION_OF_PUBLICATION_PERMISSION = "06";

    /**
     * 公開許可後編集中
     */
    public static final String EDITING_AFTER_PERMISSION_TO_PUBLISH = "07";

    /**
     * 再公開承認待ち
     */
    public static final String WAITING_FOR_REPUBLICATION_APPROVAL = "08";
}

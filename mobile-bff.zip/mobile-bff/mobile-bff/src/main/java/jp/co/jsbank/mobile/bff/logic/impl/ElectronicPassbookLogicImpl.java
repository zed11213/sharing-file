package jp.co.jsbank.mobile.bff.logic.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.codec.binary.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.jsbank.mobile.bff.config.RestClientConfig;
import jp.co.jsbank.mobile.bff.dto.AccountInfoDto;
import jp.co.jsbank.mobile.bff.dto.aba.AccountInfoAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.AccountInfoAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.BalanceGraphAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.BalanceGraphAbaResponseBody;
import jp.co.jsbank.mobile.bff.dto.aba.BalanceGraphAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.BalanceGraphDto;
import jp.co.jsbank.mobile.bff.dto.aba.CifInfomationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CifInfomationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CifInfomationDto;
import jp.co.jsbank.mobile.bff.dto.aba.CommonHeaderAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.LiquidityDepositDetailsAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.LiquidityDepositDetailsAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.LiquidityDepositDetailsDto;
import jp.co.jsbank.mobile.bff.dto.aba.LotteryResultAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.LotteryResultAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.LotteryResultsDetailsDto;
import jp.co.jsbank.mobile.bff.dto.aba.MemoRegistrationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.NotificationDepositAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.NotificationDepositDetailsAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.NotificationDepositDetailsDto;
import jp.co.jsbank.mobile.bff.dto.aba.PaidOffDto;
import jp.co.jsbank.mobile.bff.dto.aba.PeriodicDepositDetailsAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.PeriodicDepositDetailsAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.PeriodicDepositDetailsDto;
import jp.co.jsbank.mobile.bff.dto.aba.TimeDepositDetailsAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.TimeDepositDetailsAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.TimeDepositDetailsDto;
import jp.co.jsbank.mobile.bff.logic.ElectronicPassbookLogic;

/**
 * 電子通帳ロジック実装クラス
 */
@Service
public class ElectronicPassbookLogicImpl implements ElectronicPassbookLogic {

	@Autowired
	RestClientConfig restClientConfig;

	/**
	 * CIF情報取得APIを呼び出す（API ID：AA0209）
	 *
	 * @param requestDto CIF情報取得リクエストDTO
	 * @return CIF情報
	 */
	@Override
	public CifInfomationAbaResponseDto getGifInfomation(CifInfomationAbaRequestDto requestDto) {

		// Dummyデータ
		List<CifInfomationDto> dtoList = new ArrayList<CifInfomationDto>();
		CifInfomationDto dto1 = new CifInfomationDto();

		// CIF番号
		dto1.setCifNumber("0001");
		// 通帳レス設定状態
		dto1.setPassbookLessSettingStatus("01");
		// 初回登録フラグ
		dto1.setRegisterFlg("0");
		// 店番
		dto1.setBranchCode("001");

		CifInfomationDto dto2 = new CifInfomationDto();

		// CIF番号
		dto2.setCifNumber("0002");
		// 通帳レス設定状態
		dto2.setPassbookLessSettingStatus("02");
		// 初回登録フラグ
		dto2.setRegisterFlg("0");
		// 店番
		dto2.setBranchCode("002");

		CifInfomationDto dto3 = new CifInfomationDto();

		// CIF番号
		dto3.setCifNumber("0003");
		// 通帳レス設定状態
		dto3.setPassbookLessSettingStatus("03");
		// 初回登録フラグ
		dto3.setRegisterFlg("0");
		// 店番
		dto3.setBranchCode("003");

		CifInfomationDto dto4 = new CifInfomationDto();

		// CIF番号
		dto4.setCifNumber("0004");
		// 通帳レス設定状態
		dto4.setPassbookLessSettingStatus("04");
		// 初回登録フラグ
		dto4.setRegisterFlg("0");
		// 店番
		dto4.setBranchCode("004");

		CifInfomationDto dto5 = new CifInfomationDto();

		// CIF番号
		dto5.setCifNumber("0005");
		// 通帳レス設定状態
		dto5.setPassbookLessSettingStatus("05");
		// 初回登録フラグ
		dto5.setRegisterFlg("0");
		// 店番
		dto5.setBranchCode("005");

		CifInfomationDto dto6 = new CifInfomationDto();

		// CIF番号
		dto6.setCifNumber("0006");
		// 通帳レス設定状態
		dto6.setPassbookLessSettingStatus("06");
		// 初回登録フラグ
		dto6.setRegisterFlg("0");
		// 店番
		dto6.setBranchCode("006");

		CifInfomationDto dto7 = new CifInfomationDto();
		// CIF番号
		dto7.setCifNumber("0007");
		// 通帳レス設定状態
		dto7.setPassbookLessSettingStatus("01");
		// 初回登録フラグ
		dto7.setRegisterFlg("0");
		// 店番
		dto7.setBranchCode("001");

		CifInfomationDto dto8 = new CifInfomationDto();

		// CIF番号
		dto8.setCifNumber("0008");
		// 通帳レス設定状態
		dto8.setPassbookLessSettingStatus("02");
		// 初回登録フラグ
		dto8.setRegisterFlg("0");
		// 店番
		dto2.setBranchCode("002");

		CifInfomationDto dto9 = new CifInfomationDto();

		// CIF番号
		dto9.setCifNumber("0009");
		// 通帳レス設定状態
		dto9.setPassbookLessSettingStatus("03");
		// 初回登録フラグ
		dto9.setRegisterFlg("0");
		// 店番
		dto9.setBranchCode("003");

		CifInfomationDto dto10 = new CifInfomationDto();

		// CIF番号
		dto10.setCifNumber("0010");
		// 通帳レス設定状態
		dto10.setPassbookLessSettingStatus("04");
		// 初回登録フラグ
		dto10.setRegisterFlg("0");
		// 店番
		dto10.setBranchCode("004");

		CifInfomationDto dto11 = new CifInfomationDto();

		// CIF番号
		dto11.setCifNumber("0011");
		// 通帳レス設定状態
		dto11.setPassbookLessSettingStatus("05");
		// 初回登録フラグ
		dto11.setRegisterFlg("0");
		// 店番
		dto11.setBranchCode("005");

		CifInfomationDto dto12 = new CifInfomationDto();

		// CIF番号
		dto12.setCifNumber("0012");
		// 通帳レス設定状態
		dto12.setPassbookLessSettingStatus("06");
		// 初回登録フラグ
		dto12.setRegisterFlg("0");
		// 店番
		dto12.setBranchCode("006");

		dtoList.add(dto1);
		dtoList.add(dto2);
		dtoList.add(dto3);
		dtoList.add(dto4);
		dtoList.add(dto5);
		dtoList.add(dto6);
		dtoList.add(dto7);
		dtoList.add(dto8);
		dtoList.add(dto9);
		dtoList.add(dto10);
		dtoList.add(dto11);
		dtoList.add(dto12);

		CifInfomationAbaResponseDto response = new CifInfomationAbaResponseDto();
		response.setCifInfomationDtoList(dtoList);

		return response;
	}

	/**
	 * 残高情報取得APIを呼び出す（API ID：AA0209）
	 *
	 * @param requestDto 残高情報取得リクエストDTO
	 * @return 残高情報
	 */
	@Override
	public AccountInfoAbaResponseDto balanceInformationInquiry(AccountInfoAbaRequestDto requestDto) {

		// Dummyデータ
		AccountInfoDto dto = new AccountInfoDto();
//		AccountInfoDto dto2 = new AccountInfoDto();
//		AccountInfoDto dto3 = new AccountInfoDto();
//		AccountInfoDto dto4 = new AccountInfoDto();
//		AccountInfoDto dto5 = new AccountInfoDto();
//		AccountInfoDto dto6 = new AccountInfoDto();
//		AccountInfoDto dto7 = new AccountInfoDto();
//		AccountInfoDto dto8 = new AccountInfoDto();
//	    AccountInfoDto dto9 = new AccountInfoDto();
//	    AccountInfoDto dto10 = new AccountInfoDto();
//	    AccountInfoDto dto11 = new AccountInfoDto();
//	    AccountInfoDto dto12 = new AccountInfoDto();
		List<AccountInfoDto> dtoList = new ArrayList<AccountInfoDto>();
		if (StringUtils.equals(requestDto.getCifNumber(), "0001")) {

			/**
			 * 科目コード
			 */
			dto.setSubjectNameCode("01");
			/**
			 * 科目名
			 */
			dto.setSubjectNameValue("普通預金");

			/**
			 * 店番
			 */
			dto.setBranchNumber("004");

			/**
			 * 支店名
			 */
			dto.setBranchName("大森支店");

			/**
			 * 口座番号
			 */
			dto.setAccountNumber("100001");

			/**
			 * 残高
			 */
			dto.setBalance("10000");

			/**
			 * 資金化残高
			 */
			dto.setFundedBalance("90000");

			/**
			 * 総合口座フラグ
			 */
			dto.setGeneralAccountFlag("0");

			/**
			 * 総合口座リンク先-預金種目
			 */
			dto.setLinkedAccountType("3");

			/**
			 * 総合口座リンク先-店番
			 */
			dto.setLinkedBranchNumber("003");

			/**
			 * 総合口座リンク先-口座番号
			 */
			dto.setLinkedAccountNumber("136");

			/**
			 * 総合口座リンク先-サブNo
			 */
			dto.setLinkedSubNumber("011");
		
		} else if (StringUtils.equals(requestDto.getCifNumber(), "0002")) {

            /**
            * 科目コード
            */
           dto.setSubjectNameCode("02");

           /**
            * 科目名
            */
           dto.setSubjectNameValue("当座預金");

           /**
            * 店番
            */
           dto.setBranchNumber("004");

           /**
            * 支店名
            */
           dto.setBranchName("大森支店");

           /**
            * 口座番号
            */
           dto.setAccountNumber("100002");

           /**
            * 残高
            */
           dto.setBalance("20000");

           /**
            * 資金化残高
            */
           dto.setFundedBalance("90000");

           /**
            * 総合口座フラグ
            */
           dto.setGeneralAccountFlag("0");

           /**
            * 総合口座リンク先-預金種目
            */
           dto.setLinkedAccountType("3");

           /**
            * 総合口座リンク先-店番
            */
           dto.setLinkedBranchNumber("003");

           /**
            * 総合口座リンク先-口座番号
            */
           dto.setLinkedAccountNumber("136");

           /**
            * 総合口座リンク先-サブNo
            */
           dto.setLinkedSubNumber("011");

		} else if (StringUtils.equals(requestDto.getCifNumber(), "0003")) {

            /**
             * 科目コード
             */
            dto.setSubjectNameCode("03");
            /**
             * 科目名
             */
            dto.setSubjectNameValue("通知預金");

            /**
             * 店番
             */
            dto.setBranchNumber("004");

            /**
             * 支店名
             */
            dto.setBranchName("大森支店");

            /**
             * 口座番号
             */
            dto.setAccountNumber("1000001");

            /**
             * 残高
             */
            dto.setBalance("30000");

            /**
             * 資金化残高
             */
            dto.setFundedBalance("80000");

            /**
             * 総合口座フラグ
             */
            dto.setGeneralAccountFlag("0");

            /**
             * 総合口座リンク先-預金種目
             */
            dto.setLinkedAccountType("3");

            /**
             * 総合口座リンク先-店番
             */
            dto.setLinkedBranchNumber("003");

            /**
             * 総合口座リンク先-口座番号
             */
            dto.setLinkedAccountNumber("136");

            /**
             * 総合口座リンク先-サブNo
             */
            dto.setLinkedSubNumber("011");

		} else if (StringUtils.equals(requestDto.getCifNumber(), "0004")) {

            /**
            * 科目コード
            */
           dto.setSubjectNameCode("07");

           /**
            * 科目名
            */
           dto.setSubjectNameValue("定期積金");

           /**
            * 店番
            */
           dto.setBranchNumber("004");

           /**
            * 支店名
            */
           dto.setBranchName("大森支店");

           /**
            * 口座番号
            */
           dto.setAccountNumber("100003");

           /**
            * 残高
            */
           dto.setBalance("40000");

           /**
            * 資金化残高
            */
           dto.setFundedBalance("90000");

           /**
            * 総合口座フラグ
            */
           dto.setGeneralAccountFlag("0");

           /**
            * 総合口座リンク先-預金種目
            */
           dto.setLinkedAccountType("3");

           /**
            * 総合口座リンク先-店番
            */
           dto.setLinkedBranchNumber("003");

           /**
            * 総合口座リンク先-口座番号
            */
           dto.setLinkedAccountNumber("136");

           /**
            * 総合口座リンク先-サブNo
            */
           dto.setLinkedSubNumber("011");


		} else if (StringUtils.equals(requestDto.getCifNumber(), "0005")) {

            /**
             * 科目コード
             */
            dto.setSubjectNameCode("06");
            /**
             * 科目名
             */
            dto.setSubjectNameValue("定期預金");

            /**
             * 店番
             */
            dto.setBranchNumber("004");

            /**
             * 支店名
             */
            dto.setBranchName("大森支店");

            /**
             * 口座番号
             */
            dto.setAccountNumber("1000002");

            /**
             * 残高
             */
            dto.setBalance("50000");

            /**
             * 資金化残高
             */
            dto.setFundedBalance("90000");

            /**
             * 総合口座フラグ
             */
            dto.setGeneralAccountFlag("0");

            /**
             * 総合口座リンク先-預金種目
             */
            dto.setLinkedAccountType("3");

            /**
             * 総合口座リンク先-店番
             */
            dto.setLinkedBranchNumber("003");

            /**
             * 総合口座リンク先-口座番号
             */
            dto.setLinkedAccountNumber("136");

            /**
             * 総合口座リンク先-サブNo
             */
            dto.setLinkedSubNumber("011");
            

		} else if (StringUtils.equals(requestDto.getCifNumber(), "0006")) {

            /**
            * 科目コード
            */
           dto.setSubjectNameCode("03");

           /**
            * 科目名
            */
           dto.setSubjectNameValue("通知預金");

           /**
            * 店番
            */
           dto.setBranchNumber("004");

           /**
            * 支店名
            */
           dto.setBranchName("大森支店");

           /**
            * 口座番号
            */
           dto.setAccountNumber("1000003");

           /**
            * 残高
            */
           dto.setBalance("60000");

           /**
            * 資金化残高
            */
           dto.setFundedBalance("90000");

           /**
            * 総合口座フラグ
            */
           dto.setGeneralAccountFlag("0");

           /**
            * 総合口座リンク先-預金種目
            */
           dto.setLinkedAccountType("3");

           /**
            * 総合口座リンク先-店番
            */
           dto.setLinkedBranchNumber("003");

           /**
            * 総合口座リンク先-口座番号
            */
           dto.setLinkedAccountNumber("136");

           /**
            * 総合口座リンク先-サブNo
            */
           dto.setLinkedSubNumber("011");

		} else if (StringUtils.equals(requestDto.getCifNumber(), "0007")) {

            /**
             * 科目コード
             */
            dto.setSubjectNameCode("01");
            /**
             * 科目名
             */
            dto.setSubjectNameValue("普通預金");

            /**
             * 店番
             */
            dto.setBranchNumber("010");

            /**
             * 支店名
             */
            dto.setBranchName("矢口支店");

            /**
             * 口座番号
             */
            dto.setAccountNumber("100004");

            /**
             * 残高
             */
            dto.setBalance("100");

            /**
             * 資金化残高
             */
            dto.setFundedBalance("90000");

            /**
             * 総合口座フラグ
             */
            dto.setGeneralAccountFlag("0");

            /**
             * 総合口座リンク先-預金種目
             */
            dto.setLinkedAccountType("3");

            /**
             * 総合口座リンク先-店番
             */
            dto.setLinkedBranchNumber("003");

            /**
             * 総合口座リンク先-口座番号
             */
            dto.setLinkedAccountNumber("136");

            /**
             * 総合口座リンク先-サブNo
             */
            dto.setLinkedSubNumber("011");

		} else if (StringUtils.equals(requestDto.getCifNumber(), "0008")) {

            /**
            * 科目コード
            */
           dto.setSubjectNameCode("02");

           /**
            * 科目名
            */
           dto.setSubjectNameValue("当座預金");

           /**
            * 店番
            */
           dto.setBranchNumber("010");

           /**
            * 支店名
            */
           dto.setBranchName("矢口支店");

           /**
            * 口座番号
            */
           dto.setAccountNumber("100005");

           /**
            * 残高
            */
           dto.setBalance("200");

           /**
            * 資金化残高
            */
           dto.setFundedBalance("90000");

           /**
            * 総合口座フラグ
            */
           dto.setGeneralAccountFlag("0");

           /**
            * 総合口座リンク先-預金種目
            */
           dto.setLinkedAccountType("3");

           /**
            * 総合口座リンク先-店番
            */
           dto.setLinkedBranchNumber("003");

           /**
            * 総合口座リンク先-口座番号
            */
           dto.setLinkedAccountNumber("136");

           /**
            * 総合口座リンク先-サブNo
            */
           dto.setLinkedSubNumber("011");


		} else if (StringUtils.equals(requestDto.getCifNumber(), "0009")) {

            /**
             * 科目コード
             */
            dto.setSubjectNameCode("03");
            /**
             * 科目名
             */
            dto.setSubjectNameValue("通知預金");

            /**
             * 店番
             */
            dto.setBranchNumber("010");

            /**
             * 支店名
             */
            dto.setBranchName("矢口支店");

            /**
             * 口座番号
             */
            dto.setAccountNumber("1000004");

            /**
             * 残高
             */
            dto.setBalance("300");

            /**
             * 資金化残高
             */
            dto.setFundedBalance("90000");

            /**
             * 総合口座フラグ
             */
            dto.setGeneralAccountFlag("0");

            /**
             * 総合口座リンク先-預金種目
             */
            dto.setLinkedAccountType("3");

            /**
             * 総合口座リンク先-店番
             */
            dto.setLinkedBranchNumber("003");

            /**
             * 総合口座リンク先-口座番号
             */
            dto.setLinkedAccountNumber("136");

            /**
             * 総合口座リンク先-サブNo
             */
            dto.setLinkedSubNumber("011");
            


		} else if (StringUtils.equals(requestDto.getCifNumber(), "0010")) {

            /**
            * 科目コード
            */
           dto.setSubjectNameCode("07");

           /**
            * 科目名
            */
           dto.setSubjectNameValue("定期積金");

           /**
            * 店番
            */
           dto.setBranchNumber("010");

           /**
            * 支店名
            */
           dto.setBranchName("矢口支店");

           /**
            * 口座番号
            */
           dto.setAccountNumber("100006");

           /**
            * 残高
            */
           dto.setBalance("400");

           /**
            * 資金化残高
            */
           dto.setFundedBalance("90000");

           /**
            * 総合口座フラグ
            */
           dto.setGeneralAccountFlag("0");

           /**
            * 総合口座リンク先-預金種目
            */
           dto.setLinkedAccountType("3");

           /**
            * 総合口座リンク先-店番
            */
           dto.setLinkedBranchNumber("003");

           /**
            * 総合口座リンク先-口座番号
            */
           dto.setLinkedAccountNumber("136");

           /**
            * 総合口座リンク先-サブNo
            */
           dto.setLinkedSubNumber("011");


		} else if (StringUtils.equals(requestDto.getCifNumber(), "0011")) {
            /**
             * 科目コード
             */
            dto.setSubjectNameCode("06");
            /**
             * 科目名
             */
            dto.setSubjectNameValue("定期預金");

            /**
             * 店番
             */
            dto.setBranchNumber("010");

            /**
             * 支店名
             */
            dto.setBranchName("矢口支店");

            /**
             * 口座番号
             */
            dto.setAccountNumber("1000005");
            
            /**
             * 残高
             */
            dto.setBalance("500");

            /**
             * 資金化残高
             */
            dto.setFundedBalance("90000");

            /**
             * 総合口座フラグ
             */
            dto.setGeneralAccountFlag("0");

            /**
             * 総合口座リンク先-預金種目
             */
            dto.setLinkedAccountType("3");

            /**
             * 総合口座リンク先-店番
             */
            dto.setLinkedBranchNumber("003");

            /**
             * 総合口座リンク先-口座番号
             */
            dto.setLinkedAccountNumber("136");

            /**
             * 総合口座リンク先-サブNo
             */
            dto.setLinkedSubNumber("011");
            
		} else if (StringUtils.equals(requestDto.getCifNumber(), "0012")) {

            /**
            * 科目コード
            */
           dto.setSubjectNameCode("03");

           /**
            * 科目名
            */
           dto.setSubjectNameValue("通知預金");

           /**
            * 店番
            */
           dto.setBranchNumber("010");

           /**
            * 支店名
            */
           dto.setBranchName("矢口支店");

           /**
            * 口座番号
            */
           dto.setAccountNumber("1000006");

           /**
            * 残高
            */
           dto.setBalance("600");

           /**
            * 資金化残高
            */
           dto.setFundedBalance("90000");

           /**
            * 総合口座フラグ
            */
           dto.setGeneralAccountFlag("0");

           /**
            * 総合口座リンク先-預金種目
            */
           dto.setLinkedAccountType("3");

           /**
            * 総合口座リンク先-店番
            */
           dto.setLinkedBranchNumber("003");

           /**
            * 総合口座リンク先-口座番号
            */
           dto.setLinkedAccountNumber("136");

           /**
            * 総合口座リンク先-サブNo
            */
           dto.setLinkedSubNumber("011");
		}

		AccountInfoAbaResponseDto response = new AccountInfoAbaResponseDto();
		dtoList.add(dto);
		response.setBalanceList(dtoList);
		return response;
	}

	/**
	 * 入出金明細取得(流動性預金)
	 *
	 * @param requestDto 入出金明細(流動性預金)リクエストDTO
	 * @return 入出金明細情報
	 */
	@Override
	public LiquidityDepositDetailsAbaResponseDto getIiquidityDepositDetails(
			LiquidityDepositDetailsAbaRequestDto requestDto) {

		// Dummyデータ
		LiquidityDepositDetailsDto dto1 = new LiquidityDepositDetailsDto();

		/**
		 * 明細ID
		 */
		dto1.setDetailId("20220211100");

		/**
		 * 取引店番
		 */
		dto1.setBranchNumber("001");

		/**
		 * 取引記号1
		 */
		dto1.setHandling1("1");

		/**
		 * 取引記号2
		 */
		dto1.setHandling2("2");

		/**
		 * 取引記号3
		 */
		dto1.setHandling3("3");

		/**
		 * 取引記号4
		 */
		dto1.setHandling4("4");

		/**
		 * 切手手形種類番号
		 */
		dto1.setBillNumber("13346");

		/**
		 * 取引日
		 */
		dto1.setTransactionDate("2022-03-14");

		/**
		 * 起算日
		 */
		dto1.setStartingDate("2022-03-15");

		/**
		 * 概要
		 */
		dto1.setDescriptionKanji("概要ﾃｽﾄ");

		/**
		 * 摘要文言カナ
		 */
		dto1.setDescriptionKana("ﾊﾝｶｸｶﾅ");

		/**
		 * 入金額
		 */
		dto1.setDepositAmount("10000");

		/**
		 * 支払額
		 */
		dto1.setWithdrawalAmount("888");

		/**
		 * 取引後残高
		 */
		dto1.setBalance("120000");

		/**
		 * 明細概要メモ
		 */
		dto1.setMemo("レゼントを買う");

		// Dummyデータ
		LiquidityDepositDetailsDto dto2 = new LiquidityDepositDetailsDto();

		/**
		 * 明細ID
		 */
		dto2.setDetailId("20220211100");

		/**
		 * 取引店番
		 */
		dto2.setBranchNumber("001");

		/**
		 * 取引記号1
		 */
		dto2.setHandling1("1");

		/**
		 * 取引記号2
		 */
		dto2.setHandling2("2");

		/**
		 * 取引記号3
		 */
		dto2.setHandling3("3");

		/**
		 * 取引記号4
		 */
		dto2.setHandling4("4");

		/**
		 * 切手手形種類番号
		 */
		dto2.setBillNumber("13346");

		/**
		 * 取引日
		 */
		dto2.setTransactionDate("2022-03-14");

		/**
		 * 起算日
		 */
		dto2.setStartingDate("2022-03-15");

		/**
		 * 概要
		 */
		dto2.setDescriptionKanji("概要ﾃｽﾄ");

		/**
		 * 摘要文言カナ
		 */
		dto2.setDescriptionKana("ﾊﾝｶｸｶﾅ");

		/**
		 * 入金額
		 */
		dto2.setDepositAmount("100000");

		/**
		 * 支払額
		 */
		dto2.setWithdrawalAmount("888");

		/**
		 * 取引後残高
		 */
		dto2.setBalance("120000");

		/**
		 * 明細概要メモ
		 */
		dto2.setMemo("レゼントを買う");

		List<LiquidityDepositDetailsDto> list = new ArrayList<>();
		list.add(dto1);
		list.add(dto2);

		LiquidityDepositDetailsAbaResponseDto response = new LiquidityDepositDetailsAbaResponseDto();
		response.setDetailContinuationFlag(true);
		response.setContinuationDetailId("20220101101");
		response.setTransactionsList(list);

		return response;
	}

	/**
	 * 定期預金明細取得
	 *
	 * @param requestDto 定期預金明細リクエストDTO
	 * @return 定期預金明細情報
	 */
	@Override
	public TimeDepositDetailsAbaResponseDto getTimeDepositDetails(TimeDepositDetailsAbaRequestDto requestDto) {

		// Dummyデータ
		TimeDepositDetailsAbaResponseDto response = new TimeDepositDetailsAbaResponseDto();
		TimeDepositDetailsDto timeDepositDetailsDto = new TimeDepositDetailsDto();

		/**
		 * 明細ID
		 */
		timeDepositDetailsDto.setDetailId("1000001");

		/**
		 * サブNO
		 */
		timeDepositDetailsDto.setSubNumber("10");

		/**
		 * 種類（コード）
		 */
		timeDepositDetailsDto.setTypeCode("普通");

		/**
		 * 元帳残高
		 */
		timeDepositDetailsDto.setBalanceOfLedger("20000");

		/**
		 * 利率
		 */
		timeDepositDetailsDto.setInterestRate("0.012");

		/**
		 * 課税区分（文言）
		 */
		timeDepositDetailsDto.setTaxClassName("1");

		/**
		 * 満期日
		 */
		timeDepositDetailsDto.setMaturityDate("2022-03-14");

		/**
		 * 期間（文言）
		 */
		timeDepositDetailsDto.setPeriodCodeValue("一年");

		/**
		 * 利息受取方法
		 */
		timeDepositDetailsDto.setInterestReceivingMethod("1");

		/**
		 * 懸賞金区分（文言）
		 */
		timeDepositDetailsDto.setRewardAmountTypeValue("支払");

		/**
		 * 利息受取科目
		 */
		timeDepositDetailsDto.setInterestReceiveAccountType("1");

		/**
		 * 利息受取口座番号
		 */
		timeDepositDetailsDto.setIrAccountNumber("13657");

		/**
		 * 契約日
		 */
		timeDepositDetailsDto.setContractDate("2022-03-14");

		/**
		 * お取引区分
		 */
		timeDepositDetailsDto.setTransactionClassification("2");

		/**
		 * 明細概要メモ
		 */
		timeDepositDetailsDto.setMemo("メモ");

		/**
		 * 抽選回数
		 */
		timeDepositDetailsDto.setLotteryTimes("88888");

		/**
		 * 取扱組
		 */
		timeDepositDetailsDto.setHandlingGroup("10001");

		/**
		 * 開始抽選番号
		 */
		timeDepositDetailsDto.setLotteryNoStart("20001");

		/**
		 * 終了抽選番号
		 */
		timeDepositDetailsDto.setLotteryNoEnd("20003");

		/**
		 * 抽選日
		 */
		timeDepositDetailsDto.setLotteryDate("2022-03-14");

		/**
		 * 店番
		 */
		timeDepositDetailsDto.setBranchNumber("100");

		/**
		 * 当初金額
		 */
		timeDepositDetailsDto.setStartAmoun("2000000");

		/**
		 * スーパードリーム等スーパー定期種類
		 */
		timeDepositDetailsDto.setSuperRegularType("スーパードリーム（自動継続型）");

		response.setTimeDepositDetailsDtoList(Arrays.asList(timeDepositDetailsDto));

		return response;
	}

	/**
	 * 定期積金明細取得
	 *
	 * @param requestDto 定期積金明細リクエストDTO
	 * @return 定期積金明細情報
	 */
	@Override
	public PeriodicDepositDetailsAbaResponseDto getPeriodicDepositDetails(
			PeriodicDepositDetailsAbaRequestDto requestDto) {

		// Dummyデータ
		PeriodicDepositDetailsDto dto = new PeriodicDepositDetailsDto();

		/**
		 * 元金
		 */
		dto.setFundedBalance("15000");

		/**
		 * 満期日
		 */
		dto.setMaturityDate("2022-03-13");

		/**
		 * 期間
		 */
		dto.setPeriod("123");

		/**
		 * 夢付き
		 */
		dto.setDreamFlag("1");

		/**
		 * 元帳残高
		 */
		dto.setBalanceOfLedger("40000");

		/**
		 * 契約額
		 */
		dto.setAgreementAmount("10000");

		/**
		 * 給付補填金
		 */
		dto.setPayupAmount("30000");

		/**
		 * 振替日・集金日
		 */
		dto.setTransferDate("2022-03-16");

		/**
		 * 掛金額
		 */
		dto.setPremium("25000");

		/**
		 * 契約日
		 */
		dto.setContractDate("2022-03-16");

		/**
		 * 利率
		 */
		dto.setInterest("11.001");

		/**
		 * 課税区分（文言）
		 */
		dto.setTaxClassName("総合課税");

		PaidOffDto paidOffDto01 = new PaidOffDto();
		paidOffDto01.setTermDepositDate("2021-02-01");
		paidOffDto01.setNumberOfTimes("02");

		PaidOffDto paidOffDto02 = new PaidOffDto();
		paidOffDto02.setTermDepositDate("2021-02-02");
		paidOffDto02.setNumberOfTimes("02");

		PaidOffDto paidOffDto03 = new PaidOffDto();
		paidOffDto03.setTermDepositDate("2021-02-03");
		paidOffDto03.setNumberOfTimes("03");

		PaidOffDto paidOffDto04 = new PaidOffDto();
		paidOffDto04.setTermDepositDate("2021-02-04");
		paidOffDto04.setNumberOfTimes("04");

		PaidOffDto paidOffDto05 = new PaidOffDto();
		paidOffDto05.setTermDepositDate("2021-02-05");
		paidOffDto05.setNumberOfTimes("05");

		PaidOffDto paidOffDto06 = new PaidOffDto();
		paidOffDto06.setTermDepositDate("2021-02-06");
		paidOffDto06.setNumberOfTimes("12");

		PaidOffDto paidOffDto07 = new PaidOffDto();
		paidOffDto07.setTermDepositDate("2021-02-07");
		paidOffDto07.setNumberOfTimes("07");

		PaidOffDto paidOffDto08 = new PaidOffDto();
		paidOffDto08.setTermDepositDate("2021-02-08");
		paidOffDto08.setNumberOfTimes("08");

		PaidOffDto paidOffDto09 = new PaidOffDto();
		paidOffDto09.setTermDepositDate("2021-02-09");
		paidOffDto09.setNumberOfTimes("09");

		PaidOffDto paidOffDto10 = new PaidOffDto();
		paidOffDto10.setTermDepositDate("2021-02-10");
		paidOffDto10.setNumberOfTimes("10");

		PaidOffDto paidOffDto11 = new PaidOffDto();
		paidOffDto11.setTermDepositDate("2021-02-11");
		paidOffDto11.setNumberOfTimes("11");

		PaidOffDto paidOffDto12 = new PaidOffDto();
		paidOffDto12.setTermDepositDate("2021-02-12");
		paidOffDto12.setNumberOfTimes("12");

		PaidOffDto paidOffDto13 = new PaidOffDto();
		paidOffDto13.setTermDepositDate("2021-02-13");
		paidOffDto13.setNumberOfTimes("12");

		List<PaidOffDto> paidOffDtoList = new ArrayList<PaidOffDto>();
		paidOffDtoList.add(paidOffDto01);
		paidOffDtoList.add(paidOffDto02);
		paidOffDtoList.add(paidOffDto03);
		paidOffDtoList.add(paidOffDto04);
		paidOffDtoList.add(paidOffDto05);
		paidOffDtoList.add(paidOffDto06);
		paidOffDtoList.add(paidOffDto07);
		paidOffDtoList.add(paidOffDto08);
		paidOffDtoList.add(paidOffDto09);
		paidOffDtoList.add(paidOffDto10);
		paidOffDtoList.add(paidOffDto11);
		paidOffDtoList.add(paidOffDto12);
		paidOffDtoList.add(paidOffDto13);

		PeriodicDepositDetailsAbaResponseDto response = new PeriodicDepositDetailsAbaResponseDto();
		response.setPeriodicDepositDetailsDto(dto);
		response.setPaidOffList(paidOffDtoList);

		return response;
	}

	/**
	 * 通知預金明細取得
	 *
	 * @param requestDto 通知預金明細リクエストDTOlotteryResultsDetailsDtoList
	 * @return 通知預金明細情報
	 */
	@Override
	public NotificationDepositAbaResponseDto getNotificationDepositDetails(
			NotificationDepositDetailsAbaRequestDto requestDto) {

		// Dummyデータ
		NotificationDepositDetailsDto dto = new NotificationDepositDetailsDto();
		List<NotificationDepositDetailsDto> dtoList = new ArrayList<NotificationDepositDetailsDto>();
		
		/**
		 * サブNO
		 */
		dto.setSubNumber("10");
		
		/**
		 * 明細ID
		 */
		dto.setDetailId("00000001");

		/**
		 * お預かり金額
		 */
		dto.setFundedBalance("10000");

		/**
		 * 当初契約日
		 */
		dto.setInitialContractDate("2022-03-14");

		/**
		 * 契約日
		 */
		dto.setContractDate("2020-03-15");

		/**
		 * 利率
		 */
		dto.setInterestRate("20");

		/**
		 * 課税区分
		 */
		dto.setTaxClassName("03");

		dtoList.add(dto);
		NotificationDepositAbaResponseDto response = new NotificationDepositAbaResponseDto();
		response.setNoticeDepositList(dtoList);
		response.setAccountNumber("12345678");
		response.setBranchNumber("001");
		return response;
	}

	/**
	 * 概要欄メモ登録
	 *
	 * @param requestDto 概要欄メモ登録ABAリクエストDTO
	 * @return 処理結果
	 */
	@Override
	public CommonHeaderAbaResponseDto overviewFieldMemoRegistration(MemoRegistrationAbaRequestDto requestDto) {

		// // リクエストパラメータ
		// ParameterBuilder parameterDto = ParameterBuilder.build(requestDto);
		//
		// // TODO 概要欄メモ登録APIを呼び出す
		// RestTemplate restTemplate = restClientConfig.simpleRestTemplate();
		// MemoRegistrationAbaResponseDto response =
		// restTemplate.getForObject("/digitalpassbook/v1.3.0/memo/registration",
		// MemoRegistrationAbaResponseDto.class, parameterDto);

		return new CommonHeaderAbaResponseDto();
	}

	/**
	 * 収支グラフ情報取得
	 *
	 * @param requestDto 収支グラフ情報ABAリクエストDTO
	 * @return 収支情報
	 */
	@Override
	public BalanceGraphAbaResponseDto getBalanceGraphInfomation(BalanceGraphAbaRequestDto requestDto) {

		// Dummyデータ
		BalanceGraphDto dto = new BalanceGraphDto();

		/**
		 * 収支年月
		 */
		dto.setBalanceMonth("2022-03");

		/**
		 * 入金額
		 */
		dto.setDepositAmount("10000");

		/**
		 * 出金額
		 */
		dto.setInvestedAmount("56000");

		/**
		 * 月残高
		 */
		dto.setMonthlyBalance("86000");
		BalanceGraphAbaResponseBody responseBody = new BalanceGraphAbaResponseBody();
		responseBody.setBalanceInfoList(Arrays.asList(dto));

		BalanceGraphAbaResponseDto response = new BalanceGraphAbaResponseDto();
		response.setBalanceGraphAbaResponseBody(responseBody);

		return response;
	}

	/**
	 * 抽選結果取得
	 *
	 * @param requestDto 抽選結果情報ABAリクエストDTO
	 * @return 抽選結果
	 */
	@Override
	public LotteryResultAbaResponseDto getLotteryResultInfomation(LotteryResultAbaRequestDto requestDto) {
		// Dummyデータ
		LotteryResultAbaResponseDto response = new LotteryResultAbaResponseDto();
		List<LotteryResultsDetailsDto> LotteryResultsDetailsDtoList = new ArrayList<LotteryResultsDetailsDto>();

		LotteryResultsDetailsDto lotteryResultsDetailsDto1 = new LotteryResultsDetailsDto();

		/**
		 * 回次
		 */
		lotteryResultsDetailsDto1.setLotteryTimes("01");

		/**
		 * 抽選区分
		 */
		lotteryResultsDetailsDto1.setLotteryType("0");

		/**
		 * 取扱組
		 */
		lotteryResultsDetailsDto1.setLotterySet("12345");

		/**
		 * 等級
		 */
		lotteryResultsDetailsDto1.setLotteryRank("WRFD01");

		/**
		 * 当選番号
		 */
		lotteryResultsDetailsDto1.setLotteryNumber("45678");

		/**
		 * 当選本数
		 */
		lotteryResultsDetailsDto1.setLotteryCount("102");

		/**
		 * 当選金額
		 */
		lotteryResultsDetailsDto1.setLotteryAmount("100");

		/**
		 * 抽選結果受領済みフラグ
		 */
		lotteryResultsDetailsDto1.setLotteryResultReceivedFlag("1");

		LotteryResultsDetailsDto lotteryResultsDetailsDto2 = new LotteryResultsDetailsDto();

		/**
		 * 回次
		 */
		lotteryResultsDetailsDto2.setLotteryTimes("01");

		/**
		 * 抽選区分
		 */
		lotteryResultsDetailsDto2.setLotteryType("0");

		/**
		 * 取扱組
		 */
		lotteryResultsDetailsDto2.setLotterySet("12345");

		/**
		 * 等級
		 */
		lotteryResultsDetailsDto2.setLotteryRank("WRFD02");

		/**
		 * 当選番号
		 */
		lotteryResultsDetailsDto2.setLotteryNumber("45678");

		/**
		 * 当選本数
		 */
		lotteryResultsDetailsDto2.setLotteryCount("102");

		/**
		 * 当選金額
		 */
		lotteryResultsDetailsDto2.setLotteryAmount("200");

		/**
		 * 抽選結果受領済みフラグ
		 */
		lotteryResultsDetailsDto2.setLotteryResultReceivedFlag("1");

		LotteryResultsDetailsDto lotteryResultsDetailsDto3 = new LotteryResultsDetailsDto();

		/**
		 * 回次
		 */
		lotteryResultsDetailsDto3.setLotteryTimes("01");

		/**
		 * 抽選区分
		 */
		lotteryResultsDetailsDto3.setLotteryType("0");

		/**
		 * 取扱組
		 */
		lotteryResultsDetailsDto3.setLotterySet("12345");

		/**
		 * 等級
		 */
		lotteryResultsDetailsDto3.setLotteryRank("WRFD03");

		/**
		 * 当選番号
		 */
		lotteryResultsDetailsDto3.setLotteryNumber("45678");

		/**
		 * 当選本数
		 */
		lotteryResultsDetailsDto3.setLotteryCount("102");

		/**
		 * 当選金額
		 */
		lotteryResultsDetailsDto3.setLotteryAmount("300");

		/**
		 * 抽選結果受領済みフラグ
		 */
		lotteryResultsDetailsDto3.setLotteryResultReceivedFlag("1");

		LotteryResultsDetailsDto lotteryResultsDetailsDto4 = new LotteryResultsDetailsDto();

		/**
		 * 回次
		 */
		lotteryResultsDetailsDto4.setLotteryTimes("01");

		/**
		 * 抽選区分
		 */
		lotteryResultsDetailsDto4.setLotteryType("0");

		/**
		 * 取扱組
		 */
		lotteryResultsDetailsDto4.setLotterySet("12345");

		/**
		 * 等級
		 */
		lotteryResultsDetailsDto4.setLotteryRank("WRFD04");

		/**
		 * 当選番号
		 */
		lotteryResultsDetailsDto4.setLotteryNumber("45678");

		/**
		 * 当選本数
		 */
		lotteryResultsDetailsDto4.setLotteryCount("102");

		/**
		 * 当選金額
		 */
		lotteryResultsDetailsDto4.setLotteryAmount("400");

		/**
		 * 抽選結果受領済みフラグ
		 */
		lotteryResultsDetailsDto4.setLotteryResultReceivedFlag("1");
		LotteryResultsDetailsDto lotteryResultsDetailsDto5 = new LotteryResultsDetailsDto();

		/**
		 * 回次
		 */
		lotteryResultsDetailsDto5.setLotteryTimes("01");

		/**
		 * 抽選区分
		 */
		lotteryResultsDetailsDto5.setLotteryType("0");

		/**
		 * 取扱組
		 */
		lotteryResultsDetailsDto5.setLotterySet("12345");

		/**
		 * 等級
		 */
		lotteryResultsDetailsDto5.setLotteryRank("WRFD05");

		/**
		 * 当選番号
		 */
		lotteryResultsDetailsDto5.setLotteryNumber("45678");

		/**
		 * 当選本数
		 */
		lotteryResultsDetailsDto5.setLotteryCount("102");

		/**
		 * 当選金額
		 */
		lotteryResultsDetailsDto5.setLotteryAmount("500");

		/**
		 * 抽選結果受領済みフラグ
		 */
		lotteryResultsDetailsDto5.setLotteryResultReceivedFlag("1");

		LotteryResultsDetailsDto lotteryResultsDetailsDto6 = new LotteryResultsDetailsDto();

		/**
		 * 回次
		 */
		lotteryResultsDetailsDto6.setLotteryTimes("01");

		/**
		 * 抽選区分
		 */
		lotteryResultsDetailsDto6.setLotteryType("0");

		/**
		 * 取扱組
		 */
		lotteryResultsDetailsDto6.setLotterySet("12345");

		/**
		 * 等級
		 */
		lotteryResultsDetailsDto6.setLotteryRank("WRFD07");

		/**
		 * 当選番号
		 */
		lotteryResultsDetailsDto6.setLotteryNumber("45678");

		/**
		 * 当選本数
		 */
		lotteryResultsDetailsDto6.setLotteryCount("102");

		/**
		 * 当選金額
		 */
		lotteryResultsDetailsDto6.setLotteryAmount("600");

		/**
		 * 抽選結果受領済みフラグ
		 */
		lotteryResultsDetailsDto6.setLotteryResultReceivedFlag("1");

		LotteryResultsDetailsDto lotteryResultsDetailsDto7 = new LotteryResultsDetailsDto();

		/**
		 * 回次
		 */
		lotteryResultsDetailsDto7.setLotteryTimes("01");

		/**
		 * 抽選区分
		 */
		lotteryResultsDetailsDto7.setLotteryType("1");

		/**
		 * 取扱組
		 */
		lotteryResultsDetailsDto7.setLotterySet("12345");

		/**
		 * 等級
		 */
		lotteryResultsDetailsDto7.setLotteryRank("WRFD06");

		/**
		 * 当選番号
		 */
		lotteryResultsDetailsDto7.setLotteryNumber("45678");

		/**
		 * 当選本数
		 */
		lotteryResultsDetailsDto7.setLotteryCount("102");

		/**
		 * 当選金額
		 */
		lotteryResultsDetailsDto7.setLotteryAmount("700");

		/**
		 * 抽選結果受領済みフラグ
		 */
		lotteryResultsDetailsDto7.setLotteryResultReceivedFlag("1");

		LotteryResultsDetailsDto lotteryResultsDetailsDto8 = new LotteryResultsDetailsDto();

		/**
		 * 回次
		 */
		lotteryResultsDetailsDto8.setLotteryTimes("01");

		/**
		 * 抽選区分
		 */
		lotteryResultsDetailsDto8.setLotteryType("1");

		/**
		 * 取扱組
		 */
		lotteryResultsDetailsDto8.setLotterySet("12345");

		/**
		 * 等級
		 */
		lotteryResultsDetailsDto8.setLotteryRank("WRFD06");

		/**
		 * 当選番号
		 */
		lotteryResultsDetailsDto8.setLotteryNumber("45678");

		/**
		 * 当選本数
		 */
		lotteryResultsDetailsDto8.setLotteryCount("102");

		/**
		 * 当選金額
		 */
		lotteryResultsDetailsDto8.setLotteryAmount("800");

		/**
		 * 抽選結果受領済みフラグ
		 */
		lotteryResultsDetailsDto8.setLotteryResultReceivedFlag("1");

		LotteryResultsDetailsDto lotteryResultsDetailsDto9 = new LotteryResultsDetailsDto();

		/**
		 * 回次
		 */
		lotteryResultsDetailsDto9.setLotteryTimes("01");

		/**
		 * 抽選区分
		 */
		lotteryResultsDetailsDto9.setLotteryType("1");

		/**
		 * 取扱組
		 */
		lotteryResultsDetailsDto9.setLotterySet("12345");

		/**
		 * 等級
		 */
		lotteryResultsDetailsDto9.setLotteryRank("WRFD06");

		/**
		 * 当選番号
		 */
		lotteryResultsDetailsDto9.setLotteryNumber("45678");

		/**
		 * 当選本数
		 */
		lotteryResultsDetailsDto9.setLotteryCount("102");

		/**
		 * 当選金額
		 */
		lotteryResultsDetailsDto9.setLotteryAmount("900");

		/**
		 * 抽選結果受領済みフラグ
		 */
		lotteryResultsDetailsDto9.setLotteryResultReceivedFlag("1");

		LotteryResultsDetailsDto lotteryResultsDetailsDto10 = new LotteryResultsDetailsDto();

		/**
		 * 回次
		 */
		lotteryResultsDetailsDto10.setLotteryTimes("01");

		/**
		 * 抽選区分
		 */
		lotteryResultsDetailsDto10.setLotteryType("1");

		/**
		 * 取扱組
		 */
		lotteryResultsDetailsDto10.setLotterySet("12345");

		/**
		 * 等級
		 */
		lotteryResultsDetailsDto10.setLotteryRank("WRFD07");

		/**
		 * 当選番号
		 */
		lotteryResultsDetailsDto10.setLotteryNumber("45678");

		/**
		 * 当選本数
		 */
		lotteryResultsDetailsDto10.setLotteryCount("102");

		/**
		 * 当選金額
		 */
		lotteryResultsDetailsDto10.setLotteryAmount("1000");

		/**
		 * 抽選結果受領済みフラグ
		 */
		lotteryResultsDetailsDto10.setLotteryResultReceivedFlag("1");

		LotteryResultsDetailsDtoList.add(lotteryResultsDetailsDto1);
		LotteryResultsDetailsDtoList.add(lotteryResultsDetailsDto2);
		LotteryResultsDetailsDtoList.add(lotteryResultsDetailsDto3);
		LotteryResultsDetailsDtoList.add(lotteryResultsDetailsDto4);
		LotteryResultsDetailsDtoList.add(lotteryResultsDetailsDto5);
		LotteryResultsDetailsDtoList.add(lotteryResultsDetailsDto6);
		LotteryResultsDetailsDtoList.add(lotteryResultsDetailsDto7);
		LotteryResultsDetailsDtoList.add(lotteryResultsDetailsDto8);
		LotteryResultsDetailsDtoList.add(lotteryResultsDetailsDto9);
		LotteryResultsDetailsDtoList.add(lotteryResultsDetailsDto10);
		response.setLotteryResultsDetailsDtoList(LotteryResultsDetailsDtoList);
		return response;
	}
}

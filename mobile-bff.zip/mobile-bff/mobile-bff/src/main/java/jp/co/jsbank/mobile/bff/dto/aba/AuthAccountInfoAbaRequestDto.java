package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 口座情報認証ABAリクエストDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class AuthAccountInfoAbaRequestDto extends RequestBodyDto {

    /**
     * 店番
     */
    private String branchNumber;

    /**
     * 口座番号
     */
    private String accountNumber;

    /**
     * カナ氏名（名）
     */
    private String customerFirstName;
    
    /**
     * カナ氏名（姓）
     */
    private String customerLastName;

    /**
     * 生年月日
     */
    private String birthDay;

    /**
     * 郵便番号
     */
    private String zipCode;

    /**
     * CC暗証番号
     */
    private String ccPinCode;
    
    /**
     * 取引種別
     */
    private String transactionType;
}

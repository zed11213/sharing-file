package jp.co.jsbank.mobile.bff.common.code;

/**
 * 認証コード
 */
public class AuthenticationResultCode {

    /**
     * 認証成功
     */
    public static final String AUTHENTICATION_SUCCESS = "1";

    /**
     * 認証失敗
     */
    public static final String AUTHENTICATION_FAILED = "2";
}

package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * スーパードリームお利息計算明細表DTO
 */
@Data
public class SuperDreamInterestRateDto {

    /**
     * 預金番号
     */
    private String depositNumber;

    /**
     * 種類
     */
    private String type;

    /**
     * お預り金額
     */
    private String depositAmount;

    /**
     * 利率
     */
    private String interestRate;

    /**
     * 税区分
     */
    private String taxType;

    /**
     * 期日
     */
    private String expiryDate;

    /**
     * 計算期間
     */
    private String countDuration;

    /**
     * お利息
     */
    private String interestAmount;

    /**
     * お利息_国税
     */
    private String interestNationalTax;

    /**
     * お利息_地方税
     */
    private String interestLocalTax;

    /**
     * 差引お利息
     */
    private String deductedInterestAmount;

    /**
     * 抽せん番号_回
     */
    private String lotteryNoRound;

    /**
     * 抽せん番号_組
     */
    private String lotteryNoGroup;

    /**
     * 抽せん番号_開始
     */
    private String lotteryNoStart;

    /**
     * 抽せん番号_終了
     */
    private String lotteryNoEnd;

    /**
     * 懸賞金
     */
    private String rewardAmount;

    /**
     * 懸賞金_国税
     */
    private String rewardNationalTax;

    /**
     * 懸賞金_地方税
     */
    private String rewardLocalTax;

    /**
     * 差引懸賞金
     */
    private String deductedRewardAmount;

    /**
     * 新元金
     */
    private String newPrincipalAmount;

    /**
     * 新利率
     */
    private String newInterestRate;

    /**
     * 新抽せん番号_回
     */
    private String newLotteryNoRound;

    /**
     * 新抽せん番号_組
     */
    private String newLotteryNoGroup;

    /**
     * 新抽せん番号_開始
     */
    private String newLotteryNoStart;

    /**
     * 新抽せん番号_終了
     */
    private String newLotteryNoEnd;

    /**
     * 新抽せん日
     */
    private String newLotteryDate;
}

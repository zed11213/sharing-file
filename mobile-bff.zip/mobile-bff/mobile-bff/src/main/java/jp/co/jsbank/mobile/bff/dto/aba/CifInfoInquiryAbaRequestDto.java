package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * CIF情報照会ABAリクエストDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class CifInfoInquiryAbaRequestDto extends RequestBodyDto {

    /**
     * 顧客ID
     */
    private String customerId;

}

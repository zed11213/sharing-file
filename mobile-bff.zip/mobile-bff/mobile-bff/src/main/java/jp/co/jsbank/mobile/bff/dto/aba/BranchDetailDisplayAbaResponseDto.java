package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * 支店詳細照会レスボスDTO
 */
@Data
public class BranchDetailDisplayAbaResponseDto {

    /**
     * 店名（漢字）
     */
    private String branchKanjiName;
}

package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 認証キー検証ABAリクエストDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class AuthenticationKeyVerificationAbaRequestDto extends RequestBodyDto {

    /**
     * 所属
     */
    private String divisionCode;

    /**
     * 利用者認証キー
     */
    private String userAuthCode;

    /**
     * デバイスID
     */
    private String deviceId;
    
    /**
     * カナ氏名（姓）
     */
    private String customerLastName;
    
    /**
     * カナ氏名（名）      
     */
    private String customerFirstName;
    
    /**
     * 漢字氏名（姓） 
     */
    private String customerKanjiLastName;
    
    /**
     * 漢字氏名（名）  
     */
    private String customerKanjiFirstName;

}

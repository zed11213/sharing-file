package jp.co.jsbank.mobile.bff.common.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 秘匿トークンヘルプクラス。
 */
public class HashHelper {

    /**
     * ログ
     */
    private static Logger logger = LoggerFactory.getLogger(HashHelper.class);

    /**
     * コンストラクタ
     */
    private HashHelper() {
        super();
    }

    /**
     * ハッシュ化
     * 
     * @param str ハッシュしたい対象
     * @param uuid UUID
     * @return トークン値
     */
    public static String cryptoHash(String str, String uuid) {

        String result = null;

        // SHA-256（SHA-2）
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            // ハッシュ化したい対象＋UUID
            result = new String(Base64.getEncoder().encode(digest.digest(str.concat(uuid).getBytes())));
        } catch (NoSuchAlgorithmException e) {
            logger.info("ハッシュ化失敗しました。");
        }
        return result;
    }
}

package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 代表者・役員DTO
 */
@Data
public class RepresentativeOfficerDto {

    /**
     * 役員役職
     */
    private String position;

    /**
     * 役員氏名カナ（姓）
     */
    private String officerKanaLast;

    /**
     * 役員氏名カナ（名）
     */
    private String officerKanaFirst;

    /**
     * 役員氏名漢字（姓）
     */
    private String officerKanjiLast;

    /**
     * 役員氏名漢字（名）
     */
    private String officerKanjiFirst;

    /**
     * 役員生年月日
     */
    private String officerBirthday;

}

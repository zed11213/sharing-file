package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.AddressInfoDto;
import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 郵便番号住所レスポンスDTO
 */
@Data
public class PostalCodeAddressInquiryAbaResponseDto {

    /**
     * 共通レスポンス・ヘッダ
     */
    private CommonResponseHeader commonResponseHeader;

    /**
     * 住所情報
     */
    private List<AddressInfoDto> addressInfo;
    
    /**
     * 候补FLG
     */
    private String alternateFlg;
}

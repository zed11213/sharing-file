package jp.co.jsbank.mobile.bff.logic.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.jsbank.mobile.bff.common.code.PersonalityFlagCode;
import jp.co.jsbank.mobile.bff.config.RestClientConfig;
import jp.co.jsbank.mobile.bff.dto.AddressInfoDto;
import jp.co.jsbank.mobile.bff.dto.AddressInfomationRequestDto;
import jp.co.jsbank.mobile.bff.dto.BeneficialOwnerDto;
import jp.co.jsbank.mobile.bff.dto.BizAddressInfomationRequestDto;
import jp.co.jsbank.mobile.bff.dto.BizHomeInfomationRequestDto;
import jp.co.jsbank.mobile.bff.dto.BranchStoreAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.BranchStoreDto;
import jp.co.jsbank.mobile.bff.dto.IdentityVerificationDocumentsDto;
import jp.co.jsbank.mobile.bff.dto.PostalCodeAutoSearchRequestDto;
import jp.co.jsbank.mobile.bff.dto.RepresentativeOfficerDto;
import jp.co.jsbank.mobile.bff.dto.aba.AccountOpeningApplicationAbaCorporationInfoDto;
import jp.co.jsbank.mobile.bff.dto.aba.AccountOpeningApplicationBusinessOwnerInfoAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.AccountOpeningApplicationIndividualInfoAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.AccountOpeningApplicationInfoAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.AddressInfomationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.ApplicationCompleteAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.BizHomeInfomationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.BranchOfficeListInquiryAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CcIssuingAppContentUpdateAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CcIssuingApplicationContentUpdateAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CcIssuingApplicationContentUpdateAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CifInquiryAbaRequetDto;
import jp.co.jsbank.mobile.bff.dto.aba.CifInquiryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CommonHeaderAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.ContractManagementOperationHistoryAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.ContractManagementOperationHistoryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.ContractManagementOperationHistoryRegAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.ContractManagementOperationHistoryRegistrationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.DepartmentStoreAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.EmailAddressAuthorizationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.EmailAddressAuthorizationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.EmailAddressRegistrationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.EmailAddressRegistrationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.FixedTermDespositBalanceAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.FixedTermFixedBalanceAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.HeadOfficeAddressInformationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.HopeStoreSettingAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.HopeStoreSettingBusinessOwnerInfoAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.HopeStoreSettingCorporationInfoAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.HopeStoreSettingIndividualInfoAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.IndividualAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.IvrAuthorizationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.IvrAuthorizationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.IvrSendingAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.IvrSendingAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.PostalCodeAddressInquiryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.PostalCodeAutoSearchAbaResponseDto;
import jp.co.jsbank.mobile.bff.logic.AccountOpeningLogic;

/**
 * 電子通帳ロジック実装クラス
 */
@Service
public class AccountOpeningLogicImpl implements AccountOpeningLogic {

    @Autowired
    RestClientConfig restClientConfig;

    /**
     * 契約管理操作履歴照会
     *
     * @param requestDto 契約管理操作履歴ABAリクエストDTO
     * @return 契約管理操作履歴情報
     */
    @Override
    public ContractManagementOperationHistoryAbaResponseDto
            contractManagementOperationHistoryInquiry(ContractManagementOperationHistoryAbaRequestDto requestDto) {

        // Dummyデータ
        ContractManagementOperationHistoryAbaResponseDto dto = new ContractManagementOperationHistoryAbaResponseDto();

        // 画面ID
        dto.setPageId("page0001");
        // 人格区分
        dto.setPersonType(PersonalityFlagCode.INDIVIDUAL);

        return dto;
    }

    /**
     * 口座開設申込情報（法人）取得
     *
     * @param requestDto 口座開設申込情報リクエストDTO
     * @return 口座開設申込情報（法人）
     */
    @Override
    public AccountOpeningApplicationAbaCorporationInfoDto
            getAccountOpeningApplicationCorporateInfo(AccountOpeningApplicationInfoAbaRequestDto requestDto) {

        // Dummyデータ
        AccountOpeningApplicationAbaCorporationInfoDto dto = new AccountOpeningApplicationAbaCorporationInfoDto();

        /**
         * 受付番号
         */
        dto.setReceiptNumber("5354924220");

        /**
         * 顧客ID
         */
        dto.setCustomerId("5354924220");

        /**
         * CIF番号
         */
        dto.setCifNumber("0010000011");

        /**
         * 人格区分
         */
        dto.setPersonType("0");

        /**
         * 申込ステータス
         */
        dto.setApplyStatus("01");

        /**
         * 申請開始日時
         */
        dto.setApplyStartDateTime("2022-04-04T23:21:20.123456");

        /**
         * 申請有効期限日時
         */
        dto.setApplyValidDateTime("2022-04-04T14:13:12.123456");

        /**
         * 利用停止フラグ
         */
        dto.setUseSuspendFlag("1");

        /**
         * 取引種別
         */
        dto.setTransactionType("1");

        /**
         * 会社形態
         */
        dto.setCompanyForm("01");

        /**
         * 会社形態（その他）
         */
        dto.setCompanyFormOther("会社形態（その他）");

        /**
         * 会社形態位置
         */
        dto.setCompanyFormLocation("01");

        /**
         * 事業先名（カナ）
         */
        dto.setBusinessNameKana("ｼﾝﾖｳｷﾝｺ");

        /**
         * 事業先名（漢字）
         */
        dto.setBusinessNameKanji("信用金庫");

        /**
         * 代表者・役員リスト
         */
        List<RepresentativeOfficerDto> ceoOfficer = new ArrayList<RepresentativeOfficerDto>();
        RepresentativeOfficerDto representativeOfficerDto = new RepresentativeOfficerDto();

        /**
         * 役員役職
         */
        representativeOfficerDto.setPosition("01");

        /**
         * 役員氏名カナ（姓）
         */
        representativeOfficerDto.setOfficerKanaLast("ﾀﾅｶ");

        /**
         * 役員氏名カナ（名）
         */
        representativeOfficerDto.setOfficerKanaFirst("ｹﾝﾀﾛｳ");

        /**
         * 役員氏名漢字（姓）
         */
        representativeOfficerDto.setOfficerKanjiLast("田中");

        /**
         * 役員氏名漢字（名）
         */
        representativeOfficerDto.setOfficerKanjiFirst("健太郎");

        /**
         * 役員生年月日
         */
        representativeOfficerDto.setOfficerBirthday("1990-10-10");
        ceoOfficer.add(representativeOfficerDto);
        dto.setCeoOfficer(ceoOfficer);

        /**
         * 代表者氏名カナ（姓）
         */
        dto.setCeoKanaLast("ﾀﾅｶ");

        /**
         * 代表者氏名カナ（名）
         */
        dto.setCeoKanaFirst("ケンタロウ");

        /**
         * 代表者氏名漢字（姓）
         */
        dto.setCeoKanjiLast("田中");

        /**
         * 代表者氏名漢字（名）
         */
        dto.setCeoKanjiFirst("健太郎");

        /**
         * 代表者生年月日
         */
        dto.setCeoBirthday("1980-03-24");

        /**
         * 代表者郵便番号
         */
        dto.setCeoZipCode("1340087");

        /**
         * 代表者都道府県（カナ）
         */
        dto.setCeoStateKana("トウキョウト");

        /**
         * 代表者都道府県
         */
        dto.setCeoState("東京都");

        /**
         * 代表者市区町村（カナ）
         */
        dto.setCeoCityKana("江戸川");

        /**
         * 代表者市区町村
         */
        dto.setCeoCity("エドガワ");

        /**
         * 代表者丁目（カナ）
         */
        dto.setCeoStreetKana("タカシマヘイジチョウメ２６");

        /**
         * 代表者丁目
         */
        dto.setCeoStreet("高島平二丁目２６");

        /**
         * 代表者番地（カナ）
         */
        dto.setCeoAddressKana("26バン");

        /**
         * 代表者番地
         */
        dto.setCeoAddress("２６番");

        /**
         * 代表者建物名・号室（カナ）
         */
        dto.setCeoBuildingKana("ニシカツ");

        /**
         * 代表者建物名・号室
         */
        dto.setCeoBuilding("西葛");

        /**
         * 実質的支配者リスト
         */
        List<BeneficialOwnerDto> substantialRuler = new ArrayList<BeneficialOwnerDto>();
        BeneficialOwnerDto beneficialOwnerDto = new BeneficialOwnerDto();

        /**
         * 支配者氏名カナ（姓）
         */
        beneficialOwnerDto.setRulerKanaLast("ｶﾜﾆｼ");

        /**
         * 支配者氏名カナ（名）
         */
        beneficialOwnerDto.setRulerKanaFirst("ｼｮｳﾀ");

        /**
         * 支配者氏名漢字（姓）
         */
        beneficialOwnerDto.setRulerKanjiLast("川西");

        /**
         * 支配者氏名漢字（名）
         */
        beneficialOwnerDto.setRulerKanjiFirst("翔太");

        /**
         * 支配者生年月日
         */
        beneficialOwnerDto.setRulerBirth("1991-11-11");

        /**
         * 支配者郵便番号
         */
        beneficialOwnerDto.setRulerZipCode("1660004");

        /**
         * 支配者都道府県（カナ）
         */
        beneficialOwnerDto.setRulerStateKana("ﾄｳｷｮｳ");

        /**
         * 支配者都道府県
         */
        beneficialOwnerDto.setRulerState("東京");

        /**
         * 支配者市区町村（カナ）
         */
        beneficialOwnerDto.setRulerCityKana("ｴﾄﾞｶﾞﾜｸﾆｼｶｻｲ");

        /**
         * 支配者市区町村
         */
        beneficialOwnerDto.setRulerCity("江戸川区西葛西");

        /**
         * 支配者丁目（カナ）
         */
        beneficialOwnerDto.setRulerStreetKana("6ﾁｮｳﾒ");

        /**
         * 支配者丁目
         */
        beneficialOwnerDto.setRulerStreet("６丁目");

        /**
         * 支配者番地（カナ）
         */
        beneficialOwnerDto.setRulerAddressKana("2-3");

        /**
         * 支配者番地
         */
        beneficialOwnerDto.setRulerAddress("2-3");

        /**
         * 支配者建物名・号室（カナ）
         */
        beneficialOwnerDto.setRulerBuildingKana("ﾄｸﾀﾞﾏﾝｼｮﾝ301");

        /**
         * 支配者建物名・号室
         */
        beneficialOwnerDto.setRulerBuilding("徳田マンション３０１");

        substantialRuler.add(beneficialOwnerDto);
        dto.setSubstantialRuler(substantialRuler);

        /**
         * 設立年月日
         */
        dto.setEstablishDate("1990-03-24");

        /**
         * 資本金
         */
        dto.setCapital("10000");

        /**
         * 従業員人数
         */
        dto.setNumberOfEmployees("1000");

        /**
         * 所在地郵便番号
         */
        dto.setLocationZipCode("1340087");

        /**
         * 所在地都道府県（カナ）
         */
        dto.setLocationStateKana("トウキョウト");

        /**
         * 所在地都道府県
         */
        dto.setLocationState("東京都");

        /**
         * 所在地市区町村（カナ）
         */
        dto.setLocationCityKana("エドガワ");

        /**
         * 所在地市区町村
         */
        dto.setLocationCity("江戸川");

        /**
         * 所在地丁目（カナ）
         */
        dto.setLocationStreetKana("タカシマヘイジチョウメ２６");

        /**
         * 所在地丁目
         */
        dto.setLocationStreet("高島平二丁目２６");

        /**
         * 所在地番地（カナ）
         */
        dto.setLocationAddressKana("26バン");

        /**
         * 所在地番地
         */
        dto.setLocationAddress("２６番");

        /**
         * 建物名・号室（カナ）
         */
        dto.setBuildingRoomKana("ニシカツ");

        /**
         * 建物名・号室
         */
        dto.setBuildingRoom("西葛");

        /**
         * 本店所在地相違区分
         */
        dto.setHeadOfficeClassification("01");

        /**
         * 本店所在地郵便番号
         */
        dto.setHeadOfficeLocZipCode("1340088");

        /**
         * 本店所在地都道府県（カナ）
         */
        dto.setHeadOfficeLocStateKana("トウキョウト");

        /**
         * 本店所在地都道府県
         */
        dto.setHeadOfficeLocState("東京都");

        /**
         * 本店所在地市区町村（カナ）
         */
        dto.setHeadOfficeLocCityKana("エドガワ");

        /**
         * 本店所在地市区町村
         */
        dto.setHeadOfficeLocCity("江戸川");

        /**
         * 本店所在地丁目（カナ）
         */
        dto.setHeadOfficeLocStreetKana("タカシマヘイジチョウメ２8");

        /**
         * 本店所在地丁目
         */
        dto.setHeadOfficeLocStreet("高島平二丁目２8");

        /**
         * 本店所在地番地（カナ）
         */
        dto.setHeadOfficeLocAddressKana("28バン");

        /**
         * 本店所在地番地
         */
        dto.setHeadOfficeLocAddress("２8番");

        /**
         * 本店建物名・号室（カナ）
         */
        dto.setHeadOfficeLocBuildingKana("トクダ３０１");

        /**
         * 本店建物名・号室
         */
        dto.setHeadOfficeLocBuilding("徳田３０１");

        /**
         * 電話番号種別１
         */
        dto.setPhoneType1("01");

        /**
         * 自宅電話番号１（上）
         */
        dto.setHomePhone1Top("053");

        /**
         * 自宅電話番号１（中）
         */
        dto.setHomePhone1Middle("0421");

        /**
         * 自宅電話番号１（下）
         */
        dto.setHomePhone1Bottom("6578");

        /**
         * 電話番号種別２
         */
        dto.setPhoneType2("02");

        /**
         * 自宅電話番号２（上）
         */
        dto.setHomePhone2Top("054");

        /**
         * 自宅電話番号２（中）
         */
        dto.setHomePhone2Middle("0424");

        /**
         * 自宅電話番号２（下）
         */
        dto.setHomePhone2Bottom("6574");

        /**
         * 取引目的
         */
        dto.setTransactPurpose("02");

        /**
         * 取引目的（その他）
         */
        dto.setTransactPurposeOther("取引目的その他サンプル");

        /**
         * 取引目的（詳細）
         */
        dto.setTransactPurposeDetail("取引目的詳細サンプル");

        /**
         * 事業内容
         */
        dto.setBusinessDescription("07");

        /**
         * 事業内容（その他）
         */
        dto.setBusinessDescriptionOther("事業内容その他サンプル");

        /**
         * 取扱品目
         */
        dto.setHandingItem("02");

        /**
         * 主要取引先（仕入）
         */
        dto.setMainlyTradePurchase("主要取引先仕入サンプル");

        /**
         * 主要取引先（販売）
         */
        dto.setMainlyTradeSale("主要取引先販売サンプル");

        /**
         * 当金庫との取引希望
         */
        dto.setPreferredTrade("02");

        /**
         * 当金庫との取引希望（その他）
         */
        dto.setOtherBusinessWishes("当金庫との取引希望その他サンプル");

        /**
         * 取引のきっかけ
         */
        dto.setTransactionTrigger("01");

        /**
         * 開設部店コード
         */
        dto.setOpenBranchCode("1");

        /**
         * メールアドレス
         */
        dto.setEmailAddress("user0001@jsbank.co.jp");

        /**
         * 取引金融機関
         */
        dto.setFinancialInstitution("大阪梅田第二支店");

        /**
         * 取引金融機関（預金状況）
         */
        dto.setFinancialInstitutionDepositStatus("02001");

        /**
         * 取引金融機関（貸金状況）
         */
        dto.setFinancialInstitutionLoanStatus("03002");

        /**
         * 代表者本人確認書類リスト
         */
        List<IdentityVerificationDocumentsDto> identityDocuments = new ArrayList<IdentityVerificationDocumentsDto>();
        IdentityVerificationDocumentsDto identityVerificationDocumentsDto = new IdentityVerificationDocumentsDto();
        identityVerificationDocumentsDto.setDocumentsType("1");
        identityDocuments.add(identityVerificationDocumentsDto);
        dto.setIdentityDocuments(identityDocuments);

        /**
         * 事業先本人確認書類リスト
         */
        List<IdentityVerificationDocumentsDto> businessDocuments = new ArrayList<IdentityVerificationDocumentsDto>();
        IdentityVerificationDocumentsDto businessDocumentsDto = new IdentityVerificationDocumentsDto();
        identityVerificationDocumentsDto.setDocumentsType("2");
        businessDocuments.add(businessDocumentsDto);
        dto.setIdentityDocuments(businessDocuments);
        return dto;
    }

    /**
     * 口座開設申込情報（個人事業者）取得
     *
     * @param requestDto 口座開設申込情報リクエストDTO
     * @return 口座開設申込情報（個人事業者）
     */
    @Override
    public AccountOpeningApplicationBusinessOwnerInfoAbaResponseDto
            getAccountOpeningApplicationSoleProprietorInfo(AccountOpeningApplicationInfoAbaRequestDto requestDto) {

        // Dummyデータ
        AccountOpeningApplicationBusinessOwnerInfoAbaResponseDto dto = new AccountOpeningApplicationBusinessOwnerInfoAbaResponseDto();

        /**
         * 受付番号
         */
        dto.setReceiptNumber("5354924220");

        /**
         * 顧客ID
         */
        dto.setCustomerId("5354924220");

        /**
         * CIF番号
         */
        dto.setCifNumber("0010000011");

        /**
         * 人格区分
         */
        dto.setPersonType("1");

        /**
         * 申込ステータス
         */
        dto.setApplyStatus("01");

        /**
         * 申請開始日時
         */
        dto.setApplyStartDateTime("2022-04-04T23:21:20.123456");

        /**
         * 申請有効期限日時
         */
        dto.setApplyValidDateTime("2022-04-04T14:13:12.123456");

        /**
         * 利用停止フラグ
         */
        dto.setUseSuspendFlag("1");

        /**
         * 取引種別
         */
        dto.setTransactionType("1");

        /**
         * 氏名カナ（姓）
         */
        dto.setNameKanaLast("ﾀﾅｶ");

        /**
         * 氏名カナ（名）
         */
        dto.setNameKannFirst("ｹﾝﾀﾛｳ");

        /**
         * 氏名漢字（姓）
         */
        dto.setNameKanjiLast("田中");

        /**
         * 氏名漢字（名）
         */
        dto.setNameKanjiFirst("健太郎");

        /**
         * 生年月日
         */
        dto.setBirthday("1979-04-10");

        /**
         * 性別
         */
        dto.setGender("2");

        /**
         * 自宅郵便番号
         */
        dto.setHomeZipCode("1340088");

        /**
         * 自宅都道府県（カナ）
         */
        dto.setHomeStateKana("トウキョウト");

        /**
         * 自宅都道府県
         */
        dto.setHomeState("東京都");

        /**
         * 自宅市区町村（カナ）
         */
        dto.setHomeCityKana("エドガワク");

        /**
         * 自宅市区町村
         */
        dto.setHomeCity("江戸川");

        /**
         * 自宅丁目（カナ）
         */
        dto.setHomeStreetKana("6チョウメ");

        /**
         * 自宅丁目
         */
        dto.setHomeStreet("６丁目");

        /**
         * 自宅番地（カナ）
         */
        dto.setHomeAddressKana("２－３");

        /**
         * 自宅番地
         */
        dto.setHomeAddress("２－３");

        /**
         * 自宅建物名・号室（カナ）
         */
        dto.setHomeBuildingKana("トクだ３０１");

        /**
         * 自宅建物名・号室
         */
        dto.setHomeBuilding("徳田３０１");

        /**
         * 所在地郵便番号
         */
        dto.setLocationZipCode("1340088");

        /**
         * 所在地都道府県（カナ）
         */
        dto.setLocationStateKana("トウキョウト");

        /**
         * 所在地都道府県
         */
        dto.setLocationState("東京都");

        /**
         * 所在地市区町村（カナ）
         */
        dto.setLocationCityKana("エドガワ");

        /**
         * 所在地市区町村
         */
        dto.setLocationCity("江戸川");

        /**
         * 所在地丁目（カナ）
         */
        dto.setLocationStreetKana("タカシマヘイジチョウメ２8");

        /**
         * 所在地丁目
         */
        dto.setLocationStreet("高島平二丁目２8");

        /**
         * 所在地番地（カナ）
         */
        dto.setLocationAddressKana("ニシカツ");

        /**
         * 所在地番地
         */
        dto.setLocationAddress("西葛");

        /**
         * 建物名・号室（カナ）
         */
        dto.setBuildingRoomKana("トクダ３０１");

        /**
         * 建物名・号室
         */
        dto.setBuildingRoom("徳田３０１");

        /**
         * 電話番号種別１
         */
        dto.setPhoneType1("01");

        /**
         * 自宅電話番号１（上）
         */
        dto.setHomePhone1Top("070");

        /**
         * 自宅電話番号１（中）
         */
        dto.setHomePhone1Middle("3205");

        /**
         * 自宅電話番号１（下）
         */
        dto.setHomePhone1Bottom("0125");

        /**
         * 電話番号種別２
         */
        dto.setPhoneType2("02");

        /**
         * 自宅電話番号２（上）
         */
        dto.setHomePhone2Top("071");

        /**
         * 自宅電話番号２（中）
         */
        dto.setHomePhone2Middle("3206");

        /**
         * 自宅電話番号２（下）
         */
        dto.setHomePhone2Bottom("0126");

        /**
         * 取引目的
         */
        dto.setTransactPurpose("02");

        /**
         * 取引目的（その他 ）
         */
        dto.setTransactPurposeOther("取引目的その他サンプル");

        /**
         * 取引目的（詳細）
         */
        dto.setTransactPurposeDetail("取引目的詳細サンプル");

        /**
         * 職業事業内容
         */
        dto.setBusinessDescription("07");

        /**
         * 職業事業内容（その他）
         */
        dto.setBusinessDescriptionOther("事業内容その他サンプル");

        /**
         * 取扱品目
         */
        dto.setHandingItem("取扱品目サンプル");

        /**
         * 主要取引先（仕入）
         */
        dto.setMainlyTradePurchase("主要取引先仕入サンプル");

        /**
         * 主要取引先（販売）
         */
        dto.setMainlyTradeSale("主要取引先販売サンプル");

        /**
         * 当金庫との取引希望
         */
        dto.setPreferredTrade("02");

        /**
         * 当金庫との取引希望（その他）
         */
        dto.setOtherBusinessWishes("当金庫との取引希望その他サンプル");

        /**
         * 取引のきっかけ
         */
        dto.setTransactionTrigger("01");

        /**
         * 開設部店コード
         */
        dto.setOpenBranchCode("1");

        /**
         * メールアドレス
         */
        dto.setEmailAddress("user0001@jsbank.co.jp");

        /**
         * 取引金融機関
         */
        dto.setFinancialInstitution("大阪梅田第二支店");

        /**
         * 取引金融機関（預金状況）
         */
        dto.setFinancialInstitutionDepositStatus("02001");

        /**
         * 取引金融機関（貸金状況）
         */
        dto.setFinancialInstitutionLoanStatus("03002");

        /**
         * 本人確認書類リスト
         */
        IdentityVerificationDocumentsDto identityVerificationDocumentsDto = new IdentityVerificationDocumentsDto();
        identityVerificationDocumentsDto.setDocumentsType("01");
        List<IdentityVerificationDocumentsDto> identityDocuments = new ArrayList<IdentityVerificationDocumentsDto>();
        identityDocuments.add(identityVerificationDocumentsDto);
        dto.setIdentityDocuments(identityDocuments);

        return dto;
    }

    /**
     * 口座開設申込情報（個人）取得
     *
     * @param requestDto 口座開設申込情報ABAリクエストDTO
     * @return 口座開設申込情報（個人）
     */
    @Override
    public AccountOpeningApplicationIndividualInfoAbaResponseDto
            accountOpeningApplicationIndividualInfoInquiry(AccountOpeningApplicationInfoAbaRequestDto requestDto) {

        // Dummyデータ
        AccountOpeningApplicationIndividualInfoAbaResponseDto individual = new AccountOpeningApplicationIndividualInfoAbaResponseDto();
        /**
         * 受付番号
         */
        individual.setReceiptNumber("5354924220");

        /**
         * CIF番号
         */
        individual.setCifNumber("5354924220");

        /**
         * 人格区分
         */
        individual.setPersonType("0010000011");

        /**
         * 取引種別
         */
        individual.setTransactionType("0");

        /**
         * 申込日
         */
        individual.setApplicationDate("01");

        /**
         * 申請開始日時
         */
        individual.setApplyStartDateTime("2022-04-04T23:21:20.123456");

        /**
         * 申請有効期限日時
         */
        individual.setApplyValidDateTime("2022-04-04T14:13:12.123456");

        /**
         * カナ氏名（姓）
         */
        individual.setCustomerLastName("ﾀﾅｶ");

        /**
         * カナ氏名（名）
         */
        individual.setCustomerFirstName("ｹﾝﾀﾛｳ");

        /**
         * 氏名漢字（姓）
         */
        individual.setCustomerKanjiLastName("田中");

        /**
         * 氏名漢字（名）
         */
        individual.setCustomerKanjiFirstName("健太郎");

        /**
         * 性別
         */
        individual.setGender("2");

        /**
         * 性別回答有無
         */
        individual.setGenderAnswer("1");

        /**
         * 生年月日
         */
        individual.setBirthday("1979-04-10");

        /**
         * 郵便番号
         */
        individual.setZipCode("1340088");

        /**
         * 地区コード
         */
        individual.setAddressCode("100365");

        /**
         * 地区コード（枝番）
         */
        individual.setAddressCodeBranchNumber("123");

        /**
         * 都道府県（カナ）
         */
        individual.setPrefectureKana("トウキョウと");

        /**
         * 都道府県
         */
        individual.setPrefecture("東京都");

        /**
         * 市区町村（カナ）
         */
        individual.setCityKana("エドガワク");

        /**
         * 市区町村
         */
        individual.setCity("江戸川");

        /**
         * 丁目（カナ）
         */
        individual.setAddrDetail2Kana("6チョウメ");

        /**
         * 丁目
         */
        individual.setAddrDetail2("６丁目");

        /**
         * 番地（カナ）
         */
        individual.setAddrDetail3Kana("２－３");

        /**
         * 番地
         */
        individual.setAddrDetail3("２－３");

        /**
         * 申込ステータス
         */
        individual.setApplyStatus("01");

        /**
         * 建物名・号室（カナ）
         */
        individual.setBuildingRoomKana("トクダ３０１");

        /**
         * 建物名・号室
         */
        individual.setBuildingRoom("徳田３０１");

        /**
         * 電話番号１種別
         */
        individual.setPhoneType1("01");

        /**
         * 電話番号１（上）
         */
        individual.setPhoneNumOneFirst("053");

        /**
         * 電話番号１（中）
         */
        individual.setPhoneNumOneMid("0421");

        /**
         * 電話番号１（下）
         */
        individual.setPhoneNumOneLast("6578");

        /**
         * 電話番号２種別
         */
        individual.setPhoneType2("02");

        /**
         * 電話番号２（上）
         */
        individual.setPhoneNumTwoFirst("054");

        /**
         * 電話番号２（中）
         */
        individual.setPhoneNumTwoMid("0424");

        /**
         * 電話番号２（下）
         */
        individual.setPhoneNumTwoLast("6574");

        /**
         * 職業
         */
        individual.setOccupation("01");

        /**
         * 職業（その他）
         */
        individual.setOccupationOther("職業その他サンプル");

        /**
         * 取引目的
         */
        individual.setTransactPurpose("02");

        /**
         * 取引目的（その他）
         */
        individual.setTransactPurposeOther("取引目的その他サンプル");

        /**
         * 取引のきっかけ
         */
        individual.setTransactionTrigger("01");

        /**
         * 店番
         */
        individual.setBranchNumber("1100");

        /**
         * 預金種目
         */
        individual.setAccountType("01");

        /**
         * 口座番号
         */
        individual.setAccountNumber("657123654");

        /**
         * サブNo
         */
        individual.setAccountSubNumber("AccountSubNumber");

        /**
         * 勤務先名
         */
        individual.setWpName("信用金庫");

        /**
         * 勤務先郵便番号
         */
        individual.setWpZipCode("134-0088");

        /**
         * 勤務先都道府県
         */
        individual.setWpPrefecture("東京都");

        /**
         * 勤務先市区町村
         */
        individual.setWpCity("歌舞伎町");

        /**
         * 勤務先丁目
         */
        individual.setWpStreet("高島平二丁目２６");

        /**
         * 勤務先番地
         */
        individual.setWpAddress("２６番");

        /**
         * 勤務先建物名・号室
         */
        individual.setWpBuilding("２－１２－２");

        /**
         * 勤務先電話番号種別
         */
        individual.setWpPhoneType("01");

        /**
         * 勤務先電話番号（上）
         */
        individual.setWpPhoneFirst("072");

        /**
         * 勤務先電話番号（中）
         */
        individual.setWpPhoneMid("3208");

        /**
         * 勤務先電話番号（下）
         */
        individual.setWpPhoneLast("0125");

        /**
         * メールアドレス
         */
        individual.setEmailAddress("user0001@jsbank.co.jp");

        /**
         * 開設店番
         */
        individual.setOpenBranchNumber("1100");

        /**
         * eKYC確認結果
         */
        individual.setEkycResult("0");

        /**
         * 本人確認書類リスト
         */
        IdentityVerificationDocumentsDto identityVerificationDocumentsDto = new IdentityVerificationDocumentsDto();
        identityVerificationDocumentsDto.setDocumentsType("01");
        List<IdentityVerificationDocumentsDto> identityDocuments = new ArrayList<IdentityVerificationDocumentsDto>();
        identityDocuments.add(identityVerificationDocumentsDto);
        individual.setIdentityDocuments(identityDocuments);
        return individual;
    }

    /**
     * 口座開設申込内容更新（個人）
     *
     * @param requestDto 口座開設申込情報（個人）ABAリクエストDTO
     * @return 共通レスポンス・ボディ
     */
    @Override
    public CommonHeaderAbaResponseDto accountOpeningApplicationIndividualInfoUpdate(
            AccountOpeningApplicationIndividualInfoAbaResponseDto requestDto) {

        // dummyデータ
        return new CommonHeaderAbaResponseDto();
    }

    /**
     * 口座開設申込内容更新（法人）
     *
     * @param requestDto 口座開設申込情報（法人）ABAリクエストDTO
     * @return 共通レスポンス・ボディ
     */
    @Override
    public CommonHeaderAbaResponseDto
            accountOpeningApplicationCorporationInfoUpdate(AccountOpeningApplicationAbaCorporationInfoDto requestDto) {

        // dummyデータ
        return new CommonHeaderAbaResponseDto();
    }

    /**
     * 口座開設申込内容更新（個人事業主）
     *
     * @param requestDto 口座開設申込情報（個人事業主）ABAリクエストDTO
     * @return 共通レスポンス・ボディ
     */
    @Override
    public CommonHeaderAbaResponseDto accountOpeningApplicationBusinessOwnerInfoUpdate(
            AccountOpeningApplicationBusinessOwnerInfoAbaResponseDto requestDto) {

        // dummyデータ
        return new CommonHeaderAbaResponseDto();
    }

    /**
     * 契約管理操作履歴登録
     *
     * @param requestDto 契約管理操作履歴登録ABAリクエストDTO
     * 
     * @return 共通レスポンス・ボディ
     */
    @Override
    public CommonHeaderAbaResponseDto contractManagementOperationHistoryRegistration(
            ContractManagementOperationHistoryRegistrationAbaRequestDto requestDto) {

        // dummyデータ
        return new CommonHeaderAbaResponseDto();
    }

    /**
     * 定期預金残高照会
     *
     * @param regularAccountNumber 定期預金口座番号
     * 
     * @return 定期預金残高照会情報
     */
    @Override
    public FixedTermDespositBalanceAbaResponseDto fixedTermDepositInquiry(String regularAccountNumber) {

        // dummyデータ
        return new FixedTermDespositBalanceAbaResponseDto();
    }

    /**
     * 定期積金残高照会
     *
     * @param fixedAccountNumber 定期積金口座番号
     * 
     * @return 定期積金残高照会情報
     */
    @Override
    public FixedTermFixedBalanceAbaResponseDto fixedTermFixedInquiry(String fixedAccountNumber) {

        // dummyデータ
        return new FixedTermFixedBalanceAbaResponseDto();
    }

    /**
     * 営業地区部店一覧照会
     *
     * @param zipCode 郵便番号
     * @return 営業地区部店一覧照会情報
     */
    @Override
    public DepartmentStoreAbaResponseDto salesAreaDepartmentStoreInquiry(String zipCode) {

        DepartmentStoreAbaResponseDto resDto = new DepartmentStoreAbaResponseDto();

        // // dummyデータ
        // DepartmentStoreDto dto1 = new DepartmentStoreDto();
        //
        // /**
        // * 地区区分
        // */
        // dto1.setAreaCode("0342");
        //
        // /**
        // * 地区コード
        // */
        // dto1.setAddressCode("0001");
        //
        // /**
        // * 店番
        // */
        // dto1.setBranchNumber("01101");
        //
        // /**
        // * 都道府県漢字
        // */
        // dto1.setPrefecture("東京都");
        //
        // /**
        // * 市区町村漢字
        // */
        // dto1.setCity("五反田");
        //
        // /**
        // * 町漢字
        // */
        // dto1.setAddrDetail1("花火");
        //
        // /**
        // * 丁目漢字
        // */
        // dto1.setAddrDetail2("村");
        //
        // /**
        // * 地区郵便番号
        // */
        // dto1.setAreaZipCode("123-456");
        //
        // /**
        // * 金融機関コード
        // */
        // dto1.setBankCode("12458");
        //
        // /**
        // * 店名（漢字）
        // */
        // dto1.setBranchKanjiName("営業本部店");
        //
        // /**
        // * 所属部門区分
        // */
        // dto1.setDivisionType("1");
        //
        // /**
        // * 照会店舗タイプ
        // */
        // dto1.setBranchInquiryType("2");
        //
        // /**
        // * 支店郵便番号
        // */
        // dto1.setBranchZipCode("123-456");
        //
        // /**
        // * 店舗住所
        // */
        // dto1.setBranchKanjiAddress("東京都五反田123-456");
        //
        // /**
        // * 電話番号
        // */
        // dto1.setPhoneNumber("18842617777");
        //
        // /**
        // * 緯度
        // */
        // dto1.setLatitude("38.4");
        //
        // /**
        // * 経度
        // */
        // dto1.setLongitude("40.6");
        //
        // /**
        // * 表示グループ名
        // */
        // dto1.setDisplayGroupName("品川区");
        //
        // /**
        // * 表示順
        // */
        // dto1.setDisplayOrder("1");
        //
        // DepartmentStoreDto dto2 = new DepartmentStoreDto();
        //
        // /**
        // * 地区区分
        // */
        // dto2.setAreaCode("0342");
        //
        // /**
        // * 地区コード
        // */
        // dto2.setAddressCode("0001");
        //
        // /**
        // * 店番
        // */
        // dto2.setBranchNumber("01101");
        //
        // /**
        // * 都道府県漢字
        // */
        // dto2.setPrefecture("東京都");
        //
        // /**
        // * 市区町村漢字
        // */
        // dto2.setCity("五反田");
        //
        // /**
        // * 町漢字
        // */
        // dto2.setAddrDetail1("花火");
        //
        // /**
        // * 丁目漢字
        // */
        // dto2.setAddrDetail2("村");
        //
        // /**
        // * 地区郵便番号
        // */
        // dto2.setAreaZipCode("123-456");
        //
        // /**
        // * 金融機関コード
        // */
        // dto2.setBankCode("12458");
        //
        // /**
        // * 店名（漢字）
        // */
        // dto2.setBranchKanjiName("営業本部店");
        //
        // /**
        // * 所属部門区分
        // */
        // dto2.setDivisionType("1");
        //
        // /**
        // * 照会店舗タイプ
        // */
        // dto2.setBranchInquiryType("2");
        //
        // /**
        // * 支店郵便番号
        // */
        // dto2.setBranchZipCode("123-456");
        //
        // /**
        // * 店舗住所
        // */
        // dto2.setBranchKanjiAddress("品川五反田123-456");
        //
        // /**
        // * 電話番号
        // */
        // dto2.setPhoneNumber("18842617777");
        //
        // /**
        // * 緯度
        // */
        // dto2.setLatitude("38.4");
        //
        // /**
        // * 経度
        // */
        // dto2.setLongitude("40.6");
        //
        // /**
        // * 表示グループ名
        // */
        // dto2.setDisplayGroupName("品川区");
        //
        // /**
        // * 表示順
        // */
        // dto2.setDisplayOrder("2");
        //
        // DepartmentStoreDto dto3 = new DepartmentStoreDto();
        //
        // /**
        // * 地区区分
        // */
        // dto3.setAreaCode("0342");
        //
        // /**
        // * 地区コード
        // */
        // dto3.setAddressCode("0001");
        //
        // /**
        // * 店番
        // */
        // dto3.setBranchNumber("01101");
        //
        // /**
        // * 都道府県漢字
        // */
        // dto3.setPrefecture("東京都");
        //
        // /**
        // * 市区町村漢字
        // */
        // dto3.setCity("五反田");
        //
        // /**
        // * 町漢字
        // */
        // dto3.setAddrDetail1("花火");
        //
        // /**
        // * 丁目漢字
        // */
        // dto3.setAddrDetail2("村");
        //
        // /**
        // * 地区郵便番号
        // */
        // dto3.setAreaZipCode("123-456");
        //
        // /**
        // * 金融機関コード
        // */
        // dto3.setBankCode("12458");
        //
        // /**
        // * 店名（漢字）
        // */
        // dto3.setBranchKanjiName("営業本部店");
        //
        // /**
        // * 所属部門区分
        // */
        // dto3.setDivisionType("1");
        //
        // /**
        // * 照会店舗タイプ
        // */
        // dto3.setBranchInquiryType("2");
        //
        // /**
        // * 支店郵便番号
        // */
        // dto3.setBranchZipCode("123-456");
        //
        // /**
        // * 店舗住所
        // */
        // dto3.setBranchKanjiAddress("鶴見123-456");
        //
        // /**
        // * 電話番号
        // */
        // dto3.setPhoneNumber("18842617777");
        //
        // /**
        // * 緯度
        // */
        // dto3.setLatitude("38.4");
        //
        // /**
        // * 経度
        // */
        // dto3.setLongitude("40.6");
        //
        // /**
        // * 表示グループ名
        // */
        // dto3.setDisplayGroupName("品川区");
        //
        // /**
        // * 表示順
        // */
        // dto3.setDisplayOrder("3");
        //
        // DepartmentStoreDto dto4 = new DepartmentStoreDto();
        //
        // /**
        // * 地区区分
        // */
        // dto4.setAreaCode("0342");
        //
        // /**
        // * 地区コード
        // */
        // dto4.setAddressCode("0001");
        //
        // /**
        // * 店番
        // */
        // dto4.setBranchNumber("01101");
        //
        // /**
        // * 都道府県漢字
        // */
        // dto4.setPrefecture("東京都");
        //
        // /**
        // * 市区町村漢字
        // */
        // dto4.setCity("五反田");
        //
        // /**
        // * 町漢字
        // */
        // dto4.setAddrDetail1("花火");
        //
        // /**
        // * 丁目漢字
        // */
        // dto4.setAddrDetail2("村");
        //
        // /**
        // * 地区郵便番号
        // */
        // dto4.setAreaZipCode("123-456");
        //
        // /**
        // * 金融機関コード
        // */
        // dto4.setBankCode("12458");
        //
        // /**
        // * 店名（漢字）
        // */
        // dto4.setBranchKanjiName("営業本部店");
        //
        // /**
        // * 所属部門区分
        // */
        // dto4.setDivisionType("1");
        //
        // /**
        // * 照会店舗タイプ
        // */
        // dto4.setBranchInquiryType("2");
        //
        // /**
        // * 支店郵便番号
        // */
        // dto4.setBranchZipCode("123-456");
        //
        // /**
        // * 店舗住所
        // */
        // dto4.setBranchKanjiAddress("東京123-456");
        //
        // /**
        // * 電話番号
        // */
        // dto4.setPhoneNumber("18842617777");
        //
        // /**
        // * 緯度
        // */
        // dto4.setLatitude("38.4");
        //
        // /**
        // * 経度
        // */
        // dto4.setLongitude("40.6");
        //
        // /**
        // * 表示グループ名
        // */
        // dto4.setDisplayGroupName("大田区");
        //
        // /**
        // * 表示順
        // */
        // dto1.setDisplayOrder("1");
        //
        // DepartmentStoreDto dto5 = new DepartmentStoreDto();
        //
        // /**
        // * 地区区分
        // */
        // dto5.setAreaCode("0342");
        //
        // /**
        // * 地区コード
        // */
        // dto5.setAddressCode("0001");
        //
        // /**
        // * 店番
        // */
        // dto5.setBranchNumber("01101");
        //
        // /**
        // * 都道府県漢字
        // */
        // dto5.setPrefecture("東京都");
        //
        // /**
        // * 市区町村漢字
        // */
        // dto5.setCity("五反田");
        //
        // /**
        // * 町漢字
        // */
        // dto5.setAddrDetail1("花火");
        //
        // /**
        // * 丁目漢字
        // */
        // dto5.setAddrDetail2("村");
        //
        // /**
        // * 地区郵便番号
        // */
        // dto5.setAreaZipCode("123-456");
        //
        // /**
        // * 金融機関コード
        // */
        // dto5.setBankCode("12458");
        //
        // /**
        // * 店名（漢字）
        // */
        // dto5.setBranchKanjiName("営業本部店");
        //
        // /**
        // * 所属部門区分
        // */
        // dto5.setDivisionType("1");
        //
        // /**
        // * 照会店舗タイプ
        // */
        // dto5.setBranchInquiryType("2");
        //
        // /**
        // * 支店郵便番号
        // */
        // dto5.setBranchZipCode("123-456");
        //
        // /**
        // * 店舗住所
        // */
        // dto5.setBranchKanjiAddress("蒲田区123-456");
        //
        // /**
        // * 電話番号
        // */
        // dto5.setPhoneNumber("18842617777");
        //
        // /**
        // * 緯度
        // */
        // dto5.setLatitude("38.4");
        //
        // /**
        // * 経度
        // */
        // dto5.setLongitude("40.6");
        //
        // /**
        // * 表示グループ名
        // */
        // dto5.setDisplayGroupName("大田区");
        //
        // /**
        // * 表示順
        // */
        // dto5.setDisplayOrder("2");
        // List<DepartmentStoreDto> branchListByBusArea = new ArrayList<>();
        //
        // branchListByBusArea.add(dto1);
        // branchListByBusArea.add(dto2);
        // branchListByBusArea.add(dto3);
        // branchListByBusArea.add(dto4);
        // branchListByBusArea.add(dto5);
        // resDto.setBranchListByBusArea(branchListByBusArea);
        return resDto;
    }

    /**
     * 希望店設定（個人）
     *
     * @param hopeStoreAbaReqDto 希望店設定リクエストDTO
     * @return 処理結果
     */
    @Override
    public HopeStoreSettingIndividualInfoAbaResponseDto
            hopeStoreSettingIndividual(HopeStoreSettingAbaRequestDto hopeStoreAbaReqDto) {

        // dummyデータ
        HopeStoreSettingIndividualInfoAbaResponseDto dto = new HopeStoreSettingIndividualInfoAbaResponseDto();
        dto.setHopeDepartmentStore("01");
        dto.setReceiptNumber("001");

        return dto;
    }

    /**
     * 希望店設定（法人）
     *
     * @param requestDto 希望店設定リクエストDTO
     * @return 処理結果
     */
    @Override
    public HopeStoreSettingCorporationInfoAbaResponseDto
            hopeStoreAbaReqDtoCorporation(HopeStoreSettingAbaRequestDto requestDto) {

        // dummyデータ
        HopeStoreSettingCorporationInfoAbaResponseDto dto = new HopeStoreSettingCorporationInfoAbaResponseDto();
        dto.setHopeDepartmentStore("01");
        dto.setReceiptNumber("001");

        return dto;
    }

    /**
     * 希望店設定（個人事業主）
     *
     * @param requestDto 希望店設定リクエストDTO
     * @return 処理結果
     */
    @Override
    public HopeStoreSettingBusinessOwnerInfoAbaResponseDto
            hopeStoreAbaReqDtoBusinessOwner(HopeStoreSettingAbaRequestDto requestDto) {

        // dummyデータ
        HopeStoreSettingBusinessOwnerInfoAbaResponseDto dto = new HopeStoreSettingBusinessOwnerInfoAbaResponseDto();
        dto.setHopeDepartmentStore("01");
        dto.setReceiptNumber("001");

        return dto;
    }

    /**
     * 口座開設申込内登録（個人）
     *
     * @param individualRequetAbaDto 口座開設申込情報（個人）ABAリクエストDTO
     * @return 口座開設申込内容登録ABAレスボスDTO
     */
    @Override
    public IndividualAbaResponseDto accountOpeningApplicationIndividualInfoRegistration(
            AccountOpeningApplicationIndividualInfoAbaResponseDto individualRequetAbaDto) {

        // dummyデータ
        IndividualAbaResponseDto res = new IndividualAbaResponseDto();
        res.setReceiptNumber("0001");
        return res;
    }

    /**
     * 郵便番号の自動検索
     *
     * @param requestDto 郵便番号の自動検索BFFリクエストDTO
     * @return 処理結果
     */
    @Override
    public PostalCodeAutoSearchAbaResponseDto
            postalCodeAutoSearchResponseAba(PostalCodeAutoSearchRequestDto requestDto) {

        PostalCodeAutoSearchAbaResponseDto responseDto = new PostalCodeAutoSearchAbaResponseDto();

        // 都道府県設定
        responseDto.setPrefectures("東京都");
        // 都道府県（カナ）設定
        responseDto.setPrefecturesKana("トウキョウ");
        // 市区町村設定
        responseDto.setCity("板橋区");
        // 市区町村（カナ）設定
        responseDto.setCityKana("イタバシク");
        // 町漢字設定
        responseDto.setAddrDetail1("高島平");
        // 町漢字（カナ）設定
        responseDto.setAddrdetail1Kana("タカシマダイラ");
        // 丁目設定
        responseDto.setChome("2");
        // 丁目（半角）設定
        responseDto.setChomeHalfwidth("2");

        return responseDto;
    }

    /**
     * [CC発行申込内容更新]API呼出
     *
     * @param requestDto CC発行申込内容更新リクエストDTO
     * 
     * @return CC発行申込情報
     */
    @Override
    public CcIssuingApplicationContentUpdateAbaResponseDto
            ccIssuingApplicationContentUpdateAba(CcIssuingApplicationContentUpdateAbaRequestDto requestDto) {

        // API未定
        CcIssuingApplicationContentUpdateAbaResponseDto responseDTO = new CcIssuingApplicationContentUpdateAbaResponseDto();

        return responseDTO;
    }

    /**
     * [契約管理操作履歴登録]API呼出
     *
     * @param requestDto 契約管理操作履歴登録リクエストDTO
     * @return 契約管理操作履歴登録情報
     */
    @Override
    public ContractManagementOperationHistoryRegAbaResponseDto contractManagementOperationHistoryRegistrationAba(
            ContractManagementOperationHistoryRegistrationAbaRequestDto requestDto) {

        ContractManagementOperationHistoryRegAbaResponseDto responseDTO = new ContractManagementOperationHistoryRegAbaResponseDto();

        // IBパスワード
        responseDTO.setIbPassword("0143");

        return responseDTO;
    }

    /**
     * 所在地情報保存
     *
     * @param requestDto 所在地情報保存ABAリクエストDTO
     * @return 共通レスポンス・ボディ
     */
    @Override
    public AddressInfomationAbaResponseDto saveAddressInfomation(AddressInfomationRequestDto requestDto) {

        AddressInfomationAbaResponseDto responseDto = new AddressInfomationAbaResponseDto();
        // 受付番号設定
        responseDto.setReceiptNumber("0001");
        return responseDto;
    }

    /**
     * 本店所在地情報保存
     *
     * @param requestDto 本店所在地情報ABAリクエストDTO
     * @return 共通レスポンス・ボディ
     */
    @Override
    public CommonHeaderAbaResponseDto
            saveHeadOfficeAddressInformation(HeadOfficeAddressInformationAbaResponseDto requestDto) {

        return new CommonHeaderAbaResponseDto();
    }

    /**
     * biz自宅情報保存
     *
     * @param requestDto biz自宅情報ABAリクエストDTO
     * @return 共通レスポンス・ボディ
     */
    @Override
    public BizHomeInfomationAbaResponseDto saveBizHomeInformation(BizHomeInfomationRequestDto requestDto) {
        BizHomeInfomationAbaResponseDto responseDto = new BizHomeInfomationAbaResponseDto();
        // 受付番号設定
        responseDto.setReceiptNumber("0001");
        return responseDto;
    }

    /**
     * biz所在地情報保存
     *
     * @param requestDto biz所在地情報ABAリクエストDTO
     * @return 共通レスポンス・ボディ
     */
    @Override
    public CommonHeaderAbaResponseDto saveBizAddressInformation(BizAddressInfomationRequestDto requestDto) {

        return new CommonHeaderAbaResponseDto();
    }

    /**
     * 申込完了
     *
     * @param abaRequestDto 申込完了ABAリクエストDTO
     * @return 共通レスポンス・ボディ
     */
    @Override
    public CommonHeaderAbaResponseDto
            accountOpeningApplicationInformation(ApplicationCompleteAbaRequestDto abaRequestDto) {

        return new CommonHeaderAbaResponseDto();
    }

    /**
     * CC発行申込内容更新
     *
     * @param ccIssuingAppContentUpdateAbaRequestDto CC発行申込内容更新リクエストDTO
     * @return 共通レスポンス・ボディ
     */
    @Override
    public CommonHeaderAbaResponseDto ccIssuingApplicationContentUpdateAba(
            CcIssuingAppContentUpdateAbaRequestDto ccIssuingAppContentUpdateAbaRequestDto) {

        return new CommonHeaderAbaResponseDto();
    }

    /**
     * メールアドレス登録
     *
     * @param abaRequestDto メールアドレス登録リクエストDTO
     * @return 処理結果
     */
    @Override
    public EmailAddressRegistrationAbaResponseDto
            emailAddressRegistration(EmailAddressRegistrationAbaRequestDto abaRequestDto) {

        EmailAddressRegistrationAbaResponseDto responseDto = new EmailAddressRegistrationAbaResponseDto();
        responseDto.setVerifyTRXKey("0001");

        return responseDto;
    }

    /**
     * メールアドレス認証
     *
     * @param abaRequestDto メールアドレス認証AbaリクエストDTO
     * @return 認証済メールアドレスABAレスポンスDTO
     */
    @Override
    public EmailAddressAuthorizationAbaResponseDto
            emailAddressAuthorization(EmailAddressAuthorizationAbaRequestDto abaRequestDto) {

        EmailAddressAuthorizationAbaResponseDto responseDto = new EmailAddressAuthorizationAbaResponseDto();
        responseDto.setEmailAddress("111@111.com");
        return responseDto;
    }

    /**
     * IVR送信
     *
     * @param abaRequestDto IVR送信ABAリクエストDTO
     * @return IVR送信ABAレスポンスDTO
     */
    @Override
    public IvrSendingAbaResponseDto ivrSending(IvrSendingAbaRequestDto abaRequestDto) {

        IvrSendingAbaResponseDto responseDto = new IvrSendingAbaResponseDto();
        responseDto.setVerifyTRXKey("1234");

        return responseDto;
    }

    /**
     * IVR認証
     *
     * @param abaRequestDto IVR認証リクエストDTO
     * @return [確認ダイアログ]画面表示
     */
    @Override
    public IvrAuthorizationAbaResponseDto ivrAuthorization(IvrAuthorizationAbaRequestDto abaRequestDto) {

        // 「メールアドレス登録」API呼出
        IvrAuthorizationAbaResponseDto responseDto = new IvrAuthorizationAbaResponseDto();
        responseDto.setAuthenticationResult("OK");
        return responseDto;
    }

    /**
     * CIF照会
     *
     * @param abaRequestDto CIF照会ABAリクエストDTO
     * @return [CIF照会ABAレスポンスDTO]画面表示
     */
    @Override
    public CifInquiryAbaResponseDto cifInquiry(CifInquiryAbaRequetDto cifInquiryAbaRequetDto) {

        // 「メールアドレス登録」API呼出
        CifInquiryAbaResponseDto responseDto = new CifInquiryAbaResponseDto();
        responseDto.setAddressCode("1");

        return responseDto;
    }

    /**
     * 郵便番号住所照会
     *
     * @param zipCode 郵便番号
     * @return [部店リストレスポンスDTO]画面表示
     */
    @Override
    public PostalCodeAddressInquiryAbaResponseDto postalCodeAddressInquiry(String zipCode) {
        // 「メールアドレス登録」API呼出
        PostalCodeAddressInquiryAbaResponseDto responseDto = new PostalCodeAddressInquiryAbaResponseDto();
        responseDto.setAlternateFlg("1");
        AddressInfoDto addressInfoDto = new AddressInfoDto();
        addressInfoDto.setPrefectureKana("東京都");
        addressInfoDto.setPrefecture("東京都");
        addressInfoDto.setCityKana("ｲｲｲｲｲ");
        addressInfoDto.setAddrdetail1Kana("ｳｳｳｳ");
        List<AddressInfoDto> list = new ArrayList<AddressInfoDto>();
        list.add(addressInfoDto);
        responseDto.setAddressInfo(list);
        return responseDto;
    }

    /**
     * 部店一覧照会
     *
     * @param bankCode 金融機関コード
     * @return 営業地区部店一覧照会レスポンスDTO
     */
    @Override
    public BranchStoreAbaResponseDto
            branchOfficeListInquiry(BranchOfficeListInquiryAbaRequestDto branchOfficeListInquiryAbaRequestDto) {

        BranchStoreDto dto1 = new BranchStoreDto();

        /**
         * 金融機関コード
         */
        dto1.setBankCode("12458");

        /**
         * 店番
         */
        dto1.setBranchNumber("01101");

        /**
         * 店名（漢字）
         */
        dto1.setBranchKanjiName("営業本部店01");

        /**
         * 所属部門区分
         */
        dto1.setDivisionType("1");

        /**
         * 照会店舗タイプ
         */
        dto1.setBranchInquiryType("2");

        /**
         * 支店郵便番号
         */
        dto1.setZipCode("123-456");

        /**
         * 店舗住所
         */
        dto1.setBranchKanjiAddress("東京都五反田123-456");

        /**
         * 電話番号
         */
        dto1.setPhoneNumber("18842617777");

        /**
         * 緯度
         */
        dto1.setLatitude("38.4");

        /**
         * 経度
         */
        dto1.setLongitude("40.6");

        /**
         * 表示グループ名
         */
        dto1.setDisplayGroupName("品川区");

        /**
         * 店舗案内
         */
        dto1.setBranchGuide("店舗");

        /**
         * 表示グループ名
         */
        dto1.setDisplayGroupName("東京都");

        /**
         * 表示順
         */
        dto1.setDisplayOrder("1");

        BranchStoreDto dto2 = new BranchStoreDto();

        /**
         * 金融機関コード
         */
        dto2.setBankCode("12458");

        /**
         * 店番
         */
        dto2.setBranchNumber("01101");

        /**
         * 店名（漢字）
         */
        dto2.setBranchKanjiName("営業本部店02");

        /**
         * 所属部門区分
         */
        dto2.setDivisionType("1");

        /**
         * 照会店舗タイプ
         */
        dto2.setBranchInquiryType("2");

        /**
         * 支店郵便番号
         */
        dto2.setZipCode("123-456");

        /**
         * 店舗住所
         */
        dto2.setBranchKanjiAddress("東京都五反田123-456");

        /**
         * 電話番号
         */
        dto2.setPhoneNumber("18842617777");

        /**
         * 緯度
         */
        dto2.setLatitude("38.4");

        /**
         * 経度
         */
        dto2.setLongitude("40.6");

        /**
         * 表示グループ名
         */
        dto2.setDisplayGroupName("品川区");

        /**
         * 店舗案内
         */
        dto2.setBranchGuide("店舗");

        /**
         * 表示グループ名
         */
        dto2.setDisplayGroupName("東京都");

        /**
         * 表示順
         */
        dto2.setDisplayOrder("1");

        BranchStoreDto dto3 = new BranchStoreDto();

        /**
         * 金融機関コード
         */
        dto3.setBankCode("12458");

        /**
         * 店番
         */
        dto3.setBranchNumber("01101");

        /**
         * 店名（漢字）
         */
        dto3.setBranchKanjiName("営業本部店03");

        /**
         * 所属部門区分
         */
        dto3.setDivisionType("1");

        /**
         * 照会店舗タイプ
         */
        dto3.setBranchInquiryType("2");

        /**
         * 支店郵便番号
         */
        dto3.setZipCode("123-456");

        /**
         * 店舗住所
         */
        dto3.setBranchKanjiAddress("東京都五反田123-456");

        /**
         * 電話番号
         */
        dto3.setPhoneNumber("18842617777");

        /**
         * 緯度
         */
        dto3.setLatitude("38.4");

        /**
         * 経度
         */
        dto3.setLongitude("40.6");

        /**
         * 表示グループ名
         */
        dto3.setDisplayGroupName("品川区");

        /**
         * 店舗案内
         */
        dto3.setBranchGuide("店舗");

        /**
         * 表示グループ名
         */
        dto3.setDisplayGroupName("東京都");

        /**
         * 表示順
         */
        dto3.setDisplayOrder("1");
        
        
        BranchStoreDto dto4 = new BranchStoreDto();

        /**
         * 金融機関コード
         */
        dto4.setBankCode("12458");

        /**
         * 店番
         */
        dto4.setBranchNumber("01101");

        /**
         * 店名（漢字）
         */
        dto4.setBranchKanjiName("営業本部店01");

        /**
         * 所属部門区分
         */
        dto4.setDivisionType("1");

        /**
         * 照会店舗タイプ
         */
        dto4.setBranchInquiryType("2");

        /**
         * 支店郵便番号
         */
        dto4.setZipCode("123-456");

        /**
         * 店舗住所
         */
        dto4.setBranchKanjiAddress("東京都五反田123-456");

        /**
         * 電話番号
         */
        dto4.setPhoneNumber("18842617777");

        /**
         * 緯度
         */
        dto4.setLatitude("38.4");

        /**
         * 経度
         */
        dto4.setLongitude("40.6");

        /**
         * 表示グループ名
         */
        dto4.setDisplayGroupName("品川区");

        /**
         * 店舗案内
         */
        dto4.setBranchGuide("店舗");

        /**
         * 表示グループ名
         */
        dto4.setDisplayGroupName("東京都");

        /**
         * 表示順
         */
        dto4.setDisplayOrder("1");

        BranchStoreDto dto5 = new BranchStoreDto();

        /**
         * 金融機関コード
         */
        dto5.setBankCode("12458");

        /**
         * 店番
         */
        dto5.setBranchNumber("01101");

        /**
         * 店名（漢字）
         */
        dto5.setBranchKanjiName("営業本部店02");

        /**
         * 所属部門区分
         */
        dto5.setDivisionType("1");

        /**
         * 照会店舗タイプ
         */
        dto5.setBranchInquiryType("2");

        /**
         * 支店郵便番号
         */
        dto5.setZipCode("123-456");

        /**
         * 店舗住所
         */
        dto5.setBranchKanjiAddress("東京都五反田123-456");

        /**
         * 電話番号
         */
        dto5.setPhoneNumber("18842617777");

        /**
         * 緯度
         */
        dto5.setLatitude("38.4");

        /**
         * 経度
         */
        dto5.setLongitude("40.6");

        /**
         * 表示グループ名
         */
        dto5.setDisplayGroupName("品川区");

        /**
         * 店舗案内
         */
        dto5.setBranchGuide("店舗");

        /**
         * 表示グループ名
         */
        dto5.setDisplayGroupName("東京都");

        /**
         * 表示順
         */
        dto5.setDisplayOrder("1");

        BranchStoreDto dto6 = new BranchStoreDto();

        /**
         * 金融機関コード
         */
        dto6.setBankCode("12458");

        /**
         * 店番
         */
        dto6.setBranchNumber("01101");

        /**
         * 店名（漢字）
         */
        dto6.setBranchKanjiName("営業本部店03");

        /**
         * 所属部門区分
         */
        dto6.setDivisionType("1");

        /**
         * 照会店舗タイプ
         */
        dto6.setBranchInquiryType("2");

        /**
         * 支店郵便番号
         */
        dto6.setZipCode("123-456");

        /**
         * 店舗住所
         */
        dto6.setBranchKanjiAddress("東京都五反田123-456");

        /**
         * 電話番号
         */
        dto6.setPhoneNumber("18842617777");

        /**
         * 緯度
         */
        dto6.setLatitude("38.4");

        /**
         * 経度
         */
        dto6.setLongitude("40.6");

        /**
         * 表示グループ名
         */
        dto6.setDisplayGroupName("品川区");

        /**
         * 店舗案内
         */
        dto6.setBranchGuide("店舗");

        /**
         * 表示グループ名
         */
        dto6.setDisplayGroupName("東京都");

        /**
         * 表示順
         */
        dto6.setDisplayOrder("1");
        
        
        
        BranchStoreDto dto7 = new BranchStoreDto();

        /**
         * 金融機関コード
         */
        dto7.setBankCode("12458");

        /**
         * 店番
         */
        dto7.setBranchNumber("01101");

        /**
         * 店名（漢字）
         */
        dto7.setBranchKanjiName("営業本部店01");

        /**
         * 所属部門区分
         */
        dto7.setDivisionType("1");

        /**
         * 照会店舗タイプ
         */
        dto7.setBranchInquiryType("2");

        /**
         * 支店郵便番号
         */
        dto7.setZipCode("123-456");

        /**
         * 店舗住所
         */
        dto7.setBranchKanjiAddress("東京都五反田123-456");

        /**
         * 電話番号
         */
        dto7.setPhoneNumber("18842617777");

        /**
         * 緯度
         */
        dto7.setLatitude("38.4");

        /**
         * 経度
         */
        dto7.setLongitude("40.6");

        /**
         * 表示グループ名
         */
        dto7.setDisplayGroupName("品川区");

        /**
         * 店舗案内
         */
        dto7.setBranchGuide("店舗");

        /**
         * 表示グループ名
         */
        dto7.setDisplayGroupName("東京都");

        /**
         * 表示順
         */
        dto7.setDisplayOrder("1");

        BranchStoreDto dto8 = new BranchStoreDto();

        /**
         * 金融機関コード
         */
        dto8.setBankCode("12458");

        /**
         * 店番
         */
        dto8.setBranchNumber("01101");

        /**
         * 店名（漢字）
         */
        dto8.setBranchKanjiName("営業本部店02");

        /**
         * 所属部門区分
         */
        dto8.setDivisionType("1");

        /**
         * 照会店舗タイプ
         */
        dto8.setBranchInquiryType("2");

        /**
         * 支店郵便番号
         */
        dto8.setZipCode("123-456");

        /**
         * 店舗住所
         */
        dto8.setBranchKanjiAddress("東京都五反田123-456");

        /**
         * 電話番号
         */
        dto8.setPhoneNumber("18842617777");

        /**
         * 緯度
         */
        dto8.setLatitude("38.4");

        /**
         * 経度
         */
        dto8.setLongitude("40.6");

        /**
         * 表示グループ名
         */
        dto8.setDisplayGroupName("品川区");

        /**
         * 店舗案内
         */
        dto8.setBranchGuide("店舗");

        /**
         * 表示グループ名
         */
        dto8.setDisplayGroupName("東京都");

        /**
         * 表示順
         */
        dto8.setDisplayOrder("1");

        BranchStoreDto dto9 = new BranchStoreDto();

        /**
         * 金融機関コード
         */
        dto9.setBankCode("12458");

        /**
         * 店番
         */
        dto9.setBranchNumber("01101");

        /**
         * 店名（漢字）
         */
        dto9.setBranchKanjiName("営業本部店03");

        /**
         * 所属部門区分
         */
        dto9.setDivisionType("1");

        /**
         * 照会店舗タイプ
         */
        dto9.setBranchInquiryType("2");

        /**
         * 支店郵便番号
         */
        dto9.setZipCode("123-456");

        /**
         * 店舗住所
         */
        dto9.setBranchKanjiAddress("東京都五反田123-456");

        /**
         * 電話番号
         */
        dto9.setPhoneNumber("18842617777");

        /**
         * 緯度
         */
        dto9.setLatitude("38.4");

        /**
         * 経度
         */
        dto9.setLongitude("40.6");

        /**
         * 表示グループ名
         */
        dto9.setDisplayGroupName("品川区");

        /**
         * 店舗案内
         */
        dto9.setBranchGuide("店舗");

        /**
         * 表示グループ名
         */
        dto9.setDisplayGroupName("東京都");

        /**
         * 表示順
         */
        dto9.setDisplayOrder("1");
        
        
        BranchStoreDto dto10 = new BranchStoreDto();

        /**
         * 金融機関コード
         */
        dto10.setBankCode("12458");

        /**
         * 店番
         */
        dto10.setBranchNumber("01101");

        /**
         * 店名（漢字）
         */
        dto10.setBranchKanjiName("営業本部店01");

        /**
         * 所属部門区分
         */
        dto10.setDivisionType("1");

        /**
         * 照会店舗タイプ
         */
        dto10.setBranchInquiryType("2");

        /**
         * 支店郵便番号
         */
        dto10.setZipCode("123-456");

        /**
         * 店舗住所
         */
        dto10.setBranchKanjiAddress("東京都五反田123-456");

        /**
         * 電話番号
         */
        dto10.setPhoneNumber("18842617777");

        /**
         * 緯度
         */
        dto10.setLatitude("38.4");

        /**
         * 経度
         */
        dto10.setLongitude("40.6");

        /**
         * 表示グループ名
         */
        dto10.setDisplayGroupName("品川区");

        /**
         * 店舗案内
         */
        dto10.setBranchGuide("店舗");

        /**
         * 表示グループ名
         */
        dto10.setDisplayGroupName("東京都");

        /**
         * 表示順
         */
        dto10.setDisplayOrder("1");

        BranchStoreDto dto11 = new BranchStoreDto();

        /**
         * 金融機関コード
         */
        dto11.setBankCode("12458");

        /**
         * 店番
         */
        dto11.setBranchNumber("01101");

        /**
         * 店名（漢字）
         */
        dto11.setBranchKanjiName("営業本部店02");

        /**
         * 所属部門区分
         */
        dto11.setDivisionType("1");

        /**
         * 照会店舗タイプ
         */
        dto11.setBranchInquiryType("2");

        /**
         * 支店郵便番号
         */
        dto11.setZipCode("123-456");

        /**
         * 店舗住所
         */
        dto11.setBranchKanjiAddress("東京都五反田123-456");

        /**
         * 電話番号
         */
        dto11.setPhoneNumber("18842617777");

        /**
         * 緯度
         */
        dto11.setLatitude("38.4");

        /**
         * 経度
         */
        dto11.setLongitude("40.6");

        /**
         * 表示グループ名
         */
        dto11.setDisplayGroupName("品川区");

        /**
         * 店舗案内
         */
        dto11.setBranchGuide("店舗");

        /**
         * 表示グループ名
         */
        dto11.setDisplayGroupName("東京都");

        /**
         * 表示順
         */
        dto11.setDisplayOrder("1");

        BranchStoreDto dto12 = new BranchStoreDto();

        /**
         * 金融機関コード
         */
        dto12.setBankCode("12458");

        /**
         * 店番
         */
        dto12.setBranchNumber("01101");

        /**
         * 店名（漢字）
         */
        dto12.setBranchKanjiName("営業本部店03");

        /**
         * 所属部門区分
         */
        dto12.setDivisionType("1");

        /**
         * 照会店舗タイプ
         */
        dto12.setBranchInquiryType("2");

        /**
         * 支店郵便番号
         */
        dto12.setZipCode("123-456");

        /**
         * 店舗住所
         */
        dto12.setBranchKanjiAddress("東京都五反田123-456");

        /**
         * 電話番号
         */
        dto12.setPhoneNumber("18842617777");

        /**
         * 緯度
         */
        dto12.setLatitude("38.4");

        /**
         * 経度
         */
        dto12.setLongitude("40.6");

        /**
         * 表示グループ名
         */
        dto12.setDisplayGroupName("品川区");

        /**
         * 店舗案内
         */
        dto12.setBranchGuide("店舗");

        /**
         * 表示グループ名
         */
        dto12.setDisplayGroupName("東京都");

        /**
         * 表示順
         */
        dto12.setDisplayOrder("1");
        
        
        
        BranchStoreDto dto13 = new BranchStoreDto();

        /**
         * 金融機関コード
         */
        dto13.setBankCode("12458");

        /**
         * 店番
         */
        dto13.setBranchNumber("01101");

        /**
         * 店名（漢字）
         */
        dto13.setBranchKanjiName("営業本部店01");

        /**
         * 所属部門区分
         */
        dto13.setDivisionType("1");

        /**
         * 照会店舗タイプ
         */
        dto13.setBranchInquiryType("2");

        /**
         * 支店郵便番号
         */
        dto13.setZipCode("123-456");

        /**
         * 店舗住所
         */
        dto13.setBranchKanjiAddress("東京都五反田123-456");

        /**
         * 電話番号
         */
        dto13.setPhoneNumber("18842617777");

        /**
         * 緯度
         */
        dto13.setLatitude("38.4");

        /**
         * 経度
         */
        dto13.setLongitude("40.6");

        /**
         * 表示グループ名
         */
        dto13.setDisplayGroupName("品川区");

        /**
         * 店舗案内
         */
        dto13.setBranchGuide("店舗");

        /**
         * 表示グループ名
         */
        dto13.setDisplayGroupName("東京都");

        /**
         * 表示順
         */
        dto13.setDisplayOrder("1");

        BranchStoreDto dto14 = new BranchStoreDto();

        /**
         * 金融機関コード
         */
        dto14.setBankCode("12458");

        /**
         * 店番
         */
        dto14.setBranchNumber("01101");

        /**
         * 店名（漢字）
         */
        dto14.setBranchKanjiName("営業本部店02");

        /**
         * 所属部門区分
         */
        dto14.setDivisionType("1");

        /**
         * 照会店舗タイプ
         */
        dto14.setBranchInquiryType("2");

        /**
         * 支店郵便番号
         */
        dto14.setZipCode("123-456");

        /**
         * 店舗住所
         */
        dto14.setBranchKanjiAddress("東京都五反田123-456");

        /**
         * 電話番号
         */
        dto14.setPhoneNumber("18842617777");

        /**
         * 緯度
         */
        dto14.setLatitude("38.4");

        /**
         * 経度
         */
        dto14.setLongitude("40.6");

        /**
         * 表示グループ名
         */
        dto14.setDisplayGroupName("品川区");

        /**
         * 店舗案内
         */
        dto14.setBranchGuide("店舗");

        /**
         * 表示グループ名
         */
        dto14.setDisplayGroupName("東京都");

        /**
         * 表示順
         */
        dto14.setDisplayOrder("1");

        BranchStoreDto dto15 = new BranchStoreDto();

        /**
         * 金融機関コード
         */
        dto15.setBankCode("12458");

        /**
         * 店番
         */
        dto3.setBranchNumber("01101");

        /**
         * 店名（漢字）
         */
        dto15.setBranchKanjiName("営業本部店03");

        /**
         * 所属部門区分
         */
        dto15.setDivisionType("1");

        /**
         * 照会店舗タイプ
         */
        dto15.setBranchInquiryType("2");

        /**
         * 支店郵便番号
         */
        dto15.setZipCode("123-456");

        /**
         * 店舗住所
         */
        dto15.setBranchKanjiAddress("東京都五反田123-456");

        /**
         * 電話番号
         */
        dto15.setPhoneNumber("18842617777");

        /**
         * 緯度
         */
        dto15.setLatitude("38.4");

        /**
         * 経度
         */
        dto15.setLongitude("40.6");

        /**
         * 表示グループ名
         */
        dto15.setDisplayGroupName("品川区");

        /**
         * 店舗案内
         */
        dto15.setBranchGuide("店舗");

        /**
         * 表示グループ名
         */
        dto15.setDisplayGroupName("東京都");

        /**
         * 表示順
         */
        dto15.setDisplayOrder("1");
        
        BranchStoreDto dto16 = new BranchStoreDto();

        /**
         * 金融機関コード
         */
        dto16.setBankCode("12458");

        /**
         * 店番
         */
        dto16.setBranchNumber("01101");

        /**
         * 店名（漢字）
         */
        dto16.setBranchKanjiName("営業本部店01");

        /**
         * 所属部門区分
         */
        dto16.setDivisionType("1");

        /**
         * 照会店舗タイプ
         */
        dto16.setBranchInquiryType("2");

        /**
         * 支店郵便番号
         */
        dto16.setZipCode("123-456");

        /**
         * 店舗住所
         */
        dto16.setBranchKanjiAddress("東京都五反田123-456");

        /**
         * 電話番号
         */
        dto16.setPhoneNumber("18842617777");

        /**
         * 緯度
         */
        dto16.setLatitude("38.4");

        /**
         * 経度
         */
        dto16.setLongitude("40.6");

        /**
         * 表示グループ名
         */
        dto16.setDisplayGroupName("品川区");

        /**
         * 店舗案内
         */
        dto16.setBranchGuide("店舗");

        /**
         * 表示グループ名
         */
        dto16.setDisplayGroupName("東京都");

        /**
         * 表示順
         */
        dto16.setDisplayOrder("1");

        BranchStoreDto dto17 = new BranchStoreDto();

        /**
         * 金融機関コード
         */
        dto17.setBankCode("12458");

        /**
         * 店番
         */
        dto17.setBranchNumber("01101");

        /**
         * 店名（漢字）
         */
        dto17.setBranchKanjiName("営業本部店02");

        /**
         * 所属部門区分
         */
        dto17.setDivisionType("1");

        /**
         * 照会店舗タイプ
         */
        dto17.setBranchInquiryType("2");

        /**
         * 支店郵便番号
         */
        dto17.setZipCode("123-456");

        /**
         * 店舗住所
         */
        dto17.setBranchKanjiAddress("東京都五反田123-456");

        /**
         * 電話番号
         */
        dto17.setPhoneNumber("18842617777");

        /**
         * 緯度
         */
        dto17.setLatitude("38.4");

        /**
         * 経度
         */
        dto17.setLongitude("40.6");

        /**
         * 表示グループ名
         */
        dto17.setDisplayGroupName("品川区");

        /**
         * 店舗案内
         */
        dto17.setBranchGuide("店舗");

        /**
         * 表示グループ名
         */
        dto17.setDisplayGroupName("東京都");

        /**
         * 表示順
         */
        dto17.setDisplayOrder("1");

        BranchStoreDto dto18 = new BranchStoreDto();

        /**
         * 金融機関コード
         */
        dto18.setBankCode("12458");

        /**
         * 店番
         */
        dto18.setBranchNumber("01101");

        /**
         * 店名（漢字）
         */
        dto18.setBranchKanjiName("営業本部店03");

        /**
         * 所属部門区分
         */
        dto18.setDivisionType("1");

        /**
         * 照会店舗タイプ
         */
        dto18.setBranchInquiryType("2");

        /**
         * 支店郵便番号
         */
        dto18.setZipCode("123-456");

        /**
         * 店舗住所
         */
        dto18.setBranchKanjiAddress("東京都五反田123-456");

        /**
         * 電話番号
         */
        dto18.setPhoneNumber("18842617777");

        /**
         * 緯度
         */
        dto18.setLatitude("38.4");

        /**
         * 経度
         */
        dto18.setLongitude("40.6");

        /**
         * 表示グループ名
         */
        dto18.setDisplayGroupName("品川区");

        /**
         * 店舗案内
         */
        dto18.setBranchGuide("店舗");

        /**
         * 表示グループ名
         */
        dto18.setDisplayGroupName("東京都");

        /**
         * 表示順
         */
        dto18.setDisplayOrder("1");
        

        List<BranchStoreDto> branchList = new ArrayList<BranchStoreDto>();
        branchList.add(dto1);
        branchList.add(dto2);
        branchList.add(dto3);
        branchList.add(dto4);
        branchList.add(dto5);
        branchList.add(dto6);
        branchList.add(dto7);
        branchList.add(dto8);
        branchList.add(dto9);
        branchList.add(dto10);
        branchList.add(dto11);
        branchList.add(dto12);
        branchList.add(dto13);
        branchList.add(dto14);
        branchList.add(dto15);
        branchList.add(dto16);
        branchList.add(dto17);
        branchList.add(dto18);
        // 「メールアドレス登録」API呼出
        BranchStoreAbaResponseDto responseDto = new BranchStoreAbaResponseDto();
        responseDto.setBranchList(branchList);
        return responseDto;
    }
}

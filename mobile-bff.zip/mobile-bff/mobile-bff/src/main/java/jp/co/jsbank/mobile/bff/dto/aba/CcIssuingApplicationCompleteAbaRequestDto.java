package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * CC発行申込完了リクエストDTO
 */
@Data
public class CcIssuingApplicationCompleteAbaRequestDto {
	
	
	 /**
     * 受付番号
     */
    private String receptionNumber;
    
	 /**
     * 利用者ID
     */
    private String userId;
    
	 /**
     * 申込日
     */
    private String applicationDate;
    
	 /**
     * 画面ID
     */
    private String screenId;

 }




package jp.co.jsbank.mobile.bff.service.impl;

import java.util.Objects;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.jsbank.mobile.bff.common.RequestHeaderContext;
import jp.co.jsbank.mobile.bff.common.exception.NotFoundException;
import jp.co.jsbank.mobile.bff.common.redis.RedisHandler;
import jp.co.jsbank.mobile.bff.dto.AuthenticationKeyVerificationRequestDto;
import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import jp.co.jsbank.mobile.bff.dto.aba.AuthenticationKeyVerificationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.AuthenticationKeyVerificationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.UserAttributeInquiryAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.UserAttributeInquiryAbaResponseDto;
import jp.co.jsbank.mobile.bff.logic.LoginLogic;
import jp.co.jsbank.mobile.bff.service.LoginService;

/**
 * ログインサービス実装クラス
 */
@Service
public class LoginServiceImpl implements LoginService {

    @Resource
    private LoginLogic loginLogic;

    @Autowired
    private RedisHandler redisHandler;

    /**
     * ログイン認証
     *
     * @return ステータス
     */
    @Override
    public String loginAuthentication() {

        // 利用者IDトークン取得する
        String userIdToken = RequestHeaderContext.getInstance().getUserIdToken();

        if (!redisHandler.exists(userIdToken)) {
            // TODO エラー未定
            return null;
        }

        // 利用者ID取得する
        String userId = redisHandler.get(userIdToken);

        // 利用者属性照会ABAリクエストDTO
        UserAttributeInquiryAbaRequestDto userAbaRequestDto = new UserAttributeInquiryAbaRequestDto();
        // 利用者ID設定
        userAbaRequestDto.setUserId(userId);

        // エンドユーザーログインを呼び出す（API ID：AA0209）
        UserAttributeInquiryAbaResponseDto abaResponseDTO = loginLogic.userAttributeInquiry(userAbaRequestDto);

        // エラーチェックを行う
        errorCheck(abaResponseDTO.getCommonResponseHeader());

        // ステータス
        String status = "";
        if (Objects.nonNull(abaResponseDTO.getUserInfoList()) && abaResponseDTO.getUserInfoList().size() > 0) {

            status = abaResponseDTO.getUserInfoList().get(0).getStatus();
        }

        return status;
    }

    /**
     * 認証キー検証
     *
     * @param requestDto 認証キー検証リクエストDTO
     * @return 顧客ID
     */
    @Override
    public String authenticationKeyVerification(AuthenticationKeyVerificationRequestDto requestDto) {

        // 認証キー検証ABAリクエストDTO
        AuthenticationKeyVerificationAbaRequestDto abaRequestDto = new AuthenticationKeyVerificationAbaRequestDto();
        // 所属設定
        abaRequestDto.setDivisionCode(requestDto.getDivisionCode());
        // 利用者認証キー設定
        abaRequestDto.setUserAuthCode(requestDto.getUserAuthCode());
        // デバイスID設定
        abaRequestDto.setDeviceId(requestDto.getDeviceId());
        // 「認証キー検証」API呼出
        AuthenticationKeyVerificationAbaResponseDto abaResponseDTO = loginLogic
                .authenticationKeyVerification(abaRequestDto);

        // エラーチェックを行う
        errorCheck(abaResponseDTO.getCommonResponseHeader());

        return abaResponseDTO.getCustomerId();
    }

    /**
     * エラーチェック
     *
     * @param commonResponseHeader 共通レスポンスヘッダー
     */
    private void errorCheck(CommonResponseHeader commonResponseHeader) {

        if (Objects.nonNull(commonResponseHeader) && StringUtils.isNotEmpty(commonResponseHeader.getErrorCode())) {

            // TODO 異常コード待ち
            throw new NotFoundException();
        }
    }
}

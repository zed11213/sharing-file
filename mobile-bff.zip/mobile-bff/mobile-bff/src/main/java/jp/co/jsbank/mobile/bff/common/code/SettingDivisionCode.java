package jp.co.jsbank.mobile.bff.common.code;

/**
 * 設定区分コード
 */
public class SettingDivisionCode {

    /**
     * 区分なし
     */
    public static final String NO_DIVISION = "00";
    
    /**
     * キャンペーン
     */
    public static final String CAMPAIGN = "01";
    
    /**
     * 取引
     */
    public static final String TRANSACTION = "02";
}

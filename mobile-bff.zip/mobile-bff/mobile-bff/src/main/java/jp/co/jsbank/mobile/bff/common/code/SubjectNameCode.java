package jp.co.jsbank.mobile.bff.common.code;

/**
 * 科目コード
 */
public class SubjectNameCode {

    /**
     * 普通預金
     */
    public static final String SAVING_ACCOUNTS = "01";

    /**
     * 当座預金
     */
    public static final String CURRENT_ACCOUNT = "02";

    /**
     * 通知預金
     */
    public static final String NOTIFICATION_DEPOSIT = "03";

    /**
     * 別段預金
     */
    public static final String SEPARATE_DEPOSIT = "04";

    /**
     * 納税預金
     */
    public static final String TAX_PAYMENT_DEPOSIT = "05";

    /**
     * 定期預金
     */
    public static final String FIXED_TERM_DEPOSIT = "06";

    /**
     * 定期積金
     */
    public static final String FIXED_TERM_FIXED = "07";

    /**
     * 積立定期
     */
    public static final String ACCUMULATION_FIXED_TERM = "08";

    /**
     * 職員預り金
     */
    public static final String STAFF_DEPOSIT = "09";

    /**
     * 代金取引
     */
    public static final String CHARGE_TRADING = "10";

    /**
     * 割引手形
     */
    public static final String DISCOUNT_BILL = "11";

    /**
     * 手形貸付
     */
    public static final String BILL_LENDING = "12";

    /**
     * 証書貸付
     */
    public static final String DEED_LENDING = "13";

    /**
     * 代理貸付
     */
    public static final String PROXY_LENDING = "14";

    /**
     * 当座貸越
     */
    public static final String CURRENT_OVERDRAFT = "15";

    /**
     * 債務保証
     */
    public static final String DEBT_GUARANTEE = "16";

    /**
     * 内国為替
     */
    public static final String INTERNAL_EXCHANGE = "17";

    /**
     * 外国為替
     */
    public static final String FOREIGN_EXCHANGE = "18";

    /**
     * 金
     */
    public static final String GOLD = "19";

    /**
     * 債権
     */
    public static final String CREDIT = "20";

    /**
     * 外貨通知預金
     */
    public static final String FOREIGN_CURRENCY_NOTIFICATION_DEPOSIT = "21";

    /**
     * 外貨定期預金
     */
    public static final String FOREIGN_CURRENCY_TIME_DEPOSIT = "22";

    /**
     * 住宅金融公庫
     */
    public static final String RESIDENCE_FINANCIAL_CORPORATION = "23";

    /**
     * 出資金
     */
    public static final String INVESTMENTS = "26";

    /**
     * 両替商
     */
    public static final String EXCHANGE_QUOTIENT = "27";

    /**
     * シーアイエフ
     */
    public static final String CIF = "31";

    /**
     * 内部貯蓄預金
     */
    public static final String INTERNAL_SAVINGS_DEPOSIT = "33";

    /**
     * 信金ネット
     */
    public static final String BANK_NET = "35";

    /**
     * アンサー
     */
    public static final String ANSWER = "36";

    /**
     * 資金移動
     */
    public static final String FUND_TRANSFERS = "37";

    /**
     * ＣＡＦＩＳ提携
     */
    public static final String CAFIS_ALLIANCE = "38";

    /**
     * テレバンク
     */
    public static final String TELE_BANK = "39";

    /**
     * 預金共通
     */
    public static final String DEPOSIT_COMMON = "41";

    /**
     * 仮受仮払
     */
    public static final String SUSPENSE_RECEIPT_TEMPORARY_PAYMENT = "42";

    /**
     * 受入れ手数料
     */
    public static final String ACCEPTANCE_FEE = "43";

    /**
     * 経費
     */
    public static final String EXPENSE = "44";

    /**
     * 譲渡性預金
     */
    public static final String TRANSFERABILITY_DEPOSIT = "45";

    /**
     * 融資共通
     */
    public static final String LOAN_COMMON = "46";

    /**
     * 特約
     */
    public static final String SPECIAL_CONTRACT = "49";

    /**
     * 日計精査
     */
    public static final String DAILY_TOTAL_SCRUTINY = "54";

    /**
     * 業務共通
     */
    public static final String BUSINESS_COMMON = "55";

    /**
     * 担保
     */
    public static final String COLLATERAL = "56";

    /**
     * 重要用紙
     */
    public static final String IMPORTANT_PAPER = "60";

    /**
     * 外為オフコン
     */
    public static final String FOREIGN_EXCHANGE_OFFICE_COMPUTER = "61";

    /**
     * 自動送金
     */
    public static final String AUTOMATIC_REMITTANCE = "62";

    /**
     * 郵貯提携
     */
    public static final String JAPAN_POST_BANK_ALLIANCE = "63";

    /**
     * 投信窓販
     */
    public static final String INVESTMENT_TRUST_WINDOW_SALES = "64";

    /**
     * 宝くじ
     */
    public static final String LOTTERY = "65";

    /**
     * アイヒー
     */
    public static final String AIHEE = "66";

    /**
     * データ伝送
     */
    public static final String DATA_TRANSMISSION = "67";

    /**
     * ＡＴＭ振込
     */
    public static final String ATM_TRANSFER = "68";

    /**
     * 渉外支援
     */
    public static final String CONTACT_SUPPORT = "71";

    /**
     * 情報登録
     */
    public static final String INFORMATION_REGISTRATION = "72";

    /**
     * 情報検索
     */
    public static final String INFORMATION_SEARCH = "73";

    /**
     * 買入外国為替
     */
    public static final String PURCHASING_FX = "79";

    /**
     * 取立外国為替
     */
    public static final String COLLECTION_FX = "80";

    /**
     * 外為口債務保証
     */
    public static final String FOREIGN_EXCHANGE_GATE_DEBT_GUARANTEE = "81";

    /**
     * 外貨手形貸付
     */
    public static final String FOREIGN_CURRENCY_BILL_LENDING = "82";

    /**
     * 外貨証書貸付
     */
    public static final String FOREIGN_CURRENCY_DEED_LENDING = "83";

    /**
     * 端末特殊
     */
    public static final String TERMINAL_SPECIAL = "97";

    /**
     * 現金管理
     */
    public static final String CASH_MANAGEMENT = "98";

}

package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import jp.co.jsbank.mobile.bff.dto.ReceptionAnswerDataDto;
import lombok.Data;

/**
 * かんたん受付回答詳細照会ABAレスボスDTO
 */
@Data
public class EasyReceptionAnswerDetailInquiryAbaResponseDto {
	
	 /**
     * 共通レスポンス・ボディ
     */
    private CommonResponseHeader commonResponseHeader;
    
    /**
     * お知らせID
     */
    private String anncmntId;
    
    /**
     * かんたん受付回答DTOリスト
     */
    private List<ReceptionAnswerDataDto> responseList;
}

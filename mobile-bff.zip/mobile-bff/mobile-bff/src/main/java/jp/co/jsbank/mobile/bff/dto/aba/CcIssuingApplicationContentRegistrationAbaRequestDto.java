package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.IdentityDocumentsDto;
import lombok.Data;

/**
 * CC発行申込内容登録リクエストDTO
 */
@Data
public class CcIssuingApplicationContentRegistrationAbaRequestDto {
    
    /**
     * 申込ステータス
     */
    private String applyStatus;
    
    /**
     * キャッシュカード種類
     */
    private String cashCardType;
    
    /**
     * カナ氏名（姓）
     */
    private String customerLastName;
    
    /**
     * カナ氏名（名）
     */
    private String customerFirstName;
    
    /**
     * 漢字氏名（姓）
     */
    private String customerKanjiLastName;
    
    /**
     * 漢字氏名（名）
     */
    private String customerKanjiFirstName;
    
    /**
     * 生年月日
     */
    private String birthday;
    
    /**
     * 郵便番号
     */
    private String zipCode;
    
    /**
     * 職業
     */
    private String occupation;
    
	 /**
     * 職業（その他）
     */
    private String occupationOther;
    
    /**
     * 取引目的
     */
    private String transactPurpose;

    /**
     * 取引目的（その他）
     */
    private String transactPurposeOther;
    
    /**
     * 預金種目
     */
    private String accountType;
    
    /**
     * 店番
     */
    private String branchNumber;
    
    /**
     * 口座番号
     */
    private String accountNumber;
    
    /**
     * メールアドレス
     */
    private String emailAddress;
    
    /**
     * eKYC本人確認結果
     */
    private String ekycResult;
    
    /**
     * 画面ID
     */
    private String pageId;
    
    /**
     * CC暗証番号
     */
    private String ccPinCode;

    /**
     * 本人確認書類Dto
     */
    private List<IdentityDocumentsDto> identityDocumentsDtoList; 
    
 }

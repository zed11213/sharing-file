package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * 利用者情報ABAリクエストDTO
 */
@Data
public class StopTradingAbaRequestDto {

    /**
     * 利用者ID
     */
    private String userId;
    
    /**
     * 顧客ID
     */
    private String customerId;

}

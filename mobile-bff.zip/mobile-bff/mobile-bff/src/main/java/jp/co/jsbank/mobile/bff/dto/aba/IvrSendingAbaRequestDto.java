package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * IVR送信ABAリクエストDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class IvrSendingAbaRequestDto extends RequestBodyDto {

    /**
     * 受付番号
     */
    private String receiptNumber;
    
    /**
     * 利用者ID
     */
    private String userId;
    
    /**
     * 電話番号
     */
    private String phoneNumber;
}

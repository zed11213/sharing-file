package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * IVR認証スキップ情報照会ABAレスポンスDTO
 */
@Data
public class IvrAuthorizationSkipInfoInquiryAbaResponseDto {
	
	
	 /**
     * 共通レスポンス・ボディ
     */
    private CommonResponseHeader commonResponseHeader;
    
	 /**
     * CIF番号
     */
    private String cifNumber;
    
	 /**
     * 有効期間From
     */
    private String expireDateFrom;
    
	 /**
     * 有効期間To
     */
    private String expireDateTo;
    
	 /**
     * 使用済みフラグ
     */
    private String usedFlag;
    
	 /**
     * IVRスキップフラグ
     */
    private String ivrSkipFlag;
    
 }

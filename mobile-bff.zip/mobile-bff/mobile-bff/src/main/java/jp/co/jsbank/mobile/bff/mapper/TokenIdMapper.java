package jp.co.jsbank.mobile.bff.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;

import jp.co.jsbank.mobile.bff.entity.TokenIdEntity;

/**
 * トークンマッパー
 */
@Mapper
public interface TokenIdMapper {

    /**
     * トークンIDを検索する
     * 
     * @param tokenId トークンID
     * @return ID
     */
    String selectIdByToken(String tokenId);

    /**
     * トークンIDを追加する
     * 
     * @param tokenIdEntity トークンIDエンティティ
     */
    void insertIdAndToken(TokenIdEntity tokenIdEntity);
}

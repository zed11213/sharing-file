package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 通知設定情報ABAリクエストDTO
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class NotificationSettingAbaRequestDto  extends RequestBodyDto{

    /**
     * 利用者ID
     */
    private String userId;

    /**
     * 設定情報DTOリスト
     */
    private List<SettingInfoDto> settingInfos;
}

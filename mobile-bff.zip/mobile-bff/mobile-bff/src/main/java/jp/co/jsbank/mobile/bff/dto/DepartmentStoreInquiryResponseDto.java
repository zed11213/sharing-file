package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 部店照会レスボスDTO
 */
@Data
public class DepartmentStoreInquiryResponseDto {

    /**
     * 店番
     */
    private String branchNumber;

    /**
     * 店名（漢字）
     */
    private String branchKanjiName;
}

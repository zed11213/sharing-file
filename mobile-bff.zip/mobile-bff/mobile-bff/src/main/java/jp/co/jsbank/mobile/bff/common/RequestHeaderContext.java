package jp.co.jsbank.mobile.bff.common;

import lombok.Data;

/**
 * ヘッダーリクエスト
 */
@Data
public class RequestHeaderContext {

    private static final ThreadLocal<RequestHeaderContext> REQUEST_HEADER_CONTEXT_THREAD_LOCAL = new ThreadLocal<>();

    /**
     * 取引ID
     */
    private String transactionID;

    /**
     * アプリケーションID
     */
    private String applicationId;

    /**
     * 端末ID
     */
    private String deviceId;

    /**
     * 利用者IDトークン
     */
    private String userIdToken;

    /**
     * バンキングIDトークン
     */
    private String jbaIdToken;

    /**
     * アクセストークン
     */
    private String accessToken;

    /**
     * リフレッシュトークン
     */
    private String refreshToken;

    /**
     * バージョン
     */
    private String version;

    /**
     * OS
     */
    private String os;

    /**
     * 画面ID
     */
    private String screenId;
    
    /**
     * 共通鍵
     */
    private String commonKey;

    /**
     * イベントID
     */
    private String eventID;

    public static RequestHeaderContext getInstance() {
        return REQUEST_HEADER_CONTEXT_THREAD_LOCAL.get();
    }

    /**
     * 内容設定
     * 
     * @param context 内容
     */
    public void setContext(RequestHeaderContext context) {
        REQUEST_HEADER_CONTEXT_THREAD_LOCAL.set(context);
    }

    /**
     * リクエストヘッダー内容設定
     * 
     * @param requestHeaderContextBuild リクエストヘッダー内容
     */
    private RequestHeaderContext(RequestHeaderContextBuild requestHeaderContextBuild) {
        this.transactionID = requestHeaderContextBuild.transactionID;
        this.applicationId = requestHeaderContextBuild.applicationId;
        this.deviceId = requestHeaderContextBuild.deviceId;
        this.userIdToken = requestHeaderContextBuild.userIdToken;
        this.jbaIdToken = requestHeaderContextBuild.jbaIdToken;
        this.accessToken = requestHeaderContextBuild.accessToken;
        this.refreshToken = requestHeaderContextBuild.refreshToken;
        this.version = requestHeaderContextBuild.version;
        this.os = requestHeaderContextBuild.os;
        this.screenId = requestHeaderContextBuild.screenID;
        this.eventID = requestHeaderContextBuild.eventID;
        this.commonKey = requestHeaderContextBuild.commonKey;
        setContext(this);
    }
    /**
     * @author admin
     *
     */
    public static class RequestHeaderContextBuild {
        /**
         * 取引ID
         */
        private String transactionID;

        /**
         * アプリケーションID
         */
        private String applicationId;

        /**
         * 端末ID
         */
        private String deviceId;

        /**
         * 利用者IDトークン
         */
        private String userIdToken;

        /**
         * バンキングIDトークン
         */
        private String jbaIdToken;

        /**
         * アクセストークン
         */
        private String accessToken;

        /**
         * リフレッシュトークン
         */
        private String refreshToken;

        /**
         * バージョン
         */
        private String version;

        /**
         * OS
         */
        private String os;

        /**
         * 画面ID
         */
        private String screenID;

        /**
         * イベントID
         */
        private String eventID;
        
        /**
         * 共通鍵
         */
        private String commonKey;

        /**
         * 取引ID設定
         * 
         * @param transactionID 取引ID
         * @return 取引ID
         */
        public RequestHeaderContextBuild transactionID(String transactionID) {
            this.transactionID = transactionID;
            return this;
        }

        /**
         * アプリケーションID設定
         * 
         * @param applicationId アプリケーションID
         * @return アプリケーションID
         */
        public RequestHeaderContextBuild applicationId(String applicationId) {
            this.applicationId = applicationId;
            return this;
        }

        /**
         * 端末ID設定
         * 
         * @param deviceId 端末ID
         * @return 端末ID
         */
        public RequestHeaderContextBuild deviceId(String deviceId) {
            this.deviceId = deviceId;
            return this;
        }

        /**
         * ユーザーIDトークン設定
         * 
         * @param userIdToken ユーザーIDトークン
         * @return ユーザーIDトークン
         */
        public RequestHeaderContextBuild userIdToken(String userIdToken) {
            this.userIdToken = userIdToken;
            return this;
        }

        /**
         * JBAトークン設定
         * 
         * @param jbaIdToken JBAトークン
         * @return JBAトークン
         */
        public RequestHeaderContextBuild jbaIdToken(String jbaIdToken) {
            this.jbaIdToken = jbaIdToken;
            return this;
        }

        /**
         * アクセストークン設定
         * 
         * @param accessToken アクセストークン
         * @return アクセストークン
         */
        public RequestHeaderContextBuild accessToken(String accessToken) {
            this.accessToken = accessToken;
            return this;
        }

        /**
         * リフレッシュトークン設定
         * 
         * @param refreshToken リフレッシュトークン
         * @return リフレッシュトークン
         */
        public RequestHeaderContextBuild refreshToken(String refreshToken) {
            this.refreshToken = refreshToken;
            return this;
        }

        /**
         *  バージョン設定
         *  
         * @param version バージョン
         * @return バージョン
         */
        public RequestHeaderContextBuild version(String version) {
            this.version = version;
            return this;
        }

        /**
         * OS設定
         * 
         * @param os OS
         * @return OS
         */
        public RequestHeaderContextBuild os(String os) {
            this.os = os;
            return this;
        }

        /**
         * 画面ID設定
         * 
         * @param screenID 画面ID
         * @return 画面ID
         */
        public RequestHeaderContextBuild screenID(String screenID) {
            this.screenID = screenID;
            return this;
        }
        
        /**
         * 共通鍵設定
         * 
         * @param commonKey 共通鍵
         * @return 共通鍵
         */
        public RequestHeaderContextBuild commonKey(String commonKey) {
            this.commonKey = commonKey;
            return this;
        }

        /**
         *  イベントID設定
         *  
         * @param eventID イベントID
         * @return イベントID
         */
        public RequestHeaderContextBuild eventID(String eventID) {
            this.eventID = eventID;
            return this;
        }

        /**
         * リクエストヘッダー内容ビルド
         * 
         * @return リクエストヘッダー内容
         */
        public RequestHeaderContext bulid() {
            return new RequestHeaderContext(this);
        }
    }

}

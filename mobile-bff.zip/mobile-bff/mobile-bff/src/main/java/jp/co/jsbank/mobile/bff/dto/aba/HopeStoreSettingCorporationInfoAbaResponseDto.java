package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.AccountOpeningApplicationCorporationInfoDto;
import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 希望店設定（法人）ABAレスポンスDTO
 */
@Data
public class HopeStoreSettingCorporationInfoAbaResponseDto {

    /**
     * 共通レスポンス・ヘッダ
     */
    private CommonResponseHeader commonResponseHeader;

    /**
     * 受付番号
     * 
     */
    private String receiptNumber;
    
    /**
     * 希望部店
     */
    private String hopeDepartmentStore;
    
    /**
     * 人格区分
     */
    private String personType;
    
    /**
     * 画面ID
     */
    private String screenId;

    /**
     * 口座開設申込情報（法人）DTO
     */
    private AccountOpeningApplicationCorporationInfoDto corporation;

}

package jp.co.jsbank.mobile.bff.common;

/**
 * 定数クラス
 */
public class Constant {

    /**
     * JSON KEY: code
     */
    public static final String JSON_RESULT_CODE = "code";

    /**
     * JSON KEY: data
     */
    public static final String JSON_RESULT_DATA = "data";

    /**
     * ログ出力時のタイムスタンプ
     */
    public static final String CURRENT_TIMESTAMP = "yyyy-MM-dd HH:mm:ss.SSS z";

    /**
     * 固定ログメッセージテキスト: SYSTEM
     */
    public static final String SYSTEM = "SYSTEM";

    /**
     * 空の記号
     */
    public static final String EMPTY_SYMBOL = " ";

    /**
     * 金融機関コード固定値：城南信金： '1344'
     */
    public static final String FIXED_VALUE_FINANCIAL_CODE = "1344";

    /**
     * クライアントID固定値： 'jsbappclient01'
     */
    public static final String FIXED_VALUE_CLIENT_ID = "jsbappclient01";

    /**
     * 処理結果： OK
     */
    public static final String OK = "OK";

    /**
     * ""
     */
    public static final String EMPTY = "";
    
    /**
     * 公開フラグ
     */
    public static final String PUBLIC_FLG = "1";

    /**
     * GATEWAY_BASE_URL
     */
    public static final String GATEWAY_BASE_URL = "http://jag-api-gateway-service-ops-jag-gw.mycluster-jp-tok-1-430553-06f3cfc58a58986a2f2ce380e01e4d99-0000.jp-tok.containers.appdomain.cloud";
}

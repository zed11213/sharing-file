package jp.co.jsbank.mobile.bff.service;

import org.springframework.stereotype.Service;

import jp.co.jsbank.mobile.bff.dto.AccountOpeningApplicationIndividualInfoDto;
import jp.co.jsbank.mobile.bff.dto.AccountOpeningApplicationInfoDto;
import jp.co.jsbank.mobile.bff.dto.AccountOpeningApplicationRequstDto;
import jp.co.jsbank.mobile.bff.dto.AddressInfomationRequestDto;
import jp.co.jsbank.mobile.bff.dto.BizAddressInfomationRequestDto;
import jp.co.jsbank.mobile.bff.dto.BizHomeInfomationRequestDto;
import jp.co.jsbank.mobile.bff.dto.CustomerInformationEntryRequestDto;
import jp.co.jsbank.mobile.bff.dto.EmailAddressAuthorizationRequestDto;
import jp.co.jsbank.mobile.bff.dto.EmailAddressRegistrationRequestDto;
import jp.co.jsbank.mobile.bff.dto.HeadOfficeAddressInfomationRequestDto;
import jp.co.jsbank.mobile.bff.dto.HopeStoreSettingRequestDto;
import jp.co.jsbank.mobile.bff.dto.IbPasswordSettingRequestDto;
import jp.co.jsbank.mobile.bff.dto.IvrAuthenticationRequestDto;
import jp.co.jsbank.mobile.bff.dto.PostalCodeAutoSearchRequestDto;
import jp.co.jsbank.mobile.bff.dto.PostalCodeAutoSearchResponseDto;
import jp.co.jsbank.mobile.bff.dto.SalesAreaDepartmentStoreInquiryResponseDto;
import jp.co.jsbank.mobile.bff.dto.SignedUrlRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.IvrSendingRequestDto;

/**
 * 新規口座開設サービス
 */
@Service
public interface AccountOpeningService {

    /**
     * 復元処理
     *
     * @param receiptNumber 受付番号
     * @return 口座開設申込情報
     */
    AccountOpeningApplicationInfoDto restorationProcess(String receiptNumber);

    /**
     * 口座開設申込内容照会（個人）
     *
     * @param receiptNumber 受付番号
     * @param personType 人格区分
     * @return 口座開設申込内容照会（個人）情報
     */
    AccountOpeningApplicationIndividualInfoDto accountOpeningApplicationIndividualInfoInquiry(String receiptNumber,
            String personType);

    /**
     * お客様情報入力
     *
     * @param requestDto お客様情報入力リクエストDTO
     * @return 処理結果
     */
    String customerInformationRegistration(CustomerInformationEntryRequestDto requestDto);

    /**
     * ご職業などの入力
     *
     * @param requestDto 口座開設申込情報（個人）DTO
     * @return 処理結果
     */
    String occupationEtcEntry(AccountOpeningApplicationIndividualInfoDto requestDto);

    /**
     * お勤め先情報入力
     *
     * @param requestDto お客様情報入力リクエストDTO
     * @return 処理結果
     */
    String workInformationRegistration(AccountOpeningApplicationIndividualInfoDto requestDto);

    /**
     * 学校情報入力
     *
     * @param requestDto 学校情報入力リクエストDTO
     * @return 処理結果
     */
    String schoolInfomationEntry(AccountOpeningApplicationIndividualInfoDto requestDto);

    /**
     * 営業地区部店一覧照会
     *
     * @param zipCode 郵便番号
     * @return 営業地区部店一覧照会レスポンスDTO
     */
    SalesAreaDepartmentStoreInquiryResponseDto salesAreaDepartmentStoreInquiry(String zipCode);

    /**
     * 希望店設定
     *
     * @param requestDto 希望店設定リクエストDTO
     * @return 処理結果
     */
    String hopeStoreSetting(HopeStoreSettingRequestDto requestDto);

    /**
     * ICOSへ本人確認書類格納
     *
     * @param requestDto 署名付きURLリクエストDTO
     * @return 処理結果
     * @throws Exception
     */
    String putSignedUrl(SignedUrlRequestDto requestDto) throws Exception;

    /**
     * 郵便番号の自動検索
     *
     * @param requestDto 郵便番号の自動検索BFFリクエストDTO
     * @return 処理結果
     */
    PostalCodeAutoSearchResponseDto postalCodeAutoSearch(PostalCodeAutoSearchRequestDto requestDto);

    /**
     * IBパスワード設定
     *
     * @param requestDto IBパスワード設定リクエストDTO
     * 
     * @return 処理結果
     */
    String ibPasswordSetting(IbPasswordSettingRequestDto requestDto);

    /**
     * メールアドレス認証
     *
     * @param requestDto メールアドレス認証リクエストDTO
     * @return 処理結果
     */
    String emailAddressAuthorization(EmailAddressAuthorizationRequestDto requestDto);

    /**
     * メールアドレス登録
     *
     * @param requestDto メールアドレス登録リクエストDTO
     * @return 処理結果
     */
    String emailAddressRegistration(EmailAddressRegistrationRequestDto requestDto);

    /**
     * IVR送信
     *
     * @param requestDto IVR送信リクエストDTO
     * @return 処理結果
     */
    String ivrSending(IvrSendingRequestDto requestDto);

    /**
     * IVR認証
     *
     * @param requestDto IVR認証リクエストDTO
     * @return 処理結果
     */
    String ivrAuthentication(IvrAuthenticationRequestDto requestDto);

    /**
     * 所在地情報保存
     *
     * @param requestDto 所在地情報リクエストDTO
     * @return 処理結果
     */
    String saveAddressInfomation(AddressInfomationRequestDto requestDto);

    /**
     * 本店所在地情報保存
     *
     * @param requestDto 本店所在地情報リクエストDTO
     * @return 処理結果
     */
    String saveHeadOfficeAddressInformation(HeadOfficeAddressInfomationRequestDto requestDto);

    /**
     * biz自宅情報保存
     *
     * @param requestDto biz自宅情報リクエストDTO
     * @return 処理結果
     */
    String saveBizHomeInformation(BizHomeInfomationRequestDto requestDto);

    /**
     * biz所在地情報保存
     *
     * @param requestDto biz自宅情報リクエストDTO
     * @return 処理結果
     */
    String saveBizAddressInformation(BizAddressInfomationRequestDto requestDto);

	/**
	 * 申込完了
	 *
	 * @param requestDto 申込完了リクエストDTO
	 * @return 処理結果
	 */
	String accountOpeningApplicationInformation(AccountOpeningApplicationRequstDto requestDto);

	
}

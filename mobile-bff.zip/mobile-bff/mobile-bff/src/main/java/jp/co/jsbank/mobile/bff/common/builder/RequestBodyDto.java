package jp.co.jsbank.mobile.bff.common.builder;

import jp.co.jsbank.mobile.bff.dto.CommonRequestBodyOfHeaderDto;
import lombok.Data;

/**
 * リクエスト・ボディ
 */
@Data
public class RequestBodyDto {
    
    /**
     * 共通リクエスト・ヘッダ
     */
    private CommonRequestBodyOfHeaderDto commonRequestHeader;
}

package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 利用口座削除BFFリクエストDTO
 */
@Data
public class DeleteUseAccountRequestDto {

    /**
     * CIF番号
     */
    private String cifNumber;
}

package jp.co.jsbank.mobile.bff.common.icos;

import java.io.FileNotFoundException;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.ibm.cloud.objectstorage.ClientConfiguration;
import com.ibm.cloud.objectstorage.SDKGlobalConfiguration;
import com.ibm.cloud.objectstorage.auth.AWSCredentials;
import com.ibm.cloud.objectstorage.auth.AWSStaticCredentialsProvider;
import com.ibm.cloud.objectstorage.auth.BasicAWSCredentials;
import com.ibm.cloud.objectstorage.client.builder.AwsClientBuilder.EndpointConfiguration;
import com.ibm.cloud.objectstorage.services.s3.AmazonS3;
import com.ibm.cloud.objectstorage.services.s3.AmazonS3ClientBuilder;

/**
 * ICOS CONFIG クラス
 */
@Configuration
public class IcosConfigurationUtil {

    /** パブリックエンドポイント. */
    private static String gICOSPublicEndPoint = "s3.jp-tok.cloud-object-storage.appdomain.cloud";

    /**
     * ICOS接続を実施する.
     *
     * @return ICOS
     */
    @Bean
    public AmazonS3 connectIcos() throws FileNotFoundException {

        SDKGlobalConfiguration.IAM_ENDPOINT = "https://iam.cloud.ibm.com/identity/token";

        // APIKEY.
        // JAG-POC-BUCKET用のものを設定.
        String apiKey = "utJniL1TX2qazGQVw17PsCJ1Ywc_ya_fKsBojIwkMHy6";

        // Service Instance Id
        String serviceInstanceId = "crn:v1:bluemix:public:cloud-object-storage:global:a/790272cba2374bb39349d3201706b165:4545a477-605d-4f1b-b681-773134e8fe1c::";

        // エンドポイント
        String endpointUrl = gICOSPublicEndPoint;

        // ロケーション
        // IBM Cloudのプラットフォーム上は jp-tokなので、jp-tokとする.
        String location = "jp-tok";

        // COS Clientのインスタンスを生成する.
        AmazonS3 cosClient = createClient(apiKey, serviceInstanceId, endpointUrl, location);

        return cosClient;
    }

    /**
     * Create OAuth Credentials.
     * 
     * @param apiKey APIKEY
     * @param serviceInstanceId サービスインスタンスID
     * @param endpointUrl エンドポイント
     * @param location ロケーション
     * @return ICOSクライアント
     */
    public static AmazonS3 createClient(String apiKey, String serviceInstanceId, String endpointUrl, String location) {

        AWSCredentials credentials;

        // アクセスキー
        String accessKey = "bbd02271d59b4bf599c18546e7f0b75d";

        // シークレットキー
        String secretKey = "d149e79529735ff1c210425c8ee4cb444c3c9cfaa973fcb7";

        // 認証情報
        credentials = new BasicAWSCredentials(accessKey, secretKey);

        ClientConfiguration clientConfig = new ClientConfiguration().withRequestTimeout(5000);
        clientConfig.setUseTcpKeepAlive(true);

        AmazonS3 cosClient = AmazonS3ClientBuilder.standard()
                .withCredentials(new AWSStaticCredentialsProvider(credentials))
                .withEndpointConfiguration(new EndpointConfiguration(endpointUrl, location))
                .withPathStyleAccessEnabled(true).withClientConfiguration(clientConfig).build();

        return cosClient;
    }
}

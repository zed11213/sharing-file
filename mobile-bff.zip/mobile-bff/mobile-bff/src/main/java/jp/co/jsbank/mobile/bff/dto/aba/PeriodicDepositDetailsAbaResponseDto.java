package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 定期積金明細レスポンスDTO
 */
@Data
public class PeriodicDepositDetailsAbaResponseDto {

    /**
     * 共通レスポンスヘッダ
     */
    private CommonResponseHeader commonResponseHeader;

    /**
     * 定期積金明細DTO
     */
    private PeriodicDepositDetailsDto periodicDepositDetailsDto;
    
    /**
     * 領収印情報DTOリスト
     */
    private List<PaidOffDto> paidOffList;
}

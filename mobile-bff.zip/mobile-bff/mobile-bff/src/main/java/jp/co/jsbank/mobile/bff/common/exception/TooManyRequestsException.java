package jp.co.jsbank.mobile.bff.common.exception;

/**
 * データなし例外。
 *
 */
public class TooManyRequestsException extends BusinessException {

    private static final long serialVersionUID = -1L;

    /**
     * TooManyRequestsExceptionのコンスタント。
     * 
     * @param errorCode エラーコード
     */
    public TooManyRequestsException() {
        super("429");
    }
}

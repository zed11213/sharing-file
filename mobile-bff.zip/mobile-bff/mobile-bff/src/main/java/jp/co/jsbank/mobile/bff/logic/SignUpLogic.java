package jp.co.jsbank.mobile.bff.logic;

import org.springframework.stereotype.Service;

import jp.co.jsbank.mobile.bff.dto.JagBodyLinkAuthUserRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.AuthAccountInfoAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.AuthAccountInfoAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.AuthenticationKeyVerificationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.AuthenticationKeyVerificationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.BankBookLessPreferenceAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CifInfoInquiryAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CifInfoInquiryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CommonHeaderAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CustomerAttributeInquiryAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CustomerAttributeInquiryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CustomerInformationRegistrationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CustomerInformationRegistrationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.DepartmentStoreInquiryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.EmailAddressAuthorizationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.EmailAddressAuthorizationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.EmailAddressRegistrationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.EmailAddressRegistrationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.IvrAuthorizationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.IvrAuthorizationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.IvrAuthorizationSkipInfoInquiryAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.IvrAuthorizationSkipInfoInquiryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.IvrAuthorizationSkipInfoUpdateAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.IvrSendingAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.IvrSendingAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.UpdateUserAttributeAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.UserAttributeInquiryAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.UserAttributeInquiryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.UserAttributeRegistrationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.UserDataAbaRequestDto;

/**
 * 初回登録ロジック
 */
@Service
public interface SignUpLogic {

    /**
     * 部店照会リスト取得
     *
     * @return 部店照会リスト
     */
    DepartmentStoreInquiryAbaResponseDto departmentStoreInquiry();

    /**
     * 口座情報認証情報取得
     *
     * @param abaRequestDto 口座情報認証リクエストDTO
     * @return 口座情報認証ABAレスボスDTO
     */
    AuthAccountInfoAbaResponseDto authAccountInfo(AuthAccountInfoAbaRequestDto abaRequestDto);

    /**
     * 顧客情報登録
     *
     * @param abaRequestDto 顧客情報登録リクエストDTO
     * @return 共通レスポンス・ヘッダ
     */
    CustomerInformationRegistrationAbaResponseDto
            customerInformationRegistration(CustomerInformationRegistrationAbaRequestDto abaRequestDto);

    /**
     * 利用者属性更新
     *
     * @param abaRequestDto 利用者属性更新ABAリクエストDTO
     * @return 共通レスポンス・ヘッダ
     */
    CommonHeaderAbaResponseDto updateUserAttribute(UpdateUserAttributeAbaRequestDto abaRequestDto);

    /**
     * メールアドレス登録
     *
     * @param abaRequestDto メールアドレス登録ABAリクエストDTO
     * @return 処理結果
     */
    EmailAddressRegistrationAbaResponseDto
            emailAddressRegistration(EmailAddressRegistrationAbaRequestDto abaRequestDto);

    /**
     * IVR送信
     *
     * @param abaRequestDto IVR送信ABAリクエストDTO
     * @return IVR送信ABAレスポンスDTO
     */
    IvrSendingAbaResponseDto ivrSending(IvrSendingAbaRequestDto abaRequestDto);

    /**
     * IVR認証
     *
     * @param abaRequestDto IVR認証ABAリクエストDTO
     * @return IVR認証ABAレスポンスDTO
     */
    IvrAuthorizationAbaResponseDto ivrAuthorization(IvrAuthorizationAbaRequestDto abaRequestDto);

    /**
     * CIF情報照会
     *
     * @param abaRequestDto CIF情報照会ABAリクエストDTO
     * @return CIF情報照会ABAレスポンスDTO
     */
    CifInfoInquiryAbaResponseDto cifInfoInquiry(CifInfoInquiryAbaRequestDto abaRequestDto);

    /**
     * 通帳レス設定
     *
     * @param abaRequestDto 通帳レス設定ABAリクエストDTO
     * @return 共通レスポンス・ヘッダ
     */
    CommonHeaderAbaResponseDto bankBookLessPreference(BankBookLessPreferenceAbaRequestDto abaRequestDto);

    /**
     * メールアドレス認証
     * 
     * @param abaRequestDto メールアドレス認証ABAリクエストDTO
     * @return 認証済メールアドレスABAレスポンスDTO
     */
    EmailAddressAuthorizationAbaResponseDto
            emailAddressAuthorization(EmailAddressAuthorizationAbaRequestDto abaRequestDto);

    /**
     * IVR認証スキップ情報照会
     * 
     * @param abaRequestDto IVR認証スキップ情報照会ABAリクエストDTO
     * @return IVR認証スキップ情報照会ABAレスポンスDTO
     */
    IvrAuthorizationSkipInfoInquiryAbaResponseDto
            ivrAuthorizationSkipInfoInquiry(IvrAuthorizationSkipInfoInquiryAbaRequestDto abaRequestDto);

    /**
     * 顧客属性照会
     * 
     * @param abaRequestDto 顧客属性照会リクエストDTO
     * @return 顧客属性照会ABAレスポンスDTO
     */
    CustomerAttributeInquiryAbaResponseDto customerAttInquiry(CustomerAttributeInquiryAbaRequestDto abaRequestDto);

    /**
     * 認証キー検証
     *
     * @param attributeAbaRequestDto 認証キー検証ABAリクエストDTO
     * @return 認証キー検証ABAレスポンスDTO
     * 
     */
    AuthenticationKeyVerificationAbaResponseDto
            authenticationKeyVerification(AuthenticationKeyVerificationAbaRequestDto abaRequestDto);

    /**
     * 利用者属性登録
     *
     * @param abaRequestDto 利用者情報ABAレスボスDto
     * @return 利用者属性登録ABAレスボスDTO
     * 
     */
    UserAttributeRegistrationAbaResponseDto userAttributeRegistration(UserDataAbaRequestDto abaRequestDto);

    /**
     * 利用者属性照会
     *
     * @param abaRequestDto 利用者属性照会ABAリクエストDTO
     * @return 利用者属性照会ABAレスボスDTO
     * 
     */
    UserAttributeInquiryAbaResponseDto userAttributeInquiry(UserAttributeInquiryAbaRequestDto abaRequestDto);

    /**
     * IVR認証スキップ情報更新
     * 
     * @param abaRequestDto IVR認証スキップ情報更新ABAリクエストDTO
     * @return 共通レスポンス・ヘッダ
     */
    CommonHeaderAbaResponseDto
            ivrAuthorizationSkipInfoUpdate(IvrAuthorizationSkipInfoUpdateAbaRequestDto abaRequestDto);
    
    /**
     * ID端末とJBAIDの紐づけ
     * 
     * @param requestDto 端末とJBAIDの紐づけリクエストDTO
     */
    void linkingDeviceAndJbaId(JagBodyLinkAuthUserRequestDto requestDto);
}

package jp.co.jsbank.mobile.bff.controller;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jp.co.jsbank.mobile.bff.common.JsonResult;
import jp.co.jsbank.mobile.bff.dto.AccountOpeningApplicationIndividualInfoDto;
import jp.co.jsbank.mobile.bff.dto.AccountOpeningApplicationInfoDto;
import jp.co.jsbank.mobile.bff.dto.AccountOpeningApplicationRequstDto;
import jp.co.jsbank.mobile.bff.dto.AddressInfomationRequestDto;
import jp.co.jsbank.mobile.bff.dto.BizAddressInfomationRequestDto;
import jp.co.jsbank.mobile.bff.dto.BizHomeInfomationRequestDto;
import jp.co.jsbank.mobile.bff.dto.CustomerInformationEntryRequestDto;
import jp.co.jsbank.mobile.bff.dto.EmailAddressAuthorizationRequestDto;
import jp.co.jsbank.mobile.bff.dto.EmailAddressRegistrationRequestDto;
import jp.co.jsbank.mobile.bff.dto.HeadOfficeAddressInfomationRequestDto;
import jp.co.jsbank.mobile.bff.dto.HopeStoreSettingRequestDto;
import jp.co.jsbank.mobile.bff.dto.IbPasswordSettingRequestDto;
import jp.co.jsbank.mobile.bff.dto.IvrAuthenticationRequestDto;
import jp.co.jsbank.mobile.bff.dto.PostalCodeAutoSearchRequestDto;
import jp.co.jsbank.mobile.bff.dto.PostalCodeAutoSearchResponseDto;
import jp.co.jsbank.mobile.bff.dto.SalesAreaDepartmentStoreInquiryResponseDto;
import jp.co.jsbank.mobile.bff.dto.SignedUrlRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.IvrSendingRequestDto;
import jp.co.jsbank.mobile.bff.service.AccountOpeningService;

/**
 * 新規口座開設コントロール
 */
@RestController
public class AccountOpeningController {

	/**
	 * 新規口座開設サービス
	 */
	@Resource
	private AccountOpeningService accountOpeningService;

	// private Logger logger =
	// LoggerFactory.getLogger(ElectronicPassbookController.class);

	/**
	 * 復元処理
	 *
	 * @param receiptNumber 受付番号
	 * @return 口座開設申込情報
	 */
	@GetMapping(path = "/account-opening/AB0701")
	public JsonResult restorationProcess(@RequestParam String receiptNumber) {

		// 口座開設申込情報取得
		AccountOpeningApplicationInfoDto responseDto = accountOpeningService.restorationProcess(receiptNumber);

		return JsonResult.success(responseDto);
	}

	/**
	 * ICOSへ本人確認書類格納
	 *
	 * @param requestDto 署名付きURLリクエストDTO
	 * @return 処理結果
	 * @throws Exception 異常
	 */
	@PutMapping(path = "/account-opening/AB0702")
	public JsonResult putSignedUrl(@RequestBody SignedUrlRequestDto requestDto) throws Exception {

		// ICOSへ本人確認書類格納
		String result = accountOpeningService.putSignedUrl(requestDto);

		return JsonResult.success(result);
	}

	/**
	 * お勤め先情報入力
	 *
	 * @param requestDto お客様情報入力リクエストDTO
	 * @return 処理結果
	 */
	@PostMapping(path = "/account-opening/AB0703")
	public JsonResult workInformationRegistration(@RequestBody AccountOpeningApplicationIndividualInfoDto requestDto) {

		// お勤め先情報入力
		String result = accountOpeningService.workInformationRegistration(requestDto);

		return JsonResult.success(result);
	}

	/**
	 * 学校情報入力
	 *
	 * @param requestDto 学校情報入力リクエストDTO
	 * @return 処理結果
	 */
	@PostMapping(path = "/account-opening/AB0704")
	public JsonResult schoolInfomationEntry(@RequestBody AccountOpeningApplicationIndividualInfoDto requestDto) {

		// お勤め先情報入力
		String result = accountOpeningService.schoolInfomationEntry(requestDto);

		return JsonResult.success(result);
	}

	/**
	 * 口座開設申込内容照会（個人）
	 *
	 * @param receiptNumber 受付番号
	 * @param personType    人格区分
	 * @return 口座開設申込内容照会（個人）情報
	 */
	@GetMapping(path = "/account-opening/AB0705")
	public JsonResult accountOpeningApplicationIndividualInfoInquiry(@RequestParam String receiptNumber,
			@RequestParam String personType) {

		// 口座開設申込情報取得
		AccountOpeningApplicationIndividualInfoDto responseDto = accountOpeningService
				.accountOpeningApplicationIndividualInfoInquiry(receiptNumber, personType);

		return JsonResult.success(responseDto);
	}

	/**
	 * お客様情報入力
	 *
	 * @param requestDto お客様情報入力リクエストDTO
	 * @return 処理結果
	 */
	@PostMapping(path = "/account-opening/AB0706")
	public JsonResult customerInformationRegistration(@RequestBody CustomerInformationEntryRequestDto requestDto) {

		// お客様情報入力
		String result = accountOpeningService.customerInformationRegistration(requestDto);

		return JsonResult.success(result);
	}

	/**
	 * ご職業などの入力
	 *
	 * @param requestDto ご職業などの入力リクエストDTO
	 * @return 処理結果
	 */
	@PostMapping(path = "/account-opening/AB0707") 
	public JsonResult occupationEtcEntry(@RequestBody AccountOpeningApplicationIndividualInfoDto requestDto) {

		// お勤め先情報入力
		String result = accountOpeningService.occupationEtcEntry(requestDto);

		return JsonResult.success(result);
	}

	/**
	 * 営業地区部店一覧照会
	 *
	 * @param zipCode 郵便番号
	 * @return 部店リスト
	 */
	@GetMapping(path = "/account-opening/AB0708")
	public JsonResult salesAreaDepartmentStoreInquiry(@RequestParam String zipCode) {

		// 営業地区部店一覧照会
		SalesAreaDepartmentStoreInquiryResponseDto responseDto = accountOpeningService
				.salesAreaDepartmentStoreInquiry(zipCode);

		return JsonResult.success(responseDto);
	}

	/**
	 * 希望店設定
	 *
	 * @param requestDto 希望店設定BFFリクエストDTO
	 * @return 処理結果
	 */
	@PostMapping(path = "/account-opening/AB0709")
	public JsonResult hopeStoreSetting(@RequestBody HopeStoreSettingRequestDto requestDto) {

		// 希望店設定
		String result = accountOpeningService.hopeStoreSetting(requestDto);

		return JsonResult.success(result);
	}

	/**
	 * 郵便番号の自動検索
	 *
	 * @param requestDto 郵便番号の自動検索BFFリクエストDTO
	 * @return 処理結果
	 */
	@PostMapping(path = "/account-opening/AB0710")
	public JsonResult postalCodeAutoSearch(@RequestBody PostalCodeAutoSearchRequestDto requestDto) {

		// 郵便番号の自動検索
		PostalCodeAutoSearchResponseDto responseDto = accountOpeningService.postalCodeAutoSearch(requestDto);

		return JsonResult.success(responseDto);
	}

	/**
	 * IBパスワード設定
	 *
	 * @param requestDto IBパスワード設定リクエストDTO
	 * 
	 * @return CC暗証番号
	 */

	@PostMapping(path = "/account-opening/AB0711")
	public JsonResult ibPasswordSetting(@RequestBody IbPasswordSettingRequestDto requestDto) {

		String responseDto = accountOpeningService.ibPasswordSetting(requestDto);

		return JsonResult.success(responseDto);
	}

	/**
	 * メールアドレス登録
	 *
	 * @param requestDto メールアドレス登録リクエストDTO
	 * @return JsonResult
	 */
	@PostMapping(path = "/account-opening/AB0712")
	public JsonResult emailAddressRegistration(@RequestBody EmailAddressRegistrationRequestDto requestDto) {

		String result = accountOpeningService.emailAddressRegistration(requestDto);
		return JsonResult.success(result);
	}

	/**
	 * メールアドレス認証
	 *
	 * @param requestDto メールアドレス認証リクエストDTO
	 * @return JsonResult
	 */
	@PostMapping(path = "/account-opening/AB0713")
	public JsonResult emailAddressAuthorization(@RequestBody EmailAddressAuthorizationRequestDto requestDto) {

		String result = accountOpeningService.emailAddressAuthorization(requestDto);
		return JsonResult.success(result);
	}

	/**
	 * IVR送信
	 *
	 * @param requestDto IVR送信リクエストDTO
	 * @return JsonResult
	 */
	@PostMapping(path = "/account-opening/AB0714")
	public JsonResult ivrSending(@RequestBody IvrSendingRequestDto requestDto) {

		String result = accountOpeningService.ivrSending(requestDto);
		return JsonResult.success(result);
	}

	/**
	 * IVR認証
	 *
	 * @param requestDto IVR認証リクエストDTO
	 * @return JsonResult
	 */
	@PostMapping(path = "/account-opening/AB0715")
	public JsonResult ivrAuthentication(@RequestBody IvrAuthenticationRequestDto requestDto) {

		String result = accountOpeningService.ivrAuthentication(requestDto);
		return JsonResult.success(result);
	}

	/**
	 * 所在地情報保存
	 *
	 * @param requestDto 所在地情報リクエストDTO
	 * @return JsonResult
	 */
	@PostMapping(path = "/account-opening/AB0716")
	public JsonResult saveAddressInfomation(@RequestBody AddressInfomationRequestDto requestDto) {

		String receiptNumber = accountOpeningService.saveAddressInfomation(requestDto);
		return JsonResult.success(receiptNumber);
	}

	/**
	 * 本店所在地情報保存
	 *
	 * @param requestDto 本店所在地情報リクエストDTO
	 * @return JsonResult
	 */
	@PostMapping(path = "/account-opening/AB0717")
	public JsonResult saveHeadOfficeAddressInformation(@RequestBody HeadOfficeAddressInfomationRequestDto requestDto) {

		String result = accountOpeningService.saveHeadOfficeAddressInformation(requestDto);
		return JsonResult.success(result);
	}

	/**
	 * biz自宅情報保存
	 *
	 * @param requestDto biz自宅情報リクエストDTO
	 * @return JsonResult
	 */
	@PostMapping(path = "/account-opening/AB0718")
	public JsonResult saveBizHomeInformation(@RequestBody BizHomeInfomationRequestDto requestDto) {

		String receiptNumber = accountOpeningService.saveBizHomeInformation(requestDto);
		return JsonResult.success(receiptNumber);
	}

	/**
	 * biz所在地情報保存
	 *
	 * @param requestDto biz所在地情報リクエストDTO
	 * @return JsonResult
	 */
	@PostMapping(path = "/account-opening/AB0719")
	public JsonResult saveBizAddressInformation(@RequestBody BizAddressInfomationRequestDto requestDto) {

		String result = accountOpeningService.saveBizAddressInformation(requestDto);
		return JsonResult.success(result);
	}

	/**
	 * 申込完了
	 *
	 * @param requestDto 申込完了リクエストDTO
	 * @return JsonResult
	 */
	@PostMapping(path = "/account-opening/AB0720")
	public JsonResult accountOpeningApplicationInformation(@RequestBody AccountOpeningApplicationRequstDto requestDto) {

		String result = accountOpeningService.accountOpeningApplicationInformation(requestDto);
		return JsonResult.success(result);
	}
}

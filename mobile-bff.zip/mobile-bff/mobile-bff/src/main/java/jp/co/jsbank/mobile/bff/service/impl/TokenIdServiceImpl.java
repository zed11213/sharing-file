package jp.co.jsbank.mobile.bff.service.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import jp.co.jsbank.mobile.bff.entity.TokenIdEntity;
import jp.co.jsbank.mobile.bff.mapper.TokenIdMapper;
import jp.co.jsbank.mobile.bff.service.TokenIdService;

/**
 * トークンサービス
 */
@Service
public class TokenIdServiceImpl implements TokenIdService {

    @Resource
    private TokenIdMapper tokenIdMapper;

    /**
     * トークンIDを検索する
     * 
     * @return ID
     */
    public String selectIdByToken(String tokenId) {

        String id = tokenIdMapper.selectIdByToken(tokenId);

        return id;
    }

    /**
     * トークンIDを追加する
     * 
     * @param tokenIdEntity トークンIDエンティティ
     */
    @Override
    public void insertIdAndToken(TokenIdEntity tokenIdEntity) {

        tokenIdMapper.insertIdAndToken(tokenIdEntity);
    }
}

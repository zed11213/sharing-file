package jp.co.jsbank.mobile.bff.dto;

import java.util.List;

import lombok.Data;

/**
 * バージョンDTO
 */
@Data
public class VersionDto {

    /**
     * バージョン
     */
    private String anncmntVer;

    /**
     * タイトル
     */
    private String anncmntTitle;

    /**
     * 作成日時
     */
    private String createDateAndTime;

    /**
     * お知らせステータス
     */
    private String anncmntStatus;

    /**
     * 掲載開始日時
     */
    private String anncmntStartDateAndTime;

    /**
     * 掲載終了日時
     */
    private String anncmntEndDateAndTime;

    /**
     * メッセージ内容種別
     */
    private String mobileMsgType;

    /**
     * メッセージ宛先種別
     */
    private String indivisualFlg;

    /**
     * Push通知有無フラグ
     */
    private String pushNotifyFlg;

    /**
     * Push通知本文
     */
    private String pushNotifyMsg;

    /**
     * Push通知送信日時
     */
    private String pushNotifyDateAndTime;

    /**
     * PUSH通知送信先OS
     */
    private String destinationOs;

    /**
     * 同意チェックボックス有無
     */
    private String acceptanceChkFlg;

    /**
     * モバイルメッセージ本文
     */
    private String mobileMsg;

    /**
     * 画像有無フラグ
     */
    private String imgFlg;

    /**
     * 画像位置
     */
    private String imgVPosition;

    /**
     * 画像バケット名PUB
     */
    private String imgBucketPub;

    /**
     * 画像バケット名PVT
     */
    private String imgBucketPvt;

    /**
     * 画像ファイル名
     */
    private String imgFilename;

    /**
     * 画像ファイルリンク先有無
     */
    private String imgFileLinkFlg;

    /**
     * 画像ファイルリンク先URL
     */
    private String imgFileLinkUrl;

    /**
     * 送信先顧客IDリスト
     */
    private List<String> destinationCustIdList;

    /**
     * 送信先支店番号リスト
     */
    private List<String> destinationBranchNumList;

    /**
     * 承認依頼者支店番号
     */
    private String requesterBranch;

    /**
     * 承認依頼者部門コード
     */
    private String requesterDept;

    /**
     * 差戻フラグ
     */
    private String passbackFlg;

    /**
     * 更新タイムスタンプ(排他用)
     */
    private String updateTs;
    
    /**
     * ボタンリンク先有無フラグ
     */
    private String btnLinkFlg;
    
    /**
     * ボタンリンク先URL
     */
    private String btnLinkUrl;
}

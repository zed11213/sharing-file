package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * CC発行申込情報レスポンスDTO
 */
@Data
public class CcIssuingApplicationInformationAbaResponseDto {
	
	
	 /**
     * 共通レスポンス・ボディ
     */
    private CommonResponseHeader commonResponseHeader;
    
    /**
     * CC発行申込情報DTOリスト
     */
    private CcIssuingApplicationInformationAbaDto CcIssuingApplicationInformationDto;
    
 }

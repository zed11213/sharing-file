package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 本店所在地情報リクエストDTO
 */
@Data
public class HeadOfficeAddressInfomationRequestDto {

    /**
     * 受付番号
     */
    private String receiptNumber;

    /**
     * 本店所在地郵便番号
     */
    private String headOfficeLocZipCode;

    /**
     * 本店所在地都道府県（カナ）
     */
    private String headOfficeLocStateKana;

    /**
     * 本店所在地都道府県
     */
    private String headOfficeLocState;

    /**
     * 本店所在地市区町村（カナ）
     */
    private String headOfficeLocCityKana;

    /**
     * 本店所在地市区町村
     */
    private String headOfficeLocCity;

    /**
     * 本店所在地丁目（カナ）
     */
    private String headOfficeLocStreetKana;

    /**
     * 本店所在地丁目
     */
    private String headOfficeLocStreet;

    /**
     * 本店所在地番地（カナ）
     */
    private String headOfficeLocAddressKana;

    /**
     * 本店所在地番地
     */
    private String headOfficeLocAddress;

    /**
     * 本店建物名・号室（カナ）
     */
    private String headOfficeLocBuildingKana;

    /**
     * 本店建物名・号室
     */
    private String headOfficeLocBuilding;

}

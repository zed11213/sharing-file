package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 認証キー発行情報レスポンスDTO
 */
@Data
public class AuthenticationKeyIssuanceResponseDto {
	
	 /**
     * 認証キー
     */
    private String authenticationKey;
    
	 /**
     * 有効期限
     */
    private String expiryDateTime;
    
 }

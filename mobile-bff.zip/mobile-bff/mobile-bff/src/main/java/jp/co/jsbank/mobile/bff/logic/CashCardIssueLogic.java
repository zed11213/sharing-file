package jp.co.jsbank.mobile.bff.logic;

import org.springframework.stereotype.Service;

import jp.co.jsbank.mobile.bff.dto.aba.AuthAccountInfoAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.AuthAccountInfoAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CcIssuingApplicationCompleteAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CcIssuingApplicationCompleteAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CcIssuingApplicationContentRegistrationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CcIssuingApplicationContentRegistrationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CcIssuingApplicationContentUpdateAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CcIssuingApplicationContentUpdateAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CcIssuingApplicationInformationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.ContractManagementOperationHistoryInquiryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.RecoveryProcessAbaRequestDto;

/**
 * キャッシュカード発行ロジック
 */
@Service
public interface CashCardIssueLogic {

	/**
	 * [CC発行申込内容登録]API呼出
	 *
	 * @param requestDto CC発行申込内容登録登録リクエストDTO
	 * 
	 * @return CC発行申込内容登録レスボスDTO
	 */
	CcIssuingApplicationContentRegistrationAbaResponseDto contractMmanagementOperationHistoryRegistration(
			CcIssuingApplicationContentRegistrationAbaRequestDto abaRequestDto);

	/**
	 * [CC発行申込内容更新]API呼出
	 *
	 * @param requestDto CC発行申込内容更新リクエストDTO
	 * 
	 * @return CC発行申込情報レスポンスDTO
	 */
	CcIssuingApplicationContentUpdateAbaResponseDto ccIssuingApplicationContentUpdate(
			CcIssuingApplicationContentUpdateAbaRequestDto ccIssuingApplicationContentUpdateAbaRequestDto);

	/**
	 * [CC発行申込完了]API呼出
	 *
	 * @param requestDto CC発行申込完了リクエストDTO
	 * 
	 * @return CC発行申込完了レスポンスDTO
	 */

	CcIssuingApplicationCompleteAbaResponseDto ccIssuingApplicationComplete(
			CcIssuingApplicationCompleteAbaRequestDto requestDto);

	/**
	 * [契約管理操作履歴照会]API呼出
	 *
	 * @param requestDto 復元処理リクエストDTO
	 * 
	 * @return 契約管理操作履歴照会ABAレスボスDTO
	 */
	ContractManagementOperationHistoryInquiryAbaResponseDto contractManagementOperationHistoryInquiry(
			RecoveryProcessAbaRequestDto abaRequestDto);

	/**
	 * [CC発行申込内容照会]API呼出
	 *
	 * @param requestDto 復元処理リクエストDTO
	 * @return CC発行申込内容照会ResponseDTO
	 */
	CcIssuingApplicationInformationAbaResponseDto ccIssuingApplicationInformation(
			RecoveryProcessAbaRequestDto abaRequestDto);

	/**
	 * 口座情報認証情報取得
	 *
	 * @param abaRequestDto 口座情報認証リクエストDTO
	 * @return 口座情報認証ABAレスボスDTO
	 */
	AuthAccountInfoAbaResponseDto authAccountInfo(AuthAccountInfoAbaRequestDto authAccountReDto);

}

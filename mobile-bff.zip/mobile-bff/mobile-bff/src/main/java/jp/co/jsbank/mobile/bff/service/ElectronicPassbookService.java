package jp.co.jsbank.mobile.bff.service;

import java.util.List;

import org.springframework.stereotype.Service;

import jp.co.jsbank.mobile.bff.dto.AccountAndBalanceInfoResponseDto;
import jp.co.jsbank.mobile.bff.dto.BalanceGraphResponseDto;
import jp.co.jsbank.mobile.bff.dto.LiquidityDepositDetailsResponseDto;
import jp.co.jsbank.mobile.bff.dto.LotteryStatusRequestDto;
import jp.co.jsbank.mobile.bff.dto.MemoRegistrationRequestDto;
import jp.co.jsbank.mobile.bff.dto.NotificationDepositDetailsResponseDto;
import jp.co.jsbank.mobile.bff.dto.PeriodicDepositDetailsResponseDto;
import jp.co.jsbank.mobile.bff.dto.TimeDepositDetailsResponseDto;

/**
 * 電子通帳サービス
 */
@Service
public interface ElectronicPassbookService {

	/**
	 * 口座一覧と各口座の残高情報取得
	 *
	 * @return 口座一覧と各口座の残高情報
	 */
	AccountAndBalanceInfoResponseDto getAccountListAndBalanceInformation();

	/**
	 * 入出金明細取得(流動性預金)
	 * 
	 * @Param String detailContinuationFlag 明細継続フラグ
	 * @Param String detailIdFrom 開始明細ID
	 * @Param String maxInquiryCount最大検索件数
	 * @Param accountType 預金種目
	 * @Param String branchNumber 店番
	 * @param accountNumber     口座番号
	 * @param dateOfInquiryFrom 照会開始年月日
	 * @param dateOfInquiryTo   照会終了年月日
	 * @return 入出金明細情報
	 */
	LiquidityDepositDetailsResponseDto getIiquidityDepositDetails(String detailContinuationFlag, String detailIdFrom,
			String maxInquiryCount, String accountType, String branchNumber, String accountNumber,
			String dateOfInquiryFrom, String dateOfInquiryTo);

	/**
	 * 定期預金明細取得
	 *
	 * @param accountNumber 口座番号
	 * @param branchNumber  店番
	 * @param cifNumber     CIF番号
	 * @return 定期預金明細情報
	 */
	List<TimeDepositDetailsResponseDto> getTimeDepositDetails(String accountNumber, String branchNumber,
			String cifNumber);

	/**
	 * 定期積金明細取得
	 *
	 * @param accountNumber 口座番号
	 * @param branchNumber  店番
	 * @param cifNumber     CIF番号
	 * @return 定期積金明細情報
	 */
	PeriodicDepositDetailsResponseDto getPeriodicDepositDetails(String accountNumber, String branchNumber,
			String cifNumber);

	/**
	 * 通知預金明細取得
	 *
	 * @param accountNumber 口座番号
	 * @param branchNumber  店番
	 * @param cifNumber     CIF番号
	 * @return 通知預金明細情報
	 */
	NotificationDepositDetailsResponseDto getNotificationDepositDetails(String accountNumber, String branchNumber,
			String cifNumber);

	/**
	 * 概要欄メモ登録
	 *
	 * @param requestDto 明細概要メモ登録リクエストDTO
	 * @return 処理結果
	 */
	String overviewFieldMemoRegistration(MemoRegistrationRequestDto requestDto);

	/**
	 * 収支グラフ表示値取得
	 *
     * @param accountNumber 口座番号
     * @param branchNumber  店番
	 * @return 収支情報
	 */
	List<BalanceGraphResponseDto> getBalanceGraphDisplayValue(String accountNumber, String branchNumber);

	/**
	 * 抽選状態更新
	 *
	 * @param requestDto 抽選状態BFFリクエストDTO
	 * @return 処理結果
	 */
	String lotteryStatusUpdate(LotteryStatusRequestDto requestDto);

}

package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 顧客属性照会ABAリクエストDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class CustomerAttributeInquiryAbaRequestDto extends RequestBodyDto {

    /**
     * 顧客ID
     */
    private String customerId;

    /**
     * CIF情報
     */
    private List<CifNumberDto> cifNoList;

    /**
     * 人格区分
     */
    private String personCode;

    /**
     * 店番
     */
    private String branchCode;

    /**
     * 口座番号
     */
    private String accountNumber;

    /**
     * カナ氏名
     */
    private String customerName;

    /**
     * 性別
     */
    private String gender;

    /**
     * 郵便番号
     */
    private String zipNo;

    /**
     * 住所
     */
    private String address;

    /**
     * 生（設立）年月日（開始範囲）
     */
    private String startBirthday;

    /**
     * 生（設立）年月日（終了範囲）
     */
    private String endBirthday;

    /**
     * ステータス
     */
    private String status;

    /**
     * 預金種目
     */
    private String accountType;

    /**
     * 通帳レスフラグ
     */
    private String lessFlg;
}

package jp.co.jsbank.mobile.bff.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.jsbank.mobile.bff.common.Constant;
import jp.co.jsbank.mobile.bff.common.RequestHeaderContext;
import jp.co.jsbank.mobile.bff.common.exception.NotFoundException;
import jp.co.jsbank.mobile.bff.common.redis.RedisHandler;
import jp.co.jsbank.mobile.bff.common.util.DecryptorHelper;
import jp.co.jsbank.mobile.bff.dto.CardDesignSelectionRequestDto;
import jp.co.jsbank.mobile.bff.dto.CcIssuingApplicationInformationResponseDto;
import jp.co.jsbank.mobile.bff.dto.CcIssuingRequestDto;
import jp.co.jsbank.mobile.bff.dto.CcPasswordIbPasswordSettingRequestDto;
import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import jp.co.jsbank.mobile.bff.dto.EmailAddressAuthorizationRequestDto;
import jp.co.jsbank.mobile.bff.dto.IdentificationRequestDto;
import jp.co.jsbank.mobile.bff.dto.IvrAuthenticationRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.AuthAccountInfoAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.AuthAccountInfoAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CcIssuingApplicationCompleteAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CcIssuingApplicationCompleteAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CcIssuingApplicationContentRegistrationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CcIssuingApplicationContentRegistrationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CcIssuingApplicationContentUpdateAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CcIssuingApplicationContentUpdateAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CcIssuingApplicationInformationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.ContractManagementOperationHistoryInquiryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.RecoveryProcessAbaRequestDto;
import jp.co.jsbank.mobile.bff.logic.CashCardIssueLogic;
import jp.co.jsbank.mobile.bff.service.CashCardIssueService;

/**
 * キャッシュカード発行サービス実装クラス
 */
@Service
public class CashCardIssueServiceImpl implements CashCardIssueService {

    @Resource
    private CashCardIssueLogic cashcardIssueLogic;

    @Autowired
    private RedisHandler redisHandler;

    /**
     * 復元処理
     *
     * @param receptionNumber 受付番号
     * @return CC発行申込情報レスポンスDTO
     * 
     */

    @Override
    public CcIssuingApplicationInformationResponseDto getRecoveryProcess(String receptionNumber) {

        try {
            // 復元処理リクエストDTO
            RecoveryProcessAbaRequestDto abaRequestDto = new RecoveryProcessAbaRequestDto();
            // 受付番号設定
            abaRequestDto.setReceptionNumber(receptionNumber);
            // 契約管理操作履歴照会ABAレスボスDTO
            ContractManagementOperationHistoryInquiryAbaResponseDto abaResponseDto = cashcardIssueLogic
                    .contractManagementOperationHistoryInquiry(abaRequestDto);

            // エラーチェック
            errorCheck(abaResponseDto.getCommonResponseHeader());

            // 画面ID
            String screenId = RequestHeaderContext.getInstance().getScreenId();
            // CC発行申込情報レスポンスDTO
            CcIssuingApplicationInformationAbaResponseDto ccIssuingApplicationInformationAbaResponseDto = cashcardIssueLogic
                    .ccIssuingApplicationInformation(abaRequestDto);

            // エラーチェック
            errorCheck(ccIssuingApplicationInformationAbaResponseDto.getCommonResponseHeader());

            // CC発行申込情報レスポンスDTO
            CcIssuingApplicationInformationResponseDto responseDto = new CcIssuingApplicationInformationResponseDto();

            // CC発行申込情報DTO設定
            responseDto.setCcIssuingApplicationInformationDto(
                    ccIssuingApplicationInformationAbaResponseDto.getCcIssuingApplicationInformationDto());

            // 画面ID設定
            responseDto.setScreenId(screenId);

            return responseDto;
        } catch (Exception e) {

            throw new NotFoundException();
        }
    }

    /**
     * CC暗証番号・IBパスワード設定処理
     *
     * @param requestDto CC暗証番号・IBパスワード設定BFFリクエストDTO
     * @return 処理結果
     * @throws Exception
     * 
     */
    @Override
    public String ccPasswordIbPasswordSetting(CcPasswordIbPasswordSettingRequestDto requestDto) throws Exception {
        // CC暗証番号
        String ccPassword = requestDto.getCcPassword();
        // 共通鍵取得
        String commonKey = RequestHeaderContext.getInstance().getCommonKey();
        // 暗号化処理{CC暗証番号}(AA????)
        ccPassword = DecryptorHelper.decrypt(ccPassword, commonKey);
        // 受付番号
        String receptionNumber = requestDto.getReceptionNumber();
        // 画面ID
        String screenId = RequestHeaderContext.getInstance().getScreenId();
        try {
            // CC発行申込内容更新リクエストDTO
            CcIssuingApplicationContentUpdateAbaRequestDto ccIssuingApplicationContentUpdateAbaRequestDto = new CcIssuingApplicationContentUpdateAbaRequestDto();
            // CC暗証番号設定
            ccIssuingApplicationContentUpdateAbaRequestDto.setCcPinCode(ccPassword);
            // 受付番号設定
            ccIssuingApplicationContentUpdateAbaRequestDto.setReceptionNumber(receptionNumber);
            // 画面ID
            ccIssuingApplicationContentUpdateAbaRequestDto.setPageId(screenId);

            // CC発行申込情報レスポンスDTO
            CcIssuingApplicationContentUpdateAbaResponseDto ccIssuingApplicationContentUpdateAbaResponseDto = cashcardIssueLogic
                    .ccIssuingApplicationContentUpdate(ccIssuingApplicationContentUpdateAbaRequestDto);
            // エラーチェック
            errorCheck(ccIssuingApplicationContentUpdateAbaResponseDto.getCommonResponseBody());
        } catch (Exception e) {

            throw new NotFoundException();
        }
        return Constant.OK;
    }

    /**
     * カードデザイン選択
     *
     * @param requestDto カードデザイン選択リクエストDTO
     * 
     * @return receptionNumber 受付番号
     */
    @Override
    public String cardDesignSelection(CardDesignSelectionRequestDto requestDto) {

        try {
            // デザインID
            String cashCardType = requestDto.getCashCardType();

            // 画面ID
            String screenId = RequestHeaderContext.getInstance().getScreenId();

            // CC発行申込内容登録リクエストDTO
            CcIssuingApplicationContentRegistrationAbaRequestDto abaRequestDto = new CcIssuingApplicationContentRegistrationAbaRequestDto();

            // キャッシュカード種類設定
            abaRequestDto.setCashCardType(cashCardType);
            // 画面ID設定
            abaRequestDto.setPageId(screenId);

            // CC発行申込内容登録リクエストDTO
            CcIssuingApplicationContentRegistrationAbaResponseDto abaResponseDto = cashcardIssueLogic
                    .contractMmanagementOperationHistoryRegistration(abaRequestDto);

            // エラーチェック
            errorCheck(abaResponseDto.getCommonResponseHeader());

            return abaResponseDto.getReceptionNumber();
        } catch (Exception e) {

            throw new NotFoundException();
        }
    }

    /**
     * CC発行依頼
     *
     * @param requestDto CC発行依頼リクエストDTO
     * 
     * @return receptionNumber 受付番号
     */
    @Override
    public String getCcIssuing(CcIssuingRequestDto requestDto) {
        try {
            // 利用者ID Token取得する
            String userIdToken = RequestHeaderContext.getInstance().getUserIdToken();

            // 利用者ID取得する
            String userId = redisHandler.get(userIdToken);

            // 受付番号
            String receptionNumber = requestDto.getReceptionNumber();
            // 申込日
            String applicationDate = requestDto.getApplicationDate();

            // CC発行申込完了リクエストDTO
            CcIssuingApplicationCompleteAbaRequestDto ccIssuingApplicationCompleteAbaRequestDto = new CcIssuingApplicationCompleteAbaRequestDto();

            // 受付番号
            ccIssuingApplicationCompleteAbaRequestDto.setReceptionNumber(receptionNumber);

            // 申込日
            ccIssuingApplicationCompleteAbaRequestDto.setApplicationDate(applicationDate);
            // 画面ID
            ccIssuingApplicationCompleteAbaRequestDto.setScreenId(RequestHeaderContext.getInstance().getScreenId());
            // 利用者ID
            ccIssuingApplicationCompleteAbaRequestDto.setUserId(userId);

            // CC発行申込完了ResponseDTO
            CcIssuingApplicationCompleteAbaResponseDto ccIssuingApplicationCompleteAbaResponseDto = cashcardIssueLogic
                    .ccIssuingApplicationComplete(ccIssuingApplicationCompleteAbaRequestDto);

            // エラーチェック
            errorCheck(ccIssuingApplicationCompleteAbaResponseDto.getCommonResponseBody());

            return receptionNumber;
        } catch (Exception e) {

            throw new NotFoundException();
        }
    }

    /**
     * 本人確認
     *
     * @param requestDto 本人確認リクエストDTO
     * @return 処理結果
     */
    @Override
    public String identityVerification(IdentificationRequestDto requestDto) {

        try {
            // 口座情報認証リクエストDTO
            AuthAccountInfoAbaRequestDto authAccountReDto = new AuthAccountInfoAbaRequestDto();
            // 店番設定
            authAccountReDto.setBranchNumber(requestDto.getBranchNumber());
            // 口座番号設定
            authAccountReDto.setAccountNumber(requestDto.getAccountNumber());
            // カナ氏名設定
            authAccountReDto.setCustomerFirstName(requestDto.getCustomerName());
            // 生年月日設定
            authAccountReDto.setBirthDay(requestDto.getBirthday());
            // 郵便番号設定
            authAccountReDto.setCcPinCode(requestDto.getCcPinCode());
            // CC暗証番号設定
            authAccountReDto.setZipCode(requestDto.getZipCode());

            // 「口座情報認証情報取得」API呼出
            AuthAccountInfoAbaResponseDto authAccountResponseDto = cashcardIssueLogic.authAccountInfo(authAccountReDto);

            // エラーチェック
            errorCheck(authAccountResponseDto.getCommonResponseHeader());

            // CC発行申込内容更新リクエストDTO
            CcIssuingApplicationContentUpdateAbaRequestDto ccIssuingApplicationContentUpdateAbaRequestDto = new CcIssuingApplicationContentUpdateAbaRequestDto();
            // CC暗証番号設定
            ccIssuingApplicationContentUpdateAbaRequestDto.setCcPinCode(requestDto.getCcPinCode());
            // 受付番号設定
            ccIssuingApplicationContentUpdateAbaRequestDto.setReceptionNumber(requestDto.getReceptionNumber());
            // 画面ID
            ccIssuingApplicationContentUpdateAbaRequestDto.setPageId(RequestHeaderContext.getInstance().getScreenId());

            // CC発行申込情報レスポンスDTO
            CcIssuingApplicationContentUpdateAbaResponseDto ccIssuingApplicationContentUpdateAbaResponseDto = cashcardIssueLogic
                    .ccIssuingApplicationContentUpdate(ccIssuingApplicationContentUpdateAbaRequestDto);
            // エラーチェック
            errorCheck(ccIssuingApplicationContentUpdateAbaResponseDto.getCommonResponseBody());

            return requestDto.getReceptionNumber();
        } catch (Exception e) {

            throw new NotFoundException();
        }
    }

    /**
     * メールアドレス認証
     *
     * @param requestDto メールアドレス認証リクエストDTO
     * @return 処理結果
     */
    @Override
    public List<String> emailAddressAuthorization(EmailAddressAuthorizationRequestDto requestDto) {
        // TODO
        // [メールアドレス認証]API呼出\n{受付番号,OTP}(AA0104)
        // 応答{認証済メールアドレス}

        // [利用者属性更新]API呼出{利用者ID,認証済メールアドレス}(AA????)
        // 応答{OK}

        // [契約管理操作履歴登録]API呼出{顧客ID,利用者ID,人格区分,画面ID...}(AA????)
        // 応答{OK}

        // [IVRスキップ認証情報照会]API呼出\n{CIF番号}(AA0104)
        // 応答{CIF番号,IVRスキップフラグ,有効期限日時from,有効期限日時to,使用済みフラグ}

        // [顧客情報照会]API呼出{CIF番号}(AA????)
        // 応答{顧客情報}

        // [IVRスキップ認証情報更新]API呼出\n{CIF番号}(AA0104)
        // 応答{処理結果=OK}

        // トークン無効化API{端末ID,アプリID}(AZ0921)
        // トークンテーブルを更新 {WHERE 端末ID+アプリID,状態=2(無効)}
        // OK
        // 応答{処理結果=OK}

        // 応答{電話番号}
        // TODO Dummyデータ
        List<String> phoneNuumberList = new ArrayList<>();
        phoneNuumberList.add("080-4328-0815");
        phoneNuumberList.add("080-4328-0816");
        return phoneNuumberList;
    }

    /**
     * 本人確認
     *
     * @param requestDto 本人確認リクエストDTO
     * @return 処理結果
     */
    @Override
    public String identityVerification(IvrAuthenticationRequestDto requestDto) {

        // TODO Dummyデータ
        return "OK";}
        
    /**
     * IVR認証
     *
     * @param requestDto IVR認証リクエストDTO
     * @return [確認ダイアログ]画面表示
     */
    @Override
    public String ivrAuthentication(IvrAuthenticationRequestDto requestDto) {

        // // 利用者ID Token取得する
        // String userIdToken = RequestHeaderContext.getInstance().getUserIdToken();
        //
        // if (!redisHandler.exists(userIdToken)) {
        // // TODO エラー未定
        // return null;
        // }
        //
        // // 利用者ID取得する
        // String userId = redisHandler.get(userIdToken);
        // // アプリケーションID
        // String applicationId = RequestHeaderContext.getInstance().getApplicationId();
        //
        // // IVR認証ABAリクエストDTO
        // IvrAuthorizationAbaRequestDto abaRequestDto = new
        // IvrAuthorizationAbaRequestDto();
        // // OTP設定
        // abaRequestDto.setOtp(requestDto.getOtp());
        // // 利用者ID設定
        // abaRequestDto.setUserId(userId);
        // // 認証TRXキー設定
        // abaRequestDto.setAuthenticationTrxKey(applicationId);
        //
        // // IVR認証
        // IvrAuthorizationAbaResponseDto authenticationResult =
        // signUpLogic.ivrAuthorization(abaRequestDto);
        //
        // // IVR認証失敗の場合
        // if (StringUtils.equals(AuthenticationResultCodeMst.AUTHENTICATION_FAILED,
        // authenticationResult.getAuthenticationResult())) {
        //
        // // TODO エラー待ち
        // }

        return "OK";
    }

    /**
     * エラーチェック
     *
     * @param commonResponseHeader 共通レスポンスerrorCheckヘッダー
     */
    private void errorCheck(CommonResponseHeader commonResponseHeader) {

        if (Objects.nonNull(commonResponseHeader) && StringUtils.isNotEmpty(commonResponseHeader.getErrorCode())) {

            // TODO 異常コード待ち
            throw new NotFoundException();
        }
    }
}

package jp.co.jsbank.mobile.bff.logic;

import org.springframework.stereotype.Service;

import jp.co.jsbank.mobile.bff.dto.aba.AccountInformationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.AccountInformationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.AccountRegistrationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.AuthenticationKeyIssuanceAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.BranchDetailDisplayAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.BranchDetailDisplayAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CifDepositBalanceAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CifDepositBalanceAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CifInfomationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CifInfomationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CommonHeaderAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CurrentAccountAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.DeleteUseAccountAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.DepositsAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.EmailAddAuthorizationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.EmailAddChangingAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.NotificationDepositBalanceInquiryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.NotificationSettingAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.NotificationSettingAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.PassbooklesSettingAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.RegularProvidentFundAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.SavingsAccountsAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.StopTradingAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.TaxReserveDepositAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.UpdateDesignInfomationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.UseAccountRegistrationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.UseAccountRegistrationConfirmationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.UserAttributeInquiryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.UserDataAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.UserElementUpdateAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.UserInformationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.UserSettingDetailsAbaResponseDto;

/**
 * 各種登録設定ロジック
 */
@Service
public interface VariousRegistrationPreferenceLogic {

    /**
     * 通知設定情報取得
     *
     * @param userId 利用者ID
     * @return 通知設定情報レスポンスDTO
     */
    NotificationSettingAbaResponseDto getNotificationSetting(String userId);

    /**
     * 通知設定情報変更
     *
     * @param abaRequestDto 通知設定ABAリクエストDTO
     * @return 共通レスポンスヘッダー
     */
    CommonHeaderAbaResponseDto changeNotificationSettingresultnfo(NotificationSettingAbaRequestDto abaRequestDto);

    /**
     * 利用口座削除
     *
     * @param abaRequestDto 通知設定ABAリクエストDTO
     * @return 処理結果
     */
    CommonHeaderAbaResponseDto deleteUseAccount(DeleteUseAccountAbaRequestDto abaRequestDto);

    /**
     * デザイン取得
     *
     * @param userId 利用者ID
     * @return 設定済みデザイン情報
     */
    UserAttributeInquiryAbaResponseDto getDesignInfomation(String userId);

    /**
     * メールアドレス変更
     *
     * @param abaRequestDto メールアドレス変更ABAリクエストDTO
     * @return 共通レスポンスヘッダー
     */
    CommonHeaderAbaResponseDto emailAddChangingAba(EmailAddChangingAbaRequestDto abaRequestDto);

    /**
     * メールアドレス認証
     *
     * @param abaRequestDto メールアドレス認証ABAリクエストDTO
     * @return 共通レスポンスヘッダー
     */
    CommonHeaderAbaResponseDto emailAddAuthorizationAba(EmailAddAuthorizationAbaRequestDto abaRequestDto);

    /**
     * 利用者属性更新
     *
     * @param abaRequestDto メールアドレス登録ABAリクエストDTO
     * @return 共通レスポンスヘッダー
     */
    CommonHeaderAbaResponseDto userElementUpdateAba(UserElementUpdateAbaRequestDto abaRequestDto);

    /**
     * 取引停止
     *
     * @param abaRequestDto 取引停止情報ABAリクエストDTO
     * @return 共通レスポンスヘッダー
     */
    CommonHeaderAbaResponseDto stopTrading(StopTradingAbaRequestDto abaRequestDto);

    /**
     * 利用者追加確認ステータス更新
     *
     * @param abaRequestDto 利用者情報ABAリクエストDTO
     * @return 共通レスポンスヘッダー
     */
    CommonHeaderAbaResponseDto userInformationAba(UserInformationAbaRequestDto abaRequestDto);

    /**
     * 認証キー発行
     *
     * @param abaRequestDto 利用者情報ABAレスボスDto
     * @return 認証キー発行AbaレスポンスDTO
     */
    AuthenticationKeyIssuanceAbaResponseDto authenticationKeyIssuanceAba(UserDataAbaRequestDto abaRequestDto);

    /**
     * デザイン更新
     *
     * @param abaRequestDto デザイン更新ABAリクエストDTO
     * @return 共通レスポンスヘッダー
     */
    CommonHeaderAbaResponseDto updateDesignInfomation(UpdateDesignInfomationAbaRequestDto abaRequestDto);

    /**
     * 法人利用者情報一覧取得
     *
     * @param jbaIdToken JBAID
     * @return 共通レスポンスヘッダー
     */
    UserSettingDetailsAbaResponseDto getJuridicalPersonUserDetails(String jbaIdToken);

    /**
     * CIF情報取得
     * 
     * @param cifInfomationRequestDto
     *
     * @return 処理結果
     */
    CifInfomationAbaResponseDto getCifInfomation(CifInfomationAbaRequestDto abaRequestDto);

    /**
     * 口座情報取得
     *
     * @param AccountInformationAbaRequestDto
     * @return 処理結果
     */
    AccountInformationAbaResponseDto getAccountInformation(AccountInformationAbaRequestDto requestDto);

    /**
     * 普通預金残高情報取得
     * 
     * @param UseAccountRegistrationConfirmationAbaRequestDto
     *
     * @return 処理結果
     */
    SavingsAccountsAbaResponseDto
            getSavingsAccountsInfomation(UseAccountRegistrationConfirmationAbaRequestDto abaRequestDto);

    /**
     * 定期預金残高情報取得
     * 
     * @param UseAccountRegistrationConfirmationAbaRequestDto
     *
     * @return 処理結果
     */
    DepositsAbaResponseDto getDepositsInfomation(UseAccountRegistrationConfirmationAbaRequestDto abaRequestDto);

    /**
     * 定期積金残高情報取得
     * 
     * @param UseAccountRegistrationConfirmationAbaRequestDto
     *
     * @return 処理結果
     */
    RegularProvidentFundAbaResponseDto
            getRegularProvidentFundInfomation(UseAccountRegistrationConfirmationAbaRequestDto abaRequestDto);

    /**
     * 納税準備預金残高情報取得
     * 
     * @param UseAccountRegistrationConfirmationAbaRequestDto
     *
     * @return 処理結果
     */
    TaxReserveDepositAbaResponseDto
            getTaxReserveDepositInfomation(UseAccountRegistrationConfirmationAbaRequestDto abaRequestDto);

    /**
     * 当座預金残高情報取得
     * 
     * @param UseAccountRegistrationConfirmationAbaRequestDto
     *
     * @return 処理結果
     */
    CurrentAccountAbaResponseDto
            getCurrentAccountInfomation(UseAccountRegistrationConfirmationAbaRequestDto abaRequestDto);

    /**
     * 通知預金残高情報取得
     * 
     * @param UseAccountRegistrationConfirmationAbaRequestDto
     *
     * @return 処理結果
     */
    NotificationDepositBalanceInquiryAbaResponseDto
            getNotificationDepositInfomation(UseAccountRegistrationConfirmationAbaRequestDto abaRequestDto);

    /**
     * CIF預金残高一覧情報取得
     * 
     * @param CifDepositBalanceAbaRequestDto
     *
     * @return 処理結果
     */
    CifDepositBalanceAbaResponseDto getCifDepositBalanceInfomation(CifDepositBalanceAbaRequestDto abaRequestDto);

    /**
     * 支店詳細情報取得
     * 
     * @param BranchDetailDisplayAbaRequestDto
     *
     * @return 処理結果
     */
    BranchDetailDisplayAbaResponseDto getBranchDetailDisplayInfomation(BranchDetailDisplayAbaRequestDto abaRequestDto );

    /**
     * 利用口座登録情報取得
     *
     * @param UseAccountRegistrationAbaRequestDto
     * @return 処理結果
     */
    AccountRegistrationAbaResponseDto getCifInformation(UseAccountRegistrationAbaRequestDto requestDto);

    /**
     * CIF情報取得
     *
     * @param requestDto CIF情報取得リクエストDTO
     * @return CIF情報取得レスポンスDTO
     */
    CifInfomationAbaResponseDto getGifInfomation(CifInfomationAbaRequestDto requestDto);

    /**
     * 通帳レス設定
     *
     * @param requestDto 通帳レス設定ABAリクエストDTO
     * @return 共通レスポンスヘッダー
     */
    CommonHeaderAbaResponseDto getPassbooklessSettingInformation(PassbooklesSettingAbaRequestDto requestDto);
}

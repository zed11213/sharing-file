package jp.co.jsbank.mobile.bff.common.logger;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import jp.co.jsbank.mobile.bff.common.RequestHeaderContext;
import jp.co.jsbank.mobile.bff.common.redis.RedisHandler;

/**
 * ログ出力クラス
 */
@Aspect
@Component
public class LoggingAspects {

    /**
     * ログ出力のためのクラス
     */
    private static final Logger LOGGER = LoggerFactory.getLogger(LoggingAspects.class);

    /**
     * Redis処理クラス
     */
    @Autowired
    private RedisHandler redisHandler;
    /**
     * 金融機関コード
     */
    private String bankCode = "1344";
    /**
     * アプリケーションID
     */
    private String applicationID = "jsbapp01";
    /**
     * クライアントID
     */
    private String clientID = "010000";
    /**
     * 端末識別するID
     */
    private String deviceMk = "sm";
    /**
     * フォーマット
     */
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS z");
    /**
     * 区切りの文字列
     */
    private String splitValue = " ";

    /**
     * Beforeアノテーションのより、指定したメソッドの前に開始ログを追加する。
     * 
     * @param joinPoint メソッドの情報
     */
    @Before("execution(* jp.co.jsbank.mobile.bff.controller..*(..))")
    public void controllerStartLog(JoinPoint joinPoint) {

        // String args = Arrays.toString(joinPoint.getArgs());

        StringBuffer sb = getLogMessage(joinPoint);
        // sb.append(args + splitValue);
        sb.append("開始");

        LOGGER.info(sb.toString());
    }

    /**
     * AfterReturningアノテーションのより、指定したメソッドの後に終了ログを追加する。
     * 
     * @param joinPoint メソッドの情報
     * @param returnOb メソッドの戻り値
     */
    @AfterReturning(returning = "returnOb", pointcut = "execution(* jp.co.jsbank.mobile.bff.controller..*(..))")
    public void doAfterReturning(JoinPoint joinPoint, Object returnOb) {

        // String args = String.valueOf(returnOb);

        StringBuffer sb = getLogMessage(joinPoint);
        // sb.append(args + splitValue);
        sb.append("終了");

        LOGGER.info(sb.toString());

    }

    /**
     * ログ本文作成
     * 
     * @param joinPoint メソッドの情報
     * @return ログ本文
     */
    private StringBuffer getLogMessage(JoinPoint joinPoint) {
        // ログ出力時のタイムスタンプ
        String currentTimestamp = "";
        // 取引ID
        String transactionID = "";
        // 取引通番
        String transactionSeqNo = "";
        // トレースID
        String traceID = "";
        // ユーザーID
        String userID = "";
        // 端末ID
        String deviceID = "";
        // スレッドID
        String threadID = "";
        // 出力箇所
        String invokerName = "";
        // メッセージID
        String messageID = "";
        // 重大度
        String severity = "";
        // コンテキスト・ルート名
        String contextRoot = "";
        // API識別子
        String apiID = "";
        // AIFログレベル
        String aifLogLvNum = "";
        // AIFロガー名
        // String aifLogType = "";
        // AIF追跡番号
        String aifTtracNo = "";
        // ログメッセージ本文
        String messageBody = "";
        // 画面ID
        String gcreenID = "";
        // イベントID
        String eventID = "";

        currentTimestamp = sdf.format(new Date());

        userID = RequestHeaderContext.getInstance().getUserIdToken();
        if (!redisHandler.exists(userID)) {
            userID = RequestHeaderContext.getInstance().getDeviceId();
        } else {
            userID = redisHandler.get(userID);
        }
        deviceID = deviceMk + RequestHeaderContext.getInstance().getDeviceId().replace("-", "").toLowerCase();
        invokerName = joinPoint.getSignature().getDeclaringTypeName() + "#" + joinPoint.getSignature().getName();

        gcreenID = RequestHeaderContext.getInstance().getScreenId();
        eventID = RequestHeaderContext.getInstance().getEventID();

        StringBuffer sb = new StringBuffer();
        sb.append(currentTimestamp + splitValue);
        sb.append(bankCode + splitValue);
        sb.append(userID + splitValue);
        sb.append(applicationID + splitValue);
        sb.append(clientID + splitValue);
        sb.append(deviceID + splitValue);
        sb.append(messageID + splitValue);
        sb.append(severity + splitValue);
        sb.append(contextRoot + splitValue);
        sb.append(aifLogLvNum + splitValue);
        sb.append("SYSTEM" + splitValue);
        sb.append(aifTtracNo + splitValue);
        sb.append(traceID + splitValue);
        sb.append(transactionID + splitValue);
        sb.append(transactionSeqNo + splitValue);
        sb.append(threadID + splitValue);
        sb.append(apiID + splitValue);
        sb.append(invokerName + splitValue);
        sb.append(messageBody + splitValue);
        sb.append(gcreenID + splitValue);
        sb.append(eventID + splitValue);

        return sb;
    }

}

package jp.co.jsbank.mobile.bff.dto.aba;
import java.util.List;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import jp.co.jsbank.mobile.bff.dto.UserInformationDetailsDto;
import lombok.Data;

/**
 * 法人利用者情報取得ABAリクエストDTO
 */
@Data
public class UserSettingDetailsAbaResponseDto {
    /**
     * 共通レスポンス・ヘッダ
     */
    private CommonResponseHeader commonResponseHeader;

    /**
     * 利用者情報DTOリスト
     */
    private List<UserInformationDetailsDto> userInfoList;  
}

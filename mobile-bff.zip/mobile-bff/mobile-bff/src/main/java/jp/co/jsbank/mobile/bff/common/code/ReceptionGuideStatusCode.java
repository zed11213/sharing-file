package jp.co.jsbank.mobile.bff.common.code;

/**
 * 受付案内ステータスコード
 */
public class ReceptionGuideStatusCode {

    /**
     * 一時保存
     */
    public static final String TEMPORARY_SAVING = "01";
    /**
     * 公開承認待ち 
     */
    public static final String PUBLIC_APPROVAL_PENDING = "02";
    /**
     * 公開許可
     */
    public static final String PUBLIC_PERMIT = "03";
    /**
     * 公開許可取消承認待ち
     */
    public static final String PUBLIC_PERMIT_RESET_APPROVAL_PENDING = "04";
}

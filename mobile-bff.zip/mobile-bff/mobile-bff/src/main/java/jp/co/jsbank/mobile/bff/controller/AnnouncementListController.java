package jp.co.jsbank.mobile.bff.controller;

import javax.annotation.Resource;

import org.apache.commons.codec.binary.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jp.co.jsbank.mobile.bff.common.JsonResult;
import jp.co.jsbank.mobile.bff.dto.AnnouncementRequestDto;
import jp.co.jsbank.mobile.bff.dto.AnnouncementResponseDto;
import jp.co.jsbank.mobile.bff.dto.InformationTextResponseDto;
import jp.co.jsbank.mobile.bff.dto.UpdateAnnouncementRequestDto;
import jp.co.jsbank.mobile.bff.service.AnnouncementListService;

/**
 * お知らせ一覧
 */
@RestController
public class AnnouncementListController {

    @Resource
    private AnnouncementListService announcementListService;

    // private Logger logger =
    // LoggerFactory.getLogger(AnnouncementListController.class);

    /**
     * お知らせ一覧取得
     *
     * @param requestDto お知らせ一覧リクエストDTO
     * @return 処理結果
     */
    @PostMapping(path = "/announcement-list/AB1001")
    public JsonResult getAnnouncementList(@RequestBody AnnouncementRequestDto requestDto) {

        // お知らせ一覧を取得する
        AnnouncementResponseDto responseDto = announcementListService.getAnnouncementList(requestDto);

        return JsonResult.success(responseDto);
    }

    /**
     * お知らせ本文取得
     *
     * @param anncmntId お知らせID
     * @param anncmntTypeId お知らせ種別ID
     * @param documentTypeId 文書種別ID
     * @return 処理結果
     */
    @GetMapping(path = "/announcement-list/AB1002")
    public JsonResult getInformationText(@RequestParam String anncmntId, @RequestParam String anncmntTypeId,
            @RequestParam String documentTypeId) {

        // お知らせ本文DTOを取得する
        InformationTextResponseDto result = announcementListService.getInformationText(anncmntId, anncmntTypeId,
                documentTypeId);

        UpdateAnnouncementRequestDto requestDto = new UpdateAnnouncementRequestDto();
        // お知らせID設定
        requestDto.setAnncmntId(anncmntId);
        // お知らせ種別ID設定
        requestDto.setAnncmntType(anncmntTypeId);
        // 文書種別ID設定
        requestDto.setDocumentType(documentTypeId);
        // 既読フラグ設定
        requestDto.setReadFlg("1");

        // お知らせ一覧更新
        announcementListService.updateAnnouncementList(requestDto);

        return JsonResult.success(result);

    }

    /**
     * スター/お気に入り押下処理
     *
     * @param requestDto お知らせ一覧更新リクエストDTO
     * @return 処理結果
     */
    @PostMapping(path = "/announcement-list/AB1003")
    public JsonResult saveStarAndFavorite(@RequestBody UpdateAnnouncementRequestDto requestDto) {

        // お気に入りが「なし」の場合
        if (StringUtils.equals(requestDto.getBookmarkFlg(), "0")) {

            // お気に入りに「あり」を設定する
            requestDto.setBookmarkFlg("1");
        } else if (StringUtils.equals(requestDto.getBookmarkFlg(), "1")) {

            // お気に入りが「あり」の場、合お気に入りに「なし」を設定する
            requestDto.setBookmarkFlg("0");
        }

        // 処理結果
        String result = announcementListService.updateAnnouncementList(requestDto);

        return JsonResult.success(result);
    }

    /**
     * 顧客による個別確認
     *
     * @param requestDto お知らせ一覧更新リクエストDTO
     * @return 処理結果
     */
    @PostMapping(path = "/announcement-list/AB1004")
    public JsonResult individualConfirmationCustomer(@RequestBody UpdateAnnouncementRequestDto requestDto) {

        // 処理結果
        String result = announcementListService.updateAnnouncementList(requestDto);

        return JsonResult.success(result);
    }
}

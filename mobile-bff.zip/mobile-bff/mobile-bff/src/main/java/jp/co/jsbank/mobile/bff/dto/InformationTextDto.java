package jp.co.jsbank.mobile.bff.dto;
import lombok.Data;

/**
 * お知らせ一覧DTO
 */
@Data
public class InformationTextDto {

    /**
     * モバイルメッセージ本文
     */
    private String mobileMsg;

    /**
     * 画像ファイル
     */
    private String fileStream;

    /**
     * 作成日時
     */
    private String createDateAndTime;
    
    /**
     * タイトル
     */
    private String anncmntTitle;
    
    /**
     * メッセージ内容種別
     */
    private String mobileMsgType;
    
    /**
     * 同意チェックボックス有無
     */
    private String acceptanceChkFlg;
    
    /**
     * 画像有無フラグ
     */
    private String imgFlg;
    
    /**
     * 画像位置
     */
    private String imgVPosition;
    
    /**
     * ボタンリンク先有無フラグ
     */
    private String btnLinkFlg;
    
    /**
     * ボタンリンク先URL
     */
    private String btnLinkUrl;
}

package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 利用口座登録照会AbaレスポンスDTO
 */
@Data
public class SavingsAccountsAbaResponseDto {
    /**
     * 共通レスポンス・ボディ
     */
    private CommonResponseHeader commonResponseHeader;

    /**
     * CIF番号
     */
    private String cifNumber;

}

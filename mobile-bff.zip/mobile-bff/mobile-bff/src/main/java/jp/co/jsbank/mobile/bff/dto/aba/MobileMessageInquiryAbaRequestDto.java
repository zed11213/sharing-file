package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import lombok.Data;

/**
 * モバイルメッセージ詳細照会ABAリクエストDTO
 */
@Data
public class MobileMessageInquiryAbaRequestDto {

    /**
     * お知らせID
     */
    private String anncmntId;

    /**
     * お知らせステータス
     */
    private List<String> anncmntStatus;

    /**
     * 顧客ID
     */
    private String destinationCustId;
}
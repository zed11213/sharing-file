package jp.co.jsbank.mobile.bff.dto;

import java.util.Map;

import lombok.Data;

/**
 * 受付案内閲覧レスボスDTO
 */
@Data
public class ReceptionInformationViewResponseDto {

    /**
     * お知らせID
     */
    private String anncmntId;

    /**
     * タイトル
     */
    private String anncmntTitle;

    /**
     * 作成日時
     */
    private String createDateAndTime;

    /**
     * メッセージ内容種別
     */
    private String mobileMsgType;
    /**
     * 受付案内ステータス
     */
    private String receptionGuideStatus;

    /**
     * 受付案内種類
     */
    private String receptionGuideType;

    /**
     * 掲載開始日時
     */
    private String anncmntStartTime;

    /**
     * 掲載終了日時
     */
    private String anncmntEndTime;

    /**
     * 受付案内本文
     */
    private String receptionGuideMsg;

    /**
     * 画像有無フラグ
     */
    private String imgFlg;

    /**
     * 画像位置
     */
    private String imgVPosition;

    /**
     * 画像バケット名PUB
     */
    private String imgBucketPub;

    /**
     * 画像バケット名PVT
     */
    private String imgBucketPvt;

    /**
     * 画像ファイル名
     */
    private String imgFilename;

    /**
     * ボタンリンク先有無フラグ
     */
    private String btnLinkFlg;

    /**
     * ボタンリンク先URL
     */
    private String btnLinkUrl;

    /**
     * 同意チェック有無フラグ
     */
    private String acceptanceChkFlg;

    /**
     * 非会員受付有無フラグ
     */
    private String nonMemberAplyFlg;

    /**
     * Push通知設定
     */
    private String pushNotifySet;

    /**
     * Push通知本文
     */
    private String pushNotifyMsg;

    /**
     * Push通知送信日時
     */
    private String pushNotifyTime;

    /**
     * 会場選択有無フラグ
     */
    private String venueSelectFlg;

    /**
     * 申込管理者種別
     */
    private String applyAdminType;

    /**
     * 申込管理者店番
     */
    private String applyAdminBranchNum;

    /**
     * 会場店番
     */
    private String venueBranchNum;

    /**
     * 判定結果
     */
    private String judgementResult;

    /**
     * 申込確認メッセージ
     */
    private String applyConfirmMsg;

    /**
     * 支店リスト
     */
    private Map<String, String> branchMap;

    /**
     * 受付フォーマット
     */
    private String receptionFormat;

    /**
     * 更新タイムスタンプ(排他用)
     */
    private String updateTs;

    /**
     * 画像ファイル
     */
    private String fileStream;

}

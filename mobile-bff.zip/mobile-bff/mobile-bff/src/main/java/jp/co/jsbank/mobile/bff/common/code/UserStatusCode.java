package jp.co.jsbank.mobile.bff.common.code;

/**
 * 利用者ステータスコード
 */
public class UserStatusCode {

    /**
     * 正常
     */
    public static final String NORMAL = "0";

    /**
     * 確認中
     */
    public static final String IN_CONFIRMATION = "1";

    /**
     * 利用停止
     */
    public static final String SUSPEND = "2";

    /**
     * 取引停止
     */
    public static final String TRADING_STOP = "3";

}

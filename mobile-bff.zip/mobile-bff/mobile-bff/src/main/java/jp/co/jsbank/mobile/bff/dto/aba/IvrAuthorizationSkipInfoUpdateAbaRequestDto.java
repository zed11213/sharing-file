package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * IVR認証スキップ情報更新ABAリクエストDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class IvrAuthorizationSkipInfoUpdateAbaRequestDto extends RequestBodyDto {

    /**
     * 受付番号
     */
    private String receiptNumber;

    /**
     * CIF番号
     */
    private String cifNumber;

    /**
     * IVRスキップフラグ
     */
    private String ivrSkipFlag;

    /**
     * 有効時間
     */
    private String validDateTime;

    /**
     * 使用済みフラグ
     */
    private String usedFlag;

    /**
     * 最終更新日時（排他用）
     */
    private String lastUpdateTime;
}

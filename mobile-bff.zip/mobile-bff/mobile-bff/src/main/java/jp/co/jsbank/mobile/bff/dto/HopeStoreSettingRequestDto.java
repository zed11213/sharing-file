package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 希望店設定BFFリクエストDTO
 */
@Data
public class HopeStoreSettingRequestDto {

    /**
     * 受付番号
     */
    private String receptionNumber;

    /**
     * 人格区分
     */
    private String personType;

    /**
     * 希望部店
     */
    private String hopeDepartmentStore;
}

package jp.co.jsbank.mobile.bff.logic.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.codec.binary.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.jsbank.mobile.bff.common.code.DocumentTypeCode;
import jp.co.jsbank.mobile.bff.config.RestClientConfig;
import jp.co.jsbank.mobile.bff.dto.AutomaticRenewalTimeDepositInterestCalculationDto;
import jp.co.jsbank.mobile.bff.dto.BorrowingRepaymentDto;
import jp.co.jsbank.mobile.bff.dto.ContractPaymentDto;
import jp.co.jsbank.mobile.bff.dto.CurrentAccountDto;
import jp.co.jsbank.mobile.bff.dto.DiscountedBillCalculationDto;
import jp.co.jsbank.mobile.bff.dto.LoanDateDto;
import jp.co.jsbank.mobile.bff.dto.PeriodicDepositMaturityDto;
import jp.co.jsbank.mobile.bff.dto.PropertyFormationDepositBalanceNotificationDto;
import jp.co.jsbank.mobile.bff.dto.RepaymentScheduleDto;
import jp.co.jsbank.mobile.bff.dto.SuperDreamDateDto;
import jp.co.jsbank.mobile.bff.dto.SuperDreamInterestRateDto;
import jp.co.jsbank.mobile.bff.dto.TimeDepositDateDto;
import jp.co.jsbank.mobile.bff.dto.aba.CreateReportPdfAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.ElectronicIssueAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport001AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport002AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport003AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport004AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport005AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport006AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport007AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport008AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport009AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport010AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport011AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport012AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport013AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport014AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport015AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport016AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport017AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport018AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport019AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport021AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.LotteryResultAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.LotteryResultAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.LotteryResultsDetailsDto;
import jp.co.jsbank.mobile.bff.logic.ElectronicIssueLogic;

/**
 * 電子交付ロジック実装クラス
 */
@Service
public class ElectronicIssueLogicImpl implements ElectronicIssueLogic {

    @Autowired
    RestClientConfig restClientConfig;

    /**
     * 帳票CSV内容照会_定期預金利息計算（懸賞金付）（自継）
     *
     * @param requestDto お知らせ閲覧ABAリクエストDTO
     * @return 定期預金利息計算（懸賞金付）（自継）
     */
    @Override
    public InquireReport001AbaResponseDto abaInquireReportCsv001(ElectronicIssueAbaRequestDto requestDto) {

        // Dummyデータ
        InquireReport001AbaResponseDto dto = new InquireReport001AbaResponseDto();

        /**
         * 帳票バージョン
         */
        dto.setFormVersion("1.01");

        /**
         * 本状作成日
         */
        dto.setBookCreateDate("20220303");

        /**
         * 口座番号
         */
        dto.setComAccountNo("12345678901");

        /**
         * 店番
         */
        dto.setComBranchNo("001");

        /**
         * 開始日
         */
        dto.setStartDate("20220304");

        /**
         * 終了日
         */
        dto.setEndDate("20220323");

        List<SuperDreamInterestRateDto> dtoList = new ArrayList<SuperDreamInterestRateDto>();

        /**
         * スーパードリームお利息計算明細表リスト
         */
        SuperDreamInterestRateDto superDreamInterestRateDto1 = new SuperDreamInterestRateDto();

        /**
         * 預金番号
         */
        superDreamInterestRateDto1.setDepositNumber("001");

        /**
         * 種類
         */
        superDreamInterestRateDto1.setType("スーパードリーム（自動継続型）");

        /**
         * お預り金額
         */
        superDreamInterestRateDto1.setDepositAmount("1000");

        /**
         * 利率
         */
        superDreamInterestRateDto1.setInterestRate("1.156");

        /**
         * 税区分
         */
        superDreamInterestRateDto1.setTaxType("個人税");

        /**
         * 期日
         */
        superDreamInterestRateDto1.setExpiryDate("20220408");

        /**
         * 計算期間
         */
        superDreamInterestRateDto1.setCountDuration("24");

        /**
         * お利息
         */
        superDreamInterestRateDto1.setInterestAmount("1101");

        /**
         * お利息_国税
         */
        superDreamInterestRateDto1.setInterestNationalTax("1201");

        /**
         * お利息_地方税
         */
        superDreamInterestRateDto1.setInterestLocalTax("1301");

        /**
         * 差引お利息
         */
        superDreamInterestRateDto1.setDeductedInterestAmount("134568");

        /**
         * 抽せん番号_回
         */
        superDreamInterestRateDto1.setLotteryNoRound("10");

        /**
         * 抽せん番号_組
         */
        superDreamInterestRateDto1.setLotteryNoGroup("150");

        /**
         * 抽せん番号_開始
         */
        superDreamInterestRateDto1.setLotteryNoStart("1001");

        /**
         * 抽せん番号_終了
         */
        superDreamInterestRateDto1.setLotteryNoEnd("2501");

        /**
         * 懸賞金
         */
        superDreamInterestRateDto1.setRewardAmount("10000");

        /**
         * 懸賞金_国税
         */
        superDreamInterestRateDto1.setRewardNationalTax("1000");

        /**
         * 懸賞金_地方税
         */
        superDreamInterestRateDto1.setRewardLocalTax("900");

        /**
         * 差引懸賞金
         */
        superDreamInterestRateDto1.setDeductedRewardAmount("9100");

        /**
         * 新元金
         */
        superDreamInterestRateDto1.setNewPrincipalAmount("12000");

        /**
         * 新利率
         */
        superDreamInterestRateDto1.setNewInterestRate("1.368");

        /**
         * 新抽せん番号_回
         */
        superDreamInterestRateDto1.setNewLotteryNoRound("20");

        /**
         * 新抽せん番号_組
         */
        superDreamInterestRateDto1.setNewLotteryNoGroup("5");

        /**
         * 新抽せん番号_開始
         */
        superDreamInterestRateDto1.setNewLotteryNoStart("2201");

        /**
         * 新抽せん番号_終了
         */
        superDreamInterestRateDto1.setNewLotteryNoEnd("2301");

        /**
         * 新抽せん日
         */
        superDreamInterestRateDto1.setNewLotteryDate("20220517");

        /**
         * スーパードリームお利息計算明細表リスト
         */
        SuperDreamInterestRateDto superDreamInterestRateDto2 = new SuperDreamInterestRateDto();

        /**
         * 預金番号
         */
        superDreamInterestRateDto2.setDepositNumber("001");

        /**
         * 種類
         */
        superDreamInterestRateDto2.setType("スーパードリーム（自動継続型）");

        /**
         * お預り金額
         */
        superDreamInterestRateDto2.setDepositAmount("1000");

        /**
         * 利率
         */
        superDreamInterestRateDto2.setInterestRate("1.156");

        /**
         * 税区分
         */
        superDreamInterestRateDto2.setTaxType("個人税");

        /**
         * 期日
         */
        superDreamInterestRateDto2.setExpiryDate("20220408");

        /**
         * 計算期間
         */
        superDreamInterestRateDto2.setCountDuration("24");

        /**
         * お利息
         */
        superDreamInterestRateDto2.setInterestAmount("1101");

        /**
         * お利息_国税
         */
        superDreamInterestRateDto2.setInterestNationalTax("1201");

        /**
         * お利息_地方税
         */
        superDreamInterestRateDto2.setInterestLocalTax("1301");

        /**
         * 差引お利息
         */
        superDreamInterestRateDto2.setDeductedInterestAmount("134568");

        /**
         * 抽せん番号_回
         */
        superDreamInterestRateDto2.setLotteryNoRound("10");

        /**
         * 抽せん番号_組
         */
        superDreamInterestRateDto2.setLotteryNoGroup("150");

        /**
         * 抽せん番号_開始
         */
        superDreamInterestRateDto2.setLotteryNoStart("1001");

        /**
         * 抽せん番号_終了
         */
        superDreamInterestRateDto2.setLotteryNoEnd("2501");

        /**
         * 懸賞金
         */
        superDreamInterestRateDto2.setRewardAmount("10000");

        /**
         * 懸賞金_国税
         */
        superDreamInterestRateDto2.setRewardNationalTax("1000");

        /**
         * 懸賞金_地方税
         */
        superDreamInterestRateDto2.setRewardLocalTax("900");

        /**
         * 差引懸賞金
         */
        superDreamInterestRateDto2.setDeductedRewardAmount("9100");

        /**
         * 新元金
         */
        superDreamInterestRateDto2.setNewPrincipalAmount("12000");

        /**
         * 新利率
         */
        superDreamInterestRateDto2.setNewInterestRate("1.368");

        /**
         * 新抽せん番号_回
         */
        superDreamInterestRateDto2.setNewLotteryNoRound("20");

        /**
         * 新抽せん番号_組
         */
        superDreamInterestRateDto2.setNewLotteryNoGroup("5");

        /**
         * 新抽せん番号_開始
         */
        superDreamInterestRateDto2.setNewLotteryNoStart("2201");

        /**
         * 新抽せん番号_終了
         */
        superDreamInterestRateDto2.setNewLotteryNoEnd("2301");

        /**
         * 新抽せん日
         */
        superDreamInterestRateDto2.setNewLotteryDate("20220517");
        dtoList.add(superDreamInterestRateDto2);
        dtoList.add(superDreamInterestRateDto1);
        dto.setSuperDreamInterestRateList(dtoList);

        /**
         * マル優申告限度額
         */
        dto.setDeclarationLimitAmount("10000");

        /**
         * ご利用額(預金)
         */
        dto.setUsageAmount("20000");

        /**
         * 取扱店名
         */
        dto.setBranchKanjiName("東京都");

        /**
         * 取扱電話番号
         */
        dto.setBranchPhoneNumber("030-12345411");

        return dto;
    }

    /**
     * 帳票CSV内容照会_定期預金（懸賞金付）期日案内
     *
     * @param requestDto お知らせ閲覧ABAリクエストDTO
     * @return お知らせ閲覧レスポンスDTO
     */
    @Override
    public InquireReport002AbaResponseDto abaInquireReportCsv002(ElectronicIssueAbaRequestDto requestDto) {

        // Dummyデータ
        InquireReport002AbaResponseDto dto = new InquireReport002AbaResponseDto();

        /**
         * 帳票バージョン
         */
        dto.setFormVersion("1.01");

        /**
         * 本状作成日
         */
        dto.setBookCreateDate("20220303");

        /**
         * 口座番号
         */
        dto.setComAccountNo("12345678901");

        /**
         * 店番
         */
        dto.setComBranchNo("001");
        List<SuperDreamDateDto> dtoList = new ArrayList<SuperDreamDateDto>();

        /**
         * スーパードリーム期日明細表リスト
         */
        SuperDreamDateDto superDreamDateDto = new SuperDreamDateDto();

        /**
         * 預金番号
         */
        superDreamDateDto.setDepositNumber("001");

        /**
         * 預金種類
         */
        superDreamDateDto.setDepositType("スーパードリーム");

        /**
         * 種類
         */
        superDreamDateDto.setType("自動継続型");

        /**
         * お預り金額
         */
        superDreamDateDto.setDepositAmount("1000");

        /**
         * 利率
         */
        superDreamDateDto.setInterestRate("1.156");

        /**
         * 税区分
         */
        superDreamDateDto.setTaxType("個人税");

        /**
         * 期日
         */
        superDreamDateDto.setExpiryDate("20220408");

        /**
         * 計算期間
         */
        superDreamDateDto.setCountDuration("24");

        /**
         * 計算期間単位
         */
        superDreamDateDto.setCountDurationUnit("日");

        /**
         * お利息
         */
        superDreamDateDto.setInterestAmount("1101");

        /**
         * お利息_国税
         */
        superDreamDateDto.setInterestNationalTax("1201");

        /**
         * お利息_地方税
         */
        superDreamDateDto.setInterestLocalTax("1301");

        /**
         * 差引お利息
         */
        superDreamDateDto.setDeductedInterestAmount("134568");

        /**
         * 懸賞金
         */
        superDreamDateDto.setRewardAmount("10000");

        /**
         * 懸賞金_国税
         */
        superDreamDateDto.setRewardNationalTax("1000");

        /**
         * 懸賞金_地方税
         */
        superDreamDateDto.setRewardLocalTax("900");

        /**
         * 差引懸賞金
         */
        superDreamDateDto.setDeductedRewardAmount("9100");

        /**
         * 備考１
         */
        superDreamDateDto.setRemark1(" 懸賞金の当せんおめでとうございます。");

        /**
         * 備考２
         */
        superDreamDateDto.setRemark2(" 備考２");

        /**
         * 備考３
         */
        superDreamDateDto.setRemark3(" 懸賞金備考３");

        /**
         * 抽せん番号_回
         */
        superDreamDateDto.setLotteryNoRound("10");

        /**
         * 抽せん番号_組
         */
        superDreamDateDto.setLotteryNoGroup("150");

        /**
         * 抽せん番号_開始
         */
        superDreamDateDto.setLotteryNoStart("1001");

        /**
         * 抽せん番号_終了
         */
        superDreamDateDto.setLotteryNoEnd("2501");

        /**
         * 相続停止文言
         */
        superDreamDateDto.setSuccessionStopValue("相続預金につき支払時に利子税を清算。");

        /**
         * スーパードリーム期日明細表リスト
         */
        SuperDreamDateDto superDreamDateDto2 = new SuperDreamDateDto();

        /**
         * 預金番号
         */
        superDreamDateDto2.setDepositNumber("002");

        /**
         * 預金種類
         */
        superDreamDateDto2.setDepositType("スーパードリーム");

        /**
         * 種類
         */
        superDreamDateDto2.setType("自動継続型");

        /**
         * お預り金額
         */
        superDreamDateDto2.setDepositAmount("2000");

        /**
         * 利率
         */
        superDreamDateDto2.setInterestRate("2.156");

        /**
         * 税区分
         */
        superDreamDateDto2.setTaxType("個人税");

        /**
         * 期日
         */
        superDreamDateDto2.setExpiryDate("20220508");

        /**
         * 計算期間
         */
        superDreamDateDto2.setCountDuration("23");

        /**
         * 計算期間単位
         */
        superDreamDateDto2.setCountDurationUnit("日");

        /**
         * お利息
         */
        superDreamDateDto2.setInterestAmount("1101");

        /**
         * お利息_国税
         */
        superDreamDateDto2.setInterestNationalTax("1201");

        /**
         * お利息_地方税
         */
        superDreamDateDto2.setInterestLocalTax("1301");

        /**
         * 差引お利息
         */
        superDreamDateDto2.setDeductedInterestAmount("134568");

        /**
         * 懸賞金
         */
        superDreamDateDto2.setRewardAmount("10000");

        /**
         * 懸賞金_国税
         */
        superDreamDateDto2.setRewardNationalTax("1000");

        /**
         * 懸賞金_地方税
         */
        superDreamDateDto2.setRewardLocalTax("900");

        /**
         * 差引懸賞金
         */
        superDreamDateDto2.setDeductedRewardAmount("9100");

        /**
         * 備考１
         */
        superDreamDateDto2.setRemark1(" 懸賞金の当せんおめでとうございます。");

        /**
         * 備考２
         */
        superDreamDateDto2.setRemark2(" 備考２");

        /**
         * 備考３
         */
        superDreamDateDto2.setRemark3(" 懸賞金備考３");

        /**
         * 抽せん番号_回
         */
        superDreamDateDto2.setLotteryNoRound("10");

        /**
         * 抽せん番号_組
         */
        superDreamDateDto2.setLotteryNoGroup("150");

        /**
         * 抽せん番号_開始
         */
        superDreamDateDto2.setLotteryNoStart("1001");

        /**
         * 抽せん番号_終了
         */
        superDreamDateDto2.setLotteryNoEnd("2501");

        /**
         * 相続停止文言
         */
        superDreamDateDto2.setSuccessionStopValue("相続預金につき支払時に利子税を清算。");
        dtoList.add(superDreamDateDto);
        dtoList.add(superDreamDateDto2);
        dto.setSuperDreamDateList(dtoList);

        /**
         * マル優申告限度額
         */
        dto.setDeclarationLimitAmount("10,000");

        /**
         * ご利用額(預金)
         */
        dto.setUsageAmount("20,000");

        /**
         * 取扱店名
         */
        dto.setBranchKanjiName("東京都");

        /**
         * 取扱電話番号
         */
        dto.setBranchPhoneNumber("030-12345411");

        return dto;
    }

    /**
     * 帳票CSV内容照会_定期積金満期案内
     *
     * @param requestDto お知らせ閲覧ABAリクエストDTO
     * @return お知らせ閲覧レスポンスDTO
     */
    @Override
    public InquireReport004AbaResponseDto abaInquireReportCsv004(ElectronicIssueAbaRequestDto requestDto) {

        // Dummyデータ
        InquireReport004AbaResponseDto dto = new InquireReport004AbaResponseDto();

        /**
         * 帳票バージョン
         */

        dto.setFormVersion("1.01");

        /**
         * 本状作成日
         */
        dto.setBookCreateDate("20220303");

        List<PeriodicDepositMaturityDto> dtoList = new ArrayList<PeriodicDepositMaturityDto>();

        /**
         * 定期積金満期明細表リスト
         */
        PeriodicDepositMaturityDto periodicDepositMaturityDto = new PeriodicDepositMaturityDto();

        /**
         * 星
         */
        periodicDepositMaturityDto.setStar("*");

        /**
         * お積立ての種類
         */
        periodicDepositMaturityDto.setTypeOfReserve("夢付き定積");

        /**
         * 口座番号
         */
        periodicDepositMaturityDto.setAccountNumber("0045671025");

        /**
         * ご契約金額
         */
        periodicDepositMaturityDto.setContractAmount("800000");

        /**
         * お積立残高
         */
        periodicDepositMaturityDto.setReserveBalance("100");

        /**
         * 満期日
         */
        periodicDepositMaturityDto.setMaturityDate("20220403");

        /**
         * 期間年
         */
        periodicDepositMaturityDto.setPeriodYear("10");

        /**
         * 期間月
         */
        periodicDepositMaturityDto.setPeriodMonth("3");

        /**
         * 税区分
         */
        periodicDepositMaturityDto.setTaxType("課税");

        /**
         * 定期積金満期明細表リスト
         */
        PeriodicDepositMaturityDto periodicDepositMaturityDto2 = new PeriodicDepositMaturityDto();

        /**
         * 星
         */
        periodicDepositMaturityDto2.setStar("*");

        /**
         * お積立ての種類
         */
        periodicDepositMaturityDto2.setTypeOfReserve("夢付き定積");

        /**
         * 口座番号
         */
        periodicDepositMaturityDto2.setAccountNumber("0045671025");

        /**
         * ご契約金額
         */
        periodicDepositMaturityDto2.setContractAmount("800000");

        /**
         * お積立残高
         */
        periodicDepositMaturityDto2.setReserveBalance("100");

        /**
         * 満期日
         */
        periodicDepositMaturityDto2.setMaturityDate("20220403");

        /**
         * 期間年
         */
        periodicDepositMaturityDto2.setPeriodYear("10");

        /**
         * 期間月
         */
        periodicDepositMaturityDto2.setPeriodMonth("3");

        /**
         * 税区分
         */
        periodicDepositMaturityDto2.setTaxType("課税");
        dtoList.add(periodicDepositMaturityDto);
        dtoList.add(periodicDepositMaturityDto2);
        dto.setPeriodicDepositMaturityList(dtoList);

        /**
         * 取扱店名
         */
        dto.setBranchKanjiName("東京都");

        /**
         * 取扱電話番号
         */
        dto.setBranchPhoneNumber("030-12345411");

        return dto;
    }

    /**
     * 帳票CSV内容照会_定期預金期日案内
     *
     * @param requestDto お知らせ閲覧ABAリクエストDTO
     * @return お知らせ閲覧レスポンスDTO
     */
    @Override
    public InquireReport003AbaResponseDto abaInquireReportCsv003(ElectronicIssueAbaRequestDto requestDto) {

        // Dummyデータ
        InquireReport003AbaResponseDto dto = new InquireReport003AbaResponseDto();

        /**
         * 帳票バージョン
         */
        dto.setFormVersion("1.01");

        /**
         * 本状作成日
         */
        dto.setBookCreateDate("20220303");

        List<TimeDepositDateDto> dtoList = new ArrayList<TimeDepositDateDto>();

        /**
         * 定期預金等期日明細表リスト
         */
        TimeDepositDateDto timeDepositDateDto1 = new TimeDepositDateDto();

        /**
         * 預金番号
         */
        timeDepositDateDto1.setDepositNumber("001");

        /**
         * 種類
         */
        timeDepositDateDto1.setType("積立");

        /**
         * 取扱種類
         */
        timeDepositDateDto1.setHandlingType("定期");

        /**
         * お預り金額
         */
        timeDepositDateDto1.setDepositAmount("1000");

        /**
         * 利率
         */
        timeDepositDateDto1.setInterestRate("1.156");

        /**
         * 税区分
         */
        timeDepositDateDto1.setTaxType("分離課税");

        /**
         * 期日
         */
        timeDepositDateDto1.setExpiryDate("20220408");

        /**
         * 計算期間
         */
        timeDepositDateDto1.setCountDuration("24");

        /**
         * 計算期間単位
         */
        timeDepositDateDto1.setCountDurationUnit("日");

        /**
         * お利息
         */
        timeDepositDateDto1.setInterestAmount("1101");

        /**
         * お利息_国税
         */
        timeDepositDateDto1.setInterestNationalTax("1201");

        /**
         * お利息_地方税
         */
        timeDepositDateDto1.setInterestLocalTax("1301");

        /**
         * お利息_差引お利息
         */
        timeDepositDateDto1.setInterestDeductedInterestAmount("134568");

        /**
         * 支払調書文言１２
         */
        timeDepositDateDto1.setPaymentRecordValue12("利子税を清算");

        /**
         * 継続後の新元金
         */
        timeDepositDateDto1.setNewPrincipalAfterContinuation("6000");

        /**
         * 備考１
         */
        timeDepositDateDto1.setRemark1("お利息を元金に組み入れます");

        /**
         * 備考２
         */
        timeDepositDateDto1.setRemark2("備考２");

        /**
         * 備考３
         */
        timeDepositDateDto1.setRemark3("備考３");

        /**
         * 子供お預り金額
         */
        timeDepositDateDto1.setChildDepositAmount("7000");

        /**
         * 子供利率
         */
        timeDepositDateDto1.setChildInterestRate("0.011");

        /**
         * 子供税区分
         */
        timeDepositDateDto1.setChildTaxType("マル優");

        /**
         * 子供期日
         */
        timeDepositDateDto1.setChildExpiryDate("20220101");

        /**
         * 子供計算期間
         */
        timeDepositDateDto1.setChildCountDuration("21");

        /**
         * 子供計算期間単位
         */
        timeDepositDateDto1.setChildCountDurationUnit("日");

        /**
         * 子供お利息
         */
        timeDepositDateDto1.setChildInterestAmount("770");

        /**
         * 子供お利息_国税
         */
        timeDepositDateDto1.setChildInterestNationalTax("800");

        /**
         * 子供お利息_地方税
         */
        timeDepositDateDto1.setChildInterestLocalTax("600");

        /**
         * 子供お利息_差引お利息
         */
        timeDepositDateDto1.setChildInterestDeductedInterestAmount("1455");

        /**
         * 支払調書文言１１
         */
        timeDepositDateDto1.setPaymentRecordValue11("利子税を清算");

        /**
         * 親子有区分
         */
        timeDepositDateDto1.setParentChildFlag("1");

        /**
         * 子供支払区分
         */
        timeDepositDateDto1.setChildPaymentFlag("0");

        /**
         * 法人割廃止表示
         */
        timeDepositDateDto1.setCorporationAbolishExpression("0");

        /**
         * マル優改組表示
         */
        timeDepositDateDto1.setDeclarationReorganizeExpression("0");

        /**
         * 定期預金等期日明細表リスト
         */
        TimeDepositDateDto timeDepositDateDto2 = new TimeDepositDateDto();

        /**
         * 預金番号
         */
        timeDepositDateDto2.setDepositNumber("002");

        /**
         * 種類
         */
        timeDepositDateDto2.setType("積立");

        /**
         * 取扱種類
         */
        timeDepositDateDto2.setHandlingType("定期");

        /**
         * お預り金額
         */
        timeDepositDateDto2.setDepositAmount("2000");

        /**
         * 利率
         */
        timeDepositDateDto2.setInterestRate("2.156");

        /**
         * 税区分
         */
        timeDepositDateDto2.setTaxType("分離課税");

        /**
         * 期日
         */
        timeDepositDateDto2.setExpiryDate("20220508");

        /**
         * 計算期間
         */
        timeDepositDateDto2.setCountDuration("18");

        /**
         * 計算期間単位
         */
        timeDepositDateDto2.setCountDurationUnit("日");

        /**
         * お利息
         */
        timeDepositDateDto2.setInterestAmount("2101");

        /**
         * お利息_国税
         */
        timeDepositDateDto2.setInterestNationalTax("2201");

        /**
         * お利息_地方税
         */
        timeDepositDateDto2.setInterestLocalTax("2301");

        /**
         * お利息_差引お利息
         */
        timeDepositDateDto2.setInterestDeductedInterestAmount("234568");

        /**
         * 支払調書文言１２
         */
        timeDepositDateDto2.setPaymentRecordValue12("利子税を清算");

        /**
         * 継続後の新元金
         */
        timeDepositDateDto2.setNewPrincipalAfterContinuation("2000");

        /**
         * 備考１
         */
        timeDepositDateDto2.setRemark1("お利息を元金に組み入れます");

        /**
         * 備考２
         */
        timeDepositDateDto2.setRemark2("備考２");

        /**
         * 備考３
         */
        timeDepositDateDto2.setRemark3("備考３");

        /**
         * 子供お預り金額
         */
        timeDepositDateDto2.setChildDepositAmount("2000");

        /**
         * 子供利率
         */
        timeDepositDateDto2.setChildInterestRate("2.011");

        /**
         * 子供税区分
         */
        timeDepositDateDto2.setChildTaxType("マル優");

        /**
         * 子供期日
         */
        timeDepositDateDto2.setChildExpiryDate("20220201");

        /**
         * 子供計算期間
         */
        timeDepositDateDto2.setChildCountDuration("21");

        /**
         * 子供計算期間単位
         */
        timeDepositDateDto2.setChildCountDurationUnit("日");

        /**
         * 子供お利息
         */
        timeDepositDateDto2.setChildInterestAmount("770");

        /**
         * 子供お利息_国税
         */
        timeDepositDateDto2.setChildInterestNationalTax("800");

        /**
         * 子供お利息_地方税
         */
        timeDepositDateDto2.setChildInterestLocalTax("600");

        /**
         * 子供お利息_差引お利息
         */
        timeDepositDateDto2.setChildInterestDeductedInterestAmount("1455");

        /**
         * 支払調書文言１１
         */
        timeDepositDateDto2.setPaymentRecordValue11("利子税を清算");

        /**
         * 親子有区分
         */
        timeDepositDateDto2.setParentChildFlag("0");

        /**
         * 子供支払区分
         */
        timeDepositDateDto2.setChildPaymentFlag("1");

        /**
         * 法人割廃止表示
         */
        timeDepositDateDto2.setCorporationAbolishExpression("1");

        /**
         * マル優改組表示
         */
        timeDepositDateDto2.setDeclarationReorganizeExpression("1");
        dtoList.add(timeDepositDateDto1);
        dtoList.add(timeDepositDateDto2);
        dto.setTimeDepositDateList(dtoList);

        /**
         * マル優申告限度額
         */
        dto.setDeclarationLimitAmount("10,000");

        /**
         * ご利用額(預金)
         */
        dto.setUsageAmount("20,000");

        /**
         * 取扱店名
         */
        dto.setBranchKanjiName("東京都");

        /**
         * 取扱電話番号
         */
        dto.setBranchPhoneNumber("030-12345411");

        return dto;
    }

    /**
     * 帳票CSV内容照会_定期預金（自継）利息計算
     *
     * @param requestDto お知らせ閲覧ABAリクエストDTO
     * @return お知らせ閲覧レスポンスDTO
     */
    @Override
    public InquireReport005AbaResponseDto abaInquireReportCsv005(ElectronicIssueAbaRequestDto requestDto) {

        // Dummyデータ
        InquireReport005AbaResponseDto dto = new InquireReport005AbaResponseDto();

        /**
         * 帳票バージョン
         */

        dto.setFormVersion("1.01");

        /**
         * 本状作成日
         */
        dto.setBookCreateDate("20220303");

        List<AutomaticRenewalTimeDepositInterestCalculationDto> dtoList = new ArrayList<AutomaticRenewalTimeDepositInterestCalculationDto>();

        /**
         * 自動継続定期預金お利息計算明細表リスト
         */
        AutomaticRenewalTimeDepositInterestCalculationDto calculationDto = new AutomaticRenewalTimeDepositInterestCalculationDto();

        /**
         * 預金番号
         */
        calculationDto.setDepositNumber("001");

        /**
         * 種類
         */
        calculationDto.setType("積立");

        /**
         * 取扱種類
         */
        calculationDto.setHandlingType("定期");

        /**
         * お預り金額
         */
        calculationDto.setDepositAmount("1000");

        /**
         * 利率
         */
        calculationDto.setInterestRate("1.156");

        /**
         * 税区分
         */
        calculationDto.setTaxType("個人税");

        /**
         * 期日
         */
        calculationDto.setExpiryDate("20220408");

        /**
         * 計算期間
         */
        calculationDto.setCountDuration("24");

        /**
         * 計算期間単位
         */
        calculationDto.setCountDurationUnit("日");

        /**
         * お利息
         */
        calculationDto.setInterestAmount("1101");

        /**
         * お利息_国税
         */
        calculationDto.setInterestNationalTax("1201");

        /**
         * お利息_地方税
         */
        calculationDto.setInterestLocalTax("1301");

        /**
         * お利息_差引お利息
         */
        calculationDto.setInterestDeductedInterestAmount("134568");

        /**
         * 支払調書文言１２
         */
        calculationDto.setPaymentRecordValue12("利子税を清算");

        /**
         * 新元金
         */
        calculationDto.setNewPrincipalAmount("6000");

        /**
         * 備考１
         */
        calculationDto.setRemark1("お利息を元金に組み入れます");

        /**
         * 備考２
         */
        calculationDto.setRemark2("備考２");

        /**
         * 備考３
         */
        calculationDto.setRemark3("備考３");

        /**
         * 子供お預り金額
         */
        calculationDto.setChildDepositAmount("7000");

        /**
         * 子供利率
         */
        calculationDto.setChildInterestRate("0.011");

        /**
         * 子供税区分
         */
        calculationDto.setChildTaxType("マル優");

        /**
         * 子供期日
         */
        calculationDto.setChildExpiryDate("20220101");

        /**
         * 子供計算期間
         */
        calculationDto.setChildCountDuration("21");

        /**
         * 子供計算期間単位
         */
        calculationDto.setChildCountDurationUnit("日");

        /**
         * 子供お利息
         */
        calculationDto.setChildInterestAmount("770");

        /**
         * 子供お利息_国税
         */
        calculationDto.setChildInterestNationalTax("800");

        /**
         * 子供お利息_地方税
         */
        calculationDto.setChildInterestLocalTax("600");

        /**
         * 子供お利息_差引お利息
         */
        calculationDto.setChildInterestDeductedInterestAmount("1455");

        /**
         * 支払調書文言１１
         */
        calculationDto.setPaymentRecordValue11("利子税を清算");

        /**
         * 親子有区分
         */
        calculationDto.setParentChildFlag("1");

        /**
         * 子供支払区分
         */
        calculationDto.setChildPaymentFlag("0");
        /**
         * 自動継続定期預金お利息計算明細表リスト
         */
        AutomaticRenewalTimeDepositInterestCalculationDto calculationDto2 = new AutomaticRenewalTimeDepositInterestCalculationDto();

        /**
         * 預金番号
         */
        calculationDto2.setDepositNumber("002");

        /**
         * 種類
         */
        calculationDto2.setType("積立");

        /**
         * 取扱種類
         */
        calculationDto2.setHandlingType("定期");

        /**
         * お預り金額
         */
        calculationDto2.setDepositAmount("2000");

        /**
         * 利率
         */
        calculationDto2.setInterestRate("2.156");

        /**
         * 税区分
         */
        calculationDto2.setTaxType("個人税");

        /**
         * 期日
         */
        calculationDto2.setExpiryDate("20220508");

        /**
         * 計算期間
         */
        calculationDto2.setCountDuration("12");

        /**
         * 計算期間単位
         */
        calculationDto2.setCountDurationUnit("日");

        /**
         * お利息
         */
        calculationDto2.setInterestAmount("2101");

        /**
         * お利息_国税
         */
        calculationDto2.setInterestNationalTax("2201");

        /**
         * お利息_地方税
         */
        calculationDto2.setInterestLocalTax("2301");

        /**
         * お利息_差引お利息
         */
        calculationDto2.setInterestDeductedInterestAmount("234568");

        /**
         * 支払調書文言１２
         */
        calculationDto2.setPaymentRecordValue12("利子税を清算");

        /**
         * 新元金
         */
        calculationDto2.setNewPrincipalAmount("26000");

        /**
         * 備考１
         */
        calculationDto2.setRemark1("お利息を元金に組み入れます");

        /**
         * 備考２
         */
        calculationDto2.setRemark2("備考２");

        /**
         * 備考３
         */
        calculationDto2.setRemark3("備考３");

        /**
         * 子供お預り金額
         */
        calculationDto2.setChildDepositAmount("7000");

        /**
         * 子供利率
         */
        calculationDto2.setChildInterestRate("2.011");

        /**
         * 子供税区分
         */
        calculationDto2.setChildTaxType("マル優");

        /**
         * 子供期日
         */
        calculationDto2.setChildExpiryDate("20220201");

        /**
         * 子供計算期間
         */
        calculationDto2.setChildCountDuration("12");

        /**
         * 子供計算期間単位
         */
        calculationDto2.setChildCountDurationUnit("日");

        /**
         * 子供お利息
         */
        calculationDto2.setChildInterestAmount("2770");

        /**
         * 子供お利息_国税
         */
        calculationDto2.setChildInterestNationalTax("2800");

        /**
         * 子供お利息_地方税
         */
        calculationDto2.setChildInterestLocalTax("2600");

        /**
         * 子供お利息_差引お利息
         */
        calculationDto2.setChildInterestDeductedInterestAmount("2455");

        /**
         * 支払調書文言１１
         */
        calculationDto2.setPaymentRecordValue11("利子税を清算");

        /**
         * 親子有区分
         */
        calculationDto2.setParentChildFlag("0");

        /**
         * 子供支払区分
         */
        calculationDto2.setChildPaymentFlag("1");
        dtoList.add(calculationDto);
        dtoList.add(calculationDto2);
        dto.setAutomaticRenewalTimeDepositInterestCalculationList(dtoList);

        /**
         * 取扱店名
         */
        dto.setBranchKanjiName("東京都");

        /**
         * 取扱電話番号
         */
        dto.setBranchPhoneNumber("030-12345411");
        return dto;
    }

    /**
     * 帳票CSV内容照会_定期預金（自継）大口定期利息計算
     *
     * @param requestDto お知らせ閲覧ABAリクエストDTO
     * @return お知らせ閲覧レスポンスDTO
     */
    @Override
    public InquireReport006AbaResponseDto abaInquireReportCsv006(ElectronicIssueAbaRequestDto requestDto) {

        // Dummyデータ
        InquireReport006AbaResponseDto dto = new InquireReport006AbaResponseDto();

        /**
         * 帳票バージョン
         */
        dto.setFormVersion("1.01");

        /**
         * 本状作成日
         */
        dto.setBookCreateDate("20220303");

        List<AutomaticRenewalTimeDepositInterestCalculationDto> dtoList = new ArrayList<AutomaticRenewalTimeDepositInterestCalculationDto>();

        /**
         * 自動継続定期預金お利息計算明細表リスト
         */
        AutomaticRenewalTimeDepositInterestCalculationDto automaticRenewalTimeDepositInterestCalculationDto = new AutomaticRenewalTimeDepositInterestCalculationDto();

        /**
         * 預金番号
         */
        automaticRenewalTimeDepositInterestCalculationDto.setDepositNumber("001");

        /**
         * 種類
         */
        automaticRenewalTimeDepositInterestCalculationDto.setType("積立");

        /**
         * 取扱種類
         */
        automaticRenewalTimeDepositInterestCalculationDto.setHandlingType("定期");

        /**
         * お預り金額
         */
        automaticRenewalTimeDepositInterestCalculationDto.setDepositAmount("1000");

        /**
         * 利率
         */
        automaticRenewalTimeDepositInterestCalculationDto.setInterestRate("1.156");

        /**
         * 税区分
         */
        automaticRenewalTimeDepositInterestCalculationDto.setTaxType("個人税");

        /**
         * 期日
         */
        automaticRenewalTimeDepositInterestCalculationDto.setExpiryDate("20220408");

        /**
         * 計算期間
         */
        automaticRenewalTimeDepositInterestCalculationDto.setCountDuration("24");

        /**
         * 計算期間単位
         */
        automaticRenewalTimeDepositInterestCalculationDto.setCountDurationUnit("日");

        /**
         * お利息
         */
        automaticRenewalTimeDepositInterestCalculationDto.setInterestAmount("1101");

        /**
         * お利息_国税
         */
        automaticRenewalTimeDepositInterestCalculationDto.setInterestNationalTax("1201");

        /**
         * お利息_地方税
         */
        automaticRenewalTimeDepositInterestCalculationDto.setInterestLocalTax("1301");

        /**
         * お利息_差引お利息
         */
        automaticRenewalTimeDepositInterestCalculationDto.setInterestDeductedInterestAmount("134568");

        /**
         * 支払調書文言１２
         */
        automaticRenewalTimeDepositInterestCalculationDto.setPaymentRecordValue12("利子税を清算");

        /**
         * 新元金
         */
        automaticRenewalTimeDepositInterestCalculationDto.setNewPrincipalAmount("6000");

        /**
         * 備考１
         */
        automaticRenewalTimeDepositInterestCalculationDto.setRemark1("お利息を元金に組み入れます");

        /**
         * 備考２
         */
        automaticRenewalTimeDepositInterestCalculationDto.setRemark2("備考２");

        /**
         * 備考３
         */
        automaticRenewalTimeDepositInterestCalculationDto.setRemark3("備考３");

        /**
         * 子供お預り金額
         */
        automaticRenewalTimeDepositInterestCalculationDto.setChildDepositAmount("7000");

        /**
         * 子供利率
         */
        automaticRenewalTimeDepositInterestCalculationDto.setChildInterestRate("0.011");

        /**
         * 子供税区分
         */
        automaticRenewalTimeDepositInterestCalculationDto.setChildTaxType("マル優");

        /**
         * 子供期日
         */
        automaticRenewalTimeDepositInterestCalculationDto.setChildExpiryDate("20220101");

        /**
         * 子供計算期間
         */
        automaticRenewalTimeDepositInterestCalculationDto.setChildCountDuration("21");

        /**
         * 子供計算期間単位
         */
        automaticRenewalTimeDepositInterestCalculationDto.setChildCountDurationUnit("日");

        /**
         * 子供お利息
         */
        automaticRenewalTimeDepositInterestCalculationDto.setChildInterestAmount("770");

        /**
         * 子供お利息_国税
         */
        automaticRenewalTimeDepositInterestCalculationDto.setChildInterestNationalTax("800");

        /**
         * 子供お利息_地方税
         */
        automaticRenewalTimeDepositInterestCalculationDto.setChildInterestLocalTax("600");

        /**
         * 子供お利息_差引お利息
         */
        automaticRenewalTimeDepositInterestCalculationDto.setChildInterestDeductedInterestAmount("1455");

        /**
         * 支払調書文言１１
         */
        automaticRenewalTimeDepositInterestCalculationDto.setPaymentRecordValue11("利子税を清算");

        /**
         * 親子有区分
         */
        automaticRenewalTimeDepositInterestCalculationDto.setParentChildFlag("1");

        /**
         * 子供支払区分
         */
        automaticRenewalTimeDepositInterestCalculationDto.setChildPaymentFlag("0");
        /**
         * 自動継続定期預金お利息計算明細表リスト
         */
        AutomaticRenewalTimeDepositInterestCalculationDto automaticRenewalTimeDepositInterestCalculationDto2 = new AutomaticRenewalTimeDepositInterestCalculationDto();

        /**
         * 預金番号
         */
        automaticRenewalTimeDepositInterestCalculationDto2.setDepositNumber("002");

        /**
         * 種類
         */
        automaticRenewalTimeDepositInterestCalculationDto2.setType("積立");

        /**
         * 取扱種類
         */
        automaticRenewalTimeDepositInterestCalculationDto2.setHandlingType("定期");

        /**
         * お預り金額
         */
        automaticRenewalTimeDepositInterestCalculationDto2.setDepositAmount("2000");

        /**
         * 利率
         */
        automaticRenewalTimeDepositInterestCalculationDto2.setInterestRate("2.156");

        /**
         * 税区分
         */
        automaticRenewalTimeDepositInterestCalculationDto2.setTaxType("個人税");

        /**
         * 期日
         */
        automaticRenewalTimeDepositInterestCalculationDto2.setExpiryDate("20220508");

        /**
         * 計算期間
         */
        automaticRenewalTimeDepositInterestCalculationDto2.setCountDuration("12");

        /**
         * 計算期間単位
         */
        automaticRenewalTimeDepositInterestCalculationDto2.setCountDurationUnit("日");

        /**
         * お利息
         */
        automaticRenewalTimeDepositInterestCalculationDto2.setInterestAmount("2101");

        /**
         * お利息_国税
         */
        automaticRenewalTimeDepositInterestCalculationDto2.setInterestNationalTax("2201");

        /**
         * お利息_地方税
         */
        automaticRenewalTimeDepositInterestCalculationDto2.setInterestLocalTax("2301");

        /**
         * お利息_差引お利息
         */
        automaticRenewalTimeDepositInterestCalculationDto2.setInterestDeductedInterestAmount("234568");

        /**
         * 支払調書文言１２
         */
        automaticRenewalTimeDepositInterestCalculationDto2.setPaymentRecordValue12("利子税を清算");

        /**
         * 新元金
         */
        automaticRenewalTimeDepositInterestCalculationDto2.setNewPrincipalAmount("26000");

        /**
         * 備考１
         */
        automaticRenewalTimeDepositInterestCalculationDto2.setRemark1("お利息を元金に組み入れます");

        /**
         * 備考２
         */
        automaticRenewalTimeDepositInterestCalculationDto2.setRemark2("備考２");

        /**
         * 備考３
         */
        automaticRenewalTimeDepositInterestCalculationDto2.setRemark3("備考３");

        /**
         * 子供お預り金額
         */
        automaticRenewalTimeDepositInterestCalculationDto2.setChildDepositAmount("27000");

        /**
         * 子供利率
         */
        automaticRenewalTimeDepositInterestCalculationDto2.setChildInterestRate("2.011");

        /**
         * 子供税区分
         */
        automaticRenewalTimeDepositInterestCalculationDto2.setChildTaxType("マル優");

        /**
         * 子供期日
         */
        automaticRenewalTimeDepositInterestCalculationDto2.setChildExpiryDate("20220201");

        /**
         * 子供計算期間
         */
        automaticRenewalTimeDepositInterestCalculationDto2.setChildCountDuration("22");

        /**
         * 子供計算期間単位
         */
        automaticRenewalTimeDepositInterestCalculationDto2.setChildCountDurationUnit("日");

        /**
         * 子供お利息
         */
        automaticRenewalTimeDepositInterestCalculationDto2.setChildInterestAmount("770");

        /**
         * 子供お利息_国税
         */
        automaticRenewalTimeDepositInterestCalculationDto2.setChildInterestNationalTax("800");

        /**
         * 子供お利息_地方税
         */
        automaticRenewalTimeDepositInterestCalculationDto2.setChildInterestLocalTax("600");

        /**
         * 子供お利息_差引お利息
         */
        automaticRenewalTimeDepositInterestCalculationDto2.setChildInterestDeductedInterestAmount("2455");

        /**
         * 支払調書文言１１
         */
        automaticRenewalTimeDepositInterestCalculationDto2.setPaymentRecordValue11("利子税を清算");

        /**
         * 親子有区分
         */
        automaticRenewalTimeDepositInterestCalculationDto2.setParentChildFlag("0");

        /**
         * 子供支払区分
         */
        automaticRenewalTimeDepositInterestCalculationDto2.setChildPaymentFlag("1");
        dtoList.add(automaticRenewalTimeDepositInterestCalculationDto);
        dtoList.add(automaticRenewalTimeDepositInterestCalculationDto2);
        dto.setAutomaticRenewalTimeDepositInterestCalculationList(dtoList);

        /**
         * 取扱店名
         */
        dto.setBranchKanjiName("東京都");

        /**
         * 取扱電話番号
         */
        dto.setBranchPhoneNumber("030-12345411");
        return dto;
    }

    /**
     * 帳票CSV内容照会_定期預金（自由金利）期日案内
     *
     * @param requestDto お知らせ閲覧ABAリクエストDTO
     * @return お知らせ閲覧レスポンスDTO
     */
    @Override
    public InquireReport007AbaResponseDto abaInquireReportCsv007(ElectronicIssueAbaRequestDto requestDto) {

        // Dummyデータ
        InquireReport007AbaResponseDto dto = new InquireReport007AbaResponseDto();

        /**
         * 帳票バージョン
         */
        dto.setFormVersion("1.01");

        /**
         * 本状作成日
         */
        dto.setBookCreateDate("20220303");

        List<TimeDepositDateDto> dtoList = new ArrayList<TimeDepositDateDto>();

        /**
         * 定期預金等期日明細表リスト
         */
        TimeDepositDateDto timeDepositDateDto = new TimeDepositDateDto();

        /**
         * 預金番号
         */
        timeDepositDateDto.setDepositNumber("001");

        /**
         * 種類
         */
        timeDepositDateDto.setType("ジャンボ");

        /**
         * 取扱種類
         */
        timeDepositDateDto.setHandlingType("（継続元加）");

        /**
         * お預り金額
         */
        timeDepositDateDto.setDepositAmount("1000");

        /**
         * 利率
         */
        timeDepositDateDto.setInterestRate("1.156");

        /**
         * 税区分
         */
        timeDepositDateDto.setTaxType("総合課税");

        /**
         * 期日
         */
        timeDepositDateDto.setExpiryDate("20220408");

        /**
         * 計算期間
         */
        timeDepositDateDto.setCountDuration("24");

        /**
         * 計算期間単位
         */
        timeDepositDateDto.setCountDurationUnit("日");

        /**
         * お利息
         */
        timeDepositDateDto.setInterestAmount("1101");

        /**
         * お利息_国税
         */
        timeDepositDateDto.setInterestNationalTax("1201");

        /**
         * お利息_地方税
         */
        timeDepositDateDto.setInterestLocalTax("1301");

        /**
         * お利息_差引お利息
         */
        timeDepositDateDto.setInterestDeductedInterestAmount("134568");

        /**
         * 支払調書文言１２
         */
        timeDepositDateDto.setPaymentRecordValue12("利子税を清算");

        /**
         * 継続後の新元金
         */
        timeDepositDateDto.setNewPrincipalAfterContinuation("6000");

        /**
         * 備考１
         */
        timeDepositDateDto.setRemark1("お利息を元金に組み入れます");

        /**
         * 備考２
         */
        timeDepositDateDto.setRemark2("備考２");

        /**
         * 備考３
         */
        timeDepositDateDto.setRemark3("備考３");

        /**
         * 子供お預り金額
         */
        timeDepositDateDto.setChildDepositAmount("7000");

        /**
         * 子供利率
         */
        timeDepositDateDto.setChildInterestRate("0.011");

        /**
         * 子供税区分
         */
        timeDepositDateDto.setChildTaxType("マル優");

        /**
         * 子供期日
         */
        timeDepositDateDto.setChildExpiryDate("20220101");

        /**
         * 子供計算期間
         */
        timeDepositDateDto.setChildCountDuration("21");

        /**
         * 子供計算期間単位
         */
        timeDepositDateDto.setChildCountDurationUnit("日");

        /**
         * 子供お利息
         */
        timeDepositDateDto.setChildInterestAmount("770");

        /**
         * 子供お利息_国税
         */
        timeDepositDateDto.setChildInterestNationalTax("800");

        /**
         * 子供お利息_地方税
         */
        timeDepositDateDto.setChildInterestLocalTax("600");

        /**
         * 子供お利息_差引お利息
         */
        timeDepositDateDto.setChildInterestDeductedInterestAmount("1455");

        /**
         * 支払調書文言１１
         */
        timeDepositDateDto.setPaymentRecordValue11("利子税を清算");

        /**
         * 親子有区分
         */
        timeDepositDateDto.setParentChildFlag("1");

        /**
         * 子供支払区分
         */
        timeDepositDateDto.setChildPaymentFlag("0");

        /**
         * 法人割廃止表示
         */
        timeDepositDateDto.setCorporationAbolishExpression("0");

        /**
         * マル優改組表示
         */
        timeDepositDateDto.setDeclarationReorganizeExpression("0");

        /**
         * 定期預金等期日明細表リスト
         */
        TimeDepositDateDto timeDepositDateDto2 = new TimeDepositDateDto();

        /**
         * 預金番号
         */
        timeDepositDateDto2.setDepositNumber("002");

        /**
         * 種類
         */
        timeDepositDateDto2.setType("ジャンボ");

        /**
         * 取扱種類
         */
        timeDepositDateDto2.setHandlingType("（継続元加）");

        /**
         * お預り金額
         */
        timeDepositDateDto2.setDepositAmount("2000");

        /**
         * 利率
         */
        timeDepositDateDto2.setInterestRate("2.156");

        /**
         * 税区分
         */
        timeDepositDateDto2.setTaxType("総合課税");

        /**
         * 期日
         */
        timeDepositDateDto2.setExpiryDate("20220508");

        /**
         * 計算期間
         */
        timeDepositDateDto2.setCountDuration("24");

        /**
         * 計算期間単位
         */
        timeDepositDateDto2.setCountDurationUnit("日");

        /**
         * お利息
         */
        timeDepositDateDto2.setInterestAmount("2101");

        /**
         * お利息_国税
         */
        timeDepositDateDto2.setInterestNationalTax("2201");

        /**
         * お利息_地方税
         */
        timeDepositDateDto2.setInterestLocalTax("1301");

        /**
         * お利息_差引お利息
         */
        timeDepositDateDto2.setInterestDeductedInterestAmount("234568");

        /**
         * 支払調書文言１２
         */
        timeDepositDateDto2.setPaymentRecordValue12("利子税を清算");

        /**
         * 継続後の新元金
         */
        timeDepositDateDto2.setNewPrincipalAfterContinuation("6000");

        /**
         * 備考１
         */
        timeDepositDateDto2.setRemark1("お利息を元金に組み入れます");

        /**
         * 備考２
         */
        timeDepositDateDto2.setRemark2("備考２");

        /**
         * 備考３
         */
        timeDepositDateDto2.setRemark3("備考３");

        /**
         * 子供お預り金額
         */
        timeDepositDateDto2.setChildDepositAmount("7000");

        /**
         * 子供利率
         */
        timeDepositDateDto2.setChildInterestRate("2.011");

        /**
         * 子供税区分
         */
        timeDepositDateDto2.setChildTaxType("マル優");

        /**
         * 子供期日
         */
        timeDepositDateDto2.setChildExpiryDate("20220201");

        /**
         * 子供計算期間
         */
        timeDepositDateDto2.setChildCountDuration("21");

        /**
         * 子供計算期間単位
         */
        timeDepositDateDto2.setChildCountDurationUnit("日");

        /**
         * 子供お利息
         */
        timeDepositDateDto2.setChildInterestAmount("770");

        /**
         * 子供お利息_国税
         */
        timeDepositDateDto2.setChildInterestNationalTax("800");

        /**
         * 子供お利息_地方税
         */
        timeDepositDateDto2.setChildInterestLocalTax("600");

        /**
         * 子供お利息_差引お利息
         */
        timeDepositDateDto2.setChildInterestDeductedInterestAmount("1455");

        /**
         * 支払調書文言１１
         */
        timeDepositDateDto2.setPaymentRecordValue11("利子税を清算");

        /**
         * 親子有区分
         */
        timeDepositDateDto2.setParentChildFlag("0");

        /**
         * 子供支払区分
         */
        timeDepositDateDto2.setChildPaymentFlag("1");

        /**
         * 法人割廃止表示
         */
        timeDepositDateDto2.setCorporationAbolishExpression("1");

        /**
         * マル優改組表示
         */
        timeDepositDateDto2.setDeclarationReorganizeExpression("1");
        dtoList.add(timeDepositDateDto);
        dtoList.add(timeDepositDateDto2);
        dto.setTimeDepositDateList(dtoList);

        /**
         * マル優申告限度額
         */
        dto.setDeclarationLimitAmount("10011");

        /**
         * ご利用額(預金)
         */
        dto.setUsageAmount("11111211");

        /**
         * 取扱店名
         */
        dto.setBranchKanjiName("東京都");

        /**
         * 取扱電話番号
         */
        dto.setBranchPhoneNumber("030-12345411");
        return dto;
    }

    /**
     * 帳票CSV内容照会_借入終了案内
     *
     * @param requestDto お知らせ閲覧ABAリクエストDTO
     * @return お知らせ閲覧レスポンスDTO
     */
    @Override
    public InquireReport008AbaResponseDto abaInquireReportCsv008(ElectronicIssueAbaRequestDto requestDto) {

        // Dummyデータ
        InquireReport008AbaResponseDto dto = new InquireReport008AbaResponseDto();

        /**
         * 帳票バージョン
         */
        dto.setFormVersion("1.01");

        /**
         * 共通作成日付
         */
        dto.setComCreateDate("20220303");

        /**
         * 取扱店名
         */
        dto.setBranchKanjiName("東京都");

        /**
         * 取扱電話番号
         */
        dto.setBranchPhoneNumber("030-12345411");

        /**
         * 作成通番
         */
        dto.setCreateSeqNo("1221");

        /**
         * 発行区分
         */
        dto.setIssueType("1");

        /**
         * 完済日
         */
        dto.setLiquidationDate("20220202");
        return dto;
    }

    /**
     * 帳票CSV内容照会_総合口座決算案内
     *
     * @param requestDto お知らせ閲覧ABAリクエストDTO
     * @return お知らせ閲覧レスポンスDTO
     */
    @Override
    public InquireReport009AbaResponseDto abaInquireReportCsv009(ElectronicIssueAbaRequestDto requestDto) {

        // Dummyデータ
        InquireReport009AbaResponseDto dto = new InquireReport009AbaResponseDto();

        /**
         * 帳票バージョン
         */
        dto.setFormVersion("1.01");

        /**
         * 共通作成日付
         */
        dto.setComCreateDate("20220101");

        /**
         * お知らせ文言
         */
        dto.setNotificationValue("＜城南総合口座＞決算のお知らせ");

        /**
         * 文言１１
         */
        dto.setValue11("毎度お引立てありがとうございます");

        /**
         * 文言２１
         */
        dto.setValue21("さて、この度あなた様にご利用いただいてお");

        /**
         * 文言２２
         */
        dto.setValue22("さて、この度あなた様にご利用いただいてお");

        /**
         * 文言３１
         */
        dto.setValue31("２０２０年０３月０８日に");

        /**
         * 文言３２
         */
        dto.setValue32("いたしましたので、下記の通りお知らせいたします。");

        /**
         * 決算日の残高_普通預金
         */
        dto.setBalanceOnClosingDateOrdinaryDeposit("6888");

        /**
         * 決算日の残高_お借入
         */
        dto.setBalanceOnClosingDateBorrowing("999");

        /**
         * お利息
         */
        dto.setInterestAmount("111");

        /**
         * お利息の内訳_総合口座
         */
        dto.setBreakdownOfInterestGeneralAccount("100");

        /**
         * お利息の内訳_カードローン
         */
        dto.setBreakdownOfInterestCardLoan("200");

        /**
         * お利息差引後の残高_普通預金
         */
        dto.setBalanceAfterInterestDeductionOrdinaryDeposit("400");

        /**
         * お利息差引後の残高_お借入
         */
        dto.setBalanceAfterInterestDeductionBorrowing("800");

        /**
         * お借入限度超過額
         */
        dto.setOverBorrowingLimit("300");

        /**
         * 取扱店名
         */
        dto.setBranchKanjiName("東京都");

        /**
         * 取扱電話番号
         */
        dto.setBranchPhoneNumber("030-12345411");
        return dto;
    }

    /**
     * 帳票CSV内容照会_融資期日案内
     *
     * @param requestDto お知らせ閲覧ABAリクエストDTO
     * @return お知らせ閲覧レスポンスDTO
     */
    @Override
    public InquireReport010AbaResponseDto abaInquireReportCsv010(ElectronicIssueAbaRequestDto requestDto) {

        // Dummyデータ
        InquireReport010AbaResponseDto dto = new InquireReport010AbaResponseDto();

        /**
         * 帳票バージョン
         */
        dto.setFormVersion("1.01");

        /**
         * 作成日
         */
        dto.setCreateDate("20220303");

        List<LoanDateDto> dtoList = new ArrayList<LoanDateDto>();

        /**
         * 融資期日明細表リスト
         */
        LoanDateDto loanDateDto = new LoanDateDto();

        /**
         * ご融資科目
         */
        loanDateDto.setLoanItems("手形貸付");

        /**
         * ご融資番号
         */
        loanDateDto.setLoanNumber("1001");

        /**
         * ご返済期日
         */
        loanDateDto.setRepaymentDate("20220101");

        /**
         * ご融資年月日
         */
        loanDateDto.setLoanDate("20220102");

        /**
         * ご融資金の現在高
         */
        loanDateDto.setCurrentAmountOfLoan("800");

        /**
         * 文言０１
         */
        loanDateDto.setValue01("この期日にご返済が遅れますと残元金に対して年１４");

        /**
         * 文言０２
         */
        loanDateDto.setValue02("％の割合で損害金が加算されることがございますので");

        /**
         * 文言０３
         */
        loanDateDto.setValue03("期日までにご来店くださるようお願いいたします。");

        /**
         * 融資期日明細表リスト
         */
        LoanDateDto loanDateDto2 = new LoanDateDto();

        /**
         * ご融資科目
         */
        loanDateDto.setLoanItems("手形貸付");

        /**
         * ご融資番号
         */
        loanDateDto2.setLoanNumber("1001");

        /**
         * ご返済期日
         */
        loanDateDto2.setRepaymentDate("20220101");

        /**
         * ご融資年月日
         */
        loanDateDto2.setLoanDate("20220102");

        /**
         * ご融資金の現在高
         */
        loanDateDto2.setCurrentAmountOfLoan("800");

        /**
         * 文言０１
         */
        loanDateDto2.setValue01("この期日にご返済が遅れますと残元金に対して年１４");

        /**
         * 文言０２
         */
        loanDateDto2.setValue02("％の割合で損害金が加算されることがございますので");

        /**
         * 文言０３
         */
        loanDateDto2.setValue03("期日までにご来店くださるようお願いいたします。");
        dtoList.add(loanDateDto);
        dtoList.add(loanDateDto2);
        dto.setLoanDateList(dtoList);

        /**
         * 取扱店名
         */
        dto.setBranchKanjiName("東京都");

        /**
         * 取扱電話番号
         */
        dto.setBranchPhoneNumber("030-12345411");
        return dto;
    }

    /**
     * 帳票CSV内容照会_自動送金取扱終了案内
     *
     * @param requestDto お知らせ閲覧ABAリクエストDTO
     * @return お知らせ閲覧レスポンスDTO
     */
    @Override
    public InquireReport011AbaResponseDto abaInquireReportCsv011(ElectronicIssueAbaRequestDto requestDto) {

        // Dummyデータ
        InquireReport011AbaResponseDto dto = new InquireReport011AbaResponseDto();

        /**
         * 帳票バージョン
         */
        dto.setFormVersion("1.01");

        /**
         * 本状作成日
         */
        dto.setBookCreateDate("20220303");

        /**
         * 振込方式区分
         */
        dto.setRemittanceMethodFlag("1");

        /**
         * 契約日
         */
        dto.setContractDate("20220102");

        /**
         * 開始年月
         */
        dto.setStartYearMonth("202201");

        /**
         * 終了年月
         */
        dto.setEndYearMonth("202205");

        /**
         * 預金種目
         */
        dto.setDepositTypeName("001");

        /**
         * 振込指定口座
         */
        dto.setAccountNumber("4404");

        /**
         * 振込先銀行名
         */
        dto.setBankName("ﾋｺﾞ");

        /**
         * 振込先支店名
         */
        dto.setBranchName("ﾔﾂｼﾛ");

        /**
         * 登録番号
         */
        dto.setRegisterNumber("0006");

        /**
         * 受取人名
         */
        dto.setBeneficiaryName("ﾑﾗｲ 様");

        /**
         * 振込内容
         */
        dto.setRemittanceMessage("テナント料");

        /**
         * 期限
         */
        dto.setDeadLine("20220405");

        /**
         * 新開始日
         */
        dto.setNewStartDate("20220405");

        /**
         * 振込日(毎月)
         */
        dto.setRemittanceDate("10");

        /**
         * 振込金額(毎月)
         */
        dto.setRemittanceAmount("1001");

        /**
         * 振込月１
         */
        dto.setRemittanceMonth1("3");

        /**
         * 振込金額(特定月)１
         */
        dto.setRemittanceAmountSpeMonth1("500");

        /**
         * 振込月２
         */
        dto.setRemittanceMonth2("6");

        /**
         * 振込金額(特定月)２
         */
        dto.setRemittanceAmountSpeMonth1("600");

        /**
         * 引落指定口座
         */
        dto.setWithdrawalAccountNumber("123456789012");

        /**
         * 固定休日送金１１
         */
        dto.setDefiniteHolidayRemittance11("振込日が休日の場合は、");

        /**
         * 固定休日送金１２
         */
        dto.setDefiniteHolidayRemittance12("前営業日扱いとなります。");

        /**
         * 出金科目
         */
        dto.setPaymentSubjectNameValue("普通");

        /**
         * 出金口座番号
         */
        dto.setPaymentAccountNumber("88011");

        /**
         * 不定休日送金
         */
        dto.setIndefiniteHolidayRemittance("振込日が休日の場合は翌営業日扱いとなります。");

        /**
         * 一月振込日
         */
        dto.setRemittanceDate1("1");

        /**
         * 一月お振込金額
         */
        dto.setRemittanceAmount1("100001");

        /**
         * 二月振込日
         */
        dto.setRemittanceDate2("2");

        /**
         * 二月お振込金額
         */
        dto.setRemittanceAmount2("200001");

        /**
         * 三月振込日
         */
        dto.setRemittanceDate3("3");

        /**
         * 三月お振込金額
         */
        dto.setRemittanceAmount3("300001");

        /**
         * 四月振込日
         */
        dto.setRemittanceDate4("4");

        /**
         * 四月お振込金額
         */
        dto.setRemittanceAmount4("400001");

        /**
         * 五月振込日
         */
        dto.setRemittanceDate5("5");

        /**
         * 五月お振込金額
         */
        dto.setRemittanceAmount5("500001");

        /**
         * 六月振込日
         */
        dto.setRemittanceDate6("6");

        /**
         * 六月お振込金額
         */
        dto.setRemittanceAmount6("600001");

        /**
         * 七月振込日
         */
        dto.setRemittanceDate7("7");

        /**
         * 七月お振込金額
         */
        dto.setRemittanceAmount7("700001");

        /**
         * 八月振込日
         */
        dto.setRemittanceDate8("8");

        /**
         * 八月お振込金額
         */
        dto.setRemittanceAmount8("800001");

        /**
         * 九月振込日
         */
        dto.setRemittanceDate9("9");

        /**
         * 九月お振込金額
         */
        dto.setRemittanceAmount9("900001");

        /**
         * 十月振込日
         */
        dto.setRemittanceDate10("10");

        /**
         * 十月お振込金額
         */
        dto.setRemittanceAmount10("1000001");

        /**
         * 十一月振込日
         */
        dto.setRemittanceDate11("11");

        /**
         * 十一月お振込金額
         */
        dto.setRemittanceAmount11("1100001");

        /**
         * 十二月振込日
         */
        dto.setRemittanceDate12("12");

        /**
         * 十二月お振込金額
         */
        dto.setRemittanceAmount12("1200001");

        /**
         * 取扱店名
         */
        dto.setBranchKanjiName("東京都");

        /**
         * 取扱電話番号
         */
        dto.setBranchPhoneNumber("030-12345411");
        return dto;
    }

    /**
     * 帳票CSV内容照会_財形年金預金受取案内
     *
     * @param requestDto お知らせ閲覧ABAリクエストDTO
     * @return お知らせ閲覧レスポンスDTO
     */
    @Override
    public InquireReport012AbaResponseDto abaInquireReportCsv012(ElectronicIssueAbaRequestDto requestDto) {

        // Dummyデータ
        InquireReport012AbaResponseDto dto = new InquireReport012AbaResponseDto();

        /**
         * 帳票バージョン
         */
        dto.setFormVersion("1.01");

        /**
         * 本状作成日
         */
        dto.setBookCreateDate("20220303");

        /**
         * ご入金日
         */
        dto.setDepositDate("20220329");

        /**
         * お受取り額
         */
        dto.setReceivedAmount("1000011");

        /**
         * 最終お受取り日
         */
        dto.setLastBeneficiaryDate("20220501");

        /**
         * ご入金口座番号
         */
        dto.setDepositAccountNumber("1111100123");

        /**
         * 取扱店名
         */
        dto.setBranchKanjiName("東京都");

        /**
         * 取扱電話番号
         */
        dto.setBranchPhoneNumber("030-12345411");
        return dto;
    }

    /**
     * 帳票CSV内容照会_証貸変動金利通知
     *
     * @param requestDto お知らせ閲覧ABAリクエストDTO
     * @return お知らせ閲覧レスポンスDTO
     */
    @Override
    public InquireReport013AbaResponseDto abaInquireReportCsv013(ElectronicIssueAbaRequestDto requestDto) {

        // Dummyデータ
        InquireReport013AbaResponseDto dto = new InquireReport013AbaResponseDto();

        /**
         * 帳票バージョン
         */
        dto.setFormVersion("1.01");

        /**
         * 本状作成日
         */
        dto.setBookCreateDate("2022-03-03");

        /**
         * お借入利率の変更前_日付
         */
        dto.setBeforeUpdateDate("2022-03-10");

        /**
         * お借入利率の変更前_利率
         */
        dto.setBeforeUpdateRate("0.120");

        /**
         * お借入利率の変更後_日付
         */
        dto.setAfterUpdateDate("2022-03-15");

        /**
         * お借入利率の変更後_利率
         */
        dto.setAfterUpdateRate("0.125");

        /**
         * 変更幅
         */
        dto.setChangeWild("0.005");

        /**
         * 今までのお借入利率
         */
        dto.setNowRate("1.260");

        /**
         * 新しいお借入利率
         */
        dto.setNewRate("1.265");

        /**
         * 取扱店名
         */
        dto.setBranchKanjiName("東京都");

        /**
         * 取扱電話番号
         */
        dto.setBranchPhoneNumber("030-12345411");
        return dto;
    }

    /**
     * 帳票CSV内容照会_借入返済通知
     *
     * @param requestDto お知らせ閲覧ABAリクエストDTO
     * @return お知らせ閲覧レスポンスDTO
     */
    @Override
    public InquireReport014AbaResponseDto abaInquireReportCsv014(ElectronicIssueAbaRequestDto requestDto) {

        // Dummyデータ
        InquireReport014AbaResponseDto dto = new InquireReport014AbaResponseDto();

        /**
         * 帳票バージョン
         */

        dto.setFormVersion("1.01");

        /**
         * 本状作成日
         */
        dto.setBookCreateDate("2022-03-03");

        /**
         * 現在お借入残高
         */
        dto.setBorrowingBalance("10000110");

        /**
         * 内毎月分残高
         */
        dto.setMonthlyBalance("10000000");

        /**
         * 内ボーナス分残高
         */
        dto.setBalanceForBonus("110");

        /**
         * 新しい毎回返済額
         */
        dto.setRepaymentAmountForEachPayment("80000");

        /**
         * ご返済日
         */
        dto.setRepaymentDate("10");

        /**
         * 新しいボーナス返済額
         */
        dto.setNewBonusRepaymentAmount("75000");

        /**
         * loanDateDto2１
         */
        dto.setBonusRepaymentMonth1("5");

        /**
         * ボーナス返済月２
         */
        dto.setBonusRepaymentMonth2("12");

        /**
         * 期日
         */
        dto.setExpiryDate("2022-01-01");

        /**
         * 作成日
         */
        dto.setCreatedDate("2022-01-05");

        /**
         * お借入日
         */
        dto.setBorrowingDate("2022-02-05");

        /**
         * 利率変更幅(B)-(A)
         */
        dto.setRateChangeRange("1.115");

        /**
         * (B)新しい利率
         */
        dto.setNewRate("1.25");

        /**
         * (B)新しい利率_年月日現在
         */
        dto.setNewRateDate("2022-02-06");

        /**
         * (A)今迄の利率
         */
        dto.setNowRate("2.25");

        /**
         * (A)今迄の利率_年月日現在
         */
        dto.setNowRateDate("2022-04-05");

        List<ContractPaymentDto> dtoList = new ArrayList<ContractPaymentDto>();

        /**
         * 約定払込リスト
         */
        ContractPaymentDto dto1 = new ContractPaymentDto();

        /**
         * 約定払込年月日
         */
        dto1.setContractPaymentDate("2022-04-05");

        /**
         * 合計未払利息額
         */
        dto1.setTotalAccruedInterest("11111");

        /**
         * 約定払込リスト
         */
        ContractPaymentDto dto2 = new ContractPaymentDto();

        /**
         * 約定払込年月日
         */
        dto2.setContractPaymentDate("2022-05-05");

        /**
         * 合計未払利息額
         */
        dto2.setTotalAccruedInterest("12221");

        /**
         * 約定払込リスト
         */
        ContractPaymentDto dto3 = new ContractPaymentDto();

        /**
         * 約定払込年月日
         */
        dto3.setContractPaymentDate("2022-06-05");

        /**
         * 合計未払利息額
         */
        dto3.setTotalAccruedInterest("13331");

        /**
         * 約定払込リスト
         */
        ContractPaymentDto dto4 = new ContractPaymentDto();

        /**
         * 約定払込年月日
         */
        dto4.setContractPaymentDate("2022-07-05");

        /**
         * 合計未払利息額
         */
        dto4.setTotalAccruedInterest("14411");

        /**
         * 約定払込リスト
         */
        ContractPaymentDto dto5 = new ContractPaymentDto();

        /**
         * 約定払込年月日
         */
        dto5.setContractPaymentDate("2022-08-05");

        /**
         * 合計未払利息額
         */
        dto5.setTotalAccruedInterest("15551");

        /**
         * 約定払込リスト
         */
        ContractPaymentDto dto6 = new ContractPaymentDto();

        /**
         * 約定払込年月日
         */
        dto6.setContractPaymentDate("2022-09-05");

        /**
         * 合計未払利息額
         */
        dto6.setTotalAccruedInterest("16661");

        /**
         * 約定払込リスト
         */
        ContractPaymentDto dto7 = new ContractPaymentDto();

        /**
         * 約定払込年月日
         */
        dto7.setContractPaymentDate("2022-10-05");

        /**
         * 合計未払利息額
         */
        dto7.setTotalAccruedInterest("17771");

        /**
         * 約定払込リスト
         */
        ContractPaymentDto dto8 = new ContractPaymentDto();

        /**
         * 約定払込年月日
         */
        dto8.setContractPaymentDate("2022-11-05");

        /**
         * 合計未払利息額
         */
        dto8.setTotalAccruedInterest("18881");

        dtoList.add(dto1);
        dtoList.add(dto2);
        dtoList.add(dto3);
        dtoList.add(dto4);
        dtoList.add(dto5);
        dtoList.add(dto6);
        dtoList.add(dto7);
        dtoList.add(dto8);
        dto.setContractPaymentList(dtoList);

        List<RepaymentScheduleDto> repaymentScheduleDtoList = new ArrayList<RepaymentScheduleDto>();
        /**
         * ご返済予定表リスト
         */
        RepaymentScheduleDto repaymentScheduleDto1 = new RepaymentScheduleDto();

        /**
         * 約定払込年月日
         */
        repaymentScheduleDto1.setContractPaymentDate("2022-01-05");

        /**
         * お払込金額
         */
        repaymentScheduleDto1.setPaymentAmount("11000");

        /**
         * 残高
         */
        repaymentScheduleDto1.setBalance("1000");

        /**
         * お利息
         */
        repaymentScheduleDto1.setInterestAmount("100");

        /**
         * ボーナス分お払込金額
         */
        repaymentScheduleDto1.setBonusPaymentAmount("100000");

        /**
         * ボーナス分残高
         */
        repaymentScheduleDto1.setBonusBalance("10000");

        /**
         * ボーナス分_お利息
         */
        repaymentScheduleDto1.setBonusInterest("1100");

        /**
         * ご返済予定表リスト
         */
        RepaymentScheduleDto repaymentScheduleDto2 = new RepaymentScheduleDto();

        /**
         * 約定払込年月日
         */
        repaymentScheduleDto2.setContractPaymentDate("2022-02-05");

        /**
         * お払込金額
         */
        repaymentScheduleDto2.setPaymentAmount("12000");

        /**
         * 残高
         */
        repaymentScheduleDto2.setBalance("2000");

        /**
         * お利息
         */
        repaymentScheduleDto2.setInterestAmount("200");

        /**
         * ボーナス分お払込金額
         */
        repaymentScheduleDto2.setBonusPaymentAmount("200000");

        /**
         * ボーナス分残高
         */
        repaymentScheduleDto2.setBonusBalance("20000");

        /**
         * ボーナス分_お利息
         */
        repaymentScheduleDto2.setBonusInterest("1200");

        /**
         * ご返済予定表リスト
         */
        RepaymentScheduleDto repaymentScheduleDto3 = new RepaymentScheduleDto();

        /**
         * 約定払込年月日
         */
        repaymentScheduleDto3.setContractPaymentDate("2022-03-05");

        /**
         * お払込金額
         */
        repaymentScheduleDto3.setPaymentAmount("13000");

        /**
         * 残高
         */
        repaymentScheduleDto3.setBalance("3000");

        /**
         * お利息
         */
        repaymentScheduleDto3.setInterestAmount("300");

        /**
         * ボーナス分お払込金額
         */
        repaymentScheduleDto3.setBonusPaymentAmount("300000");

        /**
         * ボーナス分残高
         */
        repaymentScheduleDto3.setBonusBalance("30000");

        /**
         * ボーナス分_お利息
         */
        repaymentScheduleDto3.setBonusInterest("1300");

        /**
         * ご返済予定表リスト
         */
        RepaymentScheduleDto repaymentScheduleDto4 = new RepaymentScheduleDto();

        /**
         * 約定払込年月日
         */
        repaymentScheduleDto4.setContractPaymentDate("2022-04-05");

        /**
         * お払込金額
         */
        repaymentScheduleDto4.setPaymentAmount("14000");

        /**
         * 残高
         */
        repaymentScheduleDto4.setBalance("4000");

        /**
         * お利息
         */
        repaymentScheduleDto4.setInterestAmount("400");

        /**
         * ボーナス分お払込金額
         */
        repaymentScheduleDto4.setBonusPaymentAmount("400000");

        /**
         * ボーナス分残高
         */
        repaymentScheduleDto4.setBonusBalance("40000");

        /**
         * ボーナス分_お利息
         */
        repaymentScheduleDto4.setBonusInterest("1400");

        /**
         * ご返済予定表リスト
         */
        RepaymentScheduleDto repaymentScheduleDto5 = new RepaymentScheduleDto();

        /**
         * 約定払込年月日
         */
        repaymentScheduleDto5.setContractPaymentDate("2022-05-05");

        /**
         * お払込金額
         */
        repaymentScheduleDto5.setPaymentAmount("15000");

        /**
         * 残高
         */
        repaymentScheduleDto5.setBalance("5000");

        /**
         * お利息
         */
        repaymentScheduleDto5.setInterestAmount("500");

        /**
         * ボーナス分お払込金額
         */
        repaymentScheduleDto5.setBonusPaymentAmount("500000");

        /**
         * ボーナス分残高
         */
        repaymentScheduleDto5.setBonusBalance("50000");

        /**
         * ボーナス分_お利息
         */
        repaymentScheduleDto5.setBonusInterest("1500");

        /**
         * ご返済予定表リスト
         */
        RepaymentScheduleDto repaymentScheduleDto6 = new RepaymentScheduleDto();

        /**
         * 約定払込年月日
         */
        repaymentScheduleDto6.setContractPaymentDate("2022-06-05");

        /**
         * お払込金額
         */
        repaymentScheduleDto6.setPaymentAmount("16000");

        /**
         * 残高
         */
        repaymentScheduleDto6.setBalance("6000");

        /**
         * お利息
         */
        repaymentScheduleDto6.setInterestAmount("600");

        /**
         * ボーナス分お払込金額
         */
        repaymentScheduleDto6.setBonusPaymentAmount("600000");

        /**
         * ボーナス分残高
         */
        repaymentScheduleDto6.setBonusBalance("60000");

        /**
         * ボーナス分_お利息
         */
        repaymentScheduleDto6.setBonusInterest("1600");

        /**
         * ご返済予定表リスト
         */
        RepaymentScheduleDto repaymentScheduleDto7 = new RepaymentScheduleDto();

        /**
         * 約定払込年月日
         */
        repaymentScheduleDto7.setContractPaymentDate("2022-07-05");

        /**
         * お払込金額
         */
        repaymentScheduleDto7.setPaymentAmount("17000");

        /**
         * 残高
         */
        repaymentScheduleDto7.setBalance("7000");

        /**
         * お利息
         */
        repaymentScheduleDto7.setInterestAmount("700");

        /**
         * ボーナス分お払込金額
         */
        repaymentScheduleDto7.setBonusPaymentAmount("700000");

        /**
         * ボーナス分残高
         */
        repaymentScheduleDto7.setBonusBalance("70000");

        /**
         * ボーナス分_お利息
         */
        repaymentScheduleDto7.setBonusInterest("1700");
        repaymentScheduleDtoList.add(repaymentScheduleDto1);
        repaymentScheduleDtoList.add(repaymentScheduleDto2);
        repaymentScheduleDtoList.add(repaymentScheduleDto3);
        repaymentScheduleDtoList.add(repaymentScheduleDto4);
        repaymentScheduleDtoList.add(repaymentScheduleDto5);
        repaymentScheduleDtoList.add(repaymentScheduleDto6);
        repaymentScheduleDtoList.add(repaymentScheduleDto7);
        dto.setRepaymentScheduleList(repaymentScheduleDtoList);

        /**
         * 取扱店名
         */
        dto.setBranchKanjiName("東京都");

        /**
         * 取扱電話番号
         */
        dto.setBranchPhoneNumber("030-12345411");
        return dto;
    }

    /**
     * 帳票CSV内容照会_当座勘定照合表
     *
     * @param requestDto お知らせ閲覧ABAリクエストDTO
     * @return お知らせ閲覧レスポンスDTO
     */
    @Override
    public InquireReport015AbaResponseDto abaInquireReportCsv015(ElectronicIssueAbaRequestDto requestDto) {

        // Dummyデータ
        InquireReport015AbaResponseDto dto = new InquireReport015AbaResponseDto();

        /**
         * 帳票バージョン
         */
        dto.setFormVersion("1.01");

        /**
         * 作成日
         */
        dto.setCreateDate("20220303");

        List<CurrentAccountDto> dtoList = new ArrayList<CurrentAccountDto>();

        /**
         * 当座勘定明細表リスト
         */
        CurrentAccountDto currentAccountDto = new CurrentAccountDto();

        /**
         * 取引年月日
         */
        currentAccountDto.setTransactionDate("20220102");

        /**
         * 入出金
         */
        currentAccountDto.setDepositsAndWithdrawals("入金");

        /**
         * 種類
         */
        currentAccountDto.setType("振替");

        /**
         * 取扱
         */
        currentAccountDto.setHandling("起算");

        /**
         * 振込人名
         */
        currentAccountDto.setTransferPersonName("ﾌﾂｳﾖｷﾝ");

        /**
         * 交換
         */
        currentAccountDto.setExchange("交換");

        /**
         * 手形番号
         */
        currentAccountDto.setBillNumber("10011");

        /**
         * お支払額
         */
        currentAccountDto.setPaymentAmount("900");

        /**
         * ご入金額
         */
        currentAccountDto.setDepositAmount("800");

        /**
         * 差引残高
         */
        currentAccountDto.setDeductionBalance("500");

        /**
         * 当座勘定明細表リスト
         */
        CurrentAccountDto currentAccountDto2 = new CurrentAccountDto();

        /**
         * 取引年月日
         */
        currentAccountDto2.setTransactionDate("20220102");

        /**
         * 入出金
         */
        currentAccountDto2.setDepositsAndWithdrawals("入金");

        /**
         * 種類
         */
        currentAccountDto2.setType("振替");

        /**
         * 取扱
         */
        currentAccountDto2.setHandling("起算");

        /**
         * 振込人名
         */
        currentAccountDto2.setTransferPersonName("ﾌﾂｳﾖｷﾝ");

        /**
         * 交換
         */
        currentAccountDto2.setExchange("交換");

        /**
         * 手形番号
         */
        currentAccountDto2.setBillNumber("10011");

        /**
         * お支払額
         */
        currentAccountDto2.setPaymentAmount("900");

        /**
         * ご入金額
         */
        currentAccountDto2.setDepositAmount("800");

        /**
         * 差引残高
         */
        currentAccountDto2.setDeductionBalance("500");
        dtoList.add(currentAccountDto);
        dtoList.add(currentAccountDto2);
        dto.setCurrentAccountList(dtoList);

        /**
         * 取扱店名
         */
        dto.setBranchKanjiName("東京都");

        /**
         * 取扱電話番号
         */
        dto.setBranchPhoneNumber("030-12345411");
        return dto;
    }

    /**
     * 帳票CSV内容照会_当座勘定照合表兼当座勘定決算通知
     *
     * @param requestDto お知らせ閲覧ABAリクエストDTO
     * @return お知らせ閲覧レスポンスDTO
     */
    @Override
    public InquireReport016AbaResponseDto abaInquireReportCsv016(ElectronicIssueAbaRequestDto requestDto) {

        // Dummyデータ
        InquireReport016AbaResponseDto dto = new InquireReport016AbaResponseDto();

        /**
         * 帳票バージョン
         */
        dto.setFormVersion("1.01");

        /**
         * 作成日
         */
        dto.setCreateDate("20220303");

        List<CurrentAccountDto> dtoList = new ArrayList<CurrentAccountDto>();

        /**
         * 当座勘定明細表リスト
         */
        CurrentAccountDto currentAccountDto = new CurrentAccountDto();

        /**
         * 取引年月日
         */
        currentAccountDto.setTransactionDate("20220102");

        /**
         * 入出金
         */
        currentAccountDto.setDepositsAndWithdrawals("入金");

        /**
         * 種類
         */
        currentAccountDto.setType("振替");

        /**
         * 取扱
         */
        currentAccountDto.setHandling("起算");

        /**
         * 振込人名
         */
        currentAccountDto.setTransferPersonName("ﾌﾂｳﾖｷﾝ");

        /**
         * 交換
         */
        currentAccountDto.setExchange("交換");

        /**
         * 手形番号
         */
        currentAccountDto.setBillNumber("10011");

        /**
         * お支払額
         */
        currentAccountDto.setPaymentAmount("900");

        /**
         * ご入金額
         */
        currentAccountDto.setDepositAmount("800");

        /**
         * 差引残高
         */
        currentAccountDto.setDeductionBalance("500");

        /**
         * 当座勘定明細表リスト
         */
        CurrentAccountDto currentAccountDto2 = new CurrentAccountDto();

        /**
         * 取引年月日
         */
        currentAccountDto2.setTransactionDate("20220102");

        /**
         * 入出金
         */
        currentAccountDto2.setDepositsAndWithdrawals("入金");

        /**
         * 種類
         */
        currentAccountDto2.setType("振替");

        /**
         * 取扱
         */
        currentAccountDto2.setHandling("起算");

        /**
         * 振込人名
         */
        currentAccountDto2.setTransferPersonName("ﾌﾂｳﾖｷﾝ");

        /**
         * 交換
         */
        currentAccountDto2.setExchange("交換");

        /**
         * 手形番号
         */
        currentAccountDto2.setBillNumber("10011");

        /**
         * お支払額
         */
        currentAccountDto2.setPaymentAmount("900");

        /**
         * ご入金額
         */
        currentAccountDto2.setDepositAmount("800");

        /**
         * 差引残高
         */
        currentAccountDto2.setDeductionBalance("500");
        dtoList.add(currentAccountDto);
        dtoList.add(currentAccountDto2);
        dto.setCurrentAccountList(dtoList);

        /**
         * 取扱店名
         */
        dto.setBranchKanjiName("東京都");

        /**
         * 取扱電話番号
         */
        dto.setBranchPhoneNumber("030-12345411");
        return dto;
    }

    /**
     * 帳票CSV内容照会_貸金庫使用料期日案内
     *
     * @param requestDto お知らせ閲覧ABAリクエストDTO
     * @return お知らせ閲覧レスポンスDTO
     */
    @Override
    public InquireReport017AbaResponseDto abaInquireReportCsv017(ElectronicIssueAbaRequestDto requestDto) {

        // Dummyデータ
        InquireReport017AbaResponseDto dto = new InquireReport017AbaResponseDto();

        /**
         * 帳票バージョン
         */
        dto.setFormVersion("1.01");

        /**
         * 作成日
         */
        dto.setCreateDate("20220303");

        /**
         * 契約番号
         */
        dto.setContractNumber("14511");

        /**
         * 契約番号_種別
         */
        dto.setContractNumberKind("A");

        /**
         * 契約番号_種類
         */
        dto.setContractNumberType("1");

        /**
         * 使用料期日
         */
        dto.setUsageFeeDueDate("20220201");

        /**
         * 使用料
         */
        dto.setUsageFee("756412");

        /**
         * 振替日
         */
        dto.setTransferDate("20220501");

        /**
         * ご指定預金口座科目名
         */
        dto.setSpecifiedDepositAccountName("普通預金");

        /**
         * ご指定預金口座番号
         */
        dto.setSpecifiedDepositAccountNumber("12138");

        /**
         * 取扱店名
         */
        dto.setBranchKanjiName("東京都");

        /**
         * 取扱電話番号
         */
        dto.setBranchPhoneNumber("030-12345411");
        return dto;
    }

    /**
     * 帳票CSV内容照会_割引手形計算明細表
     *
     * @param requestDto お知らせ閲覧ABAリクエストDTO
     * @return お知らせ閲覧レスポンスDTO
     */
    @Override
    public InquireReport018AbaResponseDto abaInquireReportCsv018(ElectronicIssueAbaRequestDto requestDto) {

        // Dummyデータ
        InquireReport018AbaResponseDto dto = new InquireReport018AbaResponseDto();

        /**
         * 帳票バージョン
         */
        dto.setFormVersion("1.01");

        /**
         * 共通作成日付
         */
        dto.setComCreateDate("20220303");

        List<DiscountedBillCalculationDto> dtoList = new ArrayList<DiscountedBillCalculationDto>();

        /**
         * 割引手形計算明細表リスト
         */
        DiscountedBillCalculationDto discountedBillCalculationDto = new DiscountedBillCalculationDto();

        /**
         * お支払人
         */
        discountedBillCalculationDto.setPayer("切原");

        /**
         * 支払場所
         */
        discountedBillCalculationDto.setPaymentPlace("東京");

        /**
         * 取組年月日
         */
        discountedBillCalculationDto.setDateOfEfforts("20220201");

        /**
         * 取組番号
         */
        discountedBillCalculationDto.setActionNumber("1566");

        /**
         * 手形種類
         */
        discountedBillCalculationDto.setBillType("1");

        /**
         * 振出日
         */
        discountedBillCalculationDto.setDrawDate("20220405");

        /**
         * 手形金額
         */
        discountedBillCalculationDto.setBillAmount("1233");

        /**
         * 手形期日
         */
        discountedBillCalculationDto.setBillDueDate("20220408");

        /**
         * 割引料_日数
         */
        discountedBillCalculationDto.setDiscountDays("10");

        /**
         * 割引料_利率
         */
        discountedBillCalculationDto.setDiscountRate("1.125");

        /**
         * 割引料_金額
         */
        discountedBillCalculationDto.setDiscountAmount("11500");

        /**
         * 割引手形計算明細表リスト
         */
        DiscountedBillCalculationDto discountedBillCalculationDto2 = new DiscountedBillCalculationDto();

        /**
         * お支払人
         */
        discountedBillCalculationDto2.setPayer("切原");

        /**
         * 支払場所
         */
        discountedBillCalculationDto2.setPaymentPlace("東京");

        /**
         * 取組年月日
         */
        discountedBillCalculationDto2.setDateOfEfforts("20220201");

        /**
         * 取組番号
         */
        discountedBillCalculationDto2.setActionNumber("1566");

        /**
         * 手形種類
         */
        discountedBillCalculationDto2.setBillType("2");

        /**
         * 振出日
         */
        discountedBillCalculationDto2.setDrawDate("20220405");

        /**
         * 手形金額
         */
        discountedBillCalculationDto2.setBillAmount("1233");

        /**
         * 手形期日
         */
        discountedBillCalculationDto2.setBillDueDate("20220408");

        /**
         * 割引料_日数
         */
        discountedBillCalculationDto2.setDiscountDays("10");

        /**
         * 割引料_利率
         */
        discountedBillCalculationDto2.setDiscountRate("1.125");

        /**
         * 割引料_金額
         */
        discountedBillCalculationDto2.setDiscountAmount("12500");

        dtoList.add(discountedBillCalculationDto);
        dtoList.add(discountedBillCalculationDto2);
        dto.setDiscountedBillCalculationList(dtoList);

        /**
         * 顧客毎件数項目
         */
        dto.setEachCustomerCountItem("1-( 11) 2-( 0) 済-( 0)");

        /**
         * 徴収済金額
         */
        dto.setPaymentAmount("11211");

        /**
         * 取組金額合計
         */
        dto.setTotalAmountOfEfforts("13551");

        /**
         * 割引料合計
         */
        dto.setTotalDiscount("1118");

        /**
         * 取立料合計
         */
        dto.setTotalCollectionFee("2668");

        /**
         * ラベル識別番号
         */
        dto.setLabelIdentificationNumber("20220401-WB002-00001");

        /**
         * 消費税コメント
         */
        dto.setConsumptionTaxComment("コメント");

        /**
         * 取扱店名
         */
        dto.setBranchKanjiName("東京都");

        /**
         * 取扱電話番号
         */
        dto.setBranchPhoneNumber("030-12345411");

        return dto;
    }

    /**
     * 帳票CSV内容照会_融資返済明細表
     *
     * @param requestDto お知らせ閲覧ABAリクエストDTO
     * @return お知らせ閲覧レスポンスDTO
     */
    @Override
    public InquireReport019AbaResponseDto abaInquireReportCsv019(ElectronicIssueAbaRequestDto requestDto) {

        // Dummyデータ
        InquireReport019AbaResponseDto dto = new InquireReport019AbaResponseDto();

        /**
         * 帳票バージョン
         */
        dto.setFormVersion("1.01");

        /**
         * 本状作成日
         */
        dto.setBookCreateDate("2022-02-02");

        /**
         * 店番
         */
        dto.setBranchNumber("001");

        /**
         * 口座番号
         */
        dto.setAccountNumber("11156");

        /**
         * 融資日
         */
        dto.setLoanDate("2012-01-05");

        /**
         * 融資額
         */
        dto.setLoanAmount("6000000");

        /**
         * 毎回返済分
         */
        dto.setRepaymentAmountForEachPayment("6000000");

        /**
         * ボーナス分返済分
         */
        dto.setBonusRepayment("0");

        /**
         * 融資期日
         */
        dto.setEfficientLoanDate("2032-01-05");

        /**
         * 融資期間
         */
        dto.setLoanPeriod("240");

        /**
         * 返済日
         */
        dto.setPaymentDate("15");

        /**
         * 年利率
         */
        dto.setYearInterest("2.750");

        /**
         * 毎回返済額
         */
        dto.setRepaymentAmountEachTime("15025");

        /**
         * ボーナス分返済額
         */
        dto.setBonusRepaymentAmount("1000");

        /**
         * ボーナス返済月
         */
        dto.setBonusRepaymentMonth("10");

        /**
         * 第１回利払日
         */
        dto.setFirstInterestPaymentDate("2012-08-05");

        /**
         * 第１回返済予定日
         */
        dto.setFirstExpectedRepaymentDate("2019-08-05");

        /**
         * 自動振替口座番号
         */
        dto.setTransferAccountNumber("12138");

        List<BorrowingRepaymentDto> dtoList = new ArrayList<BorrowingRepaymentDto>();

        /**
         * お借入金のご返済明細表リスト
         */
        BorrowingRepaymentDto borrowingRepaymentDto = new BorrowingRepaymentDto();

        /**
         * 約定払込年月日
         */
        borrowingRepaymentDto.setContractPaymentDate("2019-11-05");

        /**
         * 払込金額_元金
         */
        borrowingRepaymentDto.setPaymentAmount("10000");

        /**
         * 払込金額_利息
         */
        borrowingRepaymentDto.setPaymentAmountInterest("800");

        /**
         * 残高
         */
        borrowingRepaymentDto.setBalance("5000");

        /**
         * ボーナス分払込金額_元金
         */
        borrowingRepaymentDto.setBonusPaymentAmount("20000");

        /**
         * ボーナス分払込金額_利息
         */
        borrowingRepaymentDto.setBonusPaymentAmountInterest("900");

        /**
         * ボーナス分残高
         */
        borrowingRepaymentDto.setBonusBalance("6000");

        /**
         * 備考
         */
        borrowingRepaymentDto.setRemark("備考001");
        /**
         * お借入金のご返済明細表リスト
         */
        BorrowingRepaymentDto borrowingRepaymentDto2 = new BorrowingRepaymentDto();

        /**
         * 約定払込年月日
         */
        borrowingRepaymentDto2.setContractPaymentDate("2019-11-05");

        /**
         * 払込金額_元金
         */
        borrowingRepaymentDto2.setPaymentAmount("10000");

        /**
         * 払込金額_利息
         */
        borrowingRepaymentDto2.setPaymentAmountInterest("800");

        /**
         * 残高
         */
        borrowingRepaymentDto2.setBalance("5000");

        /**
         * ボーナス分払込金額_元金
         */
        borrowingRepaymentDto2.setBonusPaymentAmount("20000");

        /**
         * ボーナス分払込金額_利息
         */
        borrowingRepaymentDto2.setBonusPaymentAmountInterest("900");

        /**
         * ボーナス分残高
         */
        borrowingRepaymentDto2.setBonusBalance("6000");

        /**
         * 備考
         */
        borrowingRepaymentDto2.setRemark("備考001");
        dtoList.add(borrowingRepaymentDto);
        dtoList.add(borrowingRepaymentDto2);
        dto.setBorrowingRepaymentList(dtoList);

        /**
         * 取扱店名
         */
        dto.setBranchKanjiName("東京都");

        /**
         * 取扱電話番号
         */
        dto.setBranchPhoneNumber("030-12345411");
        return dto;
    }

    /**
     * 帳票CSV内容照会_財産形成預金残高通知書
     *
     * @param requestDto お知らせ閲覧ABAリクエストDTO
     * @return お知らせ閲覧レスポンスDTO
     */
    @Override
    public InquireReport021AbaResponseDto abaInquireReportCsv021(ElectronicIssueAbaRequestDto requestDto) {

        // Dummyデータ
        InquireReport021AbaResponseDto dto = new InquireReport021AbaResponseDto();

        /**
         * 帳票バージョン
         */
        dto.setFormVersion("1.01");

        /**
         * 作成日
         */
        dto.setCreateDate("20220303");

        /**
         * お名前
         */
        dto.setName("山崎");

        /**
         * 勤務先
         */
        dto.setDutyFirst("富士通株式会社");

        List<PropertyFormationDepositBalanceNotificationDto> dtoList = new ArrayList<PropertyFormationDepositBalanceNotificationDto>();

        /**
         * 財産形成預金残高通知明細表リスト
         */
        PropertyFormationDepositBalanceNotificationDto propertyFormationDepositBalanceNotificationDto = new PropertyFormationDepositBalanceNotificationDto();

        /**
         * ご預金種類
         */
        propertyFormationDepositBalanceNotificationDto.setDepositType("普通預金");

        /**
         * 口座番号
         */
        propertyFormationDepositBalanceNotificationDto.setAccountNumber("11138");

        /**
         * 満期日
         */
        propertyFormationDepositBalanceNotificationDto.setMaturityDate("11220305");

        /**
         * 期間
         */
        propertyFormationDepositBalanceNotificationDto.setPeriod("10");

        /**
         * 回数
         */
        propertyFormationDepositBalanceNotificationDto.setNumberOfTimes("200");

        /**
         * 現在残高
         */
        propertyFormationDepositBalanceNotificationDto.setCurrentAmount("0");

        /**
         * 非課税限度額
         */
        propertyFormationDepositBalanceNotificationDto.setNonTaxableLimit("15000");

        /**
         * 財産形成預金残高通知明細表リスト
         */
        PropertyFormationDepositBalanceNotificationDto propertyFormationDepositBalanceNotificationDto2 = new PropertyFormationDepositBalanceNotificationDto();

        /**
         * ご預金種類
         */
        propertyFormationDepositBalanceNotificationDto2.setDepositType("普通預金");

        /**
         * 口座番号
         */
        propertyFormationDepositBalanceNotificationDto2.setAccountNumber("12138");

        /**
         * 満期日
         */
        propertyFormationDepositBalanceNotificationDto2.setMaturityDate("20220305");

        /**
         * 期間
         */
        propertyFormationDepositBalanceNotificationDto2.setPeriod("10");

        /**
         * 回数
         */
        propertyFormationDepositBalanceNotificationDto2.setNumberOfTimes("200");

        /**
         * 現在残高
         */
        propertyFormationDepositBalanceNotificationDto2.setCurrentAmount("124363");

        /**
         * 非課税限度額
         */
        propertyFormationDepositBalanceNotificationDto2.setNonTaxableLimit("15000");

        /**
         * 財産形成預金残高通知明細表リスト
         */
        PropertyFormationDepositBalanceNotificationDto propertyFormationDepositBalanceNotificationDto3 = new PropertyFormationDepositBalanceNotificationDto();

        /**
         * ご預金種類
         */
        propertyFormationDepositBalanceNotificationDto3.setDepositType("普通預金");

        /**
         * 口座番号
         */
        propertyFormationDepositBalanceNotificationDto3.setAccountNumber("12138");

        /**
         * 満期日
         */
        propertyFormationDepositBalanceNotificationDto3.setMaturityDate("20220405");

        /**
         * 期間
         */
        propertyFormationDepositBalanceNotificationDto3.setPeriod("20");

        /**
         * 回数
         */
        propertyFormationDepositBalanceNotificationDto3.setNumberOfTimes("200");

        /**
         * 現在残高
         */
        propertyFormationDepositBalanceNotificationDto3.setCurrentAmount("124363");

        /**
         * 非課税限度額
         */
        propertyFormationDepositBalanceNotificationDto3.setNonTaxableLimit("65000");
        dtoList.add(propertyFormationDepositBalanceNotificationDto);
        dtoList.add(propertyFormationDepositBalanceNotificationDto2);
        dtoList.add(propertyFormationDepositBalanceNotificationDto3);
        dto.setPropertyFormationDepositBalanceNotificationList(dtoList);

        dto.setTotalAmount("11");

        /**
         * 合計_明細件数
         */
        dto.setTotalNumber("2");

        /**
         * 合計_残高金額
         */
        dto.setTotalAmount("11011");

        /**
         * 取扱店名
         */
        dto.setBranchKanjiName("東京都");

        /**
         * 取扱電話番号
         */
        dto.setBranchPhoneNumber("030-12345411");
        return dto;
    }

    @Override
    public CreateReportPdfAbaResponseDto abaCreateReportPdf(ElectronicIssueAbaRequestDto requestDto) {

        // 文書種別コード設定
        String documentTypeCode = requestDto.getDocumentTypeCode().substring(0, 2);
        CreateReportPdfAbaResponseDto abaResponseDto = new CreateReportPdfAbaResponseDto();
        Object line = "JVBERi0xLjUKJYCBgoMKMSAwIG9iago8PC9GaWx0ZXIvRmxhdGVEZWNvZGUvRmlyc3QgMTQxL04gMjAvTGVuZ3";
        if (StringUtils.equals(documentTypeCode, DocumentTypeCode.DOCUMENTTYPE_01)) {

            // 帳票PDF出力_定期預金利息計算（懸賞金付）（自継）
            // response =
            // restTemplate.getForObject("/digitalreport/v1.0.0/reports/pdf/001/create",
            // CreateReportPdfAbaResponseDto.class, parameterDto);

            abaResponseDto.setFormPdfFileObject(line);
        } else if (StringUtils.equals(documentTypeCode, DocumentTypeCode.DOCUMENTTYPE_02)) {

            // 帳票PDF出力_定期預金（懸賞金付）期日案内
            // response =
            // restTemplate.getForObject("/digitalreport/v1.0.0/reports/pdf/002/create",
            abaResponseDto.setFormPdfFileObject(line);
        } else if (StringUtils.equals(documentTypeCode, DocumentTypeCode.DOCUMENTTYPE_03)) {

            // 帳票PDF出力_定期積金満期案内
            // response =
            // restTemplate.getForObject("/digitalreport/v1.0.0/reports/pdf/003/create",
            // CreateReportPdfAbaResponseDto.class, parameterDto);
            abaResponseDto.setFormPdfFileObject(line);
        } else if (StringUtils.equals(documentTypeCode, DocumentTypeCode.DOCUMENTTYPE_04)) {

            // 帳票PDF出力_定期預金期日案内
            // response =
            // restTemplate.getForObject("/digitalreport/v1.0.0/reports/pdf/004/create",
            // CreateReportPdfAbaResponseDto.class, parameterDto);
            abaResponseDto.setFormPdfFileObject(line);
        } else if (StringUtils.equals(documentTypeCode, DocumentTypeCode.DOCUMENTTYPE_05)) {

            // 帳票PDF出力_定期預金（自継）利息計算
            // response =
            // restTemplate.getForObject("/digitalreport/v1.0.0/reports/pdf/005/create",
            // CreateReportPdfAbaResponseDto.class, parameterDto);
            abaResponseDto.setFormPdfFileObject(line);
        } else if (StringUtils.equals(documentTypeCode, DocumentTypeCode.DOCUMENTTYPE_06)) {

            // 帳票PDF出力_定期預金（自継）大口定期利息計算
            // response =
            // restTemplate.getForObject("/digitalreport/v1.0.0/reports/pdf/006/create",
            // CreateReportPdfAbaResponseDto.class, parameterDto);
            abaResponseDto.setFormPdfFileObject(line);
        } else if (StringUtils.equals(documentTypeCode, DocumentTypeCode.DOCUMENTTYPE_07)) {

            // 帳票PDF出力_定期預金（自由金利）期日案内
            // response =
            // restTemplate.getForObject("/digitalreport/v1.0.0/reports/pdf/007/create",
            // CreateReportPdfAbaResponseDto.class, parameterDto);
            abaResponseDto.setFormPdfFileObject(line);
        } else if (StringUtils.equals(documentTypeCode, DocumentTypeCode.DOCUMENTTYPE_08)) {

            // 帳票PDF出力_借入終了案内
            // response =
            // restTemplate.getForObject("/digitalreport/v1.0.0/reports/pdf/008/create",
            // CreateReportPdfAbaResponseDto.class, parameterDto);
            abaResponseDto.setFormPdfFileObject(line);
        } else if (StringUtils.equals(documentTypeCode, DocumentTypeCode.DOCUMENTTYPE_09)) {

            abaResponseDto.setFormPdfFileObject(line);
        } else if (StringUtils.equals(documentTypeCode, DocumentTypeCode.DOCUMENTTYPE_10)) {

            // 帳票PDF出力_融資期日案内
            // response =
            // restTemplate.getForObject("/digitalreport/v1.0.0/reports/pdf/010/create",
            // CreateReportPdfAbaResponseDto.class, parameterDto);
            abaResponseDto.setFormPdfFileObject(line);
        } else if (StringUtils.equals(documentTypeCode, DocumentTypeCode.DOCUMENTTYPE_11)) {

            // 帳票PDF出力_自動送金取扱終了案内
            // response =
            // restTemplate.getForObject("/digitalreport/v1.0.0/reports/pdf/011/create",
            // CreateReportPdfAbaResponseDto.class, parameterDto);
            abaResponseDto.setFormPdfFileObject(line);

        } else if (StringUtils.equals(documentTypeCode, DocumentTypeCode.DOCUMENTTYPE_12)) {

            // 帳票PDF出力_財形年金預金受取案内
            // response =
            // restTemplate.getForObject("/digitalreport/v1.0.0/reports/pdf/012/create",
            // CreateReportPdfAbaResponseDto.class, parameterDto);
            abaResponseDto.setFormPdfFileObject(line);
        } else if (StringUtils.equals(documentTypeCode, DocumentTypeCode.DOCUMENTTYPE_13)) {

            // 帳票PDF出力_証貸変動金利通知
            // response =
            // restTemplate.getForObject("/digitalreport/v1.0.0/reports/pdf/013/create",
            // CreateReportPdfAbaResponseDto.class, parameterDto);
            abaResponseDto.setFormPdfFileObject(line);
        } else if (StringUtils.equals(documentTypeCode, DocumentTypeCode.DOCUMENTTYPE_14)) {

            // 帳票PDF出力_借入返済通知
            // response =
            // restTemplate.getForObject("/digitalreport/v1.0.0/reports/pdf/014/create",
            // CreateReportPdfAbaResponseDto.class, parameterDto);
            abaResponseDto.setFormPdfFileObject(line);
        } else if (StringUtils.equals(documentTypeCode, DocumentTypeCode.DOCUMENTTYPE_15)) {

            // 帳票PDF出力_当座勘定照合表
            // response =
            // restTemplate.getForObject("/digitalreport/v1.0.0/reports/pdf/015/create",
            // CreateReportPdfAbaResponseDto.class, parameterDto);
            abaResponseDto.setFormPdfFileObject(line);
        } else if (StringUtils.equals(documentTypeCode, DocumentTypeCode.DOCUMENTTYPE_16)) {

            // 帳票PDF出力_当座勘定照合表兼当座勘定決算通知
            // response =
            // restTemplate.getForObject("/digitalreport/v1.0.0/reports/pdf/016/create",
            // CreateReportPdfAbaResponseDto.class, parameterDto);
            abaResponseDto.setFormPdfFileObject(line);
        } else if (StringUtils.equals(documentTypeCode, DocumentTypeCode.DOCUMENTTYPE_17)) {

            // 帳票PDF出力_貸金庫使用料期日案内
            // response =
            // restTemplate.getForObject("/digitalreport/v1.0.0/reports/pdf/017/create",
            // CreateReportPdfAbaResponseDto.class, parameterDto);
            abaResponseDto.setFormPdfFileObject(line);
        } else if (StringUtils.equals(documentTypeCode, DocumentTypeCode.DOCUMENTTYPE_18)) {

            // 帳票PDF出力_割引手形計算明細表
            // response =
            // restTemplate.getForObject("/digitalreport/v1.0.0/reports/pdf/018/create",
            // CreateReportPdfAbaResponseDto.class, parameterDto);
            abaResponseDto.setFormPdfFileObject(line);
        } else if (StringUtils.equals(documentTypeCode, DocumentTypeCode.DOCUMENTTYPE_19)) {

            // 帳票PDF出力_融資返済明細表
            // response =
            // restTemplate.getForObject("/digitalreport/v1.0.0/reports/pdf/019/create",
            // CreateReportPdfAbaResponseDto.class, parameterDto);
            abaResponseDto.setFormPdfFileObject(line);
        } else if (StringUtils.equals(documentTypeCode, DocumentTypeCode.DOCUMENTTYPE_21)) {

            // 帳票PDF出力_財産形成預金残高通知書
            // response =
            // restTemplate.getForObject("/digitalreport/v1.0.0/reports/pdf/021/create",
            // CreateReportPdfAbaResponseDto.class, parameterDto);
            abaResponseDto.setFormPdfFileObject(line);
        }

        // Dummyデータ
        return abaResponseDto;
    }

    /**
     * 抽選結果取得
     *
     * @param requestDto 抽選結果情報ABAリクエストDTO
     * @return 抽選結果
     */
    @Override
    public LotteryResultAbaResponseDto getLotteryResultInfomation(LotteryResultAbaRequestDto requestDto) {
        // Dummyデータ
        LotteryResultAbaResponseDto response = new LotteryResultAbaResponseDto();
        List<LotteryResultsDetailsDto> LotteryResultsDetailsDtoList = new ArrayList<LotteryResultsDetailsDto>();

        LotteryResultsDetailsDto lotteryResultsDetailsDto1 = new LotteryResultsDetailsDto();

        /**
         * 回次
         */
        lotteryResultsDetailsDto1.setLotteryTimes("01");

        /**
         * 抽選区分
         */
        lotteryResultsDetailsDto1.setLotteryType("0");

        /**
         * 取扱組
         */
        lotteryResultsDetailsDto1.setLotterySet("12345");

        /**
         * 等級
         */
        lotteryResultsDetailsDto1.setLotteryRank("WRFD01");

        /**
         * 当選番号
         */
        lotteryResultsDetailsDto1.setLotteryNumber("45678");

        /**
         * 当選本数
         */
        lotteryResultsDetailsDto1.setLotteryCount("102");

        /**
         * 当選金額
         */
        lotteryResultsDetailsDto1.setLotteryAmount("100");

        /**
         * 抽選結果受領済みフラグ
         */
        lotteryResultsDetailsDto1.setLotteryResultReceivedFlag("1");

        LotteryResultsDetailsDto lotteryResultsDetailsDto2 = new LotteryResultsDetailsDto();

        /**
         * 回次
         */
        lotteryResultsDetailsDto2.setLotteryTimes("01");

        /**
         * 抽選区分
         */
        lotteryResultsDetailsDto2.setLotteryType("0");

        /**
         * 取扱組
         */
        lotteryResultsDetailsDto2.setLotterySet("12345");

        /**
         * 等級
         */
        lotteryResultsDetailsDto2.setLotteryRank("WRFD02");

        /**
         * 当選番号
         */
        lotteryResultsDetailsDto2.setLotteryNumber("45678");

        /**
         * 当選本数
         */
        lotteryResultsDetailsDto2.setLotteryCount("102");

        /**
         * 当選金額
         */
        lotteryResultsDetailsDto2.setLotteryAmount("200");

        /**
         * 抽選結果受領済みフラグ
         */
        lotteryResultsDetailsDto2.setLotteryResultReceivedFlag("1");

        LotteryResultsDetailsDto lotteryResultsDetailsDto3 = new LotteryResultsDetailsDto();

        /**
         * 回次
         */
        lotteryResultsDetailsDto3.setLotteryTimes("01");

        /**
         * 抽選区分
         */
        lotteryResultsDetailsDto3.setLotteryType("0");

        /**
         * 取扱組
         */
        lotteryResultsDetailsDto3.setLotterySet("12345");

        /**
         * 等級
         */
        lotteryResultsDetailsDto3.setLotteryRank("WRFD03");

        /**
         * 当選番号
         */
        lotteryResultsDetailsDto3.setLotteryNumber("45678");

        /**
         * 当選本数
         */
        lotteryResultsDetailsDto3.setLotteryCount("102");

        /**
         * 当選金額
         */
        lotteryResultsDetailsDto3.setLotteryAmount("300");

        /**
         * 抽選結果受領済みフラグ
         */
        lotteryResultsDetailsDto3.setLotteryResultReceivedFlag("1");

        LotteryResultsDetailsDto lotteryResultsDetailsDto4 = new LotteryResultsDetailsDto();

        /**
         * 回次
         */
        lotteryResultsDetailsDto4.setLotteryTimes("01");

        /**
         * 抽選区分
         */
        lotteryResultsDetailsDto4.setLotteryType("0");

        /**
         * 取扱組
         */
        lotteryResultsDetailsDto4.setLotterySet("12345");

        /**
         * 等級
         */
        lotteryResultsDetailsDto4.setLotteryRank("WRFD04");

        /**
         * 当選番号
         */
        lotteryResultsDetailsDto4.setLotteryNumber("45678");

        /**
         * 当選本数
         */
        lotteryResultsDetailsDto4.setLotteryCount("102");

        /**
         * 当選金額
         */
        lotteryResultsDetailsDto4.setLotteryAmount("400");

        /**
         * 抽選結果受領済みフラグ
         */
        lotteryResultsDetailsDto4.setLotteryResultReceivedFlag("1");
        LotteryResultsDetailsDto lotteryResultsDetailsDto5 = new LotteryResultsDetailsDto();

        /**
         * 回次
         */
        lotteryResultsDetailsDto5.setLotteryTimes("01");

        /**
         * 抽選区分
         */
        lotteryResultsDetailsDto5.setLotteryType("0");

        /**
         * 取扱組
         */
        lotteryResultsDetailsDto5.setLotterySet("12345");

        /**
         * 等級
         */
        lotteryResultsDetailsDto5.setLotteryRank("WRFD05");

        /**
         * 当選番号
         */
        lotteryResultsDetailsDto5.setLotteryNumber("45678");

        /**
         * 当選本数
         */
        lotteryResultsDetailsDto5.setLotteryCount("102");

        /**
         * 当選金額
         */
        lotteryResultsDetailsDto5.setLotteryAmount("500");

        /**
         * 抽選結果受領済みフラグ
         */
        lotteryResultsDetailsDto5.setLotteryResultReceivedFlag("1");

        LotteryResultsDetailsDto lotteryResultsDetailsDto6 = new LotteryResultsDetailsDto();

        /**
         * 回次
         */
        lotteryResultsDetailsDto6.setLotteryTimes("01");

        /**
         * 抽選区分
         */
        lotteryResultsDetailsDto6.setLotteryType("0");

        /**
         * 取扱組
         */
        lotteryResultsDetailsDto6.setLotterySet("12345");

        /**
         * 等級
         */
        lotteryResultsDetailsDto6.setLotteryRank("WRFD07");

        /**
         * 当選番号
         */
        lotteryResultsDetailsDto6.setLotteryNumber("45678");

        /**
         * 当選本数
         */
        lotteryResultsDetailsDto6.setLotteryCount("102");

        /**
         * 当選金額
         */
        lotteryResultsDetailsDto6.setLotteryAmount("600");

        /**
         * 抽選結果受領済みフラグ
         */
        lotteryResultsDetailsDto6.setLotteryResultReceivedFlag("1");

        LotteryResultsDetailsDto lotteryResultsDetailsDto7 = new LotteryResultsDetailsDto();

        /**
         * 回次
         */
        lotteryResultsDetailsDto7.setLotteryTimes("01");

        /**
         * 抽選区分
         */
        lotteryResultsDetailsDto7.setLotteryType("1");

        /**
         * 取扱組
         */
        lotteryResultsDetailsDto7.setLotterySet("12345");

        /**
         * 等級
         */
        lotteryResultsDetailsDto7.setLotteryRank("WRFD06");

        /**
         * 当選番号
         */
        lotteryResultsDetailsDto7.setLotteryNumber("45678");

        /**
         * 当選本数
         */
        lotteryResultsDetailsDto7.setLotteryCount("102");

        /**
         * 当選金額
         */
        lotteryResultsDetailsDto7.setLotteryAmount("700");

        /**
         * 抽選結果受領済みフラグ
         */
        lotteryResultsDetailsDto7.setLotteryResultReceivedFlag("1");

        LotteryResultsDetailsDto lotteryResultsDetailsDto8 = new LotteryResultsDetailsDto();

        /**
         * 回次
         */
        lotteryResultsDetailsDto8.setLotteryTimes("01");

        /**
         * 抽選区分
         */
        lotteryResultsDetailsDto8.setLotteryType("1");

        /**
         * 取扱組
         */
        lotteryResultsDetailsDto8.setLotterySet("12345");

        /**
         * 等級
         */
        lotteryResultsDetailsDto8.setLotteryRank("WRFD06");

        /**
         * 当選番号
         */
        lotteryResultsDetailsDto8.setLotteryNumber("45678");

        /**
         * 当選本数
         */
        lotteryResultsDetailsDto8.setLotteryCount("102");

        /**
         * 当選金額
         */
        lotteryResultsDetailsDto8.setLotteryAmount("800");

        /**
         * 抽選結果受領済みフラグ
         */
        lotteryResultsDetailsDto8.setLotteryResultReceivedFlag("1");

        LotteryResultsDetailsDto lotteryResultsDetailsDto9 = new LotteryResultsDetailsDto();

        /**
         * 回次
         */
        lotteryResultsDetailsDto9.setLotteryTimes("01");

        /**
         * 抽選区分
         */
        lotteryResultsDetailsDto9.setLotteryType("1");

        /**
         * 取扱組
         */
        lotteryResultsDetailsDto9.setLotterySet("12345");

        /**
         * 等級
         */
        lotteryResultsDetailsDto9.setLotteryRank("WRFD06");

        /**
         * 当選番号
         */
        lotteryResultsDetailsDto9.setLotteryNumber("45678");

        /**
         * 当選本数
         */
        lotteryResultsDetailsDto9.setLotteryCount("102");

        /**
         * 当選金額
         */
        lotteryResultsDetailsDto9.setLotteryAmount("900");

        /**
         * 抽選結果受領済みフラグ
         */
        lotteryResultsDetailsDto9.setLotteryResultReceivedFlag("1");

        LotteryResultsDetailsDto lotteryResultsDetailsDto10 = new LotteryResultsDetailsDto();

        /**
         * 回次
         */
        lotteryResultsDetailsDto10.setLotteryTimes("01");

        /**
         * 抽選区分
         */
        lotteryResultsDetailsDto10.setLotteryType("1");

        /**
         * 取扱組
         */
        lotteryResultsDetailsDto10.setLotterySet("12345");

        /**
         * 等級
         */
        lotteryResultsDetailsDto10.setLotteryRank("WRFD07");

        /**
         * 当選番号
         */
        lotteryResultsDetailsDto10.setLotteryNumber("45678");

        /**
         * 当選本数
         */
        lotteryResultsDetailsDto10.setLotteryCount("102");

        /**
         * 当選金額
         */
        lotteryResultsDetailsDto10.setLotteryAmount("1000");

        /**
         * 抽選結果受領済みフラグ
         */
        lotteryResultsDetailsDto10.setLotteryResultReceivedFlag("1");

        LotteryResultsDetailsDtoList.add(lotteryResultsDetailsDto1);
        LotteryResultsDetailsDtoList.add(lotteryResultsDetailsDto2);
        LotteryResultsDetailsDtoList.add(lotteryResultsDetailsDto3);
        LotteryResultsDetailsDtoList.add(lotteryResultsDetailsDto4);
        LotteryResultsDetailsDtoList.add(lotteryResultsDetailsDto5);
        LotteryResultsDetailsDtoList.add(lotteryResultsDetailsDto6);
        LotteryResultsDetailsDtoList.add(lotteryResultsDetailsDto7);
        LotteryResultsDetailsDtoList.add(lotteryResultsDetailsDto8);
        LotteryResultsDetailsDtoList.add(lotteryResultsDetailsDto9);
        LotteryResultsDetailsDtoList.add(lotteryResultsDetailsDto10);
        response.setLotteryResultsDetailsDtoList(LotteryResultsDetailsDtoList);
        return response;
    }
}

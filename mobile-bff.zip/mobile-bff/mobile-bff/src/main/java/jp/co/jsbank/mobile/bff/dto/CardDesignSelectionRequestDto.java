package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * カードデザイン選択BFFリクエストDTO
 */
@Data
public class CardDesignSelectionRequestDto {

    /**
     * キャッシュカード種類
     */
    private String cashCardType;
    
    /**
     * 受付番号
     */
    private String receptionNumber;
    
    /**
     * 人格区分
     */
    private String personType;

}

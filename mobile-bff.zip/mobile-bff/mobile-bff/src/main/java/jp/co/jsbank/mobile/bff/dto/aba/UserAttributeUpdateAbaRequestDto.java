package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * 利用者属性更新AbaリクエストDTO
 */
@Data
public class UserAttributeUpdateAbaRequestDto {

	 /**
     * メールアドレス
     */
    private String emailAddress;
    
    /**
     * 利用者ID
     */
    private String userId;
    
}

package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 定期預金等期日明細表DTO
 */
@Data
public class TimeDepositDateDto {

	/**
	 * 預金番号
	 */
	private String depositNumber;

	/**
	 * 種類
	 */
	private String type;

	/**
	 * 取扱種類
	 */
	private String handlingType;

	/**
	 * お預り金額
	 */
	private String depositAmount;

	/**
	 * 利率
	 */
	private String interestRate;

	/**
	 * 税区分
	 */
	private String taxType;

	/**
	 * 期日
	 */
	private String expiryDate;

	/**
	 * 計算期間
	 */
	private String countDuration;

	/**
	 * 計算期間単位
	 */
	private String countDurationUnit;

	/**
	 * お利息
	 */
	private String interestAmount;

	/**
	 * お利息_国税
	 */
	private String interestNationalTax;

	/**
	 * お利息_地方税
	 */
	private String interestLocalTax;

	/**
	 * お利息_差引お利息
	 */
	private String interestDeductedInterestAmount;

	/**
	 * 支払調書文言１２
	 */
	private String paymentRecordValue12;

	/**
	 * 継続後の新元金
	 */
	private String newPrincipalAfterContinuation;

	/**
	 * 備考１
	 */
	private String remark1;

	/**
	 * 備考２
	 */
	private String remark2;

	/**
	 * 備考３
	 */
	private String remark3;

	/**
	 * 子供お預り金額
	 */
	private String childDepositAmount;

	/**
	 * 子供利率
	 */
	private String childInterestRate;

	/**
	 * 子供税区分
	 */
	private String childTaxType;

	/**
	 * 子供期日
	 */
	private String childExpiryDate;

	/**
	 * 子供計算期間
	 */
	private String childCountDuration;

	/**
	 * 子供計算期間単位
	 */
	private String childCountDurationUnit;

	/**
	 * 子供お利息
	 */
	private String childInterestAmount;

	/**
	 * 子供お利息_国税
	 */
	private String childInterestNationalTax;

	/**
	 * 子供お利息_地方税
	 */
	private String childInterestLocalTax;

	/**
	 * 子供お利息_差引お利息
	 */
	private String childInterestDeductedInterestAmount;

	/**
	 * 支払調書文言１１
	 */
	private String paymentRecordValue11;

	/**
	 * 親子有区分
	 */
	private String parentChildFlag;

	/**
	 * 子供支払区分
	 */
	private String childPaymentFlag;

	/**
	 * 法人割廃止表示
	 */
	private String corporationAbolishExpression;

	/**
	 * マル優改組表示
	 */
	private String declarationReorganizeExpression;

}

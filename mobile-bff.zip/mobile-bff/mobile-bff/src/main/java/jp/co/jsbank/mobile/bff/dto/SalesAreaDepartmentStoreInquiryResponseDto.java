package jp.co.jsbank.mobile.bff.dto;

import java.util.List;

import lombok.Data;

/**
 * 営業地区部店一覧照会レスポンスDTO
 */
@Data
public class SalesAreaDepartmentStoreInquiryResponseDto {

    /**
     * 営業地区部店一覧照会
     */
    private List<DepartmentStoreDto> departmentStoreList;

    /**
     * 支店一覧照会
     */
    private List<BranchStoreDto> branchList;

    /**
     * 候补FLG
     */
    private String alternateFlg;

}

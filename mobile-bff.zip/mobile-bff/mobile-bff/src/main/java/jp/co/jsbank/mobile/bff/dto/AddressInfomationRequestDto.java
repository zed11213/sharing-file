package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 所在地情報リクエストDTO
 */
@Data
public class AddressInfomationRequestDto {
	
    /**
     * 所在地郵便番号
     */
    private String locationZipCode;

    /**
     * 所在地都道府県（カナ）
     */
    private String locationStateKana;

    /**
     * 所在地都道府県
     */
    private String locationState;

    /**
     * 所在地市区町村（カナ）
     */
    private String locationCityKana;

    /**
     * 所在地市区町村
     */
    private String locationCity;

    /**
     * 所在地丁目（カナ）
     */
    private String locationStreetKana;

    /**
     * 所在地丁目
     */
    private String locationStreet;

    /**
     * 所在地番地（カナ）
     */
    private String locationAddressKana;

    /**
     * 所在地番地
     */
    private String locationAddress;

    /**
     * 建物名・号室（カナ）
     */
    private String buildingRoomKana;

    /**
     * 建物名・号室
     */
    private String buildingRoom;

}

package jp.co.jsbank.mobile.bff.service;

import java.util.List;

import org.springframework.stereotype.Service;

import jp.co.jsbank.mobile.bff.dto.CardDesignSelectionRequestDto;
import jp.co.jsbank.mobile.bff.dto.CcIssuingApplicationInformationResponseDto;
import jp.co.jsbank.mobile.bff.dto.CcIssuingRequestDto;
import jp.co.jsbank.mobile.bff.dto.CcPasswordIbPasswordSettingRequestDto;
import jp.co.jsbank.mobile.bff.dto.EmailAddressAuthorizationRequestDto;
import jp.co.jsbank.mobile.bff.dto.IdentificationRequestDto;
import jp.co.jsbank.mobile.bff.dto.IvrAuthenticationRequestDto;

/**
 * キャッシュカード発行サービス
 */
@Service
public interface CashCardIssueService {

	/**
	 * 復元処理
	 *
	 * @param receptionNumber 受付番号
	 * @return CC発行申込情報レスポンスDTO
	 */
	CcIssuingApplicationInformationResponseDto getRecoveryProcess(String receptionNumber);

	/**
	 * CC暗証番号・IBパスワード設定処理
	 *
	 * @param requestDto CC暗証番号・IBパスワード設定リクエストDTO
	 * @return 処理結果
	 * @throws Exception 
	 */
	String ccPasswordIbPasswordSetting(CcPasswordIbPasswordSettingRequestDto requestDto) throws Exception;

	/**
	 * カードデザイン選択
	 *
	 * @param requestDto カードデザイン選択リクエストDTO
	 * 
	 * @return receptionNumber 受付番号
	 */
	String cardDesignSelection(CardDesignSelectionRequestDto requestDto);

	/**
	 * CC発行依頼
	 *
	 * @param requestDto CC発行依頼リクエストDTO
	 * 
	 * @return receptionNumber 受付番号
	 */
	String getCcIssuing(CcIssuingRequestDto requestDto);

	/**
	 * 本人確認
	 *
	 * @param requestDto 本人確認リクエストDTO
	 * @return 処理結果
	 */
	String identityVerification(IdentificationRequestDto requestDto);
	
    /**
     * メールアドレス認証
     *
     * @param requestDto メールアドレス認証リクエストDTO
     * @return 処理結果
     */
    List<String> emailAddressAuthorization(EmailAddressAuthorizationRequestDto requestDto);

    /**
     * IVR認証
     *
     * @param requestDto IVR認証リクエストDTO
     * @return [確認ダイアログ]画面表示
     */
    String ivrAuthentication(IvrAuthenticationRequestDto requestDto);

    /**
     * IVR確認
     *
     * @param requestDto IVR確認リクエストDTO
     * @return JsonResult
     */
    String identityVerification(IvrAuthenticationRequestDto requestDto);

}

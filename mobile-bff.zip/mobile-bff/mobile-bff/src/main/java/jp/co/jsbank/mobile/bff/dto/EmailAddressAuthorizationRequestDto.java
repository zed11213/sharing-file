package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * メールアドレス認証リクエストDTO
 */
@Data
public class EmailAddressAuthorizationRequestDto {
    /**
     * 受付番号
     */
    private String receptionNumber;

    /**
     * 人格区分
     */
    private String personType;

    /**
     * OTP
     */
    private String otp;
    
    /**
     * 認証TRXキー
     */
    private String verifyTRXKey;
    
    /**
     * CIF番号
     */
    private String cifNumber;
}

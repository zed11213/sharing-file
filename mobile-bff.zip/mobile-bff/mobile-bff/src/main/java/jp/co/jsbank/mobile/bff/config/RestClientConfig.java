package jp.co.jsbank.mobile.bff.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import jp.co.jsbank.mobile.bff.common.exception.RestClientErrorHandler;

/**
 * RestTemplateについての配置クラス。
 * 
 */
@Configuration
public class RestClientConfig {

    @Autowired
    private MappingJackson2HttpMessageConverter mappingJackson2HttpMessageConverter;

    @Autowired
    private RestClientErrorHandler restClientErrorHandler;

    /**
     * RestTemplate対象beanを生成する。
     * 
     * @return RestTemplate対象
     */
    @Bean("simpleClient")
    @Primary
    public RestTemplate simpleRestTemplate() {
        RestTemplate restTemplate = new RestTemplate(createSimpleFactory());

        restTemplate.setErrorHandler(restClientErrorHandler);
        restTemplate.getMessageConverters().add(0, mappingJackson2HttpMessageConverter);

        return restTemplate;
    }

    /**
     * ClientHttpRequestFactoryを生成する。
     * 
     * @return ClientHttpRequestFactory対象
     */
    private HttpComponentsClientHttpRequestFactory createSimpleFactory() {

        HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
        // istioで処理、以下設定をコメントする
        /**
         * requestFactory.setConnectionRequestTimeout(connectionRequestTimeout);
         * requestFactory.setConnectTimeout(connectTimeout);
         * requestFactory.setReadTimeout(readTimeout);
         */
        requestFactory.setBufferRequestBody(false);

        return requestFactory;
    }
}

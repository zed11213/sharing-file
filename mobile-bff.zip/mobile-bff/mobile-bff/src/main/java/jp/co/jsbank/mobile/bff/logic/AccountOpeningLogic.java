package jp.co.jsbank.mobile.bff.logic;

import org.springframework.stereotype.Service;

import jp.co.jsbank.mobile.bff.dto.AddressInfomationRequestDto;
import jp.co.jsbank.mobile.bff.dto.BizAddressInfomationRequestDto;
import jp.co.jsbank.mobile.bff.dto.BizHomeInfomationRequestDto;
import jp.co.jsbank.mobile.bff.dto.BranchStoreAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.PostalCodeAutoSearchRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.AccountOpeningApplicationAbaCorporationInfoDto;
import jp.co.jsbank.mobile.bff.dto.aba.AccountOpeningApplicationBusinessOwnerInfoAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.AccountOpeningApplicationIndividualInfoAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.AccountOpeningApplicationInfoAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.AddressInfomationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.ApplicationCompleteAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.BizHomeInfomationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.BranchOfficeListInquiryAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CcIssuingAppContentUpdateAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CcIssuingApplicationContentUpdateAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CcIssuingApplicationContentUpdateAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CifInquiryAbaRequetDto;
import jp.co.jsbank.mobile.bff.dto.aba.CifInquiryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CommonHeaderAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.ContractManagementOperationHistoryAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.ContractManagementOperationHistoryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.ContractManagementOperationHistoryRegAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.ContractManagementOperationHistoryRegistrationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.DepartmentStoreAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.EmailAddressAuthorizationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.EmailAddressAuthorizationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.EmailAddressRegistrationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.EmailAddressRegistrationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.FixedTermDespositBalanceAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.FixedTermFixedBalanceAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.HeadOfficeAddressInformationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.HopeStoreSettingAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.HopeStoreSettingBusinessOwnerInfoAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.HopeStoreSettingCorporationInfoAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.HopeStoreSettingIndividualInfoAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.IndividualAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.IvrAuthorizationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.IvrAuthorizationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.IvrSendingAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.IvrSendingAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.PostalCodeAddressInquiryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.PostalCodeAutoSearchAbaResponseDto;

/**
 * 新規口座開設ロジック
 */
@Service
public interface AccountOpeningLogic {

	/**
	 * 契約管理操作履歴照会
	 *
	 * @param requestDto 契約管理操作履歴ABAリクエストDTO
	 * @return 契約管理操作履歴情報
	 */
	ContractManagementOperationHistoryAbaResponseDto contractManagementOperationHistoryInquiry(
			ContractManagementOperationHistoryAbaRequestDto requestDto);

	/**
	 * 口座開設申込情報（法人）取得
	 *
	 * @param requestDto 口座開設申込情報ABAリクエストDTO
	 * @return 口座開設申込情報（法人）
	 */
	AccountOpeningApplicationAbaCorporationInfoDto getAccountOpeningApplicationCorporateInfo(
			AccountOpeningApplicationInfoAbaRequestDto requestDto);

	/**
	 * 口座開設申込情報（個人事業者）取得
	 *
	 * @param requestDto 口座開設申込情報ABAリクエストDTO
	 * @return 口座開設申込情報（個人事業者）
	 */
	AccountOpeningApplicationBusinessOwnerInfoAbaResponseDto getAccountOpeningApplicationSoleProprietorInfo(
			AccountOpeningApplicationInfoAbaRequestDto requestDto);

	/**
	 * 口座開設申込情報（個人）取得
	 *
	 * @param requestDto 口座開設申込情報ABAリクエストDTO
	 * @return 口座開設申込情報（個人）
	 */
	AccountOpeningApplicationIndividualInfoAbaResponseDto accountOpeningApplicationIndividualInfoInquiry(
			AccountOpeningApplicationInfoAbaRequestDto requestDto);

	/**
	 * 口座開設申込内容更新（個人）
	 *
	 * @param requestDto 口座開設申込情報（個人）ABAリクエストDTO
	 * @return 共通レスポンスヘッダー
	 */
	CommonHeaderAbaResponseDto accountOpeningApplicationIndividualInfoUpdate(
			AccountOpeningApplicationIndividualInfoAbaResponseDto requestDto);

	/**
	 * 口座開設申込内容更新（法人）
	 *
	 * @param requestDto 口座開設申込情報（法人）ABAリクエストDTO
	 * @return 共通レスポンスヘッダー
	 */
	CommonHeaderAbaResponseDto accountOpeningApplicationCorporationInfoUpdate(
			AccountOpeningApplicationAbaCorporationInfoDto requestDto);

	/**
	 * 口座開設申込内容更新（個人事業主）
	 *
	 * @param requestDto 口座開設申込情報（個人事業主）ABAリクエストDTO
	 * @return 共通レスポンスヘッダー
	 */
	CommonHeaderAbaResponseDto accountOpeningApplicationBusinessOwnerInfoUpdate(
			AccountOpeningApplicationBusinessOwnerInfoAbaResponseDto requestDto);

	/**
	 * 契約管理操作履歴登録
	 *
	 * @param requestDto 契約管理操作履歴登録ABAリクエストDTO
	 * @return 共通レスポンス・ボディ
	 */
	CommonHeaderAbaResponseDto contractManagementOperationHistoryRegistration(
			ContractManagementOperationHistoryRegistrationAbaRequestDto requestDto);

	/**
	 * 定期預金残高照会
	 *
	 * @param regularAccountNumber 定期預金口座番号
	 * @return 定期預金残高照会情報
	 */
	FixedTermDespositBalanceAbaResponseDto fixedTermDepositInquiry(String regularAccountNumber);

	/**
	 * 定期積金残高照会
	 *
	 * @param fixedAccountNumber 定期積金口座番号
	 * @return 定期積金残高照会情報
	 */
	FixedTermFixedBalanceAbaResponseDto fixedTermFixedInquiry(String fixedAccountNumber);

	/**
	 * 営業地区部店一覧照会
	 *
	 * @param zipCode 郵便番号
	 * @return 部店リストレスポンスDTO
	 */
	DepartmentStoreAbaResponseDto salesAreaDepartmentStoreInquiry(String zipCode);

	/**
	 * 希望店設定（個人）
	 *
	 * @param requestDto 希望店設定リクエストDTO
	 * @return 処理結果
	 */
	HopeStoreSettingIndividualInfoAbaResponseDto hopeStoreSettingIndividual(HopeStoreSettingAbaRequestDto requestDto);

	/**
	 * 希望店設定（法人）
	 *
	 * @param requestDto 希望店設定リクエストDTO
	 * @return 処理結果
	 */
	HopeStoreSettingCorporationInfoAbaResponseDto hopeStoreAbaReqDtoCorporation(
			HopeStoreSettingAbaRequestDto requestDto);

	/**
	 * 希望店設定（個人事業主）
	 *
	 * @param requestDto 希望店設定リクエストDTO
	 * @return 処理結果
	 */
	HopeStoreSettingBusinessOwnerInfoAbaResponseDto hopeStoreAbaReqDtoBusinessOwner(
			HopeStoreSettingAbaRequestDto requestDto);

	/**
	 * 口座開設申込内登録（個人）
	 *
	 * @param requestDto 口座開設申込情報（個人）ABAリクエストDTO
	 * @return 共通レスポンスヘッダー
	 */
	IndividualAbaResponseDto accountOpeningApplicationIndividualInfoRegistration(
			AccountOpeningApplicationIndividualInfoAbaResponseDto requestDto);

	/**
	 * 郵便番号の自動検索
	 *
	 * @param requestDto 郵便番号の自動検索BFFリクエストDTO
	 * @return 処理結果
	 */
	PostalCodeAutoSearchAbaResponseDto postalCodeAutoSearchResponseAba(PostalCodeAutoSearchRequestDto requestDto);

	/**
	 * [CC発行申込内容更新]API呼出
	 *
	 * @param ccIssuingAppContentUpdateAbaRequestDto CC発行申込内容更新リクエストDTO
	 * 
	 * @return CC発行申込情報レスポンスDTO
	 */
	CommonHeaderAbaResponseDto ccIssuingApplicationContentUpdateAba(
			CcIssuingAppContentUpdateAbaRequestDto ccIssuingAppContentUpdateAbaRequestDto);

	/**
	 * [契約管理操作履歴登録]API呼出
	 *
	 * @param requestDto 契約管理操作履歴登録リクエストDTO
	 * 
	 * @return 契約管理操作履歴登録レスポンスDTO
	 */
	ContractManagementOperationHistoryRegAbaResponseDto contractManagementOperationHistoryRegistrationAba(
			ContractManagementOperationHistoryRegistrationAbaRequestDto requestDto);

	/**
	 * [CC発行申込内容更新]API呼出
	 *
	 * @param requestDto CC発行申込内容更新リクエストDTO
	 * 
	 * @return CC発行申込情報
	 */
	CcIssuingApplicationContentUpdateAbaResponseDto ccIssuingApplicationContentUpdateAba(
			CcIssuingApplicationContentUpdateAbaRequestDto requestDto);

	/**
	 * 所在地情報保存
	 *
	 * @param requestDto 所在地情報保存ABAリクエストDTO
	 * @return 共通レスポンス・ボディ
	 */
	AddressInfomationAbaResponseDto saveAddressInfomation(AddressInfomationRequestDto requestDto);

	/**
	 * 本店所在地情報保存
	 *
	 * @param individualRequetAbaDto 本店所在地情報ABAリクエストDTO
	 * @return 処理結果
	 */
	CommonHeaderAbaResponseDto saveHeadOfficeAddressInformation(HeadOfficeAddressInformationAbaResponseDto requestDto);

	/**
	 * biz自宅情報保存
	 *
	 * @param requestDto biz自宅情報ABAリクエストDTO
	 * @return 共通レスポンス・ボディ
	 */
	BizHomeInfomationAbaResponseDto saveBizHomeInformation(BizHomeInfomationRequestDto requestDto);

	/**
	 * biz所在地情報保存
	 *
	 * @param individualRequetAbaDto biz所在地情報ABAリクエストDTO
	 * @return 処理結果
	 */
	CommonHeaderAbaResponseDto saveBizAddressInformation(BizAddressInfomationRequestDto requestDto);

	/**
	 * 申込完了
	 *
	 * @param ApplicationCompleteAbaRequestDto 申込完了ABAリクエストDTO
	 * @return 処理結果
	 */
	CommonHeaderAbaResponseDto accountOpeningApplicationInformation(ApplicationCompleteAbaRequestDto abaRequestDto);

	/**
	 * メールアドレス登録
	 *
	 * @param requestDto メールアドレス登録リクエストDTO
	 * @return 処理結果
	 */
	EmailAddressRegistrationAbaResponseDto emailAddressRegistration(
			EmailAddressRegistrationAbaRequestDto abaRequestDto);

	/**
	 * メールアドレス認証
	 * 
	 * @param emailAddressAuthorizationAbaRequestDto メールアドレス認証AbaリクエストDTO
	 * @return 認証済メールアドレスABAレスポンスDTO
	 */
	EmailAddressAuthorizationAbaResponseDto emailAddressAuthorization(
			EmailAddressAuthorizationAbaRequestDto emailAddressAuthorizationAbaRequestDto);

    /**
     * IVR送信
     *
     * @param abaRequestDto IVR送信ABAリクエストDTO
     * @return IVR送信ABAレスポンスDTO
     */
	IvrSendingAbaResponseDto ivrSending(IvrSendingAbaRequestDto abaRequestDto);

	/**
	 * IVR認証
	 *
	 * @param requestDto IVR認証リクエストDTO
	 * @return [確認ダイアログ]画面表示
	 */
	IvrAuthorizationAbaResponseDto ivrAuthorization(IvrAuthorizationAbaRequestDto abaRequestDto);

	/**
	 * IVR認証
	 *
	 * @param cifInquiryAbaRequetDto CIF照会ABAリクエストDTO
	 * @return CIF照会ABAレスポンスDTO
	 */
	CifInquiryAbaResponseDto cifInquiry(CifInquiryAbaRequetDto cifInquiryAbaRequetDto);

	/**
	 * 郵便番号住所照会
	 *
	 * @param zipCode 郵便番号
	 * @return 部店リストレスポンスDTO
	 */
	PostalCodeAddressInquiryAbaResponseDto postalCodeAddressInquiry(String zipCode);

	/**
	 * 営業地区部店一覧照会
	 *
	 * @param branchOfficeListInquiryAbaRequestDto 支店一覧照会リクエストDTO
	 * @return 営業地区部店一覧照会レスポンスDTO
	 */
	BranchStoreAbaResponseDto branchOfficeListInquiry(BranchOfficeListInquiryAbaRequestDto branchOfficeListInquiryAbaRequestDto);

}

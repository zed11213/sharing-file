package jp.co.jsbank.mobile.bff.service;

import org.springframework.stereotype.Service;

import jp.co.jsbank.mobile.bff.entity.TokenIdEntity;

@Service
public interface TokenIdService {

    /**
     * トークンIDを検索する
     * 
     * @return TOKEN_MAPPINGエンティティ
     */
    public void insertIdAndToken(TokenIdEntity tokenIdEntity);

    /**
     * トークンIDを追加する
     * 
     * @param tokenId トークンID
     */
    public String selectIdByToken(String tokenId);
}

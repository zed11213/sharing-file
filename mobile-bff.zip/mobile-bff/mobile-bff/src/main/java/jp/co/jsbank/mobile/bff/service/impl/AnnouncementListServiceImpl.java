package jp.co.jsbank.mobile.bff.service.impl;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.annotation.Resource;

import org.apache.commons.codec.binary.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.jsbank.mobile.bff.common.Constant;
import jp.co.jsbank.mobile.bff.common.RequestHeaderContext;
import jp.co.jsbank.mobile.bff.common.code.MobilelMsgStatusCode;
import jp.co.jsbank.mobile.bff.common.icos.IcosHandler;
import jp.co.jsbank.mobile.bff.common.redis.RedisHandler;
import jp.co.jsbank.mobile.bff.common.util.DecryptorHelper;
import jp.co.jsbank.mobile.bff.dto.AnnouncementRequestDto;
import jp.co.jsbank.mobile.bff.dto.AnnouncementResponseDto;
import jp.co.jsbank.mobile.bff.dto.InformationTextDto;
import jp.co.jsbank.mobile.bff.dto.InformationTextResponseDto;
import jp.co.jsbank.mobile.bff.dto.UpdateAnnouncementRequestDto;
import jp.co.jsbank.mobile.bff.dto.VersionDto;
import jp.co.jsbank.mobile.bff.dto.aba.AnnouncementAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.AnnouncementAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.MobileMessageInquiryAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.MobileMessageInquiryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.UpdateAnnouncementListAbaRequestDto;
import jp.co.jsbank.mobile.bff.logic.AnnouncementListLogic;
import jp.co.jsbank.mobile.bff.service.AnnouncementListService;

/**
 * お知らせ一覧サービス実装クラス
 */
@Service
public class AnnouncementListServiceImpl implements AnnouncementListService {

    @Resource
    private AnnouncementListLogic announcementListLogic;

    @Autowired
    private RedisHandler redisHandler;

    @Autowired
    private IcosHandler icosHandler;

    /**
     * お知らせ一覧取得
     *
     * @param requestDto お知らせ一覧リクエストDTO
     * @return お知らせ一覧レスポンスDTO
     */
    @Override
    public AnnouncementResponseDto getAnnouncementList(AnnouncementRequestDto requestDto) {

        // お知らせ一覧取得ABAリクエストDTO
        AnnouncementAbaRequestDto abaRequestDto = new AnnouncementAbaRequestDto();

        BeanUtils.copyProperties(requestDto, abaRequestDto);

        // 利用者IDのトークンを取得する
        String userIdToken = RequestHeaderContext.getInstance().getUserIdToken();

        if (!redisHandler.exists(userIdToken)) {
            // TODO エラー未定
            return null;
        }

        // 利用者ID設定
        abaRequestDto.setUserId(redisHandler.get(userIdToken));

        // お知らせ一覧照会
        AnnouncementAbaResponseDto announcementAbaResponseDto = announcementListLogic
                .getAnnouncementList(abaRequestDto);

        // お知らせ一覧レスポンスDTO
        AnnouncementResponseDto response = new AnnouncementResponseDto();
        // 知らせ一覧DTOリスト設定
        response.setAnncmntList(announcementAbaResponseDto.getAnncmntList());
        // 該当件数設定
        response.setDataCount(announcementAbaResponseDto.getDataCount());

        return response;
    }

    /**
     * お知らせ本文取得
     *
     * @param anncmntId お知らせID
     * @param anncmntTypeId お知らせ種別ID
     * @param documentTypeId 文書種別ID
     * @return お知らせ一覧レスポンスDTO
     */
    @Override
    public InformationTextResponseDto getInformationText(String anncmntId, String anncmntTypeId,
            String documentTypeId) {

        // JABIDのトークンを取得する
        String jbaIdToken = RequestHeaderContext.getInstance().getJbaIdToken();

        if (!redisHandler.exists(jbaIdToken)) {
            // TODO エラー未定
            return null;
        }
        // 利用者ID取得する
        String jbaId = redisHandler.get(jbaIdToken);

        // モバイルメッセージ詳細照会ABAリクエストDTO
        MobileMessageInquiryAbaRequestDto abaRequestDto = new MobileMessageInquiryAbaRequestDto();

        InformationTextDto informationTextDto = new InformationTextDto();
        // お知らせID設定
        abaRequestDto.setAnncmntId(anncmntId);
        // 顧客ID設定
        abaRequestDto.setDestinationCustId(jbaId);
        // お知らせステータス設定
        List<String> anncmntStatus = new ArrayList<String>();
        anncmntStatus.add(MobilelMsgStatusCode.PERMISSION_TO_PUBLISH);
        anncmntStatus.add(MobilelMsgStatusCode.APPROVAL_FOR_REVOCATION_OF_PUBLICATION_PERMISSION);
        abaRequestDto.setAnncmntStatus(anncmntStatus);

        // モバイルメッセージ詳細照会API
        MobileMessageInquiryAbaResponseDto abaResponseDto = announcementListLogic.mobileMessageInquiry(abaRequestDto);

        // お知らせ一覧レスポンスDTO
        InformationTextResponseDto responseDto = new InformationTextResponseDto();

        if (Objects.nonNull(abaResponseDto.getVersionList()) && abaResponseDto.getVersionList().size() > 0) {

            // バージョンDTO
            VersionDto versionDto = abaResponseDto.getVersionList().get(0);

            // モバイルメッセージ本文設定
            informationTextDto.setMobileMsg(versionDto.getMobileMsg());
            // 作成日時設定
            informationTextDto.setCreateDateAndTime(versionDto.getCreateDateAndTime());

            // 作成日時

            informationTextDto.setCreateDateAndTime(versionDto.getCreateDateAndTime());

            // タイトル
            informationTextDto.setAnncmntTitle(versionDto.getAnncmntTitle());

            // メッセージ内容種別
            informationTextDto.setMobileMsgType(versionDto.getMobileMsgType());

            // 同意チェックボックス有無
            informationTextDto.setAcceptanceChkFlg(versionDto.getAcceptanceChkFlg());

            // 画像有無フラグ
            informationTextDto.setImgFlg(versionDto.getImgFlg());

            // 画像位置
            informationTextDto.setImgVPosition(versionDto.getImgVPosition());

            // ボタンリンク先有無フラグ
            informationTextDto.setBtnLinkFlg(versionDto.getBtnLinkFlg());

            // ボタンリンク先URL
            informationTextDto.setBtnLinkUrl(versionDto.getBtnLinkUrl());

            // 画像ファイル有の場合
            if (StringUtils.equals(versionDto.getImgFlg(), "1")) {

                // 画像ファイルを取得する
                InputStream imageFileStream = icosHandler.getFile(versionDto.getImgFilename());

                if (Objects.nonNull(imageFileStream)) {

                    String imageFile = DecryptorHelper.toBase64(imageFileStream);
                    // 画像ファイル設定
                    informationTextDto.setFileStream(imageFile);
                }
            }
        }
        List<InformationTextDto> informationTextDtoList = new ArrayList<InformationTextDto>();
        informationTextDtoList.add(informationTextDto);
        responseDto.setInformationTextDtoList(informationTextDtoList);
        return responseDto;
    }

    /**
     * お知らせ一覧更新
     *
     * @param requestDto お知らせ一覧更新リクエストDTO
     * @return JsonResult
     */
    @Override
    public String updateAnnouncementList(UpdateAnnouncementRequestDto requestDto) {

        // 利用者IDのトークンを取得する
        String userIdToken = RequestHeaderContext.getInstance().getUserIdToken();

        if (!redisHandler.exists(userIdToken)) {
            // TODO エラー未定
            return null;
        }
        // 利用者ID取得する
        String userId = redisHandler.get(userIdToken);

        // お知らせ一覧更新ABAリクエストDTO
        UpdateAnnouncementListAbaRequestDto abaRequestDto = new UpdateAnnouncementListAbaRequestDto();

        BeanUtils.copyProperties(requestDto, abaRequestDto);

        // 利用者ID設定
        abaRequestDto.setUserId(userId);
        // お知らせ一覧更新API
        announcementListLogic.updateAnnouncementList(abaRequestDto);

        return Constant.OK;
    }
}

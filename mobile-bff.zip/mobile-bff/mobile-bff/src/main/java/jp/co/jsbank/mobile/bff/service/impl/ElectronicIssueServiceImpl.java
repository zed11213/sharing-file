package jp.co.jsbank.mobile.bff.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.jsbank.mobile.bff.common.RequestHeaderContext;
import jp.co.jsbank.mobile.bff.common.code.DocumentTypeCode;
import jp.co.jsbank.mobile.bff.common.exception.NotFoundException;
import jp.co.jsbank.mobile.bff.common.redis.RedisHandler;
import jp.co.jsbank.mobile.bff.dto.BorrowingRepaymentDto;
import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import jp.co.jsbank.mobile.bff.dto.ElectronicIssueRequestDto;
import jp.co.jsbank.mobile.bff.dto.InformationViewResponseDto;
import jp.co.jsbank.mobile.bff.dto.InquireReport001ResponseDto;
import jp.co.jsbank.mobile.bff.dto.InquireReport002ResponseDto;
import jp.co.jsbank.mobile.bff.dto.InquireReport003ResponseDto;
import jp.co.jsbank.mobile.bff.dto.InquireReport004ResponseDto;
import jp.co.jsbank.mobile.bff.dto.InquireReport005ResponseDto;
import jp.co.jsbank.mobile.bff.dto.InquireReport006ResponseDto;
import jp.co.jsbank.mobile.bff.dto.InquireReport007ResponseDto;
import jp.co.jsbank.mobile.bff.dto.InquireReport008ResponseDto;
import jp.co.jsbank.mobile.bff.dto.InquireReport009ResponseDto;
import jp.co.jsbank.mobile.bff.dto.InquireReport010ResponseDto;
import jp.co.jsbank.mobile.bff.dto.InquireReport011ResponseDto;
import jp.co.jsbank.mobile.bff.dto.InquireReport012ResponseDto;
import jp.co.jsbank.mobile.bff.dto.InquireReport013ResponseDto;
import jp.co.jsbank.mobile.bff.dto.InquireReport014ResponseDto;
import jp.co.jsbank.mobile.bff.dto.InquireReport015ResponseDto;
import jp.co.jsbank.mobile.bff.dto.InquireReport016ResponseDto;
import jp.co.jsbank.mobile.bff.dto.InquireReport017ResponseDto;
import jp.co.jsbank.mobile.bff.dto.InquireReport018ResponseDto;
import jp.co.jsbank.mobile.bff.dto.InquireReport019ResponseDto;
import jp.co.jsbank.mobile.bff.dto.InquireReport021ResponseDto;
import jp.co.jsbank.mobile.bff.dto.RepaymentScheduleDto;
import jp.co.jsbank.mobile.bff.dto.SuperDreamDateDto;
import jp.co.jsbank.mobile.bff.dto.SuperDreamInterestRateDto;
import jp.co.jsbank.mobile.bff.dto.aba.CreateReportPdfAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.ElectronicIssueAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport001AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport002AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport003AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport004AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport005AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport006AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport007AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport008AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport009AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport010AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport011AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport012AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport013AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport014AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport015AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport016AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport017AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport018AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport019AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.InquireReport021AbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.LotteryResultAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.LotteryResultAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.LotteryResultsDetailsDto;
import jp.co.jsbank.mobile.bff.logic.ElectronicIssueLogic;
import jp.co.jsbank.mobile.bff.service.ElectronicIssueService;

/**
 * 電子交付サービス実装クラス
 */
@Service
public class ElectronicIssueServiceImpl implements ElectronicIssueService {

    /**
     * 電子交付ロジック
     */
    @Resource
    private ElectronicIssueLogic electronicIssueLogic;

    /**
     * redis
     */
    @Autowired
    private RedisHandler redisHandler;

    /**
     * お知らせ閲覧
     *
     * @param requestDto お知らせ閲覧ABAリクエストDTO
     * @return お知らせ閲覧レスポンスDTO
     */
    @Override
    public InformationViewResponseDto informationView(ElectronicIssueRequestDto requestDto) {

        // ABAのエンドユーザーログインを認証する
        String jbaIdToken = RequestHeaderContext.getInstance().getJbaIdToken();

        if (!redisHandler.exists(jbaIdToken)) {
            // TODO エラー未定
            return null;
        }

        // redisからJBAIDを取得する
        String jbaId = redisHandler.get(jbaIdToken);

        String documentTypeCode = requestDto.getDocumentTypeCode();
        // お知らせ閲覧ABAリクエストDTO
        ElectronicIssueAbaRequestDto abaRequestDto = new ElectronicIssueAbaRequestDto();
        // 帳票ID設定
        abaRequestDto.setReportId(requestDto.getReportId());

        // 交付ステータス
        abaRequestDto.setDeliveryStatus("04");

        // 顧客ID設定
        abaRequestDto.setCustomerID(jbaId);

        abaRequestDto.setDocumentTypeCode(documentTypeCode);
        // お知らせ閲覧レスポンスDTO
        InformationViewResponseDto informationViewResponseDto = new InformationViewResponseDto();
        // 文書種別コード設定
        informationViewResponseDto.setDocumentTypeCode(documentTypeCode);
        
        // 文書種別コード
        String documentCode = documentTypeCode.substring(0, 2);
        
        try {
            if (StringUtils.equals(documentCode, DocumentTypeCode.DOCUMENTTYPE_01)) {

                // 帳票CSV内容照会_定期預金利息計算（懸賞金付）（自継）
                InquireReport001AbaResponseDto inquireReport001AbaResponseDto = electronicIssueLogic
                        .abaInquireReportCsv001(abaRequestDto);

                // エラーチェックを行う
                errorCheck(inquireReport001AbaResponseDto.getCommonResponseHeader());

                InquireReport001ResponseDto inquireReport001 = new InquireReport001ResponseDto();
                BeanUtils.copyProperties(inquireReport001AbaResponseDto, inquireReport001);

                // スーパードリームお利息計算明細表リスト
                List<SuperDreamInterestRateDto> superDreamInterestRateList = inquireReport001AbaResponseDto
                        .getSuperDreamInterestRateList();

                // 抽選結果明細リスト
                List<LotteryResultsDetailsDto> lotteryResultsDetaillist = new ArrayList<>();

                if (superDreamInterestRateList != null && superDreamInterestRateList.size() > 0) {

                    for (SuperDreamInterestRateDto superDreamInterestRateDto : superDreamInterestRateList) {

                        // 抽選結果リクエストDTO
                        LotteryResultAbaRequestDto lotteryResultabaRequestDto = new LotteryResultAbaRequestDto();
                        // 口座番号設定
                        lotteryResultabaRequestDto
                                .setAccountNumber(inquireReport001AbaResponseDto.getComAccountNo().substring(3, 10));
                        // 店番
                        lotteryResultabaRequestDto.setBranchNumber(inquireReport001AbaResponseDto.getComBranchNo());

                        lotteryResultabaRequestDto.setLotteryTimes(superDreamInterestRateDto.getLotteryNoRound());
                        // 取扱組
                        lotteryResultabaRequestDto.setLotterySet(superDreamInterestRateDto.getLotteryNoGroup());
                        // 抽選結果明細レスポンスDTO
                        LotteryResultAbaResponseDto lotteryResultAbaResponseDto = electronicIssueLogic
                                .getLotteryResultInfomation(lotteryResultabaRequestDto);

                        // エラーチェックを行う
                        errorCheck(lotteryResultAbaResponseDto.getCommonResponseHeader());

                        lotteryResultsDetaillist.addAll(lotteryResultAbaResponseDto.getLotteryResultsDetailsDtoList());

                        inquireReport001.setLotteryResultsDetailsResponseList(lotteryResultsDetaillist);
                    }
                }

                informationViewResponseDto.setInquireReport001(inquireReport001);
            } else if (StringUtils.equals(documentCode, DocumentTypeCode.DOCUMENTTYPE_02)) {

                // 帳票CSV内容照会_定期預金（懸賞金付）期日案内
                InquireReport002AbaResponseDto inquireReport002AbaResponseDto = electronicIssueLogic
                        .abaInquireReportCsv002(abaRequestDto);

                // エラーチェックを行う
                errorCheck(inquireReport002AbaResponseDto.getCommonResponseHeader());

                InquireReport002ResponseDto inquireReport002 = new InquireReport002ResponseDto();
                BeanUtils.copyProperties(inquireReport002AbaResponseDto, inquireReport002);

                // スーパードリーム期日明細表リスト
                List<SuperDreamDateDto> superDreamDateList = inquireReport002AbaResponseDto.getSuperDreamDateList();

                // 抽選結果明細リスト
                List<LotteryResultsDetailsDto> lotteryResultsDetaillist = new ArrayList<>();

                if (superDreamDateList != null && superDreamDateList.size() > 0) {

                    for (SuperDreamDateDto superDreamDateDto : superDreamDateList) {

                        // 抽選結果リクエストDTO
                        LotteryResultAbaRequestDto lotteryResultabaRequestDto = new LotteryResultAbaRequestDto();
                        // 口座番号設定
                        lotteryResultabaRequestDto
                                .setAccountNumber(inquireReport002AbaResponseDto.getComAccountNo().substring(3, 10));
                        // 店番
                        lotteryResultabaRequestDto.setBranchNumber(inquireReport002AbaResponseDto.getComBranchNo());
                        // 回次
                        lotteryResultabaRequestDto.setLotteryTimes(superDreamDateDto.getLotteryNoRound());
                        // 取扱組
                        lotteryResultabaRequestDto.setLotterySet(superDreamDateDto.getLotteryNoGroup());

                        // 抽選結果明細レスポンスDTO
                        LotteryResultAbaResponseDto lotteryResultAbaResponseDto = electronicIssueLogic
                                .getLotteryResultInfomation(lotteryResultabaRequestDto);

                        // エラーチェックを行う
                        errorCheck(lotteryResultAbaResponseDto.getCommonResponseHeader());

                        lotteryResultsDetaillist.addAll(lotteryResultAbaResponseDto.getLotteryResultsDetailsDtoList());

                        inquireReport002.setLotteryResultsDetailsResponseList(lotteryResultsDetaillist);
                    }
                }

                informationViewResponseDto.setInquireReport002(inquireReport002);
            } else if (StringUtils.equals(documentCode, DocumentTypeCode.DOCUMENTTYPE_03)) {
                // 帳票CSV内容照会_定期積金満期案内
                InquireReport003AbaResponseDto inquireReport003AbaResponseDto = electronicIssueLogic
                        .abaInquireReportCsv003(abaRequestDto);

                // エラーチェックを行う
                errorCheck(inquireReport003AbaResponseDto.getCommonResponseHeader());

                InquireReport003ResponseDto inquireReport003 = new InquireReport003ResponseDto();
                BeanUtils.copyProperties(inquireReport003AbaResponseDto, inquireReport003);
                informationViewResponseDto.setInquireReport003(inquireReport003);
                
            } else if (StringUtils.equals(documentCode, DocumentTypeCode.DOCUMENTTYPE_04)) {
             // 帳票CSV内容照会_定期預金期日案内
                InquireReport004AbaResponseDto inquireReport004AbaResponseDto = electronicIssueLogic
                        .abaInquireReportCsv004(abaRequestDto);

                // エラーチェックを行う
                errorCheck(inquireReport004AbaResponseDto.getCommonResponseHeader());

                InquireReport004ResponseDto inquireReport004 = new InquireReport004ResponseDto();
                BeanUtils.copyProperties(inquireReport004AbaResponseDto, inquireReport004);
                informationViewResponseDto.setInquireReport004(inquireReport004);

            } else if (StringUtils.equals(documentCode, DocumentTypeCode.DOCUMENTTYPE_05)) {

                // 帳票CSV内容照会_定期預金（自継）利息計算
                InquireReport005AbaResponseDto inquireReport005AbaResponseDto = electronicIssueLogic
                        .abaInquireReportCsv005(abaRequestDto);

                // エラーチェックを行う
                errorCheck(inquireReport005AbaResponseDto.getCommonResponseHeader());

                InquireReport005ResponseDto inquireReport005 = new InquireReport005ResponseDto();
                BeanUtils.copyProperties(inquireReport005AbaResponseDto, inquireReport005);
                informationViewResponseDto.setInquireReport005(inquireReport005);
            } else if (StringUtils.equals(documentCode, DocumentTypeCode.DOCUMENTTYPE_06)) {

                // 帳票CSV内容照会_定期預金（自継）大口定期利息計算
                InquireReport006AbaResponseDto inquireReport006AbaResponseDto = electronicIssueLogic
                        .abaInquireReportCsv006(abaRequestDto);

                // エラーチェックを行う
                errorCheck(inquireReport006AbaResponseDto.getCommonResponseHeader());

                InquireReport006ResponseDto inquireReport006 = new InquireReport006ResponseDto();
                BeanUtils.copyProperties(inquireReport006AbaResponseDto, inquireReport006);
                informationViewResponseDto.setInquireReport006(inquireReport006);
            } else if (StringUtils.equals(documentCode, DocumentTypeCode.DOCUMENTTYPE_07)) {

                // 帳票CSV内容照会_定期預金（自由金利）期日案内
                InquireReport007AbaResponseDto inquireReport007AbaResponseDto = electronicIssueLogic
                        .abaInquireReportCsv007(abaRequestDto);

                // エラーチェックを行う
                errorCheck(inquireReport007AbaResponseDto.getCommonResponseHeader());

                InquireReport007ResponseDto inquireReport007 = new InquireReport007ResponseDto();
                BeanUtils.copyProperties(inquireReport007AbaResponseDto, inquireReport007);
                informationViewResponseDto.setInquireReport007(inquireReport007);
            } else if (StringUtils.equals(documentCode, DocumentTypeCode.DOCUMENTTYPE_08)) {

                // 帳票CSV内容照会_借入終了案内
                InquireReport008AbaResponseDto inquireReport008AbaResponseDto = electronicIssueLogic
                        .abaInquireReportCsv008(abaRequestDto);

                // エラーチェックを行う
                errorCheck(inquireReport008AbaResponseDto.getCommonResponseHeader());

                InquireReport008ResponseDto inquireReport008 = new InquireReport008ResponseDto();
                BeanUtils.copyProperties(inquireReport008AbaResponseDto, inquireReport008);
                informationViewResponseDto.setInquireReport008(inquireReport008);
            } else if (StringUtils.equals(documentCode, DocumentTypeCode.DOCUMENTTYPE_09)) {

                // 帳票CSV内容照会_総合口座決算案内
                InquireReport009AbaResponseDto inquireReport009AbaResponseDto = electronicIssueLogic
                        .abaInquireReportCsv009(abaRequestDto);

                // エラーチェックを行う
                errorCheck(inquireReport009AbaResponseDto.getCommonResponseHeader());

                InquireReport009ResponseDto inquireReport009 = new InquireReport009ResponseDto();
                BeanUtils.copyProperties(inquireReport009AbaResponseDto, inquireReport009);
                informationViewResponseDto.setInquireReport009(inquireReport009);
            } else if (StringUtils.equals(documentCode, DocumentTypeCode.DOCUMENTTYPE_10)) {

                // 帳票CSV内容照会_融資期日案内
                InquireReport010AbaResponseDto inquireReport010AbaResponseDto = electronicIssueLogic
                        .abaInquireReportCsv010(abaRequestDto);

                // エラーチェックを行う
                errorCheck(inquireReport010AbaResponseDto.getCommonResponseHeader());

                InquireReport010ResponseDto inquireReport010 = new InquireReport010ResponseDto();
                BeanUtils.copyProperties(inquireReport010AbaResponseDto, inquireReport010);
                informationViewResponseDto.setInquireReport010(inquireReport010);
            } else if (StringUtils.equals(documentCode, DocumentTypeCode.DOCUMENTTYPE_11)) {

                // 帳票CSV内容照会_自動送金取扱終了案内
                InquireReport011AbaResponseDto inquireReport011AbaResponseDto = electronicIssueLogic
                        .abaInquireReportCsv011(abaRequestDto);

                // エラーチェックを行う
                errorCheck(inquireReport011AbaResponseDto.getCommonResponseHeader());

                InquireReport011ResponseDto inquireReport011 = new InquireReport011ResponseDto();
                BeanUtils.copyProperties(inquireReport011AbaResponseDto, inquireReport011);
                informationViewResponseDto.setInquireReport011(inquireReport011);
            } else if (StringUtils.equals(documentCode, DocumentTypeCode.DOCUMENTTYPE_12)) {

                // 帳票CSV内容照会_財形年金預金受取案内
                InquireReport012AbaResponseDto inquireReport012AbaResponseDto = electronicIssueLogic
                        .abaInquireReportCsv012(abaRequestDto);

                // エラーチェックを行う
                errorCheck(inquireReport012AbaResponseDto.getCommonResponseHeader());

                InquireReport012ResponseDto inquireReport012 = new InquireReport012ResponseDto();
                BeanUtils.copyProperties(inquireReport012AbaResponseDto, inquireReport012);
                informationViewResponseDto.setInquireReport012(inquireReport012);
            } else if (StringUtils.equals(documentCode, DocumentTypeCode.DOCUMENTTYPE_13)) {

                // 帳票CSV内容照会_証貸変動金利通知
                InquireReport013AbaResponseDto inquireReport013AbaResponseDto = electronicIssueLogic
                        .abaInquireReportCsv013(abaRequestDto);

                // エラーチェックを行う
                errorCheck(inquireReport013AbaResponseDto.getCommonResponseHeader());

                InquireReport013ResponseDto inquireReport013 = new InquireReport013ResponseDto();
                BeanUtils.copyProperties(inquireReport013AbaResponseDto, inquireReport013);
                informationViewResponseDto.setInquireReport013(inquireReport013);
            } else if (StringUtils.equals(documentCode, DocumentTypeCode.DOCUMENTTYPE_14)) {

                // 帳票CSV内容照会_借入返済通知
                InquireReport014AbaResponseDto inquireReport014AbaResponseDto = electronicIssueLogic
                        .abaInquireReportCsv014(abaRequestDto);

                // エラーチェックを行う
                errorCheck(inquireReport014AbaResponseDto.getCommonResponseHeader());

                InquireReport014ResponseDto inquireReport014 = new InquireReport014ResponseDto();
                BeanUtils.copyProperties(inquireReport014AbaResponseDto, inquireReport014);

                // ご返済予定表リスト
                List<RepaymentScheduleDto> repaymentScheduleList = inquireReport014AbaResponseDto
                        .getRepaymentScheduleList();
                if (repaymentScheduleList != null && repaymentScheduleList.size() > 0) {
                    for (RepaymentScheduleDto infoResponseDto : repaymentScheduleList) {
                        infoResponseDto
                                .setBalance(infoResponseDto.getBalance() != null ? infoResponseDto.getBalance() : "0");
                        infoResponseDto.setBonusBalance(
                                infoResponseDto.getBonusBalance() != null ? infoResponseDto.getBonusBalance() : "0");
                        infoResponseDto.setTotalBalance(String.valueOf(Integer.valueOf(infoResponseDto.getBalance())
                                + Integer.valueOf(infoResponseDto.getBonusBalance())));
                    }
                }
                inquireReport014.setRepaymentScheduleList(repaymentScheduleList);
                informationViewResponseDto.setInquireReport014(inquireReport014);
            } else if (StringUtils.equals(documentCode, DocumentTypeCode.DOCUMENTTYPE_15)) {

                // 帳票CSV内容照会_当座勘定照合表
                InquireReport015AbaResponseDto inquireReport015AbaResponseDto = electronicIssueLogic
                        .abaInquireReportCsv015(abaRequestDto);

                // エラーチェックを行う
                errorCheck(inquireReport015AbaResponseDto.getCommonResponseHeader());

                InquireReport015ResponseDto inquireReport015 = new InquireReport015ResponseDto();
                BeanUtils.copyProperties(inquireReport015AbaResponseDto, inquireReport015);
                informationViewResponseDto.setInquireReport015(inquireReport015);
            } else if (StringUtils.equals(documentCode, DocumentTypeCode.DOCUMENTTYPE_16)) {

                // 帳票CSV内容照会_当座勘定照合表兼当座勘定決算通知
                InquireReport016AbaResponseDto inquireReport016AbaResponseDto = electronicIssueLogic
                        .abaInquireReportCsv016(abaRequestDto);

                // エラーチェックを行う
                errorCheck(inquireReport016AbaResponseDto.getCommonResponseHeader());

                InquireReport016ResponseDto inquireReport016 = new InquireReport016ResponseDto();
                BeanUtils.copyProperties(inquireReport016AbaResponseDto, inquireReport016);
                informationViewResponseDto.setInquireReport016(inquireReport016);
            } else if (StringUtils.equals(documentCode, DocumentTypeCode.DOCUMENTTYPE_17)) {

                // 帳票CSV内容照会_貸金庫使用料期日案内
                InquireReport017AbaResponseDto inquireReport017AbaResponseDto = electronicIssueLogic
                        .abaInquireReportCsv017(abaRequestDto);

                // エラーチェックを行う
                errorCheck(inquireReport017AbaResponseDto.getCommonResponseHeader());

                InquireReport017ResponseDto inquireReport017 = new InquireReport017ResponseDto();
                BeanUtils.copyProperties(inquireReport017AbaResponseDto, inquireReport017);
                informationViewResponseDto.setInquireReport017(inquireReport017);
            } else if (StringUtils.equals(documentCode, DocumentTypeCode.DOCUMENTTYPE_18)) {

                // 帳票CSV内容照会_割引手形計算明細表
                InquireReport018AbaResponseDto inquireReport018AbaResponseDto = electronicIssueLogic
                        .abaInquireReportCsv018(abaRequestDto);

                // エラーチェックを行う
                errorCheck(inquireReport018AbaResponseDto.getCommonResponseHeader());

                InquireReport018ResponseDto inquireReport018 = new InquireReport018ResponseDto();
                BeanUtils.copyProperties(inquireReport018AbaResponseDto, inquireReport018);
                informationViewResponseDto.setInquireReport018(inquireReport018);
            } else if (StringUtils.equals(documentCode, DocumentTypeCode.DOCUMENTTYPE_19)) {

                // 帳票CSV内容照会_融資返済明細表
                InquireReport019AbaResponseDto inquireReport019AbaResponseDto = electronicIssueLogic
                        .abaInquireReportCsv019(abaRequestDto);

                // エラーチェックを行う
                errorCheck(inquireReport019AbaResponseDto.getCommonResponseHeader());

                InquireReport019ResponseDto inquireReport019 = new InquireReport019ResponseDto();

                BeanUtils.copyProperties(inquireReport019AbaResponseDto, inquireReport019);
                // お借入金のご返済明細表リスト
                List<BorrowingRepaymentDto> borrowingRepaymentList = inquireReport019AbaResponseDto
                        .getBorrowingRepaymentList();
                if (borrowingRepaymentList != null && borrowingRepaymentList.size() > 0) {
                    for (BorrowingRepaymentDto infoResponseDto : borrowingRepaymentList) {
                        infoResponseDto
                                .setBalance(infoResponseDto.getBalance() != null ? infoResponseDto.getBalance() : "0");
                        infoResponseDto.setBonusBalance(
                                infoResponseDto.getBonusBalance() != null ? infoResponseDto.getBonusBalance() : "0");
                        infoResponseDto.setTotalBalance(String.valueOf(Integer.valueOf(infoResponseDto.getBalance())
                                + Integer.valueOf(infoResponseDto.getBonusBalance())));
                    }
                }
                inquireReport019.setBorrowingRepaymentList(borrowingRepaymentList);
                informationViewResponseDto.setInquireReport019(inquireReport019);
            } else if (StringUtils.equals(documentCode, DocumentTypeCode.DOCUMENTTYPE_21)) {

                // 帳票CSV内容照会_財産形成預金残高通知書
                InquireReport021AbaResponseDto inquireReport021AbaResponseDto = electronicIssueLogic
                        .abaInquireReportCsv021(abaRequestDto);

                // エラーチェックを行う
                errorCheck(inquireReport021AbaResponseDto.getCommonResponseHeader());

                InquireReport021ResponseDto inquireReport021 = new InquireReport021ResponseDto();
                BeanUtils.copyProperties(inquireReport021AbaResponseDto, inquireReport021);
                informationViewResponseDto.setInquireReport021(inquireReport021);
            }

        } catch (Exception e) {

            throw new NotFoundException();
        }

        return informationViewResponseDto;
    }

    /**
     * 帳票PDFダウンロード
     *
     * @param requestDto お知らせ閲覧ABAリクエストDTO
     * @return 帳票PDFファイル
     */
    @Override
    public Object reportPdfDownload(ElectronicIssueRequestDto requestDto) {

        // ABAのエンドユーザーログインを認証する
        String jbaIdToken = RequestHeaderContext.getInstance().getJbaIdToken();

        if (!redisHandler.exists(jbaIdToken)) {
            // TODO エラー未定
            return null;
        }

        // redisからJBAIDを取得する
        String jbaId = redisHandler.get(jbaIdToken);

        // お知らせ閲覧ABAリクエストDTO
        ElectronicIssueAbaRequestDto abaRequestDto = new ElectronicIssueAbaRequestDto();

        // 帳票ID設定
        abaRequestDto.setReportId(requestDto.getReportId());

        // 交付ステータス
        abaRequestDto.setDeliveryStatus("04");

        // 顧客ID設定
        abaRequestDto.setCustomerID(jbaId);
        abaRequestDto.setDocumentTypeCode(requestDto.getDocumentTypeCode());

        CreateReportPdfAbaResponseDto abaResponseDto = new CreateReportPdfAbaResponseDto();
        try {
            // 電子交付物（PDF）照会APIを呼び出し
            abaResponseDto = electronicIssueLogic.abaCreateReportPdf(abaRequestDto);
        } catch (Exception e) {

            throw new NotFoundException();
        }
        // エラーチェックを行う
        errorCheck(abaResponseDto.getCommonResponseHeader());

        return abaResponseDto.getFormPdfFileObject();
    }

    /**
     * エラーチェック
     *
     * @param commonResponseHeader 共通レスポンスerrorCheckヘッダー
     */
    private void errorCheck(CommonResponseHeader commonResponseHeader) {

        if (Objects.nonNull(commonResponseHeader) && StringUtils.isNotEmpty(commonResponseHeader.getErrorCode())) {

            // TODO 異常コード待ち
            throw new NotFoundException();
        }
    }
}

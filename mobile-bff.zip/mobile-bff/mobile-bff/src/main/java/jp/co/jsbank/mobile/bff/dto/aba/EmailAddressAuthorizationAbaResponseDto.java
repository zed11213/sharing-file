package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 認証済メールアドレスABAレスポンスDTO
 */
@Data
public class EmailAddressAuthorizationAbaResponseDto {
	
	
	 /**
     * 共通レスポンス・ボディ
     */
    private CommonResponseHeader commonResponseHeader;
    
	 /**
     * メールアドレス
     */
    private String emailAddress;
    
    /**
    * 認証結果
    */
   private String authenticationResult;
    
 }

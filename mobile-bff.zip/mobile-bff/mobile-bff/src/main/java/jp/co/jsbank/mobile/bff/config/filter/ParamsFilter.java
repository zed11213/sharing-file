package jp.co.jsbank.mobile.bff.config.filter;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import javax.servlet.FilterChain;
import javax.servlet.ReadListener;
import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.web.filter.OncePerRequestFilter;

import com.alibaba.fastjson.JSON;

import jp.co.jsbank.mobile.bff.common.RequestHeaderContext;
import jp.co.jsbank.mobile.bff.common.util.MessageUtils;

/**
 * リクエストパラメータフィルター
 */
public class ParamsFilter extends OncePerRequestFilter {

    private static final String METHOD_POST = "POST";
    private static final String METHOD_PUT = "PUT";
    private static final String REQUEST_ENCODING = "UTF-8";
    private static final String RESPONSE_ENCODING = "text/html;charset=utf-8";
    private static final String CLASSTYPE = "java.lang.String";

    /**
     * 本人照合パス
     */
    private static final String IDENTITY_VERIFICATION_PATH = "/sign-up/ab0103";

    /**
     * バリデーションチェックメッセージID
     */
    private static final String MAAB0006 = "MAAB0006";

    /**
     * 文字種チェックメッセージID
     */
    private static final String MAAB0099 = "MAAB0099";

    @Override
    public void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {

        request.setCharacterEncoding(REQUEST_ENCODING);
        response.setContentType(RESPONSE_ENCODING);

        // リクエストヘッダ関連処理
        String checkResult = this.initHeaderContext(request);

        if (!StringUtils.isBlank(checkResult)) {

            response.setStatus(HttpStatus.BAD_REQUEST.value());
            response.getWriter().write(MessageUtils.getMessageText(MAAB0006, checkResult));

            return;
        }

        RepeatedlyReadRequestWrapper requestWrapper = new RepeatedlyReadRequestWrapper(request);

        Map<String, Object> dataMap = new HashMap<String, Object>();

        // リクエスト請求の判断
        if (METHOD_POST.equals(requestWrapper.getMethod()) || METHOD_PUT.equals(requestWrapper.getMethod())) {

            String postData = getPostData(requestWrapper);
            dataMap = modifyParams(postData);
        } else {

            dataMap = modifyParameters(requestWrapper.getParameterMap());
        }

        if (Objects.nonNull(dataMap)) {
            for (String key : dataMap.keySet()) {

                // 文字種チェック
                if (CharacterCheck.checkForbiddenCharacter(dataMap.get(key).toString())) {

                    response.setStatus(HttpStatus.BAD_REQUEST.value());
                    response.getWriter().write(MessageUtils.getMessageText(MAAB0099, dataMap.get(key).toString()));

                    return;
                }
            }
        }

        filterChain.doFilter(requestWrapper, response);
    }

    /**
     * リクエストヘッダ関連処理
     *
     * @param request HTTP請求
     * @return リクエストヘッダ
     */
    private String initHeaderContext(HttpServletRequest request) {

        // 処理結果
        String result = "";

        // 取引ID
        String transactionID = request.getHeader("transactionID");
        // アプリケーションID
        String applicationId = request.getHeader("applicationId");
        // 端末ID
        String deviceId = request.getHeader("deviceId");
        // 利用者IDトークン
        String userIdToken = request.getHeader("userIdToken");
        // バンキングIDトークン
        String jbaIdToken = request.getHeader("jbaIdToken");
        // アクセストークン
        String accessToken = request.getHeader("accessToken");
        // リフレッシュトークン
        String refreshToken = request.getHeader("refreshToken");
        // バージョン
        String version = request.getHeader("version");
        // OS
        String os = request.getHeader("os");
        // 画面ID
        String screenID = request.getHeader("screenID");
        // イベントID
        String eventID = request.getHeader("eventID");
        // 共通鍵
        String commonKey = request.getHeader("commonKey");

        StringBuffer stringBuffer = new StringBuffer();

        // 取引IDチェック
        if (StringUtils.isBlank(transactionID)) {

            stringBuffer.append("取引ID,");
        }

        // アプリケーションIDチェック
        if (StringUtils.isBlank(applicationId)) {

            stringBuffer.append("アプリケーションID,");
        }

        // 端末IDチェック
        if (StringUtils.isBlank(deviceId)) {

            stringBuffer.append("端末ID,");
        }

        // リクエストパス
        String uri = request.getRequestURI();

        if (!IDENTITY_VERIFICATION_PATH.equals(uri)) {

            // 利用者IDトークンチェック
            if (StringUtils.isBlank(userIdToken)) {

                stringBuffer.append("利用者ID,");
            }

            // バンキングIDトークン
            if (StringUtils.isBlank(jbaIdToken)) {

                stringBuffer.append("バンキングID,");
            }

        }

        // バージョンチェック
        if (StringUtils.isBlank(version)) {

            stringBuffer.append("バージョン,");
        }

        // アプリケーションIDチェック
        if (StringUtils.isBlank(os)) {

            stringBuffer.append("OS,");
        }

        // 画面IDチェック
        if (StringUtils.isBlank(screenID)) {

            stringBuffer.append("画面ID,");
        }

        // イベントIDチェック
        if (StringUtils.isBlank(eventID)) {

            stringBuffer.append("イベントID,");
        }

        // 共通鍵チェック
        if (StringUtils.isBlank(commonKey)) {

            stringBuffer.append("共通鍵,");
        }

        if (!StringUtils.isBlank(stringBuffer)) {

            stringBuffer.replace(stringBuffer.length() - 1, stringBuffer.length(), "");

            return stringBuffer.toString();
        }

        new RequestHeaderContext.RequestHeaderContextBuild().transactionID(transactionID).applicationId(applicationId)
                .deviceId(deviceId).userIdToken(userIdToken).jbaIdToken(jbaIdToken).accessToken(accessToken)
                .refreshToken(refreshToken).version(version).os(os).screenID(screenID).eventID(eventID)
                .commonKey(commonKey).bulid();

        return result;
    }

    /**
     * パラメータのスペースを削除する
     * 
     * @param params リクエスト請求パラメータ
     * @return パラメータ
     */
    private Map<String, Object> modifyParameters(Map<String, String[]> params) {

        Map<String, Object> getMap = new HashMap<String, Object>();

        Set<String> set = params.keySet();

        Iterator<String> it = set.iterator();

        while (it.hasNext()) {

            String key = (String) it.next();

            String values = params.get(key)[0];

            values = values.trim();

            getMap.put(key, values);
        }

        return getMap;
    }

    /**
     * postデータを取得する
     * 
     * @param request HTTP請求
     * @return パラメータ
     */
    private static String getPostData(HttpServletRequest request) {

        StringBuffer data = new StringBuffer();

        String line = null;

        BufferedReader reader = null;

        try {

            reader = request.getReader();

            while (null != (line = reader.readLine())) {

                data.append(line);
            }

        } catch (IOException e) {
        }

        return data.toString();
    }

    /**
     * postデータを取得する
     * 
     * @param json post請求
     * @return パラメータ
     */
    private static Map<String, Object> modifyParams(String json) {

        Map<String, Object> params = JSON.parseObject(json);

        if (Objects.nonNull(params)) {

            Map<String, Object> maps = new HashMap<>(params.size());

            for (String key : params.keySet()) {

                Object value = getValue(params.get(key));

                maps.put(key, value);
            }

            return maps;
        }

        return null;
    }

    /**
     * postデータを取得する
     * 
     * @param obj パラメータ
     * @return パラメータ
     */
    private static Object getValue(Object obj) {

        if (obj == null) {

            return null;
        }

        String type = obj.getClass().getName();

        // スペースを削除する
        if (CLASSTYPE.equals(type)) {

            obj = obj.toString().trim();
        }

        return obj;
    }

    @Override
    public void destroy() {
    }

    static class CustomHttpServletRequestWrapper extends HttpServletRequestWrapper {

        private byte[] body;

        /**
         * getBody
         * 
         * @param request HTTPリクエスト請求
         */
        CustomHttpServletRequestWrapper(HttpServletRequest request) throws IOException {
            super(request);

            BufferedReader reader = request.getReader();
            try (StringWriter writer = new StringWriter()) {
                int read;
                char[] buf = new char[1024 * 8];
                while ((read = reader.read(buf)) != -1) {
                    writer.write(buf, 0, read);
                }
                this.body = writer.getBuffer().toString().getBytes();
            }
        }

        public byte[] getBody() {
            return body;
        }

        @Override
        public ServletInputStream getInputStream() throws IOException {
            ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(body);
            return new ServletInputStream() {

                @Override
                public int read() throws IOException {
                    return byteArrayInputStream.read();
                }

                @Override
                public void setReadListener(ReadListener listener) {
                }

                @Override
                public boolean isReady() {
                    return false;
                }

                @Override
                public boolean isFinished() {
                    return false;
                }
            };
        }
    }

}

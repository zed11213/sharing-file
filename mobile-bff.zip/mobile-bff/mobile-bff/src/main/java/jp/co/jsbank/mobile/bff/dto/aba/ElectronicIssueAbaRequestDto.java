package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 電子交付ABAリクエストDTO
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class ElectronicIssueAbaRequestDto extends RequestBodyDto {

	/**
	 * 帳票ID
	 */
	private String reportId;

	/**
	 * 交付ステータス
	 */
	private String deliveryStatus;

	/**
	 * 顧客ID
	 */
	private String customerID;

	/**
	 * 文書種別コード
	 */
	private String documentTypeCode;

}

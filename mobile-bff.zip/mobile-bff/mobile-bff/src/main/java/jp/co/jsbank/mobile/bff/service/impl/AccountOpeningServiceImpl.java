package jp.co.jsbank.mobile.bff.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.jsbank.mobile.bff.common.Constant;
import jp.co.jsbank.mobile.bff.common.GetIdByTokenHandler;
import jp.co.jsbank.mobile.bff.common.RequestHeaderContext;
import jp.co.jsbank.mobile.bff.common.code.AlternateFlgCode;
import jp.co.jsbank.mobile.bff.common.code.PersonalityFlagCode;
import jp.co.jsbank.mobile.bff.common.code.SubjectNameCode;
import jp.co.jsbank.mobile.bff.common.exception.NotFoundException;
import jp.co.jsbank.mobile.bff.common.icos.IcosHandler;
import jp.co.jsbank.mobile.bff.common.redis.RedisHandler;
import jp.co.jsbank.mobile.bff.common.util.DecryptorHelper;
import jp.co.jsbank.mobile.bff.dto.AccountOpeningApplicationBusinessOwnerInfoDto;
import jp.co.jsbank.mobile.bff.dto.AccountOpeningApplicationCorporationInfoDto;
import jp.co.jsbank.mobile.bff.dto.AccountOpeningApplicationIndividualInfoDto;
import jp.co.jsbank.mobile.bff.dto.AccountOpeningApplicationInfoDto;
import jp.co.jsbank.mobile.bff.dto.AccountOpeningApplicationRequstDto;
import jp.co.jsbank.mobile.bff.dto.AddressInfoDto;
import jp.co.jsbank.mobile.bff.dto.AddressInfomationRequestDto;
import jp.co.jsbank.mobile.bff.dto.BizAddressInfomationRequestDto;
import jp.co.jsbank.mobile.bff.dto.BizHomeInfomationRequestDto;
import jp.co.jsbank.mobile.bff.dto.BranchStoreAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import jp.co.jsbank.mobile.bff.dto.CustomerInformationEntryRequestDto;
import jp.co.jsbank.mobile.bff.dto.EmailAddressAuthorizationRequestDto;
import jp.co.jsbank.mobile.bff.dto.EmailAddressRegistrationRequestDto;
import jp.co.jsbank.mobile.bff.dto.FileStreamDto;
import jp.co.jsbank.mobile.bff.dto.HeadOfficeAddressInfomationRequestDto;
import jp.co.jsbank.mobile.bff.dto.HopeStoreSettingRequestDto;
import jp.co.jsbank.mobile.bff.dto.IbPasswordSettingRequestDto;
import jp.co.jsbank.mobile.bff.dto.IcosIndividualDto;
import jp.co.jsbank.mobile.bff.dto.IdentityVerificationDocumentsDto;
import jp.co.jsbank.mobile.bff.dto.IvrAuthenticationRequestDto;
import jp.co.jsbank.mobile.bff.dto.PostalCodeAutoSearchRequestDto;
import jp.co.jsbank.mobile.bff.dto.PostalCodeAutoSearchResponseDto;
import jp.co.jsbank.mobile.bff.dto.SalesAreaDepartmentStoreInquiryResponseDto;
import jp.co.jsbank.mobile.bff.dto.SignedUrlRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.AccountOpeningApplicationAbaCorporationInfoDto;
import jp.co.jsbank.mobile.bff.dto.aba.AccountOpeningApplicationBusinessOwnerInfoAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.AccountOpeningApplicationIndividualInfoAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.AccountOpeningApplicationInfoAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.AddressInfomationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.ApplicationCompleteAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.BizHomeInfomationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.BranchOfficeListInquiryAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CcIssuingAppContentUpdateAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CifInquiryAbaRequetDto;
import jp.co.jsbank.mobile.bff.dto.aba.CifInquiryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CommonHeaderAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.ContractManagementOperationHistoryAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.ContractManagementOperationHistoryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.ContractManagementOperationHistoryRegAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.ContractManagementOperationHistoryRegistrationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.DepartmentStoreAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.EmailAddressAuthorizationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.EmailAddressAuthorizationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.EmailAddressRegistrationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.EmailAddressRegistrationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.HeadOfficeAddressInformationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.HopeStoreSettingAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.HopeStoreSettingBusinessOwnerInfoAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.HopeStoreSettingCorporationInfoAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.HopeStoreSettingIndividualInfoAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.IndividualAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.IvrAuthorizationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.IvrAuthorizationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.IvrSendingAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.IvrSendingAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.IvrSendingRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.PostalCodeAddressInquiryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.PostalCodeAutoSearchAbaResponseDto;
import jp.co.jsbank.mobile.bff.logic.AccountOpeningLogic;
import jp.co.jsbank.mobile.bff.service.AccountOpeningService;

/**
 * 新規口座開設サービス実装クラス
 */
@Service
public class AccountOpeningServiceImpl implements AccountOpeningService {

    /**
     * icosHandler
     */
    @Autowired
    private IcosHandler icosHandler;

    /**
     * redis
     */
    @Autowired
    private RedisHandler redisHandler;

    @Autowired
    private GetIdByTokenHandler getIdByTokenHandler;

    /**
     * 新規口座開設ロジック
     */
    @Resource
    private AccountOpeningLogic accountOpeningLogic;

    /**
     * 復元処理（個人）
     *
     * @param receiptNumber 受付番号
     * @return 口座開設申込情報
     */
    @Override
    public AccountOpeningApplicationInfoDto restorationProcess(String receiptNumber) {

        // 契約管理操作履歴ABAリクエストDTO
        ContractManagementOperationHistoryAbaRequestDto contractAbaRequestDto = new ContractManagementOperationHistoryAbaRequestDto();
        // 受付番号設定
        contractAbaRequestDto.setReceiptNumber(receiptNumber);
        try {
            // 契約管理操作履歴照会
            ContractManagementOperationHistoryAbaResponseDto contractManagementOperationHistoryAbaResponseDto = accountOpeningLogic
                    .contractManagementOperationHistoryInquiry(contractAbaRequestDto);

            // エラーチェック
            errorCheck(contractManagementOperationHistoryAbaResponseDto.getCommonResponseHeader());

            // 人格区分
            String personType = contractManagementOperationHistoryAbaResponseDto.getPersonType();

            // 口座開設申込情報ABAリクエストDTO
            AccountOpeningApplicationInfoAbaRequestDto abaRequestDto = new AccountOpeningApplicationInfoAbaRequestDto();
            // 受付番号
            abaRequestDto.setReceiptNumber(receiptNumber);

            // 口座開設申込情報DTO
            AccountOpeningApplicationInfoDto responseDto = new AccountOpeningApplicationInfoDto();

            // 画面ID設定
            responseDto.setScreenId(contractManagementOperationHistoryAbaResponseDto.getPageId());
            // 人格区分設定
            responseDto.setPersonType(personType);

            if (StringUtils.equals(personType, PersonalityFlagCode.INDIVIDUAL)) {

                // 口座開設申込情報（個人）DTO
                AccountOpeningApplicationIndividualInfoDto individualResponseDto = new AccountOpeningApplicationIndividualInfoDto();

                // 口座開設申込情報（個人）ABADTO
                AccountOpeningApplicationIndividualInfoAbaResponseDto individualInfoAbaReponseDto = accountOpeningLogic
                        .accountOpeningApplicationIndividualInfoInquiry(abaRequestDto);

                if (Objects.nonNull(individualInfoAbaReponseDto)) {

                    // エラーチェック
                    errorCheck(individualInfoAbaReponseDto.getCommonResponseHeader());

                    BeanUtils.copyProperties(individualInfoAbaReponseDto, individualResponseDto);
                }

                // 口座開設申込情報（個人）DTO設定
                responseDto.setIndividual(individualResponseDto);
            } else if (StringUtils.equals(personType, PersonalityFlagCode.CORPORATE)) {

                // 口座開設申込情報（法人）DTO
                AccountOpeningApplicationCorporationInfoDto corporationResponseDto = new AccountOpeningApplicationCorporationInfoDto();

                // 口座開設申込情報（法人）ABADTO
                AccountOpeningApplicationAbaCorporationInfoDto corporationInfoAbaReponseDto = accountOpeningLogic
                        .getAccountOpeningApplicationCorporateInfo(abaRequestDto);

                if (Objects.nonNull(corporationInfoAbaReponseDto)) {

                    // エラーチェック
                    errorCheck(corporationInfoAbaReponseDto.getCommonResponseHeader());

                    BeanUtils.copyProperties(corporationInfoAbaReponseDto, corporationResponseDto);
                }

                // 口座開設申込情報（個人）DTO設定
                responseDto.setCorporation(corporationResponseDto);
            } else if (StringUtils.equals(personType, PersonalityFlagCode.ONE_PERSON_OPERATION_PERSON)) {

                // 口座開設申込情報（個人事業主）DTO
                AccountOpeningApplicationBusinessOwnerInfoDto soleProprietorResponseDto = new AccountOpeningApplicationBusinessOwnerInfoDto();

                // 口座開設申込情報（個人事業主）ABADTO
                AccountOpeningApplicationBusinessOwnerInfoAbaResponseDto businessOwnerInfoAbaReponseDto = accountOpeningLogic
                        .getAccountOpeningApplicationSoleProprietorInfo(abaRequestDto);

                if (Objects.nonNull(businessOwnerInfoAbaReponseDto)) {

                    // エラーチェック
                    errorCheck(businessOwnerInfoAbaReponseDto.getCommonResponseHeader());

                    BeanUtils.copyProperties(businessOwnerInfoAbaReponseDto, soleProprietorResponseDto);
                }

                // 口座開設申込情報（個人）DTO設定
                responseDto.setSoleProprietor(soleProprietorResponseDto);
            }

            return responseDto;

        } catch (Exception e) {

            throw new NotFoundException();
        }

    }

    /**
     * 口座開設申込内容照会（個人）
     *
     * @param receiptNumber 受付番号
     * @param personType 人格区分
     * @return 口座開設申込内容照会（個人）情報
     */
    @Override
    public AccountOpeningApplicationIndividualInfoDto
            accountOpeningApplicationIndividualInfoInquiry(String receiptNumber, String personType) {

        // 口座開設申込情報（個人）DTO
        AccountOpeningApplicationIndividualInfoDto responseDto = new AccountOpeningApplicationIndividualInfoDto();
        try {

            // 人格区分が個人の場合
            if (StringUtils.equals(personType, PersonalityFlagCode.INDIVIDUAL)) {

                // 口座開設申込情報ABAリクエストDTO
                AccountOpeningApplicationInfoAbaRequestDto abaRequestDto = new AccountOpeningApplicationInfoAbaRequestDto();
                // 受付番号
                abaRequestDto.setReceiptNumber(receiptNumber);
                // 口座開設申込情報（個人）取得
                AccountOpeningApplicationIndividualInfoAbaResponseDto abaResponseDto = accountOpeningLogic
                        .accountOpeningApplicationIndividualInfoInquiry(abaRequestDto);

                if (Objects.nonNull(abaResponseDto)) {

                    // エラーチェック
                    errorCheck(abaResponseDto.getCommonResponseHeader());

                    BeanUtils.copyProperties(abaResponseDto, responseDto);
                }
            }

            return responseDto;

        } catch (Exception e) {

            throw new NotFoundException();
        }

    }

    /**
     * お客様情報入力
     *
     * @param requestDto お客様情報入力リクエストDTO
     * @return 処理結果
     */
    @Override
    public String customerInformationRegistration(CustomerInformationEntryRequestDto requestDto) {

        try {
            // 画面ID
            String pageId = RequestHeaderContext.getInstance().getScreenId();

            // 人格区分
            String personType = requestDto.getPersonType();

            // 受付番号
            String receiptNumber = requestDto.getReceiptNumber();

            // 口座開設申込情報ABAリクエストDTO
            AccountOpeningApplicationInfoAbaRequestDto abaRequestDto = new AccountOpeningApplicationInfoAbaRequestDto();
            // 受付番号
            abaRequestDto.setReceiptNumber(receiptNumber);

            // 人格区分が個人の場合
            if (StringUtils.equals(personType, PersonalityFlagCode.INDIVIDUAL)) {

                // 口座開設申込情報（個人）ABAリクエストDTO
                AccountOpeningApplicationIndividualInfoAbaResponseDto individualRequetAbaDto = new AccountOpeningApplicationIndividualInfoAbaResponseDto();

                BeanUtils.copyProperties(requestDto.getIndividual(), individualRequetAbaDto);

                // 口座開設申込内容更新（個人）
                CommonHeaderAbaResponseDto individualResult = accountOpeningLogic
                        .accountOpeningApplicationIndividualInfoUpdate(individualRequetAbaDto);

                // エラーチェック
                errorCheck(individualResult.getCommonResponseHeader());
            } else if (StringUtils.equals(personType, PersonalityFlagCode.CORPORATE)) {

                // 口座開設申込情報（法人）ABAリクエストDTO
                AccountOpeningApplicationAbaCorporationInfoDto corporationRequetAbaDto = new AccountOpeningApplicationAbaCorporationInfoDto();

                BeanUtils.copyProperties(requestDto.getCorporation(), corporationRequetAbaDto);

                // 口座開設申込内容更新（法人）
                CommonHeaderAbaResponseDto corporationResult = accountOpeningLogic
                        .accountOpeningApplicationCorporationInfoUpdate(corporationRequetAbaDto);

                // エラーチェック
                errorCheck(corporationResult.getCommonResponseHeader());
            } else if (StringUtils.equals(personType, PersonalityFlagCode.ONE_PERSON_OPERATION_PERSON)) {

                // 口座開設申込情報（個人事業主）ABAリクエストDTO
                AccountOpeningApplicationBusinessOwnerInfoAbaResponseDto businessOwnerRequetAbaDto = new AccountOpeningApplicationBusinessOwnerInfoAbaResponseDto();

                BeanUtils.copyProperties(requestDto.getSoleProprietor(), businessOwnerRequetAbaDto);

                // 口座開設申込内容更新（個人事業主）
                CommonHeaderAbaResponseDto businessOwnerResult = accountOpeningLogic
                        .accountOpeningApplicationBusinessOwnerInfoUpdate(businessOwnerRequetAbaDto);

                // エラーチェック
                errorCheck(businessOwnerResult.getCommonResponseHeader());
            }

            // 契約管理操作履歴登録ABAリクエストDTO
            ContractManagementOperationHistoryRegistrationAbaRequestDto registrationAbaRequestDto = new ContractManagementOperationHistoryRegistrationAbaRequestDto();
            // 人格区分設定
            registrationAbaRequestDto.setPersonType(personType);
            // 画面ID設定
            registrationAbaRequestDto.setPageId(pageId);
            // 受付番号設定
            registrationAbaRequestDto.setReceiptNumber(receiptNumber);

            // 契約管理操作履歴登録
            CommonHeaderAbaResponseDto registrationResult = accountOpeningLogic
                    .contractManagementOperationHistoryRegistration(registrationAbaRequestDto);

            // エラーチェック
            errorCheck(registrationResult.getCommonResponseHeader());
        } catch (Exception e) {

            throw new NotFoundException();
        }
        return Constant.OK;
    }

    /**
     * お勤め先情報入力
     *
     * @param requestDto お客様情報入力リクエストDTO
     * @return 処理結果
     */
    @Override
    public String workInformationRegistration(AccountOpeningApplicationIndividualInfoDto requestDto) {

        try {

            // 口座区分
            String accountType = requestDto.getAccountType();

            // CIF番号の存在Checkフラグ
            boolean despoitFlag = true;

            // 定期預金の場合
            if (StringUtils.equals(SubjectNameCode.FIXED_TERM_DEPOSIT, accountType)
                    || StringUtils.equals(SubjectNameCode.FIXED_TERM_FIXED, accountType)) {

                // 店番
                String branchNumber = requestDto.getBranchNumber();
                // 口座番号
                String accountNumber = requestDto.getAccountNumber();
                // CIF番号
                String cifNumber = branchNumber + accountNumber.substring(0, 7);

                // CIF照会ABAリクエストDTO
                CifInquiryAbaRequetDto cifInquiryAbaRequetDto = new CifInquiryAbaRequetDto();
                // 店番設定
                cifInquiryAbaRequetDto.setBranchNumber(branchNumber);
                // CIF番号設定
                cifInquiryAbaRequetDto.setCifNumber(cifNumber);
                // CIF照会API
                CifInquiryAbaResponseDto cifInquiryAbaResponseDto = accountOpeningLogic
                        .cifInquiry(cifInquiryAbaRequetDto);
                // エラーチェック
                errorCheck(cifInquiryAbaResponseDto.getCommonResponseHeader());

                if (Objects.isNull(cifInquiryAbaResponseDto.getCifNumber())) {

                    despoitFlag = false;
                }
            }

            if (despoitFlag) {

                // 口座開設申込情報（個人）ABAリクエストDTO
                AccountOpeningApplicationIndividualInfoAbaResponseDto individualRequetAbaDto = new AccountOpeningApplicationIndividualInfoAbaResponseDto();

                BeanUtils.copyProperties(requestDto, individualRequetAbaDto);

                // 口座開設申込内容更新（個人）
                CommonHeaderAbaResponseDto individualResult = accountOpeningLogic
                        .accountOpeningApplicationIndividualInfoUpdate(individualRequetAbaDto);
                // エラーチェック
                errorCheck(individualResult.getCommonResponseHeader());
            }

        } catch (Exception e) {

            throw new NotFoundException();
        }

        return Constant.OK;
    }

    /**
     * 営業地区部店一覧照会
     *
     * @param zipCode 郵便番号
     * @return 部店リスト
     */
    @Override
    public SalesAreaDepartmentStoreInquiryResponseDto salesAreaDepartmentStoreInquiry(String zipCode) {

        // 営業地区部店一覧照会
        DepartmentStoreAbaResponseDto abaResponse = accountOpeningLogic.salesAreaDepartmentStoreInquiry(zipCode);

        // 営業地区部店一覧照会レスポンスDTO
        SalesAreaDepartmentStoreInquiryResponseDto responseDto = new SalesAreaDepartmentStoreInquiryResponseDto();

        if (Objects.nonNull(abaResponse.getBranchListByBusArea()) && abaResponse.getBranchListByBusArea().size() > 0) {

            // 候补FLG設定
            responseDto.setAlternateFlg(AlternateFlgCode.NON_SALES_AREA_BUTEN_EMPTY);
            // 営業地区部店一覧照会設定
            responseDto.setDepartmentStoreList(abaResponse.getBranchListByBusArea());
        } else {

            // 都道府県漢字リスト
            List<String> prefectureList = Arrays.asList("東京都", "神奈川県", "川崎市", "横浜市", "相模原市", "大和市", "厚木市", "海老名市",
                    "座間市", "藤沢市", "伊勢原市", "綾瀬市", "平塚市", "秦野市", "茅ケ崎市", "鎌倉市", "高座郡", "愛甲郡");

            // 郵便番号住所照会
            PostalCodeAddressInquiryAbaResponseDto postalCodeAbaResponseDto = accountOpeningLogic
                    .postalCodeAddressInquiry(zipCode);

            List<AddressInfoDto> addressInfoList = postalCodeAbaResponseDto.getAddressInfo();
            if (Objects.nonNull(addressInfoList) && addressInfoList.size() > 0) {

                // 都道府県漢字取得
                String prefecture = addressInfoList.get(0).getPrefecture();

                if (prefectureList.contains(prefecture)) {

                    // 候补FLG設定
                    responseDto.setAlternateFlg(AlternateFlgCode.REFECTURES_KANJI_EXISTENCE);

                    // 支店一覧照会
                    BranchOfficeListInquiryAbaRequestDto branchAbaRequestDto = new BranchOfficeListInquiryAbaRequestDto();
                    // 金融機関コード設定
                    branchAbaRequestDto.setBankCode(Constant.FIXED_VALUE_FINANCIAL_CODE);
                    // 支店一覧照会
                    BranchStoreAbaResponseDto branchAbaResponseDto = accountOpeningLogic
                            .branchOfficeListInquiry(branchAbaRequestDto);

                    responseDto.setBranchList(branchAbaResponseDto.getBranchList());

                } else {

                    // 候补FLG設定
                    responseDto.setAlternateFlg(AlternateFlgCode.NON_PREFECTURES_KANJI_EXISTENCE);
                }
            }

        }

        return responseDto;
    }

    /**
     * 希望店設定
     *
     * @param requestDto 希望店設定リクエストDTO
     * @return 処理結果
     */
    @Override
    public String hopeStoreSetting(HopeStoreSettingRequestDto requestDto) {

        // 希望店設定ABAリクエストDTO
        HopeStoreSettingAbaRequestDto hopeStoreAbaReqDto = new HopeStoreSettingAbaRequestDto();

        // 人格区分
        String personType = requestDto.getPersonType();
        // 画面ID
        String screenId = RequestHeaderContext.getInstance().getScreenId();
        // 受付番号
        String receptionNumber = requestDto.getReceptionNumber();
        // 受付番号設定
        hopeStoreAbaReqDto.setReceiptNumber(receptionNumber);
        // 希望部店設定
        hopeStoreAbaReqDto.setHopeDepartmentStore(requestDto.getHopeDepartmentStore());

        try {

            if (StringUtils.equals(personType, PersonalityFlagCode.INDIVIDUAL)) {

                // 希望部店に口座開設申込内容（個人）を更新する
                HopeStoreSettingIndividualInfoAbaResponseDto hopeStoreSettingIndividualInfoAbaResponseDto = accountOpeningLogic
                        .hopeStoreSettingIndividual(hopeStoreAbaReqDto);
                // エラーチェック
                errorCheck(hopeStoreSettingIndividualInfoAbaResponseDto.getCommonResponseHeader());
            } else if (StringUtils.equals(personType, PersonalityFlagCode.CORPORATE)) {

                // 希望部店に口座開設申込内容（法人）を更新する
                HopeStoreSettingCorporationInfoAbaResponseDto hopeStoreSettingCorporationInfoAbaResponseDto = accountOpeningLogic
                        .hopeStoreAbaReqDtoCorporation(hopeStoreAbaReqDto);
                // エラーチェック
                errorCheck(hopeStoreSettingCorporationInfoAbaResponseDto.getCommonResponseHeader());
            } else if (StringUtils.equals(personType, PersonalityFlagCode.ONE_PERSON_OPERATION_PERSON)) {

                // 人格区分設定
                hopeStoreAbaReqDto.setPersonType(personType);
                // 画面ID設定
                hopeStoreAbaReqDto.setScreenId(screenId);
                // 希望部店に口座開設申込内容（個人事業者）を更新する
                HopeStoreSettingBusinessOwnerInfoAbaResponseDto hopeStoreSettingBusinessOwnerInfoAbaResponseDto = accountOpeningLogic
                        .hopeStoreAbaReqDtoBusinessOwner(hopeStoreAbaReqDto);
                // エラーチェック
                errorCheck(hopeStoreSettingBusinessOwnerInfoAbaResponseDto.getCommonResponseHeader());
            }

        } catch (Exception e) {

            throw new NotFoundException();
        }
        return Constant.OK;
    }

    /**
     * 郵便番号の自動検索
     *
     * @param requestDto 郵便番号の自動検索BFFリクエストDTO
     * @return 処理結果
     */
    @Override
    public PostalCodeAutoSearchResponseDto postalCodeAutoSearch(PostalCodeAutoSearchRequestDto requestDto) {

        try {
            // 郵便番号の自動検索ABA
            PostalCodeAutoSearchAbaResponseDto postalCodeAutoSearchResponseAbaDto = accountOpeningLogic
                    .postalCodeAutoSearchResponseAba(requestDto);

            // エラーチェック
            errorCheck(postalCodeAutoSearchResponseAbaDto.getCommonResponseHeader());

            PostalCodeAutoSearchResponseDto responseDto = new PostalCodeAutoSearchResponseDto();

            // 丁目設定
            responseDto.setChome(postalCodeAutoSearchResponseAbaDto.getChome());
            // 丁目（半角）設定
            responseDto.setChomeHalfwidth(postalCodeAutoSearchResponseAbaDto.getChomeHalfwidth());
            // 市区町村設定
            responseDto.setCity(postalCodeAutoSearchResponseAbaDto.getCity());
            // 市区町村（カナ）設定
            responseDto.setCityKana(postalCodeAutoSearchResponseAbaDto.getCityKana());
            // 都道府県設定
            responseDto.setPrefectures(postalCodeAutoSearchResponseAbaDto.getPrefectures());
            // 都道府県（カナ）設定
            responseDto.setPrefecturesKana(postalCodeAutoSearchResponseAbaDto.getPrefecturesKana());

            responseDto.setAddrDetail1(postalCodeAutoSearchResponseAbaDto.getAddrDetail1());

            responseDto.setAddrdetail1Kana(postalCodeAutoSearchResponseAbaDto.getAddrdetail1Kana());
            return responseDto;
        } catch (Exception e) {

            throw new NotFoundException();
        }
    }

    /**
     * ICOSへ本人確認書類格納
     *
     * @param requestDto 署名付きURLリクエストDTO
     * @return 処理結果
     * @throws Exception 異常
     */
    @Override
    public String putSignedUrl(SignedUrlRequestDto requestDto) throws Exception {

        // 共通鍵取得
        String commKey = RequestHeaderContext.getInstance().getCommonKey();

        // 本人確認書類DTOリスト
        List<IdentityVerificationDocumentsDto> identityDocuments = new ArrayList<>();

        // KEY PROTECT
        String bucketName = "jag-poc-bucket-helo";

        // パブリックエンドポイント
        String endPoint = "s3.jp-tok.cloud-object-storage.appdomain.cloud";

        // ファイルストリーム
        List<FileStreamDto> fileStreams = requestDto.getFileStreams();

        if (Objects.nonNull(fileStreams) && fileStreams.size() > 0) {
            for (FileStreamDto fileStreamDto : fileStreams) {

                String fileStreamDecrypt = DecryptorHelper.decrypt(fileStreamDto.getFileStream(), commKey);

                // バケットにファイルを追加する
                icosHandler.addFile(fileStreamDto.getFileName(), fileStreamDecrypt);

                // URLを取得する
                String url = icosHandler.getUrl(fileStreamDto.getFileName());

                // 本人確認書類DTO
                IdentityVerificationDocumentsDto identityDocument = new IdentityVerificationDocumentsDto();
                // 書類種類設定
                identityDocument.setDocumentsType(fileStreamDto.getDocumentsType());
                // エンドポイント設定
                identityDocument.setEndPoint(endPoint);
                // バケット設定
                identityDocument.setBucket(bucketName);
                // オブジェクトパス設定
                identityDocument.setObjectPath(url);
                // 本人確認書類追加
                identityDocuments.add(identityDocument);
            }
        }

        // 画面ID
        String pageId = RequestHeaderContext.getInstance().getScreenId();

        // 人格区分
        String personType = requestDto.getPersonType();

        // 受付番号
        String receiptNumber = requestDto.getReceiptNumber();

        // 人格区分が個人の場合
        if (StringUtils.equals(personType, PersonalityFlagCode.INDIVIDUAL)) {

            // 口座開設申込情報（個人）ABAリクエストDTO
            AccountOpeningApplicationIndividualInfoAbaResponseDto abaRequestDto = new AccountOpeningApplicationIndividualInfoAbaResponseDto();

            // 口座開設申込内容DTO（個人）
            IcosIndividualDto individual = requestDto.getIndividual();
            // 氏名漢字（姓）設定
            abaRequestDto.setCustomerKanjiLastName(individual.getNameKanjiLast());
            // 氏名漢字（名）設定
            abaRequestDto.setCustomerKanjiFirstName(individual.getNameKanjiFirst());
            // 生年月日設定
            abaRequestDto.setBirthday(individual.getBirthday());
            // 都道府県設定
            abaRequestDto.setPrefecture(individual.getPrefecture());
            // 市区町村設定
            abaRequestDto.setCity(individual.getCity());
            // 町域設定
            abaRequestDto.setAddrDetail2(individual.getAddrDetail2());

            // 本人確認書類リスト設定
            abaRequestDto.setIdentityDocuments(identityDocuments);

            // 口座開設申込内容登録（個人）
            IndividualAbaResponseDto abaResponseDto = accountOpeningLogic
                    .accountOpeningApplicationIndividualInfoRegistration(abaRequestDto);
            // エラーチェック
            errorCheck(abaResponseDto.getCommonResponseHeader());

            // 受付番号
            receiptNumber = abaResponseDto.getReceiptNumber();
        } else if (StringUtils.equals(personType, PersonalityFlagCode.CORPORATE)) {

            // 口座開設申込情報（法人）ABAリクエストDTO
            AccountOpeningApplicationAbaCorporationInfoDto abaRequestDto = new AccountOpeningApplicationAbaCorporationInfoDto();
            // 受付番号設定
            abaRequestDto.setReceiptNumber(receiptNumber);
            // 本人確認書類リスト設定
            abaRequestDto.setIdentityDocuments(identityDocuments);

            // 口座開設申込内容登録（法人）
            CommonHeaderAbaResponseDto commonResponseHeader = accountOpeningLogic
                    .accountOpeningApplicationCorporationInfoUpdate(abaRequestDto);
            // エラーチェック
            errorCheck(commonResponseHeader.getCommonResponseHeader());
        } else if (StringUtils.equals(personType, PersonalityFlagCode.ONE_PERSON_OPERATION_PERSON)) {

            // 口座開設申込情報（個人事業主）ABAリクエストDTO
            AccountOpeningApplicationBusinessOwnerInfoAbaResponseDto abaRequestDto = new AccountOpeningApplicationBusinessOwnerInfoAbaResponseDto();
            // 受付番号設定
            abaRequestDto.setReceiptNumber(receiptNumber);
            // 本人確認書類リスト設定
            abaRequestDto.setIdentityDocuments(identityDocuments);

            // 口座開設申込内容登録（個人事業主）
            CommonHeaderAbaResponseDto commonResponseHeader = accountOpeningLogic
                    .accountOpeningApplicationBusinessOwnerInfoUpdate(abaRequestDto);
            // エラーチェック
            errorCheck(commonResponseHeader.getCommonResponseHeader());
        }

        // 契約管理操作履歴登録ABAリクエストDTO
        ContractManagementOperationHistoryRegistrationAbaRequestDto registrationAbaRequestDto = new ContractManagementOperationHistoryRegistrationAbaRequestDto();
        // 人格区分設定
        registrationAbaRequestDto.setPersonType(personType);
        // 画面ID設定
        registrationAbaRequestDto.setPageId(pageId);
        // 受付番号設定
        registrationAbaRequestDto.setReceiptNumber(receiptNumber);

        // 契約管理操作履歴登録
        CommonHeaderAbaResponseDto registrationResult = accountOpeningLogic
                .contractManagementOperationHistoryRegistration(registrationAbaRequestDto);
        // エラーチェック
        errorCheck(registrationResult.getCommonResponseHeader());

        return receiptNumber;
    }

    /**
     * ご職業などの入力
     *
     * @param req uestDto ご職業などの入力リクエストDTO
     * @return 処理結果
     */
    @Override
    public String occupationEtcEntry(AccountOpeningApplicationIndividualInfoDto requestDto) {
        try {
            // 口座開設申込情報（個人）ABAリクエストDTO
            AccountOpeningApplicationIndividualInfoAbaResponseDto individualRequetAbaDto = new AccountOpeningApplicationIndividualInfoAbaResponseDto();

            BeanUtils.copyProperties(requestDto, individualRequetAbaDto);

            // 口座開設申込内容更新（個人）
            CommonHeaderAbaResponseDto individualResult = accountOpeningLogic
                    .accountOpeningApplicationIndividualInfoUpdate(individualRequetAbaDto);

            // エラーチェック
            errorCheck(individualResult.getCommonResponseHeader());

        } catch (Exception e) {

            // TODO 異常コード待ち
            throw new NotFoundException();
        }
        return Constant.OK;
    }

    /**
     * 学校情報入力
     *
     * @param requestDto 学校情報入力リクエストDTO
     * @return 処理結果
     */
    @Override
    public String schoolInfomationEntry(AccountOpeningApplicationIndividualInfoDto requestDto) {
        try {
            // 口座開設申込情報（個人）ABAリクエストDTO
            AccountOpeningApplicationIndividualInfoAbaResponseDto individualRequetAbaDto = new AccountOpeningApplicationIndividualInfoAbaResponseDto();

            BeanUtils.copyProperties(requestDto, individualRequetAbaDto);

            // 口座開設申込内容更新（個人）
            CommonHeaderAbaResponseDto individualResult = accountOpeningLogic
                    .accountOpeningApplicationIndividualInfoUpdate(individualRequetAbaDto);

            // エラーチェック
            errorCheck(individualResult.getCommonResponseHeader());

        } catch (Exception e) {

            // TODO 異常コード待ち
            throw new NotFoundException();
        }
        return Constant.OK;
    }

    /**
     * メールアドレス登録
     *
     * @param requestDto メールアドレス登録リクエストDTO
     * @return 処理結果
     */
    @Override
    public String emailAddressRegistration(EmailAddressRegistrationRequestDto requestDto) {
        // メールアドレス登録ABAリクエストDTO
        EmailAddressRegistrationAbaRequestDto abaRequestDto = new EmailAddressRegistrationAbaRequestDto();

        // 端末ID取得
        String deviceId = RequestHeaderContext.getInstance().getDeviceId();
        // 利用者ID設定
        abaRequestDto.setUserId(deviceId);
        // メールアドレス設定
        abaRequestDto.setEmailAddress(requestDto.getEmailAddress());
        // 処理区分設定
        abaRequestDto.setProcessType(requestDto.getProcessKubun());

        // メールアドレス登録ABAレスポンスDTO
        EmailAddressRegistrationAbaResponseDto abaResponseDto = new EmailAddressRegistrationAbaResponseDto();

        // メールアドレス登録
        abaResponseDto = accountOpeningLogic.emailAddressRegistration(abaRequestDto);

        // エラーチェックを行う
        errorCheck(abaResponseDto.getCommonResponseHeader());

        // 認証TRXキー
        String verifyTRXKey = abaResponseDto.getVerifyTRXKey();

        return verifyTRXKey;
    }

    /**
     * メールアドレス認証
     *
     * @param requestDto メールアドレス認証リクエストDTO
     * @return 処理結果
     */
    @Override
    public String emailAddressAuthorization(EmailAddressAuthorizationRequestDto requestDto) {

        // // 利用者ID Token取得する
        // String userIdToken = RequestHeaderContext.getInstance().getUserIdToken();
        //
        // // 利用者ID
        // String userId = redisHandler.get(userIdToken);
        try {
            // メールアドレス認証リクエストDTO
            EmailAddressAuthorizationAbaRequestDto emailAddressAuthorizationAbaRequestDto = new EmailAddressAuthorizationAbaRequestDto();
            // メールOTP設定
            emailAddressAuthorizationAbaRequestDto.setMailOTP(requestDto.getOtp());
            // 利用者ID設定
            // emailAddressAuthorizationAbaRequestDto.setUserId(userId);
            // 認証TRXキー設定
            emailAddressAuthorizationAbaRequestDto.setVerifyTRXKey(requestDto.getVerifyTRXKey());
            // メールアドレス認証
            EmailAddressAuthorizationAbaResponseDto emailAddressAuthorizationAbaResponseDto = accountOpeningLogic
                    .emailAddressAuthorization(emailAddressAuthorizationAbaRequestDto);

            // エラーチェックを行う
            errorCheck(emailAddressAuthorizationAbaResponseDto.getCommonResponseHeader());
        } catch (Exception e) {

            // TODO 異常コード待ち
            throw new NotFoundException();
        }
        return Constant.OK;
    }

    /**
     * IVR送信
     *
     * @param requestDto IVR送信リクエストDTO
     * @return 処理結果
     */
    @Override
    public String ivrSending(IvrSendingRequestDto requestDto) {

//        // 利用者IDトークン
//        String userIdToken = RequestHeaderContext.getInstance().getUserIdToken();
//
//        // 利用者ID取得する
//        String userId = redisHandler.get(userIdToken);

        try {

            // IVR送信ABAリクエストDTO
            IvrSendingAbaRequestDto abaRequestDto = new IvrSendingAbaRequestDto();
            // 電話番号設定
            abaRequestDto.setPhoneNumber(requestDto.getPhoneNumber());
            // 利用者ID
            //abaRequestDto.setUserId(userId);
            // IVR送信
            IvrSendingAbaResponseDto ivrSendingAbaResponseDto = accountOpeningLogic.ivrSending(abaRequestDto);

            // エラーチェックを行う
            errorCheck(ivrSendingAbaResponseDto.getCommonResponseHeader());

            return ivrSendingAbaResponseDto.getVerifyTRXKey();
        } catch (Exception e) {

            // TODO 異常コード待ち
            throw new NotFoundException();
        }
    }

    /**
     * IVR認証
     *
     * @param requestDto IVR認証リクエストDTO
     * @return [確認ダイアログ]画面表示
     */
    @Override
    public String ivrAuthentication(IvrAuthenticationRequestDto requestDto) {

//        // 利用者ID Token取得する
//        String userIdToken = RequestHeaderContext.getInstance().getUserIdToken();
//
//        // 利用者ID取得する
//        String userId = redisHandler.get(userIdToken);

        try {

            // IVR認証ABAリクエストDTO
            IvrAuthorizationAbaRequestDto abaRequestDto = new IvrAuthorizationAbaRequestDto();
            // 利用者ID設定
           // abaRequestDto.setUserId(userId);
            // 受付番号設定
            abaRequestDto.setReceiptNumber(requestDto.getReceiptNumber());
            // ivrOTP設定
            abaRequestDto.setIvrOTP(requestDto.getIvrOTP());
            // 認証TRXキー設定
            abaRequestDto.setVerifyTRXKey(requestDto.getVerifyTRXKey());

            // IVR認証
            IvrAuthorizationAbaResponseDto ivrAuthorizationAbaResponseDto = accountOpeningLogic
                    .ivrAuthorization(abaRequestDto);

            // エラーチェックを行う
            errorCheck(ivrAuthorizationAbaResponseDto.getCommonResponseHeader());

        } catch (Exception e) {

            // TODO 異常コード待ち
            throw new NotFoundException();
        }

        return requestDto.getReceiptNumber();
    }

    /**
     * IBパスワード設定処理
     *
     * @param requestDto IBパスワード設定BFFリクエストDTO
     * @return IBパスワード設定レスポンスDTO
     * 
     */
    @Override
    public String ibPasswordSetting(IbPasswordSettingRequestDto requestDto) {
        try {
            // 受付番号
            String receiptNumber = requestDto.getReceptionNumber();

            // 口座開設申込内容更新リクエストDTO
            CcIssuingAppContentUpdateAbaRequestDto ccIssuingAppContentUpdateAbaRequestDto = new CcIssuingAppContentUpdateAbaRequestDto();
            // 受付番号設定
            ccIssuingAppContentUpdateAbaRequestDto.setReceptionNumber(receiptNumber);

            // 口座開設申込内容更新
            CommonHeaderAbaResponseDto commonHeaderAbaResponseDto = accountOpeningLogic
                    .ccIssuingApplicationContentUpdateAba(ccIssuingAppContentUpdateAbaRequestDto);

            // エラーチェック
            errorCheck(commonHeaderAbaResponseDto.getCommonResponseHeader());

            // 人格区分
            String personType = requestDto.getPersonalityKubun();
            // 画面ID
            String screenId = RequestHeaderContext.getInstance().getScreenId();

            // 契約管理操作履歴登録リクエストDTO
            ContractManagementOperationHistoryRegistrationAbaRequestDto registrationAbaRequestDto = new ContractManagementOperationHistoryRegistrationAbaRequestDto();
            // 人格区分設定
            registrationAbaRequestDto.setPersonType(personType);
            // 画面ID設定
            registrationAbaRequestDto.setPageId(screenId);
            // 受付番号設定
            registrationAbaRequestDto.setReceiptNumber(receiptNumber);

            // 契約管理操作履歴登録ResponseDTO
            ContractManagementOperationHistoryRegAbaResponseDto regAbaResponseDto = accountOpeningLogic
                    .contractManagementOperationHistoryRegistrationAba(registrationAbaRequestDto);
            // エラーチェック
            errorCheck(regAbaResponseDto.getCommonResponseHeader());

        } catch (Exception e) {

            throw new NotFoundException();
        }
        return Constant.OK;
    }

    /**
     * 所在地情報保存
     *
     * @param requestDto 所在地情報リクエストDTO
     * @return 処理結果
     */
    @Override
    public String saveAddressInfomation(AddressInfomationRequestDto requestDto) {
        try {
            // 所在地情報
            AddressInfomationAbaResponseDto abaResponseDto = accountOpeningLogic.saveAddressInfomation(requestDto);

            // エラーチェック
            errorCheck(abaResponseDto.getCommonResponseHeader());
            return abaResponseDto.getReceiptNumber();
        } catch (Exception e) {

            throw new NotFoundException();
        }
    }

    /**
     * 本店所在地情報保存
     *
     * @param requestDto 本店所在地情報リクエストDTO
     * @return 処理結果
     */
    @Override
    public String saveHeadOfficeAddressInformation(HeadOfficeAddressInfomationRequestDto requestDto) {
        try {
            // 本店所在地情報ABAリクエストDTO
            HeadOfficeAddressInformationAbaResponseDto headOfficeAddressInformationAbaResponseDto = new HeadOfficeAddressInformationAbaResponseDto();
            // 本店所在地情報
            CommonHeaderAbaResponseDto saveHeadOfficeAddress = accountOpeningLogic
                    .saveHeadOfficeAddressInformation(headOfficeAddressInformationAbaResponseDto);

            // エラーチェック
            errorCheck(saveHeadOfficeAddress.getCommonResponseHeader());
        } catch (Exception e) {

            throw new NotFoundException();
        }
        return Constant.OK;
    }

    /**
     * biz自宅情報保存
     *
     * @param requestDto biz自宅情報リクエストDTO
     * @return 処理結果
     */
    @Override
    public String saveBizHomeInformation(BizHomeInfomationRequestDto requestDto) {
        try {
            // biz自宅情報保存ABAリクエストDTO
            BizHomeInfomationAbaResponseDto abaResponseDto = accountOpeningLogic.saveBizHomeInformation(requestDto);

            // エラーチェック
            errorCheck(abaResponseDto.getCommonResponseHeader());
            return abaResponseDto.getReceiptNumber();

        } catch (Exception e) {

            throw new NotFoundException();
        }
    }

    /**
     * biz所在地情報保存
     *
     * @param requestDto biz自宅情報リクエストDTO
     * @return 処理結果
     */
    @Override
    public String saveBizAddressInformation(BizAddressInfomationRequestDto requestDto) {
        try {
            // biz所在地情報biz所在地情報
            CommonHeaderAbaResponseDto saveBizAddressResult = accountOpeningLogic.saveBizAddressInformation(requestDto);

            // エラーチェック
            errorCheck(saveBizAddressResult.getCommonResponseHeader());
        } catch (Exception e) {

            throw new NotFoundException();
        }
        return Constant.OK;
    }

    /**
     * 申込完了
     *
     * @param requestDto 申込完了リクエストDTO
     * @return 処理結果
     */
    @Override
    public String accountOpeningApplicationInformation(AccountOpeningApplicationRequstDto requestDto) {
        try {
            // 口座開設申込完了情報ABAレスポンスDTO
            ApplicationCompleteAbaRequestDto abaRequestDto = new ApplicationCompleteAbaRequestDto();
            // 受付番号設定
            abaRequestDto.setReceiptNumber(requestDto.getReceiptNumber());

            CommonHeaderAbaResponseDto applicationCompleteResult = accountOpeningLogic
                    .accountOpeningApplicationInformation(abaRequestDto);

            // エラーチェック
            errorCheck(applicationCompleteResult.getCommonResponseHeader());

            // 契約管理操作履歴登録ABAリクエストDTO
            ContractManagementOperationHistoryRegistrationAbaRequestDto registrationAbaRequestDto = new ContractManagementOperationHistoryRegistrationAbaRequestDto();
            // 人格区分設定
            registrationAbaRequestDto.setPersonType(requestDto.getPersonType());
            // 契約管理操作履歴登録
            CommonHeaderAbaResponseDto registrationResult = accountOpeningLogic
                    .contractManagementOperationHistoryRegistration(registrationAbaRequestDto);
            // エラーチェック
            errorCheck(registrationResult.getCommonResponseHeader());

        } catch (Exception e) {

            throw new NotFoundException();
        }
        return Constant.OK;
    }

    /**
     * エラーチェック
     *
     * @param commonResponseHeader 共通レスポンスヘッダー
     */
    private void errorCheck(CommonResponseHeader commonResponseHeader) {
        if (Objects.nonNull(commonResponseHeader) && StringUtils.isNotEmpty(commonResponseHeader.getErrorCode())) {
            // TODO 異常コード待ち
            throw new NotFoundException();
        }
    }
}

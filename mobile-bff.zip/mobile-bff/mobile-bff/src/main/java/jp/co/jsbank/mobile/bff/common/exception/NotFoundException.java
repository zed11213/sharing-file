package jp.co.jsbank.mobile.bff.common.exception;

/**
 * データなし例外。
 *
 */
public class NotFoundException extends BusinessException {

	private static final long serialVersionUID = -1L;

	/**
	 * NotFoundExceptionのコンスタント。
	 * 
	 * @param errorCode エラーコード
	 */
	public NotFoundException() {
		super("404");
	}
}

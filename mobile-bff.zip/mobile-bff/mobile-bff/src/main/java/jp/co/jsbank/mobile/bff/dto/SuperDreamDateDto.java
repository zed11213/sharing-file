package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * スーパードリーム期日明細表DTO
 */
@Data
public class SuperDreamDateDto {

	/**
	 * 預金番号
	 */
	private String depositNumber;

	/**
	 * 預金種類
	 */
	private String depositType;

	/**
	 * 種類
	 */
	private String type;

	/**
	 * お預り金額
	 */
	private String depositAmount;

	/**
	 * 利率
	 */
	private String interestRate;

	/**
	 * 税区分
	 */
	private String taxType;

	/**
	 * 期日
	 */
	private String expiryDate;

	/**
	 * 計算期間
	 */
	private String countDuration;
	
	/**
	 * 計算期間単位
	 */
	private String countDurationUnit;
	
	/**
	 * お利息
	 */
	private String interestAmount;

	/**
	 * お利息_国税
	 */
	private String interestNationalTax;

	/**
	 * お利息_地方税
	 */
	private String interestLocalTax;

	/**
	 * 差引お利息
	 */
	private String deductedInterestAmount;

	/**
	 * 懸賞金
	 */
	private String rewardAmount;

	/**
	 * 懸賞金_国税
	 */
	private String rewardNationalTax;

	/**
	 * 懸賞金_地方税
	 */
	private String rewardLocalTax;

	/**
	 * 差引懸賞金
	 */
	private String deductedRewardAmount;

	/**
	 * 備考１
	 */
	private String remark1;

	/**
	 * 備考２
	 */
	private String remark2;

	/**
	 * 備考３
	 */
	private String remark3;

	/**
	 * 抽せん番号_回
	 */
	private String lotteryNoRound;

	/**
	 * 抽せん番号_組
	 */
	private String lotteryNoGroup;

	/**
	 * 抽せん番号_開始
	 */
	private String lotteryNoStart;

	/**
	 * 抽せん番号_終了
	 */
	private String lotteryNoEnd;

	/**
	 * 相続停止文言
	 */
	private String successionStopValue;
}

package jp.co.jsbank.mobile.bff.entity;

import javax.persistence.Column;
import javax.persistence.Table;
import lombok.Data;

/**
 * TOKEN_MAPPINGエンティティ
 */
@Data
@Table(name = "TOKEN_MAPPING")
public class TokenIdEntity {

    @Column(name = "ID")
    private String id;

    @Column(name = "TOKEN_ID")
    private String tokenId;
    
    @Column(name = "TYPE")
    private String type;
    
    @Column(name = "STATUS")
    private String status;
}

package jp.co.jsbank.mobile.bff.service;

import org.springframework.stereotype.Service;

import jp.co.jsbank.mobile.bff.dto.AccountInformationResponseDto;
import jp.co.jsbank.mobile.bff.dto.AuthenticationKeyIssuanceResponseDto;
import jp.co.jsbank.mobile.bff.dto.CifInfomationResponseDto;
import jp.co.jsbank.mobile.bff.dto.DeleteUseAccountRequestDto;
import jp.co.jsbank.mobile.bff.dto.EmailAddRegistrationRequestDto;
import jp.co.jsbank.mobile.bff.dto.EmailAddUpdateRequestDto;
import jp.co.jsbank.mobile.bff.dto.NotificationSettingRequestDto;
import jp.co.jsbank.mobile.bff.dto.NotificationSettingResponseDto;
import jp.co.jsbank.mobile.bff.dto.PassbooklessSettingRequestDto;
import jp.co.jsbank.mobile.bff.dto.PassbooklessSettingResponseDto;
import jp.co.jsbank.mobile.bff.dto.UpdateDesignInfomationRequestDto;
import jp.co.jsbank.mobile.bff.dto.UseAccountRegistrationRequestDto;
import jp.co.jsbank.mobile.bff.dto.UserAdditionalConfirmationStatUpdateRequestDto;
import jp.co.jsbank.mobile.bff.dto.UserAttributeInquiryConfirmationResponseDto;
import jp.co.jsbank.mobile.bff.dto.UserInfo;
import jp.co.jsbank.mobile.bff.dto.UserInformationDetailsResponseDto;

/**
 * 各種登録設定サービス
 */
@Service
public interface VariousRegistrationPreferenceService {

    /**
     * 通知設定情報取得
     *
     * @return 通知設定情報UserInfo
     */
    NotificationSettingResponseDto getNotificationSetting();

    /**
     * 通知設定情報変更
     *
     * @param requestDto 通知設定BFFリクエストDTO
     * @return 処理結果
     */
    String changeNotificationSettingInfo(NotificationSettingRequestDto requestDto);

    /**
     * 利用口座削除
     *
     * @param requestDto 通知設定BFFリクエストDTO
     * @return 処理結果
     */
    String deleteUseAccount(DeleteUseAccountRequestDto requestDto);

    /**
     * デザイン取得
     *
     * @return 設定値
     */
    String getDesignInfomation();

    /**
     * メールアドレス変更
     *
     * @param requestDto メールアドレス変更リクエストDTO
     * @return 処理結果
     */
    String emailAddressChanging(EmailAddUpdateRequestDto requestDto);

    /**
     * メールアドレス登録
     *
     * @param requestDto メールアドレス登録BFFリクエストDTO
     * @return 処理結果
     */
    String emailAddressRegistration(EmailAddRegistrationRequestDto requestDto);

    /**
     * 取引停止
     *
     * @return 利用者情報レスポンスDTOリスト
     */
    String tradingStop();

    /**
     * 利用者追加確認ステータス更新
     * 
     * @param requestDto 利用者追加確認ステータス更新BFFリクエストDTO
     * @return 処理結果
     */
    String userAdditionalConfirmationStatUpdate(UserAdditionalConfirmationStatUpdateRequestDto requestDto);

    /**
     * 認証キー発行
     * 
     * @param requestDto 利用者情報
     * @return 認証キー
     */
    AuthenticationKeyIssuanceResponseDto authenticationKeyIssuance(UserInfo requestDto);

    /**
     * デザイン更新
     *
     * @param requestDto デザイン更新BFFリクエストDTO
     * @return 処理結果
     */
    String updateDesignInfomation(UpdateDesignInfomationRequestDto requestDto);

    /**
     * 法人利用者情報一覧取得
     *
     * @param jbaIdToken JBAID
     * @return 処理結果
     */
    UserInformationDetailsResponseDto getJuridicalPersonUserDetails();

    /**
     * CIF情報取得
     *
     * @return 処理結果
     */
    CifInfomationResponseDto getCifInfomation();

    /**
     * 口座情報取得
     *
     * @param branchCode 店番
     * @param cifNumber CIF番号
     * @return 処理結果
     */
    AccountInformationResponseDto getAccountInformation(String branchCode, String cifNumber);

    /**
     * 利用口座登録
     *
     * @param requestDto 利用口座登録BFFリクエストDTO
     * @return 処理結果
     */
    String useAccountRegistration(UseAccountRegistrationRequestDto requestDto);

    /**
     * 利用口座登録確認情報取得
     *
     * @param branchCode 店番
     * @param accountNumber 口座番号
     * @param accountType 預金種目
     * @return 処理結果
     */
    UserAttributeInquiryConfirmationResponseDto getUseAccountRegistrationConfirmation(String branchCode,
            String accountNumber, String accountType);

    /**
     * 通帳レス情報取得
     *
     * @return 処理結果
     */
    PassbooklessSettingResponseDto getPassBooklessInformation();

    /**
     * 通帳レス設定
     *
     * @return 処理結果
     */
    String passBooklessSetting(PassbooklessSettingRequestDto requestDto);

}

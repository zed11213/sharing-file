package jp.co.jsbank.mobile.bff.logic.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.jsbank.mobile.bff.common.builder.ParameterBuilder;
import jp.co.jsbank.mobile.bff.common.code.MobilelMsgStatusCode;
import jp.co.jsbank.mobile.bff.config.RestClientConfig;
import jp.co.jsbank.mobile.bff.dto.AnnouncementDto;
import jp.co.jsbank.mobile.bff.dto.VersionDto;
import jp.co.jsbank.mobile.bff.dto.aba.AnnouncementAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.AnnouncementAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CifNumberDto;
import jp.co.jsbank.mobile.bff.dto.aba.CommonHeaderAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.MobileMessageInquiryAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.MobileMessageInquiryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.UpdateAnnouncementListAbaRequestDto;
import jp.co.jsbank.mobile.bff.logic.AnnouncementListLogic;

/**
 * お知らせ一覧ロジック実装クラス
 */
@Service
public class AnnouncementListLogicImpl implements AnnouncementListLogic {

    @Autowired
    RestClientConfig restClientConfig;

    /**
     * お知らせ一覧参照
     *
     * @param requestDto お知らせ一覧ABAリクエストDTO
     * @return 処理結果
     */
    @Override
    public AnnouncementAbaResponseDto getAnnouncementList(AnnouncementAbaRequestDto requestDto) {

        ParameterBuilder parameterDto = ParameterBuilder.build(requestDto);

        // お知らせ一覧参照
        AnnouncementAbaResponseDto abaResponseDto = new AnnouncementAbaResponseDto();

        // お知らせ一覧レスポンスDTO
        AnnouncementDto announcementDto1 = new AnnouncementDto();

        /**
         * お知らせ種別コード
         */
        announcementDto1.setAnncmntType("03");

        /**
         * 文書種別コード
         */
        announcementDto1.setDocumentType("01010");

        /**
         * お知らせID
         */
        announcementDto1.setAnncmntId("1234");

        /**
         * 申込ID
         */
        announcementDto1.setApplyId("0001");

        /**
         * 顧客ID
         */
        announcementDto1.setCustomerId("100001");

        /**
         * CIF番号リスト
         */
        CifNumberDto cifNo = new CifNumberDto();
        cifNo.setCifNo("0001");
        announcementDto1.setCifNoList(Arrays.asList(cifNo));

        /**
         * 受付案内種類
         */
        announcementDto1.setReceptionGuideType("01");

        /**
         * 掲載開始日時
         */
        announcementDto1.setAnncmntStartDateAndTime("2022-05-01");

        /**
         * 掲載終了日時
         */
        announcementDto1.setAnncmntEndDateAndTime("2022-05-03");

        /**
         * 作成日時
         */
        announcementDto1.setCreateTs("2022-05-01");

        /**
         * 公開日時
         */
        announcementDto1.setAnncmntDateAndTime("2022-05-23");

        /**
         * お知らせタイトル
         */
        announcementDto1.setAnncmntTitle("スーパードリームお利息計算書（自継用）");

        /**
         * 店番
         */
        announcementDto1.setBranchCode("001");

        /**
         * 口座番号
         */
        announcementDto1.setAccountNumber("1234567");

        /**
         * 預金種目
         */
        announcementDto1.setAccountType("01");

        /**
         * お気に入りフラグ
         */
        announcementDto1.setBookmarkFlg("0");

        /**
         * 既読フラグ
         */
        announcementDto1.setReadFlag("0");

        /**
         * 個別確認結果フラグ
         */
        announcementDto1.setConfirmFlg("0");

        /**
         * 帳票最終ダウンロード日時
         */
        announcementDto1.setReportLastDlTs("2022-05-23");

        /**
         * カナ氏名
         */
        announcementDto1.setCustomerName("ﾀｶﾅ");

        /**
         * 漢字氏名
         */
        announcementDto1.setCustomerKanjiName("高梨沙羅");

        /**
         * 生（設立）年月日
         */
        announcementDto1.setBirthday("2022-05-23");

        /**
         * 人格区分
         */
        announcementDto1.setPersonCode("01");

        // お知らせ一覧レスポンスDTO
        AnnouncementDto announcementDto2 = new AnnouncementDto();

        /**
         * お知らせ種別コード
         */
        announcementDto2.setAnncmntType("03");

        /**
         * 文書種別コード
         */
        announcementDto2.setDocumentType("02010");

        /**
         * お知らせID
         */
        announcementDto2.setAnncmntId("1234");

        /**
         * 申込ID
         */
        announcementDto2.setApplyId("0001");

        /**
         * 顧客ID
         */
        announcementDto2.setCustomerId("100001");

        /**
         * CIF番号リスト
         */
        announcementDto2.setCifNoList(Arrays.asList(cifNo));

        /**
         * 受付案内種類
         */
        announcementDto2.setReceptionGuideType("01");

        /**
         * 掲載開始日時
         */
        announcementDto2.setAnncmntStartDateAndTime("2022-05-01");

        /**
         * 掲載終了日時
         */
        announcementDto2.setAnncmntEndDateAndTime("2022-05-03");

        /**
         * 作成日時
         */
        announcementDto2.setCreateTs("2022-05-01");

        /**
         * 公開日時
         */
        announcementDto2.setAnncmntDateAndTime("2022-05-23");

        /**
         * お知らせタイトル
         */
        announcementDto2.setAnncmntTitle("スーパードリーム期日のご案内");

        /**
         * 店番
         */
        announcementDto2.setBranchCode("001");

        /**
         * 口座番号
         */
        announcementDto2.setAccountNumber("1234567");

        /**
         * 預金種目
         */
        announcementDto2.setAccountType("01");

        /**
         * お気に入りフラグ
         */
        announcementDto2.setBookmarkFlg("0");

        /**
         * 既読フラグ
         */
        announcementDto2.setReadFlag("0");

        /**
         * 個別確認結果フラグ
         */
        announcementDto2.setConfirmFlg("0");

        /**
         * 帳票最終ダウンロード日時
         */
        announcementDto2.setReportLastDlTs("2022-05-23");

        /**
         * カナ氏名
         */
        announcementDto2.setCustomerName("ﾀｶﾅ");

        /**
         * 漢字氏名
         */
        announcementDto2.setCustomerKanjiName("高梨沙羅");

        /**
         * 生（設立）年月日
         */
        announcementDto2.setBirthday("2022-05-23");

        /**
         * 人格区分
         */
        announcementDto2.setPersonCode("01");

        // お知らせ一覧レスポンスDTO
        AnnouncementDto announcementDto3 = new AnnouncementDto();

        /**
         * お知らせ種別コード
         */
        announcementDto3.setAnncmntType("03");

        /**
         * 文書種別コード
         */
        announcementDto3.setDocumentType("03010");

        /**
         * お知らせID
         */
        announcementDto3.setAnncmntId("1234");

        /**
         * 申込ID
         */
        announcementDto3.setApplyId("0001");

        /**
         * 顧客ID
         */
        announcementDto3.setCustomerId("100001");

        /**
         * CIF番号リスト
         */
        announcementDto3.setCifNoList(Arrays.asList(cifNo));

        /**
         * 受付案内種類
         */
        announcementDto3.setReceptionGuideType("01");

        /**
         * 掲載開始日時
         */
        announcementDto3.setAnncmntStartDateAndTime("2022-05-01");

        /**
         * 掲載終了日時
         */
        announcementDto3.setAnncmntEndDateAndTime("2022-05-03");

        /**
         * 作成日時
         */
        announcementDto3.setCreateTs("2022-05-01");

        /**
         * 公開日時
         */
        announcementDto3.setAnncmntDateAndTime("2022-05-23");

        /**
         * お知らせタイトル
         */
        announcementDto3.setAnncmntTitle("定期預金等期日のご案内（規制金利 通常分）");

        /**
         * 店番
         */
        announcementDto3.setBranchCode("001");

        /**
         * 口座番号
         */
        announcementDto3.setAccountNumber("1234567");

        /**
         * 預金種目
         */
        announcementDto3.setAccountType("01");

        /**
         * お気に入りフラグ
         */
        announcementDto3.setBookmarkFlg("0");

        /**
         * 既読フラグ
         */
        announcementDto3.setReadFlag("0");

        /**
         * 個別確認結果フラグ
         */
        announcementDto3.setConfirmFlg("0");

        /**
         * 帳票最終ダウンロード日時
         */
        announcementDto3.setReportLastDlTs("2022-05-23");

        /**
         * カナ氏名
         */
        announcementDto3.setCustomerName("ﾀｶﾅ");

        /**
         * 漢字氏名
         */
        announcementDto3.setCustomerKanjiName("高梨沙羅");

        /**
         * 生（設立）年月日
         */
        announcementDto3.setBirthday("2022-05-23");

        /**
         * 人格区分
         */
        announcementDto3.setPersonCode("01");

        // お知らせ一覧レスポンスDTO
        AnnouncementDto announcementDto4 = new AnnouncementDto();

        /**
         * お知らせ種別コード
         */
        announcementDto4.setAnncmntType("03");

        /**
         * 文書種別コード
         */
        announcementDto4.setDocumentType("04010");

        /**
         * お知らせID
         */
        announcementDto4.setAnncmntId("1234");

        /**
         * 申込ID
         */
        announcementDto4.setApplyId("0001");

        /**
         * 顧客ID
         */
        announcementDto4.setCustomerId("100001");

        /**
         * CIF番号リスト
         */
        announcementDto4.setCifNoList(Arrays.asList(cifNo));

        /**
         * 受付案内種類
         */
        announcementDto4.setReceptionGuideType("01");

        /**
         * 掲載開始日時
         */
        announcementDto4.setAnncmntStartDateAndTime("2022-05-01");

        /**
         * 掲載終了日時
         */
        announcementDto4.setAnncmntEndDateAndTime("2022-05-03");

        /**
         * 作成日時
         */
        announcementDto4.setCreateTs("2022-05-01");

        /**
         * 公開日時
         */
        announcementDto4.setAnncmntDateAndTime("2022-05-23");

        /**
         * お知らせタイトル
         */
        announcementDto4.setAnncmntTitle("定期積金満期のご案内");

        /**
         * 店番
         */
        announcementDto4.setBranchCode("001");

        /**
         * 口座番号
         */
        announcementDto4.setAccountNumber("1234567");

        /**
         * 預金種目
         */
        announcementDto4.setAccountType("01");

        /**
         * お気に入りフラグ
         */
        announcementDto4.setBookmarkFlg("0");

        /**
         * 既読フラグ
         */
        announcementDto4.setReadFlag("0");

        /**
         * 個別確認結果フラグ
         */
        announcementDto4.setConfirmFlg("0");

        /**
         * 帳票最終ダウンロード日時
         */
        announcementDto4.setReportLastDlTs("2022-05-23");

        /**
         * カナ氏名
         */
        announcementDto4.setCustomerName("ﾀｶﾅ");

        /**
         * 漢字氏名
         */
        announcementDto4.setCustomerKanjiName("高梨沙羅");

        /**
         * 生（設立）年月日
         */
        announcementDto4.setBirthday("2022-05-23");

        /**
         * 人格区分
         */
        announcementDto4.setPersonCode("01");

        // お知らせ一覧レスポンスDTO
        AnnouncementDto announcementDto5 = new AnnouncementDto();

        /**
         * お知らせ種別コード
         */
        announcementDto5.setAnncmntType("03");

        /**
         * 文書種別コード
         */
        announcementDto5.setDocumentType("05010");

        /**
         * お知らせID
         */
        announcementDto5.setAnncmntId("1234");

        /**
         * 申込ID
         */
        announcementDto5.setApplyId("0001");

        /**
         * 顧客ID
         */
        announcementDto5.setCustomerId("100001");

        /**
         * CIF番号リスト
         */
        announcementDto5.setCifNoList(Arrays.asList(cifNo));

        /**
         * 受付案内種類
         */
        announcementDto5.setReceptionGuideType("01");

        /**
         * 掲載開始日時
         */
        announcementDto5.setAnncmntStartDateAndTime("2022-05-01");

        /**
         * 掲載終了日時
         */
        announcementDto5.setAnncmntEndDateAndTime("2022-05-03");

        /**
         * 作成日時
         */
        announcementDto5.setCreateTs("2022-05-01");

        /**
         * 公開日時
         */
        announcementDto5.setAnncmntDateAndTime("2022-05-23");

        /**
         * お知らせタイトル
         */
        announcementDto5.setAnncmntTitle("自動継続定期預金お利息計算書（自動継続定期）");

        /**
         * 店番
         */
        announcementDto5.setBranchCode("001");

        /**
         * 口座番号
         */
        announcementDto5.setAccountNumber("1234567");

        /**
         * 預金種目
         */
        announcementDto5.setAccountType("01");

        /**
         * お気に入りフラグ
         */
        announcementDto5.setBookmarkFlg("0");

        /**
         * 既読フラグ
         */
        announcementDto5.setReadFlag("0");

        /**
         * 個別確認結果フラグ
         */
        announcementDto5.setConfirmFlg("0");

        /**
         * 帳票最終ダウンロード日時
         */
        announcementDto5.setReportLastDlTs("2022-05-23");

        /**
         * カナ氏名
         */
        announcementDto5.setCustomerName("ﾀｶﾅ");

        /**
         * 漢字氏名
         */
        announcementDto5.setCustomerKanjiName("高梨沙羅");

        /**
         * 生（設立）年月日
         */
        announcementDto5.setBirthday("2022-05-23");

        /**
         * 人格区分
         */
        announcementDto5.setPersonCode("01");
        
        
        // お知らせ一覧レスポンスDTO
        AnnouncementDto announcementDto6 = new AnnouncementDto();

        /**
         * お知らせ種別コード
         */
        announcementDto6.setAnncmntType("03");

        /**
         * 文書種別コード
         */
        announcementDto6.setDocumentType("06010");

        /**
         * お知らせID
         */
        announcementDto6.setAnncmntId("1234");

        /**
         * 申込ID
         */
        announcementDto6.setApplyId("0001");

        /**
         * 顧客ID
         */
        announcementDto6.setCustomerId("100001");

        /**
         * CIF番号
         */
        announcementDto6.setCifNoList(Arrays.asList(cifNo));

        /**
         * 受付案内種類
         */
        announcementDto6.setReceptionGuideType("01");

        /**
         * 掲載開始日時
         */
        announcementDto6.setAnncmntStartDateAndTime("2022-05-01");

        /**
         * 掲載終了日時
         */
        announcementDto6.setAnncmntEndDateAndTime("2022-05-03");

        /**
         * 作成
         */
        announcementDto6.setCreateTs("2022-05-01");

        /**
         * 公開日時
         */
        announcementDto6.setAnncmntDateAndTime("2022-05-23");

        /**
         * お知らせタイトル
         */
        announcementDto6.setAnncmntTitle("自動継続定期預金お利息計算書（大口定期）");

        /**
         * 店番
         */
        announcementDto6.setBranchCode("001");

        /**
         * 口座番号
         */
        announcementDto6.setAccountNumber("1234567");

        /**
         * 預金種目
         */
        announcementDto6.setAccountType("01");

        /**
         * お気に入りフラグ
         */
        announcementDto6.setBookmarkFlg("0");

        /**
         * 既読フラグ
         */
        announcementDto6.setReadFlag("0");

        /**
         * 個別確認結果フラグ
         */
        announcementDto6.setConfirmFlg("0");

        /**
         * 帳票最終ダウンロード日時
         */
        announcementDto6.setReportLastDlTs("2022-05-23");

        /**
         * カナ氏名
         */
        announcementDto6.setCustomerName("ﾀｶﾅ");

        /**
         * 漢字氏名
         */
        announcementDto6.setCustomerKanjiName("高梨沙羅");

        /**
         * 生（設立）年月日
         */
        announcementDto6.setBirthday("2022-05-23");

        /**
         * 人格区分
         */
        announcementDto6.setPersonCode("01");

        // お知らせ一覧レスポンスDTO
        AnnouncementDto announcementDto7 = new AnnouncementDto();

        /**
         * お知らせ種別コード
         */
        announcementDto7.setAnncmntType("03");

        /**
         * 文書種別コード
         */
        announcementDto7.setDocumentType("07010");

        /**
         * お知らせID
         */
        announcementDto7.setAnncmntId("1234");

        /**
         * 申込ID
         */
        announcementDto7.setApplyId("0001");

        /**
         * 顧客ID
         */
        announcementDto7.setCustomerId("100001");

        /**
         * CIF番号リスト
         */
        announcementDto7.setCifNoList(Arrays.asList(cifNo));

        /**
         * 受付案内種類
         */
        announcementDto7.setReceptionGuideType("01");

        /**
         * 掲載開始日時
         */
        announcementDto7.setAnncmntStartDateAndTime("2022-05-01");

        /**
         * 掲載終了日時
         */
        announcementDto7.setAnncmntEndDateAndTime("2022-05-03");

        /**
         * 作成日時
         */
        announcementDto7.setCreateTs("2022-05-01");

        /**
         * 公開日時
         */
        announcementDto7.setAnncmntDateAndTime("2022-05-23");

        /**
         * お知らせタイトル
         */
        announcementDto7.setAnncmntTitle("定期預金等期日のご案内（自由金利 通常分）");

        /**
         * 店番
         */
        announcementDto7.setBranchCode("001");

        /**
         * 口座番号
         */
        announcementDto7.setAccountNumber("1234567");

        /**
         * 預金種目
         */
        announcementDto7.setAccountType("01");

        /**
         * お気に入りフラグ
         */
        announcementDto7.setBookmarkFlg("0");

        /**
         * 既読フラグ
         */
        announcementDto7.setReadFlag("0");

        /**
         * 個別確認結果フラグ
         */
        announcementDto7.setConfirmFlg("0");

        /**
         * 帳票最終ダウンロード日時
         */
        announcementDto7.setReportLastDlTs("2022-05-23");

        /**
         * カナ氏名
         */
        announcementDto7.setCustomerName("ﾀｶﾅ");

        /**
         * 漢字氏名
         */
        announcementDto7.setCustomerKanjiName("高梨沙羅");

        /**
         * 生（設立）年月日
         */
        announcementDto7.setBirthday("2022-05-23");

        /**
         * 人格区分
         */
        announcementDto7.setPersonCode("01");

        // お知らせ一覧レスポンスDTO
        AnnouncementDto announcementDto8 = new AnnouncementDto();

        /**
         * お知らせ種別コード
         */
        announcementDto8.setAnncmntType("03");

        /**
         * 文書種別コード
         */
        announcementDto8.setDocumentType("08010");

        /**
         * お知らせID
         */
        announcementDto8.setAnncmntId("1234");

        /**
         * 申込ID
         */
        announcementDto8.setApplyId("0001");

        /**
         * 顧客ID
         */
        announcementDto8.setCustomerId("100001");

        /**
         * CIF番号リスト
         */
        announcementDto8.setCifNoList(Arrays.asList(cifNo));

        /**
         * 受付案内種類
         */
        announcementDto8.setReceptionGuideType("01");

        /**
         * 掲載開始日時
         */
        announcementDto8.setAnncmntStartDateAndTime("2022-05-01");

        /**
         * 掲載終了日時
         */
        announcementDto8.setAnncmntEndDateAndTime("2022-05-03");

        /**
         * 作成日時
         */
        announcementDto8.setCreateTs("2022-05-01");

        /**
         * 公開日時
         */
        announcementDto8.setAnncmntDateAndTime("2022-05-23");

        /**
         * お知らせタイトル
         */
        announcementDto8.setAnncmntTitle("お借入れが終了されたお客様へ");

        /**
         * 店番
         */
        announcementDto8.setBranchCode("001");

        /**
         * 口座番号
         */
        announcementDto8.setAccountNumber("1234567");

        /**
         * 預金種目
         */
        announcementDto8.setAccountType("01");

        /**
         * お気に入りフラグ
         */
        announcementDto8.setBookmarkFlg("0");

        /**
         * 既読フラグ
         */
        announcementDto8.setReadFlag("0");

        /**
         * 個別確認結果フラグ
         */
        announcementDto8.setConfirmFlg("0");

        /**
         * 帳票最終ダウンロード日時
         */
        announcementDto8.setReportLastDlTs("2022-05-23");

        /**
         * カナ氏名
         */
        announcementDto8.setCustomerName("ﾀｶﾅ");

        /**
         * 漢字氏名
         */
        announcementDto8.setCustomerKanjiName("高梨沙羅");

        /**
         * 生（設立）年月日
         */
        announcementDto8.setBirthday("2022-05-23");

        /**
         * 人格区分
         */
        announcementDto8.setPersonCode("01");

        // お知らせ一覧レスポンスDTO
        AnnouncementDto announcementDto9 = new AnnouncementDto();

        /**
         * お知らせ種別コード
         */
        announcementDto9.setAnncmntType("03");

        /**
         * 文書種別コード
         */
        announcementDto9.setDocumentType("09010");

        /**
         * お知らせID
         */
        announcementDto9.setAnncmntId("1234");

        /**
         * 申込ID
         */
        announcementDto9.setApplyId("0001");

        /**
         * 顧客ID
         */
        announcementDto9.setCustomerId("100001");

        /**
         * CIF番号リスト
         */
        announcementDto9.setCifNoList(Arrays.asList(cifNo));

        /**
         * 受付案内種類
         */
        announcementDto9.setReceptionGuideType("01");

        /**
         * 掲載開始日時
         */
        announcementDto9.setAnncmntStartDateAndTime("2022-05-01");

        /**
         * 掲載終了日時
         */
        announcementDto9.setAnncmntEndDateAndTime("2022-05-03");

        /**
         * 作成日時
         */
        announcementDto9.setCreateTs("2022-05-01");

        /**
         * 公開日時
         */
        announcementDto9.setAnncmntDateAndTime("2022-05-23");

        /**
         * お知らせタイトル
         */
        announcementDto9.setAnncmntTitle("城南総合口座決算のお知らせ（通常分）");

        /**
         * 店番
         */
        announcementDto9.setBranchCode("001");

        /**
         * 口座番号
         */
        announcementDto9.setAccountNumber("1234567");

        /**
         * 預金種目
         */
        announcementDto9.setAccountType("01");

        /**
         * お気に入りフラグ
         */
        announcementDto9.setBookmarkFlg("0");

        /**
         * 既読フラグ
         */
        announcementDto9.setReadFlag("0");

        /**
         * 個別確認結果フラグ
         */
        announcementDto9.setConfirmFlg("0");

        /**
         * 帳票最終ダウンロード日時
         */
        announcementDto9.setReportLastDlTs("2022-05-23");

        /**
         * カナ氏名
         */
        announcementDto9.setCustomerName("ﾀｶﾅ");

        /**
         * 漢字氏名
         */
        announcementDto9.setCustomerKanjiName("高梨沙羅");

        /**
         * 生（設立）年月日
         */
        announcementDto9.setBirthday("2022-05-23");

        /**
         * 人格区分
         */
        announcementDto9.setPersonCode("01");

        // お知らせ一覧レスポンスDTO
        AnnouncementDto announcementDto10 = new AnnouncementDto();

        /**
         * お知らせ種別コード
         */
        announcementDto10.setAnncmntType("03");

        /**
         * 文書種別コード
         */
        announcementDto10.setDocumentType("10100");

        /**
         * お知らせID
         */
        announcementDto10.setAnncmntId("1234");

        /**
         * 申込ID
         */
        announcementDto10.setApplyId("0001");

        /**
         * 顧客ID
         */
        announcementDto10.setCustomerId("100001");

        /**
         * CIF番号リスト
         */
        announcementDto10.setCifNoList(Arrays.asList(cifNo));

        /**
         * 受付案内種類
         */
        announcementDto10.setReceptionGuideType("01");

        /**
         * 掲載開始日時
         */
        announcementDto10.setAnncmntStartDateAndTime("2022-05-01");

        /**
         * 掲載終了日時
         */
        announcementDto10.setAnncmntEndDateAndTime("2022-05-03");

        /**
         * 作成日時
         */
        announcementDto10.setCreateTs("2022-05-01");

        /**
         * 公開日時
         */
        announcementDto10.setAnncmntDateAndTime("2022-05-23");

        /**
         * お知らせタイトル
         */
        announcementDto10.setAnncmntTitle("ご融資金の期日のご案内（預金担保）");

        /**
         * 店番
         */
        announcementDto10.setBranchCode("001");

        /**
         * 口座番号
         */
        announcementDto10.setAccountNumber("1234567");

        /**
         * 預金種目
         */
        announcementDto10.setAccountType("01");

        /**
         * お気に入りフラグ
         */
        announcementDto10.setBookmarkFlg("0");

        /**
         * 既読フラグ
         */
        announcementDto10.setReadFlag("0");

        /**
         * 個別確認結果フラグ
         */
        announcementDto10.setConfirmFlg("0");

        /**
         * 帳票最終ダウンロード日時
         */
        announcementDto10.setReportLastDlTs("2022-05-23");

        /**
         * カナ氏名
         */
        announcementDto10.setCustomerName("ﾀｶﾅ");

        /**
         * 漢字氏名
         */
        announcementDto10.setCustomerKanjiName("高梨沙羅");

        /**
         * 生（設立）年月日
         */
        announcementDto10.setBirthday("2022-05-23");

        /**
         * 人格区分
         */
        announcementDto10.setPersonCode("01");
        
        // お知らせ一覧レスポンスDTO
        AnnouncementDto announcementDto11 = new AnnouncementDto();

        /**
         * お知らせ種別コード
         */
        announcementDto11.setAnncmntType("03");

        /**
         * 文書種別コード
         */
        announcementDto11.setDocumentType("11010");

        /**
         * お知らせID
         */
        announcementDto11.setAnncmntId("1234");

        /**
         * 申込ID
         */
        announcementDto11.setApplyId("0001");

        /**
         * 顧客ID
         */
        announcementDto11.setCustomerId("100001");

        /**
         * CIF番号リスト
         */
        announcementDto11.setCifNoList(Arrays.asList(cifNo));

        /**
         * 受付案内種類
         */
        announcementDto11.setReceptionGuideType("01");

        /**
         * 掲載開始日時
         */
        announcementDto11.setAnncmntStartDateAndTime("2022-05-01");

        /**
         * 掲載終了日時
         */
        announcementDto11.setAnncmntEndDateAndTime("2022-05-03");

        /**
         * 作成日時
         */
        announcementDto11.setCreateTs("2022-05-01");

        /**
         * 公開日時
         */
        announcementDto11.setAnncmntDateAndTime("2022-05-23");

        /**
         * お知らせタイトル
         */
        announcementDto11.setAnncmntTitle("城南自動送金サービス取扱期間終了のご案内（固定型）");

        /**
         * 店番
         */
        announcementDto11.setBranchCode("001");

        /**
         * 口座番号
         */
        announcementDto11.setAccountNumber("1234567");

        /**
         * 預金種目
         */
        announcementDto11.setAccountType("01");

        /**
         * お気に入りフラグ
         */
        announcementDto11.setBookmarkFlg("0");

        /**
         * 既読フラグ
         */
        announcementDto11.setReadFlag("0");

        /**
         * 個別確認結果フラグ
         */
        announcementDto11.setConfirmFlg("0");

        /**
         * 帳票最終ダウンロード日時
         */
        announcementDto11.setReportLastDlTs("2022-05-23");

        /**
         * カナ氏名
         */
        announcementDto11.setCustomerName("ﾀｶﾅ");

        /**
         * 漢字氏名
         */
        announcementDto11.setCustomerKanjiName("高梨沙羅");

        /**
         * 生（設立）年月日
         */
        announcementDto11.setBirthday("2022-05-23");

        /**
         * 人格区分
         */
        announcementDto11.setPersonCode("01");

        // お知らせ一覧レスポンスDTO
        AnnouncementDto announcementDto12 = new AnnouncementDto();

        /**
         * お知らせ種別コード
         */
        announcementDto12.setAnncmntType("03");

        /**
         * 文書種別コード
         */
        announcementDto12.setDocumentType("12010");

        /**
         * お知らせID
         */
        announcementDto12.setAnncmntId("1234");

        /**
         * 申込ID
         */
        announcementDto12.setApplyId("0001");

        /**
         * 顧客ID
         */
        announcementDto12.setCustomerId("100001");

        /**
         * CIF番号リスト
         */
        announcementDto12.setCifNoList(Arrays.asList(cifNo));

        /**
         * 受付案内種類
         */
        announcementDto12.setReceptionGuideType("01");

        /**
         * 掲載開始日時
         */
        announcementDto12.setAnncmntStartDateAndTime("2022-05-01");

        /**
         * 掲載終了日時
         */
        announcementDto12.setAnncmntEndDateAndTime("2022-05-03");

        /**
         * 作成日時
         */
        announcementDto12.setCreateTs("2022-05-01");

        /**
         * 公開日時
         */
        announcementDto12.setAnncmntDateAndTime("2022-05-23");

        /**
         * お知らせタイトル
         */
        announcementDto12.setAnncmntTitle("財形年金預金年金額お受取りのご案内");

        /**
         * 店番
         */
        announcementDto12.setBranchCode("001");

        /**
         * 口座番号
         */
        announcementDto12.setAccountNumber("1234567");

        /**
         * 預金種目
         */
        announcementDto12.setAccountType("01");

        /**
         * お気に入りフラグ
         */
        announcementDto12.setBookmarkFlg("0");

        /**
         * 既読フラグ
         */
        announcementDto12.setReadFlag("0");

        /**
         * 個別確認結果フラグ
         */
        announcementDto12.setConfirmFlg("0");

        /**
         * 帳票最終ダウンロード日時
         */
        announcementDto12.setReportLastDlTs("2022-05-23");

        /**
         * カナ氏名
         */
        announcementDto12.setCustomerName("ﾀｶﾅ");

        /**
         * 漢字氏名
         */
        announcementDto12.setCustomerKanjiName("高梨沙羅");

        /**
         * 生（設立）年月日
         */
        announcementDto12.setBirthday("2022-05-23");

        /**
         * 人格区分
         */
        announcementDto12.setPersonCode("01");

        // お知らせ一覧レスポンスDTO
        AnnouncementDto announcementDto13 = new AnnouncementDto();

        /**
         * お知らせ種別コード
         */
        announcementDto13.setAnncmntType("03");

        /**
         * 文書種別コード
         */
        announcementDto13.setDocumentType("15010");

        /**
         * お知らせID
         */
        announcementDto13.setAnncmntId("1234");

        /**
         * 申込ID
         */
        announcementDto13.setApplyId("0001");

        /**
         * 顧客ID
         */
        announcementDto13.setCustomerId("100001");

        /**
         * CIF番号リスト
         */
        announcementDto13.setCifNoList(Arrays.asList(cifNo));

        /**
         * 受付案内種類
         */
        announcementDto13.setReceptionGuideType("01");

        /**
         * 掲載開始日時
         */
        announcementDto13.setAnncmntStartDateAndTime("2022-05-01");

        /**
         * 掲載終了日時
         */
        announcementDto13.setAnncmntEndDateAndTime("2022-05-03");

        /**
         * 作成日時
         */
        announcementDto13.setCreateTs("2022-05-01");

        /**
         * 公開日時
         */
        announcementDto13.setAnncmntDateAndTime("2022-05-23");

        /**
         * お知らせタイトル
         */
        announcementDto13.setAnncmntTitle("当座勘定照合表");

        /**
         * 店番
         */
        announcementDto13.setBranchCode("001");

        /**
         * 口座番号
         */
        announcementDto13.setAccountNumber("1234567");

        /**
         * 預金種目
         */
        announcementDto13.setAccountType("01");

        /**
         * お気に入りフラグ
         */
        announcementDto13.setBookmarkFlg("0");

        /**
         * 既読フラグ
         */
        announcementDto13.setReadFlag("0");

        /**
         * 個別確認結果フラグ
         */
        announcementDto13.setConfirmFlg("0");

        /**
         * 帳票最終ダウンロード日時
         */
        announcementDto13.setReportLastDlTs("2022-05-23");

        /**
         * カナ氏名
         */
        announcementDto13.setCustomerName("ﾀｶﾅ");

        /**
         * 漢字氏名
         */
        announcementDto13.setCustomerKanjiName("高梨沙羅");

        /**
         * 生（設立）年月日
         */
        announcementDto13.setBirthday("2022-05-23");

        /**
         * 人格区分
         */
        announcementDto13.setPersonCode("01");

        // お知らせ一覧レスポンスDTO
        AnnouncementDto announcementDto14 = new AnnouncementDto();

        /**
         * お知らせ種別コード
         */
        announcementDto14.setAnncmntType("03");

        /**
         * 文書種別コード
         */
        announcementDto14.setDocumentType("16010");

        /**
         * お知らせID
         */
        announcementDto14.setAnncmntId("1234");

        /**
         * 申込ID
         */
        announcementDto14.setApplyId("0001");

        /**
         * 顧客ID
         */
        announcementDto14.setCustomerId("100001");

        /**
         * CIF番号リスト
         */
        announcementDto14.setCifNoList(Arrays.asList(cifNo));

        /**
         * 受付案内種類
         */
        announcementDto14.setReceptionGuideType("01");

        /**
         * 掲載開始日時
         */
        announcementDto14.setAnncmntStartDateAndTime("2022-05-01");

        /**
         * 掲載終了日時
         */
        announcementDto14.setAnncmntEndDateAndTime("2022-05-03");

        /**
         * 作成日時
         */
        announcementDto14.setCreateTs("2022-05-01");

        /**
         * 公開日時
         */
        announcementDto14.setAnncmntDateAndTime("2022-05-23");

        /**
         * お知らせタイトル
         */
        announcementDto14.setAnncmntTitle("当座勘定照合表兼当座勘定決算のお知らせ");

        /**
         * 店番
         */
        announcementDto14.setBranchCode("001");

        /**
         * 口座番号
         */
        announcementDto14.setAccountNumber("1234567");

        /**
         * 預金種目
         */
        announcementDto14.setAccountType("01");

        /**
         * お気に入りフラグ
         */
        announcementDto14.setBookmarkFlg("0");

        /**
         * 既読フラグ
         */
        announcementDto14.setReadFlag("0");

        /**
         * 個別確認結果フラグ
         */
        announcementDto14.setConfirmFlg("0");

        /**
         * 帳票最終ダウンロード日時
         */
        announcementDto14.setReportLastDlTs("2022-05-23");

        /**
         * カナ氏名
         */
        announcementDto14.setCustomerName("ﾀｶﾅ");

        /**
         * 漢字氏名
         */
        announcementDto14.setCustomerKanjiName("高梨沙羅");

        /**
         * 生（設立）年月日
         */
        announcementDto14.setBirthday("2022-05-23");

        /**
         * 人格区分
         */
        announcementDto14.setPersonCode("01");

        // お知らせ一覧レスポンスDTO
        AnnouncementDto announcementDto15 = new AnnouncementDto();

        /**
         * お知らせ種別コード
         */
        announcementDto15.setAnncmntType("03");

        /**
         * 文書種別コード
         */
        announcementDto15.setDocumentType("17010");

        /**
         * お知らせID
         */
        announcementDto15.setAnncmntId("1234");

        /**
         * 申込ID
         */
        announcementDto15.setApplyId("0001");

        /**
         * 顧客ID
         */
        announcementDto15.setCustomerId("100001");

        /**
         * CIF番号リスト
         */
        announcementDto15.setCifNoList(Arrays.asList(cifNo));

        /**
         * 受付案内種類
         */
        announcementDto15.setReceptionGuideType("01");

        /**
         * 掲載開始日時
         */
        announcementDto15.setAnncmntStartDateAndTime("2022-05-01");

        /**
         * 掲載終了日時
         */
        announcementDto15.setAnncmntEndDateAndTime("2022-05-03");

        /**
         * 作成日時
         */
        announcementDto15.setCreateTs("2022-05-01");

        /**
         * 公開日時
         */
        announcementDto15.setAnncmntDateAndTime("2022-05-23");

        /**
         * お知らせタイトル
         */
        announcementDto15.setAnncmntTitle("貸金庫使用料期日のご案内");

        /**
         * 店番
         */
        announcementDto15.setBranchCode("001");

        /**
         * 口座番号
         */
        announcementDto15.setAccountNumber("1234567");

        /**
         * 預金種目
         */
        announcementDto15.setAccountType("01");

        /**
         * お気に入りフラグ
         */
        announcementDto15.setBookmarkFlg("0");

        /**
         * 既読フラグ
         */
        announcementDto15.setReadFlag("0");

        /**
         * 個別確認結果フラグ
         */
        announcementDto15.setConfirmFlg("0");

        /**
         * 帳票最終ダウンロード日時
         */
        announcementDto15.setReportLastDlTs("2022-05-23");

        /**
         * カナ氏名
         */
        announcementDto15.setCustomerName("ﾀｶﾅ");

        /**
         * 漢字氏名
         */
        announcementDto15.setCustomerKanjiName("高梨沙羅");

        /**
         * 生（設立）年月日
         */
        announcementDto15.setBirthday("2022-05-23");

        /**
         * 人格区分
         */
        announcementDto15.setPersonCode("01");
        
        
        // お知らせ一覧レスポンスDTO
        AnnouncementDto announcementDto16 = new AnnouncementDto();

        /**
         * お知らせ種別コード
         */
        announcementDto16.setAnncmntType("03");

        /**
         * 文書種別コード
         */
        announcementDto16.setDocumentType("18010");

        /**
         * お知らせID
         */
        announcementDto16.setAnncmntId("1234");

        /**
         * 申込ID
         */
        announcementDto16.setApplyId("0001");

        /**
         * 顧客ID
         */
        announcementDto16.setCustomerId("100001");

        /**
         * CIF番号リスト
         */
        announcementDto16.setCifNoList(Arrays.asList(cifNo));

        /**
         * 受付案内種類
         */
        announcementDto16.setReceptionGuideType("01");

        /**
         * 掲載開始日時
         */
        announcementDto16.setAnncmntStartDateAndTime("2022-05-01");

        /**
         * 掲載終了日時
         */
        announcementDto16.setAnncmntEndDateAndTime("2022-05-03");

        /**
         * 作成日時
         */
        announcementDto16.setCreateTs("2022-05-01");

        /**
         * 公開日時
         */
        announcementDto16.setAnncmntDateAndTime("2022-05-23");

        /**
         * お知らせタイトル
         */
        announcementDto16.setAnncmntTitle("割引手形計算明細表（一般）");

        /**
         * 店番
         */
        announcementDto16.setBranchCode("001");

        /**
         * 口座番号
         */
        announcementDto16.setAccountNumber("1234567");

        /**
         * 預金種目
         */
        announcementDto16.setAccountType("01");

        /**
         * お気に入りフラグ
         */
        announcementDto16.setBookmarkFlg("0");

        /**
         * 既読フラグ
         */
        announcementDto16.setReadFlag("0");

        /**
         * 個別確認結果フラグ
         */
        announcementDto16.setConfirmFlg("0");

        /**
         * 帳票最終ダウンロード日時
         */
        announcementDto16.setReportLastDlTs("2022-05-23");

        /**
         * カナ氏名
         */
        announcementDto16.setCustomerName("ﾀｶﾅ");

        /**
         * 漢字氏名
         */
        announcementDto16.setCustomerKanjiName("高梨沙羅");

        /**
         * 生（設立）年月日
         */
        announcementDto16.setBirthday("2022-05-23");

        /**
         * 人格区分
         */
        announcementDto16.setPersonCode("01");

        // お知らせ一覧レスポンスDTO
        AnnouncementDto announcementDto17 = new AnnouncementDto();

        /**
         * お知らせ種別コード
         */
        announcementDto17.setAnncmntType("03");

        /**
         * 文書種別コード
         */
        announcementDto17.setDocumentType("21010");

        /**
         * お知らせID
         */
        announcementDto17.setAnncmntId("1234");

        /**
         * 申込ID
         */
        announcementDto17.setApplyId("0001");

        /**
         * 顧客ID
         */
        announcementDto17.setCustomerId("100001");

        /**
         * CIF番号リスト
         */
        announcementDto17.setCifNoList(Arrays.asList(cifNo));

        /**
         * 受付案内種類
         */
        announcementDto17.setReceptionGuideType("01");

        /**
         * 掲載開始日時
         */
        announcementDto17.setAnncmntStartDateAndTime("2022-05-01");

        /**
         * 掲載終了日時
         */
        announcementDto17.setAnncmntEndDateAndTime("2022-05-03");

        /**
         * 作成日時
         */
        announcementDto17.setCreateTs("2022-05-01");

        /**
         * 公開日時
         */
        announcementDto17.setAnncmntDateAndTime("2022-05-23");

        /**
         * お知らせタイトル
         */
        announcementDto17.setAnncmntTitle("財産形成預金残高通知書（顧客分）");

        /**
         * 店番
         */
        announcementDto17.setBranchCode("001");

        /**
         * 口座番号
         */
        announcementDto17.setAccountNumber("1234567");

        /**
         * 預金種目
         */
        announcementDto17.setAccountType("01");

        /**
         * お気に入りフラグ
         */
        announcementDto17.setBookmarkFlg("0");

        /**
         * 既読フラグ
         */
        announcementDto17.setReadFlag("0");

        /**
         * 個別確認結果フラグ
         */
        announcementDto17.setConfirmFlg("0");

        /**
         * 帳票最終ダウンロード日時
         */
        announcementDto17.setReportLastDlTs("2022-05-23");

        /**
         * カナ氏名
         */
        announcementDto17.setCustomerName("ﾀｶﾅ");

        /**
         * 漢字氏名
         */
        announcementDto17.setCustomerKanjiName("高梨沙羅");

        /**
         * 生（設立）年月日
         */
        announcementDto17.setBirthday("2022-05-23");

        /**
         * 人格区分
         */
        announcementDto17.setPersonCode("01");
        
        
        
        // お知らせ一覧レスポンスDTO
        AnnouncementDto announcementDto18 = new AnnouncementDto();

        /**
         * お知らせ種別コード
         */
        announcementDto18.setAnncmntType("01");

        /**
         * 文書種別コード
         */
        announcementDto18.setDocumentType("21010");

        /**
         * お知らせID
         */
        announcementDto18.setAnncmntId("1234");

        /**
         * 申込ID
         */
        announcementDto18.setApplyId("0001");

        /**
         * 顧客ID
         */
        announcementDto18.setCustomerId("100001");

        /**
         * CIF番号リスト
         */
        announcementDto18.setCifNoList(Arrays.asList(cifNo));

        /**
         * 受付案内種類
         */
        announcementDto18.setReceptionGuideType("01");

        /**
         * 掲載開始日時
         */
        announcementDto18.setAnncmntStartDateAndTime("2022-05-01");

        /**
         * 掲載終了日時
         */
        announcementDto18.setAnncmntEndDateAndTime("2022-05-03");

        /**
         * 作成日時
         */
        announcementDto18.setCreateTs("2022-05-01");

        /**
         * 公開日時
         */
        announcementDto18.setAnncmntDateAndTime("2022-05-23");

        /**
         * お知らせタイトル
         */
        announcementDto18.setAnncmntTitle("メッセージ");

        /**
         * 店番
         */
        announcementDto18.setBranchCode("001");

        /**
         * 口座番号
         */
        announcementDto18.setAccountNumber("1234567");

        /**
         * 預金種目
         */
        announcementDto18.setAccountType("01");

        /**
         * お気に入りフラグ
         */
        announcementDto18.setBookmarkFlg("0");

        /**
         * 既読フラグ
         */
        announcementDto18.setReadFlag("0");

        /**
         * 個別確認結果フラグ
         */
        announcementDto18.setConfirmFlg("0");

        /**
         * 帳票最終ダウンロード日時
         */
        announcementDto18.setReportLastDlTs("2022-05-23");

        /**
         * カナ氏名
         */
        announcementDto18.setCustomerName("ﾀｶﾅ");

        /**
         * 漢字氏名
         */
        announcementDto18.setCustomerKanjiName("高梨沙羅");

        /**
         * 生（設立）年月日
         */
        announcementDto18.setBirthday("2022-05-23");

        /**
         * 人格区分
         */
        announcementDto18.setPersonCode("01");
        
        
        // お知らせ一覧レスポンスDTO
        AnnouncementDto announcementDto19 = new AnnouncementDto();

        /**
         * お知らせ種別コード
         */
        announcementDto19.setAnncmntType("02");

        /**
         * 文書種別コード
         */
        announcementDto19.setDocumentType("B2001");

        /**
         * お知らせID
         */
        announcementDto19.setAnncmntId("1234");

        /**
         * 申込ID
         */
        announcementDto19.setApplyId("0001");

        /**
         * 顧客ID
         */
        announcementDto19.setCustomerId("100001");

        /**
         * CIF番号リスト
         */
        announcementDto19.setCifNoList(Arrays.asList(cifNo));

        /**
         * 受付案内種類
         */
        announcementDto19.setReceptionGuideType("01");

        /**
         * 掲載開始日時
         */
        announcementDto19.setAnncmntStartDateAndTime("2022-05-01");

        /**
         * 掲載終了日時
         */
        announcementDto19.setAnncmntEndDateAndTime("2022-05-03");

        /**
         * 作成日時
         */
        announcementDto19.setCreateTs("2022-05-01");

        /**
         * 公開日時
         */
        announcementDto19.setAnncmntDateAndTime("2022-05-23");

        /**
         * お知らせタイトル
         */
        announcementDto19.setAnncmntTitle("かんたん受付案内");

        /**
         * 店番
         */
        announcementDto19.setBranchCode("001");

        /**
         * 口座番号
         */
        announcementDto19.setAccountNumber("1234567");

        /**
         * 預金種目
         */
        announcementDto19.setAccountType("01");

        /**
         * お気に入りフラグ
         */
        announcementDto19.setBookmarkFlg("0");

        /**
         * 既読フラグ
         */
        announcementDto19.setReadFlag("0");

        /**
         * 個別確認結果フラグ
         */
        announcementDto19.setConfirmFlg("0");

        /**
         * 帳票最終ダウンロード日時
         */
        announcementDto19.setReportLastDlTs("2022-05-23");

        /**
         * カナ氏名
         */
        announcementDto19.setCustomerName("ﾀｶﾅ");

        /**
         * 漢字氏名
         */
        announcementDto19.setCustomerKanjiName("高梨沙羅");

        /**
         * 生（設立）年月日
         */
        announcementDto19.setBirthday("2022-05-23");

        /**
         * 人格区分
         */
        announcementDto19.setPersonCode("01");
        
        // お知らせ一覧レスポンスDTO
        AnnouncementDto announcementDto20 = new AnnouncementDto();

        /**
         * お知らせ種別コード
         */
        announcementDto20.setAnncmntType("02");

        /**
         * 文書種別コード
         */
        announcementDto20.setDocumentType("B2002");

        /**
         * お知らせID
         */
        announcementDto20.setAnncmntId("1234");

        /**
         * 申込ID
         */
        announcementDto20.setApplyId("0001");

        /**
         * 顧客ID
         */
        announcementDto20.setCustomerId("100001");

        /**
         * CIF番号リスト
         */
        announcementDto20.setCifNoList(Arrays.asList(cifNo));

        /**
         * 受付案内種類
         */
        announcementDto20.setReceptionGuideType("01");

        /**
         * 掲載開始日時
         */
        announcementDto20.setAnncmntStartDateAndTime("2022-05-01");

        /**
         * 掲載終了日時
         */
        announcementDto20.setAnncmntEndDateAndTime("2022-05-03");

        /**
         * 作成日時
         */
        announcementDto20.setCreateTs("2022-05-01");

        /**
         * 公開日時
         */
        announcementDto20.setAnncmntDateAndTime("2022-05-23");

        /**
         * お知らせタイトル
         */
        announcementDto20.setAnncmntTitle("かんたん受付申込");

        /**
         * 店番
         */
        announcementDto20.setBranchCode("001");

        /**
         * 口座番号
         */
        announcementDto20.setAccountNumber("1234567");

        /**
         * 預金種目
         */
        announcementDto20.setAccountType("01");

        /**
         * お気に入りフラグ
         */
        announcementDto20.setBookmarkFlg("0");

        /**
         * 既読フラグ
         */
        announcementDto20.setReadFlag("0");

        /**
         * 個別確認結果フラグ
         */
        announcementDto20.setConfirmFlg("0");

        /**
         * 帳票最終ダウンロード日時
         */
        announcementDto20.setReportLastDlTs("2022-05-23");

        /**
         * カナ氏名
         */
        announcementDto20.setCustomerName("ﾀｶﾅ");

        /**
         * 漢字氏名
         */
        announcementDto20.setCustomerKanjiName("高梨沙羅");

        /**
         * 生（設立）年月日
         */
        announcementDto20.setBirthday("2022-05-23");

        /**
         * 人格区分
         */
        announcementDto20.setPersonCode("01");
        
        List<AnnouncementDto> list = new ArrayList<>();
        list.add(announcementDto1);
        list.add(announcementDto2);
        list.add(announcementDto3);
        list.add(announcementDto4);
        list.add(announcementDto5);
        list.add(announcementDto6);
        list.add(announcementDto7);
        list.add(announcementDto8);
        list.add(announcementDto9);
        list.add(announcementDto10);
        list.add(announcementDto11);
        list.add(announcementDto12);
        list.add(announcementDto13);
        list.add(announcementDto14);
        list.add(announcementDto15);
        list.add(announcementDto16);
        list.add(announcementDto17);
        list.add(announcementDto18);       
        list.add(announcementDto19);
        list.add(announcementDto20);
        abaResponseDto.setAnncmntList(list);

        abaResponseDto.setDataCount("100");

        return abaResponseDto;
    }

    /**
     * お知らせ本文取得
     *
     * @param requestDto お知らせ本文取得リクエストDTO
     * @return JsonResult
     */
    @Override
    public MobileMessageInquiryAbaResponseDto mobileMessageInquiry(MobileMessageInquiryAbaRequestDto requestDto) {

        ParameterBuilder parameterDto = ParameterBuilder.build(requestDto);

        MobileMessageInquiryAbaResponseDto abaResponseDto = new MobileMessageInquiryAbaResponseDto();

        VersionDto versionDto = new VersionDto();
        /**
         * バージョン
         */
        versionDto.setAnncmntVer("10");

        /**
         * タイトル
         */
        versionDto.setAnncmntTitle("ああああ");

        /**
         * 作成日時
         */
        versionDto.setCreateDateAndTime("2022-05-01");

        /**
         * お知らせステータス
         */
        versionDto.setAnncmntStatus(MobilelMsgStatusCode.PERMISSION_TO_PUBLISH);

        /**
         * 掲載開始日時
         */
        versionDto.setAnncmntStartDateAndTime("2022-04-01");

        /**
         * 掲載終了日時
         */
        versionDto.setAnncmntEndDateAndTime("2022-05-01");

        /**
         * メッセージ内容種別
         */
        versionDto.setMobileMsgType("01");

        /**
         * メッセージ宛先種別
         */
        versionDto.setIndivisualFlg("01");

        /**
         * Push通知有無フラグ
         */
        versionDto.setPushNotifyFlg("1");

        /**
         * Push通知本文
         */
        versionDto.setPushNotifyMsg("LIUFOIUWBFHIQVOYCBIQ-6551953");

        /**
         * Push通知送信日時
         */
        versionDto.setPushNotifyDateAndTime("2022-05-01");

        /**
         * PUSH通知送信先OS
         */
        versionDto.setDestinationOs("LIUFOIUWBFHIQVOYCBIQ-6551952");

        /**
         * 同意チェックボックス有無
         */
        versionDto.setAcceptanceChkFlg("1");

        /**
         * モバイルメッセージ本文
         */
        versionDto.setMobileMsg("LIUFOIUWBFHIQVOYCBIQ-6551951");

        /**
         * 画像有無フラグ
         */
        versionDto.setImgFlg("1");

        /**
         * 画像位置
         */
        versionDto.setImgVPosition("1");

        /**
         * 画像バケット名PUB
         */
        versionDto.setImgBucketPub("333444555.jpeg");

        /**
         * 画像バケット名PVT
         */
        versionDto.setImgBucketPvt("333444555.jpeg");

        /**
         * 画像ファイル名
         */
        versionDto.setImgFilename("個人撮影（表面）1653835058530.jpeg");

        /**
         * 画像ファイルリンク先有無
         */
        versionDto.setImgFileLinkFlg("1");

        /**
         * 画像ファイルリンク先URL
         */
        versionDto.setImgFileLinkFlg("http://localhost:8181");

        /**
         * 送信先顧客IDリスト
         */
        List<String> destinationCustIdList = new ArrayList<String>();
        destinationCustIdList.add("01234456");

        /**
         * 送信先支店番号リスト
         */
        List<String> destinationBranchNumList = new ArrayList<String>();
        destinationBranchNumList.add("556566");
                
        /**
         * 承認依頼者支店番号
         */
        versionDto.setRequesterBranch("7451");

        /**
         * 承認依頼者部門コード
         */
        versionDto.setRequesterDept("1");

        /**
         * 差戻フラグ
         */
        versionDto.setPassbackFlg("1");

        /**
         * 更新タイムスタンプ(排他用)
         */
        versionDto.setUpdateTs("あああ");
        
        /**
         * ボタンリンク先有無フラグ
         */
        versionDto.setBtnLinkFlg("1");
        
        /**
         * ボタンリンク先URL
         */
        versionDto.setBtnLinkUrl("http://localhost:8181");

        abaResponseDto.setVersionList(Arrays.asList(versionDto));

        return abaResponseDto;
    }

    /**
     * お知らせ一覧更新
     *
     * @param requestDto お知らせ一覧更新ABAリクエストDTO
     * @return 処理結果
     */
    @Override
    public CommonHeaderAbaResponseDto updateAnnouncementList(UpdateAnnouncementListAbaRequestDto requestDto) {

        ParameterBuilder parameterDto = ParameterBuilder.build(requestDto);

        CommonHeaderAbaResponseDto responseDto = new CommonHeaderAbaResponseDto();
        return responseDto;
    }
}
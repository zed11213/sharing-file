package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * IVR送信リクエストDTO
 */
@Data
public class IvrSendingRequestDto {

    /**
     * 受付番号
     */
    private String receiptNumber;
    
    /**
     * 電話番号
     */
    private String phoneNumber;
}

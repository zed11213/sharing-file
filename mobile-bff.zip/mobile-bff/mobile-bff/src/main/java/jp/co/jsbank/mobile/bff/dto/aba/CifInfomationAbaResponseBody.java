package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * CIF情報取得レスポンスDTO
 */
@Data
public class CifInfomationAbaResponseBody {


    /**
     * 共通レスポンス・ボディ
     */
    private CommonResponseHeader commonResponseBody;
    
    /**
     * CIF情報DTOリスト
     */
    private List<CifInfomationDto> cifInfomationDtoList;

}

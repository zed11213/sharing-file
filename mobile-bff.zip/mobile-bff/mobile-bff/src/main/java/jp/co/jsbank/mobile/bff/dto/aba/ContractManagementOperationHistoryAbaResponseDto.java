package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 契約管理操作履歴ABAレスポンスDTO
 */
@Data
public class ContractManagementOperationHistoryAbaResponseDto {

    /**
     * 共通レスポンス・ボディ
     */
    private CommonResponseHeader commonResponseHeader;

    /**
     * 受付番号
     */
    private String receiptNumber;

    /**
     * 利用者ID
     */
    private String userId;

    /**
     * 画面ID
     */
    private String pageId;

    /**
     * 人格区分
     */
    private String personType;

}

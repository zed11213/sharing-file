package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 利用者情報ABAリクエストDTO
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class UserInformationAbaRequestDto extends RequestBodyDto {
    
    /**
     * 利用者ID
     */
    private String userId;

    /**
     * 利用者区分
     */
    private String userType;

    /**
     * ステータス
     */
    private String status;

    /**
     * 漢字氏名
     */
    private String customerKanjiName;

    /**
     * カナ氏名
     */
    private String customerName;

    /**
     * 所属
     */
    private String division;
    
    /**
     * 利用者追加削除区分
     */
    private String userAddDeleteType;
 }

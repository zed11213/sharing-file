package jp.co.jsbank.mobile.bff.controller;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import jp.co.jsbank.mobile.bff.common.JsonResult;
import jp.co.jsbank.mobile.bff.dto.ApplicationAnswerViewResponseDto;
import jp.co.jsbank.mobile.bff.dto.EasyRegistrationScreenAcquisitionResponseDto;
import jp.co.jsbank.mobile.bff.dto.EasyRegistrationScreenInputInfoSendingRequestDto;
import jp.co.jsbank.mobile.bff.dto.GuidanceInquiryInfTypeIdResponseDto;
import jp.co.jsbank.mobile.bff.dto.ReceptionInformationViewResponseDto;
import jp.co.jsbank.mobile.bff.dto.ReceptionNotificationViewResponseDto;
import jp.co.jsbank.mobile.bff.service.EasyReceptionService;

/**
 * かんたん受付コントロール
 */
@RestController
public class EasyReceptionController {

    @Resource
    private EasyReceptionService easyReceptionService;

    // private Logger logger = LoggerFactory.getLogger(EasyReceptionController.class);

    /**
     * かんたん受付申込一覧照会
     *
     * @return JsonResult
     */
    @GetMapping(path = "/easy-reception/AB0901")
    public JsonResult guidanceInquiryInformationTypeId() {

        // お知らせ種別IDで案内照会
        GuidanceInquiryInfTypeIdResponseDto responseDto = easyReceptionService.guidanceInquiryInformationTypeId();

        return JsonResult.success(responseDto);

    }

    /**
     * 受付案内閲覧
     *
     * @param anncmntId お知らせID
     * @return JsonResult
     */
    @GetMapping(path = "/easy-reception/AB0902")
    public JsonResult receptionInformationView(@RequestParam String anncmntId) {

        // 受付案内閲覧
        ReceptionInformationViewResponseDto receptionInformationViewResponseDto = easyReceptionService
                .receptionInformationView(anncmntId);

        return JsonResult.success(receptionInformationViewResponseDto);
    }

    /**
     * かんたん登録画面取得
     * 
     * @return JsonResult
     */
    @GetMapping(path = "/easy-reception/AB0903")
    public JsonResult easyRegistrationScreenAcquisition() {

        // かんたん登録画面取得
        EasyRegistrationScreenAcquisitionResponseDto responseDto = easyReceptionService
                .easyRegistrationScreenAcquisition();

        return JsonResult.success(responseDto);
    }

    /**
     * ログイン前受付案内閲覧
     *
     * @param anncmntId お知らせID
     * @return JsonResult
     */
    @GetMapping(path = "/easy-reception/AB0904")
    public JsonResult receptionInformationViewBeforeLogin(@RequestParam String anncmntId) {

        // 受付案内閲覧
        ReceptionInformationViewResponseDto receptionInformationViewResponseDto = easyReceptionService
                .receptionInformationView(anncmntId);

        return JsonResult.success(receptionInformationViewResponseDto);
    }

    /**
     * かんたん登録画面入力情報送信
     *
     * @param requestDto かんたん登録画面入力情報送信リクエストDTO
     * @return JsonResult
     */
    @PostMapping(path = "/easy-reception/AB0905")
    public JsonResult easyRegistrationScreenInputInfoSending(
            @RequestBody EasyRegistrationScreenInputInfoSendingRequestDto requestDto) {

        // 受付通知閲覧
        String result = easyReceptionService.easyRegistrationScreenInputInfoSending(requestDto);

        return JsonResult.success(result);
    }

    /**
     * ログイン前かんたん登録画面入力情報送信
     *
     * @param requestDto かんたん登録画面入力情報送信リクエストDTO
     * @return JsonResult
     */
    @PostMapping(path = "/easy-reception/AB0906")
    public JsonResult easyRegistrationScreenInputInfoSendingBeforeLogin(
            @RequestBody EasyRegistrationScreenInputInfoSendingRequestDto requestDto) {

        // 受付通知閲覧
        String result = easyReceptionService.easyRegistrationScreenInputInfoSending(requestDto);

        return JsonResult.success(result);
    }

    /**
     * 受付通知閲覧
     *
     * @param anncmntId お知らせID
     * @param applicationId 申込ID
     * @return JsonResult
     */
    @GetMapping(path = "/easy-reception/AB0907")
    public JsonResult receptionNotificationView(@RequestParam String anncmntId, @RequestParam String applicationId) {

        // 受付通知閲覧
        ReceptionNotificationViewResponseDto result = easyReceptionService.receptionNotificationView(anncmntId,
                applicationId);

        return JsonResult.success(result);
    }

    /**
     * 申込回答閲覧
     *
     * @param applicationId 申込ID
     * @param anncmntId お知らせID
     * @return JsonResult
     */
    @GetMapping(path = "/easy-reception/AB0908")
    public JsonResult applicationAnswerView(@RequestParam String applicationId, @RequestParam String anncmntId) {

        // 申込回答内容
        ApplicationAnswerViewResponseDto result = easyReceptionService.applicationAnswerView(applicationId, anncmntId);

        return JsonResult.success(result);
    }

}

package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * メールアドレス登録リクエストDTO
 */
@Data
public class EmailAddressRegistrationRequestDto {
    /**
     * 受付番号
     */
    private String receptionNumber;

    /**
     * メールアドレス
     */
    private String emailAddress;

    /**
     * 処理区分=新規
     */
    private String processKubun;

}

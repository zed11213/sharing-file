package jp.co.jsbank.mobile.bff.dto;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.aba.PaidOffDto;
import jp.co.jsbank.mobile.bff.dto.aba.PeriodicDepositDetailsDto;
import lombok.Data;

/**
 * 定期積金明細レスポンスDTO
 */
@Data
public class PeriodicDepositDetailsResponseDto {

    /**
     * 定期積金明細DTOリスト
     */
    private PeriodicDepositDetailsDto periodicDepositDetailsDto;
    
    /**
     * 領収印情報DTOリスト
     */
    private List<PaidOffDto> paidOffList;
}

package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import jp.co.jsbank.mobile.bff.dto.IdentityVerificationDocumentsDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 口座開設申込情報（個人）ABADTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class AccountOpeningApplicationIndividualInfoAbaResponseDto extends RequestBodyDto {
	
    /**
     * 共通レスポンス・ボディ
     */
    private CommonResponseHeader commonResponseHeader;

    /**
     * 受付番号
     */
    private String receiptNumber;

    /**
     * CIF番号
     */
    private String cifNumber;

    /**
     * 人格区分
     */
    private String personType;
    
    /**
     * 取引種別
     */
    private String transactionType;
    
    /**
     * 申込日
     */
    private String applicationDate;
    
    /**
     * 申請開始日時
     */
    private String applyStartDateTime;

    /**
     * 申請有効期限日時
     */
    private String applyValidDateTime;
    
    /**
     * カナ氏名（姓）
     */
    private String customerLastName;
    
    /**
     * カナ氏名（名）
     */
    private String customerFirstName;
    
    /**
     * 氏名漢字（姓）
     */
    private String customerKanjiLastName;

    /**
     * 氏名漢字（名）
     */
    private String customerKanjiFirstName;
    
    /**
     * 性別
     */
    private String gender;
    
    /**
     * 性別回答有無
     */
    private String genderAnswer;
    
    /**
     * 生年月日
     */
    private String birthday;
    
    /**
     * 郵便番号
     */
    private String zipCode;
    
    /**
     * 地区コード
     */
    private String addressCode;
    
    /**
     * 地区コード（枝番）
     */
    private String addressCodeBranchNumber;
    
    /**
     * 都道府県（カナ）
     */
    private String prefectureKana;
    
    /**
     * 都道府県
     */
    private String prefecture;
    
    /**
     * 市区町村（カナ）
     */
    private String cityKana;
    
    /**
     * 市区町村
     */
    private String city;
    
    /**
     * 丁目（カナ）
     */
    private String addrDetail2Kana;
    
    /**
     * 丁目
     */
    private String addrDetail2;
    
    /**
     * 番地（カナ）
     */
    private String addrDetail3Kana;
    
    /**
     * 番地
     */
    private String addrDetail3;

    /**
     * 申込ステータス
     */
    private String applyStatus;
    
    /**
     * 建物名・号室（カナ）
     */
    private String buildingRoomKana;
    
    /**
     * 建物名・号室
     */
    private String buildingRoom	;
    
    /**
     * 電話番号１種別
     */
    private String phoneType1;
    
    /**
     * 電話番号１（上）
     */
    private String phoneNumOneFirst;
    
    /**
     * 電話番号１（中）
     */
    private String phoneNumOneMid;
    
    /**
     * 電話番号１（下）
     */
    private String phoneNumOneLast;
    
    /**
     * 電話番号２種別
     */
    private String phoneType2;
    
    /**
     * 電話番号２（上）
     */
    private String phoneNumTwoFirst;
    
    /**
     * 電話番号２（中）
     */
    private String phoneNumTwoMid;
    
    /**
     * 電話番号２（下）
     */
    private String phoneNumTwoLast;
    
    /**
     * 職業
     */
    private String occupation;

    /**
     * 職業（その他）
     */
    private String occupationOther;
    
    /**
     * 取引目的
     */
    private String transactPurpose;

    /**
     * 取引目的（その他）
     */
    private String transactPurposeOther;
    
    /**
     * 取引のきっかけ
     */
    private String transactionTrigger;
    
    /**
     * 店番
     */
    private String branchNumber;
    
    /**
     * 預金種目
     */
    private String accountType;
    
    /**
     * 口座番号
     */
    private String accountNumber;
    
    /**
     * サブNo
     */
    private String accountSubNumber;
    
    /**
     * 勤務先名
     */
    private String wpName;
    
    /**
     * 勤務先郵便番号
     */
    private String wpZipCode;

    /**
     * 勤務先都道府県
     */
    private String wpPrefecture;

    /**
     * 勤務先市区町村
     */
    private String wpCity;

    /**
     * 勤務先丁目
     */
    private String wpStreet;

    /**
     * 勤務先番地
     */
    private String wpAddress;
    
    /**
     * 勤務先建物名・号室
     */
    private String wpBuilding;

    /**
     * 勤務先電話番号種別
     */
    private String wpPhoneType;

    /**
     * 勤務先電話番号（上）
     */
    private String wpPhoneFirst;

    /**
     * 勤務先電話番号（中）
     */
    private String wpPhoneMid;

    /**
     * 勤務先電話番号（下）
     */
    private String wpPhoneLast;
    
    /**
     * メールアドレス
     */
    private String emailAddress;
    
    /**
     * 開設店番
     */
    private String openBranchNumber;
    
    /**
     * eKYC確認結果
     */
    private String ekycResult;
    
    /**
     * 本人確認書類リスト
     */
    private List<IdentityVerificationDocumentsDto> identityDocuments;
}

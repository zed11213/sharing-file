package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * かんたん受付申込詳細照会ABAリクエストDTO
 */
@Data
public class EasyReceptionApplicationDetailsInquiryAbaRequestDto {

    /**
     * お知らせID
     */
    private String anncmntId;
    
    /**
     * 申込ID
     */
    private String applyId;
 
}

package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * お知らせ一覧更新リクエストDTO
 */
@Data
public class UpdateAnnouncementRequestDto {

    /**
     * お知らせ種別コード
     */
    private String anncmntType;

    /**
     * 文書種別コード
     */
    private String documentType;

    /**
     * お知らせID
     */
    private String anncmntId;

    /**
     * 申込ID
     */
    private String applyId;

    /**
     * 個別確認フラグ
     */
    private String confirmFlg;

    /**
     * 帳票ダウンロードフラグ
     */
    private String reportDlFlg;

    /**
     * 既読フラグ
     */
    private String readFlg;

    /**
     * お気に入りフラグ
     */
    private String bookmarkFlg;
    
    /**
     * 個別確認フラグ
     */
    private String individualConfirmationFlag;
}

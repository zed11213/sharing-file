package jp.co.jsbank.mobile.bff.common.exception;

/**
 * 業務共通例外クラス
 */
public class BusinessException extends RuntimeException {

	private static final long serialVersionUID = -1L;

	protected String code;

	protected Object[] args;

	/**
	 * BusinessExceptionのコンスタント。
	 * 
	 * @param throwable 例外引数
	 */
	public BusinessException(Throwable throwable) {
		super(throwable);
		this.code = null;
		this.args = null;
	}

	/**
	 * BusinessExceptionのコンスタント。
	 * 
	 * @param code エラーコード
	 * @param args エラー引数
	 */
	public BusinessException(String code, Object... args) {
		this.code = code;
		this.args = args;
	}

	/**
	 * BusinessExceptionのコンスタント。
	 * 
	 * @param throwable 例外引数
	 * @param code エラーコード
	 * @param args エラー引数
	 */
	public BusinessException(Throwable throwable, String code, Object... args) {
		super(throwable);
		this.code = code;
		this.args = args;
	}

	public String getCode() {
		return code;
	}

	public Object[] getArgs() {
        return args == null ? null : args.clone();
    }
}

package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 通知設定BFFリクエストDTO
 */
@Data
public class NotificationSettingRequestDto {

    /**
     * 設定種別
     */
    private String settingType;

    /**
     * 設定区分
     */
    private String settingDivision;

    /**
     * 設定値
     */
    private String settingContent;
}

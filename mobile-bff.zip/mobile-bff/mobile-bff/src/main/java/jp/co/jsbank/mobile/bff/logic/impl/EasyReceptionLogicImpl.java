package jp.co.jsbank.mobile.bff.logic.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.jsbank.mobile.bff.common.code.ReceptionGuideStatusCode;
import jp.co.jsbank.mobile.bff.config.RestClientConfig;
import jp.co.jsbank.mobile.bff.dto.BranchStoreAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.BranchStoreDto;
import jp.co.jsbank.mobile.bff.dto.EasyReceptionApplicationDetailsInquiryAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.EasyReceptionGuideDetailedInquiryAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.ReceptionAnswerDataDto;
import jp.co.jsbank.mobile.bff.dto.ReceptionGuideDto;
import jp.co.jsbank.mobile.bff.dto.aba.BranchOfficeListInquiryAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CifNumberDto;
import jp.co.jsbank.mobile.bff.dto.aba.EasyReceptionAnswerDetailInquiryAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.EasyReceptionAnswerDetailInquiryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.EasyReceptionApplicationDetailsInquiryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.EasyReceptionApplicationRegistrationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.EasyReceptionApplicationRegistrationResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.GuidanceInquiryInfTypeIdAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.ReceptionInformationListInquiry;
import jp.co.jsbank.mobile.bff.dto.aba.ReceptionInformationListInquiryResponseDto;
import jp.co.jsbank.mobile.bff.logic.EasyReceptionLogic;

/**
 * ログインロジック実装クラス
 */
@Service
public class EasyReceptionLogicImpl implements EasyReceptionLogic {

    @Autowired
    RestClientConfig restClientConfig;

    /**
     * かんたん受付案内詳細照会
     *
     * @param requestDto かんたん受付案内詳細照会ABAリクエストDTO
     * @return かんたん受付案内詳細照会ABAリクエストDTO
     */
    @Override
    public GuidanceInquiryInfTypeIdAbaResponseDto
            easyReceptionGuideDetailedInquiry(EasyReceptionGuideDetailedInquiryAbaRequestDto requestDto) {
        // リクエストパラメータ
        // ParameterBuilder parameterDto = ParameterBuilder.build(requestDto);

        GuidanceInquiryInfTypeIdAbaResponseDto guidanceInquiryInfTypeIdAbaResponseDto = new GuidanceInquiryInfTypeIdAbaResponseDto();

        guidanceInquiryInfTypeIdAbaResponseDto.setAcceptanceChkFlg("1");
        guidanceInquiryInfTypeIdAbaResponseDto.setAnncmntEndTime("2022-05-22");
        guidanceInquiryInfTypeIdAbaResponseDto.setAnncmntId("458814555485");
        guidanceInquiryInfTypeIdAbaResponseDto.setAnncmntStartTime("2022-05-01");
        guidanceInquiryInfTypeIdAbaResponseDto.setAnncmntTitle("hdyyegxw");
        guidanceInquiryInfTypeIdAbaResponseDto.setApplyAdminBranchNum("123");
        guidanceInquiryInfTypeIdAbaResponseDto.setApplyAdminType("1");
        guidanceInquiryInfTypeIdAbaResponseDto.setApplyConfirmMsg("申込確認メッセージ");
        guidanceInquiryInfTypeIdAbaResponseDto.setBtnLinkFlg("1");
        guidanceInquiryInfTypeIdAbaResponseDto.setBtnLinkUrl("http://localhost:8181");
        guidanceInquiryInfTypeIdAbaResponseDto.setCreateDateAndTime("2022-05-01");
        guidanceInquiryInfTypeIdAbaResponseDto.setImgBucketPub("画像バケット名PUB");
        guidanceInquiryInfTypeIdAbaResponseDto.setImgBucketPvt("333444555.jpeg");
        guidanceInquiryInfTypeIdAbaResponseDto.setReceptionGuideStatus("EA01");
        ////////////////
        guidanceInquiryInfTypeIdAbaResponseDto.setImgFilename("個人撮影（表面）1653835058530.jpeg");
        ////////
        guidanceInquiryInfTypeIdAbaResponseDto.setImgFlg("1");
        guidanceInquiryInfTypeIdAbaResponseDto.setImgVPosition("1");
        guidanceInquiryInfTypeIdAbaResponseDto.setJudgementResult("1");
        guidanceInquiryInfTypeIdAbaResponseDto.setMobileMsgType("1");
        guidanceInquiryInfTypeIdAbaResponseDto.setApplyConfirmMsg("申込確認メッセージ");
        List<String> destinationBranchNumList = new ArrayList<String>();
        destinationBranchNumList.add("123");
        guidanceInquiryInfTypeIdAbaResponseDto.setDestinationBranchNumList(destinationBranchNumList);
        String format = "{\"input_form\": [{\"form_type\":\"text_field\",\"form_name\":\"テスト1\","
                + "\"input_length\":\"100\",\"user_enterd_text\":\"\"},{\"form_type\":\"list_box\","
                + "\"form_name\":\"テスト2\",\"items\": [{\"item_id\":\"1\",\"item_name\":\"テスト1\"},"
                + "{\"item_id\":\"2\",\"item_name\":\"テスト2\"},{\"item_id\":\"3\",\"item_name\":\"テスト3\"}],"
                + "\"user_selected_item\":\"\"},{\"form_type\":\"radio_button\",\"form_name\":\"テスト3\","
                + "\"items\": [{\"item_id\":\"1\",\"item_name\":\"テスト1\"},{\"item_id\":\"2\",\"item_name\":"
                + "\"テスト2\"},{\"item_id\":\"3\",\"item_name\":\"テスト3\"}],\"user_selected_item\":\"\"},"
                + "{\"form_type\":\"check_box\",\"form_name\":\"テスト3\",\"items\": [{\"item_id\":\"1\",\"item_name\":\"テスト1\"},"
                + "{\"item_id\":\"2\",\"item_name\":\"テスト2\"},{\"item_id\":\"3\",\"item_name\":\"テスト3\"}],\"user_selected_items\": []}]}";
        guidanceInquiryInfTypeIdAbaResponseDto.setReceptionFormat(format);
        guidanceInquiryInfTypeIdAbaResponseDto.setUpdateTs("更新タイムスタンプ(排他用)");
        guidanceInquiryInfTypeIdAbaResponseDto.setReceptionGuideMsg("5615665161516");
        guidanceInquiryInfTypeIdAbaResponseDto.setVenueBranchNum("123");
        guidanceInquiryInfTypeIdAbaResponseDto.setReceptionGuideType("1");
        guidanceInquiryInfTypeIdAbaResponseDto.setVenueSelectFlg("111");
        guidanceInquiryInfTypeIdAbaResponseDto.setPushNotifySet("1235");
        return guidanceInquiryInfTypeIdAbaResponseDto;
    }

    /**
     * かんたん受付申込登録
     *
     * @param requestDto かんたん受付申込登録ABAリクエストDTO
     * @return かんたん受付申込登録レスボスDTO
     */
    @Override
    public EasyReceptionApplicationRegistrationResponseDto
            easyReceptionApplicationRegistration(EasyReceptionApplicationRegistrationAbaRequestDto requestDto) {
        EasyReceptionApplicationRegistrationResponseDto responseDto = new EasyReceptionApplicationRegistrationResponseDto();
        responseDto.setApplyId("123456");
        return responseDto;
    }

    /**
     * 部店一覧照会
     *
     * @param branchOfficeListInquiryAbaRequestDto 支店一覧照会リクエストDTO
     * 
     * @return 支店一覧ABAレスポンスDTO
     */
    @Override
    public BranchStoreAbaResponseDto
            branchOfficeListInquiry(BranchOfficeListInquiryAbaRequestDto branchOfficeListInquiryAbaRequestDto) {
        BranchStoreAbaResponseDto responseDto = new BranchStoreAbaResponseDto();
        responseDto.setBranchInquiryCount("1");

        List<BranchStoreDto> branchStoreDtoList = new ArrayList<BranchStoreDto>();
        BranchStoreDto branchStoreDto = new BranchStoreDto();
        /**
         * 金融機関コード
         */
        branchStoreDto.setBankCode("1344");

        /**
         * 店番
         */
        branchStoreDto.setBranchNumber("123");

        /**
         * 店名（漢字）
         */
        branchStoreDto.setBranchKanjiName("蒲田区");

        /**
         * 所属部門区分
         */
        branchStoreDto.setDivisionType("1");

        /**
         * 照会店舗タイプ
         */
        branchStoreDto.setBranchInquiryType("1");

        /**
         * 郵便番号
         */
        branchStoreDto.setZipCode("123-456");

        /**
         * 住所
         */
        branchStoreDto.setBranchKanjiAddress("東京都");

        /**
         * 電話番号
         */
        branchStoreDto.setPhoneNumber("13845641234");

        /**
         * 店舗案内
         */
        branchStoreDto.setBranchGuide("店舗案内");

        /**
         * 緯度
         */
        branchStoreDto.setLatitude("30.5");

        /**
         * 経度
         */
        branchStoreDto.setLongitude("40.6");

        /**
         * 表示グループ名
         */
        branchStoreDto.setDisplayGroupName("表示グループ名");

        /**
         * 表示順
         */
        branchStoreDto.setDisplayOrder("1");

        branchStoreDtoList.add(branchStoreDto);
        responseDto.setBranchList(branchStoreDtoList);
        return responseDto;
    }

    /**
     * かんたん受付回答詳細照会
     *
     * @param easyReceptionAnswerDetailInquiryAbaRequestDto かんたん受付回答詳細照会ABAリクエストDTO
     * @return かんたん受付回答詳細照会ABAレスボスDTO
     */
    @Override
    public EasyReceptionAnswerDetailInquiryAbaResponseDto easyReceptionAnswerDetailInquiry(
            EasyReceptionAnswerDetailInquiryAbaRequestDto easyReceptionAnswerDetailInquiryAbaRequestDto) {
        EasyReceptionAnswerDetailInquiryAbaResponseDto responseDto = new EasyReceptionAnswerDetailInquiryAbaResponseDto();
        responseDto.setAnncmntId("8484444151454");
        List<ReceptionAnswerDataDto> responseList = new ArrayList<ReceptionAnswerDataDto>();
        ReceptionAnswerDataDto receptionAnswerDataDto = new ReceptionAnswerDataDto();
        /**
         * 回答ID
         */
        receptionAnswerDataDto.setResponseId("12548955");
        receptionAnswerDataDto.setPublicFlg("1");
        /**
         * 作成日時
         */
        receptionAnswerDataDto.setCreateDateAndTime("2022-05-01");

        /**
         * 回答本文
         */
        receptionAnswerDataDto.setResponseMsg("あああああああ");

        /**
         * 回答画像有無フラグ
         */
        receptionAnswerDataDto.setResImgFlg("1");

        /**
         * 回答画像位置
         */
        receptionAnswerDataDto.setResImgVPosition("1");

        /**
         * 回答画像バケット名PUB
         */
        receptionAnswerDataDto.setResImgBucketPub("333444555.jpeg");

        /**
         * 回答画像バケット名PVT
         */
        receptionAnswerDataDto.setResImgBucketPvt("333444555.jpeg");

        /**
         * 回答画像ファイル名
         */
        receptionAnswerDataDto.setResImgFilename("個人撮影（表面）1653835058530.jpeg");

        /**
         * ボタン種類
         */
        receptionAnswerDataDto.setBtnType("1");

        /**
         * ボタンリンク先有無フラグ
         */
        receptionAnswerDataDto.setBtnLinkFlg("1");

        /**
         * ボタンリンク先URL
         */
        receptionAnswerDataDto.setBtnLinkUrl("http://localhost:8080/easy");

        /**
         * 簡易受付結果
         */
        receptionAnswerDataDto.setSimpleReceptionResult("1");

        /**
         * 回答先申込IDリスト
         */
        List<String> applyIdList = new ArrayList<String>();
        applyIdList.add("123456");
        /**
         * 回答方法種別
         */
        receptionAnswerDataDto.setResponseMethodType("1");

        /**
         * 回答ステータス
         */
        receptionAnswerDataDto.setResponseStatus("あああ");

        /**
         * 更新タイムスタンプ(排他用)
         */
        receptionAnswerDataDto.setUpdateTs("あああ");
        responseList.add(receptionAnswerDataDto);
        responseDto.setResponseList(responseList);
        return responseDto;
    }

    /**
     * かんたん受付案内一覧照会
     *
     * @param requestDto かんたん受付案内一覧照会ABAリクエストDTO
     * @return かんたん受付案内一覧照会リクエストDTO
     */
    @Override
    public ReceptionInformationListInquiryResponseDto
            receptionInformationListInquiry(ReceptionInformationListInquiry requestDto) {
        ReceptionInformationListInquiryResponseDto responseDto = new ReceptionInformationListInquiryResponseDto();
        responseDto.setDataCount("111");
        List<ReceptionGuideDto> receptionGuideList = new ArrayList<ReceptionGuideDto>();
        ReceptionGuideDto receptionGuideDto = new ReceptionGuideDto();

        /**
         * お知らせID
         */
        receptionGuideDto.setAnncmntId("12345888");
        /**
         * タイトル
         */
        receptionGuideDto.setAnncmntTitle("ああああ");
        /**
         * 作成日時
         */
        receptionGuideDto.setCreateDateAndTime("2022-05-01");
        /**
         * 受付案内ステータス
         */
        receptionGuideDto.setReceptionGuideStatus(ReceptionGuideStatusCode.PUBLIC_PERMIT);
        /**
         * 受付案内種類
         */
        receptionGuideDto.setReceptionGuideType("1");
        /**
         * 掲載開始日時
         */
        receptionGuideDto.setAnncmntStartTime("2022-05-01");
        /**
         * 掲載終了日時
         */
        receptionGuideDto.setAnncmntEndTime("2022-05-22");
        /**
         * 非会員受付有無フラグ
         */
        receptionGuideDto.setNonMemberAplyFlg("1");
        /**
         * 判定結果
         */
        receptionGuideDto.setJudgementResult("1");
        receptionGuideList.add(receptionGuideDto);
        responseDto.setReceptionGuideList(receptionGuideList);
        return responseDto;
    }

    /**
     * かんたん受付申込詳細照会
     *
     * @param requestDto かんたん受付申込詳細照会ABAリクエストDTO
     * @return かんたん受付申込詳細照会ABAレスボスDTO
     */
    @Override
    public EasyReceptionApplicationDetailsInquiryAbaResponseDto
            easyReceptionApplicationDetailsInquiry(EasyReceptionApplicationDetailsInquiryAbaRequestDto requestDto) {

        EasyReceptionApplicationDetailsInquiryAbaResponseDto responseDto = new EasyReceptionApplicationDetailsInquiryAbaResponseDto();

        /**
         * 作成日時
         */
        responseDto.setCreateDateAndTime("2022-05-01");

        /**
         * 受付フォーマット
         */
        responseDto.setReceptionFormat(
                "{\"input_form\": [{\"form_type\":\"text_field\",\"form_name\":\"テスト1\","
                + "\"input_length\":\"100\",\"user_enterd_text\":\"\"},{\"form_type\":\"list_box\","
                + "\"form_name\":\"テスト2\",\"items\": [{\"item_id\":\"1\",\"item_name\":\"テスト1\"},"
                + "{\"item_id\":\"2\",\"item_name\":\"テスト2\"},{\"item_id\":\"3\",\"item_name\":\"テスト3\"}],"
                + "\"user_selected_item\":\"\"},{\"form_type\":\"radio_button\",\"form_name\":\"テスト3\","
                + "\"items\": [{\"item_id\":\"1\",\"item_name\":\"テスト1\"},{\"item_id\":\"2\",\"item_name\":"
                + "\"テスト2\"},{\"item_id\":\"3\",\"item_name\":\"テスト3\"}],\"user_selected_item\":\"\"},"
                + "{\"form_type\":\"check_box\",\"form_name\":\"テスト3\",\"items\": [{\"item_id\":\"1\",\"item_name\":\"テスト1\"},"
                + "{\"item_id\":\"2\",\"item_name\":\"テスト2\"},{\"item_id\":\"3\",\"item_name\":\"テスト3\"}],\"user_selected_items\": []}]}");
        /**
         * お知らせID
         */
        responseDto.setAnncmntId("001");

        /**
         * 申込ID
         */
        responseDto.setApplyId("0001");

        /**
         * タイトル
         */
        responseDto.setAnncmntTitle("かんたん受付申込詳細照会01");

        /**
         * 非会員フラグ
         */
        responseDto.setNonMemberFlg("1");

        /**
         * 顧客ID
         */
        responseDto.setCustomerId("jbaid");

        /**
         * 利用者ID
         */
        responseDto.setUserId("0000001");

        /**
         * カナ氏名
         */
        responseDto.setCustNameKana("ﾀﾅ ﾊﾊ");

        /**
         * 漢字氏名
         */
        responseDto.setCustNameKanji("田中 中村");

        /**
         * 郵便番号
         */
        responseDto.setCustZipCode("10005");

        /**
         * カナ住所
         */
        responseDto.setCustAddressKana("カナｼﾞｭ");

        /**
         * 住所
         */
        responseDto.setCustAddress("住所");

        /**
         * 電話番号
         */
        responseDto.setCustPhone("100-1234-555");

        /**
         * メールアドレス
         */
        responseDto.setCustMail("testz@mail.com");

        /**
         * 窓口支店番号
         */
        responseDto.setContactBranchNum("001");

        List<CifNumberDto> dtoList = new ArrayList<CifNumberDto>();
        /**
         * CIF番号リスト
         */
        CifNumberDto cifNo = new CifNumberDto();
        cifNo.setCifNo("0001");
        
        /**
         * CIF番号リスト
         */
        CifNumberDto cifNo1 = new CifNumberDto();
        cifNo1.setCifNo("0002");
        dtoList.add(cifNo);  
        dtoList.add(cifNo1);     
        responseDto.setCifNoList(dtoList);

        return responseDto;
    }
}

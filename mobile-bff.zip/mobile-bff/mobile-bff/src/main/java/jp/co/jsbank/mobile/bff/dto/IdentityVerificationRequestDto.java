package jp.co.jsbank.mobile.bff.dto;


import lombok.Data;

/**
 * 本人照合リクエストDTO
 */
@Data
public class IdentityVerificationRequestDto {
    
    /**
     * 本人区分
     */
    private String personType;

    /**
     * 店番
     */
    private String branchCode;

    /**
     * 口座番号
     */
    private String accountNumber;

    /**
     * 漢字氏名
     */
    private String customerKanjiName;
    
    /**
     * カナ氏名
     */
    private String customerName;

    /**
     * 生年月日
     */
    private String birthDay;

    /**
     * 郵便番号
     */
    private String zipCode;

    /**
     * CC暗証番号
     */
    private String ccPinCode;
    
    /**
     * 所属
     */
    private String divisionCode;
    
    /**
     * 認証キー
     */
    private String authCode;

    /**
     * デバイスID
     */
    private String deviceId;
}

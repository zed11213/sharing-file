package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 認証キー発行AbaレスポンスDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class AuthenticationKeyIssuanceAbaResponseDto extends RequestBodyDto {
	
	
	 /**
     * 共通レスポンス・ボディ
     */
    private CommonResponseHeader commonResponseHeader;
    
	 /**
     * 認証キー
     */
    private String authenticationKey;
    
	 /**
     * 有効期限
     */
    private String expiryDateTime;
    
 }

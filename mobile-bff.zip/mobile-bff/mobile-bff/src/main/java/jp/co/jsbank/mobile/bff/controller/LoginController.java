package jp.co.jsbank.mobile.bff.controller;

import javax.annotation.Resource;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import jp.co.jsbank.mobile.bff.common.JsonResult;
import jp.co.jsbank.mobile.bff.dto.AuthenticationKeyVerificationRequestDto;
import jp.co.jsbank.mobile.bff.service.LoginService;

/**
 * ログインコントロール
 */
@RestController
public class LoginController {

    @Resource
    private LoginService loginService;

    // private Logger logger = LoggerFactory.getLogger(LoginController.class);

    /**
     * ログイン認証
     *
     * @return JsonResult
     */
    @GetMapping("/login/AB0201")
    public JsonResult loginAuthentication() {

        String status = loginService.loginAuthentication();
        return JsonResult.success(status);
    }

    /**
     * 認証キー検証
     *
     * @param requestDto 認証キー検証リクエストDTO
     * @return JsonResult
     */
    @PostMapping("/login/AB0202")
    public JsonResult authenticationKeyVerification(@RequestBody AuthenticationKeyVerificationRequestDto requestDto) {

        String responseDto = loginService.authenticationKeyVerification(requestDto);
        return JsonResult.success(responseDto);
    }
}

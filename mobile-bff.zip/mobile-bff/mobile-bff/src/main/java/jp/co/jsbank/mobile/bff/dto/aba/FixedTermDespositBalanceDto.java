package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * 定期積金残高照会DTO
 */
@Data
public class FixedTermDespositBalanceDto {

    /**
     * 口座番号（ハイフン付き）
     */
    private String accountNoWithHyphen;

    /**
     * 口座番号
     */
    private String accountNumber;

    /**
     * 定期種類
     */
    private String regularTypeCode;

    /**
     * 定期種類（文言）
     */
    private String regularTypeCodeValue;

    /**
     * 期間
     */
    private String periodCode;

    /**
     * 期間（文言）
     */
    private String periodCodeValue;

    /**
     * 回数
     */
    private String numberOfTimes;

    /**
     * 利率
     */
    private String interestRate;

    /**
     * 課税区分
     */
    private String taxClassCode;

    /**
     * 課税区分（文言）
     */
    private String taxClassName;

    /**
     * 契約日
     */
    private String contractDate;

    /**
     * 満期日
     */
    private String maturityDate;

    /**
     * 元帳残高
     */
    private String balanceOfLedger;

    /**
     * 利息受取口座番号（ハイフン付き）
     */
    private String irAccountNoWithHyphen;

    /**
     * 利息受取口座番号
     */
    private String irAccountNumber;

    /**
     * スーパードリーム等スーパー定期種類
     */
    private String superRegularType;

    /**
     * 懸賞金区分
     */
    private String rewardAmountTypeCode;

    /**
     * 懸賞金区分（文言）
     */
    private String rewardAmountTypeValue;

    /**
     * 取扱組
     */
    private String handlingGroup;

    /**
     * 開始抽選番号
     */
    private String lotteryNoStart;

    /**
     * 終了抽選番号
     */
    private String lotteryNoEnd;

    /**
     * 当選金
     */
    private String winningMoney;

    /**
     * CIF番号（ハイフン付き）
     */
    private String cifNoWithHyphen;

    /**
     * CIF番号
     */
    private String cifNo;

}

package jp.co.jsbank.mobile.bff.dto;

import java.util.List;

import lombok.Data;

/**
 * お知らせ一覧レスポンスDTO
 */
@Data
public class InformationTextResponseDto {

    /**
     * お知らせ一覧Dtoリスト
     */
    private List<InformationTextDto> InformationTextDtoList;
}

package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * メールアドレス登録ABAレスポンスDTO
 */
@Data
public class EmailAddressRegistrationAbaResponseDto {
	
	
	 /**
     * 共通レスポンス・ボディ
     */
    private CommonResponseHeader commonResponseHeader;
    
	 /**
     * 認証TRXキー
     */
    private String verifyTRXKey;
    
    
 }

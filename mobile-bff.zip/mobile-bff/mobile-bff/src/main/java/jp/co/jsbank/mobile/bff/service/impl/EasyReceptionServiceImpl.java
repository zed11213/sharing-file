package jp.co.jsbank.mobile.bff.service.impl;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.jsbank.mobile.bff.common.Constant;
import jp.co.jsbank.mobile.bff.common.GetIdByTokenHandler;
import jp.co.jsbank.mobile.bff.common.RequestHeaderContext;
import jp.co.jsbank.mobile.bff.common.code.IndexCode;
import jp.co.jsbank.mobile.bff.common.code.NonMemberAplyFlgCode;
import jp.co.jsbank.mobile.bff.common.code.ReceptionGuideStatusCode;
import jp.co.jsbank.mobile.bff.common.icos.IcosHandler;
import jp.co.jsbank.mobile.bff.common.util.DecryptorHelper;
import jp.co.jsbank.mobile.bff.dto.AddressInfoDto;
import jp.co.jsbank.mobile.bff.dto.ApplicationAnswerViewResponseDto;
import jp.co.jsbank.mobile.bff.dto.BranchStoreAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.BranchStoreDto;
import jp.co.jsbank.mobile.bff.dto.EasyReceptionApplicationDetailsInquiryAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.EasyReceptionGuideDetailedInquiryAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.EasyRegistrationScreenAcquisitionResponseDto;
import jp.co.jsbank.mobile.bff.dto.EasyRegistrationScreenInputInfoSendingRequestDto;
import jp.co.jsbank.mobile.bff.dto.GuidanceInquiryInfTypeIdResponseDto;
import jp.co.jsbank.mobile.bff.dto.ReceptionAnswerDataDto;
import jp.co.jsbank.mobile.bff.dto.ReceptionInformationViewResponseDto;
import jp.co.jsbank.mobile.bff.dto.ReceptionNotificationViewResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.BranchOfficeListInquiryAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CustomerAttributeInfoDto;
import jp.co.jsbank.mobile.bff.dto.aba.CustomerAttributeInquiryAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CustomerAttributeInquiryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.EasyReceptionAnswerDetailInquiryAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.EasyReceptionAnswerDetailInquiryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.EasyReceptionApplicationDetailsInquiryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.EasyReceptionApplicationRegistrationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.EasyReceptionApplicationRegistrationResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.GuidanceInquiryInfTypeIdAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.PostalCodeAddressInquiryAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.ReceptionInformationListInquiry;
import jp.co.jsbank.mobile.bff.dto.aba.ReceptionInformationListInquiryResponseDto;
import jp.co.jsbank.mobile.bff.logic.AccountOpeningLogic;
import jp.co.jsbank.mobile.bff.logic.EasyReceptionLogic;
import jp.co.jsbank.mobile.bff.logic.SignUpLogic;
import jp.co.jsbank.mobile.bff.service.EasyReceptionService;

/**
 * かんたん受付実装クラス
 */
@Service
public class EasyReceptionServiceImpl implements EasyReceptionService {

    /**
     * かんたん受付ロジック
     */
    @Resource
    private EasyReceptionLogic easyReceptionLogic;

    /**
     * 初回登録ロジック
     */
    @Resource
    private SignUpLogic signUpLogic;

    /**
     * 新規口座開設ロジック
     */
    @Resource
    private AccountOpeningLogic accountOpeningLogic;

    /**
     * Icos処理クラス
     */
    @Autowired
    private IcosHandler icosHandler;

    /**
     * ID取得クラス
     */
    @Autowired
    private GetIdByTokenHandler getIdByTokenHandler;

    /**
     * かんたん受付申込一覧照会
     *
     * @return かんたん受付案内一覧照会レスボスDTO
     */
    @Override
    public GuidanceInquiryInfTypeIdResponseDto guidanceInquiryInformationTypeId() {

        ReceptionInformationListInquiry requestDto = new ReceptionInformationListInquiry();

        // 受付案内ステータス設定
        List<String> receptionGuideStatusList = new ArrayList<>();
        receptionGuideStatusList.add(ReceptionGuideStatusCode.PUBLIC_PERMIT);
        requestDto.setReceptionGuideStatusList(receptionGuideStatusList);
        // 非会員受付有無フラグ設定
        requestDto.setNonMemberAplyFlg(NonMemberAplyFlgCode.SAVING_ACCOUNTS);
        // 照会開始位置設定
        requestDto.setIndex(IndexCode.UPSIDE);
        // かんたん受付案内一覧照会
        ReceptionInformationListInquiryResponseDto abaResponseDto = easyReceptionLogic
                .receptionInformationListInquiry(requestDto);

        // かんたん受付案内一覧照会レスボスDTO
        GuidanceInquiryInfTypeIdResponseDto responseDto = new GuidanceInquiryInfTypeIdResponseDto();
        // 該当件数設定
        responseDto.setDataCount(abaResponseDto.getDataCount());
        // かんたん受付案内リスト設定
        responseDto.setReceptionGuideList(abaResponseDto.getReceptionGuideList());
        return responseDto;
    }

    /**
     * かんたん登録画面取得
     *
     * @return かんたん登録画面取得レスボスDTO
     */
    @Override
    public EasyRegistrationScreenAcquisitionResponseDto easyRegistrationScreenAcquisition() {

        // 顧客属性照会ABAリクエストDTO
        CustomerAttributeInquiryAbaRequestDto abaRequestDto = new CustomerAttributeInquiryAbaRequestDto();
        // 顧客IDのトークン取得
        String jbaIdToken = RequestHeaderContext.getInstance().getJbaIdToken();
        // 顧客ID設定
        abaRequestDto.setCustomerId(getIdByTokenHandler.getIdByToken(jbaIdToken));

        // 顧客属性照会API
        CustomerAttributeInquiryAbaResponseDto customerAbaResponseDto = signUpLogic.customerAttInquiry(abaRequestDto);

        // かんたん登録画面取得レスボスDTO
        EasyRegistrationScreenAcquisitionResponseDto responseDto = new EasyRegistrationScreenAcquisitionResponseDto();

        if (Objects.nonNull(customerAbaResponseDto.getCustomerList())
                && customerAbaResponseDto.getCustomerList().size() > 0) {

            CustomerAttributeInfoDto customerAttributeInfoDto = customerAbaResponseDto.getCustomerList().get(0);

            BeanUtils.copyProperties(customerAttributeInfoDto, responseDto);
            // 郵便番号住所照会
            PostalCodeAddressInquiryAbaResponseDto postalCodeAbaResponseDto = accountOpeningLogic
                    .postalCodeAddressInquiry(customerAttributeInfoDto.getZipNo());

            if (Objects.nonNull(postalCodeAbaResponseDto.getAddressInfo())
                    && postalCodeAbaResponseDto.getAddressInfo().size() > 0) {

                // 住所情報DTO取得
                AddressInfoDto addressInfoDto = postalCodeAbaResponseDto.getAddressInfo().get(0);

                // 住所ｶﾅ設定
                responseDto.setAddressKana(addressInfoDto.getPrefectureKana().concat(addressInfoDto.getCityKana())
                        .concat(addressInfoDto.getAddrdetail1Kana()));
            }
        }

        return responseDto;
    }

    /**
     * 受付通知閲覧
     *
     * @param anncmntId お知らせID
     * @param documentTypeId 文書種別ID
     * 
     * @return 受付通知閲覧レスポンスDTO
     */
    @Override
    public ReceptionNotificationViewResponseDto receptionNotificationView(String anncmntId, String applicationId) {

        // かんたん受付申込詳細照会ABAリクエストDTO
        EasyReceptionApplicationDetailsInquiryAbaRequestDto requestDto = new EasyReceptionApplicationDetailsInquiryAbaRequestDto();
        // お知らせID設定
        requestDto.setAnncmntId(anncmntId);

        // かんたん受付申込詳細照会API
        EasyReceptionApplicationDetailsInquiryAbaResponseDto abaResponseDto = easyReceptionLogic
                .easyReceptionApplicationDetailsInquiry(requestDto);

        // 受付通知閲覧レスポンスDTO
        ReceptionNotificationViewResponseDto responseDto = new ReceptionNotificationViewResponseDto();
        // 申込データ
        BeanUtils.copyProperties(abaResponseDto, responseDto);

        BranchOfficeListInquiryAbaRequestDto branchAbaRequestDto = new BranchOfficeListInquiryAbaRequestDto();
        // 金融機関コードに「1344」を設定する
        branchAbaRequestDto.setBankCode(Constant.FIXED_VALUE_FINANCIAL_CODE);
        // 店番設定
        branchAbaRequestDto.setBranchNumber(abaResponseDto.getContactBranchNum());
        // 支店一覧照会
        BranchStoreAbaResponseDto branchStoreAbaResponseDto = easyReceptionLogic
                .branchOfficeListInquiry(branchAbaRequestDto);

        // 支店一覧取得
        List<BranchStoreDto> abaBranchList = branchStoreAbaResponseDto.getBranchList();

        if (Objects.nonNull(abaBranchList) && abaBranchList.size() > 0) {

            // 店名取得
            String branchKanjiName = abaBranchList.get(0).getBranchKanjiName();

            responseDto.setBranchName(branchKanjiName);
        }

        return responseDto;
    }

    /**
     * かんたん登録画面入力情報送信
     *
     * @param requestDto かんたん登録画面入力情報送信リクエストDTO
     * 
     * @return 処理結果
     */
    @Override
    public String easyRegistrationScreenInputInfoSending(EasyRegistrationScreenInputInfoSendingRequestDto requestDto) {

        // かんたん受付申込登録ABAリクエストDTO
        EasyReceptionApplicationRegistrationAbaRequestDto abaRequestDto = new EasyReceptionApplicationRegistrationAbaRequestDto();

        BeanUtils.copyProperties(requestDto, abaRequestDto);
        // 利用者ID Token取得する
        String userIdToken = RequestHeaderContext.getInstance().getUserIdToken();
        // 利用者ID設定
        abaRequestDto.setUserId(getIdByTokenHandler.getIdByToken(userIdToken));

        // かんたん受付申込登録
        EasyReceptionApplicationRegistrationResponseDto abaResponseDto = easyReceptionLogic
                .easyReceptionApplicationRegistration(abaRequestDto);

        return abaResponseDto.getApplyId();
    }

    /**
     * 申込回答閲覧
     *
     * @param applicationId 申込ID
     * @param anncmntId お知らせID
     * @return 申込回答閲覧レスボスDTO
     */
    @Override
    public ApplicationAnswerViewResponseDto applicationAnswerView(String applicationId, String anncmntId) {

        // 申込回答閲覧レスボスDTO
        ApplicationAnswerViewResponseDto responseDto = new ApplicationAnswerViewResponseDto();

        // かんたん受付申込詳細照会ABAリクエストDTO
        EasyReceptionApplicationDetailsInquiryAbaRequestDto applicationDetailsInquiryAbaRequestDto = new EasyReceptionApplicationDetailsInquiryAbaRequestDto();
        // お知らせID設定
        applicationDetailsInquiryAbaRequestDto.setAnncmntId(anncmntId);
        // 申込ID設定
        applicationDetailsInquiryAbaRequestDto.setApplyId(applicationId);

        // かんたん受付申込詳細照会ABAレスボスDTO
        EasyReceptionApplicationDetailsInquiryAbaResponseDto applicationDetailsInquiryAbaResponseDto = easyReceptionLogic
                .easyReceptionApplicationDetailsInquiry(applicationDetailsInquiryAbaRequestDto);

        BeanUtils.copyProperties(applicationDetailsInquiryAbaResponseDto, responseDto);

        BranchOfficeListInquiryAbaRequestDto branchAbaRequestDto = new BranchOfficeListInquiryAbaRequestDto();
        // 金融機関コードに「1344」を設定する
        branchAbaRequestDto.setBankCode(Constant.FIXED_VALUE_FINANCIAL_CODE);
        // 店番設定
        branchAbaRequestDto.setBranchNumber(applicationDetailsInquiryAbaResponseDto.getContactBranchNum());
        // 支店一覧照会
        BranchStoreAbaResponseDto branchStoreAbaResponseDto = easyReceptionLogic
                .branchOfficeListInquiry(branchAbaRequestDto);

        // 支店一覧取得
        List<BranchStoreDto> abaBranchList = branchStoreAbaResponseDto.getBranchList();

        if (Objects.nonNull(abaBranchList) && abaBranchList.size() > 0) {

            // 店名取得
            String branchKanjiName = abaBranchList.get(0).getBranchKanjiName();

            responseDto.setBranchName(branchKanjiName);
        }

        // かんたん受付回答詳細照会ABAリクエストDTO
        EasyReceptionAnswerDetailInquiryAbaRequestDto answerDetailInquiryAbaRequestDto = new EasyReceptionAnswerDetailInquiryAbaRequestDto();
        // お知らせID設定
        answerDetailInquiryAbaRequestDto.setAnncmntId(anncmntId);
        // 申込ID設定
        answerDetailInquiryAbaRequestDto.setApplyId(applicationId);

        // かんたん受付回答詳細照会API
        EasyReceptionAnswerDetailInquiryAbaResponseDto answerDetailInquiryAbaResponseDto = easyReceptionLogic
                .easyReceptionAnswerDetailInquiry(answerDetailInquiryAbaRequestDto);

        if (Objects.nonNull(answerDetailInquiryAbaResponseDto.getResponseList())) {

            // かんたん受付回答取得
            ReceptionAnswerDataDto receptionAnswerDataDto = answerDetailInquiryAbaResponseDto.getResponseList().stream()
                    .filter(data -> Constant.PUBLIC_FLG.equals(data.getPublicFlg())).findAny().orElse(null);

            if (Objects.nonNull(receptionAnswerDataDto)) {

                // 回答本文設定
                responseDto.setResponseMsg(receptionAnswerDataDto.getResponseMsg());
                // ボタンリンク先有無フラグ設定
                responseDto.setBtnLinkFlg(receptionAnswerDataDto.getBtnLinkFlg());
                // ボタンリンク先URL設定
                responseDto.setBtnLinkUrl(receptionAnswerDataDto.getBtnLinkUrl());
                // ボタン種類設定
                responseDto.setBtnType(receptionAnswerDataDto.getBtnType());

                // 画像ファイル有の場合
                if (StringUtils.equals(receptionAnswerDataDto.getResImgFlg(), "1")) {

                    // 画像ファイルを取得する
                    InputStream imageFileStream = icosHandler.getFile(receptionAnswerDataDto.getResImgFilename());

                    if (Objects.nonNull(imageFileStream)) {

                        String imageFile = DecryptorHelper.toBase64(imageFileStream);
                        // 画像ファイル設定
                        responseDto.setFileStream(imageFile);
                    }
                }
            }
        }

        // かんたん受付案内詳細照会ABAリクエストDTO
        EasyReceptionGuideDetailedInquiryAbaRequestDto guideDetailedInquiryAbaRequestDto = new EasyReceptionGuideDetailedInquiryAbaRequestDto();
        // お知らせID設定
        guideDetailedInquiryAbaRequestDto.setAnncmntId(anncmntId);

        // かんたん受付案内詳細照会ABAリクエストDTO
        GuidanceInquiryInfTypeIdAbaResponseDto guideDetailedInquiryAbaResponseDto = easyReceptionLogic
                .easyReceptionGuideDetailedInquiry(guideDetailedInquiryAbaRequestDto);

        // 申込確認メッセージ設定
        responseDto.setApplyConfirmMsg(guideDetailedInquiryAbaResponseDto.getApplyConfirmMsg());

        return responseDto;
    }

    /**
     * 受付案内閲覧
     *
     * @param anncmntId お知らせID
     * @return 受付案内閲覧レスボスDTO
     */
    @Override
    public ReceptionInformationViewResponseDto receptionInformationView(String anncmntId) {

        // かんたん受付案内詳細照会ABAリクエストDTO
        EasyReceptionGuideDetailedInquiryAbaRequestDto requestDto = new EasyReceptionGuideDetailedInquiryAbaRequestDto();
        // お知らせID設定
        requestDto.setAnncmntId(anncmntId);

        // かんたん受付案内詳細照会ABAリクエストDTO
        GuidanceInquiryInfTypeIdAbaResponseDto abaResponseDto = easyReceptionLogic
                .easyReceptionGuideDetailedInquiry(requestDto);

        ReceptionInformationViewResponseDto responseDto = new ReceptionInformationViewResponseDto();

        BeanUtils.copyProperties(abaResponseDto, responseDto);

        BranchOfficeListInquiryAbaRequestDto branchAbaRequestDto = new BranchOfficeListInquiryAbaRequestDto();
        // 金融機関コードに「1344」を設定する
        branchAbaRequestDto.setBankCode(Constant.FIXED_VALUE_FINANCIAL_CODE);
        // 支店一覧照会
        BranchStoreAbaResponseDto branchStoreAbaResponseDto = easyReceptionLogic
                .branchOfficeListInquiry(branchAbaRequestDto);

        // 支店一覧取得
        List<BranchStoreDto> abaBranchList = branchStoreAbaResponseDto.getBranchList();

        List<BranchStoreDto> branchList = abaBranchList.stream()
                .filter(data -> abaResponseDto.getDestinationBranchNumList().contains(data.getBranchNumber()))
                .collect(Collectors.toList());

        // 支店設定
        if (Objects.nonNull(branchList)) {

            Map<String, String> branchMap = new HashMap<>();

            for (BranchStoreDto branchStoreDto : branchList) {

                branchMap.put(branchStoreDto.getBranchNumber(), branchStoreDto.getBranchKanjiName());
            }

            responseDto.setBranchMap(branchMap);
        }

        // 画像ファイル有の場合
        if (StringUtils.equals(abaResponseDto.getImgFlg(), "1")) {

            // 画像ファイルを取得する
            InputStream imageFileStream = icosHandler.getFile(abaResponseDto.getImgFilename());

            if (Objects.nonNull(imageFileStream)) {

                String imageFile = DecryptorHelper.toBase64(imageFileStream);
                // 画像ファイル設定
                responseDto.setFileStream(imageFile);
            }
        }

        return responseDto;
    }
}

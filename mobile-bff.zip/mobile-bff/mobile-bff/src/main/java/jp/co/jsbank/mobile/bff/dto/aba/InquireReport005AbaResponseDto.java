package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.AutomaticRenewalTimeDepositInterestCalculationDto;
import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 帳票CSV内容照会_定期預金（自継）利息計算ABAレスポンスDTO
 */
@Data
public class InquireReport005AbaResponseDto {

    /**
     * 共通レスポンスヘッダ
     */
    private CommonResponseHeader commonResponseHeader;

    /**
     * 帳票バージョン
     */
    private String formVersion;

    /**
     * 本状作成日
     */
    private String bookCreateDate;

    /**
     * 自動継続定期預金お利息計算明細表リスト
     */
    private List<AutomaticRenewalTimeDepositInterestCalculationDto> automaticRenewalTimeDepositInterestCalculationList;

    /**
     * 取扱店名
     */
    private String branchKanjiName;

    /**
     * 取扱電話番号
     */
    private String branchPhoneNumber;
}

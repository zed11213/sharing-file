package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * 引継ぎコードリクエストDTO
 */
@Data
public class TakeoverCodeAbaRequestDto {

    /**
     * 引継ぎコード
     */
    private String takeoverCode;
}

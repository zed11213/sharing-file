package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 支店詳細照会リクエストDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class BranchDetailDisplayAbaRequestDto extends RequestBodyDto {

    /**
     * 店番
     */
    private String branchNumber;
    
    /**
     * 金融機関コード
     */
    private String bankCode;
       
   
}

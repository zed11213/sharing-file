package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * 申込完了リクエストDTO
 */
@Data
public class ApplicationCompleteAbaRequestDto {
    
    /**
     * 受付番号
     */
    private String receiptNumber;
    
 }

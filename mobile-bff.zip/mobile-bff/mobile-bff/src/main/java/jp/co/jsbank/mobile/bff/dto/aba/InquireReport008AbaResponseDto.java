package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 帳票CSV内容照会_借入終了案内ABAレスポンスDTO
 */
@Data
public class InquireReport008AbaResponseDto {

	/**
	 * 共通レスポンスヘッダ
	 */
	private CommonResponseHeader commonResponseHeader;

	/**
	 * 帳票バージョン
	 */
	private String formVersion;

	/**
	 * 共通作成日付
	 */
	private String comCreateDate;

	/**
	 * 取扱店名
	 */
	private String branchKanjiName;

	/**
	 * 取扱電話番号
	 */
	private String branchPhoneNumber;

	/**
	 * 作成通番
	 */
	private String createSeqNo;

	/**
	 * 発行区分
	 */
	private String issueType;

	/**
	 * 完済日
	 */
	private String liquidationDate;
}

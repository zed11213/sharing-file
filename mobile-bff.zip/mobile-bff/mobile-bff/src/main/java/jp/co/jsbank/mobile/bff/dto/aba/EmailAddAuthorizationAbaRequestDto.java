package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * メールアドレス登録ABAリクエストDTO
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class EmailAddAuthorizationAbaRequestDto extends RequestBodyDto {

    /**
     * メールアドレス
     */
    private String emailAddress;
    
    /**
     * 受付番号
     */
    private String receiptNumber;

    /**
     * メールOTP
     */
    private String mailOTP;
    
    /**
     * 更新パターン
     */
    private String updateType;
    
    /**
     * 画面ID
     */
    private String pageId;
}

package jp.co.jsbank.mobile.bff.common;

public class MsgIdConstant {

    /**
     * メッセージID：MAAB0001
     */
    public static final String MSG_MAAB0001 = "MAAB0001";

    /**
     * メッセージID：MAAB0006
     */
    public static final String MSG_MAAB0006 = "MAAB0006";
}

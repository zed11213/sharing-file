package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * 初回契約者登録ABAレスボスDTO
 */
@Data
public class FirstContractorRegistrationAbaResponseDto {
    /**
     * JBAID
     */
    private String jbaid;


    /**
     * 利用者ID
     */
    private String userId;
}

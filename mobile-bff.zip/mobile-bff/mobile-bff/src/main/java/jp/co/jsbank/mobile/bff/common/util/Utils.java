package jp.co.jsbank.mobile.bff.common.util;

/**
 * ツールクラス
 */
public class Utils {
}

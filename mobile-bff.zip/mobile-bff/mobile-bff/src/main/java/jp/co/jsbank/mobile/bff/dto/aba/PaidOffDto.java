package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * 領収印情報DTO
 */
@Data
public class PaidOffDto {

    /**
     * 回数
     */
    private String numberOfTimes;

    /**
     * 預入日
     */
    private String termDepositDate;

}

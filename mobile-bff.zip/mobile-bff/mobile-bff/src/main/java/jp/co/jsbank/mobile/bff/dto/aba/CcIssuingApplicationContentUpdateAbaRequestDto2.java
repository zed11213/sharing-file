package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * CC発行申込内容更新リクエストDTO
 */
@Data
public class CcIssuingApplicationContentUpdateAbaRequestDto2  {
	
	
	 /**
     * 受付番号
     */
    private String receptionNumber;
    
	 /**
     * デザインID
     */
    private String designId;
    
	 /**
     * 利用者ID
     */
    private String userId;
    
 }




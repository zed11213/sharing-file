package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * 利用者属性更新ABAレスボスDTO
 */
@Data
public class UserPropertyUpdateAbaResponseDto {
	
	 /**
    * 共通レスポンス・ボディ
    */
   private CommonResponseHeader commonResponseBody;
   
}

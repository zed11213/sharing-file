package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * お客様情報入力リクエストDTO
 */
@Data
public class CustomerInformationEntryRequestDto {

    /**
     * 人格区分
     */
    private String personType;

    /**
     * 受付番号
     */
    private String receiptNumber;

    /**
     * 口座開設申込情報（個人）DTO
     */
    private AccountOpeningApplicationIndividualInfoDto individual;

    /**
     * 口座開設申込情報（法人）DTO
     */
    private AccountOpeningApplicationCorporationInfoDto corporation;

    /**
     * 口座開設申込情報（個人事業主）DTO
     */
    private AccountOpeningApplicationBusinessOwnerInfoDto soleProprietor;

}

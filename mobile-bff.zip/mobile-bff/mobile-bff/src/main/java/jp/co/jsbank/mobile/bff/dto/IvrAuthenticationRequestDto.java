package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * IVR認証リクエストDTO
 */
@Data
public class IvrAuthenticationRequestDto {

    /**
     * 認証TRXキー
     */
    private String verifyTRXKey;

    /**
     * 受付番号
     */
    private String receiptNumber;

    /**
     * IVROTP
     */
    private String ivrOTP;

}

package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 抽選結果情報ABAリクエストDTO
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class LotteryResultAbaRequestDto  extends RequestBodyDto{

    /**
     * 口座番号
     */
    private String accountNumber;

    /**
     * 店番
     */
    private String branchNumber;

    /**
     * 回次
     */
    private String lotteryTimes;
    
    /**
     * 取扱組
     */
    private String lotterySet;
}

package jp.co.jsbank.mobile.bff.common.code;

/**
 * 非会員受付有無コード
 */
public class NonMemberAplyFlgCode {

    /**
     * 有
     */
    public static final String SAVING_ACCOUNTS = "NMR01";

    /**
     * 無
     */
    public static final String CURRENT_ACCOUNT = "NMR02";
}

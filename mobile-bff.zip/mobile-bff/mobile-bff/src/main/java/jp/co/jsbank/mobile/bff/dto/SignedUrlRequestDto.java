package jp.co.jsbank.mobile.bff.dto;

import java.util.List;

import lombok.Data;

/**
 * 署名付きURLリクエストDTO
 */
@Data
public class SignedUrlRequestDto {

    /**
     * 人格区分
     */
    private String personType;

    /**
     * 受付番号
     */
    private String receiptNumber;
    
    /**
     * eKYC確認結果
     */
    private String ekycResult; 
    
    /**
     * ファイルストリーム
     */
    List<FileStreamDto> fileStreams;
    
    /**
     * 口座開設申込情報（個人）DTO
     */
    private IcosIndividualDto individual;
}

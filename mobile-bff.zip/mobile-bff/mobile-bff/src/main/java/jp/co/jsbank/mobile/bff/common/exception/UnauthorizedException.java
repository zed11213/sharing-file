package jp.co.jsbank.mobile.bff.common.exception;

/**
 * データなし例外。
 *
 */
public class UnauthorizedException extends BusinessException {

	private static final long serialVersionUID = -1L;

	/**
	 * UnauthorizedExceptionのコンスタント。
	 * 
	 * @param errorCode エラーコード
	 */
	public UnauthorizedException() {
		super("401");
	}
}

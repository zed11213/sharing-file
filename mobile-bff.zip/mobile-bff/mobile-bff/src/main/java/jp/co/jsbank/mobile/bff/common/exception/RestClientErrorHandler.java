package jp.co.jsbank.mobile.bff.common.exception;

import java.io.IOException;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.client.ResponseErrorHandler;

/**
 * RestTemplate例外ハンドラクラス。
 */
@Component
public class RestClientErrorHandler implements ResponseErrorHandler {

    @Override
    public boolean hasError(ClientHttpResponse response) throws IOException {

        return (response.getStatusCode().series() == HttpStatus.Series.CLIENT_ERROR
                || response.getStatusCode().series() == HttpStatus.Series.SERVER_ERROR);
    }

    @Override
    public void handleError(ClientHttpResponse response) throws IOException {

        if (response.getStatusCode().series() == HttpStatus.Series.CLIENT_ERROR) {

            switch (response.getStatusCode()) {

                case BAD_REQUEST:
                    // TODO HTTP応答ステータス(400)
                    throw new BadRequestException("100");
                case UNAUTHORIZED:
                    // HTTP応答ステータス(401)
                    throw new UnauthorizedException();
                case FORBIDDEN:
                    // HTTP応答ステータス(403)
                    throw new ForbiddenException();
                case NOT_FOUND:
                    // HTTP応答ステータス(404)
                    throw new NotFoundException();
                case UPGRADE_REQUIRED:
                    // HTTP応答ステータス(426)
                    throw new UpgradeRequiredException();
                case TOO_MANY_REQUESTS:
                    // HTTP応答ステータス(429)
                    throw new TooManyRequestsException();
                case INTERNAL_SERVER_ERROR:
                    // TODO HTTP応答ステータス(500)
                    throw new InternalServerErrorException("100");
                case SERVICE_UNAVAILABLE:
                    // HTTP応答ステータス(503)
                    throw new ServiceUnavailableException();
                default:
                    // なし
            }
        }
    }
}

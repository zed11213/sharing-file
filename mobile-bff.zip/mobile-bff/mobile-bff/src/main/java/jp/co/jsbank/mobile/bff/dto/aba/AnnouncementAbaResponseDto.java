package jp.co.jsbank.mobile.bff.dto.aba;

import java.util.List;

import jp.co.jsbank.mobile.bff.dto.AnnouncementDto;
import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import lombok.Data;

/**
 * お知らせ一覧ABAレスポンスDTO
 */
@Data
public class AnnouncementAbaResponseDto {

    /**
     * 共通レスポンスヘッダ
     */
    private CommonResponseHeader commonResponseHeader;
    
    /**
     * お知らせ一覧DTOリスト
     */
    private List<AnnouncementDto> anncmntList;
    
    /**
     * 該当件数
     */
    private String dataCount;

}

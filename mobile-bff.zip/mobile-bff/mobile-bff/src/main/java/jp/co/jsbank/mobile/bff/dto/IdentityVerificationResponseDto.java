package jp.co.jsbank.mobile.bff.dto;

import lombok.Data;

/**
 * 本人照合レスボスDTO
 */
@Data
public class IdentityVerificationResponseDto {

    /**
     * 顧客ID 
     */
    private String customerId;

    /**
     * 利用者ID
     */
    private String userId;
    
    /**
     * CIF番号
     */
    private String cifNo;
}

package jp.co.jsbank.mobile.bff.dto.aba;

import jp.co.jsbank.mobile.bff.common.builder.RequestBodyDto;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * メールアドレス登録ABAリクエストDTO
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class EmailAddressRegistrationAbaRequestDto extends RequestBodyDto {

    /**
     * 受付番号
     */
    private String receptionNumber;

    /**
     * 利用者ID
     */
    private String userId;

    /**
     * メールアドレス
     */
    private String emailAddress;

    /**
     * 処理区分
     */
    private String processType;
    
    /**
     * 更新パターン
     */
    private String updateType;

}

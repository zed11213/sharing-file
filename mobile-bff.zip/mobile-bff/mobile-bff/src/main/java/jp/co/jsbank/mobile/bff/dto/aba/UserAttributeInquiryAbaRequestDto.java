package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * 利用者属性照会ABAリクエストDTO
 */
@Data
public class UserAttributeInquiryAbaRequestDto {

    /**
     * 顧客ID
     */
    private String customerId;

    /**
     * 利用者ID
     */
    private String userId;
}

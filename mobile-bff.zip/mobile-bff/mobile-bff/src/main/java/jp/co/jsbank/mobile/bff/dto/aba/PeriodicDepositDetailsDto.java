package jp.co.jsbank.mobile.bff.dto.aba;

import lombok.Data;

/**
 * 定期積金明細DTO
 */
@Data
public class PeriodicDepositDetailsDto {

    /**
     * 元金
     */
    private String fundedBalance;

    /**
     * 満期日
     */
    private String maturityDate;

    /**
     * 期間
     */
    private String period;

    /**
     * 夢付き
     */
    private String dreamFlag;

    /**
     * 元帳残高
     */
    private String balanceOfLedger;

    /**
     * 契約額
     */
    private String agreementAmount;

    /**
     * 給付補填金
     */
    private String payupAmount;

    /**
     * 振替日・集金日
     */
    private String transferDate;

    /**
     * 掛金額
     */
    private String premium;
    
    /**
     * 契約日
     */
    private String contractDate;
    
    /**
     * 利率
     */
    private String interest;

    /**
     * 課税区分
     */
    private String taxClassName;

}

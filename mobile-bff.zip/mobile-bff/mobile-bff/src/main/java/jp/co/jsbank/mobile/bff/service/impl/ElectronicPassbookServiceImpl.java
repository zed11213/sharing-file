package jp.co.jsbank.mobile.bff.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jp.co.jsbank.mobile.bff.common.Constant;
import jp.co.jsbank.mobile.bff.common.RequestHeaderContext;
import jp.co.jsbank.mobile.bff.common.exception.NotFoundException;
import jp.co.jsbank.mobile.bff.common.redis.RedisHandler;
import jp.co.jsbank.mobile.bff.dto.AccountAndBalanceInfoResponseDto;
import jp.co.jsbank.mobile.bff.dto.AccountInfoDto;
import jp.co.jsbank.mobile.bff.dto.AccountInfoResponseDto;
import jp.co.jsbank.mobile.bff.dto.BalanceGraphResponseDto;
import jp.co.jsbank.mobile.bff.dto.CommonResponseHeader;
import jp.co.jsbank.mobile.bff.dto.LiquidityDepositDetailsResponseDto;
import jp.co.jsbank.mobile.bff.dto.LotteryStatusRequestDto;
import jp.co.jsbank.mobile.bff.dto.MemoRegistrationRequestDto;
import jp.co.jsbank.mobile.bff.dto.NotificationDepositDetailsResponseDto;
import jp.co.jsbank.mobile.bff.dto.PeriodicDepositDetailsResponseDto;
import jp.co.jsbank.mobile.bff.dto.TimeDepositDetailsResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.AccountInfoAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.AccountInfoAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.BalanceGraphAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.BalanceGraphAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.BalanceGraphDto;
import jp.co.jsbank.mobile.bff.dto.aba.CifInfomationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.CifInfomationAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.CifInfomationDto;
import jp.co.jsbank.mobile.bff.dto.aba.CommonHeaderAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.LiquidityDepositDetailsAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.LiquidityDepositDetailsAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.LiquidityDepositDetailsDto;
import jp.co.jsbank.mobile.bff.dto.aba.LotteryResultAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.LotteryResultAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.LotteryResultsDetailsDto;
import jp.co.jsbank.mobile.bff.dto.aba.MemoRegistrationAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.NotificationDepositAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.NotificationDepositDetailsAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.NotificationDepositDetailsDto;
import jp.co.jsbank.mobile.bff.dto.aba.PeriodicDepositDetailsAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.PeriodicDepositDetailsAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.TimeDepositDetailsAbaRequestDto;
import jp.co.jsbank.mobile.bff.dto.aba.TimeDepositDetailsAbaResponseDto;
import jp.co.jsbank.mobile.bff.dto.aba.TimeDepositDetailsDto;
import jp.co.jsbank.mobile.bff.logic.ElectronicPassbookLogic;
import jp.co.jsbank.mobile.bff.service.ElectronicPassbookService;

/**
 * 電子通帳サービス実装クラス
 */
@Service
public class ElectronicPassbookServiceImpl implements ElectronicPassbookService {

	/**
	 * 電子通帳ロジック
	 */
	@Resource
	private ElectronicPassbookLogic electronicPassbookLogic;

	/**
	 * redis
	 */
	@Autowired
	private RedisHandler redisHandler;

	/**
	 * 口座一覧と各口座の残高情報取得
	 *
	 * @return 口座一覧と各口座の残高情報
	 */
	@Override
	public AccountAndBalanceInfoResponseDto getAccountListAndBalanceInformation() {

		// ABAのエンドユーザーログインを認証する
		String jbaIdToken = RequestHeaderContext.getInstance().getJbaIdToken();

		if (!redisHandler.exists(jbaIdToken)) {
			// TODO エラー未定
			return null;
		}

		// redisからJBAIDを取得する
		String jbaId = redisHandler.get(jbaIdToken);

		// CIF情報取得リクエストDTO
		CifInfomationAbaRequestDto cifInfomationAbaRequestDto = new CifInfomationAbaRequestDto();
		// 顧客ID設定
		cifInfomationAbaRequestDto.setCustomerId(jbaId);
		try {

			// CIF情報取得
			CifInfomationAbaResponseDto cifInfomationAbaResponseDto = electronicPassbookLogic
					.getGifInfomation(cifInfomationAbaRequestDto);

			// エラーチェックを行う
			errorCheck(cifInfomationAbaResponseDto.getCommonResponseHeader());

			List<AccountInfoResponseDto> accountInfoResponseDtoList = new ArrayList<>();

			if (cifInfomationAbaResponseDto.getCifInfomationDtoList() != null
					&& cifInfomationAbaResponseDto.getCifInfomationDtoList().size() > 0) {

				for (CifInfomationDto responseDto : cifInfomationAbaResponseDto.getCifInfomationDtoList()) {
					// 残高情報取得リクエストDTO
					AccountInfoAbaRequestDto accountInfoAbaRequestDto = new AccountInfoAbaRequestDto();
					// CIF番号設定
					accountInfoAbaRequestDto.setCifNumber(responseDto.getCifNumber());
					// 店番設定
					accountInfoAbaRequestDto.setBranchCode(responseDto.getBranchCode());
					// 顧客ID設定
					accountInfoAbaRequestDto.setCustomerId(jbaId);
					// 残高情報照会
					AccountInfoAbaResponseDto accountInfoAbaResponseDto = electronicPassbookLogic
							.balanceInformationInquiry(accountInfoAbaRequestDto);

					// エラーチェックを行う
					errorCheck(accountInfoAbaResponseDto.getCommonResponseHeader());

					// 残高情報リスト
					List<AccountInfoDto> balanceList = accountInfoAbaResponseDto.getBalanceList();
					if (balanceList != null && balanceList.size() > 0) {
						for (AccountInfoDto InfoResponseDto : balanceList) {
							// 残高情報DTO取得
							AccountInfoResponseDto accountInfoDto = new AccountInfoResponseDto();

							BeanUtils.copyProperties(InfoResponseDto, accountInfoDto);

							// 残高情報追加
							accountInfoResponseDtoList.add(accountInfoDto);
						}
					}
				}
			}

			// 各科目毎残高合計取得
			List<AccountInfoResponseDto> tempResult = accountInfoResponseDtoList.stream()
					.collect(Collectors.toMap(AccountInfoResponseDto::getSubjectNameCode, a -> a, (o1, o2) -> {
						o1.setBalanceTotal(
								String.valueOf(Integer.valueOf(o1.getBalance()) + Integer.valueOf(o2.getBalance())));
						return o1;
					})).values().stream().collect(Collectors.toList());
			Map<String, String> balanceMap = new HashMap<String, String>();
			if (tempResult.size() > 0) {
				balanceMap = tempResult.stream().collect(Collectors.toMap(AccountInfoResponseDto::getSubjectNameCode,
						p -> p.getBalanceTotal() != null ? p.getBalanceTotal() : p.getBalance()));
			}

			// 全口座残高合計取得
			int totalBalance = accountInfoResponseDtoList.stream().mapToInt(p -> Integer.valueOf(p.getBalance())).sum();

			// 口座一覧レスポンスDTO
			AccountAndBalanceInfoResponseDto accountAndBalanceInfoResponseDto = new AccountAndBalanceInfoResponseDto();

			// 各科目毎残高合計設定
			accountAndBalanceInfoResponseDto.setSubjectTotalBalance(balanceMap);

			// 全口座残高合計設定
			accountAndBalanceInfoResponseDto.setAllAccountsTotalBalance(String.valueOf(totalBalance));

			// 口座一覧情報設定
			accountAndBalanceInfoResponseDto.setAccountInfoResponseDtoList(accountInfoResponseDtoList);

			return accountAndBalanceInfoResponseDto;
		} catch (Exception e) {

			throw new NotFoundException();
		}
	}

	/**
	 * 入出金明細取得(流動性預金)
	 * 
	 * @param detailContinuationFlag 明細継続フラグ
	 * @param detailIdFrom           開始明細ID
	 * @param maxInquiryCount        最大検索件数
	 * @Param accountType 預金種目
	 * @param branchNumber      店番
	 * @param accountNumber     口座番号
	 * @param dateOfInquiryFrom 照会開始年月日
	 * @param dateOfInquiryTo   照会終了年月日
	 * @return 入出金明細情報
	 */
	public LiquidityDepositDetailsResponseDto getIiquidityDepositDetails(String detailContinuationFlag,
			String detailIdFrom, String maxInquiryCount, String accountType, String branchNumber, String accountNumber,
			String dateOfInquiryFrom, String dateOfInquiryTo) {

		// ABAのエンドユーザーログインを認証する
		String jbaIdToken = RequestHeaderContext.getInstance().getJbaIdToken();

		if (!redisHandler.exists(jbaIdToken)) {
			// TODO エラー未定
			return null;
		}

		// redisからJBAIDを取得する
		String jbaId = redisHandler.get(jbaIdToken);

		// 入出金明細(流動性預金)リクエストDTO
		LiquidityDepositDetailsAbaRequestDto abaRequestDto = new LiquidityDepositDetailsAbaRequestDto();
		if (StringUtils.equals(detailContinuationFlag, "0")) {
			// 明細継続フラグ
			abaRequestDto.setDetailContinuationFlag(false);
		} else if (StringUtils.equals(detailContinuationFlag, "1")) {
			// 明細継続フラグ
			abaRequestDto.setDetailContinuationFlag(true);
		}

		// 開始明細ID
		abaRequestDto.setDetailIdFrom(detailIdFrom);
		// 最大検索件数
		abaRequestDto.setMaxInquiryCount(maxInquiryCount);
		// 預金種目
		abaRequestDto.setAccountType(accountType);
		// 店番
		abaRequestDto.setBranchNumber(branchNumber);
		// 顧客ID
		abaRequestDto.setCustomerId(jbaId);
		// 口座番号設定
		abaRequestDto.setAccountNumber(accountNumber);
		// 照会開始年月日設定
		abaRequestDto.setDateOfInquiryFrom(dateOfInquiryFrom);
		// 照会終了年月日設定
		abaRequestDto.setDateOfInquiryTo(dateOfInquiryTo);

		// 入出金明細取得
		LiquidityDepositDetailsAbaResponseDto abaResponseDto = new LiquidityDepositDetailsAbaResponseDto();

		try {

			// 入出金明細取得
			abaResponseDto = electronicPassbookLogic.getIiquidityDepositDetails(abaRequestDto);

		} catch (Exception e) {

			throw new NotFoundException();
		}

		// エラーチェックを行う
		errorCheck(abaResponseDto.getCommonResponseHeader());

		// 入出金明細(流動性預金)レスポンスDTOリスト
		LiquidityDepositDetailsResponseDto responseDto = new LiquidityDepositDetailsResponseDto();

		// 入出金明細(流動性預金)DTOリスト
		List<LiquidityDepositDetailsDto> liquidityDepositDetailsDto = abaResponseDto.getTransactionsList();

		responseDto.setTransactionsList(liquidityDepositDetailsDto);
		responseDto.setContinuationDetailId(abaResponseDto.getContinuationDetailId());
		responseDto.setDetailContinuationFlag(abaResponseDto.isDetailContinuationFlag());
		return responseDto;
	}

	/**
	 * 定期預金明細取得
	 *
	 * @param accountNumber 口座番号
	 * @param branchNumber  店番
	 * @param cifNumber     CIF番号
	 * @return 定期預金明細情報
	 */
	@Override
	public List<TimeDepositDetailsResponseDto> getTimeDepositDetails(String accountNumber, String branchNumber,
			String cifNumber) {

		// ABAのエンドユーザーログインを認証する
		String jbaIdToken = RequestHeaderContext.getInstance().getJbaIdToken();

		if (!redisHandler.exists(jbaIdToken)) {
			// TODO エラー未定
			return null;
		}

		// redisからJBAIDを取得する
		String jbaId = redisHandler.get(jbaIdToken);

		// 定期預金明細リクエストDTO
		TimeDepositDetailsAbaRequestDto abaRequestDto = new TimeDepositDetailsAbaRequestDto();
		// 口座番号設定
		abaRequestDto.setAccountNumber(accountNumber);
		// 店番
		abaRequestDto.setBranchNumber(branchNumber);
		// 顧客ID
		abaRequestDto.setCustomerId(jbaId);
		// CIF番号
		abaRequestDto.setCifNumber(cifNumber);

		try {

			// 定期預金明細
			TimeDepositDetailsAbaResponseDto abaResponseDto = electronicPassbookLogic
					.getTimeDepositDetails(abaRequestDto);

			// エラーチェックを行う
			errorCheck(abaResponseDto.getCommonResponseHeader());
			// 定期預金明細レスポンスDTOリスト
			List<TimeDepositDetailsResponseDto> responseDtoList = new ArrayList<>();

			// 定期預金明細DTOリスト
			List<TimeDepositDetailsDto> timeDepositDetailsDtoList = abaResponseDto.getTimeDepositDetailsDtoList();

			// 抽選結果明細リスト
			List<LotteryResultsDetailsDto> lotteryResultsDetaillist = new ArrayList<>();

			if (timeDepositDetailsDtoList != null && timeDepositDetailsDtoList.size() > 0) {

				for (TimeDepositDetailsDto timeDepositDetailsAbaResponseDto : timeDepositDetailsDtoList) {

					// 定期預金明細レスポンスDTO
					TimeDepositDetailsResponseDto responseDto = new TimeDepositDetailsResponseDto();

					BeanUtils.copyProperties(timeDepositDetailsAbaResponseDto, responseDto);

					// 抽選結果リクエストDTO
					LotteryResultAbaRequestDto lotteryResultabaRequestDto = new LotteryResultAbaRequestDto();
					// 口座番号設定
					lotteryResultabaRequestDto.setAccountNumber(responseDto.getIrAccountNumber());
					// 店番
					lotteryResultabaRequestDto.setBranchNumber(responseDto.getBranchNumber());
					// 回次
					lotteryResultabaRequestDto.setLotteryTimes(responseDto.getLotteryTimes());
					// 取扱組
					lotteryResultabaRequestDto.setLotterySet(responseDto.getHandlingGroup());
					// 抽選結果明細レスポンスDTO
					LotteryResultAbaResponseDto lotteryResultAbaResponseDto = electronicPassbookLogic
							.getLotteryResultInfomation(lotteryResultabaRequestDto);

					// エラーチェックを行う
					errorCheck(lotteryResultAbaResponseDto.getCommonResponseHeader());

					lotteryResultsDetaillist.addAll(lotteryResultAbaResponseDto.getLotteryResultsDetailsDtoList());

					responseDto.setLotteryResultsDetailsResponseList(lotteryResultsDetaillist);

					// 定期預金明細DTOリスト追加
					responseDtoList.add(responseDto);
				}
			}

			return responseDtoList;
		} catch (Exception e) {

			throw new NotFoundException();
		}

	}

	/**
	 * 定期積金明細取得
	 *
	 * @param accountNumber 口座番号
	 * @param branchNumber  店番
	 * @param cifNumber     CIF番号
	 * @return 定期積金明細情報
	 */
	@Override
	public PeriodicDepositDetailsResponseDto getPeriodicDepositDetails(String accountNumber, String branchNumber,
			String cifNumber) {

		// ABAのエンドユーザーログインを認証する
		String jbaIdToken = RequestHeaderContext.getInstance().getJbaIdToken();

		if (!redisHandler.exists(jbaIdToken)) {
			// TODO エラー未定
			return null;
		}

		// redisからJBAIDを取得する
		String jbaId = redisHandler.get(jbaIdToken);

		// 定期積金明細リクエストDTO
		PeriodicDepositDetailsAbaRequestDto abaRequestDto = new PeriodicDepositDetailsAbaRequestDto();
		// 口座番号設定
		abaRequestDto.setAccountNumber(accountNumber);
		// 店番
		abaRequestDto.setBranchNumber(branchNumber);
		// 顧客ID
		abaRequestDto.setCustomerId(jbaId);
		// CIF番号
		abaRequestDto.setCifNumber(cifNumber);

		// 定期積金明細取得
		PeriodicDepositDetailsAbaResponseDto abaResponseDto = new PeriodicDepositDetailsAbaResponseDto();
		try {

			// 定期積金明細取得
			abaResponseDto = electronicPassbookLogic.getPeriodicDepositDetails(abaRequestDto);

		} catch (Exception e) {

			throw new NotFoundException();
		}

		// エラーチェックを行う
		errorCheck(abaResponseDto.getCommonResponseHeader());

		// 定期積金明細レスポンスDTOリスト
		PeriodicDepositDetailsResponseDto responseDto = new PeriodicDepositDetailsResponseDto();

		// 定期積金明細DTO設定
		responseDto.setPeriodicDepositDetailsDto(abaResponseDto.getPeriodicDepositDetailsDto());
		// 領収印情報DTO設定
		responseDto.setPaidOffList(abaResponseDto.getPaidOffList());

		return responseDto;
	}

	/**
	 * 通知預金明細取得
	 *
	 * @param accountNumber 口座番号
	 * @param branchNumber  店番
	 * @param cifNumber     CIF番号
	 * @return 通知預金明細情報
	 */
	@Override
	public NotificationDepositDetailsResponseDto getNotificationDepositDetails(String accountNumber,
			String branchNumber, String cifNumber) {

		// ABAのエンドユーザーログインを認証する
		String jbaIdToken = RequestHeaderContext.getInstance().getJbaIdToken();

		if (!redisHandler.exists(jbaIdToken)) {
			// TODO エラー未定
			return null;
		}

		// redisからJBAIDを取得する
		String jbaId = redisHandler.get(jbaIdToken);

		// 通知預金明細リクエストDTO
		NotificationDepositDetailsAbaRequestDto abaRequestDto = new NotificationDepositDetailsAbaRequestDto();
		// 口座番号設定
		abaRequestDto.setAccountNumber(accountNumber);
		// 店番
		abaRequestDto.setBranchNumber(branchNumber);
		// 顧客ID
		abaRequestDto.setCustomerId(jbaId);
		// CIF番号
		abaRequestDto.setCifNumber(cifNumber);

		// 通知預金明細取得
		NotificationDepositAbaResponseDto abaResponseDto = new NotificationDepositAbaResponseDto();

		try {

			// 通知預金明細取得
			abaResponseDto = electronicPassbookLogic.getNotificationDepositDetails(abaRequestDto);

		} catch (Exception e) {

			throw new NotFoundException();
		}

		// エラーチェックを行う
		errorCheck(abaResponseDto.getCommonResponseHeader());

		// 通知預金明細レスポンスDTO
		NotificationDepositDetailsResponseDto responseDto = new NotificationDepositDetailsResponseDto();

		// 通知預金明細DTOリスト
		List<NotificationDepositDetailsDto> notificationDepositDetailsDtoList = abaResponseDto.getNoticeDepositList();

		responseDto.setNoticeDepositList(notificationDepositDetailsDtoList);
		responseDto.setAccountNumber(abaResponseDto.getAccountNumber());
		responseDto.setBranchNumber(abaResponseDto.getBranchNumber());
		return responseDto;
	}

	/**
	 * 概要欄メモ登録
	 *
	 * @param requestDto 明細概要メモ登録リクエストDTO
	 * @return 処理結果
	 */
	@Override
	public String overviewFieldMemoRegistration(MemoRegistrationRequestDto requestDto) {

		// ABAのエンドユーザーログインを認証する
		String jbaIdToken = RequestHeaderContext.getInstance().getJbaIdToken();

		if (!redisHandler.exists(jbaIdToken)) {
			// TODO エラー未定
			return null;
		}

		// redisからJBAIDを取得する
		String jbaId = redisHandler.get(jbaIdToken);

		// 概要欄メモ登録ABAリクエストDTO
		MemoRegistrationAbaRequestDto abaRequestDto = new MemoRegistrationAbaRequestDto();

		// 顧客ID
		abaRequestDto.setCustomerId(jbaId);
		// 店番
		abaRequestDto.setBranchNumber(requestDto.getBranchNumber());
		// 口座番号
		abaRequestDto.setAccountNumber(requestDto.getAccountNumber());
		// 明細ID
		abaRequestDto.setTransactionDetailNo(requestDto.getTransactionDetailNo());
		// メモ
		abaRequestDto.setMemo(requestDto.getMemo());

		// 概要欄メモ登録
		CommonHeaderAbaResponseDto abaResponseDto = new CommonHeaderAbaResponseDto();

		try {

			// 概要欄メモ登録
			electronicPassbookLogic.overviewFieldMemoRegistration(abaRequestDto);

		} catch (Exception e) {

			throw new NotFoundException();
		}

		// エラーチェックを行う
		errorCheck(abaResponseDto.getCommonResponseHeader());

		return Constant.OK;
	}

	/**
	 * 収支グラフ表示値取得
	 *
     * @param accountNumber 口座番号
     * @param branchNumber  店番
	 * @return 収支情報
	 */
	@Override
	public List<BalanceGraphResponseDto> getBalanceGraphDisplayValue(String accountNumber,
            String branchNumber) {

		// ABAのエンドユーザーログインを認証する
		String jbaIdToken = RequestHeaderContext.getInstance().getJbaIdToken();

		if (!redisHandler.exists(jbaIdToken)) {
			// TODO エラー未定
			return null;
		}

		// redisからJBAIDを取得する
		String jbaId = redisHandler.get(jbaIdToken);

		// 収支グラフ情報ABAリクエストDTO
		BalanceGraphAbaRequestDto abaRequestDto = new BalanceGraphAbaRequestDto();

		// 口座番号設定
		abaRequestDto.setAccountNumber(accountNumber);
		// 店番
		abaRequestDto.setBranchNumber(branchNumber);
		// 顧客ID
		abaRequestDto.setCustomerId(jbaId);

		// 収支グラフ情報取得
		BalanceGraphAbaResponseDto abaResponseDto = new BalanceGraphAbaResponseDto();

		try {

			// 収支グラフ情報取得
			abaResponseDto = electronicPassbookLogic.getBalanceGraphInfomation(abaRequestDto);

		} catch (Exception e) {

			throw new NotFoundException();
		}

		// エラーチェックを行う
		errorCheck(abaResponseDto.getCommonResponseHeader());

		// 収支情報レスポンスDTOリスト
		List<BalanceGraphResponseDto> responseDtoList = new ArrayList<>();

		// 収支情報DTOリスト
		List<BalanceGraphDto> balanceGraphDtoList = abaResponseDto.getBalanceGraphAbaResponseBody()
				.getBalanceInfoList();
		if (balanceGraphDtoList != null && balanceGraphDtoList.size() > 0) {

			for (BalanceGraphDto balanceGraphAbaResponseDto : balanceGraphDtoList) {

				// 収支情報レスポンスDTO
				BalanceGraphResponseDto responseDto = new BalanceGraphResponseDto();

				BeanUtils.copyProperties(balanceGraphAbaResponseDto, responseDto);

				// 収支情報DTOリスト追加
				responseDtoList.add(responseDto);
			}
		}

		return responseDtoList;
	}

	/**
	 * 抽選状態更新
	 *
	 * @param requestDto 抽選状態BFFリクエストDTO
	 * @return 処理結果
	 */
	@Override
	public String lotteryStatusUpdate(LotteryStatusRequestDto requestDto) {

		// TODO 抽選状態API未定
		redisHandler.set("lotteryStatus", requestDto.getStatus());

		return "OK";
	}

	/**
	 * エラーチェック
	 *
	 * @param commonResponseHeader 共通レスポンスerrorCheckヘッダー
	 */
	private void errorCheck(CommonResponseHeader commonResponseHeader) {

		if (Objects.nonNull(commonResponseHeader) && StringUtils.isNotEmpty(commonResponseHeader.getErrorCode())) {

			// TODO 異常コード待ち
			throw new NotFoundException();
		}
	}
}

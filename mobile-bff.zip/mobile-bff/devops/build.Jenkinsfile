def gitTag 
def gitCommitID
def pomVersion
def imageName
def imageTag

pipeline {
    agent any

    environment {
        GIT_REPO_MANIFEST = 'yjb-mobile-bff'  
        GIT_USER_NAME = 'JSBank Cloud Mgr'
        GIT_USER_EMAIL = 'EBB1XCP@jp.ibm.com'
        ICCR_NAMESPACE = 'cr-yjb-d-01'
    }

    stages {

        stage('Get Parameter') {
            steps {
                dir("mobile-bff") {
                    script {
                        def MDL = readMavenPom(file: 'pom.xml')
                        pomVersion = MDL.getVersion()
                        //imageTag = sh(returnStdout: true, script: "date +%s%N | md5sum | head -c 5").trim()
                        gitTag = "v" + "${pomVersion}" + "-" + "${BUILD_NUMBER}"
                        gitCommitID = sh(returnStdout: true, script: "git rev-parse --short HEAD").trim()
                    }
                }
                echo 'version: ' + pomVersion
                echo 'gitTag: ' + gitTag
                echo 'gitCommitID: ' + gitCommitID
            }
        }
        
        stage('Test & Build') {
            steps {
                dir("mobile-bff") {
                    sh "mvn -Dmaven.repo.local=${WORKSPACE}/repo clean package"
                }
            }
        }

        // stage('SonarQube Analysis') {
        //     steps {
        //         withCredentials([string(credentialsId: 'sonarqube-token', variable: 'SQ_TOKEN')]) {
        //             sh "sonar-scanner -Dsonar.login=${SQ_TOKEN} -Dproject.settings=devops/sonar-project.properties"
        //         }
        //     }
        // }

        stage('Login to IBM Cloud & Setup') {
            steps {
                    sh "ibmcloud config --check-version=false"

                    withCredentials([string(credentialsId: 'IBMCloud-API-Key', variable: 'API_KEY')]) {
                        sh "ibmcloud login --apikey " + "${API_KEY}" + " -r jp-tok"
                    }
                    sh "ibmcloud plugin install container-registry -f"
                    sh "ibmcloud plugin install container-service -f"
                    sh "ibmcloud cr login"
            }
        }

        stage('Source to Image') {
            steps {
                dir("mobile-bff") {
                    script{
                        imageName = "${env.GIT_REPO_MANIFEST}-main" 
                        imageTag = "${gitCommitID}"
                        iccrNameSpace = "${env.ICCR_NAMESPACE}"
                    }
                    sh "docker build -t " + "jp.icr.io/" + iccrNameSpace + "/" + imageName + ":" + imageTag + " -f Dockerfile ."
                }
            }
        }

        stage('Push Image to ICCR') {
            steps {
                    sh "docker push " + "jp.icr.io/" + iccrNameSpace + "/"  + imageName + ":" + imageTag
                    sh "docker rmi " + "jp.icr.io/" + iccrNameSpace + "/"  + imageName + ":" + imageTag
            }
        }

        //仮設定
        stage('Manifest Git Clone') {
            steps {
                dir('devops') {
                    git branch: 'master', credentialsId: 'gitlab_access_token', url: 'https://jp-tok.git.cloud.ibm.com/jsb-banking-app/cicd_test/manifest-mobile.git'
                    sh 'ls -al'
                }
            }
        }

        stage('Deploy') {
            steps {
                    sh "ibmcloud ks cluster config -c roks-dsp-app-01"
                    withCredentials([string(credentialsId: 'IBMCloud-API-Key', variable: 'API_KEY')]) {
                        sh "oc login -u apikey -p " + "${API_KEY}"
                    }
                    
                dir("devops") {
                    script {
                        deployYaml = 'yjb-deploy-mobile-bff.yaml'
                    }
                    sh "sed -i -e 's|image: jp.icr.io/" + iccrNameSpace + "/" + imageName + ".*|image: jp.icr.io/" + iccrNameSpace + "/" + imageName + ":" + imageTag + "|g' " + deployYaml
                    sh "oc apply -f " + deployYaml
                }    

            }
        }

        // stage('Source Code Git Tag') {
        //     steps {
        //        withCredentials([string(credentialsId: 'Gitlab-Source-Token', variable: 'GL_TOKEN')]) {
        //             sh "curl --request POST --header 'PRIVATE-TOKEN:" + "${GL_TOKEN}" + "' 'https://jp-tok.git.cloud.ibm.com/api/v4/projects/jsb-banking-app/" + "${env.GIT_REPO_MANIFEST}}" + "/repository/tags?tag_name=" + "${gitTag}" + "&ref=main'"
        //        }
        //     }
        // }

        // stage('Manifest Git Clone') {
        //     steps {
        //         dir("./") {
        //             sh "rm -rf " + "${env.GIT_REPO_MANIFEST}"                    
        //             sh "git config --global user.name '" + "${env.GIT_USER_NAME}" + "'"
        //             sh "git config --global user.email " + "${env.GIT_USER_EMAIL}"

        //             withCredentials([string(credentialsId: 'Github-Manifest-Token', variable: 'GH_TOKEN')]) {
        //                 sh "git remote set-url origin https://" + "${env.GIT_USER_NAME}" + ":" + "${GH_TOKEN}" + "@jp-tok.git.cloud.ibm.com:jsb-banking-app/" + "${env.GIT_REPO_MANIFEST}" + ".git"
        //                 sh "git clone https://" + "${env.GIT_USER_NAME}" + ":" + "${GH_TOKEN}" + "@jp-tok.git.cloud.ibm.com:jsb-banking-app/" + "${env.GIT_REPO_MANIFEST}" + ".git"
        //             }
        //         }
        //     }
        // }

        // stage('Edit Manifest') {
        //     steps {
        //         dir("./" + "${env.GIT_REPO_MANIFEST}") {
        //             sh "sed -i -e 's|image: private.jp.icr.io/" + iccrNameSpace + "/" + imageName + ".*|image: private.jp.icr.io/" + iccrNameSpace + "/" + imageName + ":" + imageTag + "|g' ./deploy.yaml"
        //         }
        //     }
        // }

        // stage('Manifest Git Push') {
        //     steps {
        //         dir("./" + "${env.GIT_REPO_MANIFEST}") {
        //             sh "git add ./k8s/deploy.yaml"
        //             sh 'git commit -m "Update Tag" --allow-empty'
        //             sh "git push -u origin master"
        //         }
        //     }
        // }

    }

    post {
       
        success {
            slackSend(
                color: '#42FF42',
                message: "*ビルド成功* \n" + 
                "Git Source: " + "${env.GIT_URL} \n" + 
                "Git Tag: " + gitTag + "\n" +
                "Image: " + imageName+ ":" + imageTag
            )
        }

        failure {
                slackSend(
                color: '#FF4242',
                message: "*ビルド失敗* \n" + 
                "Git Source: " + "${env.GIT_URL} \n" + 
                "Git Tag: " + gitTag + "\n" +
                "Image: " + imageName+ ":" + imageTag
            )
        }

        cleanup {
            cleanWs()
        }
       
    }


}

package jp.co.jsbank.mb.bankingapp.system

/**
 * システム設定.
 */
object Config {
    // REALM DB名
    const val REALM_DB_NAME = "myRealm.realm"

    // アプリ認証：個人向け
    private const val APP_ID_RETAIL = "JBA-Retail"

    // アプリ認証：法人向け
    private const val APP_ID_BIZZ = "JBA-Bizz"

    // アプリ認証区分（0：個人　1：法人）
    private const val APP_TYPE = "0"

    // グーグル
    // com.android.vending
    const val GOOGLE_PLAY = "com.android.vending"

    // デフォルト接続の設定
//    const val BASE_URL = "http://172.25.0.96:9090"
//    const val BASE_URL = "http://jag-gateway-service-ops-jag-gateway." +
//        "mycluster-jp-tok-1-430553-06f3cfc58a58986a2f2ce380e01e4d99-0000.jp-tok.containers.appdomain.cloud"
    //const val BASE_URL = "https://api.mb-dev.jsbank.co.jp"
    const val BASE_URL = "https://api.mb-dev.jsbank.co.jp"

    fun getAppId(): String {
        return if (isRetail()) APP_ID_RETAIL else APP_ID_BIZZ
    }

    fun isRetail(): Boolean {
        return when (APP_TYPE) {
            "0" -> true
            else -> {
                false
            }
        }
    }

    // 試行回数
    const val TRY_COUNT = 5

    // 端末種別
    const val OS_TYPE = "1"

    // トップ情報リフレッシュ間隔
    const val TOP_INFO_REFRESH_INTERVAL: Long = 1000

    /** JWT  */
    const val JAG_JWT_DEF_ISSUER = "JAG"
    const val JAG_JWT_DEF_PROFILE_CUSTOME_CLAIM_PAYLOAD = "jagPayLoad"
    const val JAG_JWT_DEF_TRAILER_CUSTOME_CLAIM_BFF_HEADER = "jagBffHeader"
    const val JAG_JWT_DEF_TRAILER_CUSTOME_CLAIM_BFF_BODY = "jagBffBody"
    const val JAG_DEF_10MINS_MILLIES_SECONDS = 600000
}

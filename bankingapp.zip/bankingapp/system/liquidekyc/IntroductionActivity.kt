package jp.co.jsbank.mb.bankingapp.system.liquidekyc

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.KeyEvent
import android.view.ViewStub
import androidx.annotation.NonNull
import androidx.annotation.Nullable
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentTransaction
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.fragment.IntroductionFirstFragment
import jp.co.jsbank.mb.bankingapp.fragment.IntroductionSecondFragment
import jp.co.jsbank.mb.bankingapp.fragment.IntroductionSelectFragment

/**
 * イントロダクション画面のレイアウト確認用のアクティビティです.
 */
class IntroductionActivity : AppCompatActivity(), BundleKeyDefinitions {
    /**
     * イントロダクションの順序.
     */
    enum class IntroductionType {
        FIRST, SECOND, SELECT
    }

    override fun onCreate(@Nullable savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        instance = this
        setContentView(R.layout.activity_introduction)
        setFragment()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK && (event?.repeatCount ?: 0) == 0) {
            return false
        }
        return super.onKeyDown(keyCode, event)
    }

    /**
     * 対象するイントロダクション画面を設定します.
     */
    private fun setFragment() {
        val intent: Intent = intent
        val type = intent.getSerializableExtra(KEY_INTRODUCTION_TYPE) as IntroductionType?
        val arguments = Bundle()
        val fragment: Fragment = getFragment(type)
        fragment.arguments = arguments
        val fragmentTransaction: FragmentTransaction = supportFragmentManager.beginTransaction()
        fragmentTransaction.replace(R.id.introduction_container, fragment).commit()
        val progressView: ViewStub = findViewById(R.id.progress_layout)
        progressView.layoutResource = R.layout.document_progress_view
        progressView.inflate()
    }

    /**
     * 対象するイントロダクション画面を取得します.
     *
     * @param type イントロダクション画面の種類
     */
    private fun getFragment(@NonNull type: IntroductionType?): Fragment {
        if (type == IntroductionType.FIRST) {
            return IntroductionFirstFragment()
        }
        return if (type == IntroductionType.SELECT) {
            IntroductionSelectFragment()
        } else IntroductionSecondFragment()
    }

//    override fun onBackPressed() {
//        ReturnDestinationConfirmer.execute(this) // ホーム画面へ戻ります
//    }

    companion object {
        @SuppressLint("StaticFieldLeak")
        var instance: Activity? = null

        /**
         * イントロダクションユニークキー.
         */
        const val KEY_INTRODUCTION_TYPE = "key_introduction_type"
    }
}

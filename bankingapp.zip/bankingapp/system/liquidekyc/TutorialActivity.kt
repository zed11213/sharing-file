//package jp.co.jsbank.mb.bankingapp.system.liquidekyc
//
//import android.Manifest
//import android.annotation.SuppressLint
//import android.app.Activity
//import android.content.pm.PackageManager
//import android.graphics.Bitmap
//import android.os.Bundle
//import android.util.Log
//import android.view.KeyEvent
//import androidx.annotation.NonNull
//import androidx.annotation.Nullable
//import androidx.appcompat.app.AppCompatActivity
//import androidx.core.content.ContextCompat
//import androidx.fragment.app.Fragment
//import androidx.fragment.app.FragmentManager
//import androidx.fragment.app.FragmentTransaction
//import jp.co.jsbank.mb.bankingapp.R
//import jp.co.jsbank.mb.bankingapp.fragment.DocumentCaptureProgressAreaFragment
//import jp.co.jsbank.mb.bankingapp.fragment.DocumentFrontCaptureTutorialFragment
//import jp.co.jsbank.mb.bankingapp.utils.PreferenceManagerUtil
//
//
///**
// * チュートリアル画面のレイアウト確認用のアクティビティです.
// */
//class TutorialActivity : AppCompatActivity(), BundleKeyDefinitions {
//    /**
//     * 照合用 ID.
//     * 起動インテントに含まれています。
//     */
//    @get:Nullable
//    @Nullable
//    var matchingIDResult: GetMatchingIDResult? = null
//        get() {
//            if (field == null) {
//                field = PreferenceManagerUtil.getGetMatchingIDResult(this, APP_KEY_MATCHING_ID_RESULT)
//            }
//            return field
//        }
//        private set
//
//    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
//        if (keyCode == KeyEvent.KEYCODE_BACK && (event?.repeatCount ?: 0) == 0) {
//            return false
//        }
//        return super.onKeyDown(keyCode, event)
//    }
//
//    override fun onBackPressed() {
////        super.onBackPressed()
//    }
//
//    override fun onCreate(@Nullable savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
////        instance = this
//        setContentView(R.layout.activity_tutorial)
//        if (savedInstanceState == null) {
//            clearImages()
//            setFragment()
//        } else {
//            Log.w(TAG, "TutorialActivity is recreated")
//
//            // POLA_ANDROID-940 撮影中カメラ権限変更、また不明原因で画面再起動した場合、トップ画面へ遷移します。
//            val errorResult: ErrorResult = if (ContextCompat.checkSelfPermission(
//                    this, Manifest.permission.CAMERA
//                ) !== PackageManager.PERMISSION_GRANTED
//            ) {
//                ErrorResult.UNAUTHORIZED_CAMERA_PERMISSION_ERROR
//            } else {
//                ErrorResult.UNEXPECTED_ERROR
//            }
////            ReturnDestinationConfirmer.execute(this, errorResult)
//        }
//    }
//
//    /**
//     * 画像イメージをクリアします.
//     */
//    private fun clearImages() {
//        recycleBitmap(frontFullImage)
//        frontFullImage = null
//        recycleBitmap(Companion.frontDocumentImage)
//        Companion.frontDocumentImage = null
//        recycleBitmap(Companion.frontCorrectedImage)
//        Companion.frontCorrectedImage = null
//        recycleBitmap(tiltedFullImage)
//        tiltedFullImage = null
//        recycleBitmap(Companion.tiltedDocumentImage)
//        Companion.tiltedDocumentImage = null
//        recycleBitmap(Companion.tiltedCorrectedImage)
//        Companion.tiltedCorrectedImage = null
//        recycleBitmap(backFullImage)
//        backFullImage = null
//        recycleBitmap(Companion.backDocumentImage)
//        Companion.backDocumentImage = null
//        recycleBitmap(Companion.selfieImage)
//        Companion.selfieImage = null
//        recycleBitmap(Companion.livenessImage)
//        Companion.livenessImage = null
//    }
//
//    /**
//     * ビットマップのリサイクルを行います.
//     *
//     * @param bitmap リサイクル対象のビットマップ
//     */
//    private fun recycleBitmap(@Nullable bitmap: Bitmap?) {
//        if (bitmap != null && !bitmap.isRecycled) {
//            bitmap.recycle()
//        }
//    }
//
//    /**
//     * フラグメントの設定を行います.
//     */
//    private fun setFragment() {
//        val manager: FragmentManager = supportFragmentManager
//        val fragment: Fragment = DocumentFrontCaptureTutorialFragment() // 次に表示するフラグメントを取得
//        val progressAreaFragment: Fragment = DocumentCaptureProgressAreaFragment()
//        val transaction: FragmentTransaction = manager.beginTransaction() // フラグメント切り替えトランザクションの取得
//        transaction.replace(R.id.fragment_container, fragment)
//        transaction.replace(R.id.progress_container, progressAreaFragment)
//        transaction.commit()
//    }
//
//    /**
//     * 書類表撮影フラグメントから撮影結果の通知を行います.
//     *
//     * @param result 撮影結果
//     */
//    fun notifyFrontImages(@NonNull result: DocumentResult) {
//        if (frontFullImage != null && !frontFullImage!!.isRecycled) {
//            Log.d(TAG, "recycle old frontFullImage")
//            frontFullImage!!.recycle()
//        }
//        frontFullImage = result.fullImage // 書類表の全体画像
//        if (Companion.frontDocumentImage != null && !Companion.frontDocumentImage!!.isRecycled) {
//            Log.d(TAG, "recycle old frontDocumentImage")
//            Companion.frontDocumentImage!!.recycle()
//        }
//        Companion.frontDocumentImage = result.documentImage // 書類表の切り出し画像
//        if (Companion.frontCorrectedImage != null && !Companion.frontCorrectedImage!!.isRecycled) {
//            Log.d(TAG, "recycle old frontCorrectedImage")
//            Companion.frontCorrectedImage!!.recycle()
//        }
//        Companion.frontCorrectedImage = result.correctedImage // 書類表の補正後画像
//    }
//
//    /**
//     * 書類斜め撮影フラグメントから撮影結果の通知を行います.
//     *
//     * @param result 撮影結果
//     */
//    fun notifyTiltedImages(@NonNull result: DocumentResult) {
//        if (tiltedFullImage != null && !tiltedFullImage!!.isRecycled) {
//            Log.d(TAG, "recycle old tiltedFullImage")
//            tiltedFullImage!!.recycle()
//        }
//        tiltedFullImage = result.fullImage // 書類斜めの全体画像
//        if (Companion.tiltedDocumentImage != null && !Companion.tiltedDocumentImage!!.isRecycled) {
//            Log.d(TAG, "recycle old tiltedDocumentImage")
//            Companion.tiltedDocumentImage!!.recycle()
//        }
//        Companion.tiltedDocumentImage = result.documentImage // 書類斜めの切り出し画像
//        if (Companion.tiltedCorrectedImage != null && !Companion.tiltedCorrectedImage!!.isRecycled) {
//            Log.d(TAG, "recycle old tiltedCorrectedImage")
//            Companion.tiltedCorrectedImage!!.recycle()
//        }
//        Companion.tiltedCorrectedImage = result.correctedImage // 書類斜めの補正後画像
//    }
//
//    /**
//     * 書類裏撮影フラグメントから撮影結果の通知を行います.
//     *
//     * @param result 撮影結果
//     */
//    fun notifyBackImages(@NonNull result: DocumentResult) {
//        if (backFullImage != null && !backFullImage!!.isRecycled) {
//            Log.d(TAG, "recycle old backFullImage")
//            backFullImage!!.recycle()
//        }
//        backFullImage = result.fullImage // 書類裏の全体画像
//        if (Companion.backDocumentImage != null && !Companion.backDocumentImage!!.isRecycled) {
//            Log.d(TAG, "recycle old backDocumentImage")
//            Companion.backDocumentImage!!.recycle()
//        }
//        Companion.backDocumentImage = result.documentImage // 書類裏の切り出し画像
//    }
//
//    /**
//     * 書類表の書類部分を切り出した画像を取得します.
//     *
//     * @return 取得した書類画像
//     */
//    @get:Nullable
//    val frontDocumentImage: Bitmap?
//        get() = Companion.frontDocumentImage
//
//    /**
//     * 書類表の書類部分の補正処理を行った画像を取得します.
//     *
//     * @return 取得した補正後書類画像
//     */
//    @get:Nullable
//    val frontCorrectedImage: Bitmap?
//        get() = Companion.frontCorrectedImage
//
//    /**
//     * 書類表の書類部分を切り出した画像を取得します.
//     *
//     * @return 取得した書類画像
//     */
//    @get:Nullable
//    val tiltedDocumentImage: Bitmap?
//        get() = Companion.tiltedDocumentImage
//
//    /**
//     * 書類斜めの書類部分の補正処理を行った画像を取得します.
//     *
//     * @return 取得した補正後書類画像
//     */
//    @get:Nullable
//    val tiltedCorrectedImage: Bitmap?
//        get() = Companion.tiltedCorrectedImage
//
//    /**
//     * 書類裏の書類部分を切り出した画像を取得します.
//     *
//     * @return 取得した書類画像
//     */
//    @get:Nullable
//    val backDocumentImage: Bitmap?
//        get() = Companion.backDocumentImage
//
//    /**
//     * セルフィー画像を取得します.
//     *
//     * @return 取得したセルフィー画像
//     */
//    @get:Nullable
//    val selfieImage: Bitmap?
//        get() = Companion.selfieImage
//
//    /**
//     * まばたき画像を取得します.
//     *
//     * @return 取得したまばたき画像
//     */
//    @get:Nullable
//    val livenessImage: Bitmap?
//        get() = Companion.livenessImage
//
//    companion object {
//        /**
//         * ログのタグ.
//         */
//        private val TAG = TutorialActivity::class.java.name
//
//        /**
//         * 書類表全体画像.
//         * DocumentFrontCaptureTutorialFragment が取得して当アクティビティに設定します。
//         */
//        @Nullable
//        private var frontFullImage: Bitmap? = null
//
//        /**
//         * 書類表切り出し画像.
//         * DocumentFrontCaptureTutorialFragment が取得して当アクティビティに設定します。
//         */
//        @Nullable
//        private var frontDocumentImage: Bitmap? = null
//
//        /**
//         * 書類表補正後画像.
//         * DocumentFrontCaptureTutorialFragment が取得して当アクティビティに設定します。
//         */
//        @Nullable
//        private var frontCorrectedImage: Bitmap? = null
//
//        /**
//         * 書類斜め全体画像.
//         * DocumentFrontCaptureTutorialFragment が取得して当アクティビティに設定します。
//         */
//        @Nullable
//        private var tiltedFullImage: Bitmap? = null
//
//        /**
//         * 書類斜め切り出し画像.
//         * DocumentFrontCaptureTutorialFragment が取得して当アクティビティに設定します。
//         */
//        @Nullable
//        private var tiltedDocumentImage: Bitmap? = null
//
//        /**
//         * 書類斜め補正後画像.
//         * DocumentFrontCaptureTutorialFragment が取得して当アクティビティに設定します。
//         */
//        @Nullable
//        private var tiltedCorrectedImage: Bitmap? = null
//
//        /**
//         * 書類裏全体画像.
//         * DocumentFrontCaptureTutorialFragment が取得して当アクティビティに設定します。
//         */
//        @Nullable
//        private var backFullImage: Bitmap? = null
//
//        /**
//         * 書類裏切り出し画像.
//         * DocumentFrontCaptureTutorialFragment が取得して当アクティビティに設定します。
//         */
//        @Nullable
//        private var backDocumentImage: Bitmap? = null
//
//        /**
//         * まばたき画像.
//         * SelfieTutorialFragment が取得して当アクティビティに設定します。
//         */
//        @Nullable
//        private var livenessImage: Bitmap? = null
//        fun setLivenessImage(@Nullable image: Bitmap?) {
//            if (livenessImage != null && !livenessImage!!.isRecycled) {
//                Log.d(TAG, "recycle old livenessImage")
//                livenessImage!!.recycle()
//            }
//            livenessImage = image
//        }
//
//        /**
//         * セルフィー画像.
//         * SelfieTutorialFragment が取得して当アクティビティに設定します。
//         */
//        @Nullable
//        private var selfieImage: Bitmap? = null
//        fun setSelfieImage(@Nullable image: Bitmap?) {
//            if (selfieImage != null && !selfieImage!!.isRecycled) {
//                Log.d(TAG, "recycle old selfieImage")
//                selfieImage!!.recycle()
//            }
//            selfieImage = image
//        }
//
//        @SuppressLint("StaticFieldLeak")
//        var instance: Activity? = null
//
//        // セルフ説明画面
//        var selfFlag = false
//
//        @JvmName("setSelfFlag1")
//        fun setSelfFlag(value: Boolean) {
//            selfFlag = value
//        }
//
//        // MBCO0405　読取結果
//        fun getResults() {
//            LiquidEkycActivity.close()
//            instance?.finish()
//        }
//    }
//}

package jp.co.jsbank.mb.bankingapp.system.liquidekyc

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.KeyEvent
import androidx.annotation.NonNull
import androidx.appcompat.app.AppCompatActivity
import asia.liquidinc.ekyc.applicant.LiquidSdk
import asia.liquidinc.ekyc.applicant.external.result.LiquidProcessingResultStatus
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.system.MyApp.Companion.CONTEXT
import jp.co.jsbank.mb.bankingapp.system.ekyc.BundleKeyDefinitions
import jp.co.jsbank.mb.bankingapp.system.ekyc.TutorialActivity
import jp.co.jsbank.mb.bankingapp.system.master.DocumentKind
import jp.co.jsbank.mb.bankingapp.system.master.EkycCard
import jp.co.jsbank.mb.bankingapp.utils.*

/**
 * 起動時の画面アクティビティです.
 */
class LiquidEkycActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        if (savedInstanceState == null) {

//            // EKYCサーバー初期化
//            getMatchingID()

            // 書類種別の設定
            setCaptureConfig()

            // 画面初期化
            setFragment()
        }

        // PolarifyKycSdk の初期設定
//        val factory = PolarifyKycSdkFactory()
//        factory.getInstance(this)
        var url = "https://applicantsdk-api.stg-liquid-ekyc.com"
        var apikey = "JDJhJDEwJHg4cFdYU2pUSGx5Zy9hRkEzclkxbC5WWEtCUjZWUTNZTmdYTm9MVlBBZ2Y3b1JsRXAwM2w2"
//        初期化ファンクションの呼び出し
//        LiquidSdk.getInstance(applicationContext).startVerify(url, String, token)

        LiquidSdk.getInstance(this).startVerify(url, apikey) { liquidProcessingResult ->
            when (liquidProcessingResult.result) {
                LiquidProcessingResultStatus.SUCCESS -> {
                    // 正常時の処理
                    Log.i("ekyc","success")
                }
                LiquidProcessingResultStatus.ERROR -> {

                    Log.i("ekyc","error")
                }
//                LiquidProcessingResultStatus.・・・ -> {
//                // 個別にハンドリングしたい「処理結果」返却時の処理
//                }
                else -> {
                    // 個別にハンドリングしなかった「処理結果」返却時の処理
                }
            }
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK && (event?.repeatCount ?: 0) == 0) {
            return false
        }
        return super.onKeyDown(keyCode, event)
    }

    /**
     * 自動/手動と書類種別の設定を行います.
     */
    private fun setCaptureConfig() {
        PreferenceManagerUtil.putBoolean(CONTEXT, BundleKeyDefinitions.APP_KEY_IS_MANUAL, true)
        PreferenceManagerUtil.putBoolean(CONTEXT, BundleKeyDefinitions.APP_KEY_USER_CANCEL, false)

        // マイナンバー
        if (PreferenceUtil.getPreferenceStringValue(ConstUtil.EKYC_CARD_TYPE) == EkycCard.MEMBER.toString()) {
            PreferenceManagerUtil.putInt(
                CONTEXT,
                BundleKeyDefinitions.APP_KEY_CAPTURE_KIND,
                DocumentKind.MY_NUMBER_CARD_OCR.ordinal
            )
        } else {
            PreferenceManagerUtil.putInt(
                CONTEXT,
                BundleKeyDefinitions.APP_KEY_CAPTURE_KIND,
                DocumentKind.DRIVER_LICENSE_CARD_OCR.ordinal
            )
        }
    }

    /**
     * チュートリアル画面を設定します.
     */
    private fun setFragment() {
//        val intent = Intent(CONTEXT, TutorialActivity::class.java)
//        startActivity(intent)
    }

    companion object {

        @SuppressLint("StaticFieldLeak")
        var instance: Activity? = null

        fun close() {
            MainActivity.IS_EKYC_BACK_FLAG = true
            val intent = Intent()
            intent.setClass(CONTEXT, MainActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            CONTEXT.startActivity(intent)
            instance?.finish()
        }
    }
}

package jp.co.jsbank.mb.bankingapp.system.liquidekyc

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.util.Log
import asia.liquidinc.ekyc.applicant.LiquidSdk
import asia.liquidinc.ekyc.applicant.external.DisplayLanguage
import asia.liquidinc.ekyc.applicant.external.FaceVerificationType
import asia.liquidinc.ekyc.applicant.external.IdentifyIdChipParameters
import asia.liquidinc.ekyc.applicant.external.LiquidDocumentType
import asia.liquidinc.ekyc.applicant.external.LiquidDocumentTypeJpki
import asia.liquidinc.ekyc.applicant.external.TermsOfUseSettings
import asia.liquidinc.ekyc.applicant.external.VerificationMethod
import asia.liquidinc.ekyc.applicant.external.VerificationMethodJpki
import asia.liquidinc.ekyc.applicant.external.VerifyFaceParameters
import asia.liquidinc.ekyc.applicant.external.VerifyIdChipParameters
import asia.liquidinc.ekyc.applicant.external.result.LiquidProcessingResultStatus
import asia.liquidinc.ekyc.applicant.external.result.chip.ChipIdentificationResultStatus
import asia.liquidinc.ekyc.applicant.external.result.chip.ChipVerificationResultStatus
import asia.liquidinc.ekyc.applicant.external.result.chip.LiquidChipData
import asia.liquidinc.ekyc.applicant.external.result.chip.MynaIdentificationResultStatus
import asia.liquidinc.ekyc.applicant.external.result.chip.Sex
import asia.liquidinc.ekyc.applicant.external.result.face.FaceVerificationResultStatus
import jp.co.jsbank.mb.bankingapp.system.ekyc.BundleKeyDefinitions
import jp.co.jsbank.mb.bankingapp.system.master.DocumentKind
import jp.co.jsbank.mb.bankingapp.system.master.EkycCard
import jp.co.jsbank.mb.bankingapp.system.master.EkycResult
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil
import jp.co.jsbank.mb.bankingapp.utils.PreferenceManagerUtil
import jp.co.jsbank.mb.bankingapp.utils.PreferenceUtil
import jp.co.jsbank.mb.bankingapp.utils.RouteUtil
import jp.co.jsbank.mb.bankingapp.utils.bitmapToBase64

class LiquidEkycHelper(private val activity: Activity) {

    var onSorryDialog: ((message: String) -> Unit)? = null

    private var documentType = ""
    private var verifyType = ""
    private var liquidSdk: LiquidSdk? = null

    fun startEkycFlow() {
        Log.i("ekyc", "startEkycFlow in LiquidEkycHelper taskId=${activity.taskId}")
        val applicantId: String? = PreferenceUtil.getPreferenceStringValue(ConstUtil.LIQUID_EKYC_APPLICANT_ID)
        val token: String? = PreferenceUtil.getPreferenceStringValue(ConstUtil.LIQUID_EKYC_TOKEN)
        liquidSdk = LiquidSdk.getInstance(activity)
        liquidSdk?.startVerify(ConstUtil.EKYC_URL, applicantId.toString(), token.toString())
        liquidSdk?.changeDisplayLanguage(DisplayLanguage.JAPANESE)

        documentType = PreferenceUtil.getPreferenceStringValue(ConstUtil.EKYC_CARD_TYPE).toString()
        verifyType = documentType
        Log.i("ekyc", "document type: $documentType")

        val termSuccessFlg = PreferenceUtil.getPreferenceBooleanValue(ConstUtil.EKYC_TERM_SUCCESS)
        setCaptureConfig()

        if (termSuccessFlg) {
            if (documentType == EkycCard.MEMBER.toString()) {
                verifyFace()
            } else {
                verifyIdChip()
            }
        } else {
            showTerms()
        }
    }

    fun handleActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        Log.i("ekyc", "handleActivityResult: requestCode=$requestCode, resultCode=$resultCode")
        val sdk = liquidSdk ?: return

        sdk.handleShowTermsOfUseResult(requestCode, resultCode, data) { result ->
            when (result.result) {
                LiquidProcessingResultStatus.SUCCESS -> {
                    PreferenceUtil.setPreferenceBooleanValue(ConstUtil.EKYC_TERM_SUCCESS, true)
                    Log.i("ekyc", "term success")
                    if (documentType == EkycCard.MEMBER.toString()) verifyFace()
                    else verifyIdChip()
                }
                LiquidProcessingResultStatus.ERROR -> {
                    Log.i("ekyc", "term error: ${result.errorCode}")
                    showSorryDialog(result.errorCode)
                }
                LiquidProcessingResultStatus.COMMUNICATION_FAILURE,
                LiquidProcessingResultStatus.SESSION_TIMEOUT -> {
                    Log.i("ekyc", "term communication failure: ${result.result}, ${result.errorCode}")
                    PreferenceUtil.removePreferenceStringValue(ConstUtil.LIQUID_EKYC_TOKEN)
                    PreferenceUtil.removePreferenceStringValue(ConstUtil.LIQUID_EKYC_APPLICANT_ID)
                    showSorryDialog(result.errorCode)
                }
                else -> Log.i("ekyc", "term other")
            }
        }

        sdk.handleFaceVerificationResult(requestCode, resultCode, data) { result ->
            when (result.resultStatus) {
                FaceVerificationResultStatus.SUCCESS -> {
                    Log.i("ekyc", "face success")
                    if (verifyType == EkycCard.MEMBER.toString()) {
                        identifyIdChip()
                    } else {
                        PreferenceUtil.setPreferenceStringValue(ConstUtil.EKYC_RESULT, EkycResult.OK.code)
                        RouteUtil.navTo(RouteName.MBCO0405Page)
                    }
                }
                FaceVerificationResultStatus.ERROR -> {
                    Log.i("ekyc", "face error: ${result.errorCode}")
                    showSorryDialog(result.errorCode)
                }
                else -> Log.i("ekyc", "face other")
            }
        }

        sdk.handleMynaIdentificationResult(requestCode, resultCode, data) { result ->
            when (result.resultStatus) {
                MynaIdentificationResultStatus.SUCCESS -> {
                    saveData(result.liquidChipData)
                    PreferenceUtil.setPreferenceStringValue(ConstUtil.EKYC_RESULT, EkycResult.OK.code)
                    Log.i("ekyc", "公的個人認証(スマホJPKI) success")
                    RouteUtil.navTo(RouteName.MBCO0405Page)
                }
                MynaIdentificationResultStatus.ERROR -> {
                    Log.i("ekyc", "公的個人認証(スマホJPKI) error: ${result.errorCode}")
                    when (result.errorCode) {
                        "SE22001", "SE99998", "SE25011" -> showSorryDialog(result.errorCode)
                        "SE24001", "SE20001", "SE25001", "SE21205" -> switchDriverVerify()
                        else -> showSorryDialog(result.errorCode)
                    }
                }
                else -> Log.i("ekyc", "公的個人認証(スマホJPKI) other")
            }
        }

        sdk.handleChipVerificationResult(requestCode, resultCode, data) { result ->
            when (result.resultStatus) {
                ChipVerificationResultStatus.SUCCESS -> {
                    saveData(result.liquidChipData)
                    Log.i("ekyc", "ic card success")
                    verifyFace()
                }
                ChipVerificationResultStatus.ERROR -> {
                    Log.i("ekyc", "ic card error: ${result.errorCode}")
                    showSorryDialog(result.errorCode)
                }
                else -> Log.i("ekyc", "ic card other")
            }
        }

        sdk.handleChipIdentificationResult(requestCode, resultCode, data) { result ->
            when (result.resultStatus) {
                ChipIdentificationResultStatus.SUCCESS -> {
                    Log.i("ekyc", "公的個人認証ファンクション success")
                    saveData(result.liquidChipData)
                    PreferenceUtil.setPreferenceStringValue(ConstUtil.EKYC_RESULT, EkycResult.OK.code)
                    RouteUtil.navTo(RouteName.MBCO0405Page)
                }
                ChipIdentificationResultStatus.ERROR -> {
                    Log.i("ekyc", "公的個人認証ファンクション error: ${result.errorCode}")
                    when (result.errorCode) {
                        "SE24001", "SE20001", "SE25001", "SE21205" -> switchDriverVerify()
                        else -> showSorryDialog(result.errorCode)
                    }
                }
                else -> {
                    Log.i("ekyc", "公的個人認証ファンクション other, errorCode=${result.errorCode}")
                    if (result.errorCode == "SE24001") {
                        verifyType = EkycCard.DRIVER.toString()
                        verifyIdChipNumberCard()
                    }
                }
            }
        }
    }

    private fun showTerms() {
        val termSetting = TermsOfUseSettings.Builder()
            .setHeaderFontColor(Color.parseColor("#000000"))
            .setScreenBgColor(Color.parseColor("#ffffff"))
            .setPrefaceFontColor(Color.parseColor("#333333"))
            .setButtonInactiveBgColor(Color.parseColor("#dddddd"))
            .setButtonActiveBgColor(Color.parseColor("#1bb0d1"))
            .setButtonFontColor(Color.parseColor("#ffffff"))
            .build()
        liquidSdk?.showTermsOfUse(termSetting, activity)
    }

    private fun verifyFace() {
        Log.i("ekyc", "verifyFace in LiquidEkycHelper")
        liquidSdk?.verifyFace(
            VerifyFaceParameters.Builder()
                .setShowReviewScreen(false)
                .setFaceVerificationType(FaceVerificationType.ACTIVE)
                .build(),
            activity
        )
    }

    private fun verifyIdChip() {
        Log.i("ekyc", "verifyIdChip in LiquidEkycHelper taskId=${activity.taskId}")
        liquidSdk?.verifyIdChip(
            VerifyIdChipParameters.Builder(LiquidDocumentType.DRIVER_LICENSE, VerificationMethod.COMPLY_HE).build(),
            activity
        )
    }

    private fun verifyIdChipNumberCard() {
        liquidSdk?.verifyIdChip(
            VerifyIdChipParameters.Builder(LiquidDocumentType.MY_NUMBER_CARD, VerificationMethod.COMPLY_HE)
                .setExcludeMyNumber(false)
                .setShowReviewScreen(false)
                .build(),
            activity
        )
    }

    private fun identifyIdChip() {
        liquidSdk?.identifyIdChip(
            IdentifyIdChipParameters.Builder()
                .setDocumentTypeJpki(LiquidDocumentTypeJpki.MY_NUMBER_CARD)
                .setVerificationMethodJpki(VerificationMethodJpki.FACE_JPKI)
                .setEnabledChipForgotPin(true)
                .setExcludeMyNumber(true)
                .build(),
            activity
        )
    }

    private fun switchDriverVerify() {
        Log.i("ekyc", "switch to driver verify")
        verifyType = EkycCard.DRIVER.toString()
        verifyIdChip()
    }

    private fun setCaptureConfig() {
        PreferenceManagerUtil.putBoolean(activity.applicationContext, BundleKeyDefinitions.APP_KEY_IS_MANUAL, true)
        PreferenceManagerUtil.putBoolean(activity.applicationContext, BundleKeyDefinitions.APP_KEY_USER_CANCEL, false)
        PreferenceManagerUtil.putInt(
            activity.applicationContext,
            BundleKeyDefinitions.APP_KEY_CAPTURE_KIND,
            DocumentKind.DRIVER_LICENSE_CARD_OCR.ordinal
        )
    }

    private fun saveData(liquidChipData: LiquidChipData?) {
        val address = liquidChipData?.address
        val addressPref = liquidChipData?.addressPref
        val addressCity = liquidChipData?.addressCity
        val addressOther = liquidChipData?.addressOther
        val birthday = liquidChipData?.birthday
        val sex = liquidChipData?.sex?.name
        val sexValue = liquidChipData?.sex?.ordinal
        val zipCode = liquidChipData?.zipCode
        val idNumber = liquidChipData?.idNumber
        val idFacePhoto = liquidChipData?.idFacePhoto?.let { bitmapToBase64(it) } ?: ""

        Log.d("ekyc", "=== LiquidChipData raw ===")
        Log.d("ekyc", "name: ${liquidChipData?.name}")
        Log.d("ekyc", "lastNameHalfWidthKanaCandidates: ${liquidChipData?.lastNameHalfWidthKanaCandidates}")
        Log.d("ekyc", "firstNameHalfWidthKanaCandidates: ${liquidChipData?.firstNameHalfWidthKanaCandidates}")
        Log.d("ekyc", "lastNameKanaCandidates: ${liquidChipData?.lastNameKanaCandidates}")
        Log.d("ekyc", "firstNameKanaCandidates: ${liquidChipData?.firstNameKanaCandidates}")
        Log.d("ekyc", "birthday: $birthday")
        Log.d("ekyc", "sex: $sex")
        Log.d("ekyc", "address: $address")
        Log.d("ekyc", "addressPref: $addressPref")
        Log.d("ekyc", "addressCity: $addressCity")
        Log.d("ekyc", "addressOther: $addressOther")
        Log.d("ekyc", "zipCode: $zipCode")
        Log.d("ekyc", "idNumber: $idNumber")
        Log.d("ekyc", "idFacePhoto: $idFacePhoto")
        Log.d("ekyc", "=======================")

        saveName(liquidChipData)

        PreferenceUtil.setPreferenceStringValue(ConstUtil.EKYC_INFO_BIRTHDATE, birthday ?: "")
        PreferenceUtil.setPreferenceStringValue(ConstUtil.EKYC_INFO_ADDRESS, address ?: "")
        PreferenceUtil.setPreferenceStringValue(ConstUtil.EKYC_INFO_ADDRESS1, addressPref ?: "")
        PreferenceUtil.setPreferenceStringValue(ConstUtil.EKYC_INFO_ADDRESS2, addressCity ?: "")
        PreferenceUtil.setPreferenceStringValue(ConstUtil.EKYC_INFO_ADDRESS3, addressOther ?: "")
        PreferenceUtil.setPreferenceStringValue(ConstUtil.EKYC_INFO_POSTALCODE, zipCode ?: "")
        PreferenceUtil.setPreferenceStringValue(ConstUtil.EKYC_INFO_GENDER, sex ?: Sex.OTHERS.name)
        PreferenceUtil.setPreferenceIntValue(ConstUtil.EKYC_INFO_GENDER_CODE, sexValue ?: Sex.OTHERS.ordinal)
        PreferenceUtil.setPreferenceStringValue(ConstUtil.EKYC_INFO_ID_NUMBER, idNumber ?: "")
        PreferenceUtil.setPreferenceBooleanValue(
            ConstUtil.EKYC_INFO_SHOW_GENDER,
            sex != null && sex != Sex.OTHERS.name
        )
        PreferenceUtil.setPreferenceStringValue(ConstUtil.EKYC_DOCUMENT_TYPE, verifyType)
        // ICカード顔画像
        PreferenceUtil.setPreferenceStringValue(ConstUtil.EKYC_IMAGE_FRONT, idFacePhoto)
    }

    private fun saveName(liquidChipData: LiquidChipData?) {
        val rawName = liquidChipData?.name
        var surnameStr: String? = null
        var firstNameStr: String? = null

        rawName?.let { name ->
            val bracketStart = name.indexOf('（')
            val bracketEnd = name.indexOf('）')
            if (bracketStart != -1 && bracketEnd != -1 && bracketEnd > bracketStart) {
                val kanjiPart = name.substring(bracketStart + 1, bracketEnd)
                val kanjiParts = kanjiPart.split("　")
                when {
                    kanjiParts.size >= 2 -> {
                        surnameStr = kanjiParts[0]
                        firstNameStr = kanjiParts[1]
                    }
                    kanjiParts.size == 1 -> {
                        surnameStr = kanjiParts[0]
                    }
                }
            }
            if (surnameStr == null || firstNameStr == null) {
                val slashIndex = name.indexOf('／')
                if (slashIndex != -1) {
                    val suffix = name.substring(slashIndex + 1).trim { it.isWhitespace() }
                    val parts = suffix.split("　")
                    when {
                        parts.size >= 2 -> {
                            surnameStr = surnameStr ?: parts[0]
                            firstNameStr = firstNameStr ?: parts[1]
                        }
                        parts.size == 1 -> {
                            surnameStr = surnameStr ?: parts[0]
                        }
                    }
                }
            }
            if (surnameStr == null || firstNameStr == null) {
                val parts = name.split("　")
                if (parts.size >= 2) {
                    surnameStr = parts[0]
                    firstNameStr = parts[1]
                }
            }
        }

        if (surnameStr == null || firstNameStr == null) {
            surnameStr = surnameStr
                ?: liquidChipData?.lastNameHalfWidthKanaCandidates?.firstOrNull()
                ?: liquidChipData?.lastNameKanaCandidates?.firstOrNull()
            firstNameStr = firstNameStr
                ?: liquidChipData?.firstNameHalfWidthKanaCandidates?.firstOrNull()
                ?: liquidChipData?.firstNameKanaCandidates?.firstOrNull()
        }

        if (surnameStr == null || firstNameStr == null) {
            rawName?.let { name ->
                val kanaPart: String = when {
                    name.indexOf('（') != -1 -> name.substring(0, name.indexOf('（')).trim { it.isWhitespace() }
                    name.indexOf('／') != -1 -> name.substring(0, name.indexOf('／')).trim { it.isWhitespace() }
                    else -> name
                }
                val kanaParts = kanaPart.split("　")
                when {
                    kanaParts.size >= 2 -> {
                        surnameStr = surnameStr ?: kanaParts[0]
                        firstNameStr = firstNameStr ?: kanaParts[1]
                    }
                    kanaParts.size == 1 -> {
                        surnameStr = surnameStr ?: kanaParts[0]
                    }
                }
            }
        }

        val surnameFull = surnameStr?.take(9) ?: ""
        val nameFull = firstNameStr?.take(9) ?: ""
        PreferenceUtil.setPreferenceStringValue(ConstUtil.EKYC_INFO_NAME, rawName ?: "")
        PreferenceUtil.setPreferenceStringValue(ConstUtil.EKYC_INFO_LAST_NAME, surnameFull)
        PreferenceUtil.setPreferenceStringValue(ConstUtil.EKYC_INFO_FIRST_NAME, nameFull)
    }

    private fun showSorryDialog(errorCode: String) {
        Log.i("ekyc", "error: $errorCode")
        val message = when (errorCode) {
            "SE22001", "SE99998", "SE25011", "SE20001",
            "SE20005", "SE21001", "SE21101", "SE21102",
            "SE21103", "SE23001", "SE21201" ->
                "読み取りを行ったICカードのお取扱いができません。\nお手数ですが、お住まいの市区町村にお問い合わせください。"
            else -> "エラー番号:$errorCode"
        }
        onSorryDialog?.invoke(message)
    }
}

package jp.co.jsbank.mb.bankingapp.system

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.media.RingtoneManager
import android.net.Uri
import android.text.TextUtils
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.google.android.gms.tasks.OnCompleteListener
import com.google.firebase.messaging.FirebaseMessaging
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.HALF_HYPHEN
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.PUSH_TOKEN
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.PUSH_TOKEN_IDENTIFY
import jp.co.jsbank.mb.bankingapp.utils.LogPrintUtil
import jp.co.jsbank.mb.bankingapp.utils.PreferenceUtil
import java.util.*

/**
 * 通知サービス.
 */
class JsBankFirebaseMessagingService : FirebaseMessagingService() {

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        showNotification(remoteMessage)
    }

    override fun onNewToken(token: String) {
        PreferenceUtil.setPreferenceStringValue(PUSH_TOKEN, token)
        PreferenceUtil.setPreferenceStringValue(
            PUSH_TOKEN_IDENTIFY,
            "sm" + UUID.randomUUID().toString().replace(HALF_HYPHEN, "").lowercase(Locale.getDefault())
        )
        super.onNewToken(token)
    }

    fun isNullFirebaseToken(): Boolean {
        val token = PreferenceUtil.getPreferenceStringValue(PUSH_TOKEN)
        return token.isNullOrBlank()
    }

    fun getToken(): String {
        var token = ""
        FirebaseMessaging.getInstance().token
            .addOnCompleteListener(
                OnCompleteListener { task ->
                    if (!task.isSuccessful) {
                        LogPrintUtil.info("Fetching FCM registration token failed${task.exception}")
                        return@OnCompleteListener
                    }

                    // Get new FCM registration token
                    token = task.result
                    PreferenceUtil.setPreferenceStringValue(PUSH_TOKEN, token)
                    LogPrintUtil.info("getToken firbase token :$token")
                }
            )
        return token
    }

    private fun showNotification(remoteMessage: RemoteMessage) {
        val notification = remoteMessage.data
        var intent = remoteMessage.toIntent()

        // 登録通知チャネル
        val channelID = "CHID_JSBAPP_PUSH_NOTIFY"
        val channelName = "城南信用金庫からのお知らせ"
        val notificationChannel = NotificationChannel(channelID, channelName, NotificationManager.IMPORTANCE_HIGH)
        notificationChannel.enableLights(true)
        notificationChannel.lightColor = Color.RED
        notificationChannel.enableVibration(true)
        notificationChannel.vibrationPattern = longArrayOf(100, 200, 300, 400, 500, 400, 300, 200, 400)
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(notificationChannel)
        // 通知フラグ
        val tag = System.currentTimeMillis().toInt()
        // 通知クリックの遷移
        if (TextUtils.isEmpty(notification["action"])) {
            val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
            intent = (launchIntent?.putExtras(intent) ?: return)
        } else {
            intent.action = notification["action"]
            intent.addCategory(Intent.CATEGORY_DEFAULT)
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val pendingIntent = PendingIntent.getActivity(
            this, tag, intent,
            PendingIntent.FLAG_IMMUTABLE
        )
        val defaultSoundUri: Uri = getNotificationSound()
        val title = notification["twi_title"] ?: "title"
        val body = notification["twi_body"] ?: "body"
        val icon: Int = getNotificationIcon()
        showNotification(this, channelID, tag, icon, title, body, defaultSoundUri, pendingIntent)
    }

    private fun showNotification(
        context: Context,
        channelID: String,
        tag: Int,
        icon: Int,
        title: String?,
        msg: String?,
        defaultSoundUri: Uri,
        pendingIntent: PendingIntent
    ) {
        val builder = NotificationCompat.Builder(context, channelID)
            .setContentTitle(title)
            .setContentText(msg)
            .setSmallIcon(icon)
            .setSound(defaultSoundUri)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setOnlyAlertOnce(true)
//            .setNumber(100)
        builder.setStyle(
            NotificationCompat.BigTextStyle()
                .bigText(msg)
        )
        NotificationManagerCompat.from(this).notify(tag, builder.build())
    }

    /**
     * 通知appアイコンの設定
     */
    private fun getNotificationIcon(): Int {
        return R.mipmap.ic_launcher
    }

    /**
     * @return Notificationを設定するためのIcon
     */
    private fun getNotificationSound(): Uri {
        return RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
    }

    /**
     *　画像名から画像のidを取得する
     * @param imageName
     * @return
     */
    fun getResource(imageName: String?): Int {
        val ctx: Context = baseContext
        return resources.getIdentifier(imageName, "drawable", ctx.packageName)
    }
}

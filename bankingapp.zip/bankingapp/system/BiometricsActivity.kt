package jp.co.jsbank.mb.bankingapp.system

import android.os.Bundle
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.logic.common.ToLoginLogic
import jp.co.jsbank.mb.bankingapp.logic.login.mblg.mblg0101.MBLG0101Logic
import jp.co.jsbank.mb.bankingapp.repositories.api.common.RestApiFactory.retrofit
import jp.co.jsbank.mb.bankingapp.system.MyApp.Companion.CONTEXT
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.BIOMETRIC_RESULT
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.BIOMETRIC_RESULT_ACCESS_CANCEL
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.BIOMETRIC_RESULT_ACCESS_FAIL
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.BIOMETRIC_RESULT_ACCESS_SUCCESS
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.EXECUTE_BACKGROUND_FLAG
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.EXECUTE_FLAG
import jp.co.jsbank.mb.bankingapp.utils.PreferenceUtil
import jp.co.jsbank.mb.bankingapp.utils.ToLoginUtil
import java.util.concurrent.Executor
import jp.co.jsbank.mb.bankingapp.repositories.api.common.gateway.GatewayRestApiFactory.retrofit as gatewayRetrofit

/**
 * 生体認証クラス.
 */
class BiometricsActivity : FragmentActivity() {
    private lateinit var executor: Executor
    private lateinit var biometricPrompt: BiometricPrompt
    private lateinit var promptInfo: BiometricPrompt.PromptInfo

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        executor = ContextCompat.getMainExecutor(CONTEXT)
        biometricPrompt = BiometricPrompt(
            this, executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationError(
                    errorCode: Int,
                    errString: CharSequence
                ) {
                    super.onAuthenticationError(errorCode, errString)
                    PreferenceUtil.setPreferenceStringValue(BIOMETRIC_RESULT, BIOMETRIC_RESULT_ACCESS_CANCEL)
                    if (MainActivity.IS_BACK_GROUND) {
                        ToLoginUtil.openLogin("1")
                    }
                    destroy()
                    finish()
                }

                override fun onAuthenticationSucceeded(
                    result: BiometricPrompt.AuthenticationResult
                ) {
                    super.onAuthenticationSucceeded(result)
                    PreferenceUtil.setPreferenceStringValue(BIOMETRIC_RESULT, BIOMETRIC_RESULT_ACCESS_SUCCESS)
                    destroy()
                    finish()
                }

                override fun onAuthenticationFailed() {
                    super.onAuthenticationFailed()
                    // PINが不正な場合
                    // PIN不正カウント設定
                    PreferenceUtil.setPreferenceIntValue(
                        ConstUtil.PASS_ERR_COUNT,
                        PreferenceUtil.getPreferenceIntValue(ConstUtil.PASS_ERR_COUNT) + 1
                    )
                    // リセットフラグ
                    PreferenceUtil.setPreferenceStringValue(BIOMETRIC_RESULT, ConstUtil.BIOMETRIC_RESULT_NOT_ACCESS)
                    destroy()
                    if (PreferenceUtil.getPreferenceIntValue(ConstUtil.PASS_ERR_COUNT) >= Config.TRY_COUNT) {
                        PreferenceUtil.setPreferenceStringValue(BIOMETRIC_RESULT, BIOMETRIC_RESULT_ACCESS_FAIL)
                        biometricPrompt.cancelAuthentication()
                        finish()
                    }
                }
            }
        )
        // 認証画面を呼び出す
        promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle(CONTEXT.getString(R.string.mbst1901_page_label_biological))
            .setSubtitle(CONTEXT.getString(R.string.MSG_ID_MB004006I))
            .setNegativeButtonText("パスコードを入力")
            .build()
        biometricPrompt.authenticate(promptInfo)
    }

    private fun destroy() {
        if (MainActivity.IS_BACK_GROUND) {
            PreferenceUtil.setPreferenceBooleanValue(EXECUTE_BACKGROUND_FLAG, true)
            ToLoginLogic().goAuthentication()
        } else {
            PreferenceUtil.setPreferenceBooleanValue(EXECUTE_FLAG, true)
            MBLG0101Logic(retrofit, gatewayRetrofit).goAuthentication()
        }
    }
}

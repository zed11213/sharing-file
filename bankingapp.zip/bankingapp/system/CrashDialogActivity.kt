package jp.co.jsbank.mb.bankingapp.system

import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.annotation.RequiresApi
import com.google.accompanist.pager.ExperimentalPagerApi
import dagger.hilt.android.AndroidEntryPoint
import jp.co.jsbank.mb.bankingapp.theme.JsBankTheme
import jp.co.jsbank.mb.bankingapp.ui.pages.common.CrashDialogPage

@AndroidEntryPoint
class CrashDialogActivity : ComponentActivity() {

    @OptIn(ExperimentalPagerApi::class)
    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            JsBankTheme {
                CrashDialogPage()
            }
        }
    }
}

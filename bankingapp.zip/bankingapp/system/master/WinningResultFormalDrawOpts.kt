package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 当選結果(本抽選).
 */
enum class WinningResultFormalDrawOpts(val code: String, val value: String) {
    DREAM_GRAND_PRIZE("93", "ドリーム大賞"),
    FIRST_PRIZE("01", "1等賞"),
    SECOND_PRIZE("02", "2等賞"),
    STRICKEN_AREA_RECONSTRUCTION_SUPPORT_GOURMAN_AWARD("22", "被災地復興応援グルメ賞"),
    STRICKEN_AREA_RECONSTRUCTION_SUPPORT_GOURMAN_AWARD_44("44", "城南特選グルメ賞"),
    THANKS_30TH("11", "３０周年感謝賞"),
    ANNIVERSARY_80TH("04", "創立８０周年記念特別賞"),
    RICE_PRIZE("33", "コシヒカリ賞"),
    THIRD_PRIZE("03", "3等賞"),
    FOUR_PRIZE("40", "4等賞"),
    RAFFLE_RESULT_A1("A1", "A1"),
    RAFFLE_RESULT_A2("A2", "A2"),
    RAFFLE_RESULT_A3("A3", "A3"),
    RAFFLE_RESULT_A4("A4", "A4"),
    RAFFLE_RESULT_A5("A5", "A5");

    companion object {
        fun getWinningResultFormalDrawOptsName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

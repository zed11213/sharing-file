package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 人格区分.
 */
enum class PersonalityFlag(val code: String = "", val value: String = "") {
    INDIVIDUAL_INITIAL_LOGIN("0", "個人_利用登録"),
    INDIVIDUAL_OTHER("8", "個人_利用登録以外"),
    CORPORATION("1", "法人"),
    INDIVIDUAL_BUSINESS("2", "個人事業者");

    companion object {
        fun getPersonalityFlagName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

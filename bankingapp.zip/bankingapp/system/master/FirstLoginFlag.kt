package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 利用登録フラグ.
 */
enum class FirstLoginFlag(val code: String = "", val value: String = "") {
    OTHER("0", "それ以外"),
    FIRST_LOGIN_CIF("1", "利用登録CIF");

    companion object {
        fun getFirstLoginFlagName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

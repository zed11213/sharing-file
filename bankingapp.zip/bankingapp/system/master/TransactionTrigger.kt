package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 取引のきっかけ.
 */
enum class TransactionTrigger(val code: String, val value: String) {
    SOLICITATION_BY_OUR_STAFF("01", "当金庫職員による勧誘"),
    APP_STORE_SEARCH("02", "アプリストア内検索"),
    THERE_IS_A_STORE_NEARBY("03", "店舗が近くにある"),
    OUR_WEBSITE_AND_SNS("04", "当金庫ホームページやSNS"),
    FAMILY_FRIENDS_WORKPLACE_REFERRALS("05", "家族、友人、職場での紹介"),
    WATCH_NEWS_ON_TV("06", "テレビ、新聞等を見て"),
    OTHER("07", "上記以外のその他");

    companion object {
        fun getTransactionTriggerName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

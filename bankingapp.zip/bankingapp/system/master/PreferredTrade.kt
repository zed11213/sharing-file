package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 当金庫との取引希望.
 */
enum class PreferredTrade(val code: String, val value: String) {
    NORMAL("01", "普通"),
    CURRENT("02", "当座"),
    REGULAR("03", "定期"),
    ISOCHORIC_PROCESS("04", "定積"),
    VIBRATION_SUPPLY("05", "給振"),
    LOAN("06", "融資"),
    IB("07", "IB"),
    OTHERS("08", "その他");

    companion object {
        fun getPreferredTradeName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

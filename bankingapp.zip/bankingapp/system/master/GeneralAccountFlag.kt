package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 総合口座フラグ.
 */
enum class GeneralAccountFlag(val code: String, val value: String) {
    IS_GENERAL("0", "総合以外"),
    NOT_GENERAL("1", "総合口座");

    companion object {
        fun getGeneralAccountFlagName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

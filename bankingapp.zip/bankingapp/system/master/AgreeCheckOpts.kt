package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 会場選択有無.
 */
enum class AgreeCheckOpts(val code: String = "", val value: String = "") {
    YES("1", "有"),
    NO("0", "無");

    companion object {
        fun getAgreeCheckOptsName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

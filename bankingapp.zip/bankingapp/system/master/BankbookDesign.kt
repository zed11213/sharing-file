package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 通帳証書デザイン.
 */
enum class BankbookDesign(val code: String = "", val value: String = "") {
    JAPANESE_PATTERN_DESIGN("0", "シンプルデザイン"),
    CINNAMOLE_DESIGN("1", "シナモロールデザイン");

    companion object {
        fun getBankbookDesignName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 状態.
 */
enum class Status(val code: String, val value: String) {
    NORMAL("0", "正常"),
    CONFIRM("1", "確認中"),
    STOP("2", "利用停止"),
    WAITING("3", "利用登録待");

    companion object {
        fun getStatus(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

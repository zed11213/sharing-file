package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 電話番号種別.
 */
enum class Phone(val code: String, val value: String) {
    FIXED_TELEPHONE("01", "固定電話"),
    MOBILE_PHONE("02", "携帯電話"),
    // 2025/01/29 共同化ため電話番号の登録・表示　start
    IP_PHONE("03", "IP電話");
    // 2025/01/29 共同化ため電話番号の登録・表示　end

    companion object {
        fun getPhoneTypeName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

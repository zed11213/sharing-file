package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 会社形態.
 */
enum class CompanyForm(val code: String, val value: String) {
    CORPORATION("01", "株式会社"),
    LIMITED_COMPANY("02", "有限会社"),
    UNLIMITED_COMPANY("03", "合名会社"),
    JOINT_STOCK_COMPANY("04", "合資会社"),
    MUTUAL_COMPANY("05", "相互会社"),
    GK("06", "合同会社"),
    COOPERATIVE("07", "協同組合"),
    FOUNDATION_CORPORATION("08", "財団法人"),
    ASSOCIATION_CORPORATION("09", "社団法人"),
    RELIGIOUS_CORPORATION("10", "宗教法人"),
    SCHOOL_CORPORATION("11", "学校法人"),
    MEDICAL_CORPORATION("12", "医療法人"),
    SOCIAL_WELFARE_CORPORATION("13", "社会福祉法人"),
    OTHERS("14", "その他");

    companion object {
        fun getCompanyFormName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

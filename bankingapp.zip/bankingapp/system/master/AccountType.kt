package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 預金種目(科目).
 */
enum class AccountType(val code: String = "", val value: String = "") {
    ORDINARY_DEPOSIT("001", "普通預金"),
    CHECKING_ACCOUNT("002", "当座預金"),
    TAX_DEPOSIT("005", "納税準備預金"),
    FIXED_SAVINGS("006", "定期預金"),
    INSTALLMENT("008", "定期積金"),
    DEPOSIT_DEPOSIT("003", "通知預金");

    companion object {
        fun getAccountTypeName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

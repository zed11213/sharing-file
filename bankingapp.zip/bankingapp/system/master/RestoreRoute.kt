package jp.co.jsbank.mb.bankingapp.system.master

import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName

/**
 * 復元画面ルート名称.
 */
enum class RestoreRoute(val code: String = "", val value: String = "") {
    // 個人
    RESTORE_MBCC0103("MBCC0103", RouteName.MBCC0103Page),
    RESTORE_MBCO0202("MBCO0202", RouteName.MBCO0202Page),
    RESTORE_MBCO0302("MBCO0302", RouteName.MBCO0302Page),
    RESTORE_MBCO0501("MBCO0501", RouteName.MBCO0501Page),
    RESTORE_MBCO0601("MBCO0601", RouteName.MBCO0601Page),
    RESTORE_MBCO0405("MBCO0405", RouteName.MBCO0405Page),
    RESTORE_MBOP0203("MBOP0203", RouteName.MBOP0203Page),
    RESTORE_MBOP0601("MBOP0601", RouteName.MBOP0601Page),
    RESTORE_MBOP0602("MBOP0602", RouteName.MBOP0602Page),
    RESTORE_MBOP0608("MBOP0608", RouteName.MBOP0608Page),
    RESTORE_MBOP0609("MBOP0609", RouteName.MBOP0609Page),
    RESTORE_MBCO0201("MBCO0201", RouteName.MBCO0201Page),
    RESTORE_MBOP0701("MBOP0701", RouteName.MBOP0701Page),
    RESTORE_MBOP0703("MBOP0703", RouteName.MBOP0703Page),
    RESTORE_MBOP0705("MBOP0705", RouteName.MBOP0705Page),
    RESTORE_MBOP0401("MBOP0401", RouteName.MBOP0401Page),
    RESTORE_MBOP0610("MBOP0610", RouteName.MBOP0610Page),
    RESTORE_MBOP0611("MBOP0611", RouteName.MBOP0611Page),
    RESTORE_MBOP1401("MBOP1401", RouteName.MBOP1401Page),
    RESTORE_MBOP0603("MBOP0603", RouteName.MBOP0603Page),
    RESTORE_MBOP0604("MBOP0604", RouteName.MBOP0604Page),
    RESTORE_MBOP0605("MBOP0605", RouteName.MBOP0605Page),
    RESTORE_MBOP0612("MBOP0612", RouteName.MBOP0612Page),
    RESTORE_MBOP0613("MBOP0613", RouteName.MBOP0613Page),
    RESTORE_MBOP0606("MBOP0606", RouteName.MBOP0606Page),
    RESTORE_MBOP0607("MBOP0607", RouteName.MBOP0607Page);

    companion object {
        fun getRestoreRouteName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return RESTORE_MBCO0405.value
        }
    }
}

package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 本人確認書類選択種類 Enum クラスです.
 */
enum class DocumentKind {
//    /**
//     * 運転免許証.
//     */
//    DRIVER_LICENSE_CARD,
//
//    /**
//     * マイナンバーカード.
//     */
//    MY_NUMBER_CARD,
//
//    /**
//     * 在留カード・特別永住者証明書.
//     */
//    RESIDENCE_CARD,

    /**
     * 運転免許証(OCR有).
     */
    DRIVER_LICENSE_CARD_OCR,

    /**
     * マイナンバーカード(OCR有).
     */
    MY_NUMBER_CARD_OCR;

    companion object {
        /**
         * 本人確認書類種類を取得します.
         *
         * @param index インデックス
         * @return 本人確認書類種類
         */
        fun getDocumentKind(index: Int): DocumentKind {
            for (kind in values()) {
                if (kind.ordinal == index) {
                    return kind
                }
            }
            return DRIVER_LICENSE_CARD_OCR
        }
    }
}

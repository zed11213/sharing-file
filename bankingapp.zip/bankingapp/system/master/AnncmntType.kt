package jp.co.jsbank.mb.bankingapp.system.master

/**
 * お知らせ種別.
 */
enum class AnncmntType(val code: String = "", val value: String = "") {
    MESSAGE("01", "メッセージ"),
    EASY_RECEPTION("02", "かんたん受付"),
    ELECTRONIC_DELIVERY("03", "電子交付");

    companion object {
        fun getAnncmntTypeName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 候補フラグ.
 */
enum class CandidateFlag(val code: String = "", val value: String = "") {
    HAS_CANDIDATE("1", "候補有り"),
    NO_CANDIDATE_DOWN("2", "候補なし"),
    NO_CANDIDATE_UP("3", "候補なし"),
    OTHER("4", "対象外");
}

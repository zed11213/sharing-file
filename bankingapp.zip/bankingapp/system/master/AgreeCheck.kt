package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 同意チェックボックス有無.
 */
enum class AgreeCheck(val code: String = "", val value: String = "") {
    NO("0", "無"),
    YES("1", "有");

    companion object {
        fun getAgreeCheckName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

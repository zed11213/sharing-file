package jp.co.jsbank.mb.bankingapp.system.master

import jp.co.jsbank.mb.bankingapp.bean.common.ChomeInfoBean.chomeList

/**
 * 職業.
 */
enum class Chome(val code: String, val value: String) {
    CHOME_1("1", "１"),
    CHOME_2("2", "２"),
    CHOME_3("3", "３"),
    CHOME_4("4", "４"),
    CHOME_5("5", "５");

    companion object {
        fun getChomeName(code: String): String {
            for (item in chomeList) {
                if (item.code == code) {
                    return item.value
                }
            }
            return ""
        }
    }
}

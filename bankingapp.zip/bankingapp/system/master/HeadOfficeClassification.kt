package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 本店所在地相違区分（法人）.
 */
enum class HeadOfficeClassification(val code: String, val value: String) {
    SAME_ADDRESS("01", "本店所在地と同一住所"),
    DIFFERENT_ADDRESS("02", "本店所在地と別住所");

    companion object {
        fun getHeadOfficeClassificationName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

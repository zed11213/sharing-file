package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 取引目的.
 */
enum class TransactPurpose(val code: String, val value: String) {
    LIVELIHOOD_EXPENSE_SETTLEMENT("01", "生計費決済"),
    BUSINESS_EXPENSE_SETTLEMENT("02", "事業費決済"),
    SALARY_PENSION("03", "給与受取/年金受取"),
    SAVINGS_ASSET_MANAGEMENT("04", "貯蓄/資産運用"),
    LOAN("05", "融資"),
    FOREX_TRADING("06", "外国為替取引"),
    OTHERS("07", "その他");

    companion object {
        fun getTransactPurposeName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

package jp.co.jsbank.mb.bankingapp.system.master

/**
 * EKYC確認結果.
 */
enum class EkycResult(val code: String = "", val value: String = "") {
    OK("0", "OK"),
    NG("1", "NG");
}

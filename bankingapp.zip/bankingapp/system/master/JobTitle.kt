package jp.co.jsbank.mb.bankingapp.system.master

/**
 * ご役職.
 */
enum class JobTitle(val code: String, val value: String) {
    CEO("01", "代表取締役"),
    DIRECTOR("02", "取締役"),
    OTHERS("03", "その他");

    companion object {
        fun getJobTitleName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

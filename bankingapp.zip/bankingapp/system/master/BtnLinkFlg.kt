package jp.co.jsbank.mb.bankingapp.system.master

/**
 * リンク先有無.
 */
enum class BtnLinkFlg(val code: String = "", val value: String = "") {
    NO("0", "無"),
    YES("1", "有");

    companion object {
        fun getBtnLinkFlgName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

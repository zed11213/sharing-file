package jp.co.jsbank.mb.bankingapp.system.master

/**
 *お知らせ一覧タイプ.
 */
enum class AnnouncementsType(val code: String = "", val value: String = "") {
    TYPE_BEFORE("0", "ログイン前"),
    TYPE_AFTER("1", "ログイン後");

    companion object {
        fun getAnnouncementsType(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

package jp.co.jsbank.mb.bankingapp.system.master

/**
 * Jag エラーコード.
 */
enum class JagErrorCode(val code: String, val value: String) {
    E10001("E10001", "E10001"),
    E10006("E10006", "E10006"),
    E10007("E10007", "E10007"),
    E10008("E10008", "E10008"),
    E10045("E10045", "E10045"),
    E10049("E10049", "E10049"),
    E10018("E10018", "E10018"),
    MBAP1044("MBAP1044", "MBAP1044"),
    BFF_ERROR("BFF_ERROR", "BFF_ERROR");
}

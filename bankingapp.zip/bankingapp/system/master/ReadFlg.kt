package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 既読フラグ.
 */
enum class ReadFlg(val code: String = "", val value: String = "") {
    UNREAD("0", "未読"),
    ALREADY_READ("1", "既読");

    companion object {
        fun getReadFlgName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

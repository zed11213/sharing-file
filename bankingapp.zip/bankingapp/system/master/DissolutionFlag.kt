package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 解約フラグ.
 */
enum class DissolutionFlag(val code: String = "", val value: String = "") {
    VALIDATE("0", "有効"),
    INVALIDATE("1", "解約");

    companion object {
        fun getDissolutionFlagName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

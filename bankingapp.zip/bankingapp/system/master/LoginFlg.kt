package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 初回ログインフラグ.
 */
enum class LoginFlg(val code: String = "", val value: String = "") {
    FIRST("0", "初回ログイン"),
    NOT_FIRST("1", "初回ログイン以外");

    companion object {
        fun getLoginFlgName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

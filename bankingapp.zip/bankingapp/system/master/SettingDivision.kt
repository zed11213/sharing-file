package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 設定区分.
 */
enum class SettingDivision(val code: String, val value: String) {
    NO_DIVISION("00", "区分なし"),
    CAMPAIGN("01", "キャンペーン"),
    TRANSACTION("02", "取引");

    companion object {
        fun getSettingDivision(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 職業.
 */
enum class Occupation(val code: String, val value: String) {
    COMPANY_GROUP_OFFICER("01", "会社役員・団体役員"),
    COMPANY_GROUP_EMPLOYEE("02", "会社員・団体職員"),
    CIVIL_SERVANT("03", "公務員"),
    SELF_EMPLOYED("04", "個人事業主/自営業"),
    PART_TEMPORARY_CONTRACT_EMPLOYEE("05", "パート/アルバイト/派遣社員/契約社員"),
    HOUSEWIFE_HOUSEHUSBAND("06", "主婦・主夫"),
    STUDENT("07", "学生"),
    RETIRED_UNEMPLOYED("08", "退職された方/無職の方"),
    OTHERS("09", "その他");

    companion object {
        fun getOccupationName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 通帳証書デザイン.
 */
enum class EkycCard() {
    MEMBER,
    DRIVER;
}

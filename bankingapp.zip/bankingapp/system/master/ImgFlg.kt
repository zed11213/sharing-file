package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 画像有無フラグ.
 */
enum class ImgFlg(val code: String = "", val value: String = "") {
    NO("0", "無"),
    YES("1", "有");

    companion object {
        fun getImgFlgName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

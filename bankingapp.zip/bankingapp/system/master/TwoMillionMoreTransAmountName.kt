package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 取引目的.
 */
enum class TwoMillionMoreTransAmountName(val code: String, val value: String) {
    OVER_2_MILLION_YEN_TO_UNDER_3_MILLION_YEN("01", "２００万円超～３００万円以下"),
    OVER_3_MILLION_YEN_TO_UNDER_5_MILLION_YEN("02", "３００万円超～５００万円以下"),
    OVER_5_MILLION_YEN_TO_UNDER_10_MILLION_YEN("03", "５００万円超～１０００万円以下"),
    OVER_10_MILLION_YEN("04", "１０００万円超");

    companion object {
        fun getName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

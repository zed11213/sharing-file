package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 預金種目(科目).
 */
enum class UpdateTypeMail(val code: String = "", val value: String = "") {
    OPENING_ACCOUNT_INDIVIDUAL("101", "口座開設（個人）"),
    OPENING_ACCOUNT_CORPORATION("102", "口座開設（法人）"),
    OPENING_ACCOUNT_SOLE_PROPRIETORSHIP("103", "口座開設（個人事業主）"),
    CC_ISSUANCE("104", "CC発行"),
    INITIAL_REGISTRATION("105", "利用登録"),
    VARIOUS_REGISTRATION_SETTINGS("106", "各種登録設定");

    companion object {
        fun getUpdateTypeMailName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

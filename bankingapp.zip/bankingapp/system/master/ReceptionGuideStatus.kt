package jp.co.jsbank.mb.bankingapp.system.master

/**
 * メッセージ内容種別.
 */
enum class ReceptionGuideStatus(val code: String = "", val value: String = "") {
    SEMINAR("01", "セミナー"),
    CAMPAIGN("02", "キャンペーン"),
    GENERAL_PAYMENT("03", "一般受付"),
    OTHER("04", "その他");

    companion object {
        fun getReceptionGuideStatusName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 事業内容.
 */
enum class BusinessDescription(val code: String, val value: String) {
    AGRICULTURE_FORESTRY_FISHERIES("21", "農業・林業・漁業"),
    MANUFACTURING_INDUSTRY("22", "製造業"),
    CONSTRUCTION_INDUSTRY("23", "建設業"),
    INFORMATION_COMMUNICATION_INDUSTRY("24", "情報通信業"),
    TRANSPORTATION_INDUSTRY("25", "運輸業"),
    WHOLESALE_RETAIL_BUSINESS("26", "卸売・小売業"),
    FINANCE_INSURANCE("27", "金融業・保険業"),
    REAL_ESTATE_BUSINESS("28", "不動産業"),
    SERVICE_INDUSTRY("29", "サービス業"),
    OTHERS("30", "その他");

    companion object {
        fun getBusinessDescriptionName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

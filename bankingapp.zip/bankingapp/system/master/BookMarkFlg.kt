package jp.co.jsbank.mb.bankingapp.system.master

/**
 * お気に入りフラグ.
 */
enum class BookMarkFlg(val code: String = "", val value: String = "") {
    UN_FAVORITE("0", "お気に入りではない"),
    FAVORITE("1", "お気に入り");

    companion object {
        fun getBookMarkFlgName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

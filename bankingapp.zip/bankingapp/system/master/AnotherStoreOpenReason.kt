package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 他の店舗をお選びいただく理由.
 */
enum class AnotherStoreOpenReason(val code: String, val value: String) {
    SCHOOL("01", "学校等の口座振替で指定された"),
    RENT_PARKING_FEE("02", "家賃・駐車場代等の支払で指定された"),
    WORK_PLACE("03", "お勤め先の給与受取で指定された"),
    NEAREST_STORE("04", "引越し予定先の最寄り店舗"),
    OTHERS("05", "その他");

    companion object {
        fun getAnotherStoreOpenReason(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

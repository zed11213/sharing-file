package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 個別確認結果フラグ.
 */
enum class ConfirmFlg(val code: String = "", val value: String = "") {
    NO("0", "確認未済"),
    YES("1", "確認済");

    companion object {
        fun getConfirmFlgName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

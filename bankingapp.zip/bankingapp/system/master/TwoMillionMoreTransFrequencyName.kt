package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 取引目的.
 */
enum class TwoMillionMoreTransFrequencyName(val code: String, val value: String) {
    MORE_THAN_THREE_TIMES_A_WEEK("01", "週に３回以上"),
    ONCE_A_WEEK("02", "週に１回"),
    ONCE_EVERY_2_3_WEEKS("03", "２～３週間に１回"),
    ONCE_A_MONTH("04", "月に１回"),
    ONCE_EVERY_2_3_MONTHS("05", "２～３か月に１回"),
    ONCE_EVERY_SIX_MONTHS("06", "半年に１回"),
    LESS_THAN_ONCE_A_YEAR("07", "１年に１回以下");

    companion object {
        fun getName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

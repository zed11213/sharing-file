package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 更新パターン
 */
enum class UpdateType(val code: String = "", val value: String = "") {
    UPDATE_TYPE_001("001", "お客様情報１（個人）"),
    UPDATE_TYPE_002("002", "お客様情報２（個人）"),
    UPDATE_TYPE_003("003", "お勤め先（個人）"),
    UPDATE_TYPE_004("004", "開設店番（個人）"),
    UPDATE_TYPE_005("005", "CC暗証番号（個人）"),
    UPDATE_TYPE_006("006", "IB暗証番号（個人）"),
    UPDATE_TYPE_007("007", "カード種類（個人）"),
    UPDATE_TYPE_008("008", "学校（個人）"),
    UPDATE_TYPE_009("009", "お勤め先（クリア）"),
    UPDATE_TYPE_010("010", "学校（クリア）"),
    UPDATE_TYPE_011("011", "本店所在地（法人）"),
    UPDATE_TYPE_012("012", "開設店番（法人）"),
    UPDATE_TYPE_013("013", "代表者確認書類（法人）"),
    UPDATE_TYPE_014("014", "お客様情報１（法人）"),
    UPDATE_TYPE_015("015", "役員・支配者（法人）"),
    UPDATE_TYPE_016("016", "お客様情報２（法人）"),
    UPDATE_TYPE_017("017", "事業先確認書類（法人）"),
    UPDATE_TYPE_018("018", "法人の所在地の入力情報を更新する。"),
    UPDATE_TYPE_021("021", "所在地（個人事業主）"),
    UPDATE_TYPE_022("022", "開設店番（個人事業主）"),
    UPDATE_TYPE_023("023", "確認書類（個人事業主）"),
    UPDATE_TYPE_024("024", "お客様情報１（個人事業主）"),
    UPDATE_TYPE_025("025", "お客様情報２（個人事業主）"),
    UPDATE_TYPE_026("026", "個人事業主のご自宅の入力情報を更新する。"),
    UPDATE_TYPE_031("031", "確認書類（CC発行）"),
    UPDATE_TYPE_032("032", "お客様情報（CC発行）"),
    UPDATE_TYPE_033("033", "CC暗証番号（CC発行）"),
    UPDATE_TYPE_101("101", "メール（口座開設（個人））"),
    UPDATE_TYPE_102("102", "メール（口座開設（（法人））"),
    UPDATE_TYPE_103("103", "メール（口座開設（（個人事業主））"),
    UPDATE_TYPE_104("104", "メール（CC発行）"),
    UPDATE_TYPE_105("105", "メール（利用登録）"),
    UPDATE_TYPE_106("106", "メール（各種登録設定）"),
    UPDATE_TYPE_111("111", "IVR（口座開設（個人））"),
    UPDATE_TYPE_112("112", "IVR（口座開設（法人））"),
    UPDATE_TYPE_113("113", "IVR（口座開設（個人事業主））"),
    UPDATE_TYPE_114("114", "IVR（CC発行）"),
    UPDATE_TYPE_115("115", "IVR（利用登録）");

    companion object {
        fun getUpdateTypeSelfempName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

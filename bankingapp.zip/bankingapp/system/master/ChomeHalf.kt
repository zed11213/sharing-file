package jp.co.jsbank.mb.bankingapp.system.master

import jp.co.jsbank.mb.bankingapp.bean.common.ChomeInfoBean.chomeHalfList

/**
 * 職業.
 */
enum class ChomeHalf(val code: String, val value: String) {
    CHOME_HALF_1("1", "1"),
    CHOME_HALF_2("2", "2"),
    CHOME_HALF_3("3", "3"),
    CHOME_HALF_4("4", "4"),
    CHOME_HALF_5("5", "5");

    companion object {
        fun getChomeHalfName(code: String): String {
            for (item in chomeHalfList) {
                if (item.code == code) {
                    return item.value
                }
            }
            return ""
        }
    }
}

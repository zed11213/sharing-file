package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 業種.
 */
enum class CategoryCode(val code: String, val value: String) {
    CATERING_INDUSTRY("001", "飲食業"),
    DOCTORS_HOSPITALS_MEDICAL_INSTITUTIONS("002", "医師・病院・医療機関"),
    TRANSPORTATION("003", "運輸業"),
    WHOLESALE("004", "卸売業"),
    MONEY_LENDING_BUSINESS("005", "貸金業"),
    VIRTUAL_CURRENCY_EXCHANGE_BUSINESS("006", "仮想通貨交換業"),
    FINANCIAL_TRUST_BUSINESS("007", "金融信託業"),
    FINANCIAL_PRODUCTS_COMMODITY_FUTURES_TRADING_BUSINESS("008", "金融商品／商品先物取引業"),
    CONSTRUCTION("009", "建設業"),
    RETAIL_TRADE("010", "小売業（除く貴金属／宝石）"),
    CONSULTING_BUSINESS("011", "コンサルティング業"),
    CREDIT_CARD_BUSINESS("012", "クレジットカード事業"),
    SERVICE_INDUSTRY("013", "サービス業"),
    FUNDS_TRANSFER_BUSINESS_COLLECTION_AGENCY_BUSINESS("014", "資金移動業・収納代行業"),
    INFORMATION_COMMUNICATIONS("015", "情報通信業"),
    MANUFACTURING("016", "製造業"),
    REAL_ESTATE_BUSINESS("017", "宅地建物取引業"),
    CALL_FORWARDING_SERVICES("018", "電話転送サービス業"),
    TELEPHONE_RECEPTION_SERVICE("019", "電話受付代行業"),
    ELECTRONIC_MONETARY_CLAIMS_RECORDING_AGENCY("020", "電子債権記録機関"),
    INVESTMENT_BUSINESS("021", "投資事業"),
    AGRICULTURE("022", "農業"),
    FORESTRY("023", "林業"),
    FISHERIES("024", "漁業"),
    REAL_ESTATE_RENTAL_BUSINESS("025", "不動産賃貸業"),
    FINANCE_LEASE_BUSINESS("026", "ファイナンスリース事業"),
    LAWYERS_LAW_LFIRMS("027", "弁護士・弁護士法人"),
    JUDICIAL_SCRIVENER_JUDICIAL_SCRIVENER_ORPORATION("028", "司法書士・司法書士法人"),
    ADMINISTRATIVE_SCRIVENER_CORPORATION("029", "行政書士・行政書士法人"),
    CERTIFIED_PUBLIC_ACCOUNTANTS_AUDIT_CORPORATIONS("030", "公認会計士・監査法人"),
    TAX_ACCOUNTANT_TAX_ACCOUNTANT_CORPORATION("031", "税理士・税理士法人"),
    JEWELRY_PRECIOUS_METALS_BUSINESS("032", "宝石・貴金属等取扱事業"),
    INSURANCE("033", "保険業"),
    PREPAID_PAYMENT_INSTRUMENT_ISSUERS("034", "前払式支払手段発行者（電子マネー発行業者）"),
    MAIL_RECEIVING_SERVICE_BUSINESS("035", "郵便物受取サービス業"),
    DEPOSIT_TAKING_FINANCIAL_SERVICES("036", "預金取扱金融業"),
    CURRENCY_EXCHANGE_BUSINESS("037", "両替業"),
    OTHERS("038", "その他");

    companion object {
        fun getName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

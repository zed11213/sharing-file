package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 性別.
 */
enum class SexType(val code: String, val value: String) {
    OTHER("0", "その他(法人等)"),
    MAN("1", "男"),
    WOMAN("2", "女"),
    UN_KNOW("3", "回答しない");

    companion object {
        fun getSexTypeName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

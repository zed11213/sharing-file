package jp.co.jsbank.mb.bankingapp.system.master

/**
 * ソート順.
 */
enum class SortFlag(val code: String = "", val value: String = "") {
    NEW_ORDER("0", "新しい順"),
    OLD_ORDER("1", "古い順");

    companion object {
        fun getSortFlagName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

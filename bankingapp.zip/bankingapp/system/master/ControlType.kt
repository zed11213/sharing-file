package jp.co.jsbank.mb.bankingapp.system.master

/**
 * メッセージ内容種別.
 */
enum class ControlType(val code: String = "", val value: String = "") {
    TEXT("text_field", "text_field"),
    LIST_BOX("list_box", "list_box"),
    RADIO_BUTTON("radio_button", "radio_button"),
    CHECK_BOX("check_box", "check_box");

    companion object {
        fun getControlTypeName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

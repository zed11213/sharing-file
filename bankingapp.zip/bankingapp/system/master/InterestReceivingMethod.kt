package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 利息受取方法.
 */
enum class InterestReceivingMethod(val code: String = "", val value: String = "") {
    INTEREST_PAYMENT("1", "利払い"),
    MOTOKA("2", "元加");

    companion object {
        fun getInterestReceivingMethodName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 通帳レス設定状態.
 */
enum class PassbookLessStatus(val code: String, val value: String) {
    NO_SET("0", "未設定"),
    SET("1", "設定済");
}

package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 証書種類.
 */
enum class CertificateType(val code: String, val value: String) {
    JUMP_MMC_SELF_SUCCESSION_MOTOKA("01", "ジャンプＭＭＣ自継元加"),
    JUMP_MMC_SELF_INTEREST_PAYMENT("02", "ジャンプＭＭＣ自継利払"),
    JUMP_MMC_LONG_TERM_SELF_RELIANCE("03", "ジャンプＭＭＣ長期自継元加"),
    JUMP_MMC_LONG_TERM_SELF_INTEREST_PAYMENT("04", "ジャンプＭＭＣ長期自継利払"),
    SUPER_REGULAR_STANDARD("05", "スーパー定期定型"),
    SUPER_REGULAR_DATE("06", "スーパー定期期日"),
    SUPER_REGULAR_SELF_RELIANCE("07", "スーパー定期自継元加"),
    SUPER_FIXED_TERM_SELF_INTEREST_PAYMENT("08", "スーパー定期自継利払"),
    SUPER_REGULAR_GENERAL_YUAN("09", "スーパー定期総合元加"),
    SUPER_REGULAR_TOTAL_INTEREST_PAYMENT("10", "スーパー定期総合利払"),
    USUALLY("11", "普通"),
    HOUSING("12", "住宅"),
    GO_ON_TO_HIGHER_EDUCATION("13", "進学"),
    WELFARE("14", "福祉"),
    MMC_REGULAR("15", "MMC定期"),
    JUMBO_NORMAL("16", "ジャンボ普通"),
    JUMBO_DATE_DESIGNATION("17", "ジャンボ期日指定"),
    MMC_NORMAL("18", "ＭＭＣ普通"),
    JUMBO_SYNTHESIS_MOTOKA("19", "ジャンボ総合元加"),
    JUMBO_COMPREHENSIVE_INTEREST_PAYMENT("20", "ジャンボ総合利払"),
    RELAY_A("21", "リレーＡ"),
    RELAY_B("22", "リレーＢ"),
    TRAFFIC("23", "交通"),
    PROPERTY_FORM_RELAY_MOTOKA("24", "財形リレー元加"),
    COMPREHENSIVE_INTEREST_PAYMENT("25", "総合利払"),
    WITH_CANCER_INSURANCE("26", "がん保険付"),
    COMPREHENSIVE_MOTOKA("27", "総合元加"),
    BEST_INTEREST_PAYMENT("28", "ベスト利払"),
    BEST_MOTOKA("29", "ベスト元加"),
    JUMP_S_TYPE_SELF_SUCCESSION_MOTOKA("30", "ジャンプＳ型自継元加"),
    SCHEDULED_DEPOSIT("31", "期日指定預金"),
    MARU_YUU_DATE_NORMAL("32", "マル優期日普通"),
    MARU_YUU_DATE_SELF_INHERITANCE_MOTOKA("33", "マル優期日自継元加"),
    MARU_YUU_DATE_SELF_SUSTAINING_INTEREST_PAYMENT("34", "マル優期日自継利払"),
    MARU_YU_DATE_GENERAL_MOTOKA("35", "マル優期日総合元加"),
    COMPOSITE_INTEREST_PAYMENT("36", "マル優期日総合利払"),
    MARU_EXPIRATION_DATE_BEST_MOMENTUM("37", "マル優期日ベスト元加"),
    MARU_PREFERRED_DATE_BEST_INTEREST_PAYMENT("38", "マル優期日ベスト利払"),
    JUMP_S_TYPE_SELF_INTEREST_PAYMENT("39", "ジャンプＳ型自継利払"),
    BEST_S_TYPE_SELF_SUFFICIENT_ADDITION("40", "ベストＳ型自継元加"),
    PROPERTY_RELAY_INTEREST_PAYMENT("41", "財形リレー利払"),
    SURCHARGE("42", "割増金"),
    MMC_OWN_ADDITION("43", "ＭＭＣ自継元加"),
    MMC_SELF_INTEREST_PAYMENT("44", "ＭＭＣ自継利払"),
    JUMBO_ORIGINAL_ADDITION("45", "ジャンボ自継元加"),
    JUMBO_SELF_INTEREST_PAYMENT("46", "ジャンボ自継利払"),
    DESIGNATION_OF_SMALL_MMC_DATE("47", "小口ＭＭＣ期日指定"),
    BEST_S_TYPE_SELF_INTEREST_PAYMENT("48", "ベストＳ型自継利払"),
    SMALL_MMC_BEST_MOTOKA("49", "小口ＭＭＣベスト元加"),
    PETTY_MMC_BEST_INTEREST_PAYMENT("50", "小口ＭＭＣベスト利払"),
    VARIABLE_NORMAL("56", "変動型普通"),
    VARIABLE_DUE_DATE("57", "変動型期日"),
    VARIABLE_SELF_SUFFICIENT_ADDITION("58", "変動型自継元加"),
    VARIABLE_SELF_INTEREST_PAYMENT("59", "変動型自継利払"),
    VARIABLE_TOTAL_COMPONENT("68", "変動型総合元加"),
    VARIABLE_COMPREHENSIVE_INTEREST_PAYMENT("69", "変動型総合利払"),
    SMALL_MOUTH_MMC_NORMAL("90", "小口ＭＭＣ普通"),
    OGUCHI_MMC_SELF_SUFFICIENT_ADDITION("91", "小口ＭＭＣ自継元加"),
    SMALL_LOT_MMC_SELF_INTEREST_PAYMENT("92", "小口ＭＭＣ自継利払"),
    SMALL_MMC_LONG_TERM_NORMAL("93", "小口ＭＭＣ長期普通"),
    SMALL_MMC_LONG_TERM_SELF_SUCCESSFUL_ADDITION("94", "小口ＭＭＣ長期自継元加"),
    SMALL_LOT_MMC_LONG_TERM_SELF_INTEREST_PAYMENT("95", "小口ＭＭＣ長期自継利払"),
    MMC_COMPREHENSIVE_ELEMENT_ADDITION("96", "ＭＭＣ総合元加"),
    MMC_GENERAL_INTEREST_PAYMENT("97", "ＭＭＣ総合利払"),
    MMC_LONG_TERM_GENERAL_ADDITION("98", "ＭＭＣ長期総合元加"),
    MMC_LONG_TERM_COMPREHENSIVE_INTEREST_PAYMENT("99", "ＭＭＣ長期総合利払");

    companion object {
        fun getCertificateTypeName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

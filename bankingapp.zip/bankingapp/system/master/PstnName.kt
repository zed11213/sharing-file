package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 役職(名称).
 */
enum class PstnName(val code: String, val value: String) {
    REPRESENTATIVE("01", "代表者"),
    BOARD_MEMBER("02", "役員"),
    MANAGER("03", "管理職"),
    GENERAL_STAFF("04", "一般職員"),
    OTHERS("99", "その他");

    companion object {
        fun getName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}






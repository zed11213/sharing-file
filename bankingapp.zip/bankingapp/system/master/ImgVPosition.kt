package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 画像位置.
 */
enum class ImgVPosition(val code: String = "", val value: String = "") {
    TOP("1", "本文上部"),
    BOTTOM("2", "本文下部");

    companion object {
        fun getImgVPositionName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

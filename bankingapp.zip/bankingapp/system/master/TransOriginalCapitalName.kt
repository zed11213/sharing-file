package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 取引原資
 */
enum class TransOriginalCapitalNameList(val code: String = "", val value: String = "") {
    SALARY("01", "給与"),
    PENSION("02", "年金"),
    SAVINGS("03", "貯蓄"),
    RENTAL_INCOME_ETC("04", "家賃等収入"),
    SALES_BUSINESS_INCOME("05", "売上金／事業収入"),
    INVESTMENT_INCOME("06", "資産運用益"),
    ASSET_SALE_PROCEEDS("07", "資産売却資金"),
    OTHERS("99", "その他");
    companion object {
        fun getName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

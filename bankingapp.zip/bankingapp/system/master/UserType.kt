package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 利用者区分.
 */
enum class UserType(val code: String = "", val value: String = "") {
    INDIVIDUAL("0", "個人"),
    BUSINESS_REPRESENTATIVE("1", "事業先代表者"),
    BUSINESS_USER("2", "事業先利用者");
}

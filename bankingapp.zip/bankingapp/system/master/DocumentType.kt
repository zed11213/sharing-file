package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 書類種類.
 */
enum class DocumentType(val code: String, val value: String) {
    PERSONAL_SHOOT_SURFACE("01", "個人撮影（表面）"),
    PERSONAL_SHOOT_BACK("02", "個人撮影（裏面）"),
    PERSONAL_SHOOT_DIAGONAL("03", "個人撮影（斜め）"),
    PERSONAL_SHOOT_FACE("04", "個人撮影（顔）"),
    BLINK("05", "まばたき"),
    CERTIFICATE("06", "登記事項証明書");
}

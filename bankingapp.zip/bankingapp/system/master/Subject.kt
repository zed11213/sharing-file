package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 科目.
 */
enum class Subject(val code: String = "", val value: String = "") {
    COMPREHENSIVE_ACCOUNT("1", "総合口座"),
    ORDINARY_DEPOSIT("01", "普通預金"),
    CHECKING_ACCOUNT("02", "当座預金"),
    DEPOSIT_DEPOSIT("03", "通知預金"),
    TAX_DEPOSIT("05", "納税預金"),
    FIXED_SAVINGS("06", "定期預金"),
    INSTALLMENT("08", "定期積金");

    companion object {
        fun getSubjectName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

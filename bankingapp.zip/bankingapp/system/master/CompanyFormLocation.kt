package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 会社形態位置.
 */
enum class CompanyFormLocation(val code: String, val value: String) {
    BEFORE("01", "前"),
    AFTER("02", "後");

    companion object {
        fun getCompanyFormLocationName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

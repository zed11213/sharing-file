package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 課税区分.
 */
enum class Taxation(val code: String = "", val value: String = "") {
    SEPARATION("T01", "分離"),
    COMPREHENSIVE("T02", "総合");

    companion object {
        fun getTaxationName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

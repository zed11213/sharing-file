package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 本店所在地相違区分（個人事業主）.
 */
enum class HeadOfficeClassificationIndividualBusiness(val code: String, val value: String) {
    SAME_ADDRESS("01", "営業所等と同一住所"),
    DIFFERENT_ADDRESS("02", "営業所等と別住所");

    companion object {
        fun getHeadOfficeClassificationIndividualBusinessName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

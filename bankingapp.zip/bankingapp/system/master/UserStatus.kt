package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 会社形態.
 */
enum class UserStatus(val code: String, val value: String) {
    OK("0", "正常"),
    CONFIRMATION_PROGRESS("1", "確認中"),
    USE_STOP("2", "利用停止"),
    EXTRACTION_STOP("3", "利用登録待");

    companion object {
        fun getUserStatusName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

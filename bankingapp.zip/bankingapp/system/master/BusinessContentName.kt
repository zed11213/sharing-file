package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 業務内容（名称）.
 */
enum class BusinessContentName(val code: String, val value: String) {
    SALES("01", "営業"),
    GENERAL_AFFAIRS("02", "一般事務"),
    GENERAL_AFFAIRS_ACCOUNTING("03", "総務・経理"),
    PLANNING_AND_MANAGEMENT("04", "企画・管理"),
    MANUFACTURING_AND_DEVELOPMENT("05", "製造・開発"),
    OTHERS("99", "その他");

    companion object {
        fun getName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

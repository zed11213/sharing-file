package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 利用状況.
 */
enum class UtilizationStatus(val code: String, val value: String) {
    UNUSED("0", "未利用"),
    USING("1", "利用中");

    companion object {
        fun getUtilizationStatus(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

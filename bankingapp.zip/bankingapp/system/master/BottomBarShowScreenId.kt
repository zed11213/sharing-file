package jp.co.jsbank.mb.bankingapp.system.master

import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName

/**
 * 表示される画面ID取得する.
 */
enum class BottomBarShowScreenId(val code: String = "", val value: String = "") {
    SCREENID_HOME("HOME", RouteName.HOME),
    SCREENID_BALANCE("BALANCE", RouteName.BALANCE),
    SCREENID_HELP("HELP", RouteName.HELP),
    SCREENID_MENU("MENU", RouteName.MENU),
    SCREENID_MBST0101("MBST0101Page", RouteName.MBST0101Page),
    SCREENID_MBDP0101("MBDP0101Page", RouteName.MBDP0101Page),
    SCREENID_MBDP0201("MBDP0201Page/{data}", RouteName.MBDP0201Page),
    SCREENID_MBDP0301("MBDP0301Page/{data}", RouteName.MBDP0301Page),
    SCREENID_MBDP0401("MBDP0401Page/{data}", RouteName.MBDP0401Page),
    SCREENID_MBDP0501("MBDP0501Page/{data}", RouteName.MBDP0501Page),
    SCREENID_MBDP0701("MBDP0701Page/{data}", RouteName.MBDP0701Page),
    SCREENID_MBDP0901("MBDP0901Page/{data}", RouteName.MBDP0901Page),
    SCREENID_MBDP1101("MBDP1101Page/{data}", RouteName.MBDP1101Page),
    SCREENID_MBDR0101("MBDR0101Page/{data}", RouteName.MBDR0101Page),
    SCREENID_MBDR0201("MBDR0201Page/{data}", RouteName.MBDR0201Page),
    SCREENID_MBDR0301("MBDR0301Page/{data}", RouteName.MBDR0301Page),
    SCREENID_MBDR0401("MBDR0401Page/{data}", RouteName.MBDR0401Page),
    SCREENID_MBDR0501("MBDR0501Page/{data}", RouteName.MBDR0501Page),
    SCREENID_MBDR0601("MBDR0601Page/{data}", RouteName.MBDR0601Page),
    SCREENID_MBDR0701("MBDR0701Page/{data}", RouteName.MBDR0701Page),
    SCREENID_MBDR0801("MBDR0801Page/{data}", RouteName.MBDR0801Page),
    SCREENID_MBDR0901("MBDR0901Page/{data}", RouteName.MBDR0901Page),
    SCREENID_MBDR1001("MBDR1001Page/{data}", RouteName.MBDR1001Page),
    SCREENID_MBDR1101("MBDR1101Page/{data}", RouteName.MBDR1101Page),
    SCREENID_MBDR1201("MBDR1201Page/{data}", RouteName.MBDR1201Page),
    SCREENID_MBDR1301("MBDR1301Page/{data}", RouteName.MBDR1301Page),
    SCREENID_MBDR1401("MBDR1401Page/{data}", RouteName.MBDR1401Page),
    SCREENID_MBDR1501("MBDR1501Page/{data}", RouteName.MBDR1501Page),
    SCREENID_MBDR1601("MBDR1601Page/{data}", RouteName.MBDR1601Page),
    SCREENID_MBDR1701("MBDR1701Page/{data}", RouteName.MBDR1701Page),
    SCREENID_MBDR1801("MBDR1801Page/{data}", RouteName.MBDR1801Page),
    SCREENID_MBDR1901("MBDR1901Page", RouteName.MBDR1901Page),
    SCREENID_MBDR2101("MBDR2101Page/{data}", RouteName.MBDR2101Page),
    SCREENID_MBNT0101("MBNT0101Page/{data}", RouteName.MBNT0101Page),
    SCREENID_MBNT0201(
        "MBNT0201Page/{anncmntId}/{anncmntType}/{documentType}/{applyId}/{readFlag}/{confirmFlg}",
        RouteName.MBNT0201Page
    ),
    SCREENID_MBRC0101("MBRC0101Page", RouteName.MBRC0101Page),
    SCREENID_MBRC0202(
        "MBRC0202Page/{data}/{inputData}/{anncmntId}/{type}/{store}" +
            "/{param1}/{param2}/{param3}/{param4}/{param5}/{param6}",
        RouteName.MBRC0202Page
    ),
    SCREENID_MBRC0201(
        "MBRC0201Page/{data}",
        RouteName.MBRC0201Page
    ),
    SCREENID_MBRC0204("MBRC0204Page/{data}", RouteName.MBRC0204Page),
    SCREENID_MBRC0301("MBRC0301Page/{param1}/{param2}/{param3}/{param4}", RouteName.MBRC0301Page);

    companion object {
        fun getBottomBarShowScreenId(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

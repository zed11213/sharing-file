package jp.co.jsbank.mb.bankingapp.system.master

/**
 * Jag API 名称.
 */
enum class JagApiServiceCode(val code: String, val value: String) {
    AZ0901("AZ0901", "AZ0901"),
    AZ0903("AZ0903", "AZ0903"),
    AZ0906("AZ0906", "AZ0906"),
    AZ0911("AZ0911", "AZ0911"),
    AZ0913("AZ0913", "AZ0913"),
    APIGW("APIGW", "APIGW");
}

package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 取引のきっかけ.
 */
enum class TwoMillionMoreCashTransScheduled(val code: String, val value: String) {
    PLANNED("1", "予定あり"),
    NOT_SCHEDULED("2", "予定なし");
    companion object {
        fun getName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 上場/非上場.
 */
enum class PlayOrNotPlay(val code: String = "", val value: String = "") {
    PLAY("1", "上場"),
    NOT_PLAY("2", "非上場"),
    OTHER_THAN_A_CORPORATION("3", "株式会社以外");
    companion object {
        fun getName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 設定種別.
 */
enum class SettingType(val code: String, val value: String) {
    EMAIL("01", "メール通知設定"),
    PUSH("02", "Push通知設定"),
    PASSBOOK_PATTERN("03", "通帳パターン設定");

    companion object {
        fun getSettingType(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

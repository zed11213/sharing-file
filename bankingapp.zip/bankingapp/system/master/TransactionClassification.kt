package jp.co.jsbank.mb.bankingapp.system.master

/**
 * お取引区分.
 */
enum class TransactionClassification(val code: String, val value: String) {
    AUTOMATIC_CONTINUATION("1", "自動継続型"),
    VARIABLE("2", "変動型");

    companion object {
        fun getTransactionClassificationName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

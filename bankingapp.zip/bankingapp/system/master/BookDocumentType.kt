package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 文書種別.
 */
enum class BookDocumentType(val code: String = "", val value: String = "") {
    SUPER_DREAM_INTEREST_STATEMENT_SELF("01010", "スーパードリームお利息計算書（自継用）"),
    INFORMATION_ON_SUPER_DREAM_DATE("02010", "スーパードリーム期日のご案内"),
    INFORMATION_ON_DUE_DATES_NORMAL("03010", "定期預金等期日のご案内（規制金利 通常分）"),
    INFORMATION_ON_DUE_DATES_NORMAL_SWITCH_OVER_THREE_MILLION("03020", "定期預金等期日のご案内（規制金利 三百万以上切替）"),
    INFORMATION_ON_THE_MATURITY_OF_REGULAR_DEPOSITS("04010", "定期積金満期のご案内"),
    AUTOMATIC_RENEWAL_TIME_DEPOSIT_INTEREST_STATEMENT_AUTOMATIC_RENEWAL_PERIOD("05010", "自動継続定期預金お利息計算書（自動継続定期）"),
    AUTOMATIC_RENEWAL_FIXED_DEPOSIT_INTEREST_STATEMENT_LARGE_FIXED_TERM("06010", "自動継続定期預金お利息計算書（大口定期）"),
    INFORMATION_ON_DUE_DATES_NORMAL_FREE_INTEREST_RATE("07010", "定期預金等期日のご案内（自由金利 通常分）"),
    INFORMATION_ON_DUE_DATES_FREE_INTEREST_RATE_SUPER_TIME_SWITCHING("07020", "定期預金等期日のご案内（自由金利 スーパー定期切替）"),
    INFORMATION_ON_DUE_DATES_SWITCHING_FREE_INTEREST_RATES_OF_THREE_MILLION_OR_MORE(
        "07030", "定期預金等期日のご案内（自由金利 三百万以上切替）"
    ),
    INFORMATION_ON_DUE_DATES_AUTOMATIC_CONTINUATION_OF_FREE_INTEREST_RATES("07040", "定期預金等期日のご案内（自由金利 自動継続分）"),
    TO_CUSTOMERS_WHO_HAVE_FINISHED_BORROWING("08010", "お借入れが終了されたお客様へ"),
    NOTICE_OF_JONAN_GENERAL_ACCOUNT_SETTLEMENT_REGULAR("09010", "城南総合口座決算のお知らせ（通常分）"),
    NOTICE_OF_SETTLEMENT_OF_ACCOUNTS_OF_JONAN_GENERAL_SPORTS_CENTER_EXCESS_OF_THIS_LOAN_LIMIT(
        "09020",
        "城南総合口座決算のお知らせ（当貸限度超過分）"
    ),
    INFORMATION_ON_LOAN_DUE_DATE_DEPOSIT_COLLATERAL("10010", "ご融資金の期日のご案内（預金担保）"),
    INFORMATION_ON_LOAN_DUE_DATE_CREDIT("10020", "ご融資金の期日のご案内（信用）"),
    GUIDANCE_OF_THE_END_OF_THE_JONAN_AUTOMATIC_REMITTANCE_SERVICE_HANDLING_PERIOD_FIXED_TYPE(
        "11010",
        "城南自動送金サービス取扱期間終了のご案内（固定型）"
    ),
    GUIDANCE_OF_THE_END_OF_THE_JONAN_AUTOMATIC_REMITTANCE_SERVICE_HANDLING_PERIOD_IRREGULAR_TYPE(
        "11020",
        "城南自動送金サービス取扱期間終了のご案内（不定期型）"
    ),
    INFORMATION_ON_RECEIVING_PENSION_DEPOSITS("12010", "財形年金預金年金額お受取りのご案内"),
    CURRENT_ACCOUNT_COLLATION_TABLE("15010", "当座勘定照合表"),
    NOTIFICATION_OF_CURRENT_ACCOUNT_COLLATION_TABLE_AND_CURRENT_ACCOUNT_SETTLEMENT("16010", "当座勘定照合表兼当座勘定決算のお知らせ"),
    INFORMATION_ON_THE_SAFE_DEPOSIT_BOX_USAGE_FEE("17010", "貸金庫使用料期日のご案内"),
    DISCOUNTED_BILL_CALCULATION_SCHEDULE_GENERAL("18010", "割引手形計算明細表（一般）"),
    DISCOUNTED_BILL_CALCULATION_SCHEDULE_ELECTRIC_BOND("18020", "割引手形計算明細表（電債）"),
    PROPERTY_FORMATION_DEPOSIT_BALANCE_NOTIFICATION_FOR_CUSTOMERS("21010", "財産形成預金残高通知書（顧客分）"),
    PROPERTY_FORMATION_DEPOSIT_BALANCE_NOTIFICATION_FOR_STAFF("21020", "財産形成預金残高通知書（職員分）"),
    BUSINESS_PARTNER_NEW_ACCOUNT_OPENING_RECEPTION_SLIP("A1000", "事業先新規口座開設受付票"),
    MOBILE_APP_ATTRIBUTE_SPECIFICATION_MESSAGE("B1001", "モバイルアプリ属性指定メッセージ"),
    MOBILE_APP_CIF_DESIGNATED_MESSAGE("B1002", "モバイルアプリCIF指定メッセージ"),
    MAIL_ATTRIBUTE_SPECIFICATION_MESSAGE("B1003", "メール属性指定メッセージ"),
    EMAIL_CIF_SPECIFICATION_MESSAGE("B1004", "メールCIF指定メッセージ"),
    EASY_RECEPTION_INFORMATION("B2001", "かんたん受付案内"),
    EASY_RECEPTION_APPLICATION("B2002", "かんたん受付申込");

    companion object {
        fun getBookDocumentTypeName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

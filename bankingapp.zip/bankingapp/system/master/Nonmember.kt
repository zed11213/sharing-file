package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 電話番号種別.
 */
enum class Nonmember(val code: String, val value: String) {
    NO("1", "非会員"),
    YES("0", "会員");

    companion object {
        fun getNonmember(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 毎月の取引金額
 */
enum class MonthlyTransAmountNameList(val code: String = "", val value: String = "") {
    UNDER_10000_YEN("01", "１万円以下"),
    OVER_10000_YEN_TO_UNDER_50000_YEN("02", "１万円超～５万円以下"),
    OVER_50000_YEN_TO_UNDER_100000_YEN("03", "５万円超～１０万円以下"),
    OVER_100000_YEN_TO_UNDER_500000_YEN("04", "１０万円超～５０万円以下"),
    OVER_500000_YEN_TO_UNDER_1000000_YEN("05", "５０万円超～１００万円以下"),
    OVER_1_MILLION_YEN_TO_UNDER_5_MILLION_YEN("06", "１００万円超～５００万円以下"),
    OVER_5_MILLION_YEN_TO_UNDER_10_MILLION_YEN("07", "５００万円超～１０００万円以下"),
    OVER_10_MILLION_YEN("08", "１０００万円超");

    companion object {
        fun getName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

package jp.co.jsbank.mb.bankingapp.system.master

/**
 * メッセージ内容種別.
 */
enum class MobileMsgType(val code: String = "", val value: String = "") {
    NORMAL("01", "通常"),
    IMPORTANT("02", "重要"),
    INDIVIDUAL_CONFIRMATION_IMPORTANT_TREATMENT("03", "個別確認(重要扱い)");

    companion object {
        fun getMobileMsgTypeName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

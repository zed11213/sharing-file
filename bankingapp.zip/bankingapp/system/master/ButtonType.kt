package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 職業.
 */
enum class ButtonType(val code: String, val value: String) {
    DETAIL("01", "詳しくはこちら"),
    CLICK("02", "click"),
    START("03", "start"),
    ONLINE("04", "ONLINE 開始");

    companion object {
        fun getButtonName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

package jp.co.jsbank.mb.bankingapp.system.master

/**
 * 抽選区分.
 */
enum class LotteryClassification(val code: String, val value: String) {
    THIS_LOTTERY("0", "本抽"),
    GRATITUDE_AWARD("1", "感謝賞");

    companion object {
        fun getLotteryClassificationName(code: String): String {
            for (value in values()) {
                if (value.code == code) {
                    return value.value
                }
            }
            return ""
        }
    }
}

package jp.co.jsbank.mb.bankingapp.system

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.IntentFilter
import android.content.res.Configuration
import android.content.res.Resources
import android.net.ConnectivityManager
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.annotation.RequiresApi
import androidx.navigation.NavHostController
import com.google.accompanist.pager.ExperimentalPagerApi
import dagger.hilt.android.AndroidEntryPoint
import jp.co.jsbank.mb.bankingapp.theme.JsBankTheme
import jp.co.jsbank.mb.bankingapp.ui.pages.common.StartPage
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.utils.*
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.ACTIVITY_FLAG_NO_ACCESS_NO_LOGIN
import jp.co.jsbank.mb.bankingapp.utils.ToLoginUtil.openLogin
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.res.stringResource
import jp.co.jsbank.mb.bankingapp.system.liquidekyc.LiquidEkycHelper
import jp.co.jsbank.mb.bankingapp.ui.widgets.dialog.ImageBodyDialog
import jp.co.jsbank.mb.bankingapp.R
import java.util.*

@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    companion object {
        var NET_IS_CONNECT: Boolean = false

        // 活性化フラグ
        var ACTIVITY_FLAG: String = if (PreferenceUtil.getPreferenceStringValue(ConstUtil.ACTIVITY_FLAG)
            .isNullOrBlank()
        ) ACTIVITY_FLAG_NO_ACCESS_NO_LOGIN else
            PreferenceUtil.getPreferenceStringValue(ConstUtil.ACTIVITY_FLAG).toString()

        @SuppressLint("StaticFieldLeak")
        var ACTIVITY: Activity? = null

        // トップ情報タイマフラグ
        var TOP_INFO_TIMER_FLAG: Boolean = false

        // EKYCバックフラグ
        var IS_EKYC_BACK_FLAG: Boolean = false

        // EKYC 再撮影フラグ
        var IS_EKYC_SHOOT_AGAIN_FLAG: Boolean = false

        // トップ情報タイマ
        var TOP_INFO_TIMER: Timer = Timer()

        @SuppressLint("StaticFieldLeak")
        var NAVCTRL: NavHostController? = null

        // 復元処理API異常フラグ
        var RECOVERY_API_ERROR_FLAG: Boolean = false

        // 復元処理済みフラグ
        var HAS_RECOVERY_FLAG: Boolean = false

        // 復元処理戻るボタン表示フラグ
        var SHOW_RETURN_BUTTON_FLAG: Boolean = true

        // 復元画面ID
        var RECOVERY_ID: String = ""

        // BottomBarID
        var BOTTOMBAR_ID: String = ""

        // プッシュ通知API実行フラグ
        var PUSH_API_RUN_FLAG: Boolean = false

        // お知らせ重要情報あるかどうかフラグ
        var IS_ANNOUNCEMENTS_IMPORTANT_FLAG: Boolean = false

        // ホームページ情報リフレッシュフラグ
        var HOME_INFO_REFRESH_FLAG: Boolean = false

        // アプリ初期化フラグ
        var APP_RESTART_FLAG: Boolean = false

        // アプリ起動画面フラグ
        var APP_START_PAGE_FLAG: Boolean = false

        // パスワード画面からヘルプ画面へ
        var PASSWORD_TO_HELP_FLAG: Boolean = false

        // しらうめJネット支店表示位置（空白：表示しない　1:上　2:下）
        var STORE_SHOW_POSITION: String = ""

        // バックグラウンドフラグ
        var IS_BACK_GROUND: Boolean = false

        // バックグラウンド時間
        var BACK_GROUND_TIME: Date = Calendar.getInstance().time

        // メニューからCC発行
        var IS_MENU_CC_CARD: Boolean = false

        // AZ0911のエラーフラグ
        var AZ0911_ERROR_FLG: Boolean = false

        // API:レスポンス401場合、続きフラグ
        var API_401_RETRY_FLAG: Boolean = true

        // ログイン画面表示フラグ
        var LOGIN_PAGE_SHOW_FLAG: Boolean = false

        // ログアウトフラグ
        var LOG_OUT_FLAG: Boolean = false
    }

    // ===== eKYC SDK Flow =====
    private var ekycSorryFlg = mutableStateOf(false)
    private var ekycSorryMessage = mutableStateOf("")
    private lateinit var ekycHelper: LiquidEkycHelper

    fun startEkycFlow() = ekycHelper.startEkycFlow()

    private var mReceiver = IntentReceiverUtil()

    @OptIn(ExperimentalPagerApi::class)
    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ACTIVITY = this
//        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)

        // グローバル例外処理クラスの登録
        MyCrashHandler().getInstance()?.init(this)

        // eKYC helper
        ekycHelper = LiquidEkycHelper(this).apply {
            onSorryDialog = { message ->
                ekycSorryMessage.value = message
                ekycSorryFlg.value = true
            }
        }

        // メインページ
        setContent {
            JsBankTheme {
                // 起動画面
                StartPage()
            }

            // eKYC エラーダイアログ
            if (ekycSorryFlg.value) {
                ImageBodyDialog(
                    image = R.drawable.account_opening,
                    imageSize = 180,
                    title = stringResource(id = R.string.mbop0102_page_accountOpeningDialog_title),
                    content = ekycSorryMessage.value,
                    buttonLabel = stringResource(id = R.string.common_page_button_return),
                    copyright = true,
                    onButtonClick = {
                        ekycSorryFlg.value = false
                        RouteUtil.navTo(RouteName.MBSU0101Page)
                    }
                )
            }

            // 共通エラーダイアログ
            POPWindowsUtil.PopWin()

            // API呼び出しローディング画面
            LoadingUtil.Loading()

            // バージョン更新ダイアログ
            VersionUpdateUtil.PopWin()

            // バックグラウンドからログイン画面
            ToLoginUtil.PopWin()
        }
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK && (event?.repeatCount ?: 0) == 0) {
            return false
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onResume() {
        super.onResume()
        val mFilter = IntentFilter()
        mFilter.addAction(ConnectivityManager.CONNECTIVITY_ACTION)
        mReceiver = IntentReceiverUtil()
        registerReceiver(mReceiver, mFilter)

        // 一定時間(現状の想定は10分)経過後は、復帰後、ログイン画面を表示する
        val now = Calendar.getInstance().time
        val diff = now.time - BACK_GROUND_TIME.time
        val second = (diff / 1000 / 60)
        if ((
            second >= 10 &&
                PreferenceUtil.getPreferenceStringValue(ConstUtil.ACTIVITY_FLAG) == ConstUtil.ACTIVITY_FLAG_ACCESS_LOGIN
            ) && !IS_BACK_GROUND && !LOGIN_PAGE_SHOW_FLAG
        ) {
            IS_BACK_GROUND = true
            val biometricEnable = BiometricsUtil().checkBiometricAvailable()
            if (biometricEnable && PreferenceUtil.getPreferenceBooleanValue(ConstUtil.BIOLOGICAL_STATE)) {
                // 生体認証利用可能の場合、顔認証/指紋認証を呼び出して、ログインを行う
                if (!PreferenceUtil.getPreferenceBooleanValue(ConstUtil.EXECUTE_BACKGROUND_FLAG) && IS_BACK_GROUND) {
                    BiometricsUtil().biometricAuthenticate()
                }
            } else {
                openLogin("1")
            }
        }
    }

    override fun onPause() {
        super.onPause()
        Log.i("ekyc", "onPause")
        unregisterReceiver(mReceiver)
    }

    override fun onStop() {
        Log.i("ekyc", "onStop")
        super.onStop()
        BACK_GROUND_TIME = Calendar.getInstance().time
    }

//    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
//        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
//        if (requestCode == ConstUtil.PERMISSION_REQUEST_NOTIFICATION) {
//            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                PreferenceUtil.setPreferenceBooleanValue(NOTIFICATION_STATE, true)
//                // プッシュ通知登録
//                if (!JsBankFirebaseMessagingService().isNullFirebaseToken()) {
//                    val viewModel= ViewModelProvider(this)[MBLG0304Logic::class.java]
//                    viewModel?.pushInfoSignUp()
//                }
//
//                RouteUtil.navTo(RouteName.MBLG0301Page, ConstUtil.FROM_OTHER)
//            } else {
//                PreferenceUtil.setPreferenceBooleanValue(NOTIFICATION_STATE, false)
//                RouteUtil.navTo(RouteName.MBLG0301Page, ConstUtil.FROM_OTHER)
//            }
//        }
//    }
    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        Log.i("ekyc", "MainActivity onActivityResult: requestCode=$requestCode, resultCode=$resultCode")
        super.onActivityResult(requestCode, resultCode, data)
        ekycHelper.handleActivityResult(requestCode, resultCode, data)
    }

    override fun getResources(): Resources {
        val resources: Resources = super.getResources()
        val configuration = Configuration()
        configuration.setToDefaults()
        resources.updateConfiguration(configuration, resources.displayMetrics)
        return resources
    }

    override fun onDestroy() {
        Log.i("ekyc", "onDestroy")
        super.onDestroy()
    }
}

package jp.co.jsbank.mb.bankingapp.system

import android.annotation.SuppressLint
import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import android.os.Environment
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import androidx.security.crypto.MasterKeys.AES256_GCM_SPEC
import androidx.security.crypto.MasterKeys.getOrCreate
import dagger.hilt.android.HiltAndroidApp
import io.realm.Realm
import io.realm.RealmConfiguration
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.REALM_ENCRYPTION_KEY
import jp.co.jsbank.mb.bankingapp.utils.KeyStoreUtil
import jp.co.jsbank.mb.bankingapp.utils.LogPrintUtil
import jp.co.jsbank.mb.bankingapp.utils.PreferenceUtil
import java.io.File
import java.security.SecureRandom
import java.util.*

@HiltAndroidApp
class MyApp : Application() {

    companion object {
        @SuppressLint("StaticFieldLeak")
        lateinit var CONTEXT: Context
        lateinit var INSTANCE: Realm
        lateinit var FILES_DIRECTORY: String
        lateinit var DOWNLOAD_FILES_DIRECTORY: String
        lateinit var SHARED_PREFERENCES: SharedPreferences
        var SCREEN_HEIGHT: Int = 0
        var SCREEN_WIDTH: Int = 0
    }

    override fun onCreate() {
        super.onCreate()
        CONTEXT = this

        // パース取得
        FILES_DIRECTORY = this.filesDir.absolutePath
        DOWNLOAD_FILES_DIRECTORY =
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS).absolutePath +
            File.separator.toString()

        // EncryptedSharedPreferences初期化
        sharedPreferencesInit()

        // Realm初期化
        realmInit()

        // 画面サイズの取得
        val wm = this.getSystemService(WINDOW_SERVICE) as WindowManager
        val dm = DisplayMetrics()
        wm.defaultDisplay.getMetrics(dm)
        val width = dm.widthPixels
        val height = dm.heightPixels
        val density = dm.density
        val densityDpi = dm.densityDpi

        SCREEN_WIDTH = (width / density).toInt()
        SCREEN_HEIGHT = (height / density).toInt()
    }

    // EncryptedSharedPreferences初期化
    private fun sharedPreferencesInit() {
        val keyGenParameterSpec = AES256_GCM_SPEC
        val masterKeyAlias = getOrCreate(keyGenParameterSpec)
        SHARED_PREFERENCES = EncryptedSharedPreferences.create(
            this,
            "shared_preferences",
            MasterKey(this, masterKeyAlias),
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )

        // バージョンをEncryptedSharedPreferencesに保存する
        PreferenceUtil.setPreferenceStringValue("android_version", getVersionName())
    }

    // Realm初期化
    private fun realmInit() {
        Realm.init(this)
        val config = RealmConfiguration.Builder()
            .name(Config.REALM_DB_NAME)
            // Realm暗号化キーを設定する
            .encryptionKey(getSecureRealmKey())
            .schemaVersion(1)
            .deleteRealmIfMigrationNeeded()
            .build()
        INSTANCE = Realm.getInstance(config)
    }

    // バージョン取得
    private fun getVersionName(): String {
        val packageManager = packageManager
        val packInfo = packageManager.getPackageInfo(packageName, 0)
        return packInfo.versionName.toString()
    }

    private fun getSecureRealmKey(): ByteArray {
        if (!PreferenceUtil.getPreferenceBooleanValue(ConstUtil.OLD_REALM_INFO)) {
            val oldKeyStoreValue = KeyStoreUtil().getFromOldKeyStore(REALM_ENCRYPTION_KEY)
            if (oldKeyStoreValue.isNotBlank()) {
                KeyStoreUtil().saveToKeyStore(REALM_ENCRYPTION_KEY, oldKeyStoreValue)
                PreferenceUtil.setPreferenceBooleanValue(ConstUtil.OLD_REALM_INFO, true)
            }
        }
        return if (KeyStoreUtil().getFromKeyStore(REALM_ENCRYPTION_KEY).isBlank()) {
            createRealmKey()
        } else Base64.getDecoder().decode(KeyStoreUtil().getFromKeyStore(REALM_ENCRYPTION_KEY))
    }

    private fun createRealmKey(): ByteArray {
        val key = ByteArray(64)
        val secureRandom = SecureRandom()
        secureRandom.nextBytes(key)
        KeyStoreUtil().saveToKeyStore(REALM_ENCRYPTION_KEY, Base64.getEncoder().encodeToString(key))
        LogPrintUtil.error(Base64.getEncoder().encodeToString(key))
        return key
    }
}

package jp.co.jsbank.mb.bankingapp.system.ekyc;

public interface BundleKeyDefinitions {
    /**
     * 照合用 ID のキー文字列.
     */
    String APP_KEY_MATCHING_ID_RESULT = "APP_KEY_MATCHING_ID_RESULT";

    /**
     * 直接カメラ画面を起動するフラグ.
     */
    String APP_KEY_DIRECT_START_CAPTURE = "APP_KEY_DIRECT_START_CAPTURE";

    /**
     * 撮影タイプ.
     * ・免許証
     * ・マイナンバーカード
     * ・在留カード
     */
    String APP_KEY_CAPTURE_KIND = "APP_KEY_CAPTURE_KIND";

    /**
     * 手動シャッターか否かのフラグ.
     */
    String APP_KEY_IS_MANUAL = "APP_KEY_IS_MANUAL";

    /**
     * ユーザーキャンセルあり/なしを切り替えるフラグ.
     */
    String APP_KEY_USER_CANCEL = "APP_KEY_USER_CANCEL";
}

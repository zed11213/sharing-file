package jp.co.jsbank.mb.bankingapp.system.ekyc

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.KeyEvent
import androidx.annotation.NonNull
import androidx.appcompat.app.AppCompatActivity
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.system.MyApp.Companion.CONTEXT
import jp.co.jsbank.mb.bankingapp.system.master.DocumentKind
import jp.co.jsbank.mb.bankingapp.system.master.EkycCard
import jp.co.jsbank.mb.bankingapp.utils.*
import jp.co.polarify.onboarding.sdk.PolarifyKycSdkFactory
import jp.co.polarify.onboarding.sdk.types.callback.GetMatchingIDCallback
import jp.co.polarify.onboarding.sdk.types.internal.ErrorResult
import jp.co.polarify.onboarding.sdk.types.result.GetMatchingIDResult

/**
 * 起動時の画面アクティビティです.
 */
class EkycActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        if (savedInstanceState == null) {

            // EKYCサーバー初期化
            getMatchingID()

            // 書類種別の設定
            setCaptureConfig()

            // 画面初期化
            setFragment()
        }

        // PolarifyKycSdk の初期設定
        val factory = PolarifyKycSdkFactory()
        factory.getInstance(this)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK && (event?.repeatCount ?: 0) == 0) {
            return false
        }
        return super.onKeyDown(keyCode, event)
    }

    /**
     * EKYCサーバー初期化
     */
    private fun getMatchingID() {
        val factory = PolarifyKycSdkFactory()
        factory.getInstance(CONTEXT).getMatchingID(object : GetMatchingIDCallback {
            override fun onSuccess(@NonNull result: GetMatchingIDResult) {
                PreferenceManagerUtil.putGetMatchingIDResult(
                    CONTEXT,
                    BundleKeyDefinitions.APP_KEY_MATCHING_ID_RESULT, result
                )
            }

            override fun onError(@NonNull errorResult: ErrorResult) {
                // Release版でも通信エラーが分かるようにAndroid標準のトースト表示を行う
                showToast(errorResult.message)
            }
        })
    }

    /**
     * 自動/手動と書類種別の設定を行います.
     */
    private fun setCaptureConfig() {
        PreferenceManagerUtil.putBoolean(CONTEXT, BundleKeyDefinitions.APP_KEY_IS_MANUAL, true)
        PreferenceManagerUtil.putBoolean(CONTEXT, BundleKeyDefinitions.APP_KEY_USER_CANCEL, false)

        // マイナンバー
        if (PreferenceUtil.getPreferenceStringValue(ConstUtil.EKYC_CARD_TYPE) == EkycCard.MEMBER.toString()) {
            PreferenceManagerUtil.putInt(
                CONTEXT,
                BundleKeyDefinitions.APP_KEY_CAPTURE_KIND,
                DocumentKind.MY_NUMBER_CARD_OCR.ordinal
            )
        } else {
            PreferenceManagerUtil.putInt(
                CONTEXT,
                BundleKeyDefinitions.APP_KEY_CAPTURE_KIND,
                DocumentKind.DRIVER_LICENSE_CARD_OCR.ordinal
            )
        }
    }

    /**
     * チュートリアル画面を設定します.
     */
    private fun setFragment() {
        val intent = Intent(CONTEXT, TutorialActivity::class.java)
        startActivity(intent)
    }

    companion object {

        @SuppressLint("StaticFieldLeak")
        var instance: Activity? = null

        fun close() {
            MainActivity.IS_EKYC_BACK_FLAG = true
            val intent = Intent()
            intent.setClass(CONTEXT, MainActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            CONTEXT.startActivity(intent)
            instance?.finish()
        }
    }
}

package jp.co.jsbank.mb.bankingapp.utils

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.system.MainActivity.Companion.NET_IS_CONNECT
import jp.co.jsbank.mb.bankingapp.system.MyApp.Companion.CONTEXT

/**
 * ブロードキャスト.
 */
class IntentReceiverUtil : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == ConnectivityManager.CONNECTIVITY_ACTION) {
            NET_IS_CONNECT = !NetCheckUtil.isConnected(CONTEXT).not()
            if (!NET_IS_CONNECT) {
                if (MainActivity.APP_START_PAGE_FLAG) {
                    POPWindowsUtil.postValue(
                        MessageReplaceUtils.messageReplace(
                            CONTEXT.getString(R.string.JAG_MSG_ID_CD16),
                            ConstUtil.APP_ERROR_CODE_MBLO0003
                        )
                    )
                } else {
                    POPWindowsUtil.postValue(
                        MessageReplaceUtils.messageReplace(
                            CONTEXT.getString(R.string.JAG_MSG_ID_CD2),
                            ConstUtil.APP_ERROR_CODE_MBLO0001
                        )
                    )
                }
            }
        }
    }
}

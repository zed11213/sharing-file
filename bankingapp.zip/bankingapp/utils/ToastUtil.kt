package jp.co.jsbank.mb.bankingapp.utils

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.widget.Toast
import jp.co.jsbank.mb.bankingapp.system.MyApp.Companion.CONTEXT

private var mToast: Toast? = null

/**
 * トーストクラス.
 *
 * @param text 文字列
 */
fun showToast(text: String?) {
    showToast(context = CONTEXT, text = text)
}

fun showToast(context: Context = CONTEXT, text: String?) {
    if (TextUtils.isEmpty(text)) return
    if (Thread.currentThread() === Looper.getMainLooper().thread) {
        showToast(context, text, Toast.LENGTH_SHORT)
    } else {
        Handler(context.mainLooper).post { showToast(context, text, Toast.LENGTH_SHORT) }
    }
}

private fun showToast(context: Context? = CONTEXT, text: String?, duration: Int) {

//    cancelToast()
    if (mToast == null) {
        mToast = Toast.makeText(context, null as CharSequence?, duration)
    }
    mToast?.apply {
        setText(text)
        this.duration = duration
        show()
    }
}

fun cancelToast() {
    mToast?.cancel()
}

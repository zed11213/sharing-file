package jp.co.jsbank.mb.bankingapp.utils

import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.unit.dp
import jp.co.jsbank.mb.bankingapp.ui.widgets.barchart.BarChartData
import jp.co.jsbank.mb.bankingapp.ui.widgets.drawer.LabelDrawer
import jp.co.jsbank.mb.bankingapp.ui.widgets.drawer.XAxisDrawer
import kotlin.math.floor
import kotlin.math.log10
import kotlin.math.pow

internal object BarChartUtil {
    fun axisAreas(
        drawScope: DrawScope,
        totalSize: Size,
        xAxisDrawer: XAxisDrawer,
        labelDrawer: LabelDrawer
    ): Pair<Rect, Rect> = with(drawScope) {
        // yAxis
        val yAxisTop = labelDrawer.requiredAboveBarHeight(drawScope)

        // Either 50dp or 10% of the chart width.
        val yAxisRight = minOf(50.dp.toPx(), size.width * 10f / 100f)

        // xAxis
        val xAxisRight = totalSize.width - minOf(50.dp.toPx(), totalSize.width * 10f / 100f)

        // Measure the size of the text and line.
        val xAxisTop = totalSize.height - xAxisDrawer.requiredHeight(drawScope)

        return Pair(
//            Rect(yAxisRight, xAxisTop, xAxisRight, totalSize.height),
            Rect(0f, xAxisTop, xAxisRight, totalSize.height),
            Rect(0f, yAxisTop, yAxisRight, xAxisTop)
        )
    }

    fun barDrawableArea(xAxisArea: Rect): Rect {
        return Rect(
            left = xAxisArea.left,
            top = 0f,
            right = xAxisArea.right - 16,
            bottom = xAxisArea.top
        )
    }

    fun BarChartData.forEachWithArea(
        drawScope: DrawScope,
        barDrawableArea: Rect,
        progress: Float,
        labelDrawer: LabelDrawer,
        block: (barAreaList: List<Rect>, index: Int, balanceInfo: BarChartData.BalanceInfo) -> Unit
    ) {
        val totalBars = balanceInfoList.size
        val widthOfBarArea = barDrawableArea.width / totalBars

        balanceInfoList.forEachIndexed { index, bar ->
            val left = barDrawableArea.left + (index * widthOfBarArea)
            var newMaxValue = maxYValue
            if (maxYValue < 1 && (maxYValue * 10000) < 10) {
                newMaxValue = 9f
            }
            val labelCount = getStep(newMaxValue.toDouble())
            val average = getAxisStep(newMaxValue.toDouble()) * labelCount
            val height = (barDrawableArea.height / (labelCount)) * labelCount - 1

            var topDepositAmount = (bar.depositAmount.toFloat() / 10000 / average.toFloat()) * height
            var topInvestedAmount = (bar.investedAmount.toFloat() / 10000 / average.toFloat()) * height
            if (maxYValue < 1 && (maxYValue * 10000) < 10) {
                topDepositAmount = (bar.depositAmount.toFloat() / average.toFloat()) * height
                topInvestedAmount = (bar.investedAmount.toFloat() / average.toFloat()) * height
            }

            val rectList: List<Rect> = listOf(
                // 収入額
                Rect(
                    left = left + 25f,
                    top = barDrawableArea.bottom - topDepositAmount,
                    right = left + 40f,
                    bottom = barDrawableArea.bottom
                ),
                // 支出額
                Rect(
                    left = left + 50f,
                    top = barDrawableArea.bottom - topInvestedAmount,
                    right = left + 65f,
                    bottom = barDrawableArea.bottom
                ),
                // 選択線
//                Rect(
//                    left = left + 45f,
//                    top = barDrawableArea.top,
//                    right = left + 45f,
//                    bottom = barDrawableArea.bottom - (
//                        max(
//                            bar.investedAmount,
//                            bar.depositAmount
//                        ) / 10000 / average.toFloat()
//                        ) * height
//                )
            )

            block(rectList, index, bar)
        }
    }

    /**
     * グラフ間隔の計算.
     *
     * @param value パス
     */
    fun getAxisStep(value: Double): Double {
        // 指数
        val exponent: Double = 10.0.pow(floor(log10(value)))
        // 仮数
        val significand = value / exponent

        // グラフ間隔
        val axisStep: Double = when {
            significand < 1.2 -> {
                0.2 * exponent
            }
            significand < 3.0 -> {
                0.5 * exponent
            }
            significand <= 5.0 -> {
                1.0 * exponent
            }
            else -> {
                2.0 * exponent
            }
        }
        return axisStep
    }

    /**
     * グラフ間隔の数.
     *
     * @param value
     */
    fun getStep(value: Double): Int {
        var count = 1
        val axisStep = getAxisStep(value)
        for (i in 0..6) {
            if ((count * axisStep) <= value) {
                count += 1
            } else {
                break
            }
        }
        return count + 1
    }
}

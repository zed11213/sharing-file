package jp.co.jsbank.mb.bankingapp.utils

import android.os.Build
import android.security.keystore.KeyProperties
import androidx.annotation.RequiresApi
import com.google.android.gms.common.util.Base64Utils
import io.realm.Realm
import jp.co.jsbank.mb.bankingapp.repositories.db.common.create
import jp.co.jsbank.mb.bankingapp.repositories.db.common.deleteAll
import jp.co.jsbank.mb.bankingapp.repositories.db.common.findAll
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.PrivateKey
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.PublicKey
import jp.co.jsbank.mb.bankingapp.system.MyApp.Companion.FILES_DIRECTORY
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.CHARSET_UTF_8
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.JAG_CRYPT_TYPE_AES_CBC_PKCS5PADDING
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.JAG_CRYPT_TYPE_SHA256
import java.io.*
import java.security.*
import java.security.interfaces.RSAPrivateKey
import java.security.interfaces.RSAPublicKey
import java.security.spec.PKCS8EncodedKeySpec
import java.util.*
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

// RSA暗号化ツール
class RSAUtil {

    // 暗号化テキストの保存先
    private val encryptedDataFilePath =
        FILES_DIRECTORY + File.separator.toString()

    // 鍵ペアの生成と保存
    @RequiresApi(Build.VERSION_CODES.O)
    fun initKey() {
        // キーペアジェネレータ
        val generator = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_RSA)
        generator.initialize(2048, SecureRandom())
        // 鍵ペアの生成
        val keyPair = generator.generateKeyPair()
        // 公開鍵の生成と保存
        val publicKey: RSAPublicKey = keyPair.public as RSAPublicKey
        val publicKeyString = Base64.getEncoder().encodeToString(publicKey.encoded)
        val pubfw = FileWriter(encryptedDataFilePath + "publicKey.keystore")
        val pubbw = BufferedWriter(pubfw)
        pubbw.write(publicKeyString)
        pubbw.flush()
        pubbw.close()
        pubfw.close()
        // 秘密鍵の生成と保存
        val privateKey: RSAPrivateKey = keyPair.private as RSAPrivateKey
        val privateKeyString = Base64.getEncoder().encodeToString(privateKey.encoded)
        val prifw = FileWriter(encryptedDataFilePath + "privateKey.keystore")
        val pribw = BufferedWriter(prifw)
        pribw.write(privateKeyString)
        pribw.flush()
        pribw.close()
        prifw.close()
    }

    // 鍵ペアの生成と保存
    @RequiresApi(Build.VERSION_CODES.O)
    fun createNewKey(saveFlag: Boolean = false) {
        // ローカルに保存
        if (saveFlag) {
            val realm = Realm.getDefaultInstance()
            val publicKeyInfo = realm.findAll(PublicKey::class.java)
            val privateKeyInfo = realm.findAll(PrivateKey::class.java)
            val pubfw = FileWriter(encryptedDataFilePath + "publicKey.keystore")
            val prifw = FileWriter(encryptedDataFilePath + "privateKey.keystore")
            val pubbw = BufferedWriter(pubfw)
            val pribw = BufferedWriter(prifw)
            pubbw.write(publicKeyInfo[0]!!.publicKey)
            pubbw.flush()
            pubbw.close()
            pubfw.close()
            pribw.write(privateKeyInfo[0]!!.privateKey)
            pribw.flush()
            pribw.close()
            prifw.close()
        } else {
            val realm = Realm.getDefaultInstance()
            // キーペアジェネレータ
            val generator = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_RSA)
            generator.initialize(2048, SecureRandom())
            // 鍵ペアの生成
            val keyPair = generator.generateKeyPair()
            // 公開鍵の生成と保存
            val publicKey: RSAPublicKey = keyPair.public as RSAPublicKey
            val publicKeyString = Base64.getEncoder().encodeToString(publicKey.encoded)
            realm.deleteAll(PublicKey::class.java)
            val public = PublicKey()
            public.id = UUID.randomUUID().toString()
            public.publicKey = publicKeyString
            realm.create(public)
            // 秘密鍵の生成と保存
            val privateKey: RSAPrivateKey = keyPair.private as RSAPrivateKey
            val privateKeyString = Base64.getEncoder().encodeToString(privateKey.encoded)
            realm.deleteAll(PrivateKey::class.java)
            val private = PrivateKey()
            private.id = UUID.randomUUID().toString()
            private.privateKey = privateKeyString
            realm.create(private)
        }
    }

    // keystoreから公開鍵を取得する
    fun loadPublicKeyByFile(): String {
        return try {
            val br = BufferedReader(FileReader(encryptedDataFilePath + "publicKey.keystore"))
            var readLine: String
            val sb = StringBuilder()
            while (br.readLine().also { readLine = it ?: "" } != null) {
                sb.append(readLine)
            }
            br.close()
            sb.toString()
        } catch (e: Exception) {
            ""
        }
    }

    // keystoreから秘密鍵を取得する
    fun loadPrivateKeyByFile(): String {
        val br = BufferedReader(FileReader(encryptedDataFilePath + "privateKey.keystore"))
        var readLine: String
        val sb = StringBuilder()
        while (br.readLine().also { readLine = it ?: "" } != null) {
            sb.append(readLine)
        }
        br.close()
        return sb.toString()
    }

    // RSA秘密鍵復号化
    @RequiresApi(Build.VERSION_CODES.O)
    fun rsaDecrypt(cipherDataStr: String): String {
        // RSA秘密鍵の取得
        val privateKeyString = loadPrivateKeyByFile()
        val buffer = Base64.getDecoder().decode(privateKeyString)
        val keySpec = PKCS8EncodedKeySpec(buffer)
        val keyFactory = KeyFactory.getInstance(KeyProperties.KEY_ALGORITHM_RSA)
        val privateKey: RSAPrivateKey = keyFactory.generatePrivate(keySpec) as RSAPrivateKey
        // RSA秘密鍵復号化
        // 注意事項：固定値「RSA/ECB/PKCS1Padding」を定数に定義する場合、エラー
        val cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding")
        cipher.init(Cipher.DECRYPT_MODE, privateKey)
        val output = cipher.doFinal(Base64.getDecoder().decode(cipherDataStr))
        return String(output, charset(CHARSET_UTF_8))
    }

    /**
     *　AES(Advanced Encryption Standard)　によるブロック暗号化を実施する.
     * 適用アルゴリズム: AES/CBC/PKCS5Padding(128bit).
     *
     * @param inpStr 暗号化対象文字列.
     * @param secret シークレット文字.
     * @param salt  16進数文字(4文字).
     */
    fun encryptAESByJavaCrypt(inpStr: String, secret: String, salt: String): String {
        val iv: IvParameterSpec = getIvParameterSpecFromSalt(salt)
        val key: SecretKeySpec = getSecretSpecFromSecretKeyString(secret)
        // 暗号器と暗号モードを設定する.
        val encryp = Cipher.getInstance(JAG_CRYPT_TYPE_AES_CBC_PKCS5PADDING)
        encryp.init(Cipher.ENCRYPT_MODE, key, iv)
        // 暗号を実施する.
        val encBytes: ByteArray
        val inpBytes: ByteArray = inpStr.toByteArray()
        val base64Encoded: String = Base64.getEncoder().encodeToString(inpBytes)
        val inpBytesAgain: ByteArray = Base64Utils.decode(base64Encoded)

        // 暗号化.
        encBytes = encryp.doFinal(inpBytes)
        val encBase64: String = Base64.getEncoder().encodeToString(encBytes)
        val encBytesAgain: ByteArray = encBase64.toByteArray()

        return Base64.getEncoder().encodeToString(encBytes)
    }

    /**
     * SALT文字列からIvParameterSpecのインスタンスを取得する.
     *
     * 現状は以下の実装をもとに生成すること.
     *
     * @param salt
     * @return
     */
    private fun getIvParameterSpecFromSalt(salt: String): IvParameterSpec {
        val iv = ByteArray(16)
        try {
            // SHA256によるダイジェスト取得.
            val digest = MessageDigest.getInstance(JAG_CRYPT_TYPE_SHA256)
            digest.reset()
            digest.update(salt.toByteArray())
            val digestBytes = digest.digest() // 32byte取得される想定.

            // 検査する.
            if (digestBytes.size >= 16) {
                // 指定されたバイト数を取得する.
                for (i in iv.indices) iv[i] = digestBytes[i]
            }
        } catch (e: NoSuchAlgorithmException) {
            LogPrintUtil.error(e.message.toString())
        }
        return IvParameterSpec(iv)
    }

    /**
     * シークレット文字列からSecretKeySpecのインスタンスを取得する.
     * @param secret
     * @return
     */
    private fun getSecretSpecFromSecretKeyString(secret: String): SecretKeySpec {
        val secretKeyBytes: ByteArray = secret.toByteArray()
        return SecretKeySpec(secretKeyBytes, KeyProperties.KEY_ALGORITHM_AES)
    }
}

package jp.co.jsbank.mb.bankingapp.utils

import android.annotation.SuppressLint
import android.content.pm.ActivityInfo
import android.util.Log
import android.view.View
import android.view.WindowManager
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.Text
import androidx.compose.material.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.State
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.google.accompanist.systemuicontroller.rememberSystemUiController
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.locks.ReentrantLock
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.logic.common.ToLoginLogic
import jp.co.jsbank.mb.bankingapp.logic.login.mblg.mblg0101.MBLG0101Logic
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.theme.H6
import jp.co.jsbank.mb.bankingapp.theme.H7
import jp.co.jsbank.mb.bankingapp.theme.copyright_background_color
import jp.co.jsbank.mb.bankingapp.theme.general_background_color
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.PasswordButton
import jp.co.jsbank.mb.bankingapp.ui.widgets.copyright.Copyright
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * ログイン表示
 */
@SuppressLint("LogNotTimber")
object ToLoginUtil {
    private val queue = ConcurrentLinkedQueue<String>()
    private var msg = MutableStateFlow("")
    private val lock = ReentrantLock()
    private var title = ""
    val _sending = mutableStateOf(true)
    val sending: State<Boolean> = _sending

    /**
     * メッセージ内容設定
     */
    fun openLogin(value: String, parmTitle: String = "") {
        title = parmTitle
        queue.add(value)
        try {
            lock.tryLock(10, TimeUnit.MILLISECONDS)
        } catch (e: InterruptedException) {
            return
        }
        try {
            msg.value = queue.poll() ?: ""
        } finally {
            lock.unlock()
        }
    }

    @Composable
    fun PopWin() {
        PopItem()
    }

    @SuppressLint("UnrememberedMutableState")
    @OptIn(ExperimentalAnimationApi::class)
    @Composable
    private fun PopItem() {
        val viewModel: ToLoginLogic = hiltViewModel()
        val viewStates = viewModel.viewStates
        val msg by msg.collectAsState()

        if (msg != "") {
            viewModel.openErrorDialog()
        }
        if (viewStates.errorScreenFlag) {
            MBLG0101Page(viewModel)
        }
    }

    /**
     * MBLG0101画面
     *
     * @param viewModel MBLG0101のロジカル
     */
    @Composable
    fun MBLG0101Page(
        viewModel: ToLoginLogic,
    ) {
        val composableScope = rememberCoroutineScope()

        // ステータスバーの色の変更
        rememberSystemUiController().setStatusBarColor(Color.White)
        val viewStates = viewModel.viewStates
        if (MainActivity.ACTIVITY?.requestedOrientation == ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE) {
            viewStates.screenFlg = true
            PreferenceUtil.setPreferenceBooleanValue(ConstUtil.PAGE_NO_DESTROY_FLAG, true)
            MainActivity.ACTIVITY?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        }

        // 生体認証を呼び出す
//        LaunchedEffect(Unit) {
//            val rtn = viewModel.doBiometric()
//            if (rtn) {
//                openLogin("")
//                viewModel1.closeErrorDialog()
//            }
//        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.White)
        ) {
            // アプリバー
            TopAppBar(modifier = Modifier.weight(0.3f), backgroundColor = Color.White, elevation = 0.dp) {
                // ポリシー
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier
                        .padding(horizontal = 10.dp)
                        .fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier.clickable {
                            // MBLG0601画面（設定メニュー）へ遷移する
                            RouteUtil.navTo(
                                RouteName.MBLG0601Page
                            )
                            openLogin("")
                            viewModel.closeErrorDialog()
                        }
                    ) {
                        Row {
                            Image(
                                contentScale = ContentScale.Fit,
                                modifier = Modifier
                                    .size(20.dp)
                                    .padding(end = 2.dp),
                                painter = painterResource(id = R.drawable.warning_red_circle),
                                contentDescription = ""
                            )
                            Text(text = stringResource(R.string.mblg0101_topBar_left_button))
                        }
                    }
                    // ヘルプ
                    Box(
                        modifier = Modifier.clickable {
                            MainActivity.PASSWORD_TO_HELP_FLAG = true
                            RouteUtil.navTo(
                                RouteName.HELP
                            )
                            openLogin("")
                            viewModel.closeErrorDialog()
                        }
                    ) {
                        Row {
                            Text(
                                text = stringResource(R.string.mblg0101_topBar_right_button),
                                modifier = Modifier.padding(end = 10.dp)
                            )
                            Image(
                                contentScale = ContentScale.Fit,
                                modifier = Modifier.size(20.dp),
                                painter = painterResource(id = R.drawable.error_red_filled_circle),
                                contentDescription = ""
                            )
                        }
                    }
                }
            }
            // 会社ロゴ
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(0.5f),
                horizontalArrangement = Arrangement.Center
            ) {
                Image(
                    contentScale = ContentScale.FillWidth,
                    modifier = Modifier
                        .align(Alignment.CenterVertically)
                        .requiredWidth(200.dp),
                    painter = painterResource(id = R.drawable.splash_title),
                    contentDescription = ""
                )
            }
            // 文言：4桁のログインパスワードを入力してください。
            if (!viewStates.passwordErr) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp, 10.dp, 10.dp, 0.dp)
                        .weight(0.5f),
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(text = stringResource(R.string.mblg0101_help_message), fontSize = H7)
                }
            } else {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp, 10.dp, 10.dp, 0.dp)
                        .weight(1.2f)
                        .background(general_background_color),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 6.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = stringResource(R.string.MSG_ID_MB004003V),
                            color = Color.Red, fontSize = H6
                        )
                    }
                }
            }
            // パスワード入力
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1.0f),
                horizontalArrangement = Arrangement.Center
            ) {
                LazyRow(state = rememberLazyListState(), content = {
                    items(count = 4, itemContent = { index ->
                        Image(
                            contentScale = ContentScale.Fit,
                            modifier = Modifier
                                .align(Alignment.CenterVertically)
                                .size(70.dp),
                            painter = painterResource(
                                id = if (viewStates.password.length >= index + 1) {
                                    R.drawable.password_filled
                                } else {
                                    R.drawable.password_unfilled
                                }
                            ),
                            contentDescription = ""
                        )
                    })
                })
            }
            // パスワードボタン
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(4.5f),
                horizontalArrangement = Arrangement.Center
            ) {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    contentPadding = PaddingValues(25.dp, 0.dp, 25.dp, 25.dp),
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.SpaceAround
                ) {
                    items(12) { index ->
                        Box(modifier = Modifier.padding(horizontal = 25.dp)) {
                            when {
                                index < 9 -> {
                                    PasswordButton(
                                        text = "${index + 1}",
                                        onClick = {
                                            if (viewStates.password.length < 3) {
                                                viewModel.onPasswordChangeUnderThree(index + 1)
                                            }else if(viewStates.password.length == 3){
                                                //ボタン非活性化
                                                _sending.value = false
                                                composableScope.launch{
                                                    val rtn = viewModel.onPasswordChangeFour(index + 1)
                                                    withContext(Dispatchers.Default){
                                                        if(rtn){
                                                            openLogin("")
                                                            viewModel.closeErrorDialog()
                                                        }
                                                    }
                                                    //ボタン活性化
                                                    _sending.value = true
                                                }
                                            }
                                        },
                                        modifier = Modifier.requiredSize(60.dp)
                                    )
                                }
                                index == 9 -> {
                                    Box {}
                                }
                                index == 10 -> {
                                    PasswordButton(
                                        text = stringResource(R.string.mblg0101_number_zero),
                                        onClick = {
                                            if(viewStates.password.length < 3){
                                                viewModel.onPasswordChangeUnderThree(0)
                                            }else if(viewStates.password.length == 3){
                                                //ボタン非活性化
                                                _sending.value = false
                                                composableScope.launch{
                                                    withContext(Dispatchers.Default){
                                                        val rtn = viewModel.onPasswordChangeFour(0)
                                                        if(rtn){
                                                            openLogin("")
                                                            viewModel.closeErrorDialog()
                                                        }
                                                    }
                                                    _sending.value = true
                                                }
                                            }
                                        },
                                        modifier = Modifier.requiredSize(60.dp)
                                    )
                                }
                                else -> {
                                    Image(
                                        contentScale = ContentScale.Fit,
                                        modifier = Modifier
                                            .align(Alignment.Center)
                                            .requiredSize(60.dp)
                                            .clickable {
                                                viewModel.onPasswordDelete()
                                            },
                                        painter = painterResource(id = R.drawable.password_delete),
                                        contentDescription = ""
                                    )
                                }
                            }
                        }
                    }
                }
            }
            // パスワード忘れ
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(0.5f)
                    .clickable {
                        RouteUtil.navTo(
                            RouteName.WEB_VIEW_PAGE + WebConstUtil.WEB_VIEW_URL_CONST + WebConstUtil.WEB_VIEW_MBLG0101_PASSWORD_MISSED
                        )
                        openLogin("")
                        viewModel.closeErrorDialog()
                    },
                horizontalArrangement = Arrangement.Center
            ) {
                Image(
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .align(Alignment.CenterVertically)
                        .size(30.dp),
                    painter = painterResource(
                        id = R.drawable.error_red_unfilled_circle
                    ),
                    contentDescription = ""
                )
                Text(
                    text = stringResource(id = R.string.mblg0101_page_password_missed),
                    fontSize = H7,
                    modifier = Modifier.align(Alignment.CenterVertically)
                )
            }
            // Copyright
            Copyright(
                modifier = Modifier
                    .weight(0.3f)
                    .background(copyright_background_color)
            )
        }
    }
}

package jp.co.jsbank.mb.bankingapp.utils

import android.content.Intent
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG
import jp.co.jsbank.mb.bankingapp.system.BiometricsActivity
import jp.co.jsbank.mb.bankingapp.system.MyApp.Companion.CONTEXT

/**
 * 生体認証クラス.
 */
class BiometricsUtil {
    // アプリケーションが生体認証を使用できるかどうかを確認します
    fun checkBiometricAvailable(): Boolean {
        var errMsg: String
        val result = BiometricManager.from(CONTEXT)
            .canAuthenticate(BIOMETRIC_STRONG).apply {
                when (this) {
                    BiometricManager.BIOMETRIC_SUCCESS -> {
                        LogPrintUtil.debug("ユーザーは正常に認証できます。")
                    }
                    BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE -> {
                        errMsg = "生体認証エラー、" +
                            "適切なハードウェアがないので、ユーザーは認証することができません" +
                            "（例えばバイオメトリックセンサーやキーホルダーなど）"
                        LogPrintUtil.debug(errMsg)
                    }
                    BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE -> {
                        errMsg = "生体認証エラー、" +
                            "ハードウェアが利用できないので、ユーザは認証できません。後でもう一度試みてください。"
                        LogPrintUtil.debug(errMsg)
                    }
                    BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED -> {
                        errMsg = "生体認証エラー、" +
                            "バイオメトリックまたはデバイス資格情報が登録されていないため、ユーザーは認証できません。"
                        LogPrintUtil.debug(errMsg)
                    }
                    else -> {
                        errMsg = "予期しないエラーが発生しました"
                        LogPrintUtil.debug(errMsg)
                    }
                }
            }
        return result == BiometricManager.BIOMETRIC_SUCCESS
    }

    // 生体認証
    fun biometricAuthenticate() {
        if (checkBiometricAvailable()) {
            val intent = Intent()
            intent.setClass(CONTEXT, BiometricsActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            CONTEXT.startActivity(intent)
        }
    }
}

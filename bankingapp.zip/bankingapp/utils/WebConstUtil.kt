package jp.co.jsbank.mb.bankingapp.utils

/**
 * Web Url.
 */
object WebConstUtil {

    // URL定数
    const val WEB_VIEW_URL_CONST = "?url="

    // WEB HOST
    const val WEB_HOST = "jsapp.js-system.jp"

//    // 初回登録-MBSU0101-はじめまして画面-チャットボットアイコン
//    const val WEB_LINK_MBSU0101_CHATBOT = "https://jschatbot.js-system.jp/general"
//
//    // 初回登録（Biz）-MBSU0101-はじめまして画面-チャットボットアイコン
//    const val WEB_LINK_MBSU0101_BIZ_CHATBOT = "https://jschatbot.js-system.jp/biz"
//
//    // トップページ-HOME-トップページ-チャットボットアイコン
//    const val WEB_LINK_HOME_CHATBOT = "https://jsapp.js-system.jp/"
//
//    // 初回登録-MBSU0301-お客様情報入力-口座番号がわからない場合
//    const val WEB_VIEW_MBSU0301_ACCOUNT_NUMBER_UN_KNOW =
//        "https://jsapp.js-system.jp/new-registration/customer-info.html"
//
//    // 初回登録（Biz）-MBSU0303-法人情報入力-口座番号がわからない場合
//    const val WEB_VIEW_MBSU0303_ACCOUNT_NUMBER_UN_KNOW =
//        "https://jsapp.js-system.jp/new-registration/customer-info.html"
//
//    // 初回登録（Biz）-MBSU0307-個人事業主情報入力-口座番号がわからない場合
//    const val WEB_VIEW_MBSU0307_ACCOUNT_NUMBER_UN_KNOW =
//        "https://jsapp.js-system.jp/new-registration/customer-info.html"
//
//    // キャッシュカード発行-MBCC0401-情報入力-口座番号がわからない場合
//    const val WEB_VIEW_MBCC0401_ACCOUNT_NUMBER_UN_KNOW =
//        "https://jsapp.js-system.jp/new-registration/customer-info.html"
//
//    // 口座開設-MBOP0602-ご職業など-口座番号が分からない場合
//    const val WEB_VIEW_MBOP0602_ACCOUNT_NUMBER_UN_KNOW = "https://jsapp.js-system.jp/new-registration/occupation.html"
//
//    // 初回登録-MBSU0502-確認番号入力-メールが届かない場合はこちら
//    const val WEB_VIEW_MBSU0502_POST_CODE_UN_KNOW =
//        "https://jsapp.js-system.jp/new-registration/confirmation-number.html"
//
//    // 初回登録（Biz）-MBSU0502-確認番号入力-メールが届かない場合はこちら
//    const val WEB_VIEW_MBSU0502_BIZ_POST_CODE_UN_KNOW =
//        "https://jsapp.js-system.jp/new-registration-biz/confirmation-number.html"
//
//    // キャッシュカード発行-MBCO0202-確認番号入力-メールが届かない場合はこちら
//    const val WEB_VIEW_MBCO0202_CASH_CARD_POST_CODE_UN_KNOW =
//        "https://jsapp.js-system.jp/cashcard/confirmation-number.html"
//
//    // 口座開設-MBCO0202-確認番号入力-メールが届かない場合はこちら
//    const val WEB_VIEW_MBCO0202_OPEN_ACCOUNT_POST_CODE_UN_KNOW =
//        "https://jsapp.js-system.jp/account/confirmation-number.html"
//
//    // 口座開設（Biz）-MBCO0202-確認番号入力-メールが届かない場合はこちら
//    const val WEB_VIEW_MBCO0202_OPEN_ACCOUNT_BIZ_POST_CODE_UN_KNOW =
//        "https://jsapp.js-system.jp/account-biz/confirmation-number.html"
//
//    // ユーザー管理メニュー-MBST0401-メールアドレス変更-メールが届かない場合はこちら
//    const val WEB_VIEW_MBST0401_POST_CODE_UN_KNOW = "https://jsapp.js-system.jp/account-biz/email-change.html"
//
//    // ログイン-MBLG0101-ログイン-パスワード忘れ・ロックした場合
//    const val WEB_VIEW_MBLG0101_PASSWORD_MISSED = "https://jsapp.js-system.jp/login/login.html"
//
//    // 口座開設-MBOP0601-情報入力-旧姓をご希望のお客様
//    const val WEB_VIEW_MBOP0601_LAST_NAME_HELP = "https://jsapp.js-system.jp/account/info-enter.html"
//
//    // 口座開設（Biz）-MBOP0606-個人事業主情報入力１-旧姓をご希望のお客様
//    const val WEB_VIEW_MBOP0606_LAST_NAME_HELP = "https://jsapp.js-system.jp/account-biz/individual-info1.html"
//
//    // 口座開設-MBOP0702-希望店舗候補選択-インターネット支店について詳しくはこちら
//    const val WEB_VIEW_MBOP0702_INTERNET_SHOP_HELP = "https://jsapp.js-system.jp/account/select-branch.html"
//
//    // 口座開設-MBCO0601-インターネットバンキングのパスワード-インターネットバンキングのパスワードに関して
//    const val WEB_VIEW_MBCO0601_INTERNET_BANKING_PASSWORD_HELP =
//        "https://jsapp.js-system.jp/account/banking-password.html"
//
//    // 口座開設（Biz）-MBOP0604-法人情報入力２-実質的支配者についてはこちら
//    const val WEB_VIEW_MBOP0604_BENEFICIAL_OWNER_HELP = "https://jsapp.js-system.jp/account-biz/biz-info2.html"
//
//    // 口座開設-MBOP0301-規定-城南バンキングアプリ利用規定
//    const val WEB_VIEW_MBOP0301_TERMS_APP = "https://jsapp.js-system.jp/account/terms-app.html"
//
//    // 口座開設-MBOP0301-規定-口座開設に関する特約事項
//    const val WEB_VIEW_MBOP0301_TERMS_OPENING_ACCOUNT = "https://jsapp.js-system.jp/account/terms-opening-account.html"
//
//    // 口座開設-MBOP0301-規定-しらうめJネット支店取引規定
//    const val WEB_VIEW_MBOP0301_TERMS_SHIRAUME = "https://jsapp.js-system.jp/account/terms-shiraume.html"
//
//    // 口座開設-MBOP0301-規定-各種規定等について
//    const val WEB_VIEW_MBOP0301_TERMS_OTHERS = "https://jsapp.js-system.jp/account/terms-others.html"
//
//    // 口座開設-MBOP0301-規定-口座開設時のご注意事項
//    const val WEB_VIEW_MBOP0301_TERMS_FIRST_OPENING = "https://jsapp.js-system.jp/account/terms-first-opening.html"
//
//    // 口座開設-MBOP0301-規定-取引にあたっての承諾事項
//    const val WEB_VIEW_MBOP0301_TERMS_AGREEMENT = "https://jsapp.js-system.jp/account/terms-agreement.html"
//
//    // 口座開設-MBOP0301-規定-個人情報のお取扱いについて
//    const val WEB_VIEW_MBOP0301_TERMS_PRIVACY = "https://jsapp.js-system.jp/account/terms-privacy.html"
//
//    // 口座開設-MBOP0301-規定-キャッシュカードのご利用限度のご案内
//    const val WEB_VIEW_MBOP0301_TERMS_CASHCARD_LIMIT = "https://jsapp.js-system.jp/account/terms-cashcard-limit.html"
//
//    // 口座開設-MBOP0301-規定-インターネットバンキングお申込みのご案内
//    const val WEB_VIEW_MBOP0301_TERMS_EBANKING_APPLICATION =
//        "https://jsapp.js-system.jp/account/terms-ebanking-application.html"
//
//    // 口座開設-MBOP0301-規定-インターネットバンキング利用規定
//    const val WEB_VIEW_MBOP0301_TERMS_EBANKING_USE = "https://jsapp.js-system.jp/account/terms-ebanking-use.html"
//
//    // 口座開設-MBOP0301-規定-口座振替に関する注意事項
//    const val WEB_VIEW_MBOP0301_TERMS_ACCOUNT_TRANSFER =
//        "https://jsapp.js-system.jp/account/terms-account-transfer.html"
//
//    // 口座開設-MBOP0301-規定-ご留意事項
//    const val WEB_VIEW_MBOP0301_TERMS_NOTE = "https://jsapp.js-system.jp/account/terms-note.html"
//
//    // 口座開設-MBOP0301-規定-電子通帳規定
//    const val WEB_VIEW_MBOP0301_TERMS_EBANKBOOK = "https://jsapp.js-system.jp/account/terms-ebankbook.html"
//
//    // 口座開設-MBOP0301-規定-外国PEPs
//    const val WEB_VIEW_MBOP0301_TERMS_PEPS = "https://jsapp.js-system.jp/account/terms-foreign-peps.html"
//
//    // 口座開設-MBOP0301-規定-税法上の居住地国
//    const val WEB_VIEW_MBOP0301_TERMS_ADDRESS = "https://jsapp.js-system.jp/account/terms-residential-country.html"
//
//    // 口座開設-MBOP0301-規定-FATCAに定める米国納税義務者
//    const val WEB_VIEW_MBOP0301_TERMS_FATCA = "https://jsapp.js-system.jp/account/terms-fatca-tax.html"
//
//    // 口座開設（Biz）-MBOP0301-規定（事業先用）-城南バンキングアプリ利用規定
//    const val WEB_VIEW_MBOP0301_BIZ_TERMS_APP = "https://jsapp.js-system.jp/account-biz/terms-app.html"
//
//    // 口座開設（Biz）-MBOP0301-規定（事業先用）-口座開設に関する特約事項
//    const val WEB_VIEW_MBOP0301_BIZ_TERMS_OPENING_ACCOUNT =
//        "https://jsapp.js-system.jp/account-biz/terms-opening-account.html"
//
//    // 口座開設（Biz）-MBOP0301-規定（事業先用）-各種規定等について
//    const val WEB_VIEW_MBOP0301_BIZ_TERMS_OTHERS = "https://jsapp.js-system.jp/account-biz/terms-others.html"
//
//    // 口座開設（Biz）-MBOP0301-規定（事業先用）-口座開設時のご注意事項
//    const val WEB_VIEW_MBOP0301_BIZ_TERMS_FIRST_OPENING =
//        "https://jsapp.js-system.jp/account-biz/terms-first-opening.html"
//
//    // 口座開設（Biz）-MBOP0301-規定（事業先用）-取引にあたっての承諾事項
//    const val WEB_VIEW_MBOP0301_BIZ_TERMS_AGREEMENT = "https://jsapp.js-system.jp/account-biz/terms-agreement.html"
//
//    // 口座開設（Biz）-MBOP0301-規定（事業先用）-個人情報のお取扱いについて
//    const val WEB_VIEW_MBOP0301_BIZ_TERMS_PRIVACY = "https://jsapp.js-system.jp/account-biz/terms-privacy.html"
//
//    // 口座開設（Biz）-MBOP0301-規定（事業先用）-キャッシュカードのご利用限度のご案内
//    const val WEB_VIEW_MBOP0301_BIZ_TERMS_CASHCARD_LIMIT =
//        "https://jsapp.js-system.jp/account-biz/terms-cashcard-limit.html"
//
//    // 口座開設（Biz）-MBOP0301-規定（事業先用）-インターネットバンキングお申込みのご案内
//    const val WEB_VIEW_MBOP0301_BIZ_TERMS_EBANKING_APPLICATION =
//        "https://jsapp.js-system.jp/account-biz/terms-ebanking-application.html"
//
//    // 口座開設（Biz）-MBOP0301-規定（事業先用）-インターネットバンキング利用規定
//    const val WEB_VIEW_MBOP0301_BIZ_TERMS_EBANKING_USE =
//        "https://jsapp.js-system.jp/account-biz/terms-ebanking-use.html"
//
//    // 口座開設（Biz）-MBOP0301-規定（事業先用）-口座振替に関する注意事項
//    const val WEB_VIEW_MBOP0301_BIZ_TERMS_ACCOUNT_TRANSFER =
//        "https://jsapp.js-system.jp/account-biz/terms-account-transfer.html"
//
//    // 口座開設（Biz）-MBOP0301-規定（事業先用）-ご留意事項
//    const val WEB_VIEW_MBOP0301_BIZ_TERMS_NOTE = "https://jsapp.js-system.jp/account-biz/terms-note.html"
//
//    // 口座開設（Biz）-MBOP0301-規定（事業先用）-電子通帳規定
//    const val WEB_VIEW_MBOP0301_BIZ_TERMS_EBANKBOOK = "https://jsapp.js-system.jp/account-biz/terms-ebankbook.html"
//
//    // メニュー-MBST1501-利用規定-城南バンキングアプリ利用規定
//    const val WEB_VIEW_MBST1501_TERMS_APP = "https://jsapp.js-system.jp/menu/terms-app.html"
//
//    // メニュー-MBST1701-個人情報のお取り扱いについて-城南バンキングアプリプライバシーポリシー
//    const val WEB_VIEW_MBST1701_PRIVACY = "https://jsapp.js-system.jp/menu/privacy.html"
//
//    // お困りの時-HELP-お困りの時-スマートフォンの機種変更を行なった際の操作方法について
//    const val WEB_VIEW_HELP_DEVICE_CHANGE = "https://jsapp.js-system.jp/faq.html"
//
//    // お困りの時-HELP-お困りの時-口座を追加したい
//    const val WEB_VIEW_HELP_NEW_ACCOUNT = "https://jsapp.js-system.jp/faq/new-account.html"
//
//    // お困りの時-HELP-お困りの時-本人確認書類で利用可能なものは？
//    const val WEB_VIEW_HELP_AVAILABLE_IDS = "https://jsapp.js-system.jp/faq/available-ids.html"
//
//    // お困りの時-HELP-お困りの時-証書を検索したい
//    const val WEB_VIEW_HELP_SEARCH_CERTIFICATE = "https://jsapp.js-system.jp/faq/search-certificate.html"
//
//    // お困りの時-HELP-お困りの時-セミナーの申込みについて
//    const val WEB_VIEW_HELP_SEMINAR_APPLICATION = "https://jsapp.js-system.jp/faq/seminar-application.html"
//
//    // お困りの時-HELP-お困りの時-ログインパスワードの変更
//    const val WEB_VIEW_HELP_CHANGE_PASSWORD = "https://jsapp.js-system.jp/faq/change-password.html"
//
//    // 電子通帳証書-MBDP0701-定期預金-懸賞金(品)の受け取り方について
//    const val WEB_VIEW_MBDP0701_TIME_DEPOSIT = "https://jsapp.js-system.jp/ecertificate/time-deposit.html"
//
//    // 電子交付-MBDR0201-スーパードリーム期日のご案内-懸賞金(品)の受け取り方について
//    const val WEB_VIEW_MBDR0201_SUPERDREAM_DUE = "https://jsapp.js-system.jp/edelivery/superdream-due.html"
//
//    // 電子交付-MBDR0101-スーパードリームお利息計算書（兼新抽せん番号通知書）-懸賞金(品)の受け取り方について
//    const val WEB_VIEW_MBDR0101_SUPERDREAM_INTEREST = "https://jsapp.js-system.jp/edelivery/superdream-interest.html"
//
//    // ログイン-MBLG0101-ログイン画面-ヘルプ
//    const val WEB_VIEW_MBLG0101_HELP = "https://jsapp.js-system.jp/login/help.html"
//
//    // 城南信用金庫ホームページ
// //akiya    const val HOME_PAGE = "https://jsapp.js-system.jp/app"
//    const val HOME_PAGE = "https://www.jsbank.co.jp"
//
//    // 外部リンク(郵便番号がわからない場合)
// //akiya    const val WEB_VIEW_POST_CODE = "https://jsapp.js-system.jp/account/about-postal.html"
//    const val WEB_VIEW_POST_CODE = "https://www.post.japanpost.jp/zipcode/"
//
//    // 個別郵便番号について
//    const val WEB_VIEW_INDIVIDUAL_POST_CODE = "https://jsapp.js-system.jp/account/about-postal.html"
//
//    // ご職業など-口座番号が分からない場合
// //akiya    const val WEB_VIEW_OPEN_ACCOUNT_NUMBER_HELP = "https://www.post.japanpost.jp/zipcode/"
//    const val WEB_VIEW_OPEN_ACCOUNT_NUMBER_HELP = "https://jsapp.js-system.jp/new-registration/customer-info.html"
//
//    // WebView(ライセンス表示)
//    const val WEB_VIEW_LICENSE = "https://jsbank.co.jp/jnet/index.html#app"
//
//    // iDeCoへのリンク
//    const val WEB_VIEW_IDECO = "https://jsapp.js-system.jp/ideco.html"
//
//    // 旧字体漢字について
//    const val WEB_VIEW_HELP_STYLE = "https://jsapp.js-system.jp/account/style-kanji.html"
//
//    // 建物名の記載について
//    const val WEB_VIEW_HELP_ABOUT_NAME = "https://jsapp.js-system.jp/account/about-name.html"

    // [J42] 初回登録-MBSU0101-はじめまして画面-チャットボットアイコン
    // 旧URL: [O] https://jschatbot.js-system.jp/general
    const val WEB_LINK_MBSU0101_CHATBOT = "https://tool.tetory.io/form/?tenantId=t0013"

    // [J41] 初回登録（Biz）-MBSU0101-はじめまして画面-チャットボットアイコン
    // 旧URL: [O] https://jschatbot.js-system.jp/biz
    const val WEB_LINK_MBSU0101_BIZ_CHATBOT = "https://tool.tetory.io/form/?tenantId=t0013"

    // [J42] トップページ-HOME-トップページ-チャットボットアイコン
    // 旧URL: [X] https://jsapp.js-system.jp/
    const val WEB_LINK_HOME_CHATBOT = "https://tool.tetory.io/form/?tenantId=t0013"

    // [J38] 初回登録-MBSU0301-お客様情報入力-口座番号がわからない場合
    // 旧URL: [O] https://jsapp.js-system.jp/new-registration/customer-info.html
    const val WEB_VIEW_MBSU0301_ACCOUNT_NUMBER_UN_KNOW = "https://jsapp.js-system.jp/new-registration/customer-info.html"

    // [J38] 初回登録（Biz）-MBSU0303-法人情報入力-口座番号がわからない場合
    // 旧URL: [O] https://jsapp.js-system.jp/new-registration/customer-info.html
    const val WEB_VIEW_MBSU0303_ACCOUNT_NUMBER_UN_KNOW = "https://jsapp.js-system.jp/new-registration/customer-info.html"

    // [J38] 初回登録（Biz）-MBSU0307-個人事業主情報入力-口座番号がわからない場合
    // 旧URL: [O] https://jsapp.js-system.jp/new-registration/customer-info.html
    const val WEB_VIEW_MBSU0307_ACCOUNT_NUMBER_UN_KNOW = "https://jsapp.js-system.jp/new-registration/customer-info.html"

    // [J38] キャッシュカード発行-MBCC0401-情報入力-口座番号がわからない場合
    // 旧URL: [O] https://jsapp.js-system.jp/new-registration/customer-info.html
    const val WEB_VIEW_MBCC0401_ACCOUNT_NUMBER_UN_KNOW = "https://jsapp.js-system.jp/new-registration/customer-info.html"

    // [J39] 口座開設-MBOP0602-ご職業など-口座番号が分からない場合
    // 旧URL: [O] https://jsapp.js-system.jp/new-registration/occupation.html
    const val WEB_VIEW_MBOP0602_ACCOUNT_NUMBER_UN_KNOW = "https://jsapp.js-system.jp/new-registration/occupation.html"

    // [J37] 初回登録-MBSU0502-確認番号入力-メールが届かない場合はこちら
    // 旧URL: [O] https://jsapp.js-system.jp/new-registration/confirmation-number.html
    const val WEB_VIEW_MBSU0502_POST_CODE_UN_KNOW = "https://jsapp.js-system.jp/new-registration/confirmation-number.html"

    // [J37] 初回登録（Biz）-MBSU0502-確認番号入力-メールが届かない場合はこちら
    // 旧URL: [X] https://jsapp.js-system.jp/new-registration-biz/confirmation-number.html
    const val WEB_VIEW_MBSU0502_BIZ_POST_CODE_UN_KNOW = "https://jsapp.js-system.jp/new-registration/confirmation-number.html"

    // [J37] キャッシュカード発行-MBCO0202-確認番号入力-メールが届かない場合はこちら
    // 旧URL: [X] https://jsapp.js-system.jp/cashcard/confirmation-number.html
    const val WEB_VIEW_MBCO0202_CASH_CARD_POST_CODE_UN_KNOW = "https://jsapp.js-system.jp/new-registration/confirmation-number.html"

    // [J37] 口座開設-MBCO0202-確認番号入力-メールが届かない場合はこちら
    // 旧URL: [X] https://jsapp.js-system.jp/account/confirmation-number.html
    const val WEB_VIEW_MBCO0202_OPEN_ACCOUNT_POST_CODE_UN_KNOW = "https://jsapp.js-system.jp/new-registration/confirmation-number.html"

    // [J37] 口座開設（Biz）-MBCO0202-確認番号入力-メールが届かない場合はこちら
    // 旧URL: [X] https://jsapp.js-system.jp/account-biz/confirmation-number.html
    const val WEB_VIEW_MBCO0202_OPEN_ACCOUNT_BIZ_POST_CODE_UN_KNOW = "https://jsapp.js-system.jp/new-registration/confirmation-number.html"

    // [J37] ユーザー管理メニュー-MBST0401-メールアドレス変更-メールが届かない場合はこちら
    // 旧URL: [X] https://jsapp.js-system.jp/account-biz/email-change.html
    const val WEB_VIEW_MBST0401_POST_CODE_UN_KNOW = "https://jsapp.js-system.jp/new-registration/confirmation-number.html"

    // [J34] ログイン-MBLG0101-ログイン-パスワード忘れ・ロックした場合
    // 旧URL: [O] https://jsapp.js-system.jp/login/login.html
    const val WEB_VIEW_MBLG0101_PASSWORD_MISSED = "https://jsapp.js-system.jp/login/login.html"

    // [J09] 口座開設-MBOP0601-情報入力-旧姓をご希望のお客様
    // 旧URL: [O] https://jsapp.js-system.jp/account/info-enter.html
    const val WEB_VIEW_MBOP0601_LAST_NAME_HELP = "https://jsapp.js-system.jp/account/info-enter.html"

    // [J09] 口座開設（Biz）-MBOP0606-個人事業主情報入力１-旧姓をご希望のお客様
    // 旧URL: [X] https://jsapp.js-system.jp/account-biz/individual-info1.html
    const val WEB_VIEW_MBOP0606_LAST_NAME_HELP = "https://jsapp.js-system.jp/account/info-enter.html"

    // [J10] 口座開設-MBOP0702-希望店舗候補選択-インターネット支店について詳しくはこちら
    // 旧URL: [O] https://jsapp.js-system.jp/account/select-branch.html
    const val WEB_VIEW_MBOP0702_INTERNET_SHOP_HELP = "https://jsapp.js-system.jp/account/select-branch.html"

    // [J08] 口座開設-MBCO0601-インターネットバンキングのパスワード-インターネットバンキングのパスワードに関して
    // 旧URL: [O] https://jsapp.js-system.jp/account/banking-password.html
    const val WEB_VIEW_MBCO0601_INTERNET_BANKING_PASSWORD_HELP = "https://jsapp.js-system.jp/account/banking-password.html"

    // [J01] 口座開設（Biz）-MBOP0604-法人情報入力２-実質的支配者についてはこちら
    // 旧URL: [O] https://jsapp.js-system.jp/account-biz/biz-info2.html
    const val WEB_VIEW_MBOP0604_BENEFICIAL_OWNER_HELP = "https://jsapp.js-system.jp/account-biz/biz-info2.html"

    // [J14] 口座開設-MBOP0301-規定-城南バンキングアプリ利用規定
    // 旧URL: [X] https://jsapp.js-system.jp/account/terms-app.html
    const val WEB_VIEW_MBOP0301_TERMS_APP = "https://jsapp.js-system.jp/account/terms-app.html"

    // [J23] 口座開設-MBOP0301-規定-口座開設に関する特約事項
    // 旧URL: [X] https://jsapp.js-system.jp/account/terms-opening-account.html
    const val WEB_VIEW_MBOP0301_TERMS_OPENING_ACCOUNT = "https://jsapp.js-system.jp/account/terms-opening-account.html"

    // [J27] 口座開設-MBOP0301-規定-しらうめJネット支店取引規定
    // 旧URL: [X] https://jsapp.js-system.jp/account/terms-shiraume.html
    const val WEB_VIEW_MBOP0301_TERMS_SHIRAUME = "https://jsapp.js-system.jp/account/terms-shiraume.html"

    // [J24] 口座開設-MBOP0301-規定-各種規定等について
    // 旧URL: [X] https://jsapp.js-system.jp/account/terms-others.html
    const val WEB_VIEW_MBOP0301_TERMS_OTHERS = "https://jsapp.js-system.jp/account/terms-others.html"

    // [J20] 口座開設-MBOP0301-規定-口座開設時のご注意事項
    // 旧URL: [X] https://jsapp.js-system.jp/account/terms-first-opening.html
    const val WEB_VIEW_MBOP0301_TERMS_FIRST_OPENING = "https://jsapp.js-system.jp/account/terms-first-opening.html"

    // [J13] 口座開設-MBOP0301-規定-取引にあたっての承諾事項
    // 旧URL: [X] https://jsapp.js-system.jp/account/terms-agreement.html
    const val WEB_VIEW_MBOP0301_TERMS_AGREEMENT = "https://jsapp.js-system.jp/account/terms-agreement.html"

    // [J25] 口座開設-MBOP0301-規定-個人情報のお取扱いについて
    // 旧URL: [X] https://jsapp.js-system.jp/account/terms-privacy.html
    const val WEB_VIEW_MBOP0301_TERMS_PRIVACY = "https://jsapp.js-system.jp/account/terms-privacy.html"

    // [J15] 口座開設-MBOP0301-規定-キャッシュカードのご利用限度のご案内
    // 旧URL: [X] https://jsapp.js-system.jp/account/terms-cashcard-limit.html
    const val WEB_VIEW_MBOP0301_TERMS_CASHCARD_LIMIT = "https://jsapp.js-system.jp/account/terms-cashcard-limit.html"

    // [J17] 口座開設-MBOP0301-規定-インターネットバンキングお申込みのご案内
    // 旧URL: [X] https://jsapp.js-system.jp/account/terms-ebanking-application.html
    const val WEB_VIEW_MBOP0301_TERMS_EBANKING_APPLICATION = "https://jsapp.js-system.jp/account/terms-ebanking-application.html"

    // [J18] 口座開設-MBOP0301-規定-インターネットバンキング利用規定
    // 旧URL: [X] https://jsapp.js-system.jp/account/terms-ebanking-use.html
    const val WEB_VIEW_MBOP0301_TERMS_EBANKING_USE = "https://jsapp.js-system.jp/account/terms-ebanking-use.html"

    // [J12] 口座開設-MBOP0301-規定-口座振替に関する注意事項
    // 旧URL: [X] https://jsapp.js-system.jp/account/terms-account-transfer.html
    const val WEB_VIEW_MBOP0301_TERMS_ACCOUNT_TRANSFER = "https://jsapp.js-system.jp/account/terms-account-transfer.html"

    // [J22] 口座開設-MBOP0301-規定-ご留意事項
    // 旧URL: [X] https://jsapp.js-system.jp/account/terms-note.html
    const val WEB_VIEW_MBOP0301_TERMS_NOTE = "https://jsapp.js-system.jp/account/terms-note.html"

    // [J16] 口座開設-MBOP0301-規定-電子通帳規定
    // 旧URL: [X] https://jsapp.js-system.jp/account/terms-ebankbook.html
    const val WEB_VIEW_MBOP0301_TERMS_EBANKBOOK = "https://jsapp.js-system.jp/account/terms-ebankbook.html"

    // [J21] 口座開設-MBOP0301-規定-外国PEPs
    // 旧URL: [X] https://jsapp.js-system.jp/account/terms-foreign-peps.html
    const val WEB_VIEW_MBOP0301_TERMS_PEPS = "https://jsapp.js-system.jp/account/terms-foreign-peps.html"

    // [J26] 口座開設-MBOP0301-規定-税法上の居住地国
    // 旧URL: [X] https://jsapp.js-system.jp/account/terms-residential-country.html
    const val WEB_VIEW_MBOP0301_TERMS_ADDRESS = "https://jsapp.js-system.jp/account/terms-residential-country.html"

    // [J19] 口座開設-MBOP0301-規定-FATCAに定める米国納税義務者
    // 旧URL: [X] https://jsapp.js-system.jp/account/terms-fatca-tax.html
    const val WEB_VIEW_MBOP0301_TERMS_FATCA = "https://jsapp.js-system.jp/account/terms-fatca-tax.html"

    // [J19] 口座開設-MBOP0301-規定-預貯金口座付番の手続について
    // 旧URL: [X] file:///android_asset/Account_Management_Law.html
    const val WEB_VIEW_MBOP0301_TERMS_MANAGEMENT_LAW = "file:///android_asset/Account_Management_Law.html"

    // [J02] 口座開設（Biz）-MBOP0301-規定（事業先用）-城南バンキングアプリ利用規定
    // 旧URL: [X] https://jsapp.js-system.jp/account-biz/terms-app.html
//    const val WEB_VIEW_MBOP0301_BIZ_TERMS_APP = "https://jsapp.js-system.jp/account-biz/terms-app.html"
    const val WEB_VIEW_MBOP0301_BIZ_TERMS_APP = "https://jsapp.js-system.jp/account-biz/terms-biz.html"

    // [J23] 口座開設（Biz）-MBOP0301-規定（事業先用）-口座開設に関する特約事項
    // 旧URL: [X] https://jsapp.js-system.jp/account-biz/terms-opening-account.html
    const val WEB_VIEW_MBOP0301_BIZ_TERMS_OPENING_ACCOUNT = "https://jsapp.js-system.jp/account/terms-opening-account.html"

    // [J04] 口座開設（Biz）-MBOP0301-規定（事業先用）-各種規定等について
    // 旧URL: [X] https://jsapp.js-system.jp/account-biz/terms-others.html
    const val WEB_VIEW_MBOP0301_BIZ_TERMS_OTHERS = "https://jsapp.js-system.jp/account-biz/terms-others.html"

    // [J20] 口座開設（Biz）-MBOP0301-規定（事業先用）-口座開設時のご注意事項
    // 旧URL: [X] https://jsapp.js-system.jp/account-biz/terms-first-opening.html
    const val WEB_VIEW_MBOP0301_BIZ_TERMS_FIRST_OPENING = "https://jsapp.js-system.jp/account/terms-first-opening.html"

    // [J13] 口座開設（Biz）-MBOP0301-規定（事業先用）-取引にあたっての承諾事項
    // 旧URL: [X] https://jsapp.js-system.jp/account-biz/terms-agreement.html
    const val WEB_VIEW_MBOP0301_BIZ_TERMS_AGREEMENT = "https://jsapp.js-system.jp/account/terms-agreement.html"

    // [J05] 口座開設（Biz）-MBOP0301-規定（事業先用）-個人情報のお取扱いについて
    // 旧URL: [X] https://jsapp.js-system.jp/account-biz/terms-privacy.html
    const val WEB_VIEW_MBOP0301_BIZ_TERMS_PRIVACY = "https://jsapp.js-system.jp/account-biz/terms-privacy.html"

    // [J15] 口座開設（Biz）-MBOP0301-規定（事業先用）-キャッシュカードのご利用限度のご案内
    // 旧URL: [X] https://jsapp.js-system.jp/account-biz/terms-cashcard-limit.html
    const val WEB_VIEW_MBOP0301_BIZ_TERMS_CASHCARD_LIMIT = "https://jsapp.js-system.jp/account/terms-cashcard-limit.html"

    // [J17] 口座開設（Biz）-MBOP0301-規定（事業先用）-インターネットバンキングお申込みのご案内
    // 旧URL: [X] https://jsapp.js-system.jp/account-biz/terms-ebanking-application.html
    const val WEB_VIEW_MBOP0301_BIZ_TERMS_EBANKING_APPLICATION = "https://jsapp.js-system.jp/account/terms-ebanking-application.html"

    // [J18] 口座開設（Biz）-MBOP0301-規定（事業先用）-インターネットバンキング利用規定
    // 旧URL: [X] https://jsapp.js-system.jp/account-biz/terms-ebanking-use.html
    const val WEB_VIEW_MBOP0301_BIZ_TERMS_EBANKING_USE = "https://jsapp.js-system.jp/account/terms-ebanking-use.html"

    // [J12] 口座開設（Biz）-MBOP0301-規定（事業先用）-口座振替に関する注意事項
    // 旧URL: [X] https://jsapp.js-system.jp/account-biz/terms-account-transfer.html
    const val WEB_VIEW_MBOP0301_BIZ_TERMS_ACCOUNT_TRANSFER = "https://jsapp.js-system.jp/account/terms-account-transfer.html"

    // [J03] 口座開設（Biz）-MBOP0301-規定（事業先用）-ご留意事項
    // 旧URL: [X] https://jsapp.js-system.jp/account-biz/terms-note.html
    const val WEB_VIEW_MBOP0301_BIZ_TERMS_NOTE = "https://jsapp.js-system.jp/account-biz/terms-note.html"

    // [J16] 口座開設（Biz）-MBOP0301-規定（事業先用）-電子通帳規定
    // 旧URL: [X] https://jsapp.js-system.jp/account-biz/terms-ebankbook.html
    const val WEB_VIEW_MBOP0301_BIZ_TERMS_EBANKBOOK = "https://jsapp.js-system.jp/account/terms-ebankbook.html"

    // [J36] メニュー-MBST1501-利用規定-城南バンキングアプリ利用規定
    // 旧URL: [O] https://jsapp.js-system.jp/menu/terms-app.html
    const val WEB_VIEW_MBST1501_TERMS_APP = "https://jsapp.js-system.jp/menu/terms-app.html"

    // [J35] メニュー-MBST1701-個人情報のお取り扱いについて-城南バンキングアプリプライバシーポリシー
    // 旧URL: [O] https://jsapp.js-system.jp/menu/privacy.html
    const val WEB_VIEW_MBST1701_PRIVACY = "https://jsapp.js-system.jp/menu/privacy.html"
    const val WEB_VIEW_MBRCF202_PRIVACY = "https://www.jsbank.co.jp/notice/privacy/"

    // [J32] お困りの時-HELP-お困りの時-スマートフォンの機種変更を行なった際の操作方法について
    // 旧URL: [O] https://jsapp.js-system.jp/faq.html
    const val WEB_VIEW_HELP_DEVICE_CHANGE = "https://jsapp.js-system.jp/faq.html"

    // [J32] お困りの時-HELP-お困りの時-口座を追加したい
    // 旧URL: [X] https://jsapp.js-system.jp/faq/new-account.html
    const val WEB_VIEW_HELP_NEW_ACCOUNT = "https://jsapp.js-system.jp/faq.html"

    // [J32] お困りの時-HELP-お困りの時-本人確認書類で利用可能なものは？
    // 旧URL: [X] https://jsapp.js-system.jp/faq/available-ids.html
    const val WEB_VIEW_HELP_AVAILABLE_IDS = "https://jsapp.js-system.jp/faq.html"

    // [J32] お困りの時-HELP-お困りの時-証書を検索したい
    // 旧URL: [X] https://jsapp.js-system.jp/faq/search-certificate.html
    const val WEB_VIEW_HELP_SEARCH_CERTIFICATE = "https://jsapp.js-system.jp/faq.html"

    // [J32] お困りの時-HELP-お困りの時-セミナーの申込みについて
    // 旧URL: [X] https://jsapp.js-system.jp/faq/seminar-application.html
    const val WEB_VIEW_HELP_SEMINAR_APPLICATION = "https://jsapp.js-system.jp/faq.html"

    // [J32] お困りの時-HELP-お困りの時-ログインパスワードの変更
    // 旧URL: [X] https://jsapp.js-system.jp/faq/change-password.html
    const val WEB_VIEW_HELP_CHANGE_PASSWORD = "https://jsapp.js-system.jp/faq.html"

    // [J29] 電子通帳証書-MBDP0701-定期預金-懸賞金(品)の受け取り方について
    // 旧URL: [O] https://jsapp.js-system.jp/ecertificate/time-deposit.html
    const val WEB_VIEW_MBDP0701_TIME_DEPOSIT = "https://jsapp.js-system.jp/ecertificate/time-deposit.html"

    // [J30] 電子交付-MBDR0201-スーパードリーム期日のご案内-懸賞金(品)の受け取り方について
    // 旧URL: [O] https://jsapp.js-system.jp/edelivery/superdream-due.html
    const val WEB_VIEW_MBDR0201_SUPERDREAM_DUE = "https://jsapp.js-system.jp/edelivery/superdream-due.html"

    // [J31] 電子交付-MBDR0101-スーパードリームお利息計算書（兼新抽せん番号通知書）-懸賞金(品)の受け取り方について
    // 旧URL: [O] https://jsapp.js-system.jp/edelivery/superdream-interest.html
    const val WEB_VIEW_MBDR0101_SUPERDREAM_INTEREST = "https://jsapp.js-system.jp/edelivery/superdream-interest.html"

    // [J32] ログイン-MBLG0101-ログイン画面-ヘルプ
    // 旧URL: [X] https://jsapp.js-system.jp/login/help.html
    const val WEB_VIEW_MBLG0101_HELP = "https://jsapp.js-system.jp/faq.html"

    // 城南信用金庫ホームページ
    // 旧URL: [O] https://jsapp.js-system.jp/app
    const val HOME_PAGE = "https://www.jsbank.co.jp"

    // 電子インボイス閲覧サービスログイン画面
    const val WEB_VIEW_DIGITAL_INVOICE = "https://jsbank.dpost-k.jp/login"

    // 外部リンク(郵便番号がわからない場合)
    // 旧URL: [O] https://jsapp.js-system.jp/account/about-postal.html
    // TODO 要変数修正　WEB_VIEW_　→　WEB_LINK_
    const val WEB_VIEW_POST_CODE = "https://www.post.japanpost.jp/zipcode/"

    // 個別郵便番号について
    const val WEB_VIEW_INDIVIDUAL_POST_CODE = "https://jsapp.js-system.jp/account/about-postal.html"

    // [J39] 外部リンク(ご職業など-口座番号が分からない場合)
    // 旧URL: [X] https://www.post.japanpost.jp/zipcode/
    const val WEB_VIEW_OPEN_ACCOUNT_NUMBER_HELP = "https://jsapp.js-system.jp/new-registration/occupation.html"

    // [J00] WebView(ライセンス表示)
    // 旧URL: [X] https://jsbank.co.jp/jnet/index.html#app
    const val WEB_VIEW_LICENSE = "file:///android_asset/Android_License.html"

    // [J33] iDeCoへのリンク
    // 旧URL: [O] https://jsapp.js-system.jp/ideco.html
    const val WEB_VIEW_IDECO = "https://jsapp.js-system.jp/ideco.html"

    // [J11] 旧字体漢字について
    // 旧URL: [O] https://jsapp.js-system.jp/account/style-kanji.html
    const val WEB_VIEW_HELP_STYLE = "https://jsapp.js-system.jp/account/style-kanji.html"

    // [J06] 建物名の記載について
    // 旧URL: [O] https://jsapp.js-system.jp/account/about-name.html
    const val WEB_VIEW_HELP_ABOUT_NAME = "https://jsapp.js-system.jp/account/about-name.html"

    // 認証キーが分からない場合
    const val WEB_VIEW_AUTH_KEY = "https://jsapp.js-system.jp/account-biz/auth-key.html"

    // アプリユーザーの追加
    const val WEB_VIEW_NEW_USER = "https://jsapp.js-system.jp/account-biz/new-user.html"

    // Web通帳の注意事項について
    const val WEB_VIEW_CAUTION_EBOOK = "https://jsapp.js-system.jp/caution-ebank.html"

    // 西暦がわからない場合
    const val WEB_VIEW_YEAR_CHECK = "https://jsapp.js-system.jp/account-biz/year-check.html"

    // 壁紙ダウンロードリンク
    const val WEB_VIEW_WALL_PAPER = "https://jsapp.js-system.jp/wallpaper/index.html"

    // IBへのリンク
    const val WEB_VIEW_SHINKIN_IB = "https://www11.ib.shinkin-ib.jp/webbk/login/b-prelogin.do?bankcode=MTM0NA=="

    // 自転車保険へのリンク
    const val WEB_LINK_BICYCLE_INSURANCE = "https://fi.ms-ins-digital.com/apply/bicycle/_ag/jsbank"

    // クーポンサービスへのリンク
    const val WEB_LINK_COUPON_SERVICE = "https://johnan-apl.cho-toku.jp/"

    // 新システムへ移行しますへのリンク
    const val WEB_LINK_NEWSYSTEM = "https://www.jsbank.co.jp/news/new_system/index.html"
}

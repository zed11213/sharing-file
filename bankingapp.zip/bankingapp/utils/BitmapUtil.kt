package jp.co.jsbank.mb.bankingapp.utils

import android.graphics.Bitmap
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import jp.co.jsbank.mb.bankingapp.system.MyApp

object BitmapUtil {
    /**
     * Save Bitmap
     *
     * @param name file name
     * @param bm  picture to save
     */
    fun saveBitmap(name: String?, bm: Bitmap) {
        val targetPath: String = MyApp.DOWNLOAD_FILES_DIRECTORY + "/images/"
        if (!fileIsExist(targetPath)) {
            showToast("")
        } else {
            val saveFile = File(targetPath, name)
            try {
                val saveImgOut = FileOutputStream(saveFile)
                bm.compress(Bitmap.CompressFormat.JPEG, 80, saveImgOut)
                saveImgOut.flush()
                saveImgOut.close()
            } catch (ex: IOException) {
                ex.printStackTrace()
            }
        }
    }

    private fun fileIsExist(fileName: String?): Boolean {
        val file = File(fileName)
        return if (file.exists()) true else {
            file.mkdirs()
        }
    }
}

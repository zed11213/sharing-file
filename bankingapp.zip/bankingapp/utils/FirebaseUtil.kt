package jp.co.jsbank.mb.bankingapp.utils

import android.os.Bundle
import android.util.Log
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.analytics.ktx.analytics
import com.google.firebase.crashlytics.FirebaseCrashlytics
import com.google.firebase.crashlytics.ktx.crashlytics
import com.google.firebase.crashlytics.ktx.setCustomKeys
import com.google.firebase.ktx.Firebase
import jp.co.jsbank.mb.bankingapp.utils.LogPrintUtil.isNotBlank
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

object FirebaseUtil {
    const val EXCEPTION_NO_JAGJBAID = "no_jagJbaId"

    private val fa: FirebaseAnalytics by lazy { Firebase.analytics }
    private val fc: FirebaseCrashlytics by lazy { Firebase.crashlytics }

    fun setUser(userId: String){
        fc.setUserId(userId)
        fa.setUserId(userId)
    }

    fun setCustomKey(key: String ,value: String){
        fc.setCustomKeys {
                key(key, value)
            }
    }

    fun addLog(msg: String){
        fc.log(msg)
    }

    fun sendReport(userId: String, exception: String, msg: String){
        if (userId.isNotBlank()){
            setUser(userId)
        }
        addLog(msg)
        val e = Exception(exception)
        fc.recordException(e)
        fc.sendUnsentReports()
        sendToAnalytics(exception, msg)
    }

    private fun sendToAnalytics(exception: String, msg: String){
        val b = Bundle().apply {
            putString("debug_message", msg)
        }
        fa.logEvent(exception, b)
    }
}

package jp.co.jsbank.mb.bankingapp.utils

import android.os.Bundle
import android.util.Log
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.analytics.ktx.analytics
import com.google.firebase.crashlytics.FirebaseCrashlytics
import com.google.firebase.crashlytics.ktx.crashlytics
import com.google.firebase.crashlytics.ktx.setCustomKeys
import com.google.firebase.ktx.Firebase
import jp.co.jsbank.mb.bankingapp.utils.LogPrintUtil.isNotBlank
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

object FirebaseUtil {
    const val EXCEPTION_NO_JAGJBAID = "no_jagJbaId"
    private const val TAG = "FirebaseLog"

    private val fa: FirebaseAnalytics by lazy { Firebase.analytics }
    private val fc: FirebaseCrashlytics by lazy { Firebase.crashlytics }

    // local log cache（用于批量发送）
    private val logBuffer = mutableListOf<String>()
    private const val BUFFER_SIZE = 10

    fun setUser(userId: String){
        fc.setUserId(userId)
        fa.setUserId(userId)
    }

    fun setCustomKey(key: String ,value: String){
        fc.setCustomKeys {
                key(key, value)
            }
    }

    /**
     * add log（local only）
     */
    fun addLog(msg: String){
        val timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("MM-dd HH:mm:ss"))
        val logMsg = "[$timestamp] $msg"

        // 1. output to Logcat（real time）
        Log.d(TAG, logMsg)

        // 2. add t0 Crashlytics
        fc.log(logMsg)

        // 3. cache
        synchronized(logBuffer) {
            logBuffer.add(logMsg)
            if (logBuffer.size >= BUFFER_SIZE) {
                flushLogs()
            }
        }
    }

    /**
     * sent immediately
     * even not crash
     */
    fun sendLogImmediately(msg: String) {
        addLog(msg)

        // 记录一个非致命异常来触发日志发送
        fc.recordException(Exception("LogTrigger: $msg"))
        fc.sendUnsentReports()

        Log.d(TAG, "Log sent immediately: $msg")
    }

    /**
     * flush logs
     */
    fun flushLogs() {
        synchronized(logBuffer) {
            if (logBuffer.isNotEmpty()) {
                val combinedLog = logBuffer.joinToString("\n")
                setCustomKey("recent_logs", combinedLog)
                logBuffer.clear()
            }
        }
    }

    /**
     * sent event to Analytics（Analytics DebugView）
     */
    fun sendEvent(eventName: String, message: String) {
        // 1. Logcat
        Log.d(TAG, "Event[$eventName]: $message")

        // 2. Analytics（DebugView）
        val b = Bundle().apply {
            putString("message", message)
            putString("timestamp", System.currentTimeMillis().toString())
        }
        fa.logEvent(eventName, b)

        // 3. also to Crashlytics
        addLog("Event[$eventName]: $message")
    }

    fun sendReport(userId: String, exception: String, msg: String){
        if (userId.isNotBlank()){
            setUser(userId)
        }
        addLog(msg)
        val e = Exception(exception)
        fc.recordException(e)
        fc.sendUnsentReports()
        sendToAnalytics(exception, msg)
    }

    private fun sendToAnalytics(exception: String, msg: String){
        val b = Bundle().apply {
            putString("debug_message", msg)
        }
        fa.logEvent(exception, b)
    }
}

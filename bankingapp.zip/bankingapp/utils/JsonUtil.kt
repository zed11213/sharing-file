package jp.co.jsbank.mb.bankingapp.utils

import android.os.Parcelable
import com.google.gson.Gson
import com.google.gson.GsonBuilder

fun Parcelable.toJson(): String {
    return Gson().toJson(this)
}

inline fun <reified T> String.fromJson(): T? {
    return try {
        val gs = GsonBuilder()
            .setPrettyPrinting()
            .disableHtmlEscaping()
            .create()
        gs.fromJson(this, T::class.java)
    } catch (e: Exception) {
        null
    }
}

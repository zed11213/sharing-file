package jp.co.jsbank.mb.bankingapp.utils

/**
 * 定数クラス.
 */
object ConstUtil {
    // 日付フォーマット「YYYYMMdd」
    const val DATE_FORMAT_YYYY_MM_DD = "yyyyMMdd"

    // 日付フォーマット「yyyyMMdd」
    const val DATE_FORMAT_YYYY_MM_DD_LOWERCASE = "yyyyMMdd"

    // 日付フォーマット「YYYY年MM月dd日」
    const val DATE_FORMAT_CHARACTERS_YYYY_MM_DD = "yyyy年MM月dd日"

    // 日付フォーマット「YYYY年MM月」
    const val DATE_FORMAT_CHARACTERS_YYYY_MM = "yyyy年MM月"

    // 日付フォーマット「yyyy年MM月」
    const val DATE_FORMAT_CHARACTERS_yyyy_MM = "yyyy年MM月"

    // 日付フォーマット「YYYY年M月」
    const val DATE_FORMAT_CHARACTERS_YYYY_M = "yyyy年M月"

    // 日付フォーマット「yyyy-MM-dd」
    const val DATE_FORMAT_YYYY_MM_DD_HYPHEN = "yyyy-MM-dd"

    // 日付フォーマット「1900-01-01」
    const val DATE_FORMAT_YYYY_MM_DD_1900 = "1900-01-01"

    // 全角スペース
    const val FULL_SPACE = "　"

    // 半角スペース
    const val HALF_SPACE = " "

    // 全角長音
    const val FULL_MACRON = "\u30FC"

    // 半角長音
    const val HALF_MACRON = "\uFF70"

    // 全角ハイフン
    const val FULL_HYPHEN = "\uFF0D"

    // 半角ハイフン
    const val HALF_HYPHEN = "\u002D"

    // 点
    const val DOT = "."

    // スプラッシュ
    const val SPLASH = "/"

    // 日付フォーマット「YYYYMMddHHmmssSSS」
    const val DATE_FORMAT_YYYY_MM_DD_HH_MM_SS_MI = "yyyyMMddHHmmssSSS"

    // 日付フォーマット「yyyy-MM-ddTHH:mm:ss.SSSSSS」
    const val DATE_FORMAT_YYYY_MM_DD_T_HH_MM_SS_MI = "yyyy-MM-dd'T'HH:mm:ss.SSSSSS"

    // 日付フォーマット「yyyy.MM.dd」
    const val DATE_FORMAT_YYYY_MM_DD_SPOT = "yyyy.MM.dd"

    // 活性化フラグ
    const val ACTIVITY_FLAG = "ACTIVITY_FLAG"

    // 活性化フラグ：未認証、未登録
    const val ACTIVITY_FLAG_NO_ACCESS_NO_LOGIN = "0"

    // 活性化フラグ：認証済、未登録
    const val ACTIVITY_FLAG_ACCESS_NO_LOGIN = "1"

    // 活性化フラグ：認証済、登録済
    const val ACTIVITY_FLAG_ACCESS_LOGIN = "2"

    // 生体認証有効化状況
    const val BIOLOGICAL_STATE = "biological_state"

    // 生体認証実行フラグ
    const val EXECUTE_FLAG = "execute_flag"

    // 生体認証実行フラグ
    const val EXECUTE_BACKGROUND_FLAG = "execute_background_flag"

    // プッシュ通知有効化状況
    const val NOTIFICATION_STATE = "notification_state"

    // モバイルプッシュトークン
    const val PUSH_TOKEN = "pushToken"

    // モバイルプッシュトークンidentify
    const val PUSH_TOKEN_IDENTIFY = "pushTokenIdentify"

    // 生体認証結果
    const val BIOMETRIC_RESULT = "biometric_result"

    // 生体認証結果　0：未認証
    const val BIOMETRIC_RESULT_NOT_ACCESS = "0"

    // 生体認証結果　1：認証失敗
    const val BIOMETRIC_RESULT_ACCESS_FAIL = "1"

    // 生体認証結果　2：認証成功
    const val BIOMETRIC_RESULT_ACCESS_SUCCESS = "2"

    // 生体認証結果　3：取消す
    const val BIOMETRIC_RESULT_ACCESS_CANCEL = "3"

    // APIアクセス結果：OK
    const val API_RESULT_OK = "OK"

    // 認証結果:OK
    const val AUTHENTICATION_RESULT_OK = "0"

    // APIアクセス結果：OK
    const val AMOUNT_FORMAT_SPOT = "."

    // APIアクセス結果：OK
    const val AMOUNT_FORMAT_COMMA = ","

    // APIアクセス結果：OK
    const val AMOUNT_FORMAT_TYPE1 = "###,##0."

    // APIアクセス結果：OK
    const val AMOUNT_FORMAT_TYPE2 = "###,##0.0"

    // APIアクセス結果：OK
    const val AMOUNT_FORMAT_TYPE3 = "###,##0.00"

    // APIアクセス結果：OK
    const val AMOUNT_FORMAT_TYPE4 = "###,##0"

    // APIアクセス結果：OK
    const val AMOUNT_FORMAT_TYPE5 = "###0.000"

    // 取引記号：訂正
    const val TRANSACTION_SYMBOL_CORRECTION = "訂"

    // 総合口座初回フラグ
    const val COMPREHENSIVE_ACCOUNT_READ_FLAG = "COMPREHENSIVE_ACCOUNT_READ_FLAG"

    // 普通預金初回フラグ
    const val ORDINARY_DEPOSIT_READ_FLAG = "ORDINARY_DEPOSIT_READ_FLAG"

    // 当座預金初回フラグ
    const val CHECKING_ACCOUNT_READ_FLAG = "CHECKING_ACCOUNT_READ_FLAG"

    // 納税準備預金初回フラグ
    const val TAX_DEPOSIT_READ_FLAG = "TAX_DEPOSIT_READ_FLAG"

    // 通帳再検索フラグ
    const val PASSBOOK_RESEARCH_FLAG = "PassbookResearch"

    // 画面保持フラグ
    const val PAGE_NO_DESTROY_FLAG = "noDestroy"

    // 画面保持フラグ
    const val REGULAR_BALANCE = "regularBalance"

    // タブ
    const val TAB_TYPE = "TAB_TYPE"

    // タブ
    const val DETAIL_TAB_TYPE = "DETAIL_TAB_TYPE"

    // データキー
    const val DATA = "data"

    // データキー
    const val ALTERNATE_FLG = "alternateFlg"

    // タイプキー
    const val TYPE = "type"

    // タイプキー
    const val APPLY_ID = "applyId"

    // タイプキー
    const val READ_FLAG = "readFlag"

    // タイプキー
    const val CONFIRM_FLG = "confirmFlg"

    // タイプキー
    const val ANNCMNT_TYPE = "anncmntType"

    // タイプキー
    const val DOCUMENT_TYPE = "documentType"

    // タイプキー
    const val STORE = "store"

    // パラメータキー
    const val PARAM_1 = "param1"

    // パラメータキー
    const val PARAM_2 = "param2"

    // パラメータキー
    const val PARAM_3 = "param3"

    // パラメータキー
    const val PARAM_4 = "param4"

    // パラメータキー
    const val PARAM_5 = "param5"

    // パラメータキー
    const val PARAM_6 = "param6"


    // ファイルサービスキー
    const val PARAM_7 = "param7"

    // インプットキー
    const val INPUT_DATA = "inputData"

    // インプットキー
    const val ANNCMNT_ID = "anncmntId"

    // データリストキー
    const val DATA_LIST = "dataList"

    // 期間開始日
    const val DATE_FROM = "dateFrom"

    // 期間終了日
    const val DATE_TO = "dateTo"

    // 年目
    const val YEAR_INDEX = "年目"

    // 個別確認結果
    const val ANNCMNT_CONFIRM = "ANNCMNT_CONFIRM"

    // 個別確認結果
    const val CONFIRM_FLAG = "CONFIRM_FLAG"

    // デザインタイプ
    const val DESIGN_TYPE = "DESIGN_TYPE"

    // デザインタイプ
    const val EKYC_CARD_TYPE = "EKYC_CARD_TYPE"

    // デザインタイプ
    const val EKYC_DOCUMENT_TYPE = "EKYC_DOCUMENT_TYPE"

    // デザインタイプ
    const val EKYC_TERM_SUCCESS = "EKYC_TERM_SUCCESS"

    // トップカードindex
    const val TOP_CARD_INDEX = "TOP_CARD_INDEX"

    // トップカードindex
    const val TOP_TO_DETAIL_CARD_INDEX = "TOP_TO_DETAIL_CARD_INDEX"

    // 详细关闭标志
    const val DETAIL_CLOSE_FLAG = "DETAIL_CLOSE_FLAG"

    // トップカードindex
    const val TOP_CERTIFICATES_FLAG = "TOP_CERTIFICATES_FLAG"

    // 抽選結果表示フラグ
    const val LOTTERY_INFO_FLAG = "LOTTERY_INFO_FLAG_"

    // 抽選結果表示フラグ(お知らせ)
    const val LOTTERY_PDF_INFO_FLAG = "LOTTERY_PDF_INFO_FLAG_"

    // ファイル選択種別　1:写真を撮る
    const val TAKE_PHOTO = 1

    // ファイル選択種別　2:アルバムから選択する
    const val SELECT_PHOTO = 2

    // EKYCタイプ
    const val EKYC_TYPE = "ekyc_type"

    // EKYC読取情報：姓名
    const val EKYC_INFO_NAME = "ekyc_info_name"

    // EKYC読取情報：名
    const val EKYC_INFO_FIRST_NAME = "ekyc_info_first_name"

    // EKYC読取情報：姓
    const val EKYC_INFO_LAST_NAME = "ekyc_info_last_name"

    // EKYC読取情報：生年月日
    const val EKYC_INFO_BIRTHDATE = "ekyc_info_birthDate"

    // EKYC読取情報：住所
    const val EKYC_INFO_ADDRESS = "ekyc_info_address"

    // EKYC読取情報：都道府県
    const val EKYC_INFO_ADDRESS1 = "ekyc_info_address1"

    // EKYC読取情報：市区町村
    const val EKYC_INFO_ADDRESS2 = "ekyc_info_address2"

    // EKYC読取情報：町域
    const val EKYC_INFO_ADDRESS3 = "ekyc_info_address3"

    // EKYC読取情報：郵便番号
    const val EKYC_INFO_POSTALCODE = "ekyc_info_postalCode"

    // EKYC読取情報：性別
    const val EKYC_INFO_GENDER = "ekyc_info_gender"

    // EKYC読取情報：性別コード
    const val EKYC_INFO_GENDER_CODE = "ekyc_info_gender_code"

    // EKYC読取情報：idナンバー
    const val EKYC_INFO_ID_NUMBER = "ekyc_info_id_number"

    // EKYC読取情報：性別表示フラグ
    const val EKYC_INFO_SHOW_GENDER = "ekyc_info_show_gender"

    const val LIQUID_EKYC_APPLICANT_ID = "liquid_ekyc_applicant_id"
    const val LIQUID_EKYC_TOKEN = "liquid_ekyc_token"
    // 電話番号①
    const val PHONE_FIRST = "phone_first"

    // 電話番号②
    const val PHONE_SECOND = "phone_second"

    // 2025/01/17 共同化ため 電話番号の登録・表示 電話番号➂追加　start
    // 電話番号➂
    const val PHONE_THREE = "phone_three"
    // 2025/01/17 共同化ため 電話番号の登録・表示 電話番号➂追加　end

    // 2025/01/17 共同化ため 本人カード仮発行追加　start
    // 本人カード仮発行
    const val CARD_DUMMY_ISSUE = "card_dummy_issue"
    const val CARD_DUMMY_ISSUE_CODE = "1"
    // 2025/01/17 共同化ため 本人カード仮発行追加　end
    // 人格区分
    const val PERSONALITY_FLAG = "PERSONALITY_FLAG"

    // 受付番号
    const val RECEIPT_NUMBER = "RECEIPT_NUMBER"

    // MBCO0405 完了API実行済みフラグ
    const val MBCO0405_COMPLETED = "MBCO0405_COMPLETED"

    // 受付番号発行
    const val RECEIPT_NUMBER_ISSUE = "RECEIPT_NUMBER_ISSUE"

    // 受付番号(CC発行)
    const val CC_RECEIPT_NUMBER = "CC_RECEIPT_NUMBER"

    // 郵便番号（自宅）
    const val SELF_POST_CODE = "SELF_POST_CODE"

    // 郵便番号（勤務先）
    const val WORK_PLACE_POST_CODE = "WORK_PLACE_POST_CODE"

    // 郵便番号（学校）
    const val SCHOOL_POST_CODE = "SCHOOL_POST_CODE"

    // 郵便番号（所在地）
    const val LOCAL_POST_CODE = "LOCAL_POST_CODE"

    // CC暗証番号
    const val CC_PASSWORD = "cc_pin"

    // IBパスワード
    const val IB_PASSWORD = "ib_pin"

    // 共通鍵
    const val COMMON_KEY_LABEL = "COMMON_KEY"

    // 電話番号
    const val PHONE_NUMBER = "phone_number"

    // 番地
    const val ADDRESS = "address"

    // 丁目
    const val CHOME = "chome"

    // 方書
    const val HOSHO = "hosho"

    // JPEG
    const val JPEG = ".jpeg"

    // メール認証遷移元：キャッシュカード発行
    const val MAIL_CONFIRM_TYPE_CASH_CARD = "cashCard"

    // メール認証遷移元：個人
    const val MAIL_CONFIRM_TYPE_INDIVIDUAL = "individual"

    // メール認証遷移元：法人
    const val MAIL_CONFIRM_TYPE_CORPORATION = "corporation"

    // メール認証遷移元：個人事業主
    const val MAIL_CONFIRM_TYPE_SOLE_PROPRIETOR = "soleProprietor"

    // EKYC_画像：セルフィー画像
    const val EKYC_IMAGE_SELF = "self"

    // EKYC_画像：まばたき画像
    const val EKYC_IMAGE_LIVENESS = "liveness"

    // EKYC_画像：書類表画像
    const val EKYC_IMAGE_FRONT = "front"

    // EKYC_画像：書類斜め画像
    const val EKYC_IMAGE_TILTED = "tilted"

    // EKYC_画像：書類裏画像
    const val EKYC_IMAGE_BACK = "back"

    // EKYC_確認結果
    const val EKYC_RESULT = "ekyc_result"

    // 口座開設入力情報確認修正フラグ
    const val OPENED_EDIT_INFO_FLAG = "OPENED_EDIT_INFO_FLAG"

    // 修正フラグ
    const val EDIT_FLAG = "EDIT_FLAG"

    // 口座開設メールアドレス
    const val OPENED_MAIL_ADDRESS = "OPENED_MAIL_ADDRESS"

    // 口座開店舗
    const val OPENED_DEPARTMENT = "OPENED_DEPARTMENT"

    // 口座開設希望店
    const val OPENED_HOPE_DEPARTMENT = "OPENED_HOPE_DEPARTMENT"

    // デバイスID
    const val DEVICE_ID = "deviceID"

    // JBAID
    const val JBA_ID_TOKEN = "jbaIdToken"

    // USER_ID_TOKEN
    const val USER_ID_TOKEN = "userIdToken"

    // 依頼番号
    const val REQUEST_NO = "requestNo"

    // パスワード
    const val PIN = "pin"

    // 電子交付選択
    const val DELIVERY_SELECT = "delivery_select"

    // 利用者開始フラグ（1：開始：初回登録未完了　2：開始：初回登録完了　以外：利用者以外）
    const val USER = "user"

    // 初回登録未完了
    const val USER_NO_DONE = "1"

    // 初回登録完了
    const val USER_DONE = "2"

    // ログイン時間
    const val LOGIN_TIME = "login_time"

    // 前回ログイン時間
    const val LAST_LOGIN_TIME = "last_login_time"

    // CIF番号
    const val CIF_NO = "cifNo"

    // 店番
    const val BRANCH_NO = "branchNo"

    // 認証TRXキー
    const val VERIFY_TRX_KEY = "verifyTRXKey"

    // JWT
    const val JAG_PROFILE_JWT = "jagProfile"

    // FormBody：jagTrailer
    const val FORM_BODY_JAGTRAILER = "jagTrailer"

    // FormBody：jagBffMethod
    const val FORM_BODY_JAGBFFMETHOD = "jagBffMethod"

    // FormBody：jagDeviceId
    const val FORM_BODY_JAGDEVICEID = "jagDeviceId"

    // FormBody：jagApplicationId
    const val FORM_BODY_JAGAPPLICATIONID = "jagApplicationId"

    // FormBody：jagJbaId
    const val FORM_BODY_JAGJBAID = "jagJbaId"

    // FormBody：jagUserId
    const val FORM_BODY_JAGUSERID = "jagUserId"

    // FormBody：jagAccessToken
    const val FORM_BODY_JAGACCESSTOKEN = "jagAccessToken"

    // JAG_ENV_CLIENT_SECRET_KEY
    const val JAG_ENV_CLIENT_SECRET_KEY = "RW1jcTRjaEpqV3lLTEFkVmo2SDVMWkFkM3hLNTY5aUY="

    // JAG_ENV_SECRET_KEY 16文字.
    const val JAG_ENV_SECRET_KEY = "VG00TURFRHVBdXFFbWZEOQ=="

    // JAG_CRYPT_TYPE_AES_CBC_PKCS5PADDING
    const val JAG_CRYPT_TYPE_AES_CBC_PKCS5PADDING = "AES/CBC/PKCS5Padding"

    // JAG_TRX_TYPE_TCC
    const val JAG_TRX_TYPE_TCC = "JAG-TCC"

    // JAG_TRX_TYPE_NRM
    const val JAG_TRX_TYPE_NRM = "JAG-NRM"

    // トランザクションID
    const val JAG_RES_TRXID = "TrxId"

    // アクセストークン
    const val ACCESS_TOKEN = "accessToken"

    // リフレッシュトークン
    const val REFRESH_TOKEN = "refreshToken"

    // JAG_CRYPT_TYPE_SHA256
    const val JAG_CRYPT_TYPE_SHA256 = "SHA-256"

    // UTF-8
    const val CHARSET_UTF_8 = "UTF-8"

    // 親子有区分
    const val PARENT_CHILD_FLAG = "1"

    // DO CANCEL状態.
    // 0: 確定要求
    const val JAG_TRX_DO_CONFIRM = "0"

    // ファイルProvider
    const val FILE_PROVIDER = "jp.co.jsbank.mb_dev.bankingapp.fileprovider"

    // PDFデータタイプ
    const val DATA_TYPE_PDF = "application/pdf"

    // メニューから
    const val FROM_MENU = "0"

    // その他から
    const val FROM_OTHER = "1"

    // MBSU0602かけ直す
    const val MBSU0602_CALL_BACK_COUNT = "MBSU0602_CALL_BACK_COUNT_"

    // MBCO0302かけ直す
    const val MBCO0302_CALL_BACK_COUNT = "MBCO0302_CALL_BACK_COUNT_"

    // Web通帳切替フラグ
    const val WEB_PASSBOOK_SWITCH_FLAG = "WEB_PASSBOOK_SWITCH_FLAG"

    // 利用者の処理区分：更新
    const val USER_UPDATE = "0"

    // 利用者の処理区分：削除
    const val USER_DELETE = "1"

    // ON
    const val ON = "0"

    // OFF
    const val OFF = "1"

    // UNMATCH
    const val UNMATCH = "UNMATCH"

    // API アクセス　タイプ
    const val API_METHOD_TYPE = "API_METHOD_TYPE"

    // API アクセス　タイプ「POST」
    const val API_METHOD_TYPE_POST = "POST"

    // API アクセス　タイプ「PUT」
    const val API_METHOD_TYPE_PUT = "PUT"

    // API リクエスト　Json データ
    const val API_REQUEST_DATA = "API_REQUEST_DATA"

    // API Content-Type
    const val API_CONTENT_TYPE = "Content-Type"

    // API Content-Type
    const val API_CONTENT_TYPE_FORM = "application/x-www-form-urlencoded"

    // しらうめJネット支店の店番
    const val INTERNET_SHOP_ID = "090"

    // しらうめJネット支店の名前
    const val INTERNET_SHOP_NAME = "しらうめJネット支店"

    // API サービス名称
    const val API_SERVICE_NAME = "API_SERVICE_NAME"

    // 初回登録電子通帳ヘルプ表示フラグ
    const val PASSBOOK_HELP_FLAG = "PASSBOOK_HELP_FLAG"

    // プッシュ通知登録成功フラグ「」
    const val PUSH_OK_FLAG = "PUSH_OK_FLAG"

    // deviceバンディングフラグ
    const val DEVICE_BINDING_FLAG = "DEVICE_BINDING_FLAG"

    // 簡単受付画面遷移元
    const val EASY_RECEPTION_PAGE_HOME = "EASY_RECEPTION_PAGE_HOME"

    // パスワードエラー回数
    const val PASS_ERR_COUNT = "PASS_ERR_COUNT"

    // 初回アプリ起動後に利用規定表示フラグ
    const val SHOW_AGREEMENT_FLAG = "SHOW_AGREEMENT_FLAG"

    // IVRスキップフラグ　0：認証画面へ遷移
    const val IVR_SKIP_ACCESS = "0"

    // IVRスキップフラグ　1：0911呼出、初回登録ピックアップだす
    const val IVR_SKIP_FAIL = "1"

    const val DETAIL_TRANSITION = "DETAIL_TRANSITION"

    // REALM DB暗号化キー（64桁）
    const val REALM_ENCRYPTION_KEY = "REALM_DB_KEY"

    // アプリのエラーコード_MBLO0001
    const val APP_ERROR_CODE_MBLO0001 = "MBLO0001"

    // アプリのエラーコード_MBLO0002
    const val APP_ERROR_CODE_MBLO0002 = "MBLO0002"

    // アプリのエラーコード_MBLO0003
    const val APP_ERROR_CODE_MBLO0003 = "MBLO0003"

    // アプリのエラーコード_MBLO0004
    const val APP_ERROR_CODE_MBLO0004 = "MBLO0004"

    // アプリのエラーコード_MBLO0005
    const val APP_ERROR_CODE_MBLO0005 = "MBLO0005"

    // アプリのエラーコード_MBLO0006
    const val APP_ERROR_CODE_MBLO0006 = "MBLO0006"

    // アプリのエラーコード_MBLO0007
    const val APP_ERROR_CODE_MBLO0007 = "MBLO0007"

    // アプリのエラーコード_MBST0005
    const val APP_ERROR_CODE_MBST0005 = "MBST0005"

    // 他店開設希望理由
    const val REASON = "REASON"

    // 他店開設希望理由（その他）
    const val REASON_OTHER = "REASON_OTHER"

    // 内部レビュー開始日取得フラグ「false:開始日が空白」
    const val INTERNAL_REVIEW_START_DATE_FLAG = "INTERNAL_REVIEW_START_DATE_FLAG"

    // 内部レビューダイアログ表示フラグ
    const val INTERNAL_REVIEW_DIALOG_FLAG = "INTERNAL_REVIEW_DIALOG_FLAG"

    // 内部レビュー開始日
    const val INTERNAL_REVIEW_START_DATE = "START_DATE"

    // 「MBCC0401」で入力した生年月日
    const val DATE_OF_BIRTH = "DATE_OF_BIRTH"

    // RESTORE古い情報
    const val OLD_RESTORE_INFO = "OLD_RESTORE_INFO"

    // realm古い情報
    const val OLD_REALM_INFO = "OLD_REALM_INFO"

    // 預金一覧から口座番号
    const val MBDP0101_ACCOUNT_NUMBER = "MBDP0101_ACCOUNT_NUMBER"

    // 名前入力欄文字制限(全角)
    const val FULL_PERSON_NAME_MAX_LENGTH = 9

    // 名前入力欄文字制限(半角)
    const val HALF_PERSON_NAME_MAX_LENGTH = 15

    // 建物名/号室入力欄文字制限(全角)
    const val FULL_BUILDING_NAME_MAX_LENGTH = 20

    // 号室入力欄文字制限(半角)
    const val HALF_BUILDING_NAME_MAX_LENGTH = 30

    // 名前入力欄文字制限(半角)
//    const val HALF_PERSON_NAME_MAX_LENGTH = 15
    const val PLACE_HOLDER_PERSON_FIRST_NAME = "城南"
    const val PLACE_HOLDER_PERSON_LAST_NAME = "太郎"
    const val PLACE_HOLDER_PERSON_NAME_KANA = "１２―３"
    const val PLACE_HOLDER_BANCHI = "１２―３"
    const val PLACE_HOLDER_BUILDING_NAME = "号室入力"
    const val PLACE_HOLDER_BUILDING_NAME_KANA = "カタカナ入力"

    //プッシュ通知権限取得
    const val PERMISSION_REQUEST_NOTIFICATION = 102
    //ekyc url
    const val EKYC_URL = "https://applicantsdk-api.stg-liquid-ekyc.com"
}

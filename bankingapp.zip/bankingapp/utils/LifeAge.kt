package jp.co.jsbank.mb.bankingapp.utils

import java.text.SimpleDateFormat
import java.util.*
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.DATE_FORMAT_YYYY_MM_DD_HYPHEN

/**
 * 生年月日クラス
 */
object LifeAge {
    /**
     * @param birthday 生年月日
     * ユーザーの誕生日に基づいて年齢を計算する
     * Calenderオブジェクトを使用して、現在の日付オブジェクトを取得します。オブジェクトから年、月、日をそれぞれ取り出します。
     * 出力結果（年齢）例：26
     */
    fun getAgeByBirth(birthday: String?): Int {
        // CalendarオブジェクトからDateオブジェクトを取得します
        val now = Calendar.getInstance()
        // 生年月日をCalendarタイプのbirオブジェクトに入れ、CalendarタイプとDateタイプの間で変換します
        val bir = Calendar.getInstance()
        val simpleDateFormat = SimpleDateFormat(DATE_FORMAT_YYYY_MM_DD_HYPHEN)
        bir.time = simpleDateFormat.parse(birthday)
        // 誕生日が現在の日付よりも大きい場合は例外をスローします：生年月日は現在の日付よりも大きくすることはできません
        if (now.before(birthday)) {
            return -1
        }
        // 現在の年、月、日を取得する
        val yearNow = now[Calendar.YEAR]
        val monthNow = now[Calendar.MONTH] + 1
        val dayNow = now[Calendar.DAY_OF_MONTH]
        // 生年月日を取得する
        val yearBirth = bir[Calendar.YEAR]
        val monthBirth = bir[Calendar.MONTH] + 1
        val dayBirth = bir[Calendar.DAY_OF_MONTH]
        // 最初に日を引き、月を借りるのに十分ではなく、次に月を引き、年を借りるのに十分ではなく、最後に年を引きます。
        val day = dayNow - dayBirth
        var month = monthNow - monthBirth
        // 年齢は、現在の年から出生年を引いたものです
        var year = yearNow - yearBirth
        if (day < 0) {
            month -= 1
        }
        if (month < 0) {
            // 1年未満で12か月間借り入れた
            year -= 1
        }
        return year
    }
}

package jp.co.jsbank.mb.bankingapp.utils

import android.annotation.SuppressLint
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.hilt.navigation.compose.hiltViewModel
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.locks.ReentrantLock
import jp.co.jsbank.mb.bankingapp.logic.common.LoadingLogic
import jp.co.jsbank.mb.bankingapp.ui.widgets.dialog.LoadingDialog
import kotlinx.coroutines.flow.MutableStateFlow

/**
 * ローディング
 */
@SuppressLint("LogNotTimber")
object LoadingUtil {
    private val queueLoading = ConcurrentLinkedQueue<Boolean>()
    private var loadingOpenFlag = MutableStateFlow(false)
    private val lock = ReentrantLock()

    // ローディングタイプ（false: 一つAPI true:複数API）
    var loadingType: Boolean = false

    // ローディング閉じるフラグ（true:閉じる）
    var loadingClose: Boolean = false

    /**
     * ローディング設定
     * @param value ローディング表示 （true:表示）
     * @param type ローディングタイプ（false: 一つAPI true:複数API）
     * @param closeFlag ローディング閉じるフラグ（true:閉じる）
     */
    fun setLoadingValue(value: Boolean = false, type: Boolean = false, closeFlag: Boolean = false) {
        queueLoading.add(value)
        loadingType = type
        loadingClose = closeFlag
        val locked = try {
            lock.tryLock(10, TimeUnit.MILLISECONDS)
        } catch (e: InterruptedException) {
            return
        }
        if (!locked) {
            return
        }
        try {
            loadingOpenFlag.value = queueLoading.poll() ?: false
        } finally {
            lock.unlock()
        }
    }

    @Composable
    fun Loading() {
        LoadingItem()
    }

    @SuppressLint("UnrememberedMutableState")
    @OptIn(ExperimentalAnimationApi::class)
    @Composable
    private fun LoadingItem() {
        val viewModel: LoadingLogic = hiltViewModel()
        val viewStates = viewModel.viewStates
        val loading by loadingOpenFlag.collectAsState()

        if (loading) {
            viewModel.openLoadingDialog()
        } else {
            if (!loadingType) {
                viewModel.closeLoadingDialog()
            }
        }
        if (!loadingClose && viewStates.loadingFlag) {
            LoadingDialog()
        }
    }
}

package jp.co.jsbank.mb.bankingapp.utils

import jp.co.jsbank.mb.bankingapp.repositories.db.common.deleteAll
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.*
import jp.co.jsbank.mb.bankingapp.system.MyApp

/**
 * Realm情報クリア.
 */
object RealmClearUtil {

    /**
     * Realm情報クリア
     */
    fun realmClear() {
        MyApp.INSTANCE.deleteAll(EPassBookAB0401::class.java)
        MyApp.INSTANCE.deleteAll(EPassBookAB0401::class.java)
        MyApp.INSTANCE.deleteAll(EPassBookAB0403::class.java)
        MyApp.INSTANCE.deleteAll(EPassBookAB0405::class.java)
        MyApp.INSTANCE.deleteAll(EPassBookAB1001::class.java)
        MyApp.INSTANCE.deleteAll(EPassBookAB0112::class.java)
        MyApp.INSTANCE.deleteAll(EPassBookAB0701::class.java)
        MyApp.INSTANCE.deleteAll(AccountOpeningAB0703::class.java)
        MyApp.INSTANCE.deleteAll(AccountOpeningAB0704::class.java)
        MyApp.INSTANCE.deleteAll(AccountOpeningAB0706::class.java)
        MyApp.INSTANCE.deleteAll(AccountOpeningAB0707::class.java)
        MyApp.INSTANCE.deleteAll(AccountOpeningAB0718::class.java)
        MyApp.INSTANCE.deleteAll(AccountOpeningAB0719::class.java)
    }
}

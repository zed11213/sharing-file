package jp.co.jsbank.mb.bankingapp.utils

import android.content.Context
import android.content.SharedPreferences
import android.preference.PreferenceManager
import androidx.annotation.NonNull
import com.google.gson.Gson
import jp.co.polarify.onboarding.sdk.types.result.GetMatchingIDResult

/**
 * Preference 制御.
 */
object PreferenceManagerUtil {
    /**
     * インスタンスの取得.
     *
     * @param context コンテキスト
     * @return インスタンス
     */
    private fun getDefaultSharedPreferences(@NonNull context: Context): SharedPreferences {
        return PreferenceManager.getDefaultSharedPreferences(context)
    }

    /**
     * プリファレンス取得（String型）.
     *
     * @param context コンテキスト
     * @param key     プリファレンスキー
     * @return プリファレンス値
     */
    fun getString(@NonNull context: Context, @NonNull key: Int): String? {
        return getDefaultSharedPreferences(context).getString(key.toString(), IDefaultValue.STRING)
    }

    /**
     * プリファレンス取得（String型）.
     *
     * @param context  コンテキスト
     * @param key      プリファレンスキー
     * @param defValue Default値
     * @return プリファレンス値
     */
    fun getString(@NonNull context: Context, @NonNull key: String?, @NonNull defValue: String?): String? {
        return getDefaultSharedPreferences(context).getString(key, defValue)
    }

    /**
     * プリファレンス取得（int型）.
     *
     * @param context コンテキスト
     * @param key     プリファレンスキー
     * @return プリファレンス値
     */
    fun getInt(@NonNull context: Context, @NonNull key: String?): Int {
        return getDefaultSharedPreferences(context).getInt(key, IDefaultValue.INT)
    }

    /**
     * プリファレンス取得（long型）.
     *
     * @param context コンテキスト
     * @param key     プリファレンスキー
     * @return プリファレンス値
     */
    fun getLong(@NonNull context: Context, @NonNull key: String?): Long {
        return getDefaultSharedPreferences(context).getLong(key, IDefaultValue.LONG)
    }

    /**
     * プリファレンス取得（boolean型）.
     *
     * @param context コンテキスト
     * @param key     プリファレンスキー
     * @return プリファレンス値
     */
    fun getBoolean(@NonNull context: Context, @NonNull key: String?): Boolean {
        return getDefaultSharedPreferences(context).getBoolean(key, IDefaultValue.BOOLEAN)
    }

    /**
     * プリファレンス取得（boolean型）.
     *
     * @param context  コンテキスト
     * @param key      プリファレンスキー
     * @param defValue Default値
     * @return プリファレンス値
     */
    fun getBoolean(@NonNull context: Context, @NonNull key: String?, defValue: Boolean): Boolean {
        return getDefaultSharedPreferences(context).getBoolean(key, defValue)
    }

    /**
     * プリファレンスに保存（String型）.
     *
     * @param context コンテキスト
     * @param key     プリファレンスキー
     * @param value   プリファレンス値
     */
    fun putString(@NonNull context: Context, @NonNull key: String?, @NonNull value: String?) {
        val editor = getDefaultSharedPreferences(context).edit()
        editor.putString(key, value)
        editor.commit()
    }

    /**
     * プリファレンスに保存（int型）.
     *
     * @param context コンテキスト
     * @param key     プリファレンスキー
     * @param value   プリファレンス値
     */
    fun putInt(@NonNull context: Context, @NonNull key: String?, value: Int) {
        val editor = getDefaultSharedPreferences(context).edit()
        editor.putInt(key, value)
        editor.commit()
    }

    /**
     * プリファレンスに保存（long型）.
     *
     * @param context コンテキスト
     * @param key     プリファレンスキー
     * @param value   プリファレンス値
     */
    fun putLong(@NonNull context: Context, @NonNull key: String?, value: Long) {
        val editor = getDefaultSharedPreferences(context).edit()
        editor.putLong(key, value)
        editor.commit()
    }

    /**
     * プリファレンスに保存（boolean型）.
     *
     * @param context コンテキスト
     * @param key     プリファレンスキー
     * @param value   プリファレンス値
     */
    fun putBoolean(@NonNull context: Context, @NonNull key: String?, value: Boolean) {
        val editor = getDefaultSharedPreferences(context).edit()
        editor.putBoolean(key, value)
        editor.commit()
    }

    /**
     * プリファレンスを削除.
     *
     * @param context コンテキスト
     * @param key     プリファレンスキー
     */
    fun remove(@NonNull context: Context, @NonNull key: String?) {
        val editor = getDefaultSharedPreferences(context).edit()
        editor.remove(key)
        editor.commit()
    }

    /**
     * プリファレンスを全削除.
     *
     * @param context コンテキスト
     */
    fun reset(@NonNull context: Context?) {
        PreferenceManager.getDefaultSharedPreferences(context).edit().clear().commit()
    }

    /**
     * プリファレンスに保存（GetMatchingIDResult型）.
     *
     * @param context コンテキスト
     * @param key     プリファレンスキー
     * @param value   プリファレンス値
     */
    fun putGetMatchingIDResult(@NonNull context: Context, @NonNull key: String?, @NonNull value: GetMatchingIDResult?) {
        val editor = getDefaultSharedPreferences(context).edit()
        val gson = Gson()
        editor.putString(key, gson.toJson(value))
        editor.commit()
    }

    /**
     * プリファレンス取得（GetMatchingIDResult型）.
     *
     * @param context コンテキスト
     * @param key     プリファレンスキー
     * @return プリファレンス値
     */
    fun getGetMatchingIDResult(@NonNull context: Context, @NonNull key: String?): GetMatchingIDResult {
        val gson = Gson()
        return gson.fromJson(
            getDefaultSharedPreferences(context).getString(key, null),
            GetMatchingIDResult::class.java
        )
    }

    /**
     * デフォルト値定義Interface.
     */
    interface IDefaultValue {
        companion object {
            /**
             * String.
             */
            const val STRING = ""

            /**
             * int.
             */
            const val INT = -1

            /**
             * long.
             */
            const val LONG: Long = -1

            /**
             * boolean.
             */
            const val BOOLEAN = false
        }
    }
}

package jp.co.jsbank.mb.bankingapp.utils

import android.util.Log
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

/**
 * ログ出力
 */
object LogPrintUtil {

    private const val MIN_STACK_OFFSET = 3
    private const val TOP_LEFT_CORNER = '╔'
    private const val BOTTOM_LEFT_CORNER = '╚'
    private const val MIDDLE_CORNER = '╟'
    private const val HORIZONTAL_DOUBLE_LINE = '║'
    private const val DOUBLE_DIVIDER = "════════════════════════════════════════════"
    private const val SINGLE_DIVIDER = "────────────────────────────────────────────"
    private val TOP_BORDER = TOP_LEFT_CORNER + DOUBLE_DIVIDER + DOUBLE_DIVIDER
    private val BOTTOM_BORDER = BOTTOM_LEFT_CORNER + DOUBLE_DIVIDER + DOUBLE_DIVIDER
    private val MIDDLE_BORDER = MIDDLE_CORNER + SINGLE_DIVIDER + SINGLE_DIVIDER
    private const val JSON_INDENT = 2
    private var TAG = "LOG_TAG"

    // build.gradleファイルから指定 4=error  5=off
    private var logLevel = jp.co.jsbank.mb.bankingapp.BuildConfig.LOG_LEVEL

    @JvmStatic
    fun init(clazz: Class<*>) {
        TAG = clazz.simpleName
    }

    @JvmStatic
    fun init(tag: String) {
        TAG = tag
    }

    @JvmStatic
    fun verbose(msg: String) {
        if (LogLevel.VERBOSE.value >= logLevel) {
            if (msg.isNotBlank()) {
                val s = getMethodNames()
                Log.v(TAG, String.format(s, msg))
            }
        }
    }

    @JvmStatic
    fun debug(msg: String) {
        if (LogLevel.DEBUG.value >= logLevel) {
            if (msg.isNotBlank()) {
                val s = getMethodNames()
                Log.d(TAG, String.format(s, msg))
            }
        }
    }

    @JvmStatic
    fun info(msg: String) {
        if (LogLevel.INFO.value >= logLevel) {
            if (msg.isNotBlank()) {
                val s = getMethodNames()
                Log.i(TAG, String.format(s, msg))
            }
        }
    }

    @JvmStatic
    fun warn(msg: String) {
        if (LogLevel.WARN.value >= logLevel) {
            if (msg.isNotBlank()) {
                val s = getMethodNames()
                Log.w(TAG, String.format(s, msg))
            }
        }
    }

    @JvmStatic
    fun error(msg: String) {
        if (LogLevel.ERROR.value >= logLevel) {
            if (msg.isNotBlank()) {
                val s = getMethodNames()
                Log.e(TAG, String.format(s, msg))
            }
        }
    }

    @JvmStatic
    fun json(info: String) {
        var info = info
        if (info.isBlank()) {
            debug("Empty/Null json content")
            return
        }

        try {
            info = info.trim { it <= ' ' }
            if (info.startsWith("{")) {
                val jsonObject = JSONObject(info)
                var message = jsonObject.toString(JSON_INDENT)
                message = message.replace("\n".toRegex(), "\n║ ")
                val s = getMethodNames()
                println(String.format(s, message))
                return
            }
            if (info.startsWith("[")) {
                val jsonArray = JSONArray(info)
                var message = jsonArray.toString(JSON_INDENT)
                message = message.replace("\n".toRegex(), "\n║ ")
                val s = getMethodNames()
                println(String.format(s, message))
                return
            }
            error("Invalid Json")
        } catch (e: JSONException) {
            error("Invalid Json")
        }
    }

    private fun getMethodNames(): String {
        val sElements = Thread.currentThread().stackTrace

        var stackOffset = getStackOffset(sElements)

        stackOffset++
        val builder = StringBuilder()
        builder.append(TOP_BORDER).append("\r\n")
            .append("║ " + "Thread: " + Thread.currentThread().name).append("\r\n")
            .append(MIDDLE_BORDER).append("\r\n")
            .append("║ ")
            .append(sElements[stackOffset].className)
            .append(".")
            .append(sElements[stackOffset].methodName)
            .append(" ")
            .append(" (")
            .append(sElements[stackOffset].fileName)
            .append(":")
            .append(sElements[stackOffset].lineNumber)
            .append(")")
            .append("\r\n")
            .append(MIDDLE_BORDER).append("\r\n")
            .append("║ ").append("%s").append("\r\n")
            .append(BOTTOM_BORDER).append("\r\n")
        return builder.toString()
    }

    private fun getStackOffset(trace: Array<StackTraceElement>): Int {
        var i = MIN_STACK_OFFSET
        while (i < trace.size) {
            val e = trace[i]
            val name = e.className
            if (name != LogPrintUtil::class.java.name) {
                return --i
            }
            i++
        }
        return -1
    }

    fun String.isBlank(msg: String): Boolean {

        return msg.isEmpty()
    }

    fun String.isNotBlank(msg: String): Boolean {

        return msg.isNotBlank()
    }

    enum class LogLevel {
        VERBOSE {
            override val value: Int
                get() = 0
        },
        DEBUG {
            override val value: Int
                get() = 1
        },
        INFO {
            override val value: Int
                get() = 2
        },
        WARN {
            override val value: Int
                get() = 3
        },
        ERROR {
            override val value: Int
                get() = 4
        },
        OFF {
            override val value: Int
                get() = 5
        };

        abstract val value: Int
    }
}

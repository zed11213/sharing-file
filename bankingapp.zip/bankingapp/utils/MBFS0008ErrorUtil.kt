package jp.co.jsbank.mb.bankingapp.utils

import kotlinx.coroutines.flow.MutableStateFlow

/**
 * MBFS0008エラーメッセージ管理
 * ResponseInterceptorで検知したMBFS0008エラーをPage層に通知する
 */
object MBFS0008ErrorUtil {
    const val ERROR_CODE = "MBFS0008"

    /**
     * エラーメッセージ
     */
    val msg = MutableStateFlow("")

    /**
     * メッセージ設定
     */
    fun postValue(value: String) {
        msg.value = value
    }

    /**
     * メッセージクリア
     */
    fun clear() {
        msg.value = ""
    }
}

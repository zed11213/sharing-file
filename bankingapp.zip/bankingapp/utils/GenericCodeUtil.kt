package jp.co.jsbank.mb.bankingapp.utils

object GenericCodeUtil {

    /**
     * 桁数が足りないものは前に0を補う
     * @param code
     * @param num
     * @return
     */
    fun autoGenericCode(code: String, num: Int): String {
        return if (code.isNotEmpty()) {
            String.format("%0" + num + "d", Integer.parseInt(code))
        } else {
            ""
        }
    }
}

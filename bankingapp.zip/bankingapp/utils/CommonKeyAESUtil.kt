package jp.co.jsbank.mb.bankingapp.utils

import android.annotation.SuppressLint
import android.security.keystore.KeyProperties
import java.util.*
import javax.crypto.Cipher
import javax.crypto.spec.SecretKeySpec

/**
 * AES暗号化ツール
 *
 */
class CommonKeyAESUtil {
    /**
     * 暗号化メソッド
     *
     * @param plainText 暗号化する文字列
     * @param commonKey 共通鍵
     * @return 暗号化文字列
     */
    @SuppressLint("GetInstance")
    fun encrypt(plainText: String, commonKey: String): String {
        val cipher = Cipher.getInstance(KeyProperties.KEY_ALGORITHM_AES)
        cipher.init(
            Cipher.ENCRYPT_MODE,
            SecretKeySpec(RSAUtil().rsaDecrypt(commonKey).toByteArray(), KeyProperties.KEY_ALGORITHM_AES)
        )
        val byteEncryptStr = cipher.doFinal(plainText.toByteArray())
        return String(Base64.getEncoder().encode(byteEncryptStr))
    }

    /**
     * 復号化メソッド
     *
     * @param encryptedStr 復号化する文字列
     * @param commonKey 共通鍵
     * @return 復号化文字列
     */
    @SuppressLint("GetInstance")
    @Throws(Exception::class)
    fun decrypt(encryptedStr: String?, commonKey: String): String {
        val cipher = Cipher.getInstance(KeyProperties.KEY_ALGORITHM_AES)
        cipher.init(
            Cipher.DECRYPT_MODE,
            SecretKeySpec(RSAUtil().rsaDecrypt(commonKey).toByteArray(), KeyProperties.KEY_ALGORITHM_AES)
        )
        val byteEncryptedStr = Base64.getDecoder().decode(encryptedStr)
        return String(cipher.doFinal(byteEncryptedStr))
    }
}

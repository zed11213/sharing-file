package jp.co.jsbank.mb.bankingapp.utils

/**
 * メッセージ置換
 */
object MessageReplaceUtils {
    fun messageReplace(msg: String, value: String, value2: String = ""): String {
        return if (value2.isBlank()) {
            msg.replace("%s", value)
        } else {
            msg.replace("%s", value).replace("%m", value2)
        }
    }
}

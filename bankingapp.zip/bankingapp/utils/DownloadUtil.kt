package jp.co.jsbank.mb.bankingapp.utils

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.runtime.Composable
import androidx.core.content.FileProvider
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*
import jp.co.jsbank.mb.bankingapp.repositories.api.common.download.*
import jp.co.jsbank.mb.bankingapp.system.MyApp.Companion.CONTEXT
import jp.co.jsbank.mb.bankingapp.system.MyApp.Companion.DOWNLOAD_FILES_DIRECTORY
import jp.co.jsbank.mb.bankingapp.ui.widgets.dialog.SampleAlertDialog
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.DATA_TYPE_PDF
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.FILE_PROVIDER
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn

/**
 * ダウンロードクラス.
 */
object DownloadUtil {

    /**
     * PDFダウンロードサービス.
     *
     * @param base64Data データ
     * @param outputFile 保存ファイル
     * @param onError エラーバックアップ
     * @param onProcess プロセスバックアップ
     * @param onSuccess 成功バックアップ
     */
    @SuppressLint("SimpleDateFormat")
    @JvmOverloads
    @RequiresApi(Build.VERSION_CODES.O)
    suspend fun pdfDownload(
        base64Data: String,
        outputFile: String,
        onError: download_error = {},
        onProcess: download_process = { _, _, _ -> },
        onSuccess: download_success = { }
    ) {
        flow {
            try {
                val simpleDateFormat = SimpleDateFormat("yyyyMMdd_HHmmss")
                val date = Date(System.currentTimeMillis())
                // テスト用base64作成 end
                val decodedBytes: ByteArray = Base64.getDecoder().decode(base64Data)
                val inputStream = java.io.ByteArrayInputStream(decodedBytes)

                val file = File(DOWNLOAD_FILES_DIRECTORY + outputFile + "_" + simpleDateFormat.format(date) + ".pdf")
                val outputStream = FileOutputStream(file)
                val bufferSize = 1024 * 8
                val buffer = ByteArray(bufferSize)
                val bufferedInputStream = BufferedInputStream(inputStream, bufferSize)
                var readLength: Int
                while (bufferedInputStream.read(buffer, 0, bufferSize)
                    .also { readLength = it } != -1
                ) {
                    outputStream.write(buffer, 0, readLength)
                }
                bufferedInputStream.close()
                outputStream.close()
                inputStream.close()
                emit(HttpDownLoadResult.success(file))
            } catch (e: Exception) {
                emit(HttpDownLoadResult.failure(e))
            }
        }.flowOn(Dispatchers.IO)
            .collect {
                it.fold(onFailure = { e ->
                    e?.let { it1 -> onError(it1) }
                }, onSuccess = { file ->
                        onSuccess(file)
                    }, onLoading = { progress ->
                        onProcess(progress.currentLength, progress.length, progress.process)
                    })
            }
    }

    /**
     * ダウンロード済みのポップアップ
     *
     * @param fileName ファイル名
     * @param onDismiss 確定ボタンバックアップ
     */
    @Composable
    fun SuccessDownloadDialog(
        fileName: String,
        onDismiss: () -> Unit
    ) {
        SampleAlertDialog(
            title = "ダウンロード完了",
            content = "「$fileName」のダウンロードが完了しました。",
            confirmText = "ファイルを開く",
            onConfirmClick = {
                val file = File(DOWNLOAD_FILES_DIRECTORY + fileName)
                if (file.exists()) {
                    val intent = Intent(Intent.ACTION_VIEW)
                    val contentUri = FileProvider
                        .getUriForFile(CONTEXT, FILE_PROVIDER, file)
                    intent.setDataAndType(contentUri, DATA_TYPE_PDF)
                    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    CONTEXT.startActivity(intent)
                }
            },
            cancelText = "OK",
            onDismiss = {
                onDismiss()
            }
        )
    }
}

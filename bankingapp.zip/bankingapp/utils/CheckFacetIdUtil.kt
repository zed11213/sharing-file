package jp.co.jsbank.mb.bankingapp.utils

import android.app.AlertDialog
import android.content.Context
import android.util.Log
import android.widget.Toast
import com.daon.fido.client.sdk.uaf.UafMessageUtils

/**
 * FacetID を生成、確認するためのクラスです.
 */
class CheckFacetIdUtil(private val context: Context) {
    /**
     * facetID を取得します.
     *
     * @return facetID
     */
    val facetID: String = UafMessageUtils.getFacetId(context)

    /**
     * facetID をログで出力します.
     */
    fun checkByLog() {
        Log.d("CheckFacetId", "facetID = { $facetID }")
    }

    /**
     * facetID をトーストで表示します.
     */
    fun checkByToast() {
        Toast.makeText(context, "facetID = { $facetID }", Toast.LENGTH_LONG).show()
    }

    /**
     * facetID をダイアログで表示します.
     */
    fun checkByDialog() {
        AlertDialog.Builder(context)
            .setTitle("facetID")
            .setMessage(facetID)
            .setPositiveButton("OK", null)
            .show()
    }
}

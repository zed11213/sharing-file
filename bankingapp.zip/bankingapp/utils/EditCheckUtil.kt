package jp.co.jsbank.mb.bankingapp.utils

import android.annotation.SuppressLint
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.*
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.system.MyApp.Companion.CONTEXT
import jp.co.jsbank.mb.bankingapp.system.master.Phone
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.DATE_FORMAT_YYYY_MM_DD_HH_MM_SS_MI
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.DATE_FORMAT_YYYY_MM_DD_HYPHEN
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.DATE_FORMAT_YYYY_MM_DD_LOWERCASE
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.DOT
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.HALF_HYPHEN
import org.jetbrains.annotations.NotNull

/**
 * Date取得用クラス.
 */
object EditCheckUtil {

    /**
     * 過去の日付を取得
     *
     * @param past 日数
     * @return
     */
    @SuppressLint("SimpleDateFormat", "WeekBasedYear")
    fun getPastDate(past: Int): String? {
        val calendar = Calendar.getInstance()
        calendar[Calendar.DAY_OF_YEAR] = calendar[Calendar.DAY_OF_YEAR] - past
        val today = calendar.time
        val format = SimpleDateFormat(DATE_FORMAT_YYYY_MM_DD_HYPHEN)
        return format.format(today)
    }

    /**
     * 前月の初日を取得
     *
     * @return
     */
    @SuppressLint("SimpleDateFormat", "WeekBasedYear")
    fun firstBeforeDayOfMonth(): String {
        val format = SimpleDateFormat(DATE_FORMAT_YYYY_MM_DD_HYPHEN)
        val day = Calendar.getInstance()
        day.add(Calendar.MONTH, -1)
        day[Calendar.DAY_OF_MONTH] = 1
        return format.format(day.time)
    }

    /**
     * 前月の初日を取得
     *
     * @return
     */
    @SuppressLint("SimpleDateFormat", "WeekBasedYear")
    fun lastBeforeDayOfMonth(): String {
        val format = SimpleDateFormat(DATE_FORMAT_YYYY_MM_DD_HYPHEN)
        val day = Calendar.getInstance()
        day[Calendar.DAY_OF_MONTH] = 0
        return format.format(day.time)
    }

    /**
     * 現在の月の初日の取得
     *
     * @return
     */
    @SuppressLint("SimpleDateFormat", "WeekBasedYear")
    fun firstCurrentDayOfMonth(): String {
        val format = SimpleDateFormat(DATE_FORMAT_YYYY_MM_DD_HYPHEN)
        val day = Calendar.getInstance()
        day.add(Calendar.MONTH, 0)
        day[Calendar.DAY_OF_MONTH] = 1
        return format.format(day.time)
    }

    /**
     * 現在の月の最終日の取得
     *
     * @return
     */
    @SuppressLint("SimpleDateFormat", "WeekBasedYear")
    fun lastCurrentOfMonth(): String {
        val format = SimpleDateFormat(DATE_FORMAT_YYYY_MM_DD_HYPHEN)
        val day = Calendar.getInstance()
        day[Calendar.DAY_OF_MONTH] = day.getActualMaximum(Calendar.DAY_OF_MONTH)
        return format.format(day.time)
    }

    /**
     * 通帳日付フォーマット
     *
     * @return
     */
    fun passbookDateFormat(date: String): String {
        val dateList = date.split(HALF_HYPHEN)
        return dateList[0].substring(2, 4) + HALF_HYPHEN + dateList[1] + DOT + dateList[2]
    }

    /**
     * 年
     *
     * @param year 年
     * @return　年のチェック結果
     */
    fun isYearCheck(@NotNull year: String): Boolean {
        val tempYear = year.toInt()
        return tempYear >= 1900
    }

    /**
     * 月
     *
     * @param month 月
     * @return　月のチェック結果
     */
    fun isMonthCheck(@NotNull month: String): Boolean {
        val tempMonth = month.toInt()
        return !(1 > tempMonth || tempMonth > 12)
    }

    /**
     * 日
     *
     * @param year 年
     * @param month 月
     * @param day 日
     * @return　日のチェック結果
     */
    @SuppressLint("WeekBasedYear")
    fun isDayCheck(
        @NotNull year: String,
        @NotNull month: String,
        @NotNull day: String
    ): Boolean {
        val input = year + HALF_HYPHEN + month + HALF_HYPHEN + day
        val pattern = "^(?!0000)[0-9]{4}-(((0[13578]|(10|12))-(0[1-9]|[1-2][0-9]|3[0-1]))" +
            "|(02-(0[1-9]|[1-2][0-9]))|((0[469]|11)-(0[1-9]|[1-2][0-9]|30)))\$"
        return Regex(pattern).matches(input)
    }

    /**
     * 日付フォーマット（YYYYMMDDHHMMSSMI）
     *
     * @param date 日付
     * @return
     */
    @SuppressLint("SimpleDateFormat", "WeekBasedYear")
    fun formatDateYYYYMMDDHHMMSSMI(date: Date): String? {
        val format = SimpleDateFormat(DATE_FORMAT_YYYY_MM_DD_HH_MM_SS_MI)
        return format.format(date)
    }

    /**
     * 半角数字チェック
     *
     * @param value チェック対象
     * @return
     */
    fun numberCheck(value: String): Boolean {
        val pattern = "^\\d*"
        return Regex(pattern).matches(value)
    }
    // 2025/01/20 共同化ためインバン利用登録修正　start
    /**
     * 半角英数字チェック
     */
    fun halfEnglishNumCheck(value: String): Boolean {
        val pattern = "^[a-zA-Z0-9]+$"
        return Regex(pattern).matches(value)
    }

    /**
     * 桁数チェック6~12桁
     *
     * @param value チェック対象
     * @param minLen 最小桁数
     * @return
     */
    fun lengthCheckRange(value: String, minLen: Int): Boolean {
        if (value.length < minLen ) {
            return false
        } else {
            return true
        }
    }

    /**
     * 半角英数字チェック
     * 6~12桁
     * 英数の両方が最低１文字は必要
     */
    fun halfEnglishNumMinLengthCheck(value: String): Boolean {
        val pattern = "^(?=.*[0-9])(?=.*[a-zA-Z]).{6,12}\$"
        return Regex(pattern).matches(value)
    }

    // 2025/01/20 共同化ためインバン利用登録修正　end
    /**
     * 桁数チェック
     *
     * @param value チェック対象
     * @param length 桁数
     * @return
     */
    fun lengthCheck(value: String, length: Int): Boolean {
        return value.length == length
    }

    /**
     * 全角カナチェック
     */
    fun String.isFullKana(): Boolean {
        return matches(Regex("^[\\u30A0-\\u30FF + \\u3000 + ．－]+$"))
    }

    /**
     * 全角カナチェック
     */
    fun String.isFullKanaNotSpace(): Boolean {
        return matches(Regex("^[\\u30A0-\\u30FF]+$")) && !isSpace()
    }

    /**
     * 個人事業主のセイ
     */
    fun String.isIndividualSei(): Boolean {
        return matches(Regex("^[\\u30A0-\\u30FF + －]+$"))
    }

    /**
     * 個人事業主のメイ
     */
    fun String.isIndividualMei(): Boolean {
        return matches(Regex("^[\\u30A0-\\u30FF + －]+$")) && !isSpace()
    }

    /**
     * 全角カナチェック(かっこを含む)
     */
    fun String.isFullBracketsKana(): Boolean {
        return matches(Regex("^[\\u30A0-\\u30FF + \\u3000 + （）＆’，－．・]+\$"))
    }

    /**
     * 半角カナチェック
     */
    private fun String.isHalfKana(): Boolean {
        return matches(Regex("^[\\uFF66-\\uFF9F]+$"))
    }

    /**
     * 半角数字チェック
     */
    fun String.isHalfNum(): Boolean {
        return matches(Regex("^[\\u0030-\\u0039]+$"))
    }

    /**
     * 半角英数字チェック
     */
    fun String.isHalfEnglishNum(): Boolean {
        return matches(Regex("^[a-zA-Z0-9]+$"))
    }

    /**
     * 全角漢字チェック
     */
    fun String.isFullKanji(): Boolean {
        return matches(Regex("^[\\u3041-\\u30FE]+$"))
    }

    /**
     * 日付フォーマット
     */
    fun String.toLabelDate(): String {
        return if (this.length == 8)
            this.substring(0, 4) + CONTEXT.getString(R.string.common_label_year) +
                this.substring(4, 6) + CONTEXT.getString(R.string.common_label_month) +
                this.substring(6, 8) + CONTEXT.getString(R.string.common_label_day)
        else if (this.length == 10 && this.contains(HALF_HYPHEN))
            this.split(HALF_HYPHEN)[0] + CONTEXT.getString(R.string.common_label_year) +
                this.split(HALF_HYPHEN)[1] + CONTEXT.getString(R.string.common_label_month) +
                this.split(HALF_HYPHEN)[2] + CONTEXT.getString(R.string.common_label_day)
        else this
    }

    /**
     * 日付フォーマット
     */
    fun String.toMonthDate(): String {
        return if (this.length == 8)
            this.substring(4, 6) + CONTEXT.getString(R.string.common_label_month) +
                this.substring(6, 8) + CONTEXT.getString(R.string.common_label_day)
        else if (this.length == 10 && this.contains(HALF_HYPHEN))
            this.split(HALF_HYPHEN)[1] + CONTEXT.getString(R.string.common_label_month) +
                this.split(HALF_HYPHEN)[2] + CONTEXT.getString(R.string.common_label_day)
        else this
    }

    /**
     * 0の補足
     */
    fun Int.fillLeftZero(digits: Int): String {
        return if (this.toString().length < digits) {
            var newValue = this.toString()
            while ((digits - newValue.length) > 0) {
                newValue = "0$newValue"
            }
            newValue
        } else {
            this.toString()
        }
    }

    /**
     * 未来日チェック
     *
     * @param date チェック対象
     * @return　未来日:True
     */
    @SuppressLint("WeekBasedYear")
    fun isFutureDays(date: String): Boolean {
        val formatter = DateTimeFormatter.ofPattern(DATE_FORMAT_YYYY_MM_DD_LOWERCASE)
        val newDate = LocalDate.parse(date, formatter)
        return newDate.isAfter(LocalDate.now())
    }

    /**
     * 固定電話番号チェック
     */
    fun String.isFixedTelePhone(): Boolean {
        return matches(
            Regex(
                "\\d{2}-\\d{4}-\\d{4}|\\d{3}-\\d{3}-\\d{4}|\\d{4}-\\d{2}-\\d{4}|\\d{5}-\\d-\\d{4}"
            )
        )
    }

    /**
     * IP電話番号チェック
     */
    fun String.isIPTelePhone(): Boolean {
        return matches(
            Regex(
                "050\\-[0-9]{4}\\-[0-9]{4}\$"
            )
        )
    }

    /**
     * 携帯電話番号チェック
     */
    fun String.isMobilePhone(): Boolean {
        return matches(
            Regex(
                "^[0-9]{3}\\-[0-9]{4}\\-[0-9]{4}\$"
            )
        )
    }

    /**
     * 固定電話、携帯電話番号共通チェック
     *
     * @param type 電話タイプ
     * @param number 電話番号
     * @return
     */
    fun String.isPhone(type: String, number: String): Boolean {
        val numFirst = number.split(HALF_HYPHEN)[0]
        // 1桁目が「0」以外場合
        if (number.substring(0, 1) != "0") {
            return false
        }
        // 固定電話場合
        if (type == Phone.FIXED_TELEPHONE.code) {
            // 市外局番が3桁以上かつ3桁目が「0」
            if (numFirst.length >= 3 && numFirst.substring(2, 3) == "0") {
                return false
            }
        } else {
            // 090,080,070,050以外
            if (numFirst != "090" && numFirst != "080" && numFirst != "070" && numFirst != "050") {
                return false
            }
        }
        return true
    }

    /**
     * 入力不可漢字チェック
     */
    fun containsInvalidCharacter(input: String):Boolean{
        return input.any { "凜熙吞噓".contains(it) }
    }


    /**
     * 半角チェック
     */
    fun String.isHalfAngle(): Boolean {
        this.forEach {
            if (!it.toString().isHalfNum() && it.toString() != "-" && it.toString() != "–"
            ) return false
        }
        return true
    }

    /**
     * 全角チェック
     */
    fun String.isFull(): Boolean {
        return matches(
            Regex(
                "^[^\\x00-\\xff|^\\uff61-\\uff9f]*\$"
            )
        )
    }

    /**
     * JIS第一水準、第二水準の漢字と、カタカナ・ひらがなチェック
     */
    fun String.isRegularName(): Boolean {
        return matches(
            Regex(
                "^[\\u4E00-\\u9FFF + \\u3040-\\u309F? + \\u30A0-\\u30FF + \\u30FD + \\u30FE +" +
                    "\\u309D + \\u309E + \\u3003 + \\u4EDD + \\u3005+ \\u3006 + \\u3007 + \\u30FC]+\$"
            )
        )
    }

    /**
     * 正規表現で半角記号チェック
     */
    fun String.isHalfAngleSign(): Boolean {
        return matches(
            Regex("^[!-/:-@¥\\[-`{-~]+\$")
        )
    }

    /**
     * 現在の日付が何曜日であるかを判断する
     *
     * @param dt 現在の日付
     * @return 曜日
     */
    fun getWeekOfDate(dt: Date): Int {
        val weekDays = arrayOf(7, 1, 2, 3, 4, 5, 6)
        val cal = Calendar.getInstance()
        cal.time = dt
        var w = cal[Calendar.DAY_OF_WEEK] - 1
        if (w < 0) w = 0
        return weekDays[w]
    }

    /**
     * 人名（漢字）チェック
     */
    fun String.isPersonNameCharacters(): Boolean {
        return matches(
            Regex(
                "^[\\u4E00-\\u9FFF + \\u3040-\\u309F? + \\u30A0-\\u30FF + \\u30FD + \\u30FE + " +
                    "\\u309D + \\u309E + \\u3003 + \\u4EDD + \\uFF0D + \\u3005+ \\u3006 + \\u3007 + \\u30FC + \\uFF0D]+\$"
            )
        ) && !isSpace()
    }

    /**
     * 人名（カナ）チェック
     */
    fun String.isPersonNameKana(): Boolean {
        return matches(Regex("^[\\uFF66-\\uFF9F + \\u002D]+\$")) && !isSpace()
    }

    /**
     * 人名（漢字）+全角スペース　チェック
     */
    fun String.isPersonNameCharactersBlank(): Boolean {
        return matches(
            Regex(
                "^[\\u4E00-\\u9FFF + \\u3040-\\u309F? + \\u30A0-\\u30FF + \\u30FD + \\u30FE + " +
                    "\\u309D + \\u309E + \\u3003 + \\u4EDD + \\uFF0D + \\u3005+ \\u3006 + \\u3007 + \\u30FC + \\uFF0D + \\u3000]+\$"
            )
        )
    }

    /**
     * 法人（カナ）・屋号（カナ）チェック ＋ タブ文字
     */
    fun String.isPersonNameKanaBlank(): Boolean {
//        return matches(Regex("^[\\uFF66-\\uFF9F + \\u002D + \\u0020 + \\u0009]+\$"))
        return matches(Regex("^[A-Z|0-9|ｦ-ﾟ|\\u0026|\\u0027|\\u002C|\\u002D|\\u002E|\\u0020|\\u0028|\\u0029|\\u0009]+$"))
    }

    /**
     * 人名以外（全角）チェック
     */
    fun String.isPersonNameOther(): Boolean {
        return matches(
            Regex(
                "^[\\u4E00-\\u9FFF + \\u3040-\\u309F? + \\u30A0-\\u30FF + \\uFF21-\\uFF3A + \\u30FD + " +
                    "\\u30FE + \\u309D + \\u309E + \\u3003 + \\u4EDD + \\u3005+ \\u3006 + \\u3007 + \\u30FC + " +
                    "\\uFF41-\\uFF5A+ \\uFF10-\\uFF19 + \\uFF06-\\uFF09 + \\uFF0C-\\uFF0E + \\u3000 + \\u2019]+\$"
            )
        )
    }

    /**
     * 人名以外（半角）チェック
     */
    fun String.isPersonNameKanaOther(): Boolean {
        return matches(
            Regex(
//                "^[0-9|\\-|ｦ-ﾟ|\\u0020|!|#|\\\$|%|&|(|)]+$"
                "^[0-9|\\-|ｦ-ﾟ + \\u0041-\\u005A + \\u0061-\\u007A + \\u0026-\\u0027 + " +
                    "\\u002C-\\u002E + \\u00AF + \\u0087 + \\u0020 + \\u002E + \\uFF65 +  \\u30FB]+\$"
            )
        )
    }

    /**
     * スペースチェック
     */
    private fun String.isSpace(): Boolean {
        return matches(Regex("^[ + 　]+\$"))
    }

    /**
     * 法人（カナ）・屋号（カナ）チェック
     */
    fun String.houjin_name_kana(): Boolean {
        return matches(
            Regex(
                "^[A-Z|0-9|ｦ-ﾟ|\\u0026|\\u0027|\\u002C|\\u002D|\\u002E|\\u0020|\\u0028|\\u0029]+$"
            )
        )
    }

    /**
     * //人名（カナ）：半角カナ+長音変換(U+002D)+ピリオド(U+002E),英数字・記号はNG
     */
    fun String.name_kana(): Boolean {
        return matches(Regex("^[ｦ-ﾟ|\\u002D|\\u002E]+\$"))
    }
}

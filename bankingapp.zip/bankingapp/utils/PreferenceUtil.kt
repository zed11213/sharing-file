package jp.co.jsbank.mb.bankingapp.utils

import android.util.Log
import jp.co.jsbank.mb.bankingapp.fragment.DocumentCaptureTutorialFragment
import jp.co.jsbank.mb.bankingapp.system.MyApp.Companion.SHARED_PREFERENCES

/**
 * Preference取得、設定用クラス.
 */
object PreferenceUtil {

    private val TAG = PreferenceUtil::class.java.name

    // 値取得
    fun getPreferenceStringValue(key: String): String? {
        return SHARED_PREFERENCES.getString(key, "")
    }

    fun getPreferenceBooleanValue(key: String?): Boolean {
        return SHARED_PREFERENCES.getBoolean(key, false)
    }

    fun getPreferenceFloatValue(key: String?): Float {
        return SHARED_PREFERENCES.getFloat(key, 0f)
    }

    fun getPreferenceIntValue(key: String?): Int {
        return SHARED_PREFERENCES.getInt(key, 0)
    }

    fun getPreferenceLongValue(key: String?): Long {
        return SHARED_PREFERENCES.getLong(key, 0L)
    }

    // 値設定
    fun setPreferenceStringValue(key: String, value: String) {
        //脆弱性診断対応：ログに重要情報を出力しないようにする（開発時、debugログを一時出力はOK）
//        Log.i(TAG, "setPreferenceStringValue $key : $value ")
        SHARED_PREFERENCES
            .edit()
            .putString(key, value)
            .apply()
    }

    fun setPreferenceBooleanValue(key: String, value: Boolean) {
        //脆弱性診断対応：ログに重要情報を出力しないようにする（開発時、debugログを一時出力はOK）
//        Log.i(TAG, "setPreferenceBooleanValue $key : $value ")
        SHARED_PREFERENCES
            .edit()
            .putBoolean(key, value)
            .apply()
    }

    fun setPreferenceFloatValue(key: String, value: Float) {
        //脆弱性診断対応：ログに重要情報を出力しないようにする（開発時、debugログを一時出力はOK）
//        Log.i(TAG, "setPreferenceFloatValue $key : $value ")
        SHARED_PREFERENCES
            .edit()
            .putFloat(key, value)
            .apply()
    }

    fun setPreferenceIntValue(key: String, value: Int) {
        //脆弱性診断対応：ログに重要情報を出力しないようにする（開発時、debugログを一時出力はOK）
//        Log.i(TAG, "setPreferenceIntValue $key : $value ")
        SHARED_PREFERENCES
            .edit()
            .putInt(key, value)
            .apply()
    }

    fun setPreferenceLongValue(key: String, value: Long) {
        //脆弱性診断対応：ログに重要情報を出力しないようにする（開発時、debugログを一時出力はOK）
//        Log.i(TAG, "setPreferenceLongValue $key : $value ")
        SHARED_PREFERENCES
            .edit()
            .putLong(key, value)
            .apply()
    }

    // キー削除
    fun removePreferenceStringValue(key: String) {
        //脆弱性診断対応：ログに重要情報を出力しないようにする（開発時、debugログを一時出力はOK）
//        Log.i(TAG, "removePreferenceStringValue $key")
        SHARED_PREFERENCES
            .edit()
            .remove(key)
            .apply()
    }

    /**
     * 画面IDとイベントID設定
     *
     * @param screenID 画面ID
     * @param eventID イベントID
     */
    fun setScreenIDAndEventID(screenID: String, eventID: String) {
        setPreferenceStringValue("screenID", screenID)
        setPreferenceStringValue("eventID", eventID)
    }
}

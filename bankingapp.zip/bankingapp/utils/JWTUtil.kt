package jp.co.jsbank.mb.bankingapp.utils

import android.security.keystore.KeyProperties
import android.util.Log
import io.jsonwebtoken.Jwts
import io.jsonwebtoken.SignatureAlgorithm
import jp.co.jsbank.mb.bankingapp.bean.common.BffJwtPayloadAuthTokenBean
import jp.co.jsbank.mb.bankingapp.bean.common.JagJwtPayloadAuthTokenBean
import jp.co.jsbank.mb.bankingapp.bean.common.JagJwtPayloadRefreshTokenBean
import jp.co.jsbank.mb.bankingapp.system.Config
import jp.co.jsbank.mb.bankingapp.system.Config.JAG_DEF_10MINS_MILLIES_SECONDS
import jp.co.jsbank.mb.bankingapp.system.Config.JAG_JWT_DEF_ISSUER
import jp.co.jsbank.mb.bankingapp.system.Config.JAG_JWT_DEF_PROFILE_CUSTOME_CLAIM_PAYLOAD
import jp.co.jsbank.mb.bankingapp.system.Config.JAG_JWT_DEF_TRAILER_CUSTOME_CLAIM_BFF_BODY
import jp.co.jsbank.mb.bankingapp.system.Config.JAG_JWT_DEF_TRAILER_CUSTOME_CLAIM_BFF_HEADER
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.HALF_HYPHEN
import jp.co.jsbank.mb.bankingapp.utils.PreferenceUtil.getPreferenceStringValue
import java.io.UnsupportedEncodingException
import java.security.KeyFactory
import java.security.interfaces.RSAPrivateKey
import java.security.spec.PKCS8EncodedKeySpec
import java.util.*

/**
 * JWTクラス
 */
class JWTUtil {

    /**
     * JWT発行日および有効期限所得
     * @param type タイプ
     * @param value 値
     * @param time タイム
     */
    private fun getTravelTime(type: Int, value: Int, time: Date): Date {
        val now = Calendar.getInstance()
        val tz: TimeZone = TimeZone.getTimeZone("Asia/Tokyo")
        TimeZone.setDefault(tz)
        now.timeZone = tz
        now.time = time
        now.add(type, value)
        return now.time
    }

    /**
     * JWT生成
     * @param type デフォルト JAG用　true場合、BFF用
     * @param jwtType 0:JWT　1:AZ0913「アクセストークン無効場合」
     */
    fun createJWT(type: Boolean = false, jwtType: Int = 0): String {
        // RSA秘密鍵の取得
        val privateKeyString = RSAUtil().loadPrivateKeyByFile()
        val buffer = Base64.getDecoder().decode(privateKeyString)
        val keySpec = PKCS8EncodedKeySpec(buffer)
        val keyFactory = KeyFactory.getInstance(KeyProperties.KEY_ALGORITHM_RSA)
        val privateKey: RSAPrivateKey = keyFactory.generatePrivate(keySpec) as RSAPrivateKey
        val issuedAt = getTravelTime(Calendar.HOUR, 0, Date())
        val expiration = getTravelTime(Calendar.MILLISECOND, JAG_DEF_10MINS_MILLIES_SECONDS, issuedAt)
        var jwtKey = ""
        try {
            // JWTヘッダー設定
            val header: MutableMap<String, Any> = HashMap()
            header["alg"] = "HS256"
            header["typ"] = "JWT"

            // JWTボディー設定
            val claims: MutableMap<String, Any> = HashMap()

            // JAG用
            if (!type) {
                // Jag パラメータ設定
                jagParamSet(jwtType, claims)
            } else {
                // BFF パラメータ設定
                bffParamSet(claims)
            }

            // JWT作成
            jwtKey = Jwts.builder()
                .setHeader(header)
                .setClaims(claims)
                .setIssuer(JAG_JWT_DEF_ISSUER)
                .setIssuedAt(issuedAt)
                .setExpiration(expiration)
                .signWith(SignatureAlgorithm.RS256, privateKey)
                .compact().toString()
        } catch (e: UnsupportedEncodingException) {
            e.printStackTrace()
        }

        // 作成したJWTキーをローカルに保存する
        PreferenceUtil.setPreferenceStringValue(ConstUtil.JAG_PROFILE_JWT, jwtKey)
        return jwtKey
    }

    /**
     * JWT生成
     * @param type デフォルト JAG用　true場合、BFF用
     * @param jwtType 0:JWT　1:AZ0913「アクセストークン無効場合」
     */
    fun asyncCreateJWT(apiData :String): String {
        // RSA秘密鍵の取得
        val privateKeyString = RSAUtil().loadPrivateKeyByFile()
        val buffer = Base64.getDecoder().decode(privateKeyString)
        val keySpec = PKCS8EncodedKeySpec(buffer)
        val keyFactory = KeyFactory.getInstance(KeyProperties.KEY_ALGORITHM_RSA)
        val privateKey: RSAPrivateKey = keyFactory.generatePrivate(keySpec) as RSAPrivateKey
        val issuedAt = getTravelTime(Calendar.HOUR, 0, Date())
        val expiration = getTravelTime(Calendar.MILLISECOND, JAG_DEF_10MINS_MILLIES_SECONDS, issuedAt)
        var jwtKey = ""
        try {
            // JWTヘッダー設定
            val header: MutableMap<String, Any> = HashMap()
            header["alg"] = "HS256"
            header["typ"] = "JWT"

            // JWTボディー設定
            val claims: MutableMap<String, Any> = HashMap()

            // BFF パラメータ設定
            asyncBffParamSet(claims, apiData)

            // JWT作成
            jwtKey = Jwts.builder()
                .setHeader(header)
                .setClaims(claims)
                .setIssuer(JAG_JWT_DEF_ISSUER)
                .setIssuedAt(issuedAt)
                .setExpiration(expiration)
                .signWith(SignatureAlgorithm.RS256, privateKey)
                .compact().toString()
        } catch (e: UnsupportedEncodingException) {
            e.printStackTrace()
        }

        // 作成したJWTキーをローカルに保存する
        PreferenceUtil.setPreferenceStringValue(ConstUtil.JAG_PROFILE_JWT, jwtKey)
        return jwtKey
    }

    /**
     * Jag パラメータ設定.
     */
    private fun bffParamSet(claims: MutableMap<String, Any>) {
        val list: Array<String> = arrayOf(
            ConstUtil.COMMON_KEY_LABEL,
            ConstUtil.JBA_ID_TOKEN,
            ConstUtil.USER_ID_TOKEN,
            ConstUtil.DEVICE_ID
        )
        val jagPeerBean = KeyStoreUtil().getJagInfo(list)
        // 共通キー
        val commonKey = jagPeerBean.jagEncryptedKey
        // JBAID
        val jbaIdToken = jagPeerBean.customerId
        // 利用者IDトークン
        val userIdToken = jagPeerBean.userId
        // 端末ID
        val deviceId = jagPeerBean.deviceId
        // 取引ID
        val calendar = Calendar.getInstance()
        val transactionID = EditCheckUtil.formatDateYYYYMMDDHHMMSSMI(calendar.time) + HALF_HYPHEN + deviceId
//        Log.i("thread","data = ${getPreferenceStringValue(ConstUtil.API_REQUEST_DATA).toString()} ")
        // API:データ
        val apiData =
            CommonKeyAESUtil().encrypt(getPreferenceStringValue(ConstUtil.API_REQUEST_DATA).toString(), commonKey)
        val bean = BffJwtPayloadAuthTokenBean()
        // JBAID
        bean.jbaIdToken = jbaIdToken
        // USERID
        bean.userIDToken = userIdToken
        // アプリケーションID
        bean.applicationID = Config.getAppId()
        // デバイスID
        bean.deviceID = deviceId
        // OS
        bean.os = Config.OS_TYPE
        // アプリケーションID
        bean.transactionID = transactionID
        // 画面Id
        bean.screenID = getPreferenceStringValue("screenID") ?: ""
        // バージョンID
        bean.version = getPreferenceStringValue("android_version") ?: ""
        // イベントID
        bean.eventID = getPreferenceStringValue("eventID") ?: ""
        claims[JAG_JWT_DEF_TRAILER_CUSTOME_CLAIM_BFF_HEADER] = bean.toJson()
        claims[JAG_JWT_DEF_TRAILER_CUSTOME_CLAIM_BFF_BODY] = apiData.ifBlank { "" }
        printBffHeader(bean, apiData, commonKey)
    }

    /**
     * Bff パラメータ設定.
     */
    private fun asyncBffParamSet(claims: MutableMap<String, Any>, data:String) {
        val list: Array<String> = arrayOf(
            ConstUtil.COMMON_KEY_LABEL,
            ConstUtil.JBA_ID_TOKEN,
            ConstUtil.USER_ID_TOKEN,
            ConstUtil.DEVICE_ID
        )
        val jagPeerBean = KeyStoreUtil().getJagInfo(list)
        // 共通キー
        val commonKey = jagPeerBean.jagEncryptedKey
        // JBAID
        val jbaIdToken = jagPeerBean.customerId
        // 利用者IDトークン
        val userIdToken = jagPeerBean.userId
        // 端末ID
        val deviceId = jagPeerBean.deviceId
        // 取引ID
        val calendar = Calendar.getInstance()
        val transactionID = EditCheckUtil.formatDateYYYYMMDDHHMMSSMI(calendar.time) + HALF_HYPHEN + deviceId

        Log.i("thread","async data = $data ")
        // API:データ
        val apiData =
            CommonKeyAESUtil().encrypt(data, commonKey)
        val bean = BffJwtPayloadAuthTokenBean()
        // JBAID
        bean.jbaIdToken = jbaIdToken
        // USERID
        bean.userIDToken = userIdToken
        // アプリケーションID
        bean.applicationID = Config.getAppId()
        // デバイスID
        bean.deviceID = deviceId
        // OS
        bean.os = Config.OS_TYPE
        // アプリケーションID
        bean.transactionID = transactionID
        // 画面Id
        bean.screenID = getPreferenceStringValue("screenID") ?: ""
        // バージョンID
        bean.version = getPreferenceStringValue("android_version") ?: ""
        // イベントID
        bean.eventID = getPreferenceStringValue("eventID") ?: ""
        claims[JAG_JWT_DEF_TRAILER_CUSTOME_CLAIM_BFF_HEADER] = bean.toJson()
        claims[JAG_JWT_DEF_TRAILER_CUSTOME_CLAIM_BFF_BODY] = apiData.ifBlank { "" }
        printBffHeader(bean, apiData, commonKey)
    }

    /**
     * BFF パラメータ設定.
     */
    private fun jagParamSet(
        jwtType: Int,
        claims: MutableMap<String, Any>
    ) {
        if (jwtType == 0) {
            val list: Array<String> = arrayOf(
                ConstUtil.COMMON_KEY_LABEL,
                ConstUtil.JBA_ID_TOKEN,
                ConstUtil.USER_ID_TOKEN,
                ConstUtil.DEVICE_ID
            )
            val jagPeerBean = KeyStoreUtil().getJagInfo(list)
            val bean = JagJwtPayloadAuthTokenBean()
            // JBAID
            bean.jbaId = jagPeerBean.customerId
            // USERID
            bean.userId = jagPeerBean.userId
            // チャレンジトークン
            bean.challengeToken = RSAUtil().encryptAESByJavaCrypt(
                jagPeerBean.deviceId,
                RSAUtil().rsaDecrypt(jagPeerBean.jagEncryptedKey),
                String(Base64.getDecoder().decode(ConstUtil.JAG_ENV_CLIENT_SECRET_KEY))
            )
            claims[JAG_JWT_DEF_PROFILE_CUSTOME_CLAIM_PAYLOAD] = bean.toJson()
            printJwt(bean)
        } else if (jwtType == 1) {
            val list: Array<String> = arrayOf(
                ConstUtil.REFRESH_TOKEN,
                ConstUtil.JBA_ID_TOKEN,
                ConstUtil.USER_ID_TOKEN,
            )
            val jagPeerBean = KeyStoreUtil().getJagInfo(list)
            val bean = JagJwtPayloadRefreshTokenBean()
            // JBAID
            bean.jbaId = jagPeerBean.customerId
            // USERID
            bean.userId = jagPeerBean.userId
            // リフレッシュトークン
            bean.refreshToken = jagPeerBean.jagRefreshToken
            claims[JAG_JWT_DEF_PROFILE_CUSTOME_CLAIM_PAYLOAD] = bean.toJson()
            printToken(bean)
        }
    }

    /**
     * JWT JAG用ログ.
     */
    private fun printJwt(bean: JagJwtPayloadAuthTokenBean) {
        val stringBuilder = StringBuilder()
        stringBuilder.appendLine("\r\n")
        stringBuilder.appendLine(
            "->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->"
        )
        stringBuilder.appendLine("JWT:JAG:{USERID=${bean.userId}}\n")
        stringBuilder.appendLine("JWT:JAG:{JBAID=${bean.jbaId}}\n")
        stringBuilder.appendLine("JWT:JAG:{チャレンジトークン=${bean.challengeToken}}\n")
        // 脆弱性診断対応：ログに重要情報を出力しないようにする（開発時、debugログを一時出力はOK）
//        LogPrintUtil.debug(stringBuilder.toString())
    }

    /**
     * アクセストークンログ.
     */
    private fun printToken(bean: JagJwtPayloadRefreshTokenBean) {
        val stringBuilder = StringBuilder()
        stringBuilder.appendLine("\r\n")
        stringBuilder.appendLine(
            "->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->"
        )
        stringBuilder.appendLine("JWT:JAG:{USERID=${bean.userId}}\n")
        stringBuilder.appendLine("JWT:JAG:{JBAID=${bean.jbaId}}\n")
        stringBuilder.appendLine("JWT:JAG:{リフレッシュトークン=${bean.refreshToken}}\n")
        // 脆弱性診断対応：ログに重要情報を出力しないようにする（開発時、debugログを一時出力はOK）
//        LogPrintUtil.debug(stringBuilder.toString())
    }

    /**
     * JWT BFF用Headerログ.
     */
    private fun printBffHeader(bean: BffJwtPayloadAuthTokenBean, apiData: String?, commonKey: String) {
        val stringBuilder = StringBuilder()
        val decryptApiData = CommonKeyAESUtil().decrypt(apiData, commonKey)
        stringBuilder.appendLine("\r\n")
        stringBuilder.appendLine(
            "->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->"
        )
        stringBuilder.appendLine("JWT BFF Header:{JBAID=${bean.jbaIdToken}}\n")
        stringBuilder.appendLine("JWT BFF Header:{USERID=${bean.userIDToken}}\n")
        stringBuilder.appendLine("JWT BFF Header:{アプリケーションID=${bean.applicationID}}\n")
        stringBuilder.appendLine("JWT BFF Header:{デバイスID=${bean.deviceID}}\n")
        stringBuilder.appendLine("JWT BFF Header:{バージョンID=${bean.version}}\n")
        stringBuilder.appendLine("JWT BFF Header:{OS=${bean.os}}\n")
        stringBuilder.appendLine("JWT BFF Header:{アプリケーションID=${bean.transactionID}}\n")
        stringBuilder.appendLine("JWT BFF Header:{画面Id=${bean.screenID}}\n")
        stringBuilder.appendLine("JWT BFF Header:{イベントID=${bean.eventID}}\n")
        stringBuilder.appendLine("JWT BFF 復号化引数:{$decryptApiData}\n")
        // 脆弱性診断対応：ログに重要情報を出力しないようにする（開発時、debugログを一時出力はOK）
//        LogPrintUtil.debug(stringBuilder.toString())
    }
}

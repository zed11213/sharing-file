package jp.co.jsbank.mb.bankingapp.utils

import android.annotation.SuppressLint
import java.time.format.DateTimeFormatter
import java.util.*
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.HALF_HYPHEN

/**
 * 年取得
 */
fun Date.getYearValue(): Int {
    val calendar = GregorianCalendar()
    calendar.time = this
    return calendar.get(Calendar.YEAR)
}

/**
 * 月取得
 */
fun Date.getMonthValue(): Int {
    val calendar = GregorianCalendar()
    calendar.time = this
    return calendar.get(Calendar.MONTH) + 1
}

/**
 * 日取得
 */
fun Date.getDayOfMonthValue(): Int {
    val calendar = GregorianCalendar()
    calendar.time = this
    return calendar.get(Calendar.DAY_OF_MONTH)
}

/**
 * 「yyyymmdd」を「yyyy-mm-dd」に変更する
 */
fun dateAddHyphen(strY: String, strM: String, strD: String): String {
    return strY + HALF_HYPHEN + strM + HALF_HYPHEN + strD
}

/**
 * 年が閏年かどうかを判断する
 */
class DateUtil {
    companion object {
        fun getDayCountOfMonth(year: Int, month: Int): Int {
            return if (month == 2) {
                if (year % 4 == 0 && year % 100 != 0 || year % 400 == 0) {
                    29
                } else {
                    28
                }
            } else if (month == 4 || month == 6 || month == 9 || month == 11) {
                30
            } else
                31
        }
    }
}

/**
 * 「yyyy-MM-ddTHH:mm:ss.SSSSSS」を「***」に変更する
 */
@SuppressLint("WeekBasedYear")
fun dateFormatTo(
    date: String,
    patternFrom: String = ConstUtil.DATE_FORMAT_YYYY_MM_DD_T_HH_MM_SS_MI,
    patternTo: String = ConstUtil.DATE_FORMAT_CHARACTERS_YYYY_MM_DD
): String {
    return if (date.isNotBlank()) {
        val formatter = DateTimeFormatter.ofPattern(patternFrom)
        val parsedDate = formatter.parse(date)
        val displayFormatter = DateTimeFormatter.ofPattern(patternTo)
        displayFormatter.format(parsedDate)
    } else {
        ""
    }
}

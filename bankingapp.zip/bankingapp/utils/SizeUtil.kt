package jp.co.jsbank.mb.bankingapp.utils

import android.content.res.Resources
import android.util.TypedValue
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import jp.co.jsbank.mb.bankingapp.system.MyApp.Companion.CONTEXT

/**
 * サイズ変更クラス.
 */
object SizeUtil {
    fun dp2px(dpValue: Float): Int {
        val scale = Resources.getSystem().displayMetrics.density
        return (dpValue * scale + 0.5f).toInt()
    }

    fun px2sp(pxValue: Float): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_SP,
            pxValue,
            CONTEXT.resources.displayMetrics
        ).toInt()
    }

    // DP:Width
    fun Int.wdp(): Dp {
        val screenDp =
            Resources.getSystem().displayMetrics.widthPixels / Resources.getSystem().displayMetrics.density
        return (this.toFloat() / 400 * screenDp).dp
    }

    // DP:Height
    fun Int.hdp(): Dp {
        val screenDp =
            Resources.getSystem().displayMetrics.heightPixels / Resources.getSystem().displayMetrics.density
        return (this.toFloat() / 400 * screenDp).dp
    }

    // SP:Width
    fun Int.wsp(): TextUnit {
        val screenDp =
            Resources.getSystem().displayMetrics.widthPixels / Resources.getSystem().displayMetrics.density
        return (this.toFloat() / 750 * screenDp).sp
    }

    // SP:Height
    fun Int.hsp(): TextUnit {
        val screenDp =
            Resources.getSystem().displayMetrics.heightPixels / Resources.getSystem().displayMetrics.density
        return (this.toFloat() / 750 * screenDp).sp
    }
}

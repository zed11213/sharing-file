package jp.co.jsbank.mb.bankingapp.utils

import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import androidx.annotation.RequiresApi
import jp.co.jsbank.mb.bankingapp.bean.common.JagPeerBean
import jp.co.jsbank.mb.bankingapp.system.MyApp.Companion.FILES_DIRECTORY
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.charset.StandardCharsets
import java.security.*
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.CipherOutputStream

/**
 * KeyStore暗号化クラス.
 */
class KeyStoreUtil {
    private val _tag = "KeyStore暗号化："
    private val _keyType = "AndroidKeyStore"
    private val _algorithm = "RSA/ECB/PKCS1Padding"
    private val _provider = "AndroidKeyStoreBCWorkaround"
    private val _savePathKey = "KeyPairPathKey"

    // 暗号化テキストの保存先
    private val encryptedDataFilePath =
        FILES_DIRECTORY + File.separator.toString()

    // キーストアキャッシュオブジェクト
    object KeyStoreCache {
        // セキュリティのためデータ型はByteArrayで保持する
        val map = hashMapOf<String, ByteArray>()

        // キャッシュ機能の有効フラグ。初期値は無効
        private var active: Boolean = false

        // キャッシュを有効化
        @Synchronized
        fun activate() {
            active = true
//            LogPrintUtil.verbose("キャッシュON")
        }

        // キャッシュを無効化
        @Synchronized
        fun deactivate() {
            active = false
            // 情報クリア
            clear()
//            LogPrintUtil.verbose("キャッシュOFF")
        }

        // キャッシュ有効化状態を返す
        fun isActive(): Boolean {
            return active
        }

        @Synchronized
        fun read(key: String): String {
            return String(map[key] ?: byteArrayOf(), charset("UTF-8"))
        }

        @Synchronized
        fun write(key: String, value: String) {
            if (!active) return
            // セキュリティのためキー削除してから書き込む
            remove(key)
            map[key] = value.toByteArray(charset("UTF-8"))
        }

        @Synchronized
        fun remove(key: String) {
            if (map.containsKey(key)) {
                // セキュリティのため情報を消してから削除する
                map[key]?.fill(0)
                map.remove(key)
            }
        }

        fun containsKey(key: String): Boolean {
            if (!active) return false
            return map.containsKey(key)
        }

        @Synchronized
        fun clear() {
            for (item in map) {
                // セキュリティのため情報を消してから削除する
                item.value.fill(0)
            }
            map.clear()
        }
    }

    // キャッシュを有効化
    fun activateCache() {
        KeyStoreCache.activate()
    }

    // キャッシュを無効化
    fun deactivateCache() {
        KeyStoreCache.deactivate()
    }

    // キャッシュ有効化状態を返す
    fun isActiveCache(): Boolean {
        return KeyStoreCache.isActive()
    }

    // KeyStore暗号化ストレージ
    @RequiresApi(Build.VERSION_CODES.M)
    fun saveToKeyStore(keyAlias: String, plainText: String) {
        try {
            val keyStore = KeyStore.getInstance(_keyType)
            keyStore.load(null)

            // keyStoreに現在のkeyが存在するか否かを判断し、存在しない場合はそのkeyを初期化する
            if (!keyStore.containsAlias(_savePathKey)) {
                val spec: KeyPairGenerator =
                    KeyPairGenerator.getInstance(
                        KeyProperties.KEY_ALGORITHM_RSA, _keyType
                    )
                spec.initialize(
                    KeyGenParameterSpec.Builder(
                        _savePathKey,
                        KeyProperties.PURPOSE_DECRYPT or KeyProperties.PURPOSE_ENCRYPT
                    )
                        .setKeySize(4096)
                        .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_RSA_PKCS1)
                        .build()
                )
                spec.generateKeyPair()
            }
            val privateKeyEntry =
                keyStore.getEntry(_savePathKey, null) as KeyStore.PrivateKeyEntry
            val publicKey: PublicKey = privateKeyEntry.certificate.publicKey

            // ここでパディングタイプを変更し、AndroidKeyStoreBookaroundに変更しました
            val inCipher: Cipher =
                Cipher.getInstance(_algorithm, _provider)
            inCipher.init(Cipher.ENCRYPT_MODE, publicKey)

            val cipherOutputStream = CipherOutputStream(
                FileOutputStream(encryptedDataFilePath + keyAlias), inCipher
            )
            // 文字列リテラルをUTF-8に置き換えます
            cipherOutputStream.write(plainText.toByteArray(charset("UTF-8")))
            cipherOutputStream.close()

            // キーストアキャッシュを更新
            KeyStoreCache.write(keyAlias, plainText)
        } catch (e: Exception) {
            LogPrintUtil.error(e.toString())
        }
    }

    // KeyStoreから、情報の取得
    fun getFromKeyStore(keyAlias: String): String {

        if (KeyStoreCache.containsKey(keyAlias)) {
            // キャッシュにあれば、キーストアキャッシュより取得
//            LogPrintUtil.verbose("キャッシュから取得：[$keyAlias]")
            return KeyStoreCache.read(keyAlias)
        }

        val keyStore = KeyStore.getInstance(_keyType)
        keyStore.load(null)
        if (keyStore.getEntry(_savePathKey, null) == null) {
            return ""
        }
        val privateKeyEntry =
            keyStore.getEntry(_savePathKey, null) as KeyStore.PrivateKeyEntry
        val privateKey: PrivateKey = privateKeyEntry.privateKey
        val publicKey: PublicKey = privateKeyEntry.certificate.publicKey

        val outCipher =
            Cipher.getInstance(_algorithm, _provider)
        outCipher.init(Cipher.DECRYPT_MODE, privateKey)

        try {
            val cipherInputStream = CipherInputStream(
                FileInputStream(encryptedDataFilePath + keyAlias),
                outCipher
            )
            val roundTrippedBytes = ByteArray(1000)
            var index = 0
            var nextByte: Int
            while (cipherInputStream.read().also { nextByte = it } != -1) {
                roundTrippedBytes[index] = nextByte.toByte()
                index++
            }

            // キーストアキャッシュを更新
            KeyStoreCache.write(keyAlias, String(roundTrippedBytes, 0, index, StandardCharsets.UTF_8))

            // 文字列リテラルをUTF-8に置き換えます
            return String(roundTrippedBytes, 0, index, StandardCharsets.UTF_8)
        } catch (e: Exception) {
            return ""
        }
    }

    // KeyStoreから、情報の取得
    fun getFromOldKeyStore(keyAlias: String): String {
        val keyStore = KeyStore.getInstance(_keyType)
        keyStore.load(null)
        if (keyStore.getEntry(keyAlias, null) == null) {
            return ""
        }
        val privateKeyEntry =
            keyStore.getEntry(keyAlias, null) as KeyStore.PrivateKeyEntry
        val privateKey: PrivateKey = privateKeyEntry.privateKey
        val publicKey: PublicKey = privateKeyEntry.certificate.publicKey

        val outCipher =
            Cipher.getInstance(_algorithm, _provider)
        outCipher.init(Cipher.DECRYPT_MODE, privateKey)

        val cipherInputStream = CipherInputStream(
            FileInputStream(encryptedDataFilePath + keyAlias),
            outCipher
        )
        val roundTrippedBytes = ByteArray(1000)

        var index = 0
        var nextByte: Int
        while (cipherInputStream.read().also { nextByte = it } != -1) {
            roundTrippedBytes[index] = nextByte.toByte()
            index++
        }

        // 文字列リテラルをUTF-8に置き換えます
        return String(roundTrippedBytes, 0, index, StandardCharsets.UTF_8)
    }

    // Jag情報ローカルに保存する
    @Synchronized
    fun jagInfoSave(
        JagPeerBean: JagPeerBean = JagPeerBean()
    ) {
        val map = hashMapOf<String, String>()

        // トランザクションID
        if (JagPeerBean.jagTrxId.isNotBlank())
            map[ConstUtil.JAG_RES_TRXID] = JagPeerBean.jagTrxId
        // 共通鍵
        if (JagPeerBean.jagEncryptedKey.isNotBlank())
            map[ConstUtil.COMMON_KEY_LABEL] = JagPeerBean.jagEncryptedKey
        // アクセストークン
        if (JagPeerBean.jagAccessToken.isNotBlank())
            map[ConstUtil.ACCESS_TOKEN] = JagPeerBean.jagAccessToken
        // リフレッシュトークン
        if (JagPeerBean.jagRefreshToken.isNotBlank())
            map[ConstUtil.REFRESH_TOKEN] = JagPeerBean.jagRefreshToken
        // 顧客ID
        if (JagPeerBean.customerId.isNotBlank())
            map[ConstUtil.JBA_ID_TOKEN] = JagPeerBean.customerId
        // 利用者ID
        if (JagPeerBean.userId.isNotBlank())
            map[ConstUtil.USER_ID_TOKEN] = JagPeerBean.userId
        // デバイスID
        if (JagPeerBean.deviceId.isNotBlank())
            map[ConstUtil.DEVICE_ID] = JagPeerBean.deviceId

        if (map.isNotEmpty())
            KeyStoreUtil().saveMapToKeyStore(map)
    }

    // キーからJag情報取得
//    @Synchronized
//    fun getJagInfo(): JagPeerBean {
//        val list: Array<String> = arrayOf(
//            ConstUtil.JAG_RES_TRXID,
//            ConstUtil.COMMON_KEY_LABEL,
//            ConstUtil.ACCESS_TOKEN,
//            ConstUtil.REFRESH_TOKEN,
//            ConstUtil.JBA_ID_TOKEN,
//            ConstUtil.USER_ID_TOKEN,
//            ConstUtil.DEVICE_ID
//        )
//        val map = getMapFromKeyStore(list)
//
//        val jagPeerBean = JagPeerBean()
//        // トランザクションID
//        jagPeerBean.jagTrxId = map[ConstUtil.JAG_RES_TRXID] ?: ""
//        // 共通鍵
//        jagPeerBean.jagEncryptedKey = map[ConstUtil.COMMON_KEY_LABEL] ?: ""
//        // アクセストークン
//        jagPeerBean.jagAccessToken = map[ConstUtil.ACCESS_TOKEN] ?: ""
//        // リフレッシュトークン
//        jagPeerBean.jagRefreshToken = map[ConstUtil.REFRESH_TOKEN] ?: ""
//        // 顧客ID
//        jagPeerBean.customerId = map[ConstUtil.JBA_ID_TOKEN] ?: ""
//        // 利用者ID
//        jagPeerBean.userId = map[ConstUtil.USER_ID_TOKEN] ?: ""
//        // デバイスID
//        jagPeerBean.deviceId = map[ConstUtil.DEVICE_ID] ?: ""
//        return jagPeerBean
//    }

    @Synchronized
    fun getJagInfo(list: Array<String>): JagPeerBean {
        val map = getMapFromKeyStore(list)

        val jagPeerBean = JagPeerBean()
        // トランザクションID
        jagPeerBean.jagTrxId = map[ConstUtil.JAG_RES_TRXID] ?: ""
        // 共通鍵
        jagPeerBean.jagEncryptedKey = map[ConstUtil.COMMON_KEY_LABEL] ?: ""
        // アクセストークン
        jagPeerBean.jagAccessToken = map[ConstUtil.ACCESS_TOKEN] ?: ""
        // リフレッシュトークン
        jagPeerBean.jagRefreshToken = map[ConstUtil.REFRESH_TOKEN] ?: ""
        // 顧客ID
        jagPeerBean.customerId = map[ConstUtil.JBA_ID_TOKEN] ?: ""
        // 利用者ID
        jagPeerBean.userId = map[ConstUtil.USER_ID_TOKEN] ?: ""
        // デバイスID
        jagPeerBean.deviceId = map[ConstUtil.DEVICE_ID] ?: ""
        return jagPeerBean
    }

    // Jag情報クリア
    @Synchronized
    fun jagInfoClear() {
        val map = hashMapOf<String, String>()

        // 顧客ID
        map[ConstUtil.JBA_ID_TOKEN] = ""
        // 利用者ID
        map[ConstUtil.USER_ID_TOKEN] = ""
        // アクセストークン
        map[ConstUtil.ACCESS_TOKEN] = ""
        // リフレッシュトークン
        map[ConstUtil.REFRESH_TOKEN] = ""

        KeyStoreUtil().saveMapToKeyStore(map)
    }

    // KeyStore暗号化ストレージ
    @RequiresApi(Build.VERSION_CODES.M)
    fun saveMapToKeyStore(map: Map<String, String>) {
        try {
            val keyStore = KeyStore.getInstance(_keyType)
            keyStore.load(null)

            // keyStoreに現在のkeyが存在するか否かを判断し、存在しない場合はそのkeyを初期化する
            if (!keyStore.containsAlias(_savePathKey)) {
                val spec: KeyPairGenerator =
                    KeyPairGenerator.getInstance(
                        KeyProperties.KEY_ALGORITHM_RSA, _keyType
                    )
                spec.initialize(
                    KeyGenParameterSpec.Builder(
                        _savePathKey,
                        KeyProperties.PURPOSE_DECRYPT or KeyProperties.PURPOSE_ENCRYPT
                    )
                        .setKeySize(4096)
                        .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_RSA_PKCS1)
                        .build()
                )
                spec.generateKeyPair()
            }
            val privateKeyEntry =
                keyStore.getEntry(_savePathKey, null) as KeyStore.PrivateKeyEntry
            val publicKey: PublicKey = privateKeyEntry.certificate.publicKey

            // ここでパディングタイプを変更し、AndroidKeyStoreBookaroundに変更しました
            val inCipher: Cipher =
                Cipher.getInstance(_algorithm, _provider)
            inCipher.init(Cipher.ENCRYPT_MODE, publicKey)

            for ((keyAlias, plainText) in map) {
                val cipherOutputStream = CipherOutputStream(
                    FileOutputStream(encryptedDataFilePath + keyAlias), inCipher
                )
                // 文字列リテラルをUTF-8に置き換えます
                cipherOutputStream.write(plainText.toByteArray(charset("UTF-8")))
                cipherOutputStream.close()

                // キーストアキャッシュを更新
                KeyStoreCache.write(keyAlias, plainText)
            }
        } catch (e: Exception) {
            LogPrintUtil.error(e.toString())
        }
    }

    // KeyStoreから、情報の取得
    private fun getMapFromKeyStore(list: Array<String>): Map<String,String> {
        val map = hashMapOf<String, String>()
        var privateKey: PrivateKey? = null

        for (keyAlias in list) {

            if (KeyStoreCache.containsKey(keyAlias)) {
                // キャッシュにあれば、キーストアキャッシュより取得
//            LogPrintUtil.verbose("キャッシュから取得：[$keyAlias]")
                map[keyAlias] = KeyStoreCache.read(keyAlias)
                continue
            }

            if (privateKey == null) {
                val keyStore = KeyStore.getInstance(_keyType)
                keyStore.load(null)
                if (keyStore.getEntry(_savePathKey, null) == null) {
                    map[keyAlias] = ""
                    continue
                }
                val privateKeyEntry =
                    keyStore.getEntry(_savePathKey, null) as KeyStore.PrivateKeyEntry
                privateKey = privateKeyEntry.privateKey
                val publicKey: PublicKey = privateKeyEntry.certificate.publicKey
            }

            val outCipher =
                Cipher.getInstance(_algorithm, _provider)
            outCipher.init(Cipher.DECRYPT_MODE, privateKey)

            try {
                val cipherInputStream = CipherInputStream(
                    FileInputStream(encryptedDataFilePath + keyAlias),
                    outCipher
                )
                val roundTrippedBytes = ByteArray(1000)
                var index = 0
                var nextByte: Int
                while (cipherInputStream.read().also { nextByte = it } != -1) {
                    roundTrippedBytes[index] = nextByte.toByte()
                    index++
                }

                // キーストアキャッシュを更新
                KeyStoreCache.write(keyAlias, String(roundTrippedBytes, 0, index, StandardCharsets.UTF_8))

                // 文字列リテラルをUTF-8に置き換えます
                map[keyAlias] = String(roundTrippedBytes, 0, index, StandardCharsets.UTF_8)
                continue
            } catch (e: Exception) {
                map[keyAlias] = ""
                continue
            }
        }

        return map
    }
}

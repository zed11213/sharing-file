package jp.co.jsbank.mb.bankingapp.utils

import java.text.DecimalFormat
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.AMOUNT_FORMAT_COMMA
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.AMOUNT_FORMAT_SPOT
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.AMOUNT_FORMAT_TYPE1
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.AMOUNT_FORMAT_TYPE2
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.AMOUNT_FORMAT_TYPE3
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.AMOUNT_FORMAT_TYPE4

/**
 * 金額フォーマット.
 */
object FmtMicrometerUtil {
    /**
     * @Title: fmtMicrometer
     * @Description: 数値を千単位で書式設定
     * @param text フォーマット要対象
     * @return String  フォーマットした数値
     */
    fun fmtMicrometer(text: String): String {
        val noStar = text.replace("*", "")
        val star = text.replace(noStar, "")
        if (text.contains(AMOUNT_FORMAT_COMMA)) {
            return text
        }
        val df: DecimalFormat = if (text.indexOf(AMOUNT_FORMAT_SPOT) > 0) {
            when {
                text.length - text.indexOf(AMOUNT_FORMAT_SPOT) - 1 == 0 -> {
                    DecimalFormat(AMOUNT_FORMAT_TYPE1)
                }
                text.length - text.indexOf(AMOUNT_FORMAT_SPOT) - 1 == 1 -> {
                    DecimalFormat(AMOUNT_FORMAT_TYPE2)
                }
                else -> {
                    DecimalFormat(AMOUNT_FORMAT_TYPE3)
                }
            }
        } else {
            DecimalFormat(AMOUNT_FORMAT_TYPE4)
        }

        return if (noStar.isBlank()) {
            "0"
        } else {
            star + df.format(noStar.toLong())
        }
    }
}

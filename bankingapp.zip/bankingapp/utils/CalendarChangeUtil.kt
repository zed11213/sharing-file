package jp.co.jsbank.mb.bankingapp.utils

import java.time.chrono.JapaneseDate
import java.time.format.DateTimeFormatter

/**
 * 和暦を日暦変更.
 */
object CalendarChangeUtil {

    /**
     * 和暦を日暦変更.
     */
    fun calendarChange(value: String): String {
        if (value.isBlank()) {
            return ""
        }

        val yearList = listOf("令和", "平成", "昭和", "大正", "明治")
        var changeFlag = false
        yearList.forEach {
            if (value.contains(it)) {
                changeFlag = true
            }
        }
        if (!changeFlag) return value

        val iYear: Int
        val sYear: String = value.split("年")[0]
            .replace("令和", "")
            .replace("平成", "")
            .replace("昭和", "")
            .replace("大正", "")
            .replace("明治", "")

        val cnt: String = value.substring(0, 2)
            .replace("令和", "2019")
            .replace("平成", "1989")
            .replace("昭和", "1926")
            .replace("大正", "1912")
            .replace("明治", "1868")
        iYear = sYear.toInt() + cnt.toInt() - 1
        return iYear.toString() + "年" + value.split("年")[1].replace("生", "")
    }

    /**
     * 和暦を日暦変更.
     */
    fun imperialCalendarChange(value: String): String {
        if (value.isNotBlank() && value.length == 8) {
            val formatter: DateTimeFormatter = DateTimeFormatter.ofPattern("Gyy年M⽉d⽇")
            val japaneseDate: JapaneseDate = JapaneseDate.of(
                value.substring(0, 4).toInt(),
                value.substring(4, 6).toInt(),
                value.substring(6, 8).toInt()
            )
            val sb = StringBuilder()
            sb.append(japaneseDate.format(formatter))
            return sb.toString()
        }
        return ""
    }
}

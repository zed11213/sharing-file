package jp.co.jsbank.mb.bankingapp.utils

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Context
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.system.MyApp
import kotlin.system.exitProcess

/**
 * すべてのエラーキャプチャ
 */
class MyCrashHandler() : Thread.UncaughtExceptionHandler {
    // システムデフォルトのUncaughtException処理クラス
    private var mDefaultHandler: Thread.UncaughtExceptionHandler? = null

    // プログラムのContextオブジェクト
    private var mContext: Context? = null

    // CrashHandlerインスタンスのシングルケースモードを取得-ダブルチェックロック
    fun getInstance(): MyCrashHandler? {
        if (myCrashHandler == null) {
            synchronized(MyCrashHandler::class.java) {
                if (myCrashHandler == null) {
                    myCrashHandler = MyCrashHandler()
                }
            }
        }
        return myCrashHandler
    }

    /**
     * 初期化
     * @param ctx
     */
    fun init(ctx: Context?) {
        mContext = ctx
        // システムのデフォルトのUncaughtExceptionプロセッサを取得する
        mDefaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        // このMyCrashHandlerをプログラムのデフォルトプロセッサとして設定します。
        Thread.setDefaultUncaughtExceptionHandler(this)
    }

    /**
     * UncaughtExceptionが発生すると、この関数が処理されます。
     */
    override fun uncaughtException(t: Thread, e: Throwable) {
        if (!handleExample(e) && mDefaultHandler != null) {
            // ユーザが処理していない場合は、システムのデフォルトの例外プロセッサに処理させ、例外が処理されたかどうかを判断することを目的とします。
            mDefaultHandler!!.uncaughtException(t, e)
        } else {
            LogPrintUtil.error(e.message.toString())
            LogPrintUtil.error(e.stackTraceToString())
            AlertDialog.Builder(MainActivity.ACTIVITY, R.style.DialogStyle)
                .setTitle(R.string.mblg0304_imageHeadDialog_title)
                .setMessage(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.JAG_MSG_ID_CD19),
                        ConstUtil.APP_ERROR_CODE_MBLO0005
                    )
                )
                .setCancelable(false)
                .setPositiveButton(
                    R.string.common_dialog_button_close
                ) { dialog, _ ->
                    dialog.dismiss()
                    // クラッシュしたappプロセスを閉じる
                    exitProcess(0)
                }.create().show()
        }
    }

    /**
     * エラー処理をカスタマイズし、エラー情報を収集する異常情報を保存してエラーレポートを送信などの操作をここで完了します。
     *
     * @param ex
     * @return true：この異常情報を処理した場合；そうでなければfalseに戻ります。
     */
    private fun handleExample(ex: Throwable?): Boolean {
        if (ex == null) return false
        return true
    }

    companion object {
        @SuppressLint("StaticFieldLeak")
        @Volatile
        private var myCrashHandler: MyCrashHandler? = null
    }
}

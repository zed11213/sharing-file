package jp.co.jsbank.mb.bankingapp.utils

import android.net.Uri
import android.os.Bundle
import android.os.Parcelable
import android.util.Log
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import java.net.URI
import java.net.URISyntaxException
import jp.co.jsbank.mb.bankingapp.system.MainActivity

/**
 * ナビゲーション用クラス.
 */
object RouteUtil {

    const val STEAD_SYMBOL = "^0^"
    fun initBundle(params: Parcelable) = Bundle().apply { putParcelable(ARGS, params) }

    fun navTo(
        destinationName: String,
        args: Any? = null,
        backStackRouteName: String? = null,
        isLaunchSingleTop: Boolean = true,
        needToRestoreState: Boolean = true,
    ) {
        var argument = ""
        if (args != null) {
            argument = when (args) {
                is Parcelable -> {
                    String.format("/%s", Uri.encode(args.toJson()))
                }
                else -> String.format("/%s", args)
            }
        }
        navigate(destinationName, argument, backStackRouteName, isLaunchSingleTop, needToRestoreState)
    }

    private fun navigate(
        destinationName: String,
        argument: String,
        backStackRouteName: String?,
        isLaunchSingleTop: Boolean,
        needToRestoreState: Boolean
    ) {
        ////脆弱性診断対応：ログに重要情報を出力しないようにする（開発時、debugログを一時出力はOK）
//        //Log.i("Route::navigate", "destination $destinationName")
        MainActivity.NAVCTRL?.navigate("$destinationName$argument") {
            if (backStackRouteName != null) {
                popUpTo(backStackRouteName) { saveState = true }
            }
            launchSingleTop = isLaunchSingleTop
            restoreState = needToRestoreState
        }
    }

    fun NavHostController.back() {
        navigateUp()
    }

    private fun getPopUpId(navCtrl: NavHostController, routeName: String?): Int {
        val defaultId = navCtrl.graph.findStartDestination().id
        return if (routeName == null) {
            defaultId
        } else {
            navCtrl.findDestination(routeName)?.id ?: defaultId
        }
    }

    fun <T> getArguments(navCtrl: NavHostController): T? {
        return navCtrl.previousBackStackEntry?.arguments?.getParcelable(ARGS)
    }

    private const val ARGS = "args"

    @Throws(URISyntaxException::class)
    fun checkDomain(inputUrl: String): Boolean {
        if (!inputUrl.startsWith("http://") && !inputUrl.startsWith("https://")) {
            return false
        }
        val whiteList = arrayOf(WebConstUtil.WEB_HOST)
        val url = URI(inputUrl)
        val inputDomain = url.host
        for (whiteDomain in whiteList) {
            if (inputDomain.endsWith(".$whiteDomain") || inputDomain == whiteDomain)
                return true
        }
        return false
    }
}

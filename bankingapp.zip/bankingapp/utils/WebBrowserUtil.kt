package jp.co.jsbank.mb.bankingapp.utils

import android.content.Intent
import android.net.Uri
import jp.co.jsbank.mb.bankingapp.system.MyApp

/**
 *  Webクラス
 */
class WebBrowserUtil {
    // URLを指定してデフォルトブラウザを開く
    fun setWebUrl(web: String) {
        var url = web
        if (!url.contains("http")) run {
            url = "https://$web"
        }

        val uri: Uri = Uri.parse(url)
        val intent = Intent(Intent.ACTION_VIEW, uri)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        MyApp.CONTEXT.startActivity(intent)
    }
}

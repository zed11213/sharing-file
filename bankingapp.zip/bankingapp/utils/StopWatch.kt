package jp.co.jsbank.mb.bankingapp.utils

import android.util.Log

object StopWatch {
    private var startTime: Long = 0L
    private const val TAG = "StopWatch"

    fun  start(msg: String){
        startTime = System.currentTimeMillis()
        Log.i(TAG,"Start: $msg at $startTime")
    }

    fun  time(msg: String){
        val now = System.currentTimeMillis()
        val seconds = (now- startTime) / 1000.0
        val formatted = String.format("%.3f秒",seconds)
        Log.i(TAG,"Start: $msg ->  cost $formatted since start" )
    }

    fun  end(msg: String){
        val end = System.currentTimeMillis()
        val seconds = (end- startTime) / 1000.0
        val formatted = String.format("%.3f秒",seconds)
        Log.i(TAG,"End: $msg ->  cost $formatted since start" )
        startTime = 0L
    }
}

package jp.co.jsbank.mb.bankingapp.utils

import android.content.Context
import android.net.ConnectivityManager

/**
 * ネットワークステータス
 */
object NetCheckUtil {

    /**
     * 現在のネットワークが利用可能かどうかを判断
     *
     * @param context
     * @return
     */
    fun isConnected(context: Context): Boolean {
        val mobileConnection = isMobileConnection(context)
        val wifiConnection = isWIFIConnection(context)
        return !(!mobileConnection && !wifiConnection)
    }

    /**
     * アクセスポイント（APN）が使用可能かどうかを判断する
     *
     * @param context
     * @return
     */
    private fun isMobileConnection(context: Context): Boolean {
        val manager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val networkInfo = manager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE)
        return networkInfo != null && networkInfo.isConnected
    }

    /**
     * wifiが使用可能かどうかを判断する
     *
     * @param context
     * @return
     */
    private fun isWIFIConnection(context: Context): Boolean {
        val manager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val networkInfo = manager.getNetworkInfo(ConnectivityManager.TYPE_WIFI)
        return networkInfo != null && networkInfo.isConnected
    }
}

package jp.co.jsbank.mb.bankingapp.utils

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.hilt.navigation.compose.hiltViewModel
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.locks.ReentrantLock
import jp.co.jsbank.mb.bankingapp.logic.common.VersionUpdateLogic
import jp.co.jsbank.mb.bankingapp.system.Config
import jp.co.jsbank.mb.bankingapp.system.MyApp
import jp.co.jsbank.mb.bankingapp.ui.widgets.dialog.SampleAlertDialog
import kotlin.system.exitProcess
import kotlinx.coroutines.flow.MutableStateFlow

/**
 * アプリケーションストアを開く
 */
object VersionUpdateUtil {

    private val queue = ConcurrentLinkedQueue<String>()
    private var msg = MutableStateFlow("")
    private val lock = ReentrantLock()
    private var title = ""

    /**
     * メッセージ内容設定
     */
    fun postValue(value: String, parmTitle: String = "") {
        title = parmTitle
        queue.add(value)
        try {
            lock.tryLock(10, TimeUnit.MILLISECONDS)
        } catch (e: InterruptedException) {
            return
        }
        try {
            msg.value = queue.poll() ?: ""
        } finally {
            lock.unlock()
        }
    }

    @Composable
    fun PopWin() {
        PopItem()
    }

    @SuppressLint("UnrememberedMutableState")
    @OptIn(ExperimentalAnimationApi::class)
    @Composable
    private fun PopItem() {
        val viewModel: VersionUpdateLogic = hiltViewModel()
        val viewStates = viewModel.viewStates
        val msg by msg.collectAsState()

        if (msg != "") {
            viewModel.openErrorDialog()
        }
        if (viewStates.errorFlag) {
            SampleAlertDialog(
                title = "",
                content = title,
                confirmText = "ストアへ移動",
                hasCancel = false,
                onConfirmClick = {
                    VersionUpdateUtil.msg.value = ""
                    // ダイアログクロス
//                    viewModel.closeErrorDialog()
                    // 更新
                    transferToGooglePlay()
                },
                onDismiss = {
                    // クラッシュしたappプロセスを閉じる
                    exitProcess(0)
                }
            )
        }
    }

    // アプリケーションストアを開く
    private fun transferToGooglePlay() {
        try {
            val applicationId =
                if (Config.isRetail()) "jp.co.jsbank.mb.bankingapp" else "jp.co.jsbank.mb.bankingapp.biz"
//            val uri = Uri.parse("market://details?id=" + BuildConfig.APPLICATION_ID)
            val uri = Uri.parse("market://details?id=$applicationId")
            val intent = Intent(Intent.ACTION_VIEW, uri)
            intent.setPackage(Config.GOOGLE_PLAY)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
            MyApp.CONTEXT.startActivity(intent)
        } catch (e: Exception) {
            val errorInfo = e.message.toString()
            LogPrintUtil.error(errorInfo)
        }
    }
}

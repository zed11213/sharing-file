package jp.co.jsbank.mb.bankingapp.utils

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import jp.co.jsbank.mb.bankingapp.system.MyApp.Companion.CONTEXT
import java.io.*
import java.lang.Exception
import java.util.*

/**
 * テスト用.
 *
 * @param path パス
 */
@RequiresApi(Build.VERSION_CODES.O)
fun encodeBase64FileUtil(path: String?): String? {
    val file = File(path)
    var byteArray: ByteArray? = null
    try {
        val inputStream: InputStream = FileInputStream(file)
        val bos = ByteArrayOutputStream()
        val b = ByteArray(1024 * 11)
        var bytesRead: Int
        while (inputStream.read(b).also { bytesRead = it } != -1) {
            bos.write(b, 0, bytesRead)
        }
        byteArray = bos.toByteArray()
        Log.e("Byte array", ">$byteArray")
    } catch (e: IOException) {
        e.printStackTrace()
    }
    return Base64.getEncoder().encodeToString(byteArray)
}

/**
 * Bitmap to Base64
 */
fun bitmapToBase64(bitmap: Bitmap): String {
    var baos: ByteArrayOutputStream? = null
    var result = ""
    try {
        baos = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos)
        var options = 90
        while (baos.toByteArray().size / 1024 > 1024) {
            baos.reset()
            bitmap.compress(Bitmap.CompressFormat.JPEG, options, baos)
            options -= 10
            if (options < 0) {
                return ""
            }
        }
        baos.flush()
        baos.close()
        result = Base64.getEncoder().encodeToString(baos.toByteArray())
    } catch (e: IOException) {
        e.printStackTrace()
    } finally {
        try {
            baos?.close()
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }
    return result
}

/**
 * Uri to Base64
 */
fun uriToBase64(uri: Uri): String {
    return try {
        val stream = CONTEXT.contentResolver.openInputStream(uri)
        val image = BitmapFactory.decodeStream(stream)
        bitmapToBase64(image)
    } catch (e: Exception) {
        e.printStackTrace()
        ""
    }
}

/**
 * Base64 to Bitmap
 */
fun base64ToBitmap(value: String): Bitmap? {
    val dec = android.util.Base64.decode(value, android.util.Base64.DEFAULT)
    return BitmapFactory.decodeByteArray(dec, 0, dec.size)
}

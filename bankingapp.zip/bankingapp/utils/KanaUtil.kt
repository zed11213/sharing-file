package jp.co.jsbank.mb.bankingapp.utils

/**
 * 半角全角変更.
 */
object KanaUtil {

    /**
     * 半角全角変更の関数（SBC case）
     * 全角スペースは12288、半角スペースは32、その他の文字の半角（33-126）と全角（65281-65374）の対応関係は：すべて65248の差
     *
     * @param input 任意の文字列
     * @return 全角文字列
     */
    fun toSbc(input: String): String {
        if (input.isBlank()) {
            return ""
        }
        val c = input.toCharArray()
        for (i in c.indices) {
            if (c[i].toInt() == 32) {
                c[i] = 12288.toChar()
                continue
            }
            if (c[i].toInt() < 127) {
                c[i] = (c[i] + 65248)
            }
        }
        return String(c)
    }

    /**
     * 全角半角変更の関数（DBC case）
     * 全角スペースは12288、半角スペースは32その他の文字半角（33-126）と全角（65281-65374）の対応関係は：すべて65248の差
     *
     * @param input 任意の文字列
     * @return 半角文字列
     */
    fun toDbc(input: String): String {
        if (input.isBlank()) {
            return ""
        }
        val c = input.toCharArray()
        for (i in c.indices) {
            if (c[i].toInt() == 12288) {
                c[i] = 32.toChar()
                continue
            }
            if (c[i].toInt() in 65281..65374) {
                c[i] = (c[i] - 65248)
            }
        }
        return String(c)
    }
}

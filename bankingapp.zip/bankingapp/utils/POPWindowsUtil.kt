package jp.co.jsbank.mb.bankingapp.utils

import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.ActivityInfo
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.res.stringResource
import androidx.hilt.navigation.compose.hiltViewModel
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.logic.common.POPWindowsLogic
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.system.MyApp
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.widgets.dialog.ImageHeadDialog
import jp.co.jsbank.mb.bankingapp.ui.widgets.dialog.ImageHeadLandscapeDialog
import kotlinx.coroutines.flow.MutableStateFlow
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.locks.ReentrantLock

/**
 * 共通メッセージ表示
 */
@SuppressLint("LogNotTimber")
object POPWindowsUtil {
    private val queue = ConcurrentLinkedQueue<String>()
    private var msg = MutableStateFlow("")
    private val lock = ReentrantLock()
    private var title = ""
    private var errorCode = ""

    /**
     * メッセージ内容設定
     */
    fun postValue(value: String, parmTitle: String = "", parmErrorCode: String = "") {
        title = parmTitle
        errorCode = parmErrorCode
        queue.add(value)
        try {
            lock.tryLock(10, TimeUnit.MILLISECONDS)
        } catch (e: InterruptedException) {
            return
        }
        try {
            msg.value = queue.poll() ?: ""
        } finally {
            lock.unlock()
        }
    }

    @Composable
    fun PopWin() {
        PopItem()
    }

    @SuppressLint("UnrememberedMutableState")
    @OptIn(ExperimentalAnimationApi::class)
    @Composable
    private fun PopItem() {
        val viewModel: POPWindowsLogic = hiltViewModel()
        val viewStates = viewModel.viewStates
        val msg by msg.collectAsState()

        if (msg != "") {
            viewModel.openErrorDialog()
        }
        if (viewStates.errorFlag) {
            if (MainActivity.ACTIVITY?.requestedOrientation == ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE) {
                ImageHeadLandscapeDialog(
                    image = R.drawable.error_info,
                    imageSize = 40,
//                    title = title.ifBlank { "エラーが発生しました" },
                    title = title.ifBlank { "" },
                    content = msg,
                    errorCode = errorCode,
                    buttonLabel = if (errorCode == ConstUtil.APP_ERROR_CODE_MBST0005) {
                        stringResource(id = R.string.common_dialog_button_top)
                    } else {
                        stringResource(id = R.string.common_dialog_button_close)
                    },
                    onButtonClick = {
                        closeDialog(viewModel)
                    }
                )
            } else {
                ImageHeadDialog(
                    image = R.drawable.error_info,
                    imageSize = 100,
//                    title = title.ifBlank { "エラーが発生しました" },
                    title = title.ifBlank { "" },
                    content = msg,
                    errorCode = errorCode,
                    buttonLabel = if (errorCode == ConstUtil.APP_ERROR_CODE_MBST0005) {
                        stringResource(id = R.string.common_dialog_button_top)
                    } else {
                        stringResource(id = R.string.common_dialog_button_close)
                    },
                    onButtonClick = {
                        closeDialog(viewModel)
                    }
                )
            }
        }
    }

    // エラーダイアログ閉じる処理
    private fun closeDialog(viewModel: POPWindowsLogic) {
        msg.value = ""
        if (MainActivity.APP_RESTART_FLAG) {
            viewModel.closeErrorDialog()
            // バンキングアプリ初期化
            systemInfoClear()
        } else {
            when (errorCode) {
                ConstUtil.APP_ERROR_CODE_MBST0005 -> RouteUtil.navTo(RouteName.HOME)
                ConstUtil.APP_ERROR_CODE_MBLO0002 -> viewModel.getDeptList()
                else -> viewModel.closeErrorDialog()
            }
        }
    }
}

// バンキングアプリ初期化
fun systemInfoClear() {
    // リセットフラグ
    PreferenceUtil.setPreferenceStringValue(ConstUtil.BIOMETRIC_RESULT, ConstUtil.BIOMETRIC_RESULT_NOT_ACCESS)
    // デバイスバンディングフラグをtrueに設定する
    PreferenceUtil.setPreferenceBooleanValue(ConstUtil.DEVICE_BINDING_FLAG, false)
    // プッシュ通知登録成功フラグ
    PreferenceUtil.removePreferenceStringValue(ConstUtil.PUSH_OK_FLAG)
    // 利用者ID、アクセストークン、リフレッシュトークン削除バンキングアプリ初期化
    PreferenceUtil.setPreferenceStringValue(
        ConstUtil.ACTIVITY_FLAG,
        ConstUtil.ACTIVITY_FLAG_NO_ACCESS_NO_LOGIN
    )
    MainActivity.APP_RESTART_FLAG = false
    MainActivity.IS_BACK_GROUND = false
    MainActivity.IS_MENU_CC_CARD = false
    PreferenceUtil.setPreferenceBooleanValue(ConstUtil.EXECUTE_FLAG, false)
    MainActivity.ACTIVITY_FLAG = ConstUtil.ACTIVITY_FLAG_NO_ACCESS_NO_LOGIN
    // トークンクリア
    KeyStoreUtil().jagInfoClear()
    // 受付番号をクリア
    KeyStoreUtil().saveToKeyStore(ConstUtil.RECEIPT_NUMBER, "")
    // 受付番号をクリア(CC発行)
    KeyStoreUtil().saveToKeyStore(ConstUtil.CC_RECEIPT_NUMBER, "")
    PreferenceUtil.setPreferenceStringValue(ConstUtil.OPENED_HOPE_DEPARTMENT, "")
    PreferenceUtil.setPreferenceStringValue(ConstUtil.OPENED_DEPARTMENT, "")
    // 入力情報クリア
    RealmClearUtil.realmClear()
    // 利用者設定
    PreferenceUtil.setPreferenceStringValue(ConstUtil.USER, "")
    // PIN不正カウントリセット
    PreferenceUtil.setPreferenceIntValue(ConstUtil.PASS_ERR_COUNT, 0)
    // 生体認証無効
    PreferenceUtil.setPreferenceBooleanValue(ConstUtil.BIOLOGICAL_STATE, false)
    // アプリRestart
    restartApplication()
}

// アプリRestart
fun restartApplication() {
    // リフレッシュトークンが無効の場合
    val intent = Intent(MyApp.CONTEXT, MainActivity::class.java)
    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
    MyApp.CONTEXT.startActivity(intent)
}

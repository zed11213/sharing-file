package jp.co.jsbank.mb.bankingapp.utils

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf

/**
 * ToContinuousHitPrevention  連打防止ボタンのため
 */
object ToContinuousHitPrevention {
    var _sending = mutableStateOf(true)
    val sending: State<Boolean> = _sending
}

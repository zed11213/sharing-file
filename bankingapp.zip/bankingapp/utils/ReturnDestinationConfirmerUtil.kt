package jp.co.jsbank.mb.bankingapp.utils

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import androidx.annotation.NonNull
import androidx.annotation.UiThread
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.polarify.onboarding.sdk.types.internal.ErrorResult

/**
 * ホーム画面遷移を行うクラスです.
 */
object ReturnDestinationConfirmerUtil {
    /**
     * ホーム画面に戻る処理です.
     *
     * @param context コンテキスト
     */
    @UiThread
    fun execute(@NonNull context: Context) {
        AlertDialog.Builder(context, R.style.DialogStyle)
            .setTitle(R.string.dialog_title)
            .setMessage(R.string.dialog_text)
            .setPositiveButton(R.string.dialog_button_continue, null)
            .setNegativeButton(
                R.string.dialog_button_return
            ) { _, _ -> startHomeActivity(context) }
            .create().show() // ダイアログを生成して表示
    }

    /**
     * ホーム画面に戻る処理です.
     *
     * @param context     コンテキスト
     * @param errorResult エラー結果情報
     */
    fun execute(@NonNull context: Context, @NonNull errorResult: ErrorResult?) {
        startHomeActivity(context)
    }

    /**
     * ホーム画面に遷移するインテントを発行します.
     *
     * @param context コンテキスト
     */
    private fun startHomeActivity(@NonNull context: Context) {
        val intent = Intent(context, MainActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
        context.startActivity(intent)
    }
}

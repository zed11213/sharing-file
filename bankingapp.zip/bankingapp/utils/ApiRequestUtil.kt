package jp.co.jsbank.mb.bankingapp.utils

import jp.co.jsbank.mb.bankingapp.system.master.JagApiServiceCode
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.API_METHOD_TYPE
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.API_REQUEST_DATA
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.API_SERVICE_NAME

/**
 * APIリクエスト設定.
 */
object ApiRequestUtil {

    /**
     * APIアクセス前の設定
     *
     * @param type タイプ
     * @param jsonData データ
     * @return
     */
    fun setApiParam(type: String, jsonData: String = "") {
        // タイプ
        PreferenceUtil.setPreferenceStringValue(API_METHOD_TYPE, type)
        // データ
        PreferenceUtil.setPreferenceStringValue(API_REQUEST_DATA, jsonData)
        // API サービス名称
        PreferenceUtil.setPreferenceStringValue(API_SERVICE_NAME, JagApiServiceCode.APIGW.value)
    }

    /**
     * API設定削除
     */
    fun deleteApiParam() {
        // タイプ
        PreferenceUtil.setPreferenceStringValue(API_METHOD_TYPE, "")
        // データ
        PreferenceUtil.setPreferenceStringValue(API_REQUEST_DATA, "")
    }
}

package jp.co.jsbank.mb.bankingapp.utils

import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.FULL_HYPHEN
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.FULL_MACRON
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.HALF_HYPHEN
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.FULL_SPACE
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.HALF_SPACE

object CharacterUtil {
    const val NUMBER_HYPHEN = "0123456789０１２３４５６７８９-ｰ−－ー‐‑—–―"
    //文字変換タイプ
    enum class ConvertType {
        ToFullWidth, //全角に変換
        ToHalfWidth, //半角に変換
        ToUpperAlphabet_HalfOnly, //大文字A～Zに変換する
        ToUpperAiueo_HalfOnly, //大文字ｱｲｳｴｵﾔﾕﾖに変換
        ToHalfPeriod, //、(読点)。 (句点)｀(グレイブアクセント)・(中点)を.(ピリオド)に変換する ※半角のみ
        HalfMacronToHyphen, //半角長音をハイフンに変換
        FullMacronToHyphen, //全角長音をハイフンに変換
        FullHyphenToMacron, //ハイフンを全角長音に変換
        FillZero2, //零埋め（２桁）
    }
    //文字タイプ
    enum class CharacterType {
        Alphabet, //英字
        HalfKana, //半角カナ
        FullKana, //全角カナ
        Full, //全角
        Half, //半角
        Numb, //数字
        Symbol, //記号
        Other, //その他
    }

    /**
     * 、(読点)	。 (句点)｀(グレイブアクセント)・(中点)を.(ピリオド)に変換　※半角のみ
     *
     * @param input 任意の文字列
     * @return 変換後文字列
     */
    fun toHalfPeriod(input: String): String {
        if (input.isBlank()) {
            return ""
        }
        var result = input.replace("･",".")
                          .replace("・",".")
                          .replace("｡",".")
                          .replace("､",".")
                          .replace("`",".")
        return result
    }

    fun toUpperAlphabet_Half(input: String):String{
        return input.map { c ->
            if (c in 'a'..'z'){
                (c.code - 32).toChar()
            }else{
                c
            }
        }.joinToString("")
    }

    /**
     * 半角長音をハイフンu002Dに変換する
     *
     * @param input 任意の文字列
     * @return 変換後文字列
     */
    fun halfWidthMacronToHyphen(input: String): String {
        if (input.isBlank()) {
            return ""
        }
        return input.replace("－", HALF_HYPHEN) // UTF-8 EFBC8D 全角ハイフン
                    .replace("ー", HALF_HYPHEN) // UTF-8 E383BC 全角の長音
                    .replace("‐", HALF_HYPHEN) // UTF-8 E28090 別のハイフン
                    .replace("‑", HALF_HYPHEN) // UTF-8 E28091 改行しないハイフン
                    .replace("–", HALF_HYPHEN) // UTF-8 E28093 ENダッシュ
                    .replace("—", HALF_HYPHEN) // UTF-8 E28094 EMダッシュ
                    .replace("―", HALF_HYPHEN) // UTF-8 E28095 全角のダッシュ
                    .replace("−", HALF_HYPHEN) // UTF-8 E28892 全角のマイナス
                    .replace("ｰ", HALF_HYPHEN) // UTF-8 EFBDB0 半角カナの長音
                    .replace("-", HALF_HYPHEN) // UTF-8 2D     ASCIIのハイフン
    }

    /**
     * 全角長音をハイフンに変換する
     *
     * @param input 任意の文字列
     * @return 変換後文字列
     */
    fun fullWidthMacronToHyphen(input: String): String {
        if (input.isBlank()) {
            return ""
        }
        return input.replace("-", FULL_HYPHEN) // UTF-8 2D     ASCIIのハイフン
                    .replace("ー", FULL_HYPHEN) // UTF-8 E383BC 全角の長音
                    .replace("‐", FULL_HYPHEN) // UTF-8 E28090 別のハイフン
                    .replace("‑", FULL_HYPHEN) // UTF-8 E28091 改行しないハイフン
                    .replace("–", FULL_HYPHEN) // UTF-8 E28093 ENダッシュ
                    .replace("—", FULL_HYPHEN) // UTF-8 E28094 EMダッシュ
                    .replace("―", FULL_HYPHEN) // UTF-8 E28095 全角のダッシュ
                    .replace("−", FULL_HYPHEN) // UTF-8 E28892 全角のマイナス
                    .replace("ｰ", FULL_HYPHEN) // UTF-8 EFBDB0 半角カナの長音
    }

    /**
     * ハイフンを全角長音u30FCに変換する
     *
     * @param input 任意の文字列
     * @return 変換後文字列
     */
    fun fullWidthHyphenToMacron(input: String): String {
        if (input.isBlank()) {
            return ""
        }
        return input.replace("-", FULL_MACRON) // UTF-8 2D     ASCIIのハイフン
                    .replace("ー", FULL_MACRON) // UTF-8 E383BC 全角の長音
                    .replace("‐", FULL_MACRON) // UTF-8 E28090 別のハイフン
                    .replace("‑", FULL_MACRON) // UTF-8 E28091 改行しないハイフン
                    .replace("–", FULL_MACRON) // UTF-8 E28093 ENダッシュ
                    .replace("—", FULL_MACRON) // UTF-8 E28094 EMダッシュ
                    .replace("―", FULL_MACRON) // UTF-8 E28095 全角のダッシュ
                    .replace("−", FULL_MACRON) // UTF-8 E28892 全角のマイナス
                    .replace("ｰ", FULL_MACRON) // UTF-8 EFBDB0 半角カナの長音
    }

    /**
     * 絵文字含めるか
     *
     * @param input 任意の文字列
     * @return true or false
     */
    fun containsEmoji(input: String):Boolean{
        input.forEach { char ->
            val type = Character.getType(char)
            if (type == Character.SURROGATE.toInt() || type == Character.OTHER_SYMBOL.toInt()) {
                return true
            }
        }
        return false
    }

    /**
     * 数字ハイフン長音のみか
     *
     * @param input 任意の文字列
     * @return true or false
     */
    fun containsNumberHyphenOnly(input: String):Boolean{
        val filtered = input.filter { NUMBER_HYPHEN.contains(it) }
        return input == filtered
    }

    /**
     * 数字ハイフン以外のキャラクターを外す
     *
     * @param input 任意の文字列
     * @return true or false
     */
    fun filterNumberHyphen(input: String):String{
        return input.filter { NUMBER_HYPHEN.contains(it) }
    }

    /**
     * スペースが含めるか
     *
     * @param input 任意の文字列
     * @return フィルター後の文字列
     */
    fun containsSpace(input: String):Boolean{
        return input.contains(" ")||input.contains("　")
    }

    /**
     * スペースを外す
     *
     * @param input 任意の文字列
     * @return フィルター後の文字列
     */
    fun removeSpace(input: String):String{
        return input.replace(" ","").replace("　","")
    }

    // 建物名・号室を繋ぐ
    fun addSplitMarkToBuildingRoom(build: String?, room: String?): String {
        /*
         番地(あり)・建物名(なし)・号室(なし)の場合：「番地」
         */
        var buildingRoom = ""
        if (!build.isNullOrBlank() && !room.isNullOrBlank()){
            /*
               番地(あり)・建物名(あり)・号室(あり)の場合：(「番地」+スペース」)、（「建物名」＋「スペース」＋「号室」）
               */
            buildingRoom = build + FULL_SPACE + room
        } else if (build.isNullOrBlank() && !room.isNullOrBlank()){
            /*
               番地(必須)・建物名(なし)・号室(あり)の場合：「番地」、（ハイフン」＋「号室」）
              */
            buildingRoom = FULL_HYPHEN + room
        } else if (!build.isNullOrBlank() && room.isNullOrBlank()){
            /*
             番地(あり)・建物名(あり)・号室(なし)の場合：(「番地」+スペース」)、「建物名」
             */
            buildingRoom = build
        }
        return buildingRoom
    }

    // 建物名・号室を繋ぐ(カナ)
    fun addSplitMarkToBuildingRoomKana(build: String?, room: String?): String {
        /*
         番地(あり)・建物名(なし)・号室(なし)の場合：「番地」
         */
        var buildingRoom = ""
        if (!build.isNullOrBlank() && !room.isNullOrBlank()){
            /*
               番地(あり)・建物名(あり)・号室(あり)の場合：(「番地」+スペース」)、（「建物名」＋「スペース」＋「号室」）
               */
            buildingRoom = build + HALF_SPACE + room
        } else if (build.isNullOrBlank() && !room.isNullOrBlank()){
            /*
               番地(必須)・建物名(なし)・号室(あり)の場合：「番地」、（ハイフン」＋「号室」）
              */
            buildingRoom = HALF_HYPHEN + room
        } else if (!build.isNullOrBlank() && room.isNullOrBlank()){
            /*
             番地(あり)・建物名(あり)・号室(なし)の場合：(「番地」+スペース」)、「建物名」
             */
            buildingRoom = build
        }
        return buildingRoom
    }

    //　建物名・号室を復元
    public fun restoreFromBuildingRoom(buildingRoomSpace: String): Pair<String, String> {
        val dateComponents = buildingRoomSpace.split(FULL_SPACE)
        return if (dateComponents.size == 2) {
            Pair(dateComponents[0], dateComponents[1])
        } else if (buildingRoomSpace.startsWith(FULL_HYPHEN)) {
            Pair("", buildingRoomSpace.removePrefix(FULL_HYPHEN))
        } else {
            Pair(buildingRoomSpace, "")
        }
    }

    //　建物名・号室を復元(カナ)
    public fun restoreFromBuildingRoomKana(buildingRoomSpaceKana: String): Pair<String, String> {
        val dateComponents = buildingRoomSpaceKana.split(HALF_SPACE)
        return if (dateComponents.size == 2) {
            Pair(dateComponents[0], dateComponents[1])
        } else if (buildingRoomSpaceKana.startsWith(HALF_HYPHEN)) {
            Pair("", buildingRoomSpaceKana.removePrefix(HALF_HYPHEN))
        } else {
            Pair(buildingRoomSpaceKana, "")
        }
    }
}

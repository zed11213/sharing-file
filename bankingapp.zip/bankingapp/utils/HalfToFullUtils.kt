package jp.co.jsbank.mb.bankingapp.utils

import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.FULL_SPACE
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.HALF_SPACE
import jp.co.jsbank.mb.bankingapp.utils.KanaUtil.toDbc
import jp.co.jsbank.mb.bankingapp.utils.KanaUtil.toSbc

/**
 * 半角カナの場合、全角カナに変換
 */
object HalfToFullUtils {
    private val kanaHan = arrayOf(
        arrayOf("ｶﾞ", "ガ"),
        arrayOf("ｷﾞ", "ギ"),
        arrayOf("ｸﾞ", "グ"),
        arrayOf("ｹﾞ", "ゲ"),
        arrayOf("ｺﾞ", "ゴ"),
        arrayOf("ｻﾞ", "ザ"),
        arrayOf("ｼﾞ", "ジ"),
        arrayOf("ｽﾞ", "ズ"),
        arrayOf("ｾﾞ", "ゼ"),
        arrayOf("ｿﾞ", "ゾ"),
        arrayOf("ﾀﾞ", "ダ"),
        arrayOf("ﾁﾞ", "ヂ"),
        arrayOf("ﾂﾞ", "ヅ"),
        arrayOf("ﾃﾞ", "デ"),
        arrayOf("ﾄﾞ", "ド"),
        arrayOf("ﾊﾞ", "バ"),
        arrayOf("ﾋﾞ", "ビ"),
        arrayOf("ﾌﾞ", "ブ"),
        arrayOf("ﾍﾞ", "ベ"),
        arrayOf("ﾎﾞ", "ボ"),
        arrayOf("ﾊﾟ", "パ"),
        arrayOf("ﾋﾟ", "ピ"),
        arrayOf("ﾌﾟ", "プ"),
        arrayOf("ﾍﾟ", "ペ"),
        arrayOf("ﾎﾟ", "ポ"),
        arrayOf("ｳﾞ", "ヴ"),
        arrayOf("ｱ", "ア"),
        arrayOf("ｲ", "イ"),
        arrayOf("ｳ", "ウ"),
        arrayOf("ｴ", "エ"),
        arrayOf("ｵ", "オ"),
        arrayOf("ｶ", "カ"),
        arrayOf("ｷ", "キ"),
        arrayOf("ｸ", "ク"),
        arrayOf("ｹ", "ケ"),
        arrayOf("ｺ", "コ"),
        arrayOf("ｻ", "サ"),
        arrayOf("ｼ", "シ"),
        arrayOf("ｽ", "ス"),
        arrayOf("ｾ", "セ"),
        arrayOf("ｿ", "ソ"),
        arrayOf("ﾀ", "タ"),
        arrayOf("ﾁ", "チ"),
        arrayOf("ﾂ", "ツ"),
        arrayOf("ﾃ", "テ"),
        arrayOf("ﾄ", "ト"),
        arrayOf("ﾅ", "ナ"),
        arrayOf("ﾆ", "ニ"),
        arrayOf("ﾇ", "ヌ"),
        arrayOf("ﾈ", "ネ"),
        arrayOf("ﾉ", "ノ"),
        arrayOf("ﾊ", "ハ"),
        arrayOf("ﾋ", "ヒ"),
        arrayOf("ﾌ", "フ"),
        arrayOf("ﾍ", "ヘ"),
        arrayOf("ﾎ", "ホ"),
        arrayOf("ﾏ", "マ"),
        arrayOf("ﾐ", "ミ"),
        arrayOf("ﾑ", "ム"),
        arrayOf("ﾒ", "メ"),
        arrayOf("ﾓ", "モ"),
        arrayOf("ﾔ", "ヤ"),
        arrayOf("ﾕ", "ユ"),
        arrayOf("ﾖ", "ヨ"),
        arrayOf("ﾗ", "ラ"),
        arrayOf("ﾘ", "リ"),
        arrayOf("ﾙ", "ル"),
        arrayOf("ﾚ", "レ"),
        arrayOf("ﾛ", "ロ"),
        arrayOf("ﾜ", "ワ"),
        arrayOf("ｦ", "ヲ"),
        arrayOf("ﾝ", "ン"),
        arrayOf("ｧ", "ァ"),
        arrayOf("ｨ", "ィ"),
        arrayOf("ｩ", "ゥ"),
        arrayOf("ｪ", "ェ"),
        arrayOf("ｫ", "ォ"),
        arrayOf("ｬ", "ャ"),
        arrayOf("ｭ", "ュ"),
        arrayOf("ｮ", "ョ"),
        arrayOf("ｯ", "ッ"),
        arrayOf("｡", "。"),
        arrayOf("(", "（"),
        arrayOf(")", "）"),
        arrayOf("｢", "「"),
        arrayOf("｣", "」"),
        arrayOf("､", "、"),
        arrayOf("･", "・"),
        arrayOf("'", "’"),
        arrayOf("", ""),
        arrayOf("\t", "　"),
        arrayOf("\n", "　"),
        arrayOf(" ", "　"),
        arrayOf("0", "０"),
        arrayOf("1", "１"),
        arrayOf("2", "２"),
        arrayOf("3", "３"),
        arrayOf("4", "４"),
        arrayOf("5", "５"),
        arrayOf("6", "６"),
        arrayOf("7", "７"),
        arrayOf("8", "８"),
        arrayOf("9", "９"),
        arrayOf("a", "ａ"),
        arrayOf("b", "ｂ"),
        arrayOf("c", "ｃ"),
        arrayOf("d", "ｄ"),
        arrayOf("e", "ｅ"),
        arrayOf("f", "ｆ"),
        arrayOf("g", "ｇ"),
        arrayOf("h", "ｈ"),
        arrayOf("i", "ｉ"),
        arrayOf("j", "ｊ"),
        arrayOf("k", "ｋ"),
        arrayOf("l", "ｌ"),
        arrayOf("m", "ｍ"),
        arrayOf("n", "ｎ"),
        arrayOf("o", "ｏ"),
        arrayOf("p", "ｐ"),
        arrayOf("q", "ｑ"),
        arrayOf("r", "ｒ"),
        arrayOf("s", "ｓ"),
        arrayOf("t", "ｔ"),
        arrayOf("u", "ｕ"),
        arrayOf("v", "ｖ"),
        arrayOf("w", "ｗ"),
        arrayOf("x", "ｘ"),
        arrayOf("y", "ｙ"),
        arrayOf("z", "ｚ"),
        arrayOf("A", "Ａ"),
        arrayOf("B", "Ｂ"),
        arrayOf("C", "Ｃ"),
        arrayOf("D", "Ｄ"),
        arrayOf("E", "Ｅ"),
        arrayOf("F", "Ｆ"),
        arrayOf("G", "Ｇ"),
        arrayOf("H", "Ｈ"),
        arrayOf("I", "Ｉ"),
        arrayOf("J", "Ｊ"),
        arrayOf("K", "Ｋ"),
        arrayOf("L", "Ｌ"),
        arrayOf("M", "Ｍ"),
        arrayOf("N", "Ｎ"),
        arrayOf("O", "Ｏ"),
        arrayOf("P", "Ｐ"),
        arrayOf("Q", "Ｑ"),
        arrayOf("R", "Ｒ"),
        arrayOf("S", "Ｓ"),
        arrayOf("T", "Ｔ"),
        arrayOf("U", "Ｕ"),
        arrayOf("V", "Ｖ"),
        arrayOf("W", "Ｗ"),
        arrayOf("X", "Ｘ"),
        arrayOf("Y", "Ｙ"),
        arrayOf("Z", "Ｚ"),
    )

    fun halfToFullChar(input: String): String {
        // UTF-8 EFBC8D 全角ハイフン 交換
        var org = input
            .replace("-", "\uFF0D") // UTF-8 2D     ASCIIのハイフン
            .replace("ー", "\uFF0D") // UTF-8 E383BC 全角の長音
            .replace("‐", "\uFF0D") // UTF-8 E28090 別のハイフン
            .replace("‑", "\uFF0D") // UTF-8 E28091 改行しないハイフン
            .replace("–", "\uFF0D") // UTF-8 E28093 ENダッシュ
            .replace("—", "\uFF0D") // UTF-8 E28094 EMダッシュ
            .replace("―", "\uFF0D") // UTF-8 E28095 全角のダッシュ
            .replace("−", "\uFF0D") // UTF-8 E28892 全角のマイナス
            .replace("ｰ", "\uFF0D") // UTF-8 EFBDB0 半角カナの長音

        kanaHan.forEach {
            org = org.replace(it[0], it[1])
        }
        return toSbc(org)
    }

    fun fullToHalfChar(input: String): String {
        var org = input.replace("　", " ")
            // UTF-8 2D     ASCIIのハイフン 交換
            .replace("－", "\u002D") // UTF-8 EFBC8D 全角ハイフン
            .replace("ー", "\u002D") // UTF-8 E383BC 全角の長音
            .replace("‐", "\u002D") // UTF-8 E28090 別のハイフン
            .replace("‑", "\u002D") // UTF-8 E28091 改行しないハイフン
            .replace("–", "\u002D") // UTF-8 E28093 ENダッシュ
            .replace("—", "\u002D") // UTF-8 E28094 EMダッシュ
            .replace("―", "\u002D") // UTF-8 E28095 全角のダッシュ
            .replace("−", "\u002D") // UTF-8 E28892 全角のマイナス
            .replace("ｰ", "\u002D") // UTF-8 EFBDB0 半角カナの長音
        kanaHan.forEach {
            org = org.replace(it[1], it[0])
        }
        return toDbc(org)
    }

    // 初回登録用halfToFull
    fun halfToFullCharName(input: String): String {
        var org = input
            .replace("-", "\uFF0D") // UTF-8 2D     ASCIIのハイフン
            .replace("ー", "\uFF0D") // UTF-8 E383BC 全角の長音
            .replace("‐", "\uFF0D") // UTF-8 E28090 別のハイフン
            .replace("‑", "\uFF0D") // UTF-8 E28091 改行しないハイフン
            .replace("–", "\uFF0D") // UTF-8 E28093 ENダッシュ
            .replace("—", "\uFF0D") // UTF-8 E28094 EMダッシュ
            .replace("―", "\uFF0D") // UTF-8 E28095 全角のダッシュ
            .replace("−", "\uFF0D") // UTF-8 E28892 全角のマイナス
            .replace("ｰ", "\uFF0D") // UTF-8 EFBDB0 半角カナの長音
        kanaHan.forEach {
            org = org.replace(it[0], it[1])
        }
        return toSbc(org)
    }

    // 初回登録用fullToHalf
    fun fullToHalfCharName(input: String): String {
        var org = input.replace("　", " ")
            // UTF-8 2D     ASCIIのハイフン 交換
            .replace("－", "\u002D") // UTF-8 EFBC8D 全角ハイフン
            .replace("ー", "\u002D") // UTF-8 E383BC 全角の長音
            .replace("‐", "\u002D") // UTF-8 E28090 別のハイフン
            .replace("‑", "\u002D") // UTF-8 E28091 改行しないハイフン
            .replace("–", "\u002D") // UTF-8 E28093 ENダッシュ
            .replace("—", "\u002D") // UTF-8 E28094 EMダッシュ
            .replace("―", "\u002D") // UTF-8 E28095 全角のダッシュ
            .replace("−", "\u002D") // UTF-8 E28892 全角のマイナス
            .replace("ｰ", "\u002D") // UTF-8 EFBDB0 半角カナの長音
            .replace("-", "\u002D") // UTF-8 2D     ASCIIのハイフン
        kanaHan.forEach {
            org = org.replace(it[1], it[0])
        }
        return toDbc(org)
    }

    // 小文字を大文字に変換する。(全角)。
//    fun smallToBigChar(input: String): String {
//        val kanaHan = arrayOf(
//            arrayOf("ァ", "ア"), arrayOf("ィ", "イ"), arrayOf("ゥ", "ウ"), arrayOf("ェ", "エ"), arrayOf("ォ", "オ"),
//            arrayOf("ャ", "ヤ"), arrayOf("ュ", "ユ"), arrayOf("ョ", "ヨ"), arrayOf("ッ", "ツ")
//        )
//        var org = input
//        kanaHan.forEach {
//            println("${it[0]} = ${it[0][0].code}")
//            org = org.replace(it[0], it[1])
//        }
//        return org
//    }

    // 全角に変換
    fun toFullWidth(input: String): String {
        var org = input
        kanaHan.forEach {
            org = org.replace(it[0], it[1])
        }
        return toSbc(org)
    }

    //半角に変換
    fun toHalfWidth(input: String): String {
        var org = input
        kanaHan.forEach {
            org = org.replace(it[1], it[0])
        }
        return toDbc(org)
    }

    // 小文字を大文字に変換する(半角)。
    // ｧｨｩｪｫｬｭｮｯ -> ｱｲｳｴｵﾔﾕﾖﾂ
    fun toUpperAiueo_Half(input: String): String {
        val kanaHan = arrayOf(
            arrayOf("ｧ", "ｱ"), arrayOf("ｨ", "ｲ"), arrayOf("ｩ", "ｳ"), arrayOf("ｪ", "ｴ"), arrayOf("ｫ", "ｵ"),
            arrayOf("ｬ", "ﾔ"), arrayOf("ｭ", "ﾕ"), arrayOf("ｮ", "ﾖ"), arrayOf("ｯ", "ﾂ")
        )
        var org = input
        kanaHan.forEach {
            org = org.replace(it[0], it[1])
        }
        return org
    }

    // 大文字を小文字に変換する。
    fun bigToSmallChar(input: String): String {
        val kanaHan = arrayOf(
            arrayOf("ｧ", "ア"), arrayOf("ｨ", "イ"), arrayOf("ｩ", "ウ"), arrayOf("ｪ", "エ"), arrayOf("ｫ", "オ"),
            arrayOf("ｬ", "ヤ"), arrayOf("ｭ", "ユ"), arrayOf("ｮ", "ヨ"), arrayOf("ｯ", "ツ")
        )
        var org = input
        kanaHan.forEach {
            org = org.replace(it[1], it[0])
        }
        return org
    }

    // concat AddressKana + SPACE_KANA
//    fun concatAddressKana(addressKana: String?, buildRoomKana: String?): String {
//        if (buildRoomKana.isNullOrBlank()) {
//            return if (addressKana.isNullOrBlank()) "" else addressKana
//        }
//        return String.format("%s%s", addressKana, SPACE_KANA)
//    }

    // concat Address + SPACE
//    fun concatAddress(address: String?, buildRoom: String?): String {
//        if (buildRoom.isNullOrBlank()) {
//            return if (address.isNullOrBlank()) "" else address
//        }
//        return String.format("%s%s", address, SPACE)
//    }

    // concat build+room (half)
    fun concatBuildRoomKana(build: String?, room: String?): String {
        return concatWithSpecify(build, HALF_SPACE, room)
    }

    // concat build+room
    fun concatBuildRoom(build: String?, room: String?): String {
        return concatWithSpecify(build, FULL_SPACE, room)
    }

    // concat String with specify character
    fun concatWithSpecify(build: String?, space: String, room: String?): String {
        var buildRoom: String
        if (!build.isNullOrBlank() && !room.isNullOrBlank()) {
            buildRoom = String.format("%s%s%s", build, space, room)
        } else if (!build.isNullOrBlank()) {
            buildRoom = build
        } else if (!room.isNullOrBlank()) {
            buildRoom = room
        } else {
            buildRoom = ""
        }
        return buildRoom
    }

    // concat build+room (half) Db
    fun concatBuildRoomKanaDb(build: String?, room: String?): String {
        return concatWithSpecifyDb(build, HALF_SPACE, room)
    }

    // concat build+room Db
    fun concatBuildRoomDb(build: String?, room: String?): String {
        return concatWithSpecifyDb(build, FULL_SPACE, room)
    }

    // concat String with specify character db
    fun concatWithSpecifyDb(build: String?, space: String, room: String?): String {
        var buildRoom: String
        if (!build.isNullOrBlank() && !room.isNullOrBlank()) {
            buildRoom = String.format("%s%s%s", build, space, room)
        } else if (!build.isNullOrBlank()) {
            buildRoom = build
        } else if (!room.isNullOrBlank()) {
            buildRoom = room
        } else {
            buildRoom = ""
        }
        return buildRoom
    }

    // split buildRoom with space(half)
    fun splitBuildRoomKana(buildRoom: String?): Pair<String, String> {
        return splitBySpecify(buildRoom, HALF_SPACE);
    }

    // split buildRoom with space
    fun splitBuildRoom(buildRoom: String?): Pair<String, String> {
        return splitBySpecify(buildRoom, FULL_SPACE);
    }

    // split String with specify character
    fun splitBySpecify(buildRoom: String?, specify: String): Pair<String, String> {
        if (buildRoom.isNullOrBlank()) {
            return Pair("", "")
        } else {
            val pairs = buildRoom.split(specify, limit = 2)
            return Pair(
                pairs.getOrElse(0) { "" },
                pairs.getOrElse(1) { "" }
            )
        }
    }

    // check BuildRoom number
    fun checkBuildRoom(build: String?, room: String?): Boolean {
        var bool = false
        if  ( (!build.isNullOrBlank() && !room.isNullOrBlank() && build.count() + room.count() > 19)
            || (build.isNullOrBlank() && !room.isNullOrBlank() && room.count() > 20)
            || (!build.isNullOrBlank() && room.isNullOrBlank() && build.count() > 20) ) {
            bool = true
        }
        return  bool
    }

    // check BuildRoom kana number
    fun checkBuildRoomKana(build: String?, room: String?): Boolean {
        var bool = false
        if  ( (!build.isNullOrBlank() && !room.isNullOrBlank() && build.count() + room.count() > 29)
            || (build.isNullOrBlank() && !room.isNullOrBlank() && room.count() > 30)
            || (!build.isNullOrBlank() && room.isNullOrBlank() && build.count() > 30) ) {
            bool = true
        }
        return  bool
    }

    /*
         番地(あり)・建物名(あり)・号室(あり)の場合：(「番地」+スペース」)、（「建物名」＋「スペース」＋「号室」）、区切り文字を除き１８文字
         番地(あり)・建物名(なし)・号室(あり)の場合：(「番地」+スペース」)、（「ハイフン」＋「号室」）、区切り文字を除き１9文字
         番地(あり)・建物名(あり)・号室(なし)の場合：(「番地」+スペース」)、「建物名」、区切り文字を除き１9文字
         番地(あり)・建物名(なし)・号室(なし)の場合：「番地」、区切り文字を除き20文字
         */
    fun checkBanchiBuildingRoom(banchi: String, build: String?, room: String?): Boolean {
        var bool = false
        if  ( (!build.isNullOrBlank() && !room.isNullOrBlank() && banchi.count() + build.count() + room.count() > 18)
                || (build.isNullOrBlank() && !room.isNullOrBlank() && banchi.count() + room.count() > 19)
                || (!build.isNullOrBlank() && room.isNullOrBlank() && banchi.count() + build.count() > 19)
                || (build.isNullOrBlank() && room.isNullOrBlank() && banchi.count() > 20) )
             {
            bool = true
        }
        return  bool
    }

    /*
         番地(あり)・建物名(あり)・号室(あり)の場合：(「番地」+スペース」)、（「建物名」＋「スペース」＋「号室」）、区切り文字を除き２７文字
         番地(あり)・建物名(なし)・号室(あり)の場合：(「番地」+スペース」)、（「ハイフン」＋「号室」）、区切り文字を除き２７文字
         番地(あり)・建物名(あり)・号室(なし)の場合：(「番地」+スペース」)、「建物名」、区切り文字を除き２７文字
         番地(あり)・建物名(なし)・号室(なし)の場合：「番地」、区切り文字を除き２８文字
         */
    fun checkBanchiBuildingRoomKana(banchi: String, build: String?, room: String?): Boolean {
        var bool = false
        if  ( (!build.isNullOrBlank() && !room.isNullOrBlank() && banchi.count() + build.count() + room.count() > 27)
            || (build.isNullOrBlank() && !room.isNullOrBlank() && banchi.count() + room.count() > 27)
            || (!build.isNullOrBlank() && room.isNullOrBlank() && banchi.count() + build.count() > 27)
            || (build.isNullOrBlank() && room.isNullOrBlank() && banchi.count() > 28) ){
            bool = true
        }
        return  bool
    }
}

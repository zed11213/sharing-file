package jp.co.jsbank.mb.bankingapp.utils

/**
 * エラー処理
 */
class ErrorUtil {
    fun apiErrorCatch(message: String) {
        LogPrintUtil.error(message)
        LoadingUtil.setLoadingValue(value = false)
    }
}

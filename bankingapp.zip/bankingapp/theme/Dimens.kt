package jp.co.jsbank.mb.bankingapp.theme

import androidx.compose.ui.unit.sp

val H1 = 48.sp
val H2 = 36.sp
val H2_5 = 30.sp
val H3 = 24.sp
val H4 = 20.sp
val H5 = 18.sp
val H6 = 16.sp
val H7 = 14.sp
val H8 = 12.sp
val H9 = 10.sp
val H10 = 8.sp
val H11 = 6.sp

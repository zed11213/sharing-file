package jp.co.jsbank.mb.bankingapp.theme

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.TweenSpec
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import com.google.accompanist.insets.ProvideWindowInsets
import com.google.accompanist.systemuicontroller.rememberSystemUiController

// 夜色テーマ
private val DarkColorPalette = AppColors(
    themeUi = Color.White,
    buttonPrimaryColor = Color(0xFFCE3F52),
    textPrimaryColor = Color(0xFF000000),
)

// 昼間のテーマ
private val LightColorPalette = AppColors(
    themeUi = Color.White,
    buttonPrimaryColor = Color(0xFFCE3F52),
    textPrimaryColor = Color(0xFF000000),
)
var LocalAppColors = compositionLocalOf {
    LightColorPalette
}

@Stable
object AppTheme {
    val colors: AppColors
        @Composable
        get() = LocalAppColors.current

    enum class Theme {
        Light, Dark
    }
}

@Stable
class AppColors(
    themeUi: Color,
    buttonPrimaryColor: Color,
    textPrimaryColor: Color,
) {
    var themeUi: Color by mutableStateOf(themeUi)
        internal set
    var buttonPrimaryColor: Color by mutableStateOf(buttonPrimaryColor)
        internal set
    var textPrimaryColor: Color by mutableStateOf(textPrimaryColor)
        internal set
}

@Composable
fun JsBankTheme(
    theme: AppTheme.Theme = AppTheme.Theme.Light,
    content: @Composable () -> Unit
) {
    val targetColors = when (theme) {
        AppTheme.Theme.Light -> {
            LightColorPalette.themeUi = Color.White
            LightColorPalette.buttonPrimaryColor = Color(0xFFCE3F52)
            LightColorPalette
        }
        AppTheme.Theme.Dark -> DarkColorPalette
    }

    val themeUi = animateColorAsState(targetColors.themeUi, TweenSpec(600))
    val buttonPrimaryColor = animateColorAsState(targetColors.buttonPrimaryColor, TweenSpec(600))
    val textPrimaryColor = animateColorAsState(targetColors.textPrimaryColor, TweenSpec(600))

    val appColors = AppColors(
        themeUi = themeUi.value,
        buttonPrimaryColor = buttonPrimaryColor.value,
        textPrimaryColor = textPrimaryColor.value,
    )

    val systemUiCtrl = rememberSystemUiController()
    systemUiCtrl.setStatusBarColor(appColors.themeUi)
    systemUiCtrl.setNavigationBarColor(appColors.themeUi)
    systemUiCtrl.setSystemBarsColor(appColors.themeUi)

    ProvideWindowInsets {
        CompositionLocalProvider(LocalAppColors provides appColors, content = content)
    }
}

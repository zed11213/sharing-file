package jp.co.jsbank.mb.bankingapp.theme

import androidx.compose.ui.graphics.Color

// 一般のラベル色
val general_label_color = Color(0xFF121212)

// 口座カードのラベルの色
val account_card_label_color = Color(0xFF949391)

// アプリバーのタイトルの色
var app_bar_title_color = Color(0xFF424241)

// 著名なラベル色
val prominent_label_color = Color(0xFFCE3F52)

// 著名なラベル色（未選択）
val prominent_label_color_unSelect = Color(0xFFFEBBC5)

// 文言色
val text_color = Color(0xFF5D5D5D)

// ボーダの色
val border_color = Color(0xFF707070)

// 一般の分割線の色
val general_dividing_line_color = Color(0xFFDEDEDE)

// 総合口座切り替えボタンのラベルの色
val general_account_switching_button_label_color = Color(0xFFC93438)

// 普通預金切り替えボタンのラベルの色
val ordinary_deposit_switching_button_label_color = Color(0xFF4B65AD)

// 定期預金切り替えボタンのラベルの色
val periodic_deposit_switching_button_label_color = Color(0xFFBE8507)

// 定期積金切り替えボタンのラベルの色
val mpf_switching_button_label_color = Color(0xFFDB5F28)

// 当座預金切り替えボタンのラベルの色
val current_account_switching_button_label_color = Color(0xFFC39806)

// 当座預金切り替えボタンの背景色
val current_account_switching_button_background_color = Color(0x1ADB5F28)

// 選択の当座預金切り替えボタンの背景色
val selected_current_account_switching_button_background_color = Color(0x33DB5F28)

// 通知預金切り替えボタンのラベルの色
val notification_deposit_switching_button_label_color = Color(0xFF3A839A)

// 納税準備預金切り替えボタンのラベルの色
val tax_reserve_deposit_switching_button_label_color = Color(0xFF1B4302)

// 口座明細のラベル色
val account_detail_label_color = Color(0xFF5C5B5A)

// 入金額のラベル色
val deposit_amount_label_color = Color(0xFF587FCB)

// 入金額のラベル色（未選択）
val deposit_amount_label_color_unSelect = Color(0xFFBFD5F3)

// 一般の背景色
val general_background_color = Color(0x1ACE3F52)

// アプリバーの背景色
val app_bar_background_color = Color(0xFFF3F2EF)

// 入力チップの色
val input_tip_color = Color(0xFFCE3F52)

// 著作権の背景色
val copyright_background_color = Color(0xFFEDECEA)

// 入力フレームの背景色
val input_frame_background_color = Color(0x1AE84F4F)

// 総合口座タブの背景色
val general_account_tab_background_color = Color(0x4DFFFFFF)

// 総合口座切り替えボタンの背景色
val general_account_switching_button_background_color = Color(0x0DCE3F52)

// 選択の総合口座切り替えボタンの背景色
val selected_general_account_switching_button_background_color = Color(0x33CE3F52)

// 普通預金切り替えボタンの背景色
val ordinary_deposit_switching_button_background_color = Color(0x1A4B65AD)

// 選択の普通預金切り替えボタンの背景色
val selected_ordinary_deposit_switching_button_background_color = Color(0x334B65AD)

// 定期預金切り替えボタンの背景色
val periodic_deposit_switching_button_background_color = Color(0x1AFAD658)

// 選択の定期預金切り替えボタンの背景色
val selected_periodic_deposit_switching_button_background_color = Color(0x33FAD658)

// 定期積金切り替えボタンの背景色
val mpf_switching_button_background_color = Color(0x0DDB5F28)

// 選択の定期積金切り替えボタンの背景色
val selected_mpf_switching_button_background_color = Color(0x33DB5F28)

// 通知預金切り替えボタンの背景色
val notification_deposit_switching_button_background_color = Color(0x1A3A839A)

// 選択の通知預金切り替えボタンの背景色
val selected_notification_deposit_switching_button_background_color = Color(0x333A839A)

// 納税準備預金切り替えボタンの背景色
val tax_reserve_deposit_switching_button_background_color = Color(0x1A1B4302)

// 選択の納税準備預金切り替えボタンの背景色
val selected_tax_reserve_deposit_switching_button_background_color = Color(0x331B4302)

// 通帳テーブルヘッダの色
val passbook_table_border_color = Color(0xFFE57E4A)

// 通帳テーブルボディの色
val passbook_table_single_bg_color = Color(0xFFFFEAEF)

// 通帳切替えボタンの背景色
val passbook_tab_bg_color = Color(0xFFD9D8D4)

// ラジオボタンセレクトの色
val radio_button_select_bg_color = Color(0xFFCE3F52)

// ラジオボーダーの色
val radio_button_border_bg_color = Color(0xFFCE3F52)

// 期間非活性の色
val date_select_disable_bg_color = Color(0xFFF5F5F5)

// 通帳金額の背景色
val passbook_amount_bg_color = Color(0xFFE5F4DA)

// 夏の文字色
val summer_text_color = Color(0xFF118FC7)

// 秋の文字色
val autumn_text_color = Color(0xFFAD5F27)

// 冬の文字色
val winter_text_color = Color(0xFF305BAF)

// 非活性ボタンの色
val inactive_button_bg_color = Color(0x80CE3F52)

// 非活性文字の色
val inactive_font_color = Color(0xFF949391)

// 一般的な明るいグレー
val simple_light_gray_color = Color(0xFFD8D8D8)

// アプリ起動画面の背景色
val app_start_bg_color = Color(0xFFC8E9FB)

// 一般的なグレー
val simple_gray_color = Color(0xFF949494)

// 案内タブグリーン
val electronic_delivery_tab_green = Color(0xFF4B978C)

// 納税準備預金シナモンアプリバーの色
val details_card_pay_tax_cinnamole_appbar_color = Color(0xFFF5FFF6)

// 納税準備預金シナモン背景色
val details_card_pay_tax_cinnamole_background_color = Color(0xFFE1ECB9)

// 当座預金シナモンアプリバーの色
val details_card_current_cinnamole_appbar_color = Color(0xFFFFFFE6)

// 当座預金シナモン背景色
val details_card_current_cinnamole_background_color = Color(0xFFFFF2B8)

// 総合口座シナモンアプリバーの色
val details_card_comprehensive_cinnamole_appbar_color = Color(0xFFFCEFF5)

// 総合口座シナモン背景色
val details_card_comprehensive_cinnamole_background_color = Color(0xFFF8D0D3)

// 普通預金シナモンアプリバーの色
val usually_account_details_cinnamole_appbar_color = Color(0xFFF5FAFF)

// 普通預金シナモン背景色
val usually_account_details_cinnamole_background_color = Color(0xFFBADAF2)

// 定期積金シナモン背景色
val deposit_account_details_cinnamole_background_color = Color(0xFFFDE3A9)

// 通知預金シナモン背景色
val notice_deposit_details_cinnamole_background_color = Color(0xFFD3EBF3)

// 定期預金シナモンアプリバーの色
val regular_deposit_details_cinnamole_appbar_color = Color(0xFFFBEDCA)

// 非活性の背景色
val inactive_background_color = Color(0xFFECECEC)

// ラジオボーダーの色
val radio_button_error_color = Color(0xFFFF003B)

package jp.co.jsbank.mb.bankingapp.bean.opened.mbco.mbco0601

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * MBCO0601リクエストエンティティ.
 */
@Parcelize
data class MBCO0601RequestBean(
    /**
     * 受付番号
     */
    var receptionNumber: String = "",

    /**
     * IBパスワード
     *
     */
    var ibPassword: String = "",

    /**
     * CC暗証番号
     */
    var ccPassword: String = "",

    /**
     * 人格区分
     */
    var personalityKubun: String = "",

    /**
     * 更新パターン
     */
    var updateType: String = "",

) : Parcelable

package jp.co.jsbank.mb.bankingapp.bean.opened.mbco.mbco0601

/**
 * MBCO0601レスポンスエンティティ.
 */
data class MBCO0601ResponseBean(
    /**
     * IBパスワード.
     */
    var pibPassword: String = "",

    /**
     * CC暗証番号.
     */
    var ccPassword: String = "",
)

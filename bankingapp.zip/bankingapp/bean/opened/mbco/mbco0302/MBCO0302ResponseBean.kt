package jp.co.jsbank.mb.bankingapp.bean.opened.mbco.mbco0302

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * MBCO0302レスポンスエンティティ.
 */
data class MBCO0302ResponseBean(
    /**
     * 認証結果.
     */
    var authenticationResult: String = "",
)

/**
 * MBCO0302渡すパラメータ.
 */
@Parcelize
data class MBCO0302Param(

    /**
     * タイプ
     */
    var type: String = "",

    /**
     * 電話番号
     */
    var phoneNumber: String = "",
) : Parcelable

package jp.co.jsbank.mb.bankingapp.bean.opened.mbco.mbco0302

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * MBCO0302リクエストエンティティ.
 */
@Parcelize
data class AB0808RequestBean(
    /**
     * 受付番号.
     */
    var receiptNumber: String = "",
    /**
     * 電話番号.
     */
    var phoneNumber: String = "",
    /**
     * IVROTP.
     */
    var ivrOtp: String = "",
    /**
     * 更新パターン.
     */
    var updateType: String = "",
) : Parcelable

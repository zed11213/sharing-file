package jp.co.jsbank.mb.bankingapp.bean.opened.mbco.mbco0302

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * MBCO0302リクエストエンティティ.
 */
@Parcelize
data class MBCO0302RequestBean(

    /**
     * IVROTP.
     */
    var ivrOtp: String = "",

    /**
     * 受付番号.
     */
    var receiptNumber: String = "",

    /**
     * 電話番号.
     */
    var phoneNumber: String = "",

    /**
     * 依頼番号.
     */
    var requestNo: String = "",

    /**
     * 人格区分.
     */
    var personType: String = "",

    /**
     * 更新パターン
     */
    var updateType: String = "",
) : Parcelable

package jp.co.jsbank.mb.bankingapp.bean.opened.mbco.mbop0202

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * MBCO0202リクエストエンティティ.
 */
@Parcelize
data class AB0807ResponseBean(
    /**
     * 受付番号
     */
    var receptionNumber: String = "",

    /**
     * 人格区分
     */
    var personalityKubun: String = "",

    /**
     * otp
     */
    var otp: String = "",
) : Parcelable

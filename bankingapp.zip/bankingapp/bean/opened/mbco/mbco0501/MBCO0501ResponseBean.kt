package jp.co.jsbank.mb.bankingapp.bean.opened.mbco.mbco0501

/**
 * MBCO0501レスポンスエンティティ.
 */
data class MBCO0501ResponseBean(
    /**
     * IBパスワード.
     */
    var ibPassword: String = "",

    /**
     * CC暗証番号.
     */
    var ccPassword: String = "",
)

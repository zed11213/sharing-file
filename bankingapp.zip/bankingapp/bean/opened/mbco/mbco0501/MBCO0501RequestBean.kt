package jp.co.jsbank.mb.bankingapp.bean.opened.mbco.mbco0501

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * MBCO0501リクエストエンティティ.
 */
@Parcelize
data class MBCO0501RequestBean(
    /**
     * 受付番号
     */
    var receptionNumber: String = "",

    /**
     * CC暗証番号
     *
     */
    var ccPassword: String = "",

    /**
     * 人格区分
     */
    var personalityKubun: String = "",

    /**
     * 更新パターン
     */
    var updateType: String = "",

) : Parcelable

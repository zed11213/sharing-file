package jp.co.jsbank.mb.bankingapp.bean.opened.mbco.mbco0201

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * MBCO0201リクエストエンティティ.
 */
@Parcelize
data class MBCO0201RequestBean(
    /**
     * 受付番号
     */
    var receptionNumber: String = "",

    /**
     * メールアドレス
     */
    var emailAddress: String = "",

    /**
     * 処理区分（0：新規　１：更新）
     */
    var processKubun: String = "",

    /**
     * 取引種別
     */
    var transactionType: String = "",

    /**
     * 更新パターン
     */
    var updateType: String = "",

    /**
     * 人格区分
     */
    var personType: String = "",
) : Parcelable

package jp.co.jsbank.mb.bankingapp.bean.opened.mbco.mbco0201

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * MBCO0201レスポンスエンティティ.
 */
@Parcelize
data class MBCO0201ResponseBean(

    /**
     * トランザクションコード
     */
    var transactionCode: String = "",
) : Parcelable

/**
 * MBCO0201渡すパラメータ.
 */
@Parcelize
data class MBCO0202Param(

    /**
     * タイプ
     */
    var type: String = "",

    /**
     * メールアドレス
     */
    var emailAddress: String = "",

    /**
     * トランザクションコード
     */
    var transactionCode: String = "",
) : Parcelable

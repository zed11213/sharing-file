package jp.co.jsbank.mb.bankingapp.bean.opened.mbco.mbco0301

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * MBCO0301リクエストエンティティ.
 */
@Parcelize
data class MBCO0301RequestBean(
    /**
     * 電話番号
     */
    var phoneNumber: String = "",

    /**
     * 受付番号.
     */
    var receiptNumber: String = "",

    /**
     * 人格区分.
     */
    var personType: String = "",

    /**
     * 更新パターン
     */
    var updateType: String = "",
) : Parcelable

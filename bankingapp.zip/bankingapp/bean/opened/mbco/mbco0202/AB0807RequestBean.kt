package jp.co.jsbank.mb.bankingapp.bean.opened.mbco.mbco0202

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * AB0807リクエストエンティティ.
 */
@Parcelize
data class AB0807RequestBean(

    /**
     * メールアドレス
     */
    var emailAddress: String = "",

    /**
     * メールOTP
     */
    var mailOtp: String = "",

    /**
     * 依頼番号
     */
    var requestNo: String = "",

    /**
     * CIF番号
     */
    var cifNumber: String = "",

    /**
     * 受付番号
     */
    var receiptNumber: String = "",

    /**
     * 認証キー
     */
    var authCode: String = "",

    /**
     * 人格区分
     */
    var personType: String = "",

    /**
     * 更新パターン
     */
    var updateType: String = "",
) : Parcelable

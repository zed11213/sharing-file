package jp.co.jsbank.mb.bankingapp.bean.opened.mbco.mbco0202

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * MBCO0202リクエストエンティティ.
 */
@Parcelize
data class MBCO0202RequestBean(
    /**
     * 受付番号
     */
    var receiptNumber: String = "",

    /**
     * 人格区分
     */
    var personType: String = "",

    /**
     * otp
     */
    var mailOtp: String = "",

    /**
     * メールアドレス
     */
    var emailAddress: String = "",

    /**
     * 更新パターン
     */
    var updateType: String = "",
) : Parcelable

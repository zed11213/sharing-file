package jp.co.jsbank.mb.bankingapp.bean.opened.mbop.mbop0602

import jp.co.jsbank.mb.bankingapp.bean.common.Individual

/**
 * MBOP0602リクエストエンティティ.
 */
data class MBOP0602RequestBean(
    /**
     * 画面ID.
     */
    var screenId: String = "",

    /**
     * 人格区分.
     */
    var personType: String = "",

    /**
     * 受付番号.
     */
    var receiptNumber: String = "",

    /**
     * 口座区分.
     */
    var accountType: String = "",

    /**
     * 定期積金口座番号.
     */
    var fixedAccountNumber: String = "",

    /**
     * 定期預金口座番号.
     */
    var regularAccountNumber: String = "",

    /**
     * 口座開設申込情報（個人）
     */
    var individual: Individual = Individual(),
)

package jp.co.jsbank.mb.bankingapp.bean.opened.mbop.mbop0602

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * MBOP0602応答エンティティ.
 */
@Parcelize
data class MBOP0602ResponseBean(
    /**
     * 生年月日
     */
    var birthday: String = "",

    /**
     * 番地
     */
    var addrDetail3: String = "",

    /**
     * 住所方書
     */
    var addressDetail: String = "",

    /**
     * 電話番号１
     */
    var phoneNumber1: String = "",
) : Parcelable

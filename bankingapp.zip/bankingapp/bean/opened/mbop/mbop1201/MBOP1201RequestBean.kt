package jp.co.jsbank.mb.bankingapp.bean.opened.mbop.mbop1201

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * MBOP1201リクエストエンティティ.
 */
@Parcelize
data class MBOP1201RequestBean(

    /**
     * 人格区分
     */
    var personType: String = "",

    /**
     * 受付番号
     */
    var receiptNumber: String = "",

    /**
     * 申込日
     */
    var applicationDate: String = "",

) : Parcelable

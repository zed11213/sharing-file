package jp.co.jsbank.mb.bankingapp.bean.opened.mbop.mbop0203

import jp.co.jsbank.mb.bankingapp.bean.common.Individual

/**
 * MBOP0203レスポンスエンティティ.
 */
data class MBOP0203ResponseBean(
    // 口座開設申込情報（個人）
    var individual: Individual = Individual()
)

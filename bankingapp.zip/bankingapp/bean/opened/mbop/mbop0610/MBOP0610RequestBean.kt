package jp.co.jsbank.mb.bankingapp.bean.opened.mbop.mbop0610

import android.os.Parcelable
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.FULL_SPACE
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.HALF_SPACE
import jp.co.jsbank.mb.bankingapp.utils.toJson
import kotlinx.android.parcel.Parcelize

/**
 * MBOP0610リクエストエンティティ.
 */
@Parcelize
data class MBOP0610RequestBean(

    /**
     * 申込ステータス.
     */
    var applyStatus: String = "",

    /**
     * 所在地郵便番号
     */
    var locationZipCode: String = "",

    /**
     * 所在地都道府県（半角カナ）
     */
    var locationPrefectureKana: String = "",

    /**
     * 所在地都道府県
     */
    var locationPrefecture: String = "",

    /**
     * 所在地市区町村（半角カナ）
     */
    var locationCityKana: String = "",

    /**
     * 所在地市区町村
     */
    var locationCity: String = "",

    /**
     * 所在地丁目（半角カナ）
     */
    var locationStreetKana: String = "",

    /**
     * 所在地丁目
     */
    var locationStreet: String = "",

    /**
     * 所在地番地（半角カナ）
     */
    var locationAddressKana: String = "",

    /**
     * 所在地番地（全角）
     */
    var locationAddress: String = "",

    /**
     * 建物名・号室（半角カナ）
     */
    var locationBuildingRoomKana: String = "",

    /**
     * 建物名・号室（全角）
     */
    var locationBuildingRoom: String = "",

    /**
     * 本店所在地相違区分
     */
    var headOfficeClassification: String = "",

    /**
     * 画面ID
     */
    var pageId: String = "",

    /**
     * 本店所在地郵便番号
     */
    var headOfficeLocZipCode: String = "",

    /**
     * 本店所在地都道府県（半角カナ）
     */
    var headOfficeLocPrefectureKana: String = "",

    /**
     * 本店所在地都道府県
     */
    var headOfficeLocPrefecture: String = "",

    /**
     * 本店所在地市区町村（半角カナ）
     */
    var headOfficeLocCityKana: String = "",

    /**
     * 本店所在地市区町村
     */
    var headOfficeLocCity: String = "",

    /**
     * 本店所在地丁目（半角カナ）
     */
    var headOfficeLocStreetKana: String = "",

    /**
     * 本店所在地丁目
     */
    var headOfficeLocStreet: String = "",

    /**
     * 本店所在地番地（半角カナ）
     */
    var headOfficeLocAddressKana: String = "",

    /**
     * 本店所在地番地（全角）
     */
    var headOfficeLocAddress: String = "",

    /**
     * 本店建物名・号室（半角カナ）
     */
    var headOfficeLocBuildingRoomKana: String = "",

    /**
     * 本店建物名・号室（全角）
     */
    var headOfficeLocBuildingRoom: String = "",
    /**
     * 受付番号.
     */
    var receiptNumber: String = "",

    /**
     * 更新パターン
     */
    var updateType: String = "",
) : Parcelable {
    /**
     * API通信前のパラメータ処理
     * 番地にスペースを入れる
     */
    fun convertToParams(): String {
        return this.copy(
            locationAddress = this.locationAddress + if (this.locationBuildingRoom.isBlank()) "" else FULL_SPACE,
            locationAddressKana = this.locationAddressKana + if (this.locationBuildingRoomKana.isBlank()) "" else HALF_SPACE,
            headOfficeLocAddress = this.headOfficeLocAddress + if (this.headOfficeLocBuildingRoomKana.isBlank()) "" else FULL_SPACE,
            headOfficeLocAddressKana = this.headOfficeLocAddressKana + if (this.headOfficeLocBuildingRoomKana.isBlank()) "" else FULL_SPACE,
        ).toJson()
    }
}

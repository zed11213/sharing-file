package jp.co.jsbank.mb.bankingapp.bean.opened.mbop.mbop0613

import android.os.Parcelable
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.FULL_SPACE
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.HALF_SPACE
import jp.co.jsbank.mb.bankingapp.utils.toJson
import kotlinx.android.parcel.Parcelize

/**
 * MBOP0613リクエストエンティティ.
 */
@Parcelize
data class MBOP0613RequestBean(

    /**
     * 受付番号
     */
    var receiptNumber: String = "",

    /**
     * 所在地郵便番号
     */
    var locationZipCode: String = "",

    /**
     * 所在地都道府県（半角カナ）
     */
    var locationPrefectureKana: String = "",

    /**
     * 所在地都道府県
     */
    var locationPrefecture: String = "",

    /**
     * 所在地市区町村（半角カナ）
     */
    var locationCityKana: String = "",

    /**
     * 所在地市区町村
     */
    var locationCity: String = "",

    /**
     * 所在地丁目（半角カナ）
     */
    var locationStreetKana: String = "",

    /**
     * 所在地丁目
     */
    var locationStreet: String = "",

    /**
     * 所在地番地（半角カナ）
     */
    var locationAddressKana: String = "",

    /**
     * 所在地番地（全角）
     */
    var locationAddress: String = "",

    /**
     * 建物名・号室（半角カナ）
     */
    var locationBuildingRoomKana: String = "",

    /**
     * 建物名・号室（全角）
     */
    var locationBuildingRoom: String = "",

    /**
     * 更新パターン
     */
    var updateType: String = "",
) : Parcelable {
    /**
     * API通信前のパラメータ処理
     * 番地にスペースを入れる
     */
    fun convertToParams(): String {
        return this.copy(
            locationAddress = this.locationAddress + if (this.locationBuildingRoom.isBlank()) "" else FULL_SPACE,
            locationAddressKana = this.locationAddressKana + if (this.locationBuildingRoomKana.isBlank()) "" else HALF_SPACE,
        ).toJson()
    }
}

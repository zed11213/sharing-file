package jp.co.jsbank.mb.bankingapp.bean.opened.mbop.mbop0703

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * MBOP0703リクエストエンティティ.
 */
@Parcelize
data class MBOP0703RequestBean(

    /**
     * 受付番号
     */
    var receptionNumber: String = "",

    /**
     * 人格区分
     */
    var personType: String = "",

    /**
     * 希望部店
     */
    var hopeDepartmentStore: String = "",

    /**
     * 他店開設希望理由
     */
    var reasonToOpenAccAnotherBranch: String = "",

    /**
     * 他店開設希望理由（その他）
     */
    var reasonToOpenAccAnotherBranchOther: String = "",

    /**
     * 更新パターン
     */
    var updateType: String = "",
) : Parcelable

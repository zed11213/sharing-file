package jp.co.jsbank.mb.bankingapp.bean.opened.mbop.mbop0611

import android.os.Parcelable
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.FULL_SPACE
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.HALF_SPACE
import kotlinx.android.parcel.Parcelize

/**
 * MBOP0611リクエストエンティティ.
 */
@Parcelize
data class MBOP0611RequestBean(

    /**
     * 受付番号
     */
    var receiptNumber: String = "",

    /**
     * 本店所在地郵便番号
     */
    var headOfficeLocZipCode: String = "",

    /**
     * 本店所在地都道府県（半角カナ）
     */
    var headOfficeLocPrefectureKana: String = "",

    /**
     * 本店所在地都道府県
     */
    var headOfficeLocPrefecture: String = "",

    /**
     * 本店所在地市区町村（半角カナ）
     */
    var headOfficeLocCityKana: String = "",

    /**
     * 本店所在地市区町村
     */
    var headOfficeLocCity: String = "",

    /**
     * 本店所在地丁目（半角カナ）
     */
    var headOfficeLocStreetKana: String = "",

    /**
     * 本店所在地丁目
     */
    var headOfficeLocStreet: String = "",

    /**
     * 本店所在地番地（半角カナ）
     */
    var headOfficeLocAddressKana: String = "",

    /**
     * 本店所在地番地（全角）
     */
    var headOfficeLocAddress: String = "",

    /**
     * 本店建物名・号室（半角カナ）
     */
    var headOfficeLocBuildingRoomKana: String = "",

    /**
     * 本店建物名・号室（全角）
     */
    var headOfficeLocBuildingRoom: String = "",

    /**
     * 画面ID
     */
    var pageId: String = "",

    /**
     * 更新パターン
     */
    var updateType: String = "",
) : Parcelable {
    /**
     * API通信前のパラメータ処理
     * 番地にスペースを入れる
     */
    fun convertToParams(): MBOP0611RequestBean {
        return this.copy(
            headOfficeLocAddress = this.headOfficeLocAddress + if (this.headOfficeLocBuildingRoom.isBlank()) "" else FULL_SPACE,
            headOfficeLocAddressKana = this.headOfficeLocAddressKana + if (this.headOfficeLocBuildingRoomKana.isBlank()) "" else HALF_SPACE,
        )
    }
}

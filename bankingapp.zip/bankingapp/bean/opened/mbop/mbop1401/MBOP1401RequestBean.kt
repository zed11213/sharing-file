package jp.co.jsbank.mb.bankingapp.bean.opened.mbop.mbop1401

import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import jp.co.jsbank.mb.bankingapp.bean.common.FileInfoBean

/**
 * MBOP1401リクエストエンティティ.
 */
@Parcelize
data class MBOP1401RequestBean(

    /**
     * ファイル情報リスト
     */
    var fileStreams: MutableList<FileInfoBean> = mutableListOf(),

    /**
     * 人格区分
     */
    var personType: String = "",

    /**
     * 受付番号
     */
    var receiptNumber: String = "",

    /**
     * eKYC確認結果
     */
    var ekycResult: String = "",

    /**
     * 本人確認書類コード
     */
    var identificationDocumentCode: String = "",

    /**
     * 郵便番号
     */
    var zipCode: String = "",

    /**
     * 漢字氏名（姓）
     */
    var customerKanjiLastName: String = "",

    /**
     * 漢字氏名（名）
     */
    var customerKanjiFirstName: String = "",

    /**
     * 生年月日
     */
    var birthday: String = "",

    /**
     * 更新パターン
     */
    var updateType: String = "",
) : Parcelable

/**
 * 個人情報
 */
@Parcelize
data class IndividualInfo(

    /**
     * 氏名漢字（姓）
     */
    var customerKanjiLastName: String = "",

    /**
     * 氏名漢字（名）
     */
    var customerKanjiFirstName: String = "",

    /**
     * 生年月日
     */
    var birthday: String = "",

    /**
     * 都道府県
     */
    var prefecture: String = "",

    /**
     * 市区町村
     */
    var city: String = "",

    /**
     * 町域
     */
    var addrDetail2: String = "",
) : Parcelable

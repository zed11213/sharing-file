package jp.co.jsbank.mb.bankingapp.bean.opened.mbop.mbop0612

import android.os.Parcelable
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.FULL_SPACE
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.HALF_SPACE
import kotlinx.android.parcel.Parcelize

/**
 * MBOP0612リクエストエンティティ.
 */
@Parcelize
data class MBOP0612RequestBean(

    /**
     * 自宅郵便番号
     */
    var zipCode: String = "",

    /**
     * 自宅都道府県（半角カナ）
     */
    var prefectureKana: String = "",

    /**
     * 自宅都道府県
     */
    var prefecture: String = "",

    /**
     * 自宅市区町村（半角カナ）
     */
    var cityKana: String = "",

    /**
     * 自宅市区町村
     */
    var city: String = "",

    /**
     * 自宅丁目（半角カナ）
     */
    var addrDetail2Kana: String = "",

    /**
     * 自宅丁目
     */
    var addrDetail2: String = "",

    /**
     * 自宅番地（半角カナ）
     */
    var addrDetail3Kana: String = "",

    /**
     * 自宅番地（全角）
     */
    var addrDetail3: String = "",

    /**
     * 自宅建物名・号室（半角カナ）
     */
    var buildingRoomKana: String = "",

    /**
     * 自宅建物名・号室（全角）
     */
    var buildingRoom: String = "",

    /**
     * 本店所在地相違区分
     */
    var locationClassification: String = "",

    /**
     * 所在地郵便番号
     */
    var locationZipCode: String = "",

    /**
     * 所在地都道府県（半角カナ）
     */
    var locationPrefectureKana: String = "",

    /**
     * 所在地都道府県
     */
    var locationPrefecture: String = "",

    /**
     * 所在地市区町村（半角カナ）
     */
    var locationCityKana: String = "",

    /**
     * 所在地市区町村
     */
    var locationCity: String = "",

    /**
     * 所在地丁目（半角カナ）
     */
    var locationStreetKana: String = "",

    /**
     * 所在地丁目
     */
    var locationStreet: String = "",

    /**
     * 所在地番地（半角カナ）
     */
    var locationAddressKana: String = "",

    /**
     * 所在地番地（全角）
     */
    var locationAddress: String = "",

    /**
     * 建物名・号室（半角カナ）
     */
    var locationBuildingRoomKana: String = "",

    /**
     * 建物名・号室（全角）
     */
    var locationBuildingRoom: String = "",
    /**
     * 受付番号.
     */
    var receiptNumber: String = "",

    /**
     * 更新パターン
     */
    var updateType: String = "",
) : Parcelable {
    /**
     * API通信前のパラメータ処理
     * 番地にスペースを入れる
     */
    fun convertToParams(): MBOP0612RequestBean {
        return this.copy(
            addrDetail3 = this.addrDetail3 + if (this.buildingRoom.isBlank()) "" else FULL_SPACE,
            addrDetail3Kana = this.addrDetail3Kana + if (this.buildingRoomKana.isBlank()) "" else HALF_SPACE,
            locationAddress = this.locationAddress + if (this.locationBuildingRoom.isBlank()) "" else FULL_SPACE,
            locationAddressKana = this.locationAddressKana + if (this.locationBuildingRoomKana.isBlank()) "" else HALF_SPACE,
        )
    }
}

package jp.co.jsbank.mb.bankingapp.bean.opened.mbop.mbop0601

import android.os.Parcelable
import jp.co.jsbank.mb.bankingapp.bean.common.CorporationBean
import jp.co.jsbank.mb.bankingapp.bean.common.Individual
import jp.co.jsbank.mb.bankingapp.bean.common.SoleProprietorBean
import kotlinx.android.parcel.Parcelize

/**
 * MBOP0601リクエストエンティティ.
 */
@Parcelize
data class MBOP0601RequestBean(

    /**
     * 人格区分
     */
    var personType: String = "",

    /**
     * 受付番号
     */
    var receiptNumber: String = "",

    /**
     * 口座開設申込情報（個人）
     */
    var individualDto: Individual = Individual(),

    /**
     * 口座開設申込情報（法人）
     */
    var corporationDto: CorporationBean = CorporationBean(),

    /**
     * 口座開設申込情報（個人事業主）
     */
    var selfempDto: SoleProprietorBean = SoleProprietorBean(),

    /**
     * 更新パターン
     */
    var updateType: String = "",


) : Parcelable {
    /**
     * パラメータ処理
     */
    fun convertToParams(): MBOP0601RequestBean {
        return this.copy(
            individualDto = this.individualDto.convertToParams(),
            corporationDto = this.corporationDto.convertToParams(),
            selfempDto = this.selfempDto.convertToParams(),
        )
    }
}

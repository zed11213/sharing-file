package jp.co.jsbank.mb.bankingapp.bean.opened.mbop.mbop1202

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

/**
 * MBOP1202リクエストエンティティ.
 */
@Parcelize
data class MBOP1202RequestBean(

    @SerializedName("person_type")
    var personType: String = "",

    // 連携ID
    @SerializedName("applicant_id")
    var applicantId: String = "",
    // 受付番号
    @SerializedName("reception_number")
    var receptionNumber: String = "",

    // 更新区分
    @SerializedName("update_type")
    var updateType: String = "",
    // 氏名　姓
//    @SerializedName("last_name")
//    var lastName: String = "",
    // 氏名　名
//    @SerializedName("first_name")
//    var firstName: String = "",
    // 氏名　ミドルネーム
    @SerializedName("middle_name")
    var middleName: String = "",
    // 氏名　姓　カナ
    @SerializedName("last_name_kana")
    var lastNameKana: String = "",
    // 氏名　名　カナ
    @SerializedName("first_name_kana")
    var firstNameKana: String = "",
    // 氏名　ミドルネーム　カナ
    @SerializedName("middle_name_kana")
    var middleNameKana: String = "",
    // 生年月日
    var birthday: String = "",
    // 国籍　ISO 3166-1 alpha-2
    val nationality: String = "jp",
    // 性別
    var sex: String = "",
    //  郵便番号
    @SerializedName("zip_code")
    var zipCode: String = "",
    //  電話番号
    @SerializedName("phone_number")
    var phoneNumber: String = "",
    // 分かれていない場合は住所1のみを設定
    var address1: String = "",
    var address2: String = "",
    var address3: String = "",
    var address4: String = "",
    //　本人確認書類番号
    @SerializedName("id_number")
    var idNumber: String = "",

) : Parcelable

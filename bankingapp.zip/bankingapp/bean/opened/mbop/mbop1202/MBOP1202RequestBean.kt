package jp.co.jsbank.mb.bankingapp.bean.opened.mbop.mbop1202

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.parcelize.Parcelize

import jp.co.jsbank.mb.bankingapp.bean.common.FileInfoBean
/**
 * MBOP1202リクエストエンティティ.
 */
@Parcelize
data class MBOP1202RequestBean(

    // 本人区分
    var personType: String = "",
    // 連携ID
    var applicantId: String = "",
    // 受付番号
    var receptionNumber: String = "",

    // 更新区分
    var updateType: String = "",
    // 氏名　姓
    var lastName: String = "",
    // 氏名　名
    var firstName: String = "",
    // 氏名　ミドルネーム
    var middleName: String = "",
    // 氏名　姓　カナ
    var lastNameKana: String = "",
    // 氏名　名　カナ
    var firstNameKana: String = "",
    // 氏名　ミドルネーム　カナ
    var middleNameKana: String = "",
    // 生年月日
    var birthday: String = "",
    // 国籍　ISO 3166-1 alpha-2
    val nationality: String = "jp",
    // 性別
    var sex: String = "",
    //  郵便番号
    var zipCode: String = "",
    //  電話番号
    var phoneNumber: String = "",
    // 分かれていない場合は住所1のみを設定
    var address1: String = "",
    var address2: String = "",
    var address3: String = "",
    var address4: String = "",
    //　本人確認書類番号
    var idNumber: String = "",
    // ファイル情報リスト
    var fileStreams: MutableList<FileInfoBean> = mutableListOf(),
) : Parcelable

package jp.co.jsbank.mb.bankingapp.bean.opened.mbop.mbop0701

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * MBOP0701応答エンティティ.
 */
data class MBOP0701ResponseBean(
    /**
     * 候补FLG
     */
    var alternateFlg: String = "",

    /**
     * 営業地区部店一覧照会店舗リスト
     */
    var departmentStoreList: List<DepartmentStore> = listOf(),

    /**
     * 支店一覧照会店舗リスト
     */
    var branchList: List<BranchStore> = listOf(),
)

/**
 * 店舗情報.
 */
@Parcelize
data class DepartmentStore(
    /**
     * 地区コード
     */
    var addressCode: String = "",

    /**
     * 店番
     */
    var branchNumber: String = "",

    /**
     * 地区区分
     */
    var areaCode: String = "",

    /**
     * 都道府県漢字
     */
    var prefecture: String = "",

    /**
     * 市区町村漢字
     */
    var city: String = "",

    /**
     * 町漢字
     */
    var addrDetail1: String = "",

    /**
     * 丁目漢字
     */
    var addrDetail2: String = "",

    /**
     * 地区郵便番号
     */
    var areaZipCode: String = "",

    /**
     * 金融機関コード
     */
    var bankCode: String = "",

    /**
     * 店名（漢字）
     */
    var branchKanjiName: String = "",

    /**
     * 所属部門区分
     */
    var divisionType: String = "",

    /**
     * 照会店舗タイプ
     */
    var branchInquiryType: String = "",

    /**
     * 支店郵便番号
     */
    var branchZipCode: String = "",

    /**
     * 店舗住所
     */
    var branchKanjiAddress: String = "",

    /**
     * 電話番号
     */
    var phoneNumber: String = "",

    /**
     * 緯度
     */
    var latitude: String = "",

    /**
     * 経度
     */
    var longitude: String = "",

    /**
     * 表示グループ名
     */
    var displayGroupName: String = "",

    /**
     * 表示順
     */
    var displayOrder: String = "",
) : Parcelable

/**
 * 支店店舗情報.
 */
@Parcelize
data class BranchStore(
    /**
     * 金融機関コード
     */
    var bankCode: String = "",

    /**
     * 店番
     */
    var branchNumber: String = "",

    /**
     * 店名（漢字）
     */
    var branchKanjiName: String = "",

    /**
     * 所属部門区分
     */
    var divisionType: String = "",

    /**
     * 照会店舗タイプ
     */
    var branchInquiryType: String = "",

    /**
     * 郵便番号
     */
    var zipCode: String = "",

    /**
     * 住所
     */
    var branchKanjiAddress: String = "",

    /**
     * 電話番号
     */
    var phoneNumber: String = "",

    /**
     * 店舗案内
     */
    var branchGuide: String = "",

    /**
     * 緯度
     */
    var latitude: String = "",

    /**
     * 経度
     */
    var longitude: String = "",

    /**
     * 表示グループ名
     */
    var displayGroupName: String = "",

    /**
     * 表示順
     */
    var displayOrder: String = "",

) : Parcelable

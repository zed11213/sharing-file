package jp.co.jsbank.mb.bankingapp.bean.basic

import jp.co.jsbank.mb.bankingapp.bean.common.ErrorResponseBean

/**
 * レスポンスベース
 */
data class BasicBean<T>(
    var resultDto: T?,
    var statusCode: Int,
) : ErrorResponseBean()

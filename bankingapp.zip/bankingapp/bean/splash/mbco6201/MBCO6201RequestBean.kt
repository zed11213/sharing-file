package jp.co.jsbank.mb.bankingapp.bean.splash.mbco6201

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * JAGリクエストボディ
 */
@Parcelize
data class MBCO6201RequestBean(

    /**
     * デバイスID
     */
    var jagDeviceId: String = "",

    /**
     * アプリケーションID（個人用：JBA-Retail 個人以外：JBA-Bizz）
     */
    var jagApplicationId: String = "",

    /**
     * 旧公開鍵（BASE64にてencodeしたものを指定すること.）
     */
    var jagPublicKeyInvalid: String = "",

    /**
     * 公開鍵（BASE64にてencodeしたものを指定すること.）
     */
    var jagPublicKey: String = "",

    /**
     * チャレンジトークン
     */
    var jagChallengeToken: String = "",

    /**
     * TRX種別
     */
    var jagTrxType: String = "",

    /**
     * トランザクションID
     */
    var jagTrxId: String = "",

    /**
     * JAG PROFILE JWT
     */
    var jagProfile: String = "",

    /**
     * 確定キャンセル要求(0: 確定要求 1: キャンセル要求)
     */
    var jagDoCancel: String = "",
) : Parcelable

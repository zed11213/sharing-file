package jp.co.jsbank.mb.bankingapp.bean.splash.mbco6201

/**
 * 公開鍵登録応答エンティティ
 */
data class AZ0901ResponseEntity(

    /**
     * トランザクションID
     */
    var jagTrxId: String = "",

    /**
     * 公開鍵
     */
    var jagEncryptedKey: String = "",
)

/**
 * 公開鍵更新応答エンティティ
 */
data class AZ0903ResponseEntity(

    /**
     * トランザクションID
     */
    var jagTrxId: String = "",

    /**
     * 公開鍵
     */
    var jagEncryptedKey: String = "",
)

/**
 * 認可コード取得応答エンティティ
 */
data class AZ0911ResponseEntity(

    /**
     * アクセストークン
     */
    var jagTrxId: String = "",

    /**
     * アクセストークン
     */
    var jagAccessToken: String = "",

    /**
     * リフレッシュトークン
     */
    var jagRefreshToken: String = "",
)

/**
 * 認可コード取得応答エンティティ
 */
data class AZ0913ResponseEntity(

    /**
     * アクセストークン
     */
    var jagTrxId: String = "",

    /**
     * アクセストークン
     */
    var jagAccessToken: String = "",

    /**
     * リフレッシュトークン
     */
    var jagRefreshToken: String = "",
)

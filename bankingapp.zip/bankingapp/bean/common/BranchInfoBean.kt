package jp.co.jsbank.mb.bankingapp.bean.common

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * 郵便番号
 */
@Parcelize
data class BranchInfoBean(

    /**
     * 店番
     */
    var branchCode: String = "",

    /**
     * CIF番号
     */
    var cifNo: String = "",
) : Parcelable

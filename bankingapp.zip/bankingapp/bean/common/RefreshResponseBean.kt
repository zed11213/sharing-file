package jp.co.jsbank.mb.bankingapp.bean.common

/**
 * リフレッシュレスポンス
 */
data class RefreshResponseBean(

    /**
     * アクセストークン.
     */
    var accessToken: String = "",

    /**
     * リフレッシュトークン.
     */
    var refreshToken: String = "",

)

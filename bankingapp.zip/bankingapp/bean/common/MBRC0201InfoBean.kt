package jp.co.jsbank.mb.bankingapp.bean.common

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * お知らせID
 */
@Parcelize
data class MBRC0201InfoBean(

    /**
     * お知らせID
     */
    var anncmntId: String = "",
) : Parcelable

package jp.co.jsbank.mb.bankingapp.bean.common

/**
 * エラー応答共通定義
 */
open class ErrorResponseBean(
    /**
     * エラーコード
     */
    var errorCode: String? = "",
    /**
     * エラーメッセージ
     */
    var errorMessage: String? = "",
)

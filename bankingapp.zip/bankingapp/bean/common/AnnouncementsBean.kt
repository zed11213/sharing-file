package jp.co.jsbank.mb.bankingapp.bean.common

/**
 * お知らせ
 */
data class AnnouncementsBean(

    /**
     * お知らせの日付
     */
    var date: String = "",

    /**
     * お知らせの種類
     */
    var type: String = "",

    /**
     * お知らせの内容
     */
    var content: String = "",

    /**
     * 重要フラグ
     */
    var mainFlag: String = "",

    /**
     * お気に入りフラグ
     */
    var attentionFlag: String = "",

    /**
     * 既読フラグ
     */
    var readFlag: String = "",
)

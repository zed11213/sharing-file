package jp.co.jsbank.mb.bankingapp.bean.common

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * 受付番号
 */
@Parcelize
data class RestorationInfoBean(

    /**
     * 受付番号
     */
    var receiptNumber: String = "",
) : Parcelable

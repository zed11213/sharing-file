package jp.co.jsbank.mb.bankingapp.bean.common

import android.os.Parcelable
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.FULL_SPACE
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.HALF_SPACE
import kotlinx.android.parcel.Parcelize

/**
 * 口座開設申込情報（法人）
 */
@Parcelize
data class CorporationBean(
    /**
     * 受付番号.
     */
    var receiptNumber: String = "",

    /**
     * 顧客.
     */
    var customerId: String = "",

    /**
     * CIF番号.
     */
    var cifNumber: String = "",

    /**
     * 人格区分.
     */
    var personType: String = "",

    /**
     * 画面ID
     */
    var pageId: String = "",

    /**
     * 申込ステータス.
     */
    var applyStatus: String = "",

    /**
     * 申請開始日時.
     */
    var applyStartDateTime: String = "",

    /**
     * 申請有効期限日時.
     */
    var applyValidDateTime: String = "",

    /**
     * 利用停止フラグ.
     */
    var useSuspendFlag: String = "",

    /**
     * 取引種別.
     */
    var transactionType: String = "",

    /**
     * 会社形態.
     */
    var companyForm: String = "",

    /**
     * 会社形態（その他 ）.
     */
    var companyFormOther: String = "",

    /**
     * 会社形態位置.
     */
    var companyFormLocation: String = "",

    /**
     * 事業先名（半角カナ）.
     */
    var businessNameKana: String = "",

    /**
     * 事業先名（漢字）.
     */
    var businessNameKanji: String = "",

    /**
     * 設立年月日
     */
    var establishDate: String = "",

    /**
     * 資本金
     */
    var capital: String = "",

    /**
     * 従業員人数
     */
    var numberOfEmployees: String = "",

    /**
     * 事業先電話番号種別
     */
    var businessPhoneType: String = "",

    /**
     * 事業先電話番号（上）
     */
    var businessPhoneNumFirst: String = "",

    /**
     * 事業先電話番号（中）
     */
    var businessPhoneNumMid: String = "",

    /**
     * 事業先電話番号（下）
     */
    var businessPhoneNumLast: String = "",

    /**
     * 代表者氏名カナ（姓）
     */
    var ceoKanaLast: String = "",

    /**
     * 代表者氏名カナ（名）
     */
    var ceoKanaFirst: String = "",

    /**
     * 代表者氏名漢字（姓）
     */
    var ceoKanjiLast: String = "",

    /**
     * 代表者氏名漢字（名）
     */
    var ceoKanjiFirst: String = "",

    /**
     * 代表者生年月日
     */
    var ceoBirthday: String = "",

    /**
     * 代表者郵便番号
     */
    var ceoZipCode: String = "",

    /**
     * 代表者都道府県（半角カナ）
     */
    var ceoStateKana: String = "",

    /**
     * 代表者都道府県
     */
    var ceoState: String = "",

    /**
     * 代表者市区町村（半角カナ）
     */
    var ceoCityKana: String = "",

    /**
     * 代表者市区町村
     */
    var ceoCity: String = "",

    /**
     * 代表者丁目（半角カナ）
     */
    var ceoStreetKana: String = "",

    /**
     * 代表者丁目
     */
    var ceoStreet: String = "",

    /**
     * 代表者番地（半角カナ）
     */
    var ceoAddressKana: String = "",

    /**
     * 代表者番地（全角）
     */
    var ceoAddress: String = "",

    /**
     * 代表者建物名・号室（半角カナ）
     */
    var ceoBuildingKana: String = "",

    /**
     * 代表者建物名・号室（全角）
     */
    var ceoBuilding: String = "",

    /**
     * 所在地郵便番号
     */
    var locationZipCode: String = "",

    /**
     * 所在地都道府県（半角カナ）
     */
    var locationStateKana: String = "",

    /**
     * 所在地都道府県
     */
    var locationState: String = "",

    /**
     * 所在地市区町村（半角カナ）
     */
    var locationCityKana: String = "",

    /**
     * 所在地市区町村
     */
    var locationCity: String = "",

    /**
     * 所在地丁目（半角カナ）
     */
    var locationStreetKana: String = "",

    /**
     * 所在地丁目
     */
    var locationStreet: String = "",

    /**
     * 所在地番地（半角カナ）
     */
    var locationAddressKana: String = "",

    /**
     * 所在地番地（全角）
     */
    var locationAddress: String = "",

    /**
     * 所在地建物名・号室（半角カナ）
     */
    var locationBuildingRoomKana: String = "",

    /**
     * 所在地建物名・号室（全角）
     */
    var locationBuildingRoom: String = "",

    /**
     * 本店所在地相違区分
     */
    var headOfficeClassification: String = "",

    /**
     * 本店所在地郵便番号
     */
    var headOfficeLocZipCode: String = "",

    /**
     * 本店所在地都道府県（半角カナ）
     */
    var headOfficeLocPrefectureKana: String = "",

    /**
     * 本店所在地都道府県
     */
    var headOfficeLocPrefecture: String = "",

    /**
     * 本店所在地市区町村（半角カナ）
     */
    var headOfficeLocCityKana: String = "",

    /**
     * 本店所在地市区町村
     */
    var headOfficeLocCity: String = "",

    /**
     * 本店所在地丁目（半角カナ）
     */
    var headOfficeLocStreetKana: String = "",

    /**
     * 本店所在地丁目
     */
    var headOfficeLocStreet: String = "",

    /**
     * 本店所在地番地（半角カナ）
     */
    var headOfficeLocAddressKana: String = "",

    /**
     * 本店所在地番地（全角）
     */
    var headOfficeLocAddress: String = "",

    /**
     * 本店建物名・号室（半角カナ）
     */
    var headOfficeLocBuildingRoomKana: String = "",

    /**
     * 本店建物名・号室（全角）
     */
    var headOfficeLocBuildingRoom: String = "",

    /**
     * 電話番号１種別.
     */
    var phoneType1: String = "",

    /**
     * 電話番号１（上）.
     */
    var homePhone1Top: String = "",

    /**
     * 電話番号１（中）.
     */
    var homePhone1Middle: String = "",

    /**
     * 電話番号１（下）.
     */
    var homePhone1Bottom: String = "",

    /**
     * 電話番号２種別.
     */
    var phoneType2: String = "",

    /**
     * 電話番号２（上）.
     */
    var homePhone2Top: String = "",

    /**
     * 電話番号２（中）.
     */
    var homePhone2Middle: String = "",

    /**
     * 電話番号２（下）.
     */
    var homePhone2Bottom: String = "",

    /**
     * 代表者・役員.
     */
    var ceoOfficer: MutableList<CeoOfficer> = mutableListOf(),

    /**
     * 実質的支配者.
     */
    var substantialRuler: MutableList<SubstantialRuler> = mutableListOf(),

    /**
     * 取引目的
     */
    var transactPurpose: String = "",

    /**
     * 取引目的（その他）
     */
    var transactPurposeOther: String = "",

    /**
     * 取引目的（詳細）
     */
    var transactPurposeDetail: String = "",

    /**
     * 事業内容
     */
    var businessDescription: String = "",

    /**
     * 事業内容（その他）
     */
    var businessDescriptionOther: String = "",

    /**
     * 取扱品目
     */
    var handingItem: String = "",

    /**
     * 主要取引先（仕入）
     */
    var mainlyTradePurchase: String = "",

    /**
     * 主要取引先（販売）
     */
    var mainlyTradeSale: String = "",

    /**
     * 当金庫との取引希望
     */
    var preferredTrade: String = "",

    /**
     * 当金庫との取引希望（その他）
     */
    var otherBusinessWishes: String = "",

    /**
     * 取引のきっかけ
     */
    var transactionTrigger: String = "",

    /**
     * 開設部店コード
     */
    var openBranchCode: String = "",

    /**
     * メールアドレス
     */
    var emailAddress: String = "",

    /**
     * 取引金融機関
     */
    var financialInstitution: String = "",

    /**
     * 取引金融機関（預金状況）
     */
    var financialInstitutionDepositStatus: String = "",

    /**
     * 取引金融機関（貸金状況）
     */
    var financialInstitutionLoanStatus: String = "",

    /**
     * 役員役職
     */
    var position: String = "",

    /**
     * 役員カナ氏名（姓）
     */
    var officerLastName: String = "",

    /**
     * 役員カナ氏名（名）
     */
    var officerFirstName: String = "",

    /**
     * 役員漢字氏名（名）
     */
    var officerKanjiLastName: String = "",

    /**
     * 役員漢字氏名（名）
     */
    var officerKanjiFirstName: String = "",

    /**
     * 役員生年月日
     */
    var officerBirthday: String = "",

    /**
     * 役員郵便番号
     */
    var officerZipCode: String = "",

    /**
     * 役員都道府県（半角カナ）
     */
    var officerPrefectureKana: String = "",

    /**
     * 役員都道府県
     */
    var officerPrefecture: String = "",

    /**
     * 役員市区町村（半角カナ）
     */
    var officerCityKana: String = "",

    /**
     * 役員市区町村
     */
    var officerCity: String = "",

    /**
     * 役員丁目（半角カナ）
     */
    var officerStreetKana: String = "",

    /**
     * 役員丁目
     */
    var officerStreet: String = "",

    /**
     * 役員番地（半角カナ）
     */
    var officerAddressKana: String = "",

    /**
     * 役員番地（全角）
     */
    var officerAddress: String = "",

    /**
     * 役員建物名・号室（半角カナ）
     */
    var officerBuildingKana: String = "",

    /**
     * 役員建物名・号室（全角）
     */
    var officerBuilding: String = "",

    /**
     * 役員電話番号種別
     */
    var officerPhoneType: String = "",

    /**
     * 役員電話番号（上）
     */
    var officerPhoneNumOneFirst: String = "",

    /**
     * 役員電話番号（中）
     */
    var officerPhoneNumOneMid: String = "",

    /**
     * 役員電話番号（下）
     */
    var officerPhoneNumOneLast: String = "",

    /**
     * 支配者カナ氏名（姓）
     */
    var rulerLastName: String = "",

    /**
     * 支配者カナ氏名（名））
     */
    var rulerFirstName: String = "",

    /**
     * 支配者漢字氏名（姓）
     */
    var rulerKanjiLastName: String = "",

    /**
     * 支配者漢字氏名（名）
     */
    var rulerKanjiFirstName: String = "",

    /**
     * 支配者生年月日
     */
    var rulerBirth: String = "",

    /**
     * 支配者郵便番号
     */
    var rulerZipCode: String = "",

    /**
     * 支配者都道府県（半角カナ）
     */
    var rulerPrefectureKana: String = "",

    /**
     * 支配者都道府県
     */
    var rulerPrefecture: String = "",

    /**
     * 支配者市区町村（半角カナ）
     */
    var rulerCityKana: String = "",

    /**
     * 支配者市区町村
     */
    var rulerCity: String = "",

    /**
     * 支配者丁目（半角カナ）
     */
    var rulerStreetKana: String = "",

    /**
     * 支配者丁目
     */
    var rulerStreet: String = "",

    /**
     * 支配者番地（半角カナ）
     */
    var rulerAddressKana: String = "",

    /**
     * 支配者番地（全角）
     */
    var rulerAddress: String = "",

    /**
     * 支配者建物名・号室（半角カナ）
     */
    var rulerBuildingKana: String = "",

    // 2025/01/29 共同化ため実質的支配者の電話番号　start
    /**
     * 実質的支配者電話番号
     */
    var rulerPhoneType: String = "",

    /**
     * 実質的支配者電話番号
     */
    var rulerPhoneFirst: String = "",

    /**
     * 実質的支配者電話番号
     */
    var rulerPhoneSecond: String = "",

    /**
     * 実質的支配者電話番号
     */
    var rulerPhoneThird: String = "",
    // 2025/01/29 共同化ため実質的支配者の電話番号　end
    /**
     * 配者建物名・号室（全角）
     */
    var rulerBuilding: String = "",

    /**
     * 代表者本人確認書類
     */
    var identityDocuments: List<IdentityDocuments> = listOf(),

    /**
     * 本人確認書類
     */
    var businessDocuments: List<BusinessDocuments> = listOf(),

    /**
     * 本人確認書類URL
     */
    var identityVerificationDocumentsUrl: String = "",
) : Parcelable {
    /**
     * API通信前のパラメータ処理
     * 番地にスペースを入れる
     */
    fun convertToParams(): CorporationBean {
        return this.copy(
            officerAddress = this.officerAddress + if (this.officerBuilding.isBlank()) "" else FULL_SPACE,
            officerAddressKana = this.officerAddressKana + if (this.officerBuildingKana.isBlank()) "" else HALF_SPACE,
            rulerAddress = this.rulerAddress + if (this.rulerBuilding.isBlank()) "" else FULL_SPACE,
            rulerAddressKana = this.rulerAddressKana + if (this.rulerBuildingKana.isBlank()) "" else HALF_SPACE,
            ceoAddress = this.ceoAddress + if (this.ceoBuilding.isBlank()) "" else FULL_SPACE,
            ceoAddressKana = this.ceoAddressKana + if (this.ceoBuildingKana.isBlank()) "" else HALF_SPACE,
            locationAddress = this.locationAddress + if (this.locationBuildingRoom.isBlank()) "" else FULL_SPACE,
            locationAddressKana = this.locationAddressKana + if (this.locationBuildingRoomKana.isBlank()) "" else HALF_SPACE,
            headOfficeLocAddress = this.headOfficeLocAddress + if (this.headOfficeLocBuildingRoom.isBlank()) "" else FULL_SPACE,
            headOfficeLocAddressKana = this.headOfficeLocAddressKana + if (this.headOfficeLocBuildingRoomKana.isBlank()) "" else HALF_SPACE,
            ceoOfficer = this.ceoOfficer.map{ it.convertToParams() }.toMutableList(),
            substantialRuler = this.substantialRuler.map{ it.convertToParams() }.toMutableList(),
        )
    }
}

@Parcelize
data class CeoOfficer(
    /**
     * 役員役職
     */
    var position: String = "",

    /**
     * 役員氏名カナ（姓）
     */
    var officerLastName: String = "",

    /**
     * 役員氏名カナ（名）
     */
    var officerFirstName: String = "",

    /**
     * 役員氏名漢字（姓）
     */
    var officerKanjiLastName: String = "",

    /**
     * 役員氏名漢字（名）
     */
    var officerKanjiFirstName: String = "",

    /**
     * 役員生年月日
     */
    var officerBirthday: String = "",

    /**
     * 役員郵便番号
     */
    var officerZipCode: String = "",

    /**
     * 役員都道府県（半角カナ）
     */
    var officerPrefectureKana: String = "",

    /**
     * 役員都道府県
     */
    var officerPrefecture: String = "",

    /**
     * 役員市区町村（半角カナ）
     */
    var officerCityKana: String = "",

    /**
     * 役員市区町村
     */
    var officerCity: String = "",

    /**
     * 役員丁目（半角カナ）
     */
    var officerStreetKana: String = "",

    /**
     * 役員丁目
     */
    var officerStreet: String = "",

    /**
     * 役員番地（半角カナ）
     */
    var officerAddressKana: String = "",

    /**
     * 役員番地（全角）
     */
    var officerAddress: String = "",

    /**
     * 役員建物名・号室（半角カナ）
     */
    var officerBuildingKana: String = "",

    /**
     * 役員建物名・号室（全角）
     */
    var officerBuilding: String = "",

    /**
     * 役員電話番号種別
     */
    var officerPhoneType: String = "",

    /**
     * 役員電話番号（上）
     */
    var officerPhoneNumOneFirst: String = "",

    /**
     * 役員電話番号（中）
     */
    var officerPhoneNumOneMid: String = "",

    /**
     * 役員電話番号（下）
     */
    var officerPhoneNumOneLast: String = "",
) : Parcelable {
    /**
     * API通信前のパラメータ処理
     * 番地にスペースを入れる
     */
    fun convertToParams(): CeoOfficer {
        return this.copy(
            officerAddress = this.officerAddress + if (this.officerBuilding.isBlank()) "" else FULL_SPACE,
            officerAddressKana = this.officerAddressKana + if (this.officerBuildingKana.isBlank()) "" else HALF_SPACE,
        )
    }
}

@Parcelize
data class SubstantialRuler(
    /**
     * 支配者氏名カナ（姓）
     */
    var rulerLastName: String = "",

    /**
     * 支配者氏名カナ（名）
     */
    var rulerFirstName: String = "",

    /**
     * 支配者氏名漢字（姓）
     */
    var rulerKanjiLastName: String = "",

    /**
     * 支配者氏名漢字（名）
     */
    var rulerKanjiFirstName: String = "",

    /**
     * 支配者生年月日
     */
    var rulerBirthday: String = "",

    /**
     * 支配者郵便番号
     */
    var rulerZipCode: String = "",

    /**
     * 支配者都道府県（半角カナ）
     */
    var rulerPrefectureKana: String = "",

    /**
     * 支配者都道府県
     */
    var rulerPrefecture: String = "",

    /**
     * 支配者市区町村（半角カナ）
     */
    var rulerCityKana: String = "",

    /**
     * 支配者市区町村
     */
    var rulerCity: String = "",

    /**
     * 支配者丁目（半角カナ）
     */
    var rulerStreetKana: String = "",

    /**
     * 支配者丁目
     */
    var rulerStreet: String = "",

    /**
     * 支配者番地（半角カナ）
     */
    var rulerAddressKana: String = "",

    /**
     * 支配者番地（全角）
     */
    var rulerAddress: String = "",

    /**
     * 支配者建物名・号室（半角カナ）
     */
    var rulerBuildingKana: String = "",

    /**
     * 支配者建物名・号室（全角）
     */
    var rulerBuilding: String = "",

    // 2025/01/29 共同化ため実質的支配者の電話番号　start
    /**
     * 実質的支配者電話番号
     */
    var rulerPhoneType: String = "",

    /**
     * 実質的支配者電話番号
     */
    var rulerPhoneTypeLabel: String = "",

    /**
     * 実質的支配者電話番号
     */
    var rulerPhoneNumFirst: String = "",

    /**
     * 実質的支配者電話番号
     */
    var rulerPhoneNumMid: String = "",

    /**
     * 実質的支配者電話番号
     */
    var rulerPhoneNumLast: String = "",
    // 2025/01/29 共同化ため実質的支配者の電話番号　end
) : Parcelable {
    /**
     * API通信前のパラメータ処理
     * 番地にスペースを入れる
     */
    fun convertToParams(): SubstantialRuler {
        return this.copy(
            rulerAddress = this.rulerAddress + if (this.rulerBuilding.isBlank()) "" else FULL_SPACE,
            rulerAddressKana = this.rulerAddressKana + if (this.rulerBuildingKana.isBlank()) "" else HALF_SPACE,
        )
    }
}

@Parcelize
data class BusinessDocuments(
    /**
     * 書類種類
     */
    var documentsType: String = "",

    /**
     * エンドポイント
     */
    var endPoint: String = "",

    /**
     * バケット
     */
    var bucket: String = "",

    /**
     * オブジェクトパス
     */
    var objectPath: String = "",

    /**
     * ファイル名
     */
    var fileName: String = "",

    /**
     * ファイル
     */
    var fileStream: String = "",
) : Parcelable

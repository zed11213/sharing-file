package jp.co.jsbank.mb.bankingapp.bean.common

import android.os.Parcelable
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.FULL_SPACE
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.HALF_SPACE
import kotlinx.android.parcel.Parcelize

/**
 * 口座開設申込情報（個人）
 */
@Parcelize
data class Individual(
    /**
     * 受付番号.
     */
    var receiptNumber: String = "",

    /**
     * CIF番号.
     */
    var cifNumber: String = "",

    /**
     * 顧客ID.
     */
    var customerId: String = "",

    /**
     * 人格区分.
     */
    var personType: String = "",

    /**
     * 取引種別.
     */
    var transactionType: String = "",

    /**
     * 申込ステータス.
     */
    var applyStatus: String = "",

    /**
     * 申込日.
     */
    var applicationDate: String = "",

    /**
     * 申請開始日時.
     */
    var applyStartDateTime: String = "",

    /**
     * 申請有効期限日時.
     */
    var applyValidDateTime: String = "",

    /**
     * 利用停止フラグ.
     */
    var useSuspendFlag: String = "",

    /**
     * カナ氏名（姓）.
     */
    var customerLastName: String = "",

    /**
     * カナ氏名（名）.
     */
    var customerFirstName: String = "",

    /**
     * 氏名漢字（姓）.
     */
    var customerKanjiLastName: String = "",

    /**
     * 氏名漢字（名）.
     */
    var customerKanjiFirstName: String = "",

    /**
     * 生年月日.
     */
    var birthday: String = "",

    /**
     * 性別.
     */
    var gender: String = "",

    /**
     * 性別回答有無.
     */
    var genderAnswer: String = "",

    /**
     * 郵便番号.
     */
    var zipCode: String = "",

    /**
     * 地区コード.
     */
    var addressCode: String = "",

    /**
     * 地区コード（枝番）.
     */
    var addressCodeBranchNumber: String = "",

    /**
     * 都道府県（半角カナ）.
     */
    var prefectureKana: String = "",

    /**
     * 都道府県.
     */
    var prefecture: String = "",

    /**
     * 市区町村（半角カナ）.
     */
    var cityKana: String = "",

    /**
     * 市区町村.
     */
    var city: String = "",

    /**
     * 丁目（半角カナ）.
     */
    var addrDetail2Kana: String = "",

    /**
     * 丁目.
     */
    var addrDetail2: String = "",

    /**
     * 番地（半角カナ）.
     */
    var addrDetail3Kana: String = "",

    /**
     * 番地（全角）.
     */
    var addrDetail3: String = "",

    /**
     * 建物名・号室（半角カナ）.
     */
    var buildingRoomKana: String = "",

    /**
     * 建物名・号室（全角）.
     */
    var buildingRoom: String = "",

    /**
     * 地区コード.
     */
    var districtCode: String = "",

    /**
     * 地区コード-枝番.
     */
    var districtCodeBranchNumber: String = "",

    /**
     * 地区コード-番地（全角）.
     */
    var districtCodeAddress: String = "",

    /**
     * 住所方書（半角カナ）.
     */
    var addressKana: String = "",

    /**
     * 住所方書（漢字）.
     */
    var addressKanji: String = "",

    /**
     * 電話番号１種別.
     */
    var phoneType1: String = "",

    /**
     * 電話番号１（上）.
     */
    var phoneNumOneFirst: String = "",

    /**
     * 電話番号１（中）.
     */
    var phoneNumOneMid: String = "",

    /**
     * 電話番号１（下）.
     */
    var phoneNumOneLast: String = "",

    /**
     * 電話番号２種別.
     */
    var phoneType2: String = "",

    /**
     * 電話番号２（上）.
     */
    var phoneNumTwoFirst: String = "",

    /**
     * 電話番号２（中）.
     */
    var phoneNumTwoMid: String = "",

    /**
     * 電話番号２（下）.
     */
    var phoneNumTwoLast: String = "",

    /**
     * 業種.
     */
    var category: String = "",

    /**
     * 職業.
     */
    var occupation: String = "",

    /**
     * 職業（その他 ）.
     */
    var occupationOther: String = "",

    /**
     * 取引目的.
     */
    var transactPurpose: String = "",

    /**
     * 取引目的（その他 ）.
     */
    var transactPurposeOther: String = "",

    /**
     * 取引のきっかけ.
     */
    var transactionTrigger: String = "",

    /**
     * 店番.
     */
    var branchNumber: String = "",

    /**
     * 預金種目.
     */
    var accountType: String = "",

    /**
     * 口座番号.
     */
    var accountNumber: String = "",

    // 2025/01/23 共同化ためマネロン　項目を追加　start
    /**
     * 取引原資.
     */
    var transOriginalCapitalName: String = "",

    /**
     * 取引原資その他.
     */
    var transOriginalCapitalOtherDescribeAnswer: String = "",
    /**
     * 毎月の取引金額.
     */
    var monthlyTransAmountName: String = "",

    /**
     * 取引頻度.
     */
    var transFrequencyName: String = "",

    /**
     * ２００万超の現金取引予定.
     */
    var twoMillionMoreCashTransScheduled: String = "",

    /**
     * ２００万超取引理由.
     */
    var twoMillionMoreTransReason: String = "",

    /**
     * ２００万超取引頻度.
     */
    var twoMillionMoreTransFrequencyName: String = "",

    /**
     * ２００万超取引金額.
     */
    var twoMillionMoreTransAmountName: String = "",

    /**
     * 業務内容（名称）.
     */
    var businessContentName: String = "",

    /**
     * 業務内容その他.
     */
    var businessContentOtherDescribeAnswer: String = "",

    /**
     * 役職（名称）.
     */
    var pstnName: String = "",

    /**
     * 役職その他記述回答.
     */
    var pstnOtherDescribeAnswer: String = "",

    /**
     * 年収.
     */
    var annualIncome: String = "",

    /**
     * 上場／非上場.
     */
    var playOrNotPlay: String = "",
    // 2025/01/23 共同化ためマネロン　項目を追加　end

    /**
     * サブNo.
     */
    var accountSubNumber: String = "",

    /**
     * 勤務先名.
     */
    var wpName: String = "",

    /**
     * 勤務先名（半角カナ）.
     */
    var wpNameKana: String = "",

    /**
     * 勤務先郵便番号.
     */
    var wpZipCode: String = "",

    /**
     * 勤務先都道府県.
     */
    var wpPrefecture: String = "",

    /**
     * 勤務先都道府県（半角カナ）.
     */
    var wpStateKana: String = "",

    /**
     * 勤務先市区町村.
     */
    var wpCity: String = "",

    /**
     * 勤務先市区町村（半角カナ）.
     */
    var wpCityKana: String = "",

    /**
     * 勤務先丁目（半角カナ）.
     */
    var wpStreetKana: String = "",

    /**
     * 勤務先丁目.
     */
    var wpStreet: String = "",

    /**
     * 勤務先番地（全角）.
     */
    var wpAddress: String = "",

    /**
     * 勤務先番地（半角カナ）.
     */
    var wpAddressKana: String = "",

    /**
     * 勤務先建物名・号室（全角）.
     */
    var wpBuilding: String = "",

    /**
     * 勤務先電話番号種別.
     */
    var wpPhoneType: String = "",

    /**
     * 勤務先電話番号（上）.
     */
    var wpPhoneFirst: String = "",

    /**
     * 勤務先電話番号（中）.
     */
    var wpPhoneMid: String = "",

    /**
     * 勤務先電話番号（下）.
     */
    var wpPhoneLast: String = "",

    /**
     * 学校名.
     */
    var schName: String = "",

    /**
     * 学校郵便番号.
     */
    var schZipCode: String = "",

    /**
     * 学校都道府県.
     */
    var schPrefectures: String = "",

    /**
     * 学校市区町村.
     */
    var schCity: String = "",

    /**
     * 学校丁目.
     */
    var schStreet: String = "",

    /**
     * 学校番地（全角）.
     */
    var schAddress: String = "",

    /**
     * 学校建物名・号室（全角）.
     */
    var schBuilding: String = "",

    /**
     * 学校電話番号（電話区分）.
     */
    var schPhoneNumberType: String = "",

    /**
     * 学校電話番号（上）.
     */
    var schPhoneNumberFirst: String = "",

    /**
     * 学校電話番号（中）.
     */
    var schPhoneNumberMid: String = "",

    /**
     * 学校電話番号（下）.
     */
    var schPhoneNumberLast: String = "",

    /**
     * メールアドレス.
     */
    var emailAddress: String = "",

    /**
     * 定期・定積口座番号.
     */
    var fixedDepositAccountNumber: String = "",

    /**
     * 開設店番.
     */
    var openBranchNumber: String = "",

    /**
     * 開設部店コード.
     */
    var openBranchCode: String = "",

    /**
     * eKYC確認結果.
     */
    var ekycResult: String = "",

    /**
     * 本人確認書類URL.
     */
    var identityVerificationDocumentsUrl: String = "",

    /**
     * 本人確認書類.
     */
    var identityDocuments: List<IdentityDocuments> = listOf(),

    /**
     * 更新パターン
     */
    var updateType: String = "",
) : Parcelable {

    /**
     * API通信前のパラメータ処理
     * 番地にスペースを入れる
     */
    fun convertToParams(): Individual {
        return this.copy(
            addrDetail3 = this.addrDetail3 + if (this.buildingRoom.isBlank()) "" else FULL_SPACE,
            addrDetail3Kana = this.addrDetail3Kana + if (this.buildingRoomKana.isBlank()) "" else HALF_SPACE,
            schAddress = this.schAddress + if (this.schBuilding.isBlank()) "" else FULL_SPACE,
            wpAddress = this.wpAddress + if (this.wpBuilding.isBlank()) "" else FULL_SPACE,
        )
    }
}

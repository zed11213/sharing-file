package jp.co.jsbank.mb.bankingapp.bean.common

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * 顧客番号、店番ペアリスト
 */
@Parcelize
data class CifBranchPairListBean(

    /**
     * CifBranchPair リスト
     */
    var cifBranchPairList: MutableList<CifBranchPair> = mutableListOf<CifBranchPair>(),

    ) : Parcelable

/**
 * 顧客番号、店番ペア
 */
@Parcelize
data class CifBranchPair(

    /**
     * 顧客番号
     * 例:0008813
     */
    var cifNo: String = "",

    /**
     * 店番
     * 例:001
     */
    var branchCode: String = "",

    ) : Parcelable

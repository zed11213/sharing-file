package jp.co.jsbank.mb.bankingapp.bean.common

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * Jag用
 */
@Parcelize
data class JagPeerBean(

    /**
     * トランザクションID
     */
    var jagTrxId: String = "",

    /**
     * 共通鍵
     */
    var jagEncryptedKey: String = "",

    /**
     * アクセストークン
     */
    var jagAccessToken: String = "",

    /**
     * リフレッシュトークン
     */
    var jagRefreshToken: String = "",

    /**
     * 顧客ID
     */
    var customerId: String = "",

    /**
     * 利用者ID
     */
    var userId: String = "",

    /**
     * デバイスID
     */
    var deviceId: String = "",
) : Parcelable

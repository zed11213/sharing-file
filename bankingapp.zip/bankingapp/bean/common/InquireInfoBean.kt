package jp.co.jsbank.mb.bankingapp.bean.common

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * 店舗リスト
 */
@Parcelize
data class InquireInfoBean(

    /**
     * 受付番号
     */
    var receiptNumber: String = "",

    /**
     * 人格区分
     */
    var personType: String = "",
) : Parcelable

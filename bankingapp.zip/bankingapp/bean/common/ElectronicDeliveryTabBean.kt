package jp.co.jsbank.mb.bankingapp.bean.common

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * 電子交付用のタブのデータ
 */
@Parcelize
data class ElectronicDeliveryTabBean(

    /**
     * 口座番号
     */
    var accountNo: String = "",

    var accountNumber: String = "",

    /**
     * 預金番号
     */
    var code: String = "",

    /**
     * 種類
     */
    var type: String = "",
) : Parcelable

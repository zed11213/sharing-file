package jp.co.jsbank.mb.bankingapp.bean.common

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * お知らせID
 */
@Parcelize
data class AnncmntIdInfoBean(

    /**
     * お知らせID
     */
    var anncmntId: String = "",

    /**
     * 申込ID
     */
    var applyId: String = "",

    /**
     * お知らせ種別コード
     */
    var anncmntType: String = "",

    /**
     * 文書種別コード
     */
    var documentType: String = "",
) : Parcelable

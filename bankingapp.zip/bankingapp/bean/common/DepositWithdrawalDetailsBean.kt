package jp.co.jsbank.mb.bankingapp.bean.common

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * 店舗リスト
 */
@Parcelize
data class DepositWithdrawalDetailsBean(

    /**
     * 明細継続フラグ
     */
    var detailContinuationFlag: String = "",

    /**
     * 開始明細ID
     */
    var detailIdFrom: String = "",

    /**
     * 最大検索件数
     */
    var maxInquiryCount: Int = 0,

    /**
     * 預金種目
     */
    var accountType: String = "",

    /**
     * 店番
     */
    var branchNumber: String = "",

    /**
     * 口座番号
     */
    var accountNumber: String = "",

    /**
     * 口座番号
     */
    var dateOfInquiryFrom: String = "",

    /**
     * 照会開始年月日
     */
    var dateOfInquiryTo: String = "",

) : Parcelable

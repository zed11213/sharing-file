package jp.co.jsbank.mb.bankingapp.bean.common

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * 店舗リスト
 */
@Parcelize
data class AllBalanceInfoBean(

    /**
     * 口座番号
     */
    var accountNumber: String = "",

    /**
     * 店番
     */
    var branchNumber: String = "",

    /**
     * CIF番号
     */
    var cifNumber: String = "",

    /**
     * 預金種目
     */
    var accountType: String = "",
) : Parcelable

package jp.co.jsbank.mb.bankingapp.bean.common

import android.os.Parcelable
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.FULL_SPACE
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.HALF_SPACE
import kotlinx.android.parcel.Parcelize

/**
 * 口座開設申込情報（個人事業主）
 */
@Parcelize
data class SoleProprietorBean(
    /**
     * 受付番号
     */
    var receiptNumber: String = "",

    /**
     * 更新パターン
     */
    var updateType: String = "",

    /**
     * 顧客ID.
     */
    var customerId: String = "",

    /**
     * CIF番号
     */
    var cifNumber: String = "",

    /**
     * 人格区分
     */
    var personType: String = "",

    /**
     * 申込ステータス
     */
    var applyStatus: String = "",

    /**
     * 申請開始日時
     */
    var applyStartDateTime: String = "",

    /**
     * 申請有効期限日時
     */
    var applyValidDateTime: String = "",

    /**
     * 利用停止フラグ.
     */
    var useSuspendFlag: String = "",

    /**
     * 取引種別
     */
    var transactionType: String = "",

    /**
     * 申込日
     */
    var applicationDate: String = "",

    /**
     * 氏名カナ（姓）
     */
    var customerLastName: String = "",

    /**
     * 氏名カナ（名）
     */
    var customerFirstName: String = "",

    /**
     * 氏名漢字（姓）
     */
    var customerKanjiLastName: String = "",

    /**
     * 氏名漢字（名）
     */
    var customerKanjiFirstName: String = "",

    /**
     * 生年月日
     */
    var birthday: String = "",

    /**
     * 性別
     */
    var gender: String = "",

    /**
     * 性別回答有無
     */
    var genderAnswer: String = "",

    /**
     * 屋号カナ
     */
    var roomNoKana: String = "",

    /**
     * 屋号
     */
    var roomNo: String = "",

    /**
     * 従業員人数
     */
    var numberOfEmployees: String = "",

    /**
     * 郵便番号
     */
    var homeZipCode: String = "",

    /**
     * 都道府県
     */
    var homeState: String = "",

    /**
     * 都道府県（半角カナ）
     */
    var homeStateKana: String = "",

    /**
     * 市区町村（半角カナ）
     */
    var homeCityKana: String = "",

    /**
     * 市区町村
     */
    var homeCity: String = "",

    /**
     * 丁目（半角カナ）
     */
    var homeStreetKana: String = "",

    /**
     * 丁目
     */
    var homeStreet: String = "",

    /**
     * 番地（半角カナ）
     */
    var homeAddressKana: String = "",

    /**
     * 番地（全角）
     */
    var homeAddress: String = "",

    /**
     * 建物名・号室（半角カナ）
     */
    var homeBuildingKana: String = "",

    /**
     * 建物名・号室（全角）
     */
    var homeBuilding: String = "",

    /**
     * 所在地郵便番号
     */
    var locationZipCode: String = "",

    /**
     * 所在地都道府県（半角カナ）
     */
    var locationStateKana: String = "",

    /**
     * 所在地都道府県
     */
    var locationState: String = "",

    /**
     * 所在地市区町村（半角カナ）
     */
    var locationCityKana: String = "",

    /**
     * 所在地市区町村
     */
    var locationCity: String = "",

    /**
     * 所在地丁目（半角カナ）
     */
    var locationStreetKana: String = "",

    /**
     * 所在地丁目
     */
    var locationStreet: String = "",

    /**
     * 所在地番地（半角カナ）
     */
    var locationAddressKana: String = "",

    /**
     * 所在地番地（全角）
     */
    var locationAddress: String = "",

    /**
     * 建物名・号室（半角カナ）
     */
    var buildingRoomKana: String = "",

    /**
     * 建物名・号室（全角）
     */
    var buildingRoom: String = "",

    /**
     * 電話番号１種別.
     */
    var phoneType1: String = "",

    /**
     * 電話番号１（上）.
     */
    var homePhone1Top: String = "",

    /**
     * 電話番号１（中）.
     */
    var homePhone1Middle: String = "",

    /**
     * 電話番号１（下）.
     */
    var homePhone1Bottom: String = "",

    /**
     * 電話番号２種別.
     */
    var phoneType2: String = "",

    /**
     * 電話番号２（上）.
     */
    var homePhone2Top: String = "",

    /**
     * 電話番号２（中）.
     */
    var homePhone2Middle: String = "",

    /**
     * 電話番号２（下）.
     */
    var homePhone2Bottom: String = "",

    /**
     * 所在地相違区分
     */
    var locationClassification: String = "",

    /**
     * 電話番号種別
     */
    var phoneType: String = "",

    /**
     * 自宅電話番号（上）
     */
    var phoneNumOneFirst: String = "",

    /**
     * 自宅電話番号（中）
     */
    var phoneNumOneMid: String = "",

    /**
     * 自宅電話番号（下）
     */
    var phoneNumOneLast: String = "",

    /**
     * 事業先電話番号種別
     */
    var businessPhoneType: String = "",

    /**
     * 事業先電話番号（上）
     */
    var businessPhoneNumFirst: String = "",

    /**
     * 事業先電話番号（中）
     */
    var businessPhoneNumMid: String = "",

    /**
     * 事業先電話番号（下）
     */
    var businessPhoneNumLast: String = "",

    /**
     * 取引目的
     */
    var transactPurpose: String = "",

    /**
     * 取引目的（その他 ）
     */
    var transactPurposeOther: String = "",

    /**
     * 取引目的（詳細）
     */
    var transactPurposeDetail: String = "",

    /**
     * 職業事業内容
     */
    var businessDescription: String = "",

    /**
     * 職業事業内容（その他）
     */
    var businessDescriptionOther: String = "",

    /**
     * 取扱品目
     */
    var handingItem: String = "",

    /**
     * 主要取引先（仕入）
     */
    var mainlyTradePurchase: String = "",

    /**
     * 主要取引先（販売）
     */
    var mainlyTradeSale: String = "",

    /**
     * 当金庫との取引希望
     */
    var preferredTrade: String = "",

    /**
     * 当金庫との取引希望（その他）
     */
    var otherBusinessWishes: String = "",

    /**
     * 取引のきっかけ
     */
    var transactionTrigger: String = "",

    /**
     * 開設部店コード
     */
    var openBranchCode: String = "",

    /**
     * メールアドレス
     */
    var emailAddress: String = "",

    /**
     * 取引金融機関
     */
    var financialInstitution: String = "",

    /**
     * 取引金融機関（預金状況）
     */
    var financialInstitutionDepositStatus: String = "",

    /**
     * 取引金融機関（貸金状況）
     */
    var financialInstitutionLoanStatus: String = "",

    /**
     * 開設店番
     */
    var openBranchNumber: String = "",

    /**
     * 取引金融機関（貸金状況）
     */
    var identityDocuments: List<IdentityDocuments> = listOf(),

    /**
     * 本人確認書類URL
     */
    var identityVerificationDocumentsUrl: String = "",

    /**
     * 自宅郵便番号
     */
    var zipCode: String = "",

    /**
     * 自宅都道府県（半角カナ）
     */
    var prefectureKana: String = "",

    /**
     * 自宅都道府県
     */
    var prefecture: String = "",

    /**
     * 自宅市区町村（半角カナ）
     */
    var cityKana: String = "",

    /**
     * 自宅市区町村
     */
    var city: String = "",

    /**
     * 自宅丁目（半角カナ）
     */
    var addrDetail2Kana: String = "",

    /**
     * 自宅丁目
     */
    var addrDetail2: String = "",

    /**
     * 自宅番地（半角カナ）
     */
    var addrDetail3Kana: String = "",

    /**
     * 自宅番地（全角）
     */
    var addrDetail3: String = "",

    /**
     * 所在地都道府県（半角カナ）
     */
    var locationPrefectureKana: String = "",

    /**
     * 所在地都道府県
     */
    var locationPrefecture: String = "",
) : Parcelable {
    /**
     * API通信前のパラメータ処理
     * 番地にスペースを入れる
     */
    fun convertToParams(): SoleProprietorBean {
        return this.copy(
            homeAddress = this.homeAddress + if (this.homeBuilding.isBlank()) "" else FULL_SPACE,
            homeAddressKana = this.homeAddressKana + if (this.homeBuildingKana.isBlank()) "" else HALF_SPACE,
            locationAddress = this.locationAddress + if (this.buildingRoom.isBlank()) "" else FULL_SPACE,
            locationAddressKana = this.locationAddressKana + if (this.buildingRoomKana.isBlank()) "" else HALF_SPACE,
        )
    }
}

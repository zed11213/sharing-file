package jp.co.jsbank.mb.bankingapp.bean.common

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * お知らせ
 */
@Parcelize
data class RecoveryResponseBean(

    /**
     * 人格区分
     */
    var personType: String = "",

    /**
     * 画面ID
     */
    var screenId: String = "",

    /**
     * 口座開設申込情報（個人）
     */
    var individual: Individual = Individual(),

    /**
     * 口座開設申込情報（法人）
     */
    var corporation: CorporationBean = CorporationBean(),

    /**
     * 口座開設申込情報（個人事業主）
     */
    var soleProprietor: SoleProprietorBean = SoleProprietorBean(),

    /**
     * 生年月日
     */
    var birthday: String = "",

    /**
     * 番地
     */
    var addrDetail3: String = "",

    /**
     * 住所方書
     */
    var addressDetail: String = "",

    /**
     * 電話番号１
     */
    var phoneNumber1: String = "",

) : Parcelable

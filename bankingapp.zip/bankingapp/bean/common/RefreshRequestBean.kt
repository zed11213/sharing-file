package jp.co.jsbank.mb.bankingapp.bean.common

/**
 * リフレッシュリクエスト
 */
data class RefreshRequestBean(

    /**
     * 端末ID
     */
    var deviceId: String = "",

    /**
     * 個人向け/ JBA-INDV, 個人事業主/法人向け/ JBA-BIZZ.
     */
    var applicationId: String = "",

    /**
     * JBAID
     */
    var jbaId: String = "",

    /**
     * 利用者ID
     */
    var userId: String = "",

    /**
     * リフレッシュトークン
     */
    var refreshToken: String = "",

)

package jp.co.jsbank.mb.bankingapp.bean.common

import androidx.compose.runtime.Composable

/**
 * Bannerエンティティ.
 */
data class BannerBean(
    var imageId: Int,
    var content: @Composable () -> Unit
)

package jp.co.jsbank.mb.bankingapp.bean.common

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * JWT(BFF用)
 */
@Parcelize
data class BffJwtPayloadAuthTokenBean(

    /**
     * JBAID
     */
    var jbaIdToken: String = "",

    /**
     * USERID
     */
    var userIDToken: String = "",

    /**
     * アプリケーションID
     */
    var applicationID: String = "",

    /**
     * デバイスID
     */
    var deviceID: String = "",

    /**
     * バージョンID
     */
    var version: String = "",

    /**
     * OS
     */
    var os: String = "android",

    /**
     * アプリケーションID
     */
    var transactionID: String = "",

    /**
     * 画面Id
     */
    var screenID: String = "",

    /**
     * イベントID
     */
    var eventID: String = "",

) : Parcelable

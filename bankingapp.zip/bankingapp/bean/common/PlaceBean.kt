package jp.co.jsbank.mb.bankingapp.bean.common

/**
 * レスポンスベース
 */
data class PlaceBasicBean(
    var results: List<PlaceLatLngBean>?,
    var status: String,
)

data class PlaceLatLngBean(
    var types: List<String>? = null,
    var formatted_address: String? = null,
    var address_components: List<Address>? = null,
    var geometry: Geometry? = null
)

data class Address(
    var long_name: String? = null,
    var short_name: String? = null,
    var types: List<String>? = null,
)

data class Location(
    var lat: Double = 0.0,
    var lng: Double = 0.0
)

data class Viewport(
    var southwest: Location? = null,
    var northeast: Location? = null
)

data class Geometry(
    var location: Location? = null,
    var location_type: String? = null,
    var viewport: Viewport? = null
)

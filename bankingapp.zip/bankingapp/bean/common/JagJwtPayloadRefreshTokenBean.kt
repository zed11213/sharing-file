package jp.co.jsbank.mb.bankingapp.bean.common

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * JWT
 */
@Parcelize
data class JagJwtPayloadRefreshTokenBean(

    /**
     * JBAID
     */
    var jbaId: String = "",

    /**
     * USERID
     */
    var userId: String = "",

    /**
     * リフレッシュトークン
     */
    var refreshToken: String = "",

) : Parcelable

package jp.co.jsbank.mb.bankingapp.bean.common

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * 店舗リスト
 */
@Parcelize
data class AnncmntInfoBean(

    /**
     * お知らせID
     */
    var anncmntId: String = "",

    /**
     * お知らせステータス
     */
    var anncmntStatus: String = "04",

    /**
     * お知らせ種別コード
     */
    var anncmntType: String = "",

    /**
     * 文書種別コード
     */
    var documentType: String = "",

    /**
     * 申込ID
     */
    var applyId: String = "",
) : Parcelable

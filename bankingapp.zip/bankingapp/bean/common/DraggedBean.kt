package jp.co.jsbank.mb.bankingapp.bean.common

import androidx.compose.ui.graphics.Path

/**
 * ScratchCardエンティティ.
 */
data class DraggedPath(
    val path: Path,
    val width: Float = 50f
)

package jp.co.jsbank.mb.bankingapp.bean.common

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class IdentityDocuments(
    /**
     * 書類種類
     */
    var documentsType: String = "",

    /**
     * エンドポイント
     */
    var endPoint: String = "",

    /**
     * バケット
     */
    var bucket: String = "",

    /**
     * オブジェクトパス
     */
    var objectPath: String = "",

    /**
     * ファイル名
     */
    var fileName: String = "",

    /**
     * ファイル
     */
    var fileStream: String = "",
) : Parcelable

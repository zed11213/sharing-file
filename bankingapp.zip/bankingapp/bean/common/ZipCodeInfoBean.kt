package jp.co.jsbank.mb.bankingapp.bean.common

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * 郵便番号
 */
@Parcelize
data class ZipCodeInfoBean(

    /**
     * 郵便番号
     */
    var zipCode: String = "",
) : Parcelable

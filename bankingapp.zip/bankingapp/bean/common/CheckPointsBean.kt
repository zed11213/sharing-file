package jp.co.jsbank.mb.bankingapp.bean.common

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import jp.co.jsbank.mb.bankingapp.theme.H7

/**
 * 注意点
 */
data class CheckPointsBean(

    /**
     * アイコン
     */
    var icon: ImageVector = Icons.Default.Check,

    /**
     * アイコンの色
     */
    var iconColor: Color = Color(0xFFCE3F52),

    /**
     * アイコンのサイズ
     */
    var iconSize: Dp = 13.dp,

    /**
     * 内容
     */
    var content: String,

    /**
     * 内容のサイズ
     */
    var fontSize: TextUnit = H7
)

package jp.co.jsbank.mb.bankingapp.bean.common

import android.os.Parcelable
import jp.co.jsbank.mb.bankingapp.system.master.*
import kotlinx.parcelize.Parcelize

/**
 * DropDownリスト
 */
@Parcelize
data class CodeBean(

    /**
     * コード
     */
    var code: String = "",

    /**
     * 名称
     */
    var value: String = "",
) : Parcelable

/**
 * 取引目的リスト(個人).
 */
var individualTransactPurposeList: List<CodeBean> = listOf(
    CodeBean(
        TransactPurpose.LIVELIHOOD_EXPENSE_SETTLEMENT.code,
        TransactPurpose.LIVELIHOOD_EXPENSE_SETTLEMENT.value
    ),
    CodeBean(
        TransactPurpose.SALARY_PENSION.code,
        TransactPurpose.SALARY_PENSION.value
    ),
    CodeBean(
        TransactPurpose.SAVINGS_ASSET_MANAGEMENT.code,
        TransactPurpose.SAVINGS_ASSET_MANAGEMENT.value
    ),
    CodeBean(
        TransactPurpose.LOAN.code,
        TransactPurpose.LOAN.value
    ),
    CodeBean(
        TransactPurpose.OTHERS.code,
        TransactPurpose.OTHERS.value
    ),
)

/**
 * 取引目的リスト.
 */
var transactPurposeList: List<CodeBean> = listOf(
    CodeBean(
        TransactPurpose.LIVELIHOOD_EXPENSE_SETTLEMENT.code,
        TransactPurpose.LIVELIHOOD_EXPENSE_SETTLEMENT.value
    ),
    CodeBean(
        TransactPurpose.BUSINESS_EXPENSE_SETTLEMENT.code,
        TransactPurpose.BUSINESS_EXPENSE_SETTLEMENT.value
    ),
    CodeBean(
        TransactPurpose.SALARY_PENSION.code,
        TransactPurpose.SALARY_PENSION.value
    ),
    CodeBean(
        TransactPurpose.SAVINGS_ASSET_MANAGEMENT.code,
        TransactPurpose.SAVINGS_ASSET_MANAGEMENT.value
    ),
    CodeBean(
        TransactPurpose.LOAN.code,
        TransactPurpose.LOAN.value
    ),
    CodeBean(
        TransactPurpose.FOREX_TRADING.code,
        TransactPurpose.FOREX_TRADING.value
    ),
    CodeBean(
        TransactPurpose.OTHERS.code,
        TransactPurpose.OTHERS.value
    ),
)

/**
 * 取引目的リストBiz.
 */
var transactPurposeBizList: List<CodeBean> = listOf(
    CodeBean(
        TransactPurpose.BUSINESS_EXPENSE_SETTLEMENT.code,
        TransactPurpose.BUSINESS_EXPENSE_SETTLEMENT.value
    ),
    CodeBean(
        TransactPurpose.SAVINGS_ASSET_MANAGEMENT.code,
        TransactPurpose.SAVINGS_ASSET_MANAGEMENT.value
    ),
    CodeBean(
        TransactPurpose.LOAN.code,
        TransactPurpose.LOAN.value
    ),
    CodeBean(
        TransactPurpose.FOREX_TRADING.code,
        TransactPurpose.FOREX_TRADING.value
    ),
    CodeBean(
        TransactPurpose.OTHERS.code,
        TransactPurpose.OTHERS.value
    ),
)

/**
 * 職業リスト.
 */
var occupationList: List<CodeBean> = listOf(
    CodeBean(
        Occupation.COMPANY_GROUP_OFFICER.code,
        Occupation.COMPANY_GROUP_OFFICER.value
    ),
    CodeBean(
        Occupation.COMPANY_GROUP_EMPLOYEE.code,
        Occupation.COMPANY_GROUP_EMPLOYEE.value
    ),
    CodeBean(
        Occupation.CIVIL_SERVANT.code,
        Occupation.CIVIL_SERVANT.value
    ),
    CodeBean(
        Occupation.SELF_EMPLOYED.code,
        Occupation.SELF_EMPLOYED.value
    ),
    CodeBean(
        Occupation.PART_TEMPORARY_CONTRACT_EMPLOYEE.code,
        Occupation.PART_TEMPORARY_CONTRACT_EMPLOYEE.value
    ),
    CodeBean(
        Occupation.HOUSEWIFE_HOUSEHUSBAND.code,
        Occupation.HOUSEWIFE_HOUSEHUSBAND.value
    ),
    CodeBean(
        Occupation.STUDENT.code,
        Occupation.STUDENT.value
    ),
    CodeBean(
        Occupation.RETIRED_UNEMPLOYED.code,
        Occupation.RETIRED_UNEMPLOYED.value
    ),
    CodeBean(
        Occupation.OTHERS.code,
        Occupation.OTHERS.value
    ),
)

/**
 * 電話番号種別リスト.
 */
var phoneList: List<CodeBean> = listOf(
    CodeBean(
        Phone.FIXED_TELEPHONE.code,
        Phone.FIXED_TELEPHONE.value
    ),
    CodeBean(
        Phone.MOBILE_PHONE.code,
        Phone.MOBILE_PHONE.value
    ),// 2025/01/29 共同化ため電話番号の登録・表示　start
    CodeBean(
        Phone.IP_PHONE.code,
        Phone.IP_PHONE.value
    )
    // 2025/01/29 共同化ため電話番号の登録・表示　end
)

/**
 * 取引のきっかけリスト.
 */
var transactionTriggerList: List<CodeBean> = listOf(
    CodeBean(
        TransactionTrigger.SOLICITATION_BY_OUR_STAFF.code,
        TransactionTrigger.SOLICITATION_BY_OUR_STAFF.value
    ),
    CodeBean(
        TransactionTrigger.APP_STORE_SEARCH.code,
        TransactionTrigger.APP_STORE_SEARCH.value
    ),
    CodeBean(
        TransactionTrigger.THERE_IS_A_STORE_NEARBY.code,
        TransactionTrigger.THERE_IS_A_STORE_NEARBY.value
    ),
    CodeBean(
        TransactionTrigger.OUR_WEBSITE_AND_SNS.code,
        TransactionTrigger.OUR_WEBSITE_AND_SNS.value
    ),
    CodeBean(
        TransactionTrigger.FAMILY_FRIENDS_WORKPLACE_REFERRALS.code,
        TransactionTrigger.FAMILY_FRIENDS_WORKPLACE_REFERRALS.value
    ),
    CodeBean(
        TransactionTrigger.WATCH_NEWS_ON_TV.code,
        TransactionTrigger.WATCH_NEWS_ON_TV.value
    ),
    CodeBean(
        TransactionTrigger.OTHER.code,
        TransactionTrigger.OTHER.value
    )
)

/**
 * 口座リスト.
 */
var accountList: List<CodeBean> = listOf(
    CodeBean(
        AccountType.FIXED_SAVINGS.code,
        AccountType.FIXED_SAVINGS.value
    ),
    CodeBean(
        AccountType.INSTALLMENT.code,
        AccountType.INSTALLMENT.value
    )
)

/**
 * 本店所在地相違区分リスト（法人）.
 */
var headOfficeClassificationList: List<CodeBean> = listOf(
    CodeBean(
        HeadOfficeClassification.SAME_ADDRESS.code,
        HeadOfficeClassification.SAME_ADDRESS.value
    ),
    CodeBean(
        HeadOfficeClassification.DIFFERENT_ADDRESS.code,
        HeadOfficeClassification.DIFFERENT_ADDRESS.value
    )
)

/**
 * 本店所在地相違区分リスト（個人事業主）.
 */
var headOfficeClassificationIndividualBusinessList: List<CodeBean> = listOf(
    CodeBean(
        HeadOfficeClassificationIndividualBusiness.SAME_ADDRESS.code,
        HeadOfficeClassificationIndividualBusiness.SAME_ADDRESS.value
    ),
    CodeBean(
        HeadOfficeClassificationIndividualBusiness.DIFFERENT_ADDRESS.code,
        HeadOfficeClassificationIndividualBusiness.DIFFERENT_ADDRESS.value
    )
)

/**
 * 事業内容リスト.
 */
var businessDescriptionList: List<CodeBean> = listOf(
    CodeBean(
        BusinessDescription.AGRICULTURE_FORESTRY_FISHERIES.code,
        BusinessDescription.AGRICULTURE_FORESTRY_FISHERIES.value
    ),
    CodeBean(
        BusinessDescription.MANUFACTURING_INDUSTRY.code,
        BusinessDescription.MANUFACTURING_INDUSTRY.value
    ),
    CodeBean(
        BusinessDescription.CONSTRUCTION_INDUSTRY.code,
        BusinessDescription.CONSTRUCTION_INDUSTRY.value
    ),
    CodeBean(
        BusinessDescription.INFORMATION_COMMUNICATION_INDUSTRY.code,
        BusinessDescription.INFORMATION_COMMUNICATION_INDUSTRY.value
    ),
    CodeBean(
        BusinessDescription.TRANSPORTATION_INDUSTRY.code,
        BusinessDescription.TRANSPORTATION_INDUSTRY.value
    ),
    CodeBean(
        BusinessDescription.WHOLESALE_RETAIL_BUSINESS.code,
        BusinessDescription.WHOLESALE_RETAIL_BUSINESS.value
    ),
    CodeBean(
        BusinessDescription.FINANCE_INSURANCE.code,
        BusinessDescription.FINANCE_INSURANCE.value
    ),
    CodeBean(
        BusinessDescription.REAL_ESTATE_BUSINESS.code,
        BusinessDescription.REAL_ESTATE_BUSINESS.value
    ),
    CodeBean(
        BusinessDescription.SERVICE_INDUSTRY.code,
        BusinessDescription.SERVICE_INDUSTRY.value
    ),
    CodeBean(
        BusinessDescription.OTHERS.code,
        BusinessDescription.OTHERS.value
    )
)

/**
 * 当金庫との主な取引希望リスト.
 */
var preferredTradeList: List<CodeBean> = listOf(
    CodeBean(
        PreferredTrade.NORMAL.code,
        PreferredTrade.NORMAL.value
    ),
    CodeBean(
        PreferredTrade.CURRENT.code,
        PreferredTrade.CURRENT.value
    ),
    CodeBean(
        PreferredTrade.REGULAR.code,
        PreferredTrade.REGULAR.value
    ),
    CodeBean(
        PreferredTrade.ISOCHORIC_PROCESS.code,
        PreferredTrade.ISOCHORIC_PROCESS.value
    ),
    CodeBean(
        PreferredTrade.VIBRATION_SUPPLY.code,
        PreferredTrade.VIBRATION_SUPPLY.value
    ),
    CodeBean(
        PreferredTrade.LOAN.code,
        PreferredTrade.LOAN.value
    ),
    CodeBean(
        PreferredTrade.IB.code,
        PreferredTrade.IB.value
    ),
    CodeBean(
        PreferredTrade.OTHERS.code,
        PreferredTrade.OTHERS.value
    ),
)

/**
 * 会社形態リスト.
 */
var companyFormList: List<CodeBean> = listOf(
    CodeBean(
        CompanyForm.CORPORATION.code,
        CompanyForm.CORPORATION.value
    ),
    CodeBean(
        CompanyForm.LIMITED_COMPANY.code,
        CompanyForm.LIMITED_COMPANY.value
    ),
    CodeBean(
        CompanyForm.UNLIMITED_COMPANY.code,
        CompanyForm.UNLIMITED_COMPANY.value
    ),
    CodeBean(
        CompanyForm.JOINT_STOCK_COMPANY.code,
        CompanyForm.JOINT_STOCK_COMPANY.value
    ),
    CodeBean(
        CompanyForm.MUTUAL_COMPANY.code,
        CompanyForm.MUTUAL_COMPANY.value
    ),
    CodeBean(
        CompanyForm.GK.code,
        CompanyForm.GK.value
    ),
    CodeBean(
        CompanyForm.COOPERATIVE.code,
        CompanyForm.COOPERATIVE.value
    ),
    CodeBean(
        CompanyForm.FOUNDATION_CORPORATION.code,
        CompanyForm.FOUNDATION_CORPORATION.value
    ),
    CodeBean(
        CompanyForm.ASSOCIATION_CORPORATION.code,
        CompanyForm.ASSOCIATION_CORPORATION.value
    ),
    CodeBean(
        CompanyForm.RELIGIOUS_CORPORATION.code,
        CompanyForm.RELIGIOUS_CORPORATION.value
    ),
    CodeBean(
        CompanyForm.SCHOOL_CORPORATION.code,
        CompanyForm.SCHOOL_CORPORATION.value
    ),
    CodeBean(
        CompanyForm.MEDICAL_CORPORATION.code,
        CompanyForm.MEDICAL_CORPORATION.value
    ),
    CodeBean(
        CompanyForm.SOCIAL_WELFARE_CORPORATION.code,
        CompanyForm.SOCIAL_WELFARE_CORPORATION.value
    ),
    CodeBean(
        CompanyForm.OTHERS.code,
        CompanyForm.OTHERS.value
    )
)

/**
 * 会社形態位置リスト.
 */
var companyFormLocationList: List<CodeBean> = listOf(
    CodeBean(
        CompanyFormLocation.BEFORE.code,
        CompanyFormLocation.BEFORE.value
    ),
    CodeBean(
        CompanyFormLocation.AFTER.code,
        CompanyFormLocation.AFTER.value
    )
)

/**
 * ご役職リスト.
 */
var jobTitleList: List<CodeBean> = listOf(
    CodeBean(
        JobTitle.DIRECTOR.code,
        JobTitle.DIRECTOR.value
    ),
    CodeBean(
        JobTitle.OTHERS.code,
        JobTitle.OTHERS.value
    )
)

/**
 * 科目リスト.
 */
var subjectList: List<CodeBean> = listOf(
    CodeBean(
        Subject.ORDINARY_DEPOSIT.code,
        Subject.ORDINARY_DEPOSIT.value
    ),
    CodeBean(
        Subject.FIXED_SAVINGS.code,
        Subject.FIXED_SAVINGS.value
    ),
    CodeBean(
        Subject.INSTALLMENT.code,
        Subject.INSTALLMENT.value
    ),
    CodeBean(
        Subject.CHECKING_ACCOUNT.code,
        Subject.CHECKING_ACCOUNT.value
    ),
    CodeBean(
        Subject.DEPOSIT_DEPOSIT.code,
        Subject.DEPOSIT_DEPOSIT.value
    ),
    CodeBean(
        Subject.TAX_DEPOSIT.code,
        Subject.TAX_DEPOSIT.value
    )
)

/**
 * 預金種目(科目)リスト.
 */
var accountTypeList: List<CodeBean> = listOf(
    CodeBean(
        AccountType.ORDINARY_DEPOSIT.code,
        AccountType.ORDINARY_DEPOSIT.value
    ),
    CodeBean(
        AccountType.FIXED_SAVINGS.code,
        AccountType.FIXED_SAVINGS.value
    ),
    CodeBean(
        AccountType.INSTALLMENT.code,
        AccountType.INSTALLMENT.value
    ),
    CodeBean(
        AccountType.CHECKING_ACCOUNT.code,
        AccountType.CHECKING_ACCOUNT.value
    ),
    // 2025/01/16 共同化ため 通知預金による利用口座追加 削除　start
//    CodeBean(
//        AccountType.DEPOSIT_DEPOSIT.code,
//        AccountType.DEPOSIT_DEPOSIT.value
//    ),
    // 2025/01/16 共同化ため 通知預金による利用口座追加 削除　end
    CodeBean(
        AccountType.TAX_DEPOSIT.code,
        AccountType.TAX_DEPOSIT.value
    )
)

/**
 * 他の店舗をお選びいただく理由リスト.
 */
var anotherStoreOpenReasonList: List<CodeBean> = listOf(
    CodeBean(
        AnotherStoreOpenReason.SCHOOL.code,
        AnotherStoreOpenReason.SCHOOL.value
    ),
    CodeBean(
        AnotherStoreOpenReason.RENT_PARKING_FEE.code,
        AnotherStoreOpenReason.RENT_PARKING_FEE.value
    ),
    CodeBean(
        AnotherStoreOpenReason.WORK_PLACE.code,
        AnotherStoreOpenReason.WORK_PLACE.value
    ),
    CodeBean(
        AnotherStoreOpenReason.NEAREST_STORE.code,
        AnotherStoreOpenReason.NEAREST_STORE.value
    ),
    CodeBean(
        AnotherStoreOpenReason.OTHERS.code,
        AnotherStoreOpenReason.OTHERS.value
    ),
)
// 2025/01/23 共同化ため リスク格付け対応　start
/**
 * 業種リスト.
 */
var categoryCodeList: List<CodeBean> = listOf(
    CodeBean(
        CategoryCode.CATERING_INDUSTRY.code,
        CategoryCode.CATERING_INDUSTRY.value
    ),
    CodeBean(
        CategoryCode.DOCTORS_HOSPITALS_MEDICAL_INSTITUTIONS.code,
        CategoryCode.DOCTORS_HOSPITALS_MEDICAL_INSTITUTIONS.value
    ),
    CodeBean(
        CategoryCode.TRANSPORTATION.code,
        CategoryCode.TRANSPORTATION.value
    ),
    CodeBean(
        CategoryCode.WHOLESALE.code,
        CategoryCode.WHOLESALE.value
    ),
    CodeBean(
        CategoryCode.MONEY_LENDING_BUSINESS.code,
        CategoryCode.MONEY_LENDING_BUSINESS.value
    ),
    CodeBean(
        CategoryCode.VIRTUAL_CURRENCY_EXCHANGE_BUSINESS.code,
        CategoryCode.VIRTUAL_CURRENCY_EXCHANGE_BUSINESS.value
    ),
    CodeBean(
        CategoryCode.FINANCIAL_TRUST_BUSINESS.code,
        CategoryCode.FINANCIAL_TRUST_BUSINESS.value
    ),
    CodeBean(
        CategoryCode.FINANCIAL_PRODUCTS_COMMODITY_FUTURES_TRADING_BUSINESS.code,
        CategoryCode.FINANCIAL_PRODUCTS_COMMODITY_FUTURES_TRADING_BUSINESS.value
    ),
    CodeBean(
        CategoryCode.CONSTRUCTION.code,
        CategoryCode.CONSTRUCTION.value
    ),
    CodeBean(
        CategoryCode.RETAIL_TRADE.code,
        CategoryCode.RETAIL_TRADE.value
    ),
    CodeBean(
        CategoryCode.CONSULTING_BUSINESS.code,
        CategoryCode.CONSULTING_BUSINESS.value
    ),
    CodeBean(
        CategoryCode.CREDIT_CARD_BUSINESS.code,
        CategoryCode.CREDIT_CARD_BUSINESS.value
    ),
    CodeBean(
        CategoryCode.SERVICE_INDUSTRY.code,
        CategoryCode.SERVICE_INDUSTRY.value
    ),
    CodeBean(
        CategoryCode.FUNDS_TRANSFER_BUSINESS_COLLECTION_AGENCY_BUSINESS.code,
        CategoryCode.FUNDS_TRANSFER_BUSINESS_COLLECTION_AGENCY_BUSINESS.value
    ),
    CodeBean(
        CategoryCode.INFORMATION_COMMUNICATIONS.code,
        CategoryCode.INFORMATION_COMMUNICATIONS.value
    ),
    CodeBean(
        CategoryCode.MANUFACTURING.code,
        CategoryCode.MANUFACTURING.value
    ),
    CodeBean(
        CategoryCode.REAL_ESTATE_BUSINESS.code,
        CategoryCode.REAL_ESTATE_BUSINESS.value
    ),
    CodeBean(
        CategoryCode.CALL_FORWARDING_SERVICES.code,
        CategoryCode.CALL_FORWARDING_SERVICES.value
    ),
    CodeBean(
        CategoryCode.TELEPHONE_RECEPTION_SERVICE.code,
        CategoryCode.TELEPHONE_RECEPTION_SERVICE.value
    ),
    CodeBean(
        CategoryCode.ELECTRONIC_MONETARY_CLAIMS_RECORDING_AGENCY.code,
        CategoryCode.ELECTRONIC_MONETARY_CLAIMS_RECORDING_AGENCY.value
    ),
    CodeBean(
        CategoryCode.INVESTMENT_BUSINESS.code,
        CategoryCode.INVESTMENT_BUSINESS.value
    ),
    CodeBean(
        CategoryCode.AGRICULTURE.code,
        CategoryCode.AGRICULTURE.value
    ),
    CodeBean(
        CategoryCode.FORESTRY.code,
        CategoryCode.FORESTRY.value
    ),
    CodeBean(
        CategoryCode.FISHERIES.code,
        CategoryCode.FISHERIES.value
    ),
    CodeBean(
        CategoryCode.REAL_ESTATE_RENTAL_BUSINESS.code,
        CategoryCode.REAL_ESTATE_RENTAL_BUSINESS.value
    ),
    CodeBean(
        CategoryCode.FINANCE_LEASE_BUSINESS.code,
        CategoryCode.FINANCE_LEASE_BUSINESS.value
    ),
    CodeBean(
        CategoryCode.LAWYERS_LAW_LFIRMS.code,
        CategoryCode.LAWYERS_LAW_LFIRMS.value
    ),
    CodeBean(
        CategoryCode.JUDICIAL_SCRIVENER_JUDICIAL_SCRIVENER_ORPORATION.code,
        CategoryCode.JUDICIAL_SCRIVENER_JUDICIAL_SCRIVENER_ORPORATION.value
    ),
    CodeBean(
        CategoryCode.ADMINISTRATIVE_SCRIVENER_CORPORATION.code,
        CategoryCode.ADMINISTRATIVE_SCRIVENER_CORPORATION.value
    ),
    CodeBean(
        CategoryCode.CERTIFIED_PUBLIC_ACCOUNTANTS_AUDIT_CORPORATIONS.code,
        CategoryCode.CERTIFIED_PUBLIC_ACCOUNTANTS_AUDIT_CORPORATIONS.value
    ),
    CodeBean(
        CategoryCode.TAX_ACCOUNTANT_TAX_ACCOUNTANT_CORPORATION.code,
        CategoryCode.TAX_ACCOUNTANT_TAX_ACCOUNTANT_CORPORATION.value
    ),
    CodeBean(
        CategoryCode.JEWELRY_PRECIOUS_METALS_BUSINESS.code,
        CategoryCode.JEWELRY_PRECIOUS_METALS_BUSINESS.value
    ),
    CodeBean(
        CategoryCode.INSURANCE.code,
        CategoryCode.INSURANCE.value
    ),
    CodeBean(
        CategoryCode.PREPAID_PAYMENT_INSTRUMENT_ISSUERS.code,
        CategoryCode.PREPAID_PAYMENT_INSTRUMENT_ISSUERS.value
    ),
    CodeBean(
        CategoryCode.MAIL_RECEIVING_SERVICE_BUSINESS.code,
        CategoryCode.MAIL_RECEIVING_SERVICE_BUSINESS.value
    ),
    CodeBean(
        CategoryCode.DEPOSIT_TAKING_FINANCIAL_SERVICES.code,
        CategoryCode.DEPOSIT_TAKING_FINANCIAL_SERVICES.value
    ),
    CodeBean(
        CategoryCode.CURRENCY_EXCHANGE_BUSINESS.code,
        CategoryCode.CURRENCY_EXCHANGE_BUSINESS.value
    ),
    CodeBean(
        CategoryCode.OTHERS.code,
        CategoryCode.OTHERS.value
    ),
)
// 2025/01/23 共同化ため リスク格付け対応　end
// 2025/01/23 共同化ため マネロン対応対応　start
/**
 * 取引原資（名称）
 */
var transOriginalCapitalNameList: List<CodeBean> = listOf(
    CodeBean(
        TransOriginalCapitalNameList.SALARY.code,
        TransOriginalCapitalNameList.SALARY.value
    ),
    CodeBean(
        TransOriginalCapitalNameList.PENSION.code,
        TransOriginalCapitalNameList.PENSION.value
    ),
    CodeBean(
        TransOriginalCapitalNameList.SAVINGS.code,
        TransOriginalCapitalNameList.SAVINGS.value
    ),
    CodeBean(
        TransOriginalCapitalNameList.RENTAL_INCOME_ETC.code,
        TransOriginalCapitalNameList.RENTAL_INCOME_ETC.value
    ),
    CodeBean(
        TransOriginalCapitalNameList.SALES_BUSINESS_INCOME.code,
        TransOriginalCapitalNameList.SALES_BUSINESS_INCOME.value
    ),
    CodeBean(
        TransOriginalCapitalNameList.INVESTMENT_INCOME.code,
        TransOriginalCapitalNameList.INVESTMENT_INCOME.value
    ),
    CodeBean(
        TransOriginalCapitalNameList.ASSET_SALE_PROCEEDS.code,
        TransOriginalCapitalNameList.ASSET_SALE_PROCEEDS.value
    ),
    CodeBean(
        TransOriginalCapitalNameList.OTHERS.code,
        TransOriginalCapitalNameList.OTHERS.value
    ),
)
/**
 * 毎月の取引金額
 */
var monthlyTransAmountNameList: List<CodeBean> = listOf(
    CodeBean(
        MonthlyTransAmountNameList.UNDER_10000_YEN.code,
        MonthlyTransAmountNameList.UNDER_10000_YEN.value
    ),
    CodeBean(
        MonthlyTransAmountNameList.OVER_10000_YEN_TO_UNDER_50000_YEN.code,
        MonthlyTransAmountNameList.OVER_10000_YEN_TO_UNDER_50000_YEN.value
    ),
    CodeBean(
        MonthlyTransAmountNameList.OVER_50000_YEN_TO_UNDER_100000_YEN.code,
        MonthlyTransAmountNameList.OVER_50000_YEN_TO_UNDER_100000_YEN.value
    ),
    CodeBean(
        MonthlyTransAmountNameList.OVER_100000_YEN_TO_UNDER_500000_YEN.code,
        MonthlyTransAmountNameList.OVER_100000_YEN_TO_UNDER_500000_YEN.value
    ),
    CodeBean(
        MonthlyTransAmountNameList.OVER_500000_YEN_TO_UNDER_1000000_YEN.code,
        MonthlyTransAmountNameList.OVER_500000_YEN_TO_UNDER_1000000_YEN.value
    ),
    CodeBean(
        MonthlyTransAmountNameList.OVER_1_MILLION_YEN_TO_UNDER_5_MILLION_YEN.code,
        MonthlyTransAmountNameList.OVER_1_MILLION_YEN_TO_UNDER_5_MILLION_YEN.value
    ),
    CodeBean(
        MonthlyTransAmountNameList.OVER_5_MILLION_YEN_TO_UNDER_10_MILLION_YEN.code,
        MonthlyTransAmountNameList.OVER_5_MILLION_YEN_TO_UNDER_10_MILLION_YEN.value
    ),
    CodeBean(
        MonthlyTransAmountNameList.OVER_10_MILLION_YEN.code,
        MonthlyTransAmountNameList.OVER_10_MILLION_YEN.value
    ),
)

/**
 * 取引頻度
 */
var transFrequencyNameList: List<CodeBean> = listOf(
    CodeBean(
        TransFrequencyNameList.MORE_THAN_THREE_TIMES_A_WEEK.code,
        TransFrequencyNameList.MORE_THAN_THREE_TIMES_A_WEEK.value
    ),
    CodeBean(
        TransFrequencyNameList.ONCE_A_WEEK.code,
        TransFrequencyNameList.ONCE_A_WEEK.value
    ),
    CodeBean(
        TransFrequencyNameList.ONCE_EVERY_2_3_WEEKS.code,
        TransFrequencyNameList.ONCE_EVERY_2_3_WEEKS.value
    ),
    CodeBean(
        TransFrequencyNameList.ONCE_A_MONTH.code,
        TransFrequencyNameList.ONCE_A_MONTH.value
    ),
    CodeBean(
        TransFrequencyNameList.ONCE_EVERY_2_3_MONTHS.code,
        TransFrequencyNameList.ONCE_EVERY_2_3_MONTHS.value
    ),
    CodeBean(
        TransFrequencyNameList.ONCE_EVERY_SIX_MONTHS.code,
        TransFrequencyNameList.ONCE_EVERY_SIX_MONTHS.value
    ),
    CodeBean(
        TransFrequencyNameList.LESS_THAN_ONCE_A_YEAR.code,
        TransFrequencyNameList.LESS_THAN_ONCE_A_YEAR.value
    ),
)

/**
 * ２００万円超の現金取引予定
 */
var twoMillionMoreCashTransScheduledList: List<CodeBean> = listOf(
    CodeBean(
        TwoMillionMoreCashTransScheduled.PLANNED.code,
        TwoMillionMoreCashTransScheduled.PLANNED.value
    ),
    CodeBean(
        TwoMillionMoreCashTransScheduled.NOT_SCHEDULED.code,
        TwoMillionMoreCashTransScheduled.NOT_SCHEDULED.value
    ),
)

/**
 * ２００万超取引頻度
 */
var twoMillionMoreTransFrequencyNameList: List<CodeBean> = listOf(
    CodeBean(
        TwoMillionMoreTransFrequencyName.MORE_THAN_THREE_TIMES_A_WEEK.code,
        TwoMillionMoreTransFrequencyName.MORE_THAN_THREE_TIMES_A_WEEK.value
    ),
    CodeBean(
        TwoMillionMoreTransFrequencyName.ONCE_A_WEEK.code,
        TwoMillionMoreTransFrequencyName.ONCE_A_WEEK.value
    ),
    CodeBean(
        TwoMillionMoreTransFrequencyName.ONCE_EVERY_2_3_WEEKS.code,
        TwoMillionMoreTransFrequencyName.ONCE_EVERY_2_3_WEEKS.value
    ),
    CodeBean(
        TwoMillionMoreTransFrequencyName.ONCE_A_MONTH.code,
        TwoMillionMoreTransFrequencyName.ONCE_A_MONTH.value
    ),
    CodeBean(
        TwoMillionMoreTransFrequencyName.ONCE_EVERY_2_3_MONTHS.code,
        TwoMillionMoreTransFrequencyName.ONCE_EVERY_2_3_MONTHS.value
    ),
    CodeBean(
        TwoMillionMoreTransFrequencyName.ONCE_EVERY_SIX_MONTHS.code,
        TwoMillionMoreTransFrequencyName.ONCE_EVERY_SIX_MONTHS.value
    ),
    CodeBean(
        TwoMillionMoreTransFrequencyName.LESS_THAN_ONCE_A_YEAR.code,
        TwoMillionMoreTransFrequencyName.LESS_THAN_ONCE_A_YEAR.value
    ),
)

/**
 * ２００万超取引金額
 */
var twoMillionMoreTransAmountNameList: List<CodeBean> = listOf(
    CodeBean(
        TwoMillionMoreTransAmountName.OVER_2_MILLION_YEN_TO_UNDER_3_MILLION_YEN.code,
        TwoMillionMoreTransAmountName.OVER_2_MILLION_YEN_TO_UNDER_3_MILLION_YEN.value
    ),
    CodeBean(
        TwoMillionMoreTransAmountName.OVER_3_MILLION_YEN_TO_UNDER_5_MILLION_YEN.code,
        TwoMillionMoreTransAmountName.OVER_3_MILLION_YEN_TO_UNDER_5_MILLION_YEN.value
    ),
    CodeBean(
        TwoMillionMoreTransAmountName.OVER_5_MILLION_YEN_TO_UNDER_10_MILLION_YEN.code,
        TwoMillionMoreTransAmountName.OVER_5_MILLION_YEN_TO_UNDER_10_MILLION_YEN.value
    ),
    CodeBean(
        TwoMillionMoreTransAmountName.OVER_10_MILLION_YEN.code,
        TwoMillionMoreTransAmountName.OVER_10_MILLION_YEN.value
    ),
)

/**
 * 業務内容（名称）
 */
var businessContentNameList: List<CodeBean> = listOf(
    CodeBean(
        BusinessContentName.SALES.code,
        BusinessContentName.SALES.value
    ),
    CodeBean(
        BusinessContentName.GENERAL_AFFAIRS.code,
        BusinessContentName.GENERAL_AFFAIRS.value
    ),
    CodeBean(
        BusinessContentName.GENERAL_AFFAIRS_ACCOUNTING.code,
        BusinessContentName.GENERAL_AFFAIRS_ACCOUNTING.value
    ),
    CodeBean(
        BusinessContentName.PLANNING_AND_MANAGEMENT.code,
        BusinessContentName.PLANNING_AND_MANAGEMENT.value
    ),
    CodeBean(
        BusinessContentName.MANUFACTURING_AND_DEVELOPMENT.code,
        BusinessContentName.MANUFACTURING_AND_DEVELOPMENT.value
    ),
    CodeBean(
        BusinessContentName.OTHERS.code,
        BusinessContentName.OTHERS.value
    ),
)

/**
 * 上場／非上場
 */
var playOrNotPlayList: List<CodeBean> = listOf(
    CodeBean(
        PlayOrNotPlay.PLAY.code,
        PlayOrNotPlay.PLAY.value
    ),
    CodeBean(
        PlayOrNotPlay.NOT_PLAY.code,
        PlayOrNotPlay.NOT_PLAY.value
    ),
    CodeBean(
        PlayOrNotPlay.OTHER_THAN_A_CORPORATION.code,
        PlayOrNotPlay.OTHER_THAN_A_CORPORATION.value
    ),
)

/**
 * 役職（名称）
 */
var pstnNameList: List<CodeBean> = listOf(
    CodeBean(
        PstnName.REPRESENTATIVE.code,
        PstnName.REPRESENTATIVE.value
    ),
    CodeBean(
        PstnName.BOARD_MEMBER.code,
        PstnName.BOARD_MEMBER.value
    ),
    CodeBean(
        PstnName.MANAGER.code,
        PstnName.MANAGER.value
    ),
    CodeBean(
        PstnName.GENERAL_STAFF.code,
        PstnName.GENERAL_STAFF.value
    ),
    CodeBean(
        PstnName.OTHERS.code,
        PstnName.OTHERS.value
    ),
)
// 2025/01/23 共同化ため マネロン対応対応　end

package jp.co.jsbank.mb.bankingapp.bean.common

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * 郵便番号
 */
@Parcelize
data class PostCodeRequestBean(

    /**
     * 郵便番号
     */
    var postalCode: String = "",
) : Parcelable

@Parcelize
data class PostCodeResponseBean(

    /**
     * 地区コード
     */
    var addressCode: String = "",

    /**
     * 都道府県
     */
    var prefecture: String = "",

    /**
     * 市区町村
     */
    var city: String = "",

    /**
     * 町漢字
     */
    var addrDetail1: String = "",

    /**
     * 丁目
     */
    var addrDetail2: String = "",

    /**
     * 都道府県（半角カナ）
     */
    var prefectureKana: String = "",

    /**
     * 市区町村（半角カナ）
     */
    var cityKana: String = "",

    /**
     * 町カナ
     */
    var addrdetail1Kana: String = "",

    /**
     * 丁目（半角）
     */
    var addrdetail2Kana: String = "",

    /**
     * 郵便番号
     */
    var zipCode: String = "",

    /**
     * 住所漢字
     */
    var address: String = "",

    /**
     * 住所カナ
     */
    var addressKana: String = "",

    /**
     * 住所漢字丁目なし
     */
    var addressNashi: String = "",

    /**
     * 住所カナ丁目なし
     */
    var addressKanaNashi: String = "",
) : Parcelable

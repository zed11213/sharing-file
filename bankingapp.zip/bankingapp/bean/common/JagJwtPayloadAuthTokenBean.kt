package jp.co.jsbank.mb.bankingapp.bean.common

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * JWT
 */
@Parcelize
data class JagJwtPayloadAuthTokenBean(

    /**
     * JBAID
     */
    var jbaId: String = "",

    /**
     * USERID
     */
    var userId: String = "",

    /**
     * チャレンジトークン
     */
    var challengeToken: String = "",

) : Parcelable

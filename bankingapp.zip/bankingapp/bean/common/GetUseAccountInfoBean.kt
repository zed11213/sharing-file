package jp.co.jsbank.mb.bankingapp.bean.common

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * 店舗リスト
 */
@Parcelize
data class GetUseAccountInfoBean(

    /**
     * 店番
     */
    var branchCode: String = "",

    /**
     * 口座番号
     */
    var accountNumber: String = "",

    /**
     * 預金種目
     */
    var accountType: String = "",

    /**
     * 口座番号Sub
     */
    var accountSubNumber: String = "",
) : Parcelable

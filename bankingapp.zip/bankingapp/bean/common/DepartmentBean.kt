package jp.co.jsbank.mb.bankingapp.bean.common

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

/**
 * 店舗リスト
 */
@Parcelize
data class DepartmentBean(

    /**
     * 店舗コード
     */
    var branchNumber: String = "",

    /**
     * 店舗名称
     */
    var branchKanjiName: String = "",
) : Parcelable

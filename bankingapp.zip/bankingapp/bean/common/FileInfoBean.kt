package jp.co.jsbank.mb.bankingapp.bean.common;


import android.os.Parcelable
import kotlinx.parcelize.Parcelize


/**
 * ファイル情報
 */
@Parcelize
data class FileInfoBean(

        /**
         * 書類種類
         */
        var documentsType: String = "",

        /**
         * ファイル名
         */
        var fileName: String = "",

        /**
         * ファイルストリーム(base64)
         */
        var fileStream: String = "",
        ) : Parcelable


package jp.co.jsbank.mb.bankingapp.bean.main.balance

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * 収支情報
 *
 */
@Parcelize
data class BalanceResponseBean(

    /**
     * 収支年月
     */
    var balanceMonth: String = "",

    /**
     * 入金額
     */
    var depositAmount: String = "0",

    /**
     * 出金額
     */
    var investedAmount: String = "0",

    /**
     * 残高
     */
    var monthlyBalance: String = "0",
) : Parcelable

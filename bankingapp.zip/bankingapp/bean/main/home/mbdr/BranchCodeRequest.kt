package jp.co.jsbank.mb.bankingapp.bean.main.home.mbdr

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class BranchCodeRequest (
    var branchCode: String
) : Parcelable

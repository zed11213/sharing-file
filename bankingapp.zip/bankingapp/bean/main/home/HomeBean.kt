package jp.co.jsbank.mb.bankingapp.bean.main.home

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class BalanceInformation(
    // CIF番号
    var cifNumber: String = "",
    // 店番
    var branchNumber: String = "",
    // 支店名
    var branchName: String = "",
    // 科目コード
    var subjectNameCode: String = "",
    // 科目名
    var subjectNameValue: String = "",
    // 口座番号
    var accountNumber: String = "",
    // 残高
    var balance: String = "",
    // 毎残高の合計
    var balanceTotal: String = "",
    // 支払可能残高
    var fundingBalance: String = "",
    // 定期残高
    var regularBalance: String = "",
    // 選択フラグ
    var selected: Boolean = false,
    // 選択の口座
    var topSelected: Boolean = false,
    // 総合口座フラグ
    var generalAccountFlag: String = "",
    // 総合口座リンク先-預金種目
    var linkedAccountType: String = "",
    // 総合口座リンク先-店番
    var linkedBranchNumber: String = "",
    // 総合口座リンク先-口座番号
    var linkedAccountNumber: String = "",
    // 総合口座リンク先-サブNo
    var linkedSubNumber: String = "",
    // 預金種目
    var accountType: String = "",
    // 解約フラグ
    var dissolutionFlg: String = "0",
) : Parcelable

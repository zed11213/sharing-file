package jp.co.jsbank.mb.bankingapp.bean.main.home.mblg

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * ログイン日時
 */
@Parcelize
data class MBLG0101ResponseBean(

    /**
     * ログイン日時
     */
    var loginTs: String = "",

    /**
     * 通知Token作成フラグ「0：作成必要」
     */
    var tokenFlg: String = "",
) : Parcelable

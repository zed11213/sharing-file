package jp.co.jsbank.mb.bankingapp.bean.login.mbsu.mbsu0301

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * MBSU0301リクエストエンティティ.
 */
@Parcelize
data class MBSU0301RequestBean(

    /**
     * 店番
     */
    var shopId: String = "",
    /**
     * 口座番号
     */
    var accountNumber: String = "",
    /**
     * 姓
     */
    var firstName: String = "",
    /**
     * 名前
     */
    var secondName: String = "",
    /**
     * 年
     */
    var year: String = "",
    /**
     * 月
     */
    var month: String = "",
    /**
     * 日
     */
    var day: String = "",
    /**
     * 郵便番号
     */
    var postCode: String = "",
    /**
     * キャッシュカード暗証番号
     */
    var cashCardPassword: String = "",
) : Parcelable

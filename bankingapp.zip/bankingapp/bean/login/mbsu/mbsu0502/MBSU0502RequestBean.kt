package jp.co.jsbank.mb.bankingapp.bean.login.mbsu.mbsu0502

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * MBSU0502リクエストエンティティ.
 */
@Parcelize
data class MBSU0502RequestBean(

    /**
     * メールアドレス
     */
    var emailAddress: String = "",

    /**
     * メールOTP
     */
    var mailOtp: String = "",

    /**
     * 依頼番号
     */
    var requestNo: String = "",

    /**
     * CIF番号
     */
    var cifNumber: String = "",

    /**
     * 受付番号
     */
    var receiptNumber: String = "",

    /**
     * 認証TRXキー
     */
    var authCode: String = "",

    /**
     * 人格区分
     */
    var personType: String = "",

    /**
     * 更新パターン
     */
    var updateType: String = "",
) : Parcelable

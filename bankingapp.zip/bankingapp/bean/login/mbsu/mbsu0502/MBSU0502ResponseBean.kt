package jp.co.jsbank.mb.bankingapp.bean.login.mbsu.mbsu0502

/**
 * MBSU0502レスポンスエンティティ.
 */
data class MBSU0502ResponseBean(

    /**
     * バンキングIDトークン.
     */
    var phoneNumberList: List<String> = listOf(),
)

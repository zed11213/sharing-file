package jp.co.jsbank.mb.bankingapp.bean.login.mbsu.mbsu0601

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * MBSU0601リクエストエンティティ.
 */
@Parcelize
data class MBSU0601RequestBean(
    /**
     * 人格区分.
     */
    var personType: String = "",

    /**
     * 電話番号.
     */
    var phoneNumber: String = "",

    /**
     * 更新パターン
     */
    var updateType: String = "",

    /**
     * CIF番号
     */
    var cifNumber: String = "",

    /**
     * 店番
     */
    var branchNumber: String = "",

    /**
     * 依頼番号
     */
    var requestNo: String = "",
) : Parcelable

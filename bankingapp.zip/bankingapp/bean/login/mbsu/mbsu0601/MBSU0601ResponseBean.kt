package jp.co.jsbank.mb.bankingapp.bean.login.mbsu.mbsu0601

/**
 * MBSU0601レスポンスエンティティ.
 */
data class MBSU0601ResponseBean(
    /**
     * IVRスキップフラグ「1：スキップ、0：スキップしない」.
     */
    var ivrSkipFlag: String = "",

    /**
     * 利用者IDトークン.
     */
    var userIdToken: String = "",

    /**
     * 顧客IDトークン.
     */
    var customerIdToken: String = "",
)

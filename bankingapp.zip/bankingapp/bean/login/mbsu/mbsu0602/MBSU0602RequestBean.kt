package jp.co.jsbank.mb.bankingapp.bean.login.mbsu.mbsu0602

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * MBSU0602リクエストエンティティ.
 */
@Parcelize
data class MBSU0602RequestBean(
    /**
     * 受付番号.
     */
    var receiptNumber: String = "",

    /**
     * 電話番号.
     */
    var phoneNumber: String = "",

    /**
     * IVROTP.
     */
    var ivrOtp: String = "",

    /**
     * 依頼番号.
     */
    var requestNo: String = "",

    /**
     * 人格区分.
     */
    var personType: String = "",

    /**
     * 更新パターン
     */
    var updateType: String = "",

) : Parcelable

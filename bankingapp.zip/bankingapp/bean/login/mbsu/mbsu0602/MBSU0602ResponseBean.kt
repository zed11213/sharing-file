package jp.co.jsbank.mb.bankingapp.bean.login.mbsu.mbsu0602

/**
 * MBSU0502レスポンスエンティティ.
 */
data class MBSU0602ResponseBean(

    /**
     * 認証結果.
     */
    var authenticationResult: String = "",

    /**
     * 顧客ID.
     */
    var customerId: String = "",

    /**
     * 利用者ID.
     */
    var userId: String = "",
)

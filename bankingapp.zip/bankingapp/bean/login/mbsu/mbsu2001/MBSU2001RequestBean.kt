package jp.co.jsbank.mb.bankingapp.bean.login.mbsu.mbsu2001

/**
 * MBSU2001リクエストエンティティ.
 */
data class MBSU2001RequestBean(
    /**
     * 引継ぎコード.
     */
    var takeoverCode: String = "",
)

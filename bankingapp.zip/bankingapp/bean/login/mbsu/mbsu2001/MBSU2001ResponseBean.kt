package jp.co.jsbank.mb.bankingapp.bean.login.mbsu.mbsu2001

/**
 * MBSU2001レスポンスエンティティ.
 */
data class MBSU2001ResponseBean(
    /**
     * バンキングIDトークン.
     */
    var jbaIdToken: String = "",

    /**
     * 利用者IDトークン.
     */
    var userIdToken: String = "",
)

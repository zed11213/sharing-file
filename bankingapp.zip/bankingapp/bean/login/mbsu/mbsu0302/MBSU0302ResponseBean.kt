package jp.co.jsbank.mb.bankingapp.bean.login.mbsu.mbsu0302

/**
 * MBSU0302レスポンスエンティティ.
 */
data class MBSU0302ResponseBean(
    /**
     * 顧客ID.
     */
    var customerId: String = "",

    /**
     * 利用者ID.
     */
    var userId: String = "",

    /**
     * 依頼番号.
     */
    var requestNo: String = "",

    /**
     * CIF番号.
     */
    var cifNo: String = "",

    /**
     * 本人カード仮発行.
     */
    var cardDummyIssue: String = "",
)

package jp.co.jsbank.mb.bankingapp.bean.login.mbsu.mbsu0302

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * MBSU0302リクエストエンティティ.
 */
@Parcelize
data class MBSU0302RequestBean(
    /**
     * 本人区分
     */
    var personType: String = "",

    /**
     * 利用者区分
     */
    var userType: String = "",

    /**
     * 店番
     */
    var branchCode: String = "",

    /**
     * 口座番号
     */
    var accountNumber: String = "",

    /**
     * カナ氏名（姓）
     */
    var customerLastName: String = "",

    /**
     * カナ氏名（名）
     */
    var customerFirstName: String = "",

    /**
     * 漢字氏名（姓）
     */
    var customerKanjiLastName: String = "",

    /**
     * 漢字氏名（名）
     */
    var customerKanjiFirstName: String = "",

    /**
     * 生年月日
     */
    var birthDay: String = "",

    /**
     * 郵便番号
     */
    var zipCode: String = "",

    /**
     * 暗証番号
     */
    var ccPinCode: String = "",

    /**
     * 所属
     */
    var divisionCode: String = "",

    /**
     * 認証キー
     */
    var authCode: String = "",

    /**
     * デバイスID(プッシュ通知)
     */
    var deviceId: String = "",

) : Parcelable

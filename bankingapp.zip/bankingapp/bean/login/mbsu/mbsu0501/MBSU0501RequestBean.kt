package jp.co.jsbank.mb.bankingapp.bean.login.mbsu.mbsu0501

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * MBSU0501リクエストエンティティ.
 */
@Parcelize
data class MBSU0501RequestBean(

    /**
     * 更新パターン（0：新規　１：更新）
     */
    var updateType: String = "",

    /**
     * メールアドレス
     */
    var emailAddress: String = "",

    /**
     * 人格区分
     */
    var personType: String = "",
) : Parcelable

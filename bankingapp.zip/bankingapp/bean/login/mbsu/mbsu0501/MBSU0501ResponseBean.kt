package jp.co.jsbank.mb.bankingapp.bean.login.mbsu.mbsu0501

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * MBSU0501レスポンスエンティティ.
 */
@Parcelize
data class MBSU0501ResponseBean(

    /**
     * トランザクションコード
     */
    var transactionCode: String = "",
) : Parcelable

/**
 * MBSU0502渡すパラメータ.
 */
@Parcelize
data class MBSU0502Param(

    /**
     * メールアドレス
     */
    var emailAddress: String = "",

    /**
     * トランザクションコード
     */
    var transactionCode: String = "",
) : Parcelable

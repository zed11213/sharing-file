package jp.co.jsbank.mb.bankingapp.bean.login.mbsu.mbsu0102

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import jp.co.jsbank.mb.bankingapp.theme.H6
import jp.co.jsbank.mb.bankingapp.theme.H7
import jp.co.jsbank.mb.bankingapp.theme.text_color

data class CardBean(

    /**
     * アイコン
     */
    var icon: Painter,

    /**
     * アイコンの色
     */
    var iconColor: Color = Color.Red,

    /**
     * アイコンのサイズ
     */
    var iconSize: Dp = 20.dp,

    /**
     * タイトル
     */
    var title: String,

    /**
     * 内容
     */
    var content: String = "",

    /**
     * 内容
     */
    var contentSize: TextUnit = H7,

    /**
     * 内容
     */
    var contentColor: Color = text_color,

    /**
     * 内容のサイズ
     */
    var fontSize: TextUnit = H6
)

package jp.co.jsbank.mb.bankingapp.bean.login.mblg.mblg0302

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * MBLG0302リクエストエンティティ.
 */
@Parcelize
data class MBLG0302RequestBean(
    /**
     * 通帳パターン.
     */
    var bankbookPattern: String = "",
) : Parcelable

package jp.co.jsbank.mb.bankingapp.bean.login.mblg.mblg0201

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * 通知預金明細
 */
@Parcelize
data class NoticeDeposit(

    /**
     * 明細ID
     */
    var detailId: String = "",

    /**
     * お預かり金額
     */
    var fundedBalance: String = "",

    /**
     * 当初契約日
     */
    var initialContractDate: String = "",

    /**
     * 契約日
     */
    var contractDate: String = "",

    /**
     * 利率
     */
    var interestRate: String = "",

    /**
     * 課税区分
     */
    var taxClassName: String = "",

    /**
     * サブNO
     */
    var subNo: String = "",

    /**
     * 証書種類
     */
    var documentaryEvidenceType: String = "",

    /**
     * 口座番号
     */
    var accountNumber: String = "",

    /**
     * 店舗名
     */
    var branchName: String = "",

    /**
     * 店番
     */
    var branchNumber: String = "",
) : Parcelable

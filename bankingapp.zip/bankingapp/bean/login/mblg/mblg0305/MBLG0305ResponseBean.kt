package jp.co.jsbank.mb.bankingapp.bean.login.mblg.mblg0305

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * MBLG0305エンティティ.
 */
@Parcelize
data class MBLG0305ResponseBean(

    /**
     * 口座情報リスト.
     */
    var accountInfo: List<AccountDto> = listOf(),

    /**
     * CIF情報リスト.
     */
    var cifInfomationDtoList: List<CifInfomationDto> = listOf(),
) : Parcelable

/**
 * 口座情報.
 */
@Parcelize
data class AccountDto(

    /**
     * 店番.
     */
    var branchNumber: String = "",

    /**
     * 科目名.
     */
    var subjectNameValue: String = "",

    /**
     * 店名（漢字）.
     */
    var branchKanjiName: String = "",

    /**
     * 口座番号.
     */
    var accountNumber: String = "",
) : Parcelable

/**
 * CIF情報.
 */
@Parcelize
data class CifInfomationDto(

    /**
     * CIF番号.
     */
    var cifNo: String = "",

    /**
     * 店番.
     */
    var branchCode: String = "",
) : Parcelable

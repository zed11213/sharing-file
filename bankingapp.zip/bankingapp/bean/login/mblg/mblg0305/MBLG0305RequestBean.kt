package jp.co.jsbank.mb.bankingapp.bean.login.mblg.mblg0305

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * MBLG0305リクエストエンティティ.
 */
@Parcelize
data class MBLG0305RequestBean(

    /**
     * CIF情報リスト.
     */
    var cifInfomationDtoList: List<CifInfomationDto> = listOf(),
) : Parcelable

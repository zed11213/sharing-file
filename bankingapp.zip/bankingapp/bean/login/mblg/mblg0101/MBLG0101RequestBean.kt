package jp.co.jsbank.mb.bankingapp.bean.login.mblg.mblg0101

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * MBLG0101リクエストエンティティ.
 */
@Parcelize
data class MBLG0101RequestBean(
    /**
     * 初回ログインフラグ.
     */
    var loginFlg: String = "",
) : Parcelable

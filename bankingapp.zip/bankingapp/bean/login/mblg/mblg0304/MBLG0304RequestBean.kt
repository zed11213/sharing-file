package jp.co.jsbank.mb.bankingapp.bean.login.mblg.mblg0304

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * MBLG0304リクエストエンティティ.
 */
@Parcelize
data class MBLG0304RequestBean(

    /**
     * アイデンティティ
     */
    var identity: String = "",

    /**
     * アドレス
     */
    var address: String = ""
) : Parcelable

package jp.co.jsbank.mb.bankingapp.bean.cashCard.mbcc.mbcc0301

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * MBCC0301リクエストエンティティ.
 */
@Parcelize
data class MBCC0301RequestBean(
    /**
     * キャッシュカード種類
     */
    var cashCardType: String = "",

    /**
     * 更新パターン
     */
    var updateType: String = "",
    /**
     * 受付番号
     */
    var receptionNumber: String = "",

    /**
     * 人格区分
     */
    var personType: String = ""
) : Parcelable

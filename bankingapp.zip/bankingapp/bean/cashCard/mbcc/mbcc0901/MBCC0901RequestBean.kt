package jp.co.jsbank.mb.bankingapp.bean.cashCard.mbcc.mbcc0901

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * MBCC0901リクエストエンティティ.
 */
@Parcelize
data class MBCC0901RequestBean(
    /**
     * 受付番号
     */
    var receptionNumber: String = "",
    /**
     * 申込日
     */
    var applicationDate: String = "",
) : Parcelable

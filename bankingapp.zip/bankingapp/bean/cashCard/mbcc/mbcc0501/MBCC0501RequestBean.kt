package jp.co.jsbank.mb.bankingapp.bean.cashCard.mbcc.mbcc0501

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * MBCC0501リクエストエンティティ.
 */
@Parcelize
data class MBCC0501RequestBean(

    /**
     * 店番
     */
    var branchNumber: String = "",

    /**
     * 口座番号
     */
    var accountNumber: String = "",

    /**
     * CIF番号
     */
    var cifNumber: String = "",

    /**
     * カナ氏名（名）
     */
    var customerFirstName: String = "",

    /**
     * カナ氏名（姓）
     */
    var customerLastName: String = "",

    /**
     * 漢字氏名（姓）
     */
    var customerKanjiLastName: String = "",

    /**
     * 漢字氏名（名）
     */
    var customerKanjiFirstName: String = "",

    /**
     * 生年月日
     */
    var birthday: String = "",

    /**
     * 郵便番号
     */
    var zipCode: String = "",

    /**
     * 職業
     */
    var occupation: String = "",

    /**
     * 職業（その他）
     */
    var occupationOther: String = "",

    /**
     * 取引目的
     */
    var transactPurpose: String = "",

    /**
     * 取引目的（その他）
     */
    var transactPurposeOther: String = "",

    /**
     * 預金種目
     */
    var accountType: String = "",

    /**
     * CC暗証番号
     */
    var ccPinCode: String = "",

    /**
     * 取引種別
     */
    var transactionType: String = "",

    /**
     * 受付番号
     */
    var receiptNumber: String = "",

    /**
     * 画面ID
     */
    var pageId: String = "",

    /**
     * 更新パターン
     */
    var updateType: String = "",
) : Parcelable

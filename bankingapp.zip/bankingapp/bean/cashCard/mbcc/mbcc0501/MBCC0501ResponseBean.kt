package jp.co.jsbank.mb.bankingapp.bean.cashCard.mbcc.mbcc0501

/**
 * MBCC0501レスポンスエンティティ.
 */
data class MBCC0501ResponseBean(

    /**
     * 受付番号.
     */
    var receptionNumber: String = "",

    /**
     * 電話番号１.
     */
    var phoneNumber1: String = "",

    /**
     * 電話番号２.
     */
    var phoneNumber2: String = "",
    // 2025/01/16 共同化ため電話番号の登録・表示　電話３追加　start
    /**
     * 電話番号３.
     */
    var phoneNumber3: String = "",
    // 2025/01/16 共同化ため電話番号の登録・表示　電話３追加　end

    // 2025/01/24 共同化ためバンキングアプリでのチェック項目の確認（注意コード等）start
    /**
     * 本人カード仮発行.
     */
    var cardDummyIssue: String = "",
    // 2025/01/24 共同化ためバンキングアプリでのチェック項目の確認（注意コード等）　end
    /**
     * 番地.
     */
    var addrDetail3: String = "",

    /**
     * 住所方書（カナ）.
     */
    var addressDetailKana: String = "",
)

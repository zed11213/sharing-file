package jp.co.jsbank.mb.bankingapp.bean.ekyc

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**EkycReq
 * お知らせ一覧
 */
@Parcelize
data class GetTokenResponse(

    /**
     * お知らせID
     */
    var applicantId: String = "",

    /**
     * お知らせ種別コード
     */
    var token: String = "",

) : Parcelable

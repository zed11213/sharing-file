package jp.co.jsbank.mb.bankingapp.bean.ekyc

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

/**EkycReq
 * お知らせ一覧
 */
@Parcelize
data class GetTokenRequest(

    /**
     *　連携ID
     */
    var applicantId: String = "",

    /**
     * 優先度　　default １　
     */
    var operationAssignmentPriority: String = "",

    /**
     * redirectUrl
     */
    var redirectUrl: String = "",

    /**
     * errorRedirectUrl
     */
    var errorRedirectUrl: String = "",


) : Parcelable

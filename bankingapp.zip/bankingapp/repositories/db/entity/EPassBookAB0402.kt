package jp.co.jsbank.mb.bankingapp.repositories.db.entity

import io.realm.RealmObject
import io.realm.annotations.PrimaryKey
import io.realm.annotations.RealmClass

/**
 * 口座一覧と各口座.
 */
@RealmClass
open class EPassBookAB0402 : RealmObject() {
    /**
     * ID.
     */
    @PrimaryKey
    open lateinit var id: String

    /**
     * 入出金明細取得(流動性預金)(JSON).
     */
    open lateinit var normalNormalTaxPaymentRes: String
}

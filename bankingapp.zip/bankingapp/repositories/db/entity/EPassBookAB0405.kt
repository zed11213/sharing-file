package jp.co.jsbank.mb.bankingapp.repositories.db.entity

import io.realm.RealmObject
import io.realm.annotations.PrimaryKey
import io.realm.annotations.RealmClass

/**
 * 通知預金明細.
 */
@RealmClass
open class EPassBookAB0405 : RealmObject() {

    /**
     * ID.
     */
    @PrimaryKey
    open lateinit var id: String

    /**
     * 通知預金明細(JSON).
     */
    open lateinit var noticeDepositList: String
}

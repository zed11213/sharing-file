package jp.co.jsbank.mb.bankingapp.repositories.db.entity

import io.realm.RealmObject
import io.realm.annotations.PrimaryKey
import io.realm.annotations.RealmClass

/**
 * 口座一覧と各口座.
 */
@RealmClass
open class EPassBookAB0401 : RealmObject() {
    /**
     * ID.
     */
    @PrimaryKey
    open lateinit var id: String

    /**
     * 各科目毎残高合計.
     */
    open lateinit var subjectTotalBalance: String

    /**
     * 全口座残高合計.
     */
    open lateinit var allAccountsTotalBalance: String

    /**
     * 口座情報.
     */
    open lateinit var balanceInformationList: String
}

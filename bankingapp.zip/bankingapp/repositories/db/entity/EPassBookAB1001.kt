package jp.co.jsbank.mb.bankingapp.repositories.db.entity

import io.realm.RealmObject
import io.realm.annotations.PrimaryKey
import io.realm.annotations.RealmClass

/**
 * 口座一覧と各口座.
 */
@RealmClass
open class EPassBookAB1001 : RealmObject() {
    /**
     * ID.
     */
    @PrimaryKey
    open lateinit var id: String

    /**
     * お知らせ一覧DTOリスト.
     */
    open lateinit var anncmntList: String

    /**
     * 該当件数.
     */
    open lateinit var dataCount: String
}

package jp.co.jsbank.mb.bankingapp.repositories.db.entity

import io.realm.RealmObject
import io.realm.annotations.PrimaryKey
import io.realm.annotations.RealmClass

/**
 * 口座一覧と各口座.
 */
@RealmClass
open class EPassBookAB0701 : RealmObject() {
    /**
     * ID.
     */
    @PrimaryKey
    open lateinit var id: String

    /**
     * 人格区分.
     */
    open lateinit var personType: String

    /**
     * 画面ID.
     */
    open lateinit var screenId: String

    /**
     * 口座開設申込情報（個人）
     */
    open lateinit var individual: String

    /**
     * 口座開設申込情報（法人）
     */
    open lateinit var corporation: String

    /**
     * 口座開設申込情報（個人事業主）
     */
    open lateinit var soleProprietor: String
}

package jp.co.jsbank.mb.bankingapp.repositories.db.entity

import io.realm.RealmObject
import io.realm.annotations.PrimaryKey
import io.realm.annotations.RealmClass

/**
 * CIF照会.
 */
@RealmClass
open class AccountOpeningAB0707 : RealmObject() {
    /**
     * ID.
     */
    @PrimaryKey
    open lateinit var id: String

    /**
     * CIF照会情報.
     */
    open lateinit var cifInformation: String
}

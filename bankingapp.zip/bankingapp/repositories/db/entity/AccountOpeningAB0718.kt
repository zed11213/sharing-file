package jp.co.jsbank.mb.bankingapp.repositories.db.entity

import io.realm.RealmObject
import io.realm.annotations.PrimaryKey
import io.realm.annotations.RealmClass

/**
 * ご自宅情報入力.
 */
@RealmClass
open class AccountOpeningAB0718 : RealmObject() {
    /**
     * ID.
     */
    @PrimaryKey
    open lateinit var id: String

    /**
     * ご自宅情報.
     */
    open lateinit var homeInformation: String
}

package jp.co.jsbank.mb.bankingapp.repositories.db.entity

import io.realm.RealmObject
import io.realm.annotations.PrimaryKey
import io.realm.annotations.RealmClass

/**
 * 定期預金明細.
 */
@RealmClass
open class EPassBookAB0403 : RealmObject() {

    /**
     * ID.
     */
    @PrimaryKey
    open lateinit var id: String

    /**
     * 定期預金明細(JSON).
     */
    open lateinit var termDepositDetails: String
}

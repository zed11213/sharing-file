package jp.co.jsbank.mb.bankingapp.repositories.db.entity

import io.realm.RealmObject
import io.realm.annotations.PrimaryKey
import io.realm.annotations.RealmClass

/**
 * Publicキー.
 */
@RealmClass
open class PublicKey : RealmObject() {
    /**
     * ID.
     */
    @PrimaryKey
    open lateinit var id: String

    /**
     * 共通キー.
     */
    open lateinit var publicKey: String
}

package jp.co.jsbank.mb.bankingapp.repositories.db.entity

import io.realm.RealmObject
import io.realm.annotations.PrimaryKey
import io.realm.annotations.RealmClass

@RealmClass
open class EPassBookMBOP1401 : RealmObject() {
    /**
     * ID.
     */
    @PrimaryKey
    open lateinit var id: String

    /**
     * 選択した期間.
     */
    open lateinit var selectedValue: String

    /**
     * 期間開始日.
     */
    open lateinit var dateFrom: String

    /**
     * 期間終了日.
     */
    open lateinit var dateTo: String
}

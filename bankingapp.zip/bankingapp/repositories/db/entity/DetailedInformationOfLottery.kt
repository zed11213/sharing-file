package jp.co.jsbank.mb.bankingapp.repositories.db.entity

import io.realm.RealmObject
import io.realm.annotations.PrimaryKey
import io.realm.annotations.RealmClass

/**
 * 抽選明細Id情報.
 */
@RealmClass
open class DetailedInformationOfLottery : RealmObject() {
    /**
     * ID.
     */
    @PrimaryKey
    open lateinit var id: String

    /**
     * 明細ID.
     */
    open lateinit var detailedId: String
}

package jp.co.jsbank.mb.bankingapp.repositories.db.entity

import io.realm.RealmObject
import io.realm.annotations.PrimaryKey
import io.realm.annotations.RealmClass

/**
 * 学校情報.
 */
@RealmClass
open class AccountOpeningAB0704 : RealmObject() {
    /**
     * ID.
     */
    @PrimaryKey
    open lateinit var id: String

    /**
     * お勤め先情報.
     */
    open lateinit var schoolInformation: String
}

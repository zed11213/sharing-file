package jp.co.jsbank.mb.bankingapp.repositories.db.entity

import io.realm.RealmObject
import io.realm.annotations.PrimaryKey
import io.realm.annotations.RealmClass

/**
 * 店舗リスト.
 */
@RealmClass
open class EPassBookAB0112 : RealmObject() {

    /**
     * ID.
     */
    @PrimaryKey
    open lateinit var id: String

    /**
     * 店舗リスト.
     */
    open lateinit var deptList: String
}

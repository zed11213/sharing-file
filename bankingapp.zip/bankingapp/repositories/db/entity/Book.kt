package jp.co.jsbank.mb.bankingapp.repositories.db.entity

import io.realm.RealmObject
import io.realm.annotations.PrimaryKey
import io.realm.annotations.RealmClass

/**
 * データクラス.
 */
@RealmClass
open class Book : RealmObject() {
    @PrimaryKey
    open var id: String = ""
    open var name: String? = ""
    open var author: String? = ""
}

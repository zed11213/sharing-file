package jp.co.jsbank.mb.bankingapp.repositories.db.entity

import io.realm.RealmObject
import io.realm.annotations.PrimaryKey
import io.realm.annotations.RealmClass

/**
 * お客様情報入力.
 */
@RealmClass
open class AccountOpeningAB0706 : RealmObject() {
    /**
     * ID.
     */
    @PrimaryKey
    open lateinit var id: String

    /**
     * 口座開設情報.
     */
    open lateinit var customerInformation: String
}

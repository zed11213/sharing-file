package jp.co.jsbank.mb.bankingapp.repositories.db.entity

import io.realm.RealmObject
import io.realm.annotations.PrimaryKey
import io.realm.annotations.RealmClass

/**
 * 共通キー.
 */
@RealmClass
open class CommonKey : RealmObject() {
    /**
     * ID.
     */
    @PrimaryKey
    open lateinit var id: String

    /**
     * 共通キー.
     */
    open lateinit var commonKey: String
}

package jp.co.jsbank.mb.bankingapp.repositories.db.entity

import io.realm.RealmObject
import io.realm.annotations.PrimaryKey
import io.realm.annotations.RealmClass

/**
 * 所在地情報入力.
 */
@RealmClass
open class AccountOpeningAB0719 : RealmObject() {
    /**
     * ID.
     */
    @PrimaryKey
    open lateinit var id: String

    /**
     * 所在地情報.
     */
    open lateinit var locationInformation: String
}

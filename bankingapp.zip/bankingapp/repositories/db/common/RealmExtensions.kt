package jp.co.jsbank.mb.bankingapp.repositories.db.common

import io.realm.Realm
import io.realm.RealmObject
import io.realm.RealmQuery
import io.realm.RealmResults

/**
 * クリエイト.
 *
 * @param clazz    クラス名
 * @param f コールバックオブジェクト
 * @return realmオブジェクト
 */
fun <T : RealmObject> Realm.create(clazz: Class<T>, f: (it: T) -> Unit): T {
    beginTransaction()
    val realmObject = createObject(clazz)
    f(realmObject)
    commitTransaction()
    return realmObject
}

/**
 * クリエイト.
 *
 * @param it    クラス名
 * @return realmオブジェクト
 */
fun <T : RealmObject> Realm.create(it: T): T {
    beginTransaction()
    val realmObject = copyToRealm(it)
    commitTransaction()
    return realmObject
}

/**
 * クリエイト　Or 更新.
 *
 * @param it データクラス
 * @return realmオブジェクト
 */
fun <T : RealmObject> Realm.createOrUpdate(it: T): T {
    beginTransaction()
    val realmObject = copyToRealmOrUpdate(it)
    commitTransaction()
    return realmObject
}

/**
 * 全部削除.
 *
 * @param clazz データクラス
 */
fun <T : RealmObject> Realm.deleteAll(clazz: Class<T>) {
    beginTransaction()
    val results = where(clazz).findAll()
    results.deleteAllFromRealm()
    commitTransaction()
}

/**
 * 削除.
 *
 * @param clazz データクラス
 * @param key データキー
 * @param value データ値
 */
fun <T : RealmObject> Realm.delete(clazz: Class<T>, key: String, value: String) {
    beginTransaction()
    val results = where(clazz).equalTo(key, value).findAll()
    results.deleteAllFromRealm()
    commitTransaction()
}

/**
 * 検索.
 *
 * @param clazz データクラス
 * @param conditionMap データマップ
 * @return 検索した結果
 */
fun <T : RealmObject> Realm.query(
    clazz: Class<T>,
    conditionMap: Map<String, String>?
): RealmResults<T> {
    val query: RealmQuery<T> = where(clazz)
    if (conditionMap != null) {
        for ((key, value) in conditionMap) {
            query.equalTo(key, value)
        }
    }
    return query.findAll()
}

/**
 * 検索.
 *
 * @param clazz データクラス
 * @param conditionMap データマップ
 * @return 検索した結果(ファーストレコード)
 */
fun <T : RealmObject> Realm.show(clazz: Class<T>, conditionMap: Map<String, String>?): T? {
    val query: RealmQuery<T> = where(clazz)
    if (conditionMap != null) {
        for ((key, value) in conditionMap) {
            query.equalTo(key, value)
        }
    }
    return query.findFirst()
}

/**
 * 検索.
 *
 * @param clazz データクラス
 * @return 全部結果
 */
fun <T : RealmObject> Realm.findAll(clazz: Class<T>): RealmResults<T> {
    return query(clazz, null)
}

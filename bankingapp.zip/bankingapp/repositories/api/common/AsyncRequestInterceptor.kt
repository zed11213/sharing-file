package jp.co.jsbank.mb.bankingapp.repositories.api.common

import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import jp.co.jsbank.mb.bankingapp.system.Config.getAppId
import jp.co.jsbank.mb.bankingapp.utils.*
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.API_CONTENT_TYPE
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.API_CONTENT_TYPE_FORM
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.FORM_BODY_JAGACCESSTOKEN
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.FORM_BODY_JAGAPPLICATIONID
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.FORM_BODY_JAGBFFMETHOD
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.FORM_BODY_JAGDEVICEID
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.FORM_BODY_JAGJBAID
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.FORM_BODY_JAGTRAILER
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.FORM_BODY_JAGUSERID
import okhttp3.FormBody
import okhttp3.Interceptor
import okhttp3.Response
import java.io.IOException
import javax.inject.Inject

/**
 * リクエストインターセプター
 */
class AsyncRequestInterceptor @Inject constructor() : Interceptor {

    @RequiresApi(Build.VERSION_CODES.N)
    @Throws(IOException::class)
    override fun intercept(chain: Interceptor.Chain): Response {

        val requestBody = chain.request().body

        var bodyString = ""
        if (requestBody != null){
            val buffer = okio.Buffer()
            requestBody.writeTo(buffer)
            bodyString = buffer.readUtf8()
        }

        val list: Array<String> = arrayOf(
            ConstUtil.ACCESS_TOKEN,
            ConstUtil.JBA_ID_TOKEN,
            ConstUtil.USER_ID_TOKEN,
            ConstUtil.DEVICE_ID
        )
        val jagPeerBean = KeyStoreUtil().getJagInfo(list)
//        // ローディング開始
//        if (!LoadingUtil.loadingType && !LoadingUtil.loadingClose) {
//            LoadingUtil.setLoadingValue(value = true)
//        }
        // JBAID
        val jbaIdToken = jagPeerBean.customerId
        // 利用者IDトークン
        val userIdToken = jagPeerBean.userId
        // アクセストークン
        val accessToken = jagPeerBean.jagAccessToken
//        Log.i("thread", "c = ${jagPeerBean.customerId} u = ${jagPeerBean.userId} a = ${jagPeerBean.jagAccessToken} d = ${jagPeerBean.deviceId}")
//        Log.i("thread", "url = ${chain.request().url}")
//        Log.i("thread", "method = ${chain.request().method}  bodyString = $bodyString ")

        // API:タイプ

        val formBody = FormBody.Builder()
            // JAG Trailer JWT
            .add(FORM_BODY_JAGTRAILER, JWTUtil().asyncCreateJWT(bodyString))
            // BFF API HTTP METHOD (例. GET, POST など)
            .add(
                FORM_BODY_JAGBFFMETHOD,
                ConstUtil.API_METHOD_TYPE_POST
            )
            // 端末ID
            .add(FORM_BODY_JAGDEVICEID, jagPeerBean.deviceId)
            // アプリケーションID.
            .add(FORM_BODY_JAGAPPLICATIONID, getAppId())
            // JBA ID.
            .add(FORM_BODY_JAGJBAID, if (accessToken.isBlank()) "" else jbaIdToken)
            // USER ID.
            .add(FORM_BODY_JAGUSERID, if (accessToken.isBlank()) "" else userIdToken)
            // 認可コード（アクセストークン）
            .add(FORM_BODY_JAGACCESSTOKEN, accessToken)
            .build()

        // Jag フォームボディーーログ
        printFormBody(formBody)

        // Content-Type：application/x-www-form-urlencoded
        val request = chain.request().newBuilder().post(formBody)
            .addHeader(API_CONTENT_TYPE, API_CONTENT_TYPE_FORM)
            .build()

        return chain.proceed(request)
    }

    /**
     * Jag フォームボディーーログ.
     */
    private fun printFormBody(str: FormBody) {
        val stringBuilder = StringBuilder()
        stringBuilder.appendLine("\r\n")
        stringBuilder.appendLine(
            "->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->"
        )
        var formBodyStr = ""
        for (i in 0 until str.size) {
            formBodyStr += "Http FormBody:{${str.name(i)}=${str.value(i)}}\n"
        }
        stringBuilder.appendLine(formBodyStr)
        // 脆弱性診断対応：ログに重要情報を出力しないようにする（開発時、debugログを一時出力はOK）
        LogPrintUtil.debug(stringBuilder.toString())
    }
}

package jp.co.jsbank.mb.bankingapp.repositories.api.common

import android.os.Build
import androidx.annotation.RequiresApi
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.bean.common.ErrorResponseBean
import jp.co.jsbank.mb.bankingapp.logic.common.RefreshLogic
import jp.co.jsbank.mb.bankingapp.repositories.api.common.gateway.GatewayRestApiFactory
import jp.co.jsbank.mb.bankingapp.system.Config
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.system.MyApp
import jp.co.jsbank.mb.bankingapp.system.master.JagApiServiceCode
import jp.co.jsbank.mb.bankingapp.system.master.JagErrorCode
import jp.co.jsbank.mb.bankingapp.utils.*
import jp.co.jsbank.mb.bankingapp.utils.ApiRequestUtil.deleteApiParam
import kotlinx.coroutines.runBlocking
import okhttp3.*
import okhttp3.ResponseBody.Companion.toResponseBody
import java.io.IOException
import java.net.URLDecoder
import javax.inject.Inject

/**
 * レスポンスインターセプター
 */
class ResponseInterceptor @Inject constructor() : Interceptor {
    @RequiresApi(Build.VERSION_CODES.N)
    @Throws(IOException::class)
    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request()
        val repository = GatewayRestApiFactory.retrofit
        return kotlin.runCatching { chain.proceed(request) }
            // 成功場合
            .onSuccess {
                logRequest(request, chain.connection())
                when (it.code) {
                    200 -> {
                        // 呼び出しAPIがBFF場合
                        if (PreferenceUtil.getPreferenceStringValue(ConstUtil.API_SERVICE_NAME)
                            == JagApiServiceCode.APIGW.code
                        ) {
                            // 新しレスポンス作成
                            return newResponseCreate(it)
                        } else {
                            if (!LoadingUtil.loadingType && !LoadingUtil.loadingClose) {
                                LoadingUtil.setLoadingValue(value = false)
                            }
                            // レスポンス成功ログ
                            logResponse(it)
                        }
                    }
                    412 -> {
                        // 公開鍵更新
                        val res = runBlocking { RefreshLogic(repository).az0903() }
                        if (res) {
                            val newRequest = signedRequest(it)
                            it.close()
                            // 新しレスポンス作成
                            return newResponseCreate(chain.proceed(newRequest))
                        } else {
                            // エラーメッセージダイアログ表示
                            showErrorMsgDialog(it)
                        }
                    }
                    426 -> {
                        val errorInfo = it.peekBody((1024 * 1024).toLong()).string().fromJson<ErrorResponseBean>()
                        // APPバージョン更新
                        VersionUpdateUtil.postValue(errorInfo?.errorCode!!, errorInfo.errorMessage!!)
                    }
                    400, 418, 500 -> {
                        // エラーメッセージダイアログ表示
                        showErrorMsgDialog(it)
                    }
                    530 -> {
                        // ITb2 #257 時間帯別の処理を外し、530のときは常にメンテナンス中ですというメッセージとする
                        val errorMsg: String = MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.JAG_MSG_ID_CD6),
                            ConstUtil.APP_ERROR_CODE_MBLO0002
                        )
                        LoadingUtil.setLoadingValue(value = false)
                        LogPrintUtil.error(errorMsg)
                        POPWindowsUtil.postValue(value = errorMsg, parmErrorCode = ConstUtil.APP_ERROR_CODE_MBLO0002)
                    }
                    else -> {
                        if (MainActivity.API_401_RETRY_FLAG) {
                            val errorInfo = it.peekBody((1024 * 1024).toLong()).string().fromJson<ErrorResponseBean>()
                            if (errorInfo?.errorCode.isNullOrBlank()) {
                                val errorMsg = MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.JAG_MSG_ID_CD21),
                                    ConstUtil.APP_ERROR_CODE_MBLO0007,
                                    it.code.toString()
                                )
                                LoadingUtil.setLoadingValue(value = false)
                                LogPrintUtil.error(errorMsg)
                                POPWindowsUtil.postValue(errorMsg)
                            } else {
                                val errorMsg = errorInfo?.errorMessage.toString()
                                LoadingUtil.setLoadingValue(value = false)
                                LogPrintUtil.error(errorMsg)
                                POPWindowsUtil.postValue(errorMsg)
                            }
                        }
                    }
                }
            }
            // 失敗場合
            .onFailure {
                if (!it.message.toString().contains("Canceled")) {
                    val errorMsg = MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.JAG_MSG_ID_CD17),
                        ConstUtil.APP_ERROR_CODE_MBLO0004
                    )
                    LogPrintUtil.error(errorMsg)
                    POPWindowsUtil.postValue(errorMsg)
                }
                LoadingUtil.setLoadingValue(value = false)
            }
            .getOrThrow()
    }

    /**
     * 新しレスポンス作成.
     *
     * @param it レスポンス
     * @return 新しレスポンス
     */
    private fun newResponseCreate(it: Response): Response {
        val list: Array<String> = arrayOf(
            ConstUtil.COMMON_KEY_LABEL
        )
        val jagPeerBean = KeyStoreUtil().getJagInfo(list)
        // 共通キー
        val commonKey = jagPeerBean.jagEncryptedKey
        // レスポンスボディー
        val body = it.body?.string() ?: ""
        // 復号化レスポンスボディー
        val decryptStr = CommonKeyAESUtil().decrypt(body, commonKey)
        // 新しレスポンス作成
        val boy: ResponseBody = decryptStr.toResponseBody(it.body?.contentType())
        val newResponse = it.newBuilder().body(boy).build()
        if (!LoadingUtil.loadingType && !LoadingUtil.loadingClose) {
            LoadingUtil.setLoadingValue(value = false)
        }
        logResponse(newResponse)
        return newResponse
    }

    /**
     * 新しリクエスト作成.
     *
     * @return 新しリクエスト
     */
    private fun signedRequest(response: Response): Request {
        val list: Array<String> = arrayOf(
            ConstUtil.ACCESS_TOKEN,
            ConstUtil.JBA_ID_TOKEN,
            ConstUtil.USER_ID_TOKEN,
            ConstUtil.DEVICE_ID
        )
        val jagPeerBean = KeyStoreUtil().getJagInfo(list)
        // JBAID
        val jbaIdToken = jagPeerBean.customerId
        // 利用者IDトークン
        val userIdToken = jagPeerBean.userId
        // アクセストークン
        val accessToken = jagPeerBean.jagAccessToken
        // API:タイプ
        val apiType = PreferenceUtil.getPreferenceStringValue(ConstUtil.API_METHOD_TYPE)
        val formBody = FormBody.Builder()
            // JAG Trailer JWT
            .add(ConstUtil.FORM_BODY_JAGTRAILER, JWTUtil().createJWT(type = true))
            // BFF API HTTP METHOD (例. GET, POST など)
            .add(
                ConstUtil.FORM_BODY_JAGBFFMETHOD,
                apiType?.ifBlank { ConstUtil.API_METHOD_TYPE_POST }
                    ?: ConstUtil.API_METHOD_TYPE_POST
            )
            // 端末ID
            .add(ConstUtil.FORM_BODY_JAGDEVICEID, jagPeerBean.deviceId)
            // アプリケーションID.
            .add(ConstUtil.FORM_BODY_JAGAPPLICATIONID, Config.getAppId())
            // JBA ID.
            .add(ConstUtil.FORM_BODY_JAGJBAID, if (accessToken.isBlank()) "" else jbaIdToken)
            // USER ID.
            .add(ConstUtil.FORM_BODY_JAGUSERID, if (accessToken.isBlank()) "" else userIdToken)
            // 認可コード（アクセストークン）
            .add(ConstUtil.FORM_BODY_JAGACCESSTOKEN, jagPeerBean.jagAccessToken)
            .build()
        // API サービス名称
        PreferenceUtil.setPreferenceStringValue(ConstUtil.API_SERVICE_NAME, JagApiServiceCode.APIGW.value)
        deleteApiParam()
        return response.request.newBuilder().post(formBody)
            .build()
    }

    /**
     * エラーメッセージダイアログ表示.
     *
     * @param it レスポンス
     */
    private fun showErrorMsgDialog(it: Response) {
        val errorInfo = it.peekBody((1024 * 1024).toLong()).string().fromJson<ErrorResponseBean>()
        val errorCode = if (errorInfo?.errorCode.isNullOrBlank()) it.code.toString() else errorInfo?.errorCode
        var errorMsg = errorInfo?.errorMessage ?: MyApp.CONTEXT.getString(R.string.MSG_ID_SYSTEM_ERROR)
        var errorTitle = ""
        LogPrintUtil.error(errorMsg)

        // エラーメッセージ内容格納
        val pair = editErrorMsg(errorMsg, errorCode, errorTitle, it)
        errorMsg = pair.first
        errorTitle = pair.second

        // HTTPステータスコードが以下で、エラーコードがない(body部がhtmlで応答)場合に表示
        if (it.code == 500 && errorInfo?.errorCode.isNullOrBlank()) {
            errorMsg = MessageReplaceUtils.messageReplace(
                MyApp.CONTEXT.getString(R.string.JAG_MSG_ID_CD21),
                ConstUtil.APP_ERROR_CODE_MBLO0007,
                it.code.toString()
            )
        }

        // ログ情報設定
        LogPrintUtil.init("エラー情報")
        LogPrintUtil.error("エラーコード:$errorCode　　エラーメッセージ:$errorMsg")
        // MBFS0008の場合はPage層で処理するため、共通ダイアログを表示しない
        if (errorCode == MBFS0008ErrorUtil.ERROR_CODE) {
            MBFS0008ErrorUtil.postValue(errorMsg)
        } else {
            POPWindowsUtil.postValue(errorMsg, errorTitle, errorCode.toString())
        }
        LoadingUtil.setLoadingValue(value = false)
    }

    // エラーメッセージ内容格納
    private fun editErrorMsg(
        errorMsg: String,
        errorCode: String?,
        errorTitle: String,
        it: Response
    ): Pair<String, String> {
        var errorMsg1 = errorMsg
        var errorTitle1 = errorTitle
        when (PreferenceUtil.getPreferenceStringValue(ConstUtil.API_SERVICE_NAME)) {
            JagApiServiceCode.AZ0901.code -> {
                errorMsg1 = MessageReplaceUtils.messageReplace(
                    MyApp.CONTEXT.getString(R.string.JAG_MSG_ID_CD13),
                    errorCode.toString()
                )
            }
            JagApiServiceCode.AZ0903.code, JagApiServiceCode.AZ0906.code -> {
                errorMsg1 = MessageReplaceUtils.messageReplace(
                    MyApp.CONTEXT.getString(R.string.JAG_MSG_ID_CD5),
                    errorCode.toString()
                )
            }
            JagApiServiceCode.AZ0911.code -> {
                errorMsg1 = when (errorCode) {
                    JagErrorCode.E10001.code -> {
                        MainActivity.APP_RESTART_FLAG = true
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.JAG_MSG_ID_CD14),
                            errorCode.toString()
                        )
                    }
                    JagErrorCode.E10006.code, JagErrorCode.E10007.code, JagErrorCode.E10008.code -> {
                        MainActivity.APP_RESTART_FLAG = true
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.JAG_MSG_ID_CD12),
                            errorCode.toString()
                        )
                    }
                    JagErrorCode.E10045.code -> {
                        MainActivity.APP_RESTART_FLAG = true
                        errorTitle1 = "利用停止エラー"
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.JAG_MSG_ID_CD12),
                            errorCode.toString()
                        )
                    }
                    JagErrorCode.E10049.code -> {
                        errorTitle1 = "承認待ちエラー"
                        if (MainActivity.AZ0911_ERROR_FLG) {
                            MessageReplaceUtils.messageReplace(
                                MyApp.CONTEXT.getString(R.string.JAG_MSG_ID_E100491),
                                errorCode.toString() + "1"
                            )
                        } else {
                            MessageReplaceUtils.messageReplace(
                                MyApp.CONTEXT.getString(R.string.JAG_MSG_ID_DD24),
                                errorCode.toString()
                            )
                        }
                    }
                    else -> {
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.JAG_MSG_ID_CD13),
                            errorCode.toString()
                        )
                    }
                }
            }
            JagApiServiceCode.AZ0913.code -> {
                errorMsg1 = when (errorCode) {
                    JagErrorCode.E10001.code -> {
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.JAG_MSG_ID_CD14),
                            errorCode.toString()
                        )
                    }
                    JagErrorCode.E10045.code -> {
                        MainActivity.API_401_RETRY_FLAG = false
                        MainActivity.APP_RESTART_FLAG = true
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.JAG_MSG_ID_CD14),
                            errorCode.toString()
                        )
                    }
                    JagErrorCode.E10018.code -> {
                        ""
                    }
                    else -> {
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.JAG_MSG_ID_CD13),
                            errorCode.toString()
                        )
                    }
                }
            }
            JagApiServiceCode.APIGW.code -> {
                when (it.code) {
                    500 -> {
                        if (!errorCode?.contains("MB")!!) {
                            errorMsg1 = when (errorCode) {
                                JagErrorCode.E10001.code -> {
                                    MainActivity.APP_RESTART_FLAG = true
                                    MessageReplaceUtils.messageReplace(
                                        MyApp.CONTEXT.getString(R.string.JAG_MSG_ID_CD12),
                                        errorCode.toString()
                                    )
                                }
                                JagErrorCode.E10045.code -> {
                                    MainActivity.APP_RESTART_FLAG = true
                                    errorTitle1 = "利用停止エラー"
                                    MessageReplaceUtils.messageReplace(
                                        MyApp.CONTEXT.getString(R.string.JAG_MSG_ID_CD12),
                                        errorCode.toString()
                                    )
                                }
                                JagErrorCode.E10049.code -> {
                                    errorTitle1 = "承認待ちエラー"
                                    MessageReplaceUtils.messageReplace(
                                        MyApp.CONTEXT.getString(R.string.JAG_MSG_ID_DD24),
                                        errorCode.toString()
                                    )
                                }
                                else -> {
                                    MessageReplaceUtils.messageReplace(
                                        MyApp.CONTEXT.getString(R.string.JAG_MSG_ID_CD14),
                                        errorCode.toString()
                                    )
                                }
                            }
                        }
                    }
                    else -> {
                        if (errorCode == JagErrorCode.MBAP1044.code) {
                            errorMsg1 = ""
                        }
                    }
                }
            }
        }
        return Pair(errorMsg1, errorTitle1)
    }

    /**
     * レスポンスログ.
     *
     * @param response レスポンス
     */
    private fun logResponse(response: Response) {
        val str = StringBuffer()
        str.appendLine("\r\n")
        str.appendLine("<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-")

        var headerText = ""
        response.headers.toMultimap().forEach { header ->
            headerText += "Http Header:{${header.key}=${header.value}}\n"
        }
        str.appendLine(headerText)
        kotlin.runCatching {
            val peekBody: ResponseBody = response.peekBody((1024 * 1024).toLong())
            str.appendLine(peekBody.string())
        }.getOrNull()

        str.appendLine(
            "<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<" +
                "-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-"
        )
        // 脆弱性診断対応：ログに重要情報を出力しないようにする（開発時、debugログを一時出力はOK）
        LogPrintUtil.debug(str.toString())
    }

    /**
     * リクエストログ.
     *
     * @param request リクエスト
     * @param connection 接続
     */
    private fun logRequest(request: Request, connection: Connection?) {
        val str = StringBuilder()
        str.appendLine("\r\n")
        str.appendLine(
            "->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->"
        )
        logHeaders(str, request, connection)
        str.appendLine("RequestBody:${request.body}")
        // 脆弱性診断対応：ログに重要情報を出力しないようにする（開発時、debugログを一時出力はOK）
//        LogPrintUtil.debug(str.toString())
    }

    /**
     * ヘッダーログ.
     *
     * @param str 文字列
     * @param request リクエスト
     * @param connection 接続
     */
    private fun logHeaders(str: StringBuilder, request: Request, connection: Connection?) {
        logBasic(str, request, connection)
        var headerStr = ""
        request.headers.toMultimap().forEach { header ->
            headerStr += "Http Header:{${header.key}=${header.value}}\n"
        }
        str.appendLine(headerStr)
    }

    /**
     * ベースログ.
     *
     * @param str 文字列
     * @param request リクエスト
     * @param connection 接続
     */
    private fun logBasic(str: StringBuilder, request: Request, connection: Connection?) {
        str.appendLine(
            "Http method:${request.method} url:${decodeUrlStr(request.url.toString())} tag:" +
                "${request.tag()} protocol:${connection?.protocol() ?: Protocol.HTTP_1_1}"
        )
    }

    /**
     * ベースログ.
     *
     * @param url リクエストパス
     * @return デコードしたパス
     */
    private fun decodeUrlStr(url: String): String? {
        return kotlin.runCatching {
            URLDecoder.decode(url, "utf-8")
        }.onFailure { it.printStackTrace() }.getOrNull()
    }
}

package jp.co.jsbank.mb.bankingapp.repositories.api.common

/**
 * HttpResult
 */
sealed class HttpResult<out T> {
    // 成功
    data class Success<T>(val result: T) : HttpResult<T>()

    // 失敗
    data class Error(
        val errorMessage: String? = "",
        val errorCode: Int = 0
    ) : HttpResult<Nothing>()
}

package jp.co.jsbank.mb.bankingapp.repositories.api.common

import android.content.Intent
import android.os.Build
import androidx.annotation.RequiresApi
import java.io.IOException
import java.net.URLDecoder
import javax.inject.Inject
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.system.MyApp.Companion.CONTEXT
import jp.co.jsbank.mb.bankingapp.utils.LogPrintUtil
import jp.co.jsbank.mb.bankingapp.utils.showToast
import kotlinx.coroutines.DelicateCoroutinesApi
import okhttp3.*

/**
 * レスポンスインターセプター
 */
class RefreshResponseInterceptor @Inject constructor() : Interceptor {
    @OptIn(DelicateCoroutinesApi::class)
    @RequiresApi(Build.VERSION_CODES.N)
    @Throws(IOException::class)
    override fun intercept(chain: Interceptor.Chain): Response {
        val request = chain.request()
        return kotlin.runCatching { chain.proceed(request) }
            // 成功場合
            .onSuccess {
                logRequest(request, chain.connection())
                when (it.code) {
                    200 -> {
                        logResponse(it)
                    }
                    else -> {
                        // リフレッシュトークンが無効の場合
                        val intent = Intent(CONTEXT, MainActivity::class.java)
                        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        CONTEXT.startActivity(intent)
                    }
                }
            }
            // 失敗場合
            .onFailure {
                LogPrintUtil.error(it.message ?: "ネットワークがありません。再試行してください。")
                showToast(it.message)
            }
            .getOrThrow()
    }

    /**
     * レスポンスログ.
     *
     * @param response レスポンス
     */
    private fun logResponse(response: Response) {
        val str = StringBuffer()
        str.appendLine("\r\n")
        str.appendLine("<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-")

        var headerText = ""
        response.headers.toMultimap().forEach { header ->
            headerText += "Http Header:{${header.key}=${header.value}}\n"
        }
        str.appendLine(headerText)
        kotlin.runCatching {
            val peekBody: ResponseBody = response.peekBody((1024 * 1024).toLong())
            str.appendLine(peekBody.string())
        }.getOrNull()

        str.appendLine(
            "<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<" +
                "-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-<<-"
        )
        // 脆弱性診断対応：ログに重要情報を出力しないようにする（開発時、debugログを一時出力はOK）
//        LogPrintUtil.debug(str.toString())
    }

    /**
     * リクエストログ.
     *
     * @param request リクエスト
     * @param connection 接続
     */
    private fun logRequest(request: Request, connection: Connection?) {
        val str = StringBuilder()
        str.appendLine("\r\n")
        str.appendLine(
            "->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->->"
        )
        logHeaders(str, request, connection)
        str.appendLine("RequestBody:${request.body}")
        // 脆弱性診断対応：ログに重要情報を出力しないようにする（開発時、debugログを一時出力はOK）
//        LogPrintUtil.debug(str.toString())
    }

    /**
     * ヘッダーログ.
     *
     * @param str 文字列
     * @param request リクエスト
     * @param connection 接続
     */
    private fun logHeaders(str: StringBuilder, request: Request, connection: Connection?) {
        logBasic(str, request, connection)
        var headerStr = ""
        request.headers.toMultimap().forEach { header ->
            headerStr += "Http Header:{${header.key}=${header.value}}\n"
        }
        str.appendLine(headerStr)
    }

    /**
     * ベースログ.
     *
     * @param str 文字列
     * @param request リクエスト
     * @param connection 接続
     */
    private fun logBasic(str: StringBuilder, request: Request, connection: Connection?) {
        str.appendLine(
            "Http method:${request.method} url:${decodeUrlStr(request.url.toString())} tag:" +
                "${request.tag()} protocol:${connection?.protocol() ?: Protocol.HTTP_1_1}"
        )
    }

    /**
     * ベースログ.
     *
     * @param url リクエストパス
     * @return デコードしたパス
     */
    private fun decodeUrlStr(url: String): String? {
        return kotlin.runCatching {
            URLDecoder.decode(url, "utf-8")
        }.onFailure { it.printStackTrace() }.getOrNull()
    }
}

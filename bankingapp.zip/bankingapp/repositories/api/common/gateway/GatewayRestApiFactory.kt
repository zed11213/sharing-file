package jp.co.jsbank.mb.bankingapp.repositories.api.common.gateway

import java.util.concurrent.TimeUnit
import jp.co.jsbank.mb.bankingapp.repositories.api.common.ResponseInterceptor
import jp.co.jsbank.mb.bankingapp.repositories.api.request.gateway.GatewayRestService
import jp.co.jsbank.mb.bankingapp.system.Config.BASE_URL
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

/**
 * okhttp + retrofit構成
 */
object GatewayRestApiFactory {

    // デフォルト接続の設定
    private const val DEFAULT_CONNECT_TIMEOUT = 600000
    private const val DEFAULT_READ_TIMEOUT = 600000
    private const val DEFAULT_WRITE_TIMEOUT = 600000
    private lateinit var SERVICE: GatewayRestService

    // retrofit
    val retrofit: GatewayRestService
        get() {
            if (!GatewayRestApiFactory::SERVICE.isInitialized) {
                SERVICE = Retrofit.Builder()
                    .client(okHttp)
                    .addConverterFactory(GsonConverterFactory.create())
                    .baseUrl(BASE_URL)
                    .build()
                    .create(GatewayRestService::class.java)
            }
            return SERVICE
        }

    // okHttp
    val okHttp: OkHttpClient
        get() {
            return OkHttpClient.Builder().run {
                connectTimeout(DEFAULT_CONNECT_TIMEOUT.toLong(), TimeUnit.MILLISECONDS)
                readTimeout(DEFAULT_READ_TIMEOUT.toLong(), TimeUnit.MILLISECONDS)
                writeTimeout(DEFAULT_WRITE_TIMEOUT.toLong(), TimeUnit.MILLISECONDS)
                addInterceptor(ResponseInterceptor())
                build()
            }
        }
}

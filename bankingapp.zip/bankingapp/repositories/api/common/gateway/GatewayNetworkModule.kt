package jp.co.jsbank.mb.bankingapp.repositories.api.common.gateway

import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton
import jp.co.jsbank.mb.bankingapp.repositories.api.request.gateway.GatewayRestService
import okhttp3.OkHttpClient

@Module
@InstallIn(SingletonComponent::class)
class GatewayNetworkModule {

    @Singleton
    @Provides
    fun gatewayProvideApiService(): GatewayRestService = GatewayRestApiFactory.retrofit

    @Singleton
    @Provides
    fun gatewayProvideOkHttp(): OkHttpClient = GatewayRestApiFactory.okHttp
}

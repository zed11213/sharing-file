package jp.co.jsbank.mb.bankingapp.repositories.api.common

import java.util.concurrent.TimeUnit
import jp.co.jsbank.mb.bankingapp.repositories.api.common.gateway.GatewayRestApiFactory
import jp.co.jsbank.mb.bankingapp.repositories.api.request.AsyncRestService
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.system.Config.BASE_URL
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

/**
 * okhttp + retrofit構成
 */
object RestApiFactory {

    // デフォルト接続の設定
    private const val DEFAULT_CONNECT_TIMEOUT = 120000
    private const val DEFAULT_READ_TIMEOUT = 120000
    private const val DEFAULT_WRITE_TIMEOUT = 120000
    private lateinit var SERVICE: RestService
    private lateinit var ASYNC_SERVICE: AsyncRestService
    // retrofit
    val retrofit: RestService
        get() {
            if (!RestApiFactory::SERVICE.isInitialized) {
                SERVICE = Retrofit.Builder()
                    .client(okHttp)
                    .addConverterFactory(GsonConverterFactory.create())
                    .baseUrl(BASE_URL)
                    .build()
                    .create(RestService::class.java)
            }
            return SERVICE
        }

    val asyncRetrofit: AsyncRestService
        get() {
            if (!RestApiFactory::ASYNC_SERVICE.isInitialized) {
                ASYNC_SERVICE = Retrofit.Builder()
                    .client(asyncOkHttp)
                    .addConverterFactory(GsonConverterFactory.create())
                    .baseUrl(BASE_URL)
                    .build()
                    .create(AsyncRestService::class.java)
            }
            return ASYNC_SERVICE
        }



    // okHttp
    val okHttp: OkHttpClient
        get() {
            return OkHttpClient.Builder().run {
                connectTimeout(DEFAULT_CONNECT_TIMEOUT.toLong(), TimeUnit.MILLISECONDS)
                readTimeout(DEFAULT_READ_TIMEOUT.toLong(), TimeUnit.MILLISECONDS)
                writeTimeout(DEFAULT_WRITE_TIMEOUT.toLong(), TimeUnit.MILLISECONDS)
                authenticator(TokenRefreshAuthenticator(GatewayRestApiFactory.retrofit))
                addInterceptor(RequestInterceptor())
                addInterceptor(ResponseInterceptor())
                build()
            }
        }
    // okHttp
    val asyncOkHttp: OkHttpClient
        get() {
            return OkHttpClient.Builder().run {
                connectTimeout(DEFAULT_CONNECT_TIMEOUT.toLong(), TimeUnit.MILLISECONDS)
                readTimeout(DEFAULT_READ_TIMEOUT.toLong(), TimeUnit.MILLISECONDS)
                writeTimeout(DEFAULT_WRITE_TIMEOUT.toLong(), TimeUnit.MILLISECONDS)
                authenticator(TokenRefreshAuthenticator(GatewayRestApiFactory.retrofit))
                addInterceptor(AsyncRequestInterceptor())
                addInterceptor(AsyncResponseInterceptor())
                build()
            }
        }
}

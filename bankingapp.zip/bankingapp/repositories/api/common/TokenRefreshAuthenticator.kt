package jp.co.jsbank.mb.bankingapp.repositories.api.common

import jp.co.jsbank.mb.bankingapp.logic.common.RefreshLogic
import jp.co.jsbank.mb.bankingapp.repositories.api.request.gateway.GatewayRestService
import jp.co.jsbank.mb.bankingapp.system.Config
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.system.master.JagApiServiceCode
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil
import jp.co.jsbank.mb.bankingapp.utils.JWTUtil
import jp.co.jsbank.mb.bankingapp.utils.KeyStoreUtil
import jp.co.jsbank.mb.bankingapp.utils.PreferenceUtil
import kotlinx.coroutines.runBlocking
import okhttp3.*
import android.util.Log


/**
 * トークンリフレッシュインターセプター
 */

class TokenRefreshAuthenticator(private val repository: GatewayRestService) : Authenticator {

    // アクセス回数
    private val Response.retryCount: Int
        get() {
            var currentResponse = priorResponse
            var result = 1
            while (currentResponse != null) {
                result++
                currentResponse = currentResponse.priorResponse
            }
            return result
        }

    // HTTP コードが401場合
    override fun authenticate(route: Route?, response: Response): Request? = when {
        response.retryCount > 3 -> {
            null
        }
        else -> {
            // tokenの更新と再リクエスト
            val res = runBlocking { RefreshLogic(repository).az0913() }

            // リフレッシュトークンが無効場合
            if (res) {
                request(response)
            } else {
                if (MainActivity.API_401_RETRY_FLAG) {
                    // アクセストークとリフレッシュトークンを再取得
                    val res = runBlocking { RefreshLogic(repository).az0911() }
                    request(response)
                } else {
                    null
                }
            }
        }
    }

    private fun request(response: Response): Request {
        val list: Array<String> = arrayOf(
            ConstUtil.ACCESS_TOKEN,
            ConstUtil.JBA_ID_TOKEN,
            ConstUtil.USER_ID_TOKEN,
            ConstUtil.DEVICE_ID
        )
        val jagPeerBean = KeyStoreUtil().getJagInfo(list)
        // JBAID
        val jbaIdToken = jagPeerBean.customerId
        // 利用者IDトークン
        val userIdToken = jagPeerBean.userId
        // アクセストークン
        val accessToken = jagPeerBean.jagAccessToken

        Log.i("thread","j =${jagPeerBean.customerId} u = ${jagPeerBean.userId} ${jagPeerBean.jagAccessToken}")
        // API:タイプ
        val apiType = PreferenceUtil.getPreferenceStringValue(ConstUtil.API_METHOD_TYPE)
        val formBody = FormBody.Builder()
            // JAG Trailer JWT
            .add(ConstUtil.FORM_BODY_JAGTRAILER, JWTUtil().createJWT(type = true))
            // BFF API HTTP METHOD (例. GET, POST など)
            .add(
                ConstUtil.FORM_BODY_JAGBFFMETHOD,
                apiType?.ifBlank { ConstUtil.API_METHOD_TYPE_POST }
                    ?: ConstUtil.API_METHOD_TYPE_POST
            )
            // 端末ID
            .add(ConstUtil.FORM_BODY_JAGDEVICEID, jagPeerBean.deviceId)
            // アプリケーションID.
            .add(ConstUtil.FORM_BODY_JAGAPPLICATIONID, Config.getAppId())
            // JBA ID.
            .add(ConstUtil.FORM_BODY_JAGJBAID, if (accessToken.isBlank()) "" else jbaIdToken)
            // USER ID.
            .add(ConstUtil.FORM_BODY_JAGUSERID, if (accessToken.isBlank()) "" else userIdToken)
            // 認可コード（アクセストークン）
            .add(ConstUtil.FORM_BODY_JAGACCESSTOKEN, jagPeerBean.jagAccessToken)
            .build()
        // API サービス名称
        PreferenceUtil.setPreferenceStringValue(ConstUtil.API_SERVICE_NAME, JagApiServiceCode.APIGW.value)
        return response.request
            .newBuilder().post(formBody)
            .build()
    }
}

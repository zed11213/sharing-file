package jp.co.jsbank.mb.bankingapp.repositories.api.common

import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.repositories.api.request.AsyncRestService
import okhttp3.OkHttpClient

@Module
@InstallIn(SingletonComponent::class)
class NetworkModule {

    @Singleton
    @Provides
    fun provideApiService(): RestService = RestApiFactory.retrofit

    @Singleton
    @Provides
    fun provideAsyncApiService(): AsyncRestService = RestApiFactory.asyncRetrofit

    @Singleton
    @Provides
    fun provideOkHttp(): OkHttpClient = RestApiFactory.okHttp
}

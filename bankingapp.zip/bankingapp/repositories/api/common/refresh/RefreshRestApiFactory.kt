package jp.co.jsbank.mb.bankingapp.repositories.api.common.refresh

import java.util.concurrent.TimeUnit
import jp.co.jsbank.mb.bankingapp.repositories.api.common.RefreshResponseInterceptor
import jp.co.jsbank.mb.bankingapp.repositories.api.request.refresh.RefreshRestService
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

/**
 * okhttp + retrofit構成
 */
object RefreshRestApiFactory {

    // デフォルト接続の設定
    private const val BASE_URL = "http://jag-api-gateway-service-ops-jag-gw." +
        "mycluster-jp-tok-1-430553-06f3cfc58a58986a2f2ce380e01e4d99-0000.jp-tok.containers.appdomain.cloud"
    private const val DEFAULT_CONNECT_TIMEOUT = 30000
    private const val DEFAULT_READ_TIMEOUT = 30000
    private const val DEFAULT_WRITE_TIMEOUT = 30000
    private lateinit var SERVICE: RefreshRestService

    // retrofit
    val retrofit: RefreshRestService
        get() {
            if (!RefreshRestApiFactory::SERVICE.isInitialized) {
                SERVICE = Retrofit.Builder()
                    .client(okHttp)
                    .addConverterFactory(GsonConverterFactory.create())
                    .baseUrl(BASE_URL)
                    .build()
                    .create(RefreshRestService::class.java)
            }
            return SERVICE
        }

    // okHttp
    val okHttp: OkHttpClient
        get() {
            return OkHttpClient.Builder().run {
                connectTimeout(DEFAULT_CONNECT_TIMEOUT.toLong(), TimeUnit.MILLISECONDS)
                readTimeout(DEFAULT_READ_TIMEOUT.toLong(), TimeUnit.MILLISECONDS)
                writeTimeout(DEFAULT_WRITE_TIMEOUT.toLong(), TimeUnit.MILLISECONDS)
                addInterceptor(RefreshResponseInterceptor())
                build()
            }
        }
}

package jp.co.jsbank.mb.bankingapp.repositories.api.common.refresh

import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton
import jp.co.jsbank.mb.bankingapp.repositories.api.request.refresh.RefreshRestService
import okhttp3.OkHttpClient

@Module
@InstallIn(SingletonComponent::class)
class RefreshNetworkModule {

    @Singleton
    @Provides
    fun refreshProvideApiService(): RefreshRestService = RefreshRestApiFactory.retrofit

    @Singleton
    @Provides
    fun refreshProvideOkHttp(): OkHttpClient = RefreshRestApiFactory.okHttp
}

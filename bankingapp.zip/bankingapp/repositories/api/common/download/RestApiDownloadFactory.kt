package jp.co.jsbank.mb.bankingapp.repositories.api.common.download

import java.io.File
import jp.co.jsbank.mb.bankingapp.repositories.api.request.download.RestDownLoadService
import retrofit2.Retrofit

typealias download_error = suspend (Throwable) -> Unit
typealias download_process = suspend (downloadedSize: Long, length: Long, progress: Float) -> Unit
typealias download_success = suspend (uri: File) -> Unit

/**
 * retrofit構成
 */
object RestApiDownloadFactory {

    private val retrofit = Retrofit.Builder()
        .baseUrl("http://www.xxx.com")
        .validateEagerly(true)
        .build()

    val apiService: RestDownLoadService = retrofit.create(RestDownLoadService::class.java)
}

package jp.co.jsbank.mb.bankingapp.repositories.api.common.download

/**
 * ダウンロード
 */
class HttpDownLoadResult<out T> constructor(val value: Any?) {

    val isSuccess: Boolean get() = value !is Failure && value !is Progress

    val isFailure: Boolean get() = value is Failure

    val isLoading: Boolean get() = value is Progress

    fun exceptionOrNull(): Throwable? =
        when (value) {
            is Failure -> value.exception
            else -> null
        }

    companion object {
        fun <T> success(value: T): HttpDownLoadResult<T> =
            HttpDownLoadResult(value)

        fun <T> failure(exception: Throwable): HttpDownLoadResult<T> =
            HttpDownLoadResult(createFailure(exception))

        fun <T> progress(currentLength: Long, length: Long, process: Float): HttpDownLoadResult<T> =
            HttpDownLoadResult(createLoading(currentLength, length, process))
    }

    data class Failure(val exception: Throwable)

    data class Progress(val currentLength: Long, val length: Long, val process: Float)
}

private fun createFailure(exception: Throwable): HttpDownLoadResult.Failure =
    HttpDownLoadResult.Failure(exception)

private fun createLoading(currentLength: Long, length: Long, process: Float) =
    HttpDownLoadResult.Progress(currentLength, length, process)

inline fun <R, T> HttpDownLoadResult<T>.fold(
    onSuccess: (value: T) -> R,
    onLoading: (loading: HttpDownLoadResult.Progress) -> R,
    onFailure: (exception: Throwable?) -> R
): R {
    return when {
        isFailure -> {
            onFailure(exceptionOrNull())
        }
        isLoading -> {
            onLoading(value as HttpDownLoadResult.Progress)
        }
        else -> {
            onSuccess(value as T)
        }
    }
}

package jp.co.jsbank.mb.bankingapp.repositories.api.request.download

import okhttp3.ResponseBody
import retrofit2.http.GET
import retrofit2.http.Streaming
import retrofit2.http.Url

/**
 * ダウンロードサービス
 */
interface RestDownLoadService {

    @Streaming
    @GET
    suspend fun downloadFile(@Url fileUrl: String?): ResponseBody
}

package jp.co.jsbank.mb.bankingapp.repositories.api.request

import jp.co.jsbank.mb.bankingapp.bean.basic.BasicBean
import jp.co.jsbank.mb.bankingapp.bean.cashCard.mbcc.mbcc0501.MBCC0501ResponseBean
import jp.co.jsbank.mb.bankingapp.bean.common.AnnouncementsBean
import jp.co.jsbank.mb.bankingapp.bean.common.DepartmentBean
import jp.co.jsbank.mb.bankingapp.bean.common.PostCodeResponseBean
import jp.co.jsbank.mb.bankingapp.bean.common.RecoveryResponseBean
import jp.co.jsbank.mb.bankingapp.bean.ekyc.GetTokenResponse
import jp.co.jsbank.mb.bankingapp.bean.login.mblg.mblg0305.MBLG0305ResponseBean
import jp.co.jsbank.mb.bankingapp.bean.login.mbsu.mbsu0302.MBSU0302ResponseBean
import jp.co.jsbank.mb.bankingapp.bean.login.mbsu.mbsu0501.MBSU0501ResponseBean
import jp.co.jsbank.mb.bankingapp.bean.login.mbsu.mbsu0502.MBSU0502ResponseBean
import jp.co.jsbank.mb.bankingapp.bean.login.mbsu.mbsu0601.MBSU0601ResponseBean
import jp.co.jsbank.mb.bankingapp.bean.login.mbsu.mbsu0602.MBSU0602ResponseBean
import jp.co.jsbank.mb.bankingapp.bean.main.balance.BalanceResponseBean
import jp.co.jsbank.mb.bankingapp.bean.main.home.mbdp.mbdp0301.AB0402ResponseBean
import jp.co.jsbank.mb.bankingapp.bean.main.home.mbdp.mbdp0301.TermDepositDetails
import jp.co.jsbank.mb.bankingapp.bean.main.home.mbdp.mbdp0901.PeriodicDepositDetailsRes
import jp.co.jsbank.mb.bankingapp.bean.main.home.mbdp.mbdp1101.MBDP1101ResponseBean
import jp.co.jsbank.mb.bankingapp.bean.main.home.mblg.MBLG0101ResponseBean
import jp.co.jsbank.mb.bankingapp.bean.main.home.mbnt.mbnt0101.AB0501ResponseBean
import jp.co.jsbank.mb.bankingapp.bean.main.home.mbnt.mbnt0101.MBNT0101ResponseBean
import jp.co.jsbank.mb.bankingapp.bean.main.home.mbnt.mbnt0201.MBNT0201ResponseBean
import jp.co.jsbank.mb.bankingapp.bean.main.home.mbrc.mbrc0101.MBRC0101ResponseBean
import jp.co.jsbank.mb.bankingapp.bean.main.home.mbrc.mbrc0201.CustomerResponse
import jp.co.jsbank.mb.bankingapp.bean.main.home.mbrc.mbrc0201.MBRC0201ResponseBean
import jp.co.jsbank.mb.bankingapp.bean.main.home.mbrc.mbrc0301.MBRC0301ResponseBean
import jp.co.jsbank.mb.bankingapp.bean.main.menu.mbst.mbst0501.GetJuridicalPersonUserDetailsRes
import jp.co.jsbank.mb.bankingapp.bean.main.menu.mbst.mbst0503.AuthenticationKeyIssuanceRes
import jp.co.jsbank.mb.bankingapp.bean.main.menu.mbst.mbst0802.GetUseAccountRegistrationRes
import jp.co.jsbank.mb.bankingapp.bean.main.menu.mbst.mbst0901.CifInfomationRes
import jp.co.jsbank.mb.bankingapp.bean.main.menu.mbst.mbst1201.MBST1201Bean
import jp.co.jsbank.mb.bankingapp.bean.main.menu.mbst.mbst1201.SubjectBalanceInfo
import jp.co.jsbank.mb.bankingapp.bean.main.menu.mbst.mbst1801.UserInfoListRes
import jp.co.jsbank.mb.bankingapp.bean.opened.mbco.mbco0201.MBCO0201ResponseBean
import jp.co.jsbank.mb.bankingapp.bean.opened.mbco.mbco0302.MBCO0302ResponseBean
import jp.co.jsbank.mb.bankingapp.bean.opened.mbop.mbop0602.MBOP0602ResponseBean
import jp.co.jsbank.mb.bankingapp.bean.opened.mbop.mbop0701.MBOP0701ResponseBean
import retrofit2.http.POST
import retrofit2.http.PUT

/**
 * Httpサービス
 */
interface RestService {

    /** ====================================================================== **/
    /** ============================MBLG====================================== **/
    /** ====================================================================== **/

    /* ============================MBLG0201================================== */
    // お知らせ一覧取得
    @POST("v2/apigw/e-passbook/AB0601")
    suspend fun AB0601(): BasicBean<AnnouncementsBean>

    // 入出金明細取得(流動性預金)
    @POST("v2/apigw/e-passbook/AB0402")
    suspend fun AB0402(): BasicBean<AB0402ResponseBean?>

    // 定期預金明細取得
    @POST("v2/apigw/e-passbook/AB0403")
    suspend fun AB0403(): BasicBean<List<TermDepositDetails>?>

    // 定期積金明細取得
    @POST("v2/apigw/e-passbook/AB0404")
    suspend fun AB0404(): BasicBean<PeriodicDepositDetailsRes>

    // 通知預金明細取得
    @POST("v2/apigw/e-passbook/AB0405")
    suspend fun AB0405(): BasicBean<MBDP1101ResponseBean>

    /* ============================Balance================================== */
    // 収支グラフ表示値取得
    @POST("v2/apigw/e-passbook/AB0407")
    suspend fun AB0407(): BasicBean<List<BalanceResponseBean>>

    /* ============================MBLG0302================================== */
    // 通帳パターン設定
    @POST("v2/apigw/sign-up/AB0120")
    suspend fun AB0120(): BasicBean<String?>

    // バインディング
    @PUT("v2/apigw/sign-up/AB0121")
    suspend fun AB0121(): BasicBean<String?>

    /* ============================MBLG0304================================== */
    // プッシュ通知登録
    @POST("v2/apigw/sign-up/AB0119")
    suspend fun AB0119(): BasicBean<String?>

    /* ============================MBST1201================================== */
    // 各科目の残高情報を取得する
    @POST("v2/apigw/e-passbook/AB0401")
    suspend fun AB0401(): BasicBean<SubjectBalanceInfo>

    /** ====================================================================== **/
    /** ============================MBSU====================================== **/
    /** ====================================================================== **/

    /* ============================MBSU0102================================== */
    // 全部店リスト取得
    @POST("v2/apigw/sign-up/AB0112")
    suspend fun AB0112(): BasicBean<List<DepartmentBean>>

    /* ============================MBSU0501================================== */
    // 認証コード要求
    @POST("v2/apigw/sign-up/AB0101")
    suspend fun AB0101(): BasicBean<MBSU0501ResponseBean>

    /* ============================MBSU0502================================== */
    // 認証コード要求
    @POST("v2/apigw/sign-up/AB0102")
    suspend fun AB0102(): BasicBean<MBSU0502ResponseBean>

    /* ============================MBSU0302================================== */
    // 本人照合
    @POST("v2/apigw/sign-up/AB0103")
    suspend fun AB0103(): BasicBean<MBSU0302ResponseBean>

    /* ============================MBSU0601================================== */
    // IVR送信
    @POST("v2/apigw/sign-up/AB0105")
    suspend fun AB0105(): BasicBean<MBSU0601ResponseBean>

    /* ============================MBSU0602================================== */
    // IVR認証
    @POST("v2/apigw/sign-up/AB0106")
    suspend fun AB0106(): BasicBean<MBSU0602ResponseBean>

    /** ====================================================================== **/
    /** ============================MBDP====================================== **/
    /** ====================================================================== **/

    /* ============================MBDP1301================================== */
    // 概要欄メモ登録
    @PUT("v2/apigw/e-passbook/AB0406")
    suspend fun AB0406(): BasicBean<String?>

    /* ============================MBDP1301================================== */

    /** ====================================================================== **/
    /** ============================MBCO====================================== **/
    /** ====================================================================== **/

    /* ============================MBCO0501================================== */
    // CC暗証番号設定
    @POST("v2/apigw/cashcard-issue/AB0802")
    suspend fun AB0802(): BasicBean<String?>

    /* ============================MBCO0601================================== */
    // IBパスワード設定
    @POST("v2/apigw/account-opening/AB0711")
    suspend fun AB0711(): BasicBean<String?>

    /** ====================================================================== **/
    /** ============================MBOP====================================== **/
    /** ====================================================================== **/

    /* ============================MBOP1401================================== */
    // ICOSへ本人確認書類格納
    @PUT("v2/apigw/account-opening/AB0702")
    suspend fun AB0702(): BasicBean<String?>

    /* ============================MBOP0203================================== */
    // 店舗リスト取得
    @POST("v2/apigw/account-opening/AB0705")
    suspend fun AB0705(): BasicBean<MBOP0701ResponseBean>

    /* ============================MBOP0601================================== */
    // お客様情報入力
    @POST("v2/apigw/account-opening/AB0706")
    suspend fun AB0706(): BasicBean<String>

    /* ============================MBOP0602================================== */
    // ご職業などの入力
    @POST("v2/apigw/account-opening/AB0707")
    suspend fun AB0707(): BasicBean<String?>

    /* ============================MBOP0701================================== */
    // 営業地区部店一覧照会 TODO
    @POST("v2/apigw/account-opening/AB0708")
    suspend fun AB0708(): BasicBean<MBOP0701ResponseBean>

    /* ============================MBOP0703================================== */
    // 希望店設定
    @POST("v2/apigw/account-opening/AB0709")
    suspend fun AB0709(): BasicBean<String?>

    /* ============================MBOP0608================================== */
    // お勤め先情報入力
    @POST("v2/apigw/account-opening/AB0703")
    suspend fun AB0703(): BasicBean<String>

    /* ============================MBOP0609================================== */
    // 学校情報入力入力
    @POST("v2/apigw/account-opening/AB0704")
    suspend fun AB0704(): BasicBean<String>

    /* ============================MBCO0201================================== */
    // 認証コード要求
    @POST("v2/apigw/account-opening/AB0712")
    suspend fun AB0712(): BasicBean<MBCO0201ResponseBean>

    /* ============================MBCO0202================================== */
    // 認証コード要求
    @POST("v2/apigw/account-opening/AB0713")
    suspend fun AB0713(): BasicBean<String?>

    /* ============================MBCO0301================================== */
    // IVR送信
    @POST("v2/apigw/account-opening/AB0714")
    suspend fun AB0714(): BasicBean<String?>

    /* ============================MBCO0302================================== */
    // IVR認証
    @POST("v2/apigw/account-opening/AB0715")
    suspend fun AB0715(): BasicBean<MBCO0302ResponseBean>

    /* ============================MBOP0610================================== */
    // 所在地情報保存
    @POST("v2/apigw/account-opening/AB0716")
    suspend fun AB0716(): BasicBean<String?>

    /* ============================MBOP0611================================== */
    // 本店所在地情報保存
    @POST("v2/apigw/account-opening/AB0717")
    suspend fun AB0717(): BasicBean<String?>

    /* ============================MBOP0612================================== */
    // bizご自宅情報保存
    @POST("v2/apigw/account-opening/AB0718")
    suspend fun AB0718(): BasicBean<String?>

    /* ============================MBOP0613================================== */
    // bizご自宅情報保存
    @POST("v2/apigw/account-opening/AB0719")
    suspend fun AB0719(): BasicBean<String?>

    // 郵便番号の自動検索
    @POST("v2/apigw/account-opening/AB0710")
    suspend fun AB0710(): BasicBean<List<PostCodeResponseBean>>

    // 本人確認
    @POST("v2/apigw/cashcard-issue/AB0805")
    suspend fun AB0805(): BasicBean<MBCC0501ResponseBean>

    // CC発行依頼
    @POST("v2/apigw/cashcard-issue/AB0804")
    suspend fun AB0804(): BasicBean<String?>

    // メールアドレス認証
    @POST("v2/apigw/cashcard-issue/AB0807")
    suspend fun AB0807(): BasicBean<String?>

    // IVR認証
    @POST("v2/apigw/cashcard-issue/AB0808")
    suspend fun AB0808(): BasicBean<MBCO0302ResponseBean>

    // 申込完了
    @POST("v2/apigw/account-opening/AB0720")
    suspend fun AB0720(): BasicBean<String?>

    // 復元処理
    @POST("v2/apigw/account-opening/AB0701")
    suspend fun AB0701(): BasicBean<RecoveryResponseBean>

    // お知らせ閲覧
    @POST("v2/apigw/electronic-issue/AB0501")
    suspend fun AB0501(): BasicBean<AB0501ResponseBean>

    // 帳票PDFダウンロード
    @POST("v2/apigw/electronic-issue/AB0502")
    suspend fun AB0502(): BasicBean<String?>

    // ログイン認証
    @POST("v2/apigw/login/AB0201")
    suspend fun AB0201(): BasicBean<MBLG0101ResponseBean>

    // お知らせ一覧取得
    @POST("v2/apigw/announcement-list/AB1001")
    suspend fun AB1001(): BasicBean<MBNT0101ResponseBean>

    // スター/お知らせ本文取得
    @POST("v2/apigw/announcement-list/AB1002")
    suspend fun AB1002(): BasicBean<MBNT0201ResponseBean>

    // スター/お気に入り押下処理
    @POST("v2/apigw/announcement-list/AB1003")
    suspend fun AB1003(): BasicBean<String?>

    // 顧客による個別確認
    @POST("v2/apigw/announcement-list/AB1004")
    suspend fun AB1004(): BasicBean<String?>

    // 通知設定情報取得
    @POST("v2/apigw/various-registration-preference/AB1101")
    suspend fun AB1101(): BasicBean<UserInfoListRes>

    // 通知設定情報変更
    @PUT("v2/apigw/various-registration-preference/AB1102")
    suspend fun AB1102(): BasicBean<String?>

    // 利用口座削除
    @PUT("v2/apigw/various-registration-preference/AB1103")
    suspend fun AB1103(): BasicBean<String?>

    // 利用口座登録
    @PUT("v2/apigw/various-registration-preference/AB1104")
    suspend fun AB1104(): BasicBean<String?>

    // デザイン取得
    @POST("v2/apigw/various-registration-preference/AB1105")
    suspend fun AB1105(): BasicBean<String?>

    // デザイン更新
    @POST("v2/apigw/various-registration-preference/AB1106")
    suspend fun AB1106(): BasicBean<String?>

    // メールアドレス変更
    @PUT("v2/apigw/various-registration-preference/AB1107")
    suspend fun AB1107(): BasicBean<MBSU0501ResponseBean>

    // メールアドレス登録
    @POST("v2/apigw/various-registration-preference/AB1108")
    suspend fun AB1108(): BasicBean<String?>

    // 法人利用者情報一覧取得
    @POST("v2/apigw/various-registration-preference/AB1109")
    suspend fun AB1109(): BasicBean<GetJuridicalPersonUserDetailsRes>

    // 認証キー発行
    @POST("v2/apigw/various-registration-preference/AB1110")
    suspend fun AB1110(): BasicBean<AuthenticationKeyIssuanceRes>

    // 利用者追加確認ステータス更新
    @POST("v2/apigw/various-registration-preference/AB1111")
    suspend fun AB1111(): BasicBean<String?>

    // 取引停止
    @POST("v2/apigw/various-registration-preference/AB1112")
    suspend fun AB1112(): BasicBean<String?>

    // 利用口座登録確認情報取得
    @POST("v2/apigw/various-registration-preference/AB1113")
    suspend fun AB1113(): BasicBean<GetUseAccountRegistrationRes>

    // CIF情報取得
    @POST("v2/apigw/various-registration-preference/AB1114")
    suspend fun AB1114(): BasicBean<CifInfomationRes>

    // 通帳レス情報取得
    @POST("v2/apigw/various-registration-preference/AB1116")
    suspend fun AB1116(): BasicBean<MBLG0305ResponseBean>

    // 通帳レス設定
    @POST("v2/apigw/various-registration-preference/AB1117")
    suspend fun AB1117(): BasicBean<String?>

    // 解約済口座取得
    @POST("v2/apigw/various-registration-preference/AB1118")
    suspend fun AB1118(): BasicBean<List<MBST1201Bean>>

    // 解約済口座削除
    @POST("v2/apigw/various-registration-preference/AB1119")
    suspend fun AB1119(): BasicBean<String?>

    // お知らせ種別IDで案内照会
    @POST("v2/apigw/easy-reception/AB0901")
    suspend fun AB0901(): BasicBean<MBRC0101ResponseBean>

    // 受付案内閲覧
    @POST("v2/apigw/easy-reception/AB0902")
    suspend fun AB0902(): BasicBean<MBRC0201ResponseBean>

    // かんたん登録画面取得
    @POST("v2/apigw/easy-reception/AB0903")
    suspend fun AB0903(): BasicBean<CustomerResponse>

    // 受付案内閲覧（ログイン前）
    @POST("v2/apigw/easy-reception/AB0904")
    suspend fun AB0904(): BasicBean<MBRC0201ResponseBean>

    // かんたん登録画面入力情報送信
    @POST("v2/apigw/easy-reception/AB0905")
    suspend fun AB0905(): BasicBean<String?>

    // かんたん登録画面入力情報送信（ログイン前）
    @POST("v2/apigw/easy-reception/AB0906")
    suspend fun AB0906(): BasicBean<String?>

    // 受付通知閲覧
    @POST("v2/apigw/easy-reception/AB0907")
    suspend fun AB0907(): BasicBean<MBRC0301ResponseBean>

    // 申込回答閲覧
    @POST("v2/apigw/easy-reception/AB0908")
    suspend fun AB0908(): BasicBean<MBRC0301ResponseBean>

    // カードデザイン選択
    @POST("v2/apigw/cashcard-issue/AB0803")
    suspend fun AB0803(): BasicBean<String?>

    // トークン取得
    @POST("v2/apigw/ekyc/AB1201")
    suspend fun AB1201(): BasicBean<GetTokenResponse?>

    // JPKI フロー
    @POST("v2/apigw/ekyc/AB1202")
    suspend fun AB1202(): BasicBean<String>

    // へ方式フロー
    @POST("v2/apigw/ekyc/AB1203")
    suspend fun AB1203(): BasicBean<String>

}

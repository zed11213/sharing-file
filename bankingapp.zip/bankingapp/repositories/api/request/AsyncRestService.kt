package jp.co.jsbank.mb.bankingapp.repositories.api.request

import jp.co.jsbank.mb.bankingapp.bean.basic.BasicBean
import jp.co.jsbank.mb.bankingapp.bean.common.TermDepositDetailsInfoBean
import jp.co.jsbank.mb.bankingapp.bean.main.home.mbdp.mbdp0301.TermDepositDetails
import jp.co.jsbank.mb.bankingapp.bean.main.home.mbdp.mbdp1101.MBDP1101ResponseBean
import retrofit2.http.Body
import retrofit2.http.POST

/**
 * Httpサービス
 */
interface AsyncRestService {
    // 定期預金明細取得
    @POST("v2/apigw/e-passbook/AB0403")
    suspend fun AB0403Async(@Body bean: TermDepositDetailsInfoBean): BasicBean<List<TermDepositDetails>?>

    // 通知預金明細取得
    @POST("v2/apigw/e-passbook/AB0405")
    suspend fun AB0405Async(@Body bean: TermDepositDetailsInfoBean): BasicBean<MBDP1101ResponseBean>
}

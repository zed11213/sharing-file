package jp.co.jsbank.mb.bankingapp.repositories.api.request.refresh

import jp.co.jsbank.mb.bankingapp.bean.common.RefreshRequestBean
import jp.co.jsbank.mb.bankingapp.bean.common.RefreshResponseBean
import retrofit2.http.Body
import retrofit2.http.POST

/**
 * Httpサービス
 */
interface RefreshRestService {

    // 認可コードのリフレッシュ処理を実施する
    @POST("/jag/az0913")
    suspend fun AZ0913(
        @Body body: RefreshRequestBean
    ): RefreshResponseBean
}

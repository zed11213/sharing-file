package jp.co.jsbank.mb.bankingapp.repositories.api.request.gateway

import jp.co.jsbank.mb.bankingapp.bean.splash.mbco6201.*
import retrofit2.http.Body
import retrofit2.http.POST

/**
 * Httpサービス
 */
interface GatewayRestService {

    /* ====================JAG / Johnan API Gateway========================== */
    // 公開鍵登録
    @POST("/v2/jag/az0901")
    suspend fun AZ0901(
        @Body body: MBCO6201RequestBean
    ): AZ0901ResponseEntity

    // 公開鍵更新
    @POST("/v2/jag/az0903")
    suspend fun AZ0903(
        @Body body: MBCO6201RequestBean
    ): AZ0903ResponseEntity

    // TCC確定
    @POST("/v2/jag/az0906")
    suspend fun AZ0906(
        @Body body: MBCO6201RequestBean
    ): String

    // 認可コード取得
    @POST("/v2/jag/az0911")
    suspend fun AZ0911(
        @Body body: MBCO6201RequestBean
    ): AZ0911ResponseEntity

    // 認可コード更新
    @POST("/v2/jag/az0913")
    suspend fun AZ0913(
        @Body body: MBCO6201RequestBean
    ): AZ0913ResponseEntity
}

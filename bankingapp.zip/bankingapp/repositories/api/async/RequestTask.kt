package jp.co.jsbank.mb.bankingapp.repositories.api.async

import android.util.Log

class RequestTask(
    val id: String,
    val groupId: String,
    private val job: suspend () -> Any?
) {
    val TAG : String = "Task"
    var isRunning = false
    suspend fun execute(): Boolean {
        try {
            //Log.i(TAG, "Task<$id> start")
            job()
            //Log.i(TAG, "Task<$id> end")
            return true
            
        } catch (e: Exception) {
            var error = e.message ?: "予期せぬエラー"
            Log.e(TAG, "Task<$id> エラー: $error")
            throw e
        }
    }
}

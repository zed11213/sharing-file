package jp.co.jsbank.mb.bankingapp.repositories.api.async

import java.util.concurrent.atomic.AtomicInteger

class RequestTaskGroup{
    var id: String = ""
    val tasks: MutableList<RequestTask> = mutableListOf()
    var finished: AtomicInteger = AtomicInteger(0)
    var size : Int = 0

    fun onTaskFinished(){
        finished.set(finished.get()+1)
    }
}

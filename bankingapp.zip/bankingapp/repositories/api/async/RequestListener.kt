package jp.co.jsbank.mb.bankingapp.repositories.api.async

interface RequestListener {
    fun onRequestFinished(groupId: String, taskId: String, finish:Int , total: Int)
    fun onRequestFailed(groupId: String, taskId: String, errorMsg: String)
}

package jp.co.jsbank.mb.bankingapp.repositories.api.async

import android.util.Log
import jp.co.jsbank.mb.bankingapp.utils.StopWatch
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import java.lang.Thread.sleep
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.BlockingQueue
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicBoolean

class SchedulerManager : TaskListener{

    val TAG = "SchedulerManager"
    val maxConcurrency: Int = 5
    val waitingTaskGroups : BlockingQueue<RequestTaskGroup> = ArrayBlockingQueue(100)
    val runningTasks : MutableList<RequestTask> = CopyOnWriteArrayList()
    val runningTaskGroups : MutableList<RequestTaskGroup> = CopyOnWriteArrayList()
    val taskListeners : ConcurrentHashMap<String, RequestListener> = ConcurrentHashMap()

    private var _isRunning = AtomicBoolean(false)

    private val taskMutex: Mutex = Mutex()
    private val jobMutex: Mutex = Mutex()
    private var schedulerJob: Job? = null
    private var workerJob: Job? = null
    private val semaphore = Semaphore(maxConcurrency)
    private val activeJobs = mutableListOf<Job>()

    fun start() {
        //Log.i(TAG,"start")
        if (_isRunning.get()) {
            return
        }
        _isRunning.set(true)

        schedulerJob = CoroutineScope(Dispatchers.IO).async {
            schedulerLoop()
        }

        try {
            workerJob = CoroutineScope(Dispatchers.IO).async {
                workerJob()
            }

        } catch (e: Exception) {
            _isRunning.set(false)
        }
    }

    fun stop() {
        if (!_isRunning.get()) {
            return
        }
        
        _isRunning.set(false)

        schedulerJob?.cancel()
        schedulerJob = null

        workerJob?.cancel()
        workerJob = null

        runningTasks.clear()
    }

    private suspend fun schedulerLoop() {
        var isRunning = true
        while (isRunning && _isRunning.get()) {
            while (runningTasks.size < maxConcurrency) {
                val task = getNextTask()
                if (task != null){
                    addIdleTask(task)
                }  else {
                    isRunning = false
                    break
                    //Log.i(TAG,"待つタスクはありません")
                }
            }

            try {
                delay(50)
            } catch (e: Exception) {
                _isRunning.set(false)
            }
        }
    }

    private suspend fun workerJob() {
        //Log.i(TAG,"workerJob start")
        try {
            while (_isRunning.get()) {
                var tasks = getIdleTasks()
//                //Log.i(TAG,"get idle tasks = ${tasks.size}")
                if (tasks.isNotEmpty()) {
                    tasks.forEach { task ->
                        task.isRunning = true
                        val listener = this@SchedulerManager
                        val job = CoroutineScope(Dispatchers.IO).async {
                            executeTaskConcurrent(task, listener)
                        }
                        jobMutex.withLock {
                            activeJobs.add(job)
                        }
                    }

                } else {
                    //Log.i(TAG,"${runningTasks.size} tasks is running")
                    sleep(100)
                    jobMutex.withLock {
                        activeJobs.removeIf { job ->
                            job.isCompleted || job.isCancelled
                        }
                    }
                }
            }
        } catch (e: Exception) {
            _isRunning.set(false)
            runningTasks.forEach { task ->
                runningTasks.remove(task)
            }

            jobMutex.withLock {
                activeJobs.forEach { it.cancel() }
            }
        }
    }
    private suspend fun getIdleTasks(): MutableList<RequestTask> {
        return taskMutex.withLock {
            runningTasks.filter { t ->
                t.isRunning == false
            }.toMutableList()
        }
    }
    private suspend fun addIdleTask(task: RequestTask){
        //Log.i(TAG,"addIdleTask group:<${task.groupId}> task:<${task.id}>")
        return taskMutex.withLock {
            runningTasks.add(task)
        }
    }
    private suspend fun removeTask(task: RequestTask){
        return taskMutex.withLock {
            runningTasks.remove(task)
        }
    }

    private fun getNextTask(): RequestTask? {
        var group = runningTaskGroups.firstOrNull { it ->
            it.tasks.isNotEmpty()
        }
        if (group != null) {
            return group.tasks.removeAt(0)
        }else {
            group = waitingTaskGroups.poll()
            StopWatch.time("${group.id} 開始")
            if (group != null) {
                val task =  group.tasks.removeAt(0);
                runningTaskGroups.add(group)
                return task
            } else {
                return null
            }
        }
    }

    private suspend fun executeTaskConcurrent(task: RequestTask, listener: TaskListener ) {
        //Log.i(TAG,"executeTaskConcurrent")
        semaphore.acquire()
        try {
            task.execute()
            removeTask(task)
            listener.onSuccess(task.groupId,task.id)

        } catch (e: Exception) {
            removeTask(task)
            listener.onFailed(task.groupId,task.id, e.message.toString())
            throw e
        } finally {
            semaphore.release()
        }
    }

    fun putTaskGroup(taskGroup: RequestTaskGroup, listener: RequestListener) {
        waitingTaskGroups.put(taskGroup)
        taskListeners[taskGroup.id] = listener
    }

    override fun onSuccess(groupId: String, taskId: String) {
        //Log.i("TaskRequest","onSuccess group = $groupId task = $taskId")
        val group = runningTaskGroups.firstOrNull { group ->
            group.id == groupId
        }

        if (group != null) {
            group.onTaskFinished()
            taskListeners[groupId]?.onRequestFinished(groupId, taskId, group.finished.get(), group.size)
            if (group.finished.get() == group.size) {
                runningTaskGroups.remove(group)
                StopWatch.time("${group.id} 終了")
                if (runningTaskGroups.isEmpty() && waitingTaskGroups.isEmpty()){
                    StopWatch.end("${group.id} 計測終了")
                    stop()
                }
            }
        }
    }

    override fun onFailed(groupId: String, taskId: String, errorMsg: String) {
        taskListeners[groupId]?.onRequestFailed(groupId, taskId, errorMsg)
        stop()
    }
}


interface TaskListener {
    fun onSuccess(groupId: String, taskId: String)
    fun onFailed(groupId: String, taskId: String, errorMsg: String)
}

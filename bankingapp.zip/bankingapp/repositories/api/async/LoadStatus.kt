package jp.co.jsbank.mb.bankingapp.repositories.api.async

enum class LoadStatus {
    NONE,
    LOADING,
    COMPLETE,
    ERROR
}

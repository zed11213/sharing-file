package jp.co.jsbank.mb.bankingapp.ui.widgets.dropDown

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.material.DropdownMenu
import androidx.compose.material.DropdownMenuItem
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.bean.common.CodeBean
import jp.co.jsbank.mb.bankingapp.system.MyApp.Companion.SCREEN_HEIGHT
import jp.co.jsbank.mb.bankingapp.system.MyApp.Companion.SCREEN_WIDTH
import jp.co.jsbank.mb.bankingapp.theme.H6
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.click
import org.jetbrains.annotations.NotNull

@Composable
fun DropDownWidget(
    @NotNull value: String,
    @NotNull itemList: List<CodeBean> = listOf(),
    placeholder: String = "",
    isError: Boolean = false,
    isNoChoice: Boolean = true,
    backGround: Color = Color(0x1AE84F4F),
    enabled: Boolean = true,
    @NotNull onClick: (CodeBean) -> Unit,
) {
    val input = remember(value) { mutableStateOf(value) }
    val expanded = remember { mutableStateOf(false) }
    val newItemList: MutableList<CodeBean> = mutableListOf()
    if (isNoChoice) {
        newItemList.add(CodeBean(code = "", value = "選択なし"))
    }

    newItemList.addAll(itemList)

    Column(
        modifier = Modifier
            .fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 0.dp)
                .background(
                    if (input.value.isBlank()) backGround
                    else Color(0xFFF5F5F5)
                )
                .border(
                    BorderStroke(
                        1.dp,
                        color = if (isError) Color.Red else Color.White
                    )
                )
                .click {
                    if (newItemList.size > 1 && enabled) {
                        expanded.value = true
                    }
                },
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = value.ifEmpty { placeholder },
                fontSize = H6,
                color = Color(0xFF121212),
                modifier = Modifier.padding(vertical = 20.dp, horizontal = 15.dp)
            )
            Text(
                text = stringResource(id = R.string.common_right_arrow),
                fontSize = H6,
                color = Color(0xFF121212),
                modifier = Modifier
                    .padding(vertical = 10.dp, horizontal = 15.dp)
                    .rotate(90.0f)
            )
        }
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 0.dp)
        ) {
            DropdownMenu(
                modifier = Modifier
                    .width((SCREEN_WIDTH - 40).dp)
                    .height((SCREEN_HEIGHT / 2).dp),
                expanded = expanded.value,
                onDismissRequest = { expanded.value = false },
            ) {
                newItemList.forEachIndexed { index, _ ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 0.dp)
                    ) {
                        DropdownMenuItem(
                            onClick = {
                                expanded.value = false
                                onClick.invoke(
                                    if (newItemList[index].code.isBlank()) {
                                        CodeBean(code = "", value = "")
                                    } else {
                                        newItemList[index]
                                    }
                                )
                            },
                        ) {
                            Text(text = newItemList[index].value, modifier = Modifier.fillMaxWidth())
                        }
                    }
                }
            }
        }
    }
}

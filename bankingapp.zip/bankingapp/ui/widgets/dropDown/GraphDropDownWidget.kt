package jp.co.jsbank.mb.bankingapp.ui.widgets.dropDown

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material.DropdownMenu
import androidx.compose.material.DropdownMenuItem
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.bean.common.CodeBean
import jp.co.jsbank.mb.bankingapp.system.MyApp.Companion.SCREEN_HEIGHT
import jp.co.jsbank.mb.bankingapp.system.MyApp.Companion.SCREEN_WIDTH
import jp.co.jsbank.mb.bankingapp.theme.H5
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.click
import org.jetbrains.annotations.NotNull

@Composable
fun GraphDropDownWidget(
    @NotNull value: String,
    @NotNull itemList: List<CodeBean> = listOf(),
    placeholder: String = "",
    backGround: Color = Color(0x1AE84F4F),
    selectedBackGround: Color = Color(0xFFF5F5F5),
    selectedTextColor: Color = Color.White,
    @NotNull onClick: (CodeBean) -> Unit,
) {
    val input = remember { mutableStateOf(value) }
    val expanded = remember { mutableStateOf(false) }
    Column(
        modifier = Modifier
            .fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    if (input.value.isBlank()) backGround
                    else selectedBackGround
                )
                .click {
                    expanded.value = true
                },
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier.weight(1.5f),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = value.ifEmpty { placeholder },
                    fontSize = H5,
                    color = selectedTextColor,
                    modifier = Modifier.padding(vertical = 10.dp, horizontal = 0.dp)
                )
            }
            Column(
                modifier = Modifier.weight(0.2f),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Image(
                    contentScale = ContentScale.Fit,
                    painter = painterResource(id = R.drawable.drop_down),
                    contentDescription = ""
                )
            }
        }
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 0.dp)
        ) {
            DropdownMenu(
                modifier = Modifier
                    .width(SCREEN_WIDTH.dp)
                    .height(
                        if ((55 * itemList.size) > (SCREEN_HEIGHT / 2))
                            (SCREEN_HEIGHT / 2).dp else (55 * itemList.size).dp
                    ),
                expanded = expanded.value,
                onDismissRequest = { expanded.value = false },
            ) {
                itemList.forEachIndexed { index, _ ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .padding(horizontal = 0.dp)
                    ) {
                        DropdownMenuItem(
                            onClick = {
                                expanded.value = false
                                onClick.invoke(itemList[index])
                            },
                        ) {
                            Text(
                                text = itemList[index].value,
                                modifier = Modifier.fillMaxWidth(),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }
}

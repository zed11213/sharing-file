package jp.co.jsbank.mb.bankingapp.ui.widgets.webview

import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.graphics.Bitmap
import android.net.http.SslError
import android.webkit.*
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.system.MyApp
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.CHARSET_UTF_8
import jp.co.jsbank.mb.bankingapp.utils.MessageReplaceUtils
import jp.co.jsbank.mb.bankingapp.utils.POPWindowsUtil
import jp.co.jsbank.mb.bankingapp.utils.WebBrowserUtil
import java.security.InvalidKeyException
import java.security.NoSuchAlgorithmException
import java.security.NoSuchProviderException
import java.security.SignatureException
import java.security.cert.CertificateException

@SuppressLint("UseCompatLoadingForDrawables", "SetJavaScriptEnabled")
@Composable
fun WebView(
    url: String,
    type: Boolean = false
) {
    lateinit var webView: WebView
    Box {
        AndroidView(
            factory = { context ->
                webView = WebView(context)
                webView.apply {
                    settings.javaScriptEnabled = true
                    settings.useWideViewPort = true
                    settings.loadWithOverviewMode = true
                    settings.setSupportZoom(false)
                    settings.builtInZoomControls = true
                    settings.displayZoomControls = false
                    settings.allowFileAccess = true
                    settings.javaScriptCanOpenWindowsAutomatically = true
                    settings.loadsImagesAutomatically = true
                    settings.defaultTextEncodingName = CHARSET_UTF_8
//                    webViewClient = object : WebViewClient() {}
                    val extraHeaders: MutableMap<String, String> = HashMap()
                    extraHeaders["X-Jsbank-Key"] = "jsapp.js-system.jp"
                    loadUrl(url, extraHeaders)
                }
            },
            modifier = Modifier.fillMaxSize(),
            update = { webView ->
                webView.webViewClient = object : WebViewClient() {
                    override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                        super.onPageStarted(view, url, favicon)
                    }

                    override fun onPageFinished(view: WebView?, url: String?) {
                        super.onPageFinished(view, url)
                    }

                    override fun onReceivedError(
                        view: WebView?,
                        request: WebResourceRequest?,
                        error: WebResourceError?
                    ) {
                        super.onReceivedError(view, request, error)
                    }

                    @SuppressLint("WebViewClientOnReceivedSslError")
                    override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler, error: SslError) {
                        try {
                            val errorMsg = MessageReplaceUtils.messageReplace(
                                MyApp.CONTEXT.getString(R.string.JAG_MSG_ID_CD20),
                                ConstUtil.APP_ERROR_CODE_MBLO0006
                            )
                            POPWindowsUtil.postValue(errorMsg)
                            handler.cancel()
                        } catch (e: CertificateException) {
                            handler.cancel()
                        } catch (e: NoSuchAlgorithmException) {
                            handler.cancel()
                        } catch (e: InvalidKeyException) {
                            handler.cancel()
                        } catch (e: NoSuchProviderException) {
                            handler.cancel()
                        } catch (e: SignatureException) {
                            handler.cancel()
                        }
                    }

                    override fun shouldOverrideUrlLoading(view: WebView, strUrl: String): Boolean {
                        try {
                            // ブラウザ起動
                            WebBrowserUtil().setWebUrl(strUrl)
                        } catch (e: ActivityNotFoundException) {
                            val errorMsg = MessageReplaceUtils.messageReplace(
                                MyApp.CONTEXT.getString(R.string.JAG_MSG_ID_CD20),
                                ConstUtil.APP_ERROR_CODE_MBLO0006
                            )
                            POPWindowsUtil.postValue(errorMsg)
                        }
                        return true
                    }
                }
            }
        )
    }
}

package jp.co.jsbank.mb.bankingapp.ui.widgets.banner

import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import coil.compose.rememberImagePainter
import com.google.accompanist.pager.ExperimentalPagerApi
import com.google.accompanist.pager.HorizontalPager
import com.google.accompanist.pager.PagerState
import jp.co.jsbank.mb.bankingapp.bean.common.BannerBean

/**
 * Banner
 *
 * @param pagerState　Banner状態
 * @param pageList ページリスト
 */
@ExperimentalPagerApi
@Composable
fun Banner(
    pagerState: PagerState,
    pageList: List<BannerBean>,
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
    ) {

        // アニメーション実行のリスニング
        var executeChangePage by remember { mutableStateOf(false) }
        var currentPageIndex = 0

        // banner
        HorizontalPager(
            count = pageList.size,
            state = pagerState,
            modifier = Modifier
                .pointerInput(pagerState.currentPage) {
                    awaitPointerEventScope {
                        while (true) {
                            // PointerEventPass.Initial - ジェスチャーを優先的に処理し、処理後サブアセンブリに渡す
                            val event = awaitPointerEvent(PointerEventPass.Initial)
                            // 最初に押した指を取得
                            val dragEvent = event.changes.firstOrNull()
                            when {
                                // 現在の移動ジェスチャーが消費されているかどうか
                                dragEvent!!.positionChangeConsumed() -> {
                                    return@awaitPointerEventScope
                                }
                                // すでに押されているかどうか(ジェスチャーが押されて消費されているマークを無視)
                                dragEvent.changedToDownIgnoreConsumed() -> {
                                    // 現在のページインデックス値を記録
                                    currentPageIndex = pagerState.currentPage
                                }
                                // 持ち上げたかどうか(ジェスチャーを押して消費したマークを無視)
                                dragEvent.changedToUpIgnoreConsumed() -> {
                                    // ページにスクロール/アニメーションがない場合pagerState.targetPageはnullです。
                                    // このときはイベントをクリックします。
                                    if (pagerState.targetPage == null) return@awaitPointerEventScope
                                    // pageCountが1より大きく、指が上がったときにページが変わらない場合は、
                                    // 手動でアニメーションをトリガーします
                                    if (currentPageIndex == pagerState.currentPage &&
                                        pagerState.pageCount > 1
                                    ) {
                                        executeChangePage = !executeChangePage
                                    }
                                }
                            }
                        }
                    }
                }
                .fillMaxSize(),
            verticalAlignment = Alignment.Bottom,
        ) { page ->
            Column(modifier = Modifier.fillMaxSize()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(0.5f)
                        .background(Color(0x1ACE3F52)),
                ) {
                    Image(
                        painter = rememberImagePainter(pageList[page].imageId),
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop,
                        contentDescription = null
                    )
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(0.3f)
                ) {
                    pageList[page].content()
                }

                Box(
                    modifier = Modifier
                        .align(Alignment.CenterHorizontally)
                        .padding(vertical = 10.dp)
                ) {
                    // 指示点
                    Row(
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        for (i in pageList.indices) {
                            // サイズ
                            var size by remember { mutableStateOf(5.dp) }
                            size = if (pagerState.currentPage == i) 7.dp else 5.dp

                            // 色
                            val color =
                                if (pagerState.currentPage == i) Color.Black else Color.Gray

                            Box(
                                modifier = Modifier
                                    .clip(CircleShape)
                                    .background(color)
                                    // サイズが変わるとアニメーションの形で変わります
                                    .animateContentSize()
                                    .size(size)
                            )
                            // 指示点間の間隔
                            if (i != pageList.lastIndex) Spacer(
                                modifier = Modifier
                                    .height(0.dp)
                                    .width(4.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

package jp.co.jsbank.mb.bankingapp.ui.widgets.select

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.theme.*
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.click

/**
 * ファイル授受サービスのお申し込みタイプ選択
 *
 * @param selectedType 選択されたタイプ ("0": お申込, "1": ご利用停止, "": 未選択)
 * @param onTypeSelected タイプが選択された時のコールバック
 * @param enabled 有効/無効フラグ（デフォルト: true）
 */
@Composable
fun FileServiceStatusRadioButton(
    selectedType: String,
    onTypeSelected: (String) -> Unit = {},
    enabled: Boolean = true
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        Text(
            text = stringResource(id = R.string.mbrc0202_page_label_file_service_type),
            color = general_label_color,
            fontSize = H7
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(24.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // お申込選択肢
            FileServiceRadioButtonItem(
                text = stringResource(id = R.string.mbrc0202_page_label_file_service_apply),
                isSelected = selectedType == "0",
                onClick = { onTypeSelected("0") },
                enabled = enabled
            )
            // ご利用停止選択肢
            FileServiceRadioButtonItem(
                text = stringResource(id = R.string.mbrc0202_page_label_file_service_stop),
                isSelected = selectedType == "1",
                onClick = { onTypeSelected("1") },
                enabled = enabled
            )
        }
    }
}

/**
 * 汎用ラジオボタン項目
 *
 * @param text 表示テキスト
 * @param isSelected 選択状態
 * @param onClick クリック時のコールバック
 * @param enabled 有効/無効フラグ（デフォルト: true）
 */
@Composable
private fun FileServiceRadioButtonItem(
    text: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    enabled: Boolean = true
) {
    val borderColor = if (isSelected) radio_button_select_bg_color else Color.Gray
    val fillColor = radio_button_select_bg_color

    Row(
        modifier = if (enabled) Modifier.click { onClick() } else Modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Box(
            modifier = Modifier
                .size(16.dp)
                .border(
                    width = 1.dp,
                    color = borderColor,
                    shape = CircleShape
                ),
            contentAlignment = Alignment.Center
        ) {
            if (isSelected) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .background(
                            color = fillColor,
                            shape = CircleShape
                        )
                )
            }
        }
        Text(
            text = text,
            color = general_label_color,
            fontSize = H7
        )
    }
}

package jp.co.jsbank.mb.bankingapp.ui.widgets.select

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.material.Icon
import androidx.compose.material.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.theme.*
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.click
import org.jetbrains.annotations.NotNull

/**
 * 店舗選択ボックス
 *
 * @param value 選択の内容
 * @param placeholder 選択が空のときに表示されるオプションのプレースホルダ
 * @return 選択ボックス
 */
@Composable
fun ShopSelectWidget(
    @NotNull value: String,
    placeholder: String = "",
    isError: Boolean = false,
    backGround: Color = Color(0x1AE84F4F),
    @NotNull onClick: () -> Unit,
    onClear: () -> Unit = {},
) {
    val input = remember {
        mutableStateOf(value)
    }

    // valueが変更されたらinputも更新
    LaunchedEffect(value) {
        if (input.value != value) {
            input.value = value
        }
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 0.dp)
            .background(
                if (value.isBlank()) backGround
                else Color(0xFFF5F5F5)
            )
            .border(
                BorderStroke(
                    1.dp,
                    color = if (isError) Color(0xFFFF003B) else Color.White
                )
            )
            .click {
                onClick.invoke()
            },
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = value.ifEmpty { placeholder },
            fontSize = H6,
            color = Color(0xFF121212),
            modifier = Modifier.padding(vertical = 20.dp, horizontal = 15.dp)
        )
        if (value.isNotEmpty()) {
            Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "",
                tint = inactive_button_bg_color,
                modifier = Modifier
                    .padding(horizontal = 15.dp)
                    .click {
                        input.value = ""
                        onClear.invoke()
                    },
            )
        } else {
            Text(
                text = stringResource(id = R.string.common_right_arrow),
                fontSize = H6,
                color = Color(0xFF121212),
                modifier = Modifier.padding(horizontal = 15.dp)
            )
        }
    }
}

/**
 * 店舗選択ボックス
 *
 * @param value 選択の内容
 * @param enabled　有効状態
 * @return 選択ボックス
 */
@Composable
fun DateSelectWidget(
    @NotNull value: String,
    enabled: Boolean = true,
    disabledShowValue: Boolean = false,
    isError: Boolean = false,
    @NotNull onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxSize()
            .padding(0.dp, 0.dp, 0.dp, 0.dp)
            .background(
                if (enabled) input_frame_background_color else date_select_disable_bg_color
            )
            .border(
                BorderStroke(
                    1.dp,
                    color = if (isError) Color(0xFFFF003B) else Color.White
                )
            )
            .click {
                if (enabled) onClick.invoke()
            },
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = if (enabled || disabledShowValue) value else "",
            fontSize = H6,
            color = general_label_color,
            modifier = Modifier
                .padding(horizontal = 15.dp)
        )
        if (enabled)
            Text(
                text = stringResource(id = R.string.common_right_arrow),
                fontSize = H6,
                color = general_label_color,
                modifier = Modifier
                    .padding(horizontal = 15.dp)
                    .rotate(90.0f)
            )
    }
}

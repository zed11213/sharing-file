package jp.co.jsbank.mb.bankingapp.ui.widgets.button

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Button
import androidx.compose.material.ButtonDefaults
import androidx.compose.material.Card
import androidx.compose.material.IconButton
import androidx.compose.material.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.theme.*
import jp.co.jsbank.mb.bankingapp.utils.ToContinuousHitPrevention
import jp.co.jsbank.mb.bankingapp.utils.ToLoginUtil
import kotlinx.coroutines.launch

/**
 * ベースボタン.
 *
 * @param width 幅
 * @param modifier 修飾子
 * @param text ボタン名称
 * @param bgColor 背景色
 * @param textColor ラベル色
 * @param onClick ロールバック
 */
@Composable
fun AppButton(
    width: Float = 1f,
    modifier: Modifier = Modifier,
    text: String,
    bgColor: Color = Color.White,
    textColor: Color = Color.Black,
    fontSize: TextUnit = 18.sp,
    time: Int = VIEW_CLICK_INTERVAL_TIME,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(30.dp),
        elevation = 10.dp,
        modifier = modifier
            .wrapContentHeight()
            .fillMaxWidth(width)
    ) {
        Box(
            Modifier
                .background(color = bgColor)
                .fillMaxWidth()
                .click(time = time) {
                    onClick.invoke()
                }
        ) {
            Text(
                text = text,
                Modifier
                    .padding(8.dp, 15.dp, 8.dp, 15.dp)
                    .align(Alignment.Center),
                fontSize = fontSize,
                maxLines = 1,
                color = textColor,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                fontFamily = FontFamily.SansSerif
            )
        }
    }
}

@Composable
fun AppButton2nd(
    width: Float = 1f,
    modifier: Modifier = Modifier,
    text: String,
    bgColor: Color = Color.White,
    textColor: Color = Color.Black,
    fontSize: TextUnit = 18.sp,
    onClick: () -> Unit,
    enabled: Boolean,
    time: Int = VIEW_CLICK_INTERVAL_TIME
) {
    Card(
        shape = RoundedCornerShape(30.dp),
        elevation = 10.dp,
        modifier = modifier
            .wrapContentHeight()
            .fillMaxWidth(width)
    ) {
        Box(
            Modifier
                .background(color = bgColor)
                .fillMaxWidth()
                .click(enabled = enabled, time = time) {
                    onClick.invoke()
                }
        ) {
            Text(
                text = text,
                Modifier
                    .padding(8.dp, 15.dp, 8.dp, 15.dp)
                    .align(Alignment.Center),
                fontSize = fontSize,
                maxLines = 1,
                color = textColor,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                fontFamily = FontFamily.SansSerif
            )
        }
    }
}

/**
 * 連打防止ボタン(プライマリーボタンver.)
 *
 * @param text ボタン名称
 * @param modifier 修飾子
 * @param width 幅
 * @param onClick ロールバック
 */
@Composable
fun HitPreventionButton(
    text: String,
    modifier: Modifier = Modifier,
    width: Float = 1f,
    bgColor: Color = AppTheme.colors.buttonPrimaryColor,
    fontSize: TextUnit = 18.sp,
    time: Int = VIEW_CLICK_INTERVAL_TIME,
    onClick: () -> Unit
) {
    val sending by ToContinuousHitPrevention.sending
    AppButton2nd(
        text = text,
        modifier = modifier,
        width = width,
        textColor = Color(0xFFFFFFFF),
        fontSize = fontSize,
        onClick = onClick,
        bgColor = bgColor,
        enabled = sending,
        time = time
    )
}

/**
 * プライマリーボタン.
 *
 * @param text ボタン名称
 * @param modifier 修飾子
 * @param width 幅
 * @param waitNextFrame テキストフィールドの文字変換のため、1フレームを待って
 * @param onClick ロールバック
 */
@Composable
fun PrimaryButton(
    text: String,
    modifier: Modifier = Modifier,
    width: Float = 1f,
    bgColor: Color = AppTheme.colors.buttonPrimaryColor,
    fontSize: TextUnit = 18.sp,
    time: Int = VIEW_CLICK_INTERVAL_TIME,
    waitNextFrame: Boolean = false,
    onClick: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val focusManager = LocalFocusManager.current
    AppButton(
        text = text,
        modifier = modifier,
        width = width,
        textColor = Color(0xFFFFFFFF),
        fontSize = fontSize,
        bgColor = bgColor,
        time = time,
        onClick = {
            focusManager.clearFocus()  //クリックする際にまずキーボードを閉じます
            scope.launch {
                if (waitNextFrame) {
                    withFrameNanos {  }
                }
                onClick()
            }
        }

    )
}

/**
 * 青ボタン.
 *
 * @param text ボタン名称
 * @param modifier 修飾子
 * @param width 幅
 * @param onClick ロールバック
 */
@Composable
fun SecondButton(
    text: String,
    modifier: Modifier = Modifier,
    width: Float = 1f,
    fontSize: TextUnit = 18.sp,
    onClick: () -> Unit
) {
    AppButton(
        text = text,
        modifier = modifier,
        width = width,
        textColor = Color(0xFFFFFFFF),
        onClick = onClick,
        fontSize = fontSize,
        bgColor = Color(0xFF013C6E)
    )
}

/**
 * パスワードボタン.
 *
 * @param text ボタン名称
 * @param modifier 修飾子
 * @param onClick ロールバック
 */
@Composable
fun PasswordButton(
    text: String,
    modifier: Modifier = Modifier,
    onClick: (String) -> Unit
) {
    val sending by ToLoginUtil.sending
    Button(
        shape = RoundedCornerShape(100),
        colors = ButtonDefaults.textButtonColors(
            backgroundColor = Color.White,
            disabledContentColor = Color.White
        ),
        modifier = modifier,
        enabled = sending,
        onClick = { onClick.invoke(text) }
    ) {
        Text(
                text = text,
//                Modifier
//                    .padding(8.dp, 8.dp, 8.dp, 8.dp),
                fontSize = 28.sp,
                color = Color.Black,
                textAlign = TextAlign.Center,
                fontWeight = FontWeight.Bold,
            )
    }
}

/**
 * アイコンボタン.
 *
 * @param leftText 左側ボタン表示名称
 * @param rightText 右側ボタン表示名称
 * @param image 画像Id
 * @param imageSize 画像サイズ
 * @param textColor 文字列色
 * @param modifier 修飾子
 * @param onClick ロールバック
 */
@Composable
fun IconButton(
    leftText: String = "",
    rightText: String = "",
    textSize: TextUnit = 14.sp,
    image: Int,
    imageSize: Dp = 30.dp,
    textColor: Color = Color(0xFFCE3F52),
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    IconButton(
        onClick = composeClick {
            onClick.invoke()
        },
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = modifier) {
            if (leftText.isNotBlank()) {
                Text(text = leftText, fontSize = textSize, modifier = Modifier.padding(end = 5.dp), color = textColor)
            }
            Image(
                contentScale = ContentScale.Fit,
                modifier = Modifier.size(imageSize),
                painter = painterResource(id = image),
                contentDescription = ""
            )
            if (rightText.isNotBlank()) {
                Text(
                    text = rightText,
                    fontSize = textSize,
                    modifier = Modifier.padding(start = 5.dp),
                    color = textColor
                )
            }
        }
    }
}

/**
 * アイコンボタン.
 *
 * @param text ボタン表示名称
 * @param leftImage 左側画像Id
 * @param leftImageSize 左側画像サイズ
 * @param rightImage 右側画像Id
 * @param rightImageSize 右側画像サイズ
 * @param textColor 文字列色
 * @param modifier 修飾子
 * @param onClick ロールバック
 */
@Composable
fun IconSecondButton(
    text: String = "",
    leftImage: Int,
    leftImageSize: Dp = 30.dp,
    rightImage: Int,
    rightImageSize: Dp = 30.dp,
    textColor: Color = Color(0xFFCE3F52),
    modifier: Modifier = Modifier,
    onClick: (String) -> Unit
) {
    IconButton(
        onClick = composeClick {
            onClick
        },
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(
                contentScale = ContentScale.Fit,
                modifier = Modifier.size(leftImageSize),
                painter = painterResource(id = leftImage),
                contentDescription = "image"
            )
            Text(
                text = text,
                fontSize = 16.sp,
                modifier = Modifier.padding(start = 5.dp, end = 5.dp),
                color = textColor
            )
            Image(
                contentScale = ContentScale.Fit,
                modifier = Modifier.size(rightImageSize),
                painter = painterResource(id = rightImage),
                contentDescription = ""
            )
        }
    }
}

/**
 * アイコンボタン.
 *
 * @param text ボタン表示名称
 * @param count お知らせ数
 * @param image 画像Id
 * @param imageSize 画像サイズ
 * @param textColor 文字列色
 * @param modifier 修飾子
 * @param onClick ロールバック
 */
@Composable
fun Icon3rdButton(
    text: String = "",
    count: Int = 0,
    image: Int,
    imageSize: Dp = 30.dp,
    textColor: Color = Color(0xFFCE3F52),
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    IconButton(
        onClick = composeClick {
            onClick.invoke()
        },
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .border(0.dp, Color(0xFFCE3F52), CircleShape)
                    .background(Color(0xFFCE3F52))
                    .align(Alignment.CenterVertically)
                    .wrapContentSize()
            ) {
                Text(
                    color = Color.White,
                    text = "$count",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .background(Color(0xFFCE3F52))
                        .align(Alignment.Center)
                        .padding(horizontal = 10.dp, vertical = 5.dp),
                )
            }
            Text(
                text = text,
                fontSize = 16.sp,
                modifier = Modifier.padding(horizontal = 5.dp),
                color = textColor
            )
            Image(
                contentScale = ContentScale.Fit,
                modifier = Modifier.size(imageSize),
                painter = painterResource(id = image),
                contentDescription = ""
            )
        }
    }
}

/**
 * 支店ボタン.
 *
 * @param text ボタン表示名称
 * @param textColor 文字列色
 * @param backgroundColor 背景色
 * @param modifier 修飾子
 * @param onClick ロールバック
 */
@Composable
fun BranchButton(
    text: String = "",
    textColor: Color = Color(0xFF000000),
    fontSize: TextUnit = 16.sp,
    backgroundColor: Color = Color(0xFFCE3F52),
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    IconButton(
        onClick = composeClick {
            onClick.invoke()
        },
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(100))
                    .background(backgroundColor)
                    .align(Alignment.CenterVertically)
                    .wrapContentSize()
            ) {
                Text(
                    color = textColor, text = text, fontSize = fontSize,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(horizontal = 10.dp, vertical = 10.dp),
                )
            }
        }
    }
}

/**
 * イメージボタン.
 *
 * @param text ボタン名称
 * @param modifier 修飾子
 * @param onClick ロールバック
 */
@Composable
fun ImageButton(
    image: Int,
    imageSize: Dp = 30.dp,
    backgroundColor: Color = Color(0xFFCE3F52),
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    IconButton(
        onClick = composeClick {
            onClick.invoke()
        },
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(100))
                    .background(backgroundColor)
                    .align(Alignment.CenterVertically)
                    .wrapContentSize()
                    .padding(10.dp)
            ) {
                Image(
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.size(imageSize),
                    painter = painterResource(id = image),
                    contentDescription = ""
                )
            }
        }
    }
}

/**
 * テキストボタン.
 *
 * @param text 表示名称
 * @param textColor 文字列色
 * @param modifier 修飾子
 * @param onClick ロールバック
 */
@Composable
fun SingleTextButton(
    text: String = "",
    textColor: Color = Color(0xFFCE3F52),
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    IconButton(
        onClick = composeClick {
            onClick.invoke()
        },
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(text = text, fontSize = 16.sp, modifier = Modifier.padding(end = 5.dp), color = textColor)
        }
    }
}

/**
 * お知らせボタン.
 *
 * @param text ボタン表示名称
 * @param textColor 文字列色
 * @param backgroundColor 背景色
 * @param onClick ロールバック
 */
@Composable
fun InfoListBranchButton(
    text: String = "",
    textColor: Color = Color(0xFF000000),
    fontSize: TextUnit = 16.sp,
    backgroundColor: Color = Color(0xFFCE3F52),
    onClick: () -> Unit
) {
    IconButton(
        onClick = composeClick {
            onClick.invoke()
        },
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(100))
                    .background(backgroundColor)
                    .align(Alignment.CenterVertically)
                    .wrapContentSize()
                    .width(110.dp)
            ) {
                Text(
                    color = textColor, text = text, fontSize = fontSize,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(horizontal = 10.dp, vertical = 10.dp),
                )
            }
        }
    }
}

/**
 * 浮動ボタン.
 *
 * @param text ボタン表示名称
 * @param size ボタンサイズ
 * @param onClick ロールバック
 */
@Composable
fun FloatingActionButton(
    text: String = "",
    size: Dp = 45.dp,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .click {
                onClick.invoke()
            },
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Image(
            contentScale = ContentScale.Fit,
            painter = painterResource(id = R.drawable.cinnamon_chat),
            contentDescription = "",
            modifier = Modifier.size(size)
        )
        Text(
            text = text,
            fontSize = 15.sp,
            color = Color(0xFFCE3F52),
            modifier = Modifier,
            letterSpacing = 0.1.sp
        )
    }
}

/**
 * サブNoボタン.
 *
 * @param text ボタン表示名称
 * @param textColor 文字列色
 * @param backgroundColor 背景色
 * @param modifier 修飾子
 * @param onClick ロールバック
 */
@Composable
fun SubNoButton(
    text: String = "",
    textColor: Color = Color(0xFF000000),
    fontSize: TextUnit = 16.sp,
    backgroundColor: Color = Color(0xFFCE3F52),
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    IconButton(
        onClick = composeClick {
            onClick.invoke()
        },
    ) {
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(100))
                .background(backgroundColor)
                .wrapContentSize()
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    color = textColor, text = "No", fontSize = 14.sp,
                    modifier = Modifier
                        .padding(12.dp, 6.dp, 0.dp, 6.dp)
                        .align(Alignment.Bottom),
                )
                Text(
                    color = textColor, text = text, fontSize = fontSize,
                    modifier = Modifier
                        .padding(2.dp, 6.dp, 12.dp, 6.dp),
                )
            }
        }
    }
}

const val VIEW_CLICK_INTERVAL_TIME = 800

inline fun Modifier.click(
    time: Int = VIEW_CLICK_INTERVAL_TIME,
    enabled: Boolean = true,
    onClickLabel: String? = null,
    role: Role? = null,
    crossinline onClick: () -> Unit
): Modifier = composed {
    var lastClickTime by remember { mutableStateOf(value = 0L) }
    clickable(enabled, onClickLabel, role) {
        val currentTimeMillis = System.currentTimeMillis()
        if (currentTimeMillis - time >= lastClickTime) {
            onClick()
            lastClickTime = currentTimeMillis
        }
    }
}

@Composable
inline fun composeClick(
    time: Int = VIEW_CLICK_INTERVAL_TIME,
    crossinline onClick: () -> Unit
): () -> Unit {
    var lastClickTime by remember { mutableStateOf(value = 0L) }
    return {
        val currentTimeMillis = System.currentTimeMillis()
        if (currentTimeMillis - time >= lastClickTime) {
            onClick()
            lastClickTime = currentTimeMillis
        }
    }
}

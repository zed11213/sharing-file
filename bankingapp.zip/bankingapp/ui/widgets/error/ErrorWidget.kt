package jp.co.jsbank.mb.bankingapp.ui.widgets.error

import androidx.annotation.Nullable
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.theme.H6

/**
 * 入力エラー.
 *
 */
@Composable
fun EditErrorWidget() {
    Row() {
        Text(
            modifier = Modifier.padding(5.dp, 5.dp, 5.dp, 5.dp),
            color = Color(0xFFCE3F52),
            text = stringResource(id = R.string.common_input_error_message),
            fontSize = H6
        )
    }
}

/**
 * エラー表示リストビュー.
 */
@Composable
fun EditErrorListWidget(errMsgList: List<String>) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(10.dp, 10.dp, 10.dp, 0.dp)
            .background(Color(0x1ACE3F52)),
    ) {
        EditErrorWidget()
        errMsgList.distinct().forEach {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = stringResource(id = R.string.common_label_dot),
                    color = Color(0xFFCE3F52),
                    modifier = Modifier.padding(0.dp, 5.dp, 0.dp, 10.dp).align(Alignment.Top)
                )
                Text(
                    modifier = Modifier.padding(5.dp, 5.dp, 5.dp, 10.dp),
                    color = Color(0xFFCE3F52),
                    text = it,
                    fontSize = H6
                )
            }
        }
    }
}

/**
 * 通信エラー.
 *
 */
@Composable
fun SignalErrorWidget(
    @Nullable message: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(10.dp, 10.dp, 10.dp, 0.dp)
            .border(
                BorderStroke(
                    1.dp,
                    color = Color(0xFFCE3F52)
                )
            ),
        horizontalArrangement = Arrangement.Center
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(5.dp, 5.dp, 5.dp, 5.dp),
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.Center
        ) {
            Image(
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .size(25.dp)
                    .padding(0.dp, 10.dp, 0.dp, 0.dp),
                painter = painterResource(id = R.drawable.simple_warning_icon),
                contentDescription = ""
            )
            Text(
                modifier = Modifier.padding(5.dp, 5.dp, 5.dp, 5.dp),
                color = Color(0xFFCE3F52),
                text = message,
                fontSize = H6
            )
        }
    }
}

package jp.co.jsbank.mb.bankingapp.ui.widgets.textField

import jp.co.jsbank.mb.bankingapp.utils.CharacterUtil

open class FullWidthInputWidget(
    value: String,
    placeholder: String = "",
    onChange: (String) -> Unit,
    enabled: Boolean = true,
    isError: Boolean = false,
    isOption: Boolean = false,
    maxLength: Int = Int.MAX_VALUE,
) : ComInputWidget(
    value = value,
    placeholder = placeholder,
    maxLength = maxLength,
    enabled = enabled,
    isError = isError,
    isOption = isOption,
    onChange = onChange,
    onImeAction = {}) {
    override fun appendConvertOptions() {
        // 全角変換
        convertOptions.add(CharacterUtil.ConvertType.ToFullWidth)
    }
}

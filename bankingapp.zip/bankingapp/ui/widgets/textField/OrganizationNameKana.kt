package jp.co.jsbank.mb.bankingapp.ui.widgets.textField

open class OrganizationNameKana(
    value: String,
    onChange: (String) -> Unit,
    enabled: Boolean = true,
    placeholder: String = "",
    isError: Boolean = false,
    isOption: Boolean = false,
    maxLength: Int = Int.MAX_VALUE,
    maxHalfLength: Int = Int.MAX_VALUE,
) : HalfWidthKanaInputWidget(
    value = value,
    placeholder = placeholder,
    maxLength = maxLength,
    maxHalfLength = maxHalfLength,
    onChange = onChange,
    isError = isError,
    isOption = isOption,
    enabled = enabled,
)

package jp.co.jsbank.mb.bankingapp.ui.widgets.textField

import jp.co.jsbank.mb.bankingapp.utils.CharacterUtil

/*
 *  号室(全角)
 *
 */

open class AddressRoom(
    value: String,
    onChange: (String) -> Unit,
    enabled: Boolean = true,
    placeholder: String = "",
    isError: Boolean = false,
    maxLength: Int = Int.MAX_VALUE,
) : Address(
    value = value,
    placeholder = placeholder,
    maxLength = maxLength,
    enabled = enabled,
    isError = isError,
    isOption = true,
    onChange = onChange,
) {
    override fun isContainInvalidCharacter(input: String): Boolean {
        return CharacterUtil.containsEmoji(input) || CharacterUtil.containsSpace(input)
    }

    override fun removeInvalidCharacter(input: String): String {
        return CharacterUtil.removeSpace(input)
    }
}



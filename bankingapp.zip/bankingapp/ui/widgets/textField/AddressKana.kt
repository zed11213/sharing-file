package jp.co.jsbank.mb.bankingapp.ui.widgets.textField

import jp.co.jsbank.mb.bankingapp.utils.CharacterUtil

/* 住所/(カナ)
 *
 */
open class AddressKana(
    value: String,
    onChange: (String) -> Unit,
    enabled: Boolean = true,
    placeholder: String = "",
    isError: Boolean = false,
    isOption: Boolean = false,
    maxLength: Int = Int.MAX_VALUE,
    maxHalfLength: Int = Int.MAX_VALUE,
) : HalfWidthKanaInputWidget(
    value = value,
    placeholder = placeholder,
    maxLength = maxLength,
    maxHalfLength = maxHalfLength,
    onChange = onChange,
    isError = isError,
    isOption = isOption,
    enabled = enabled,
    )

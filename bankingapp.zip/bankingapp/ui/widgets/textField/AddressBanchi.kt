package jp.co.jsbank.mb.bankingapp.ui.widgets.textField

import jp.co.jsbank.mb.bankingapp.utils.CharacterUtil
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil

// 番地(全角)
class AddressBanchi(
    value: String,
    onChange: (String) -> Unit,
    isError: Boolean = false,
    isOption: Boolean = false,
    maxLength: Int = Int.MAX_VALUE,
) : Address(
    value = value,
    placeholder = ConstUtil.PLACE_HOLDER_BANCHI,
    maxLength = maxLength,
    enabled = true,
    isError = isError,
    isOption = isOption,
    onChange = onChange,
) {
    override fun appendConvertOptions() {
       super.appendConvertOptions()
        // 全角長音をハイフンに変換
        convertOptions.add(CharacterUtil.ConvertType.FullMacronToHyphen)
    }

    override fun isContainInvalidCharacter(input: String): Boolean {
        return CharacterUtil.containsEmoji(input) || !CharacterUtil.containsNumberHyphenOnly(input)
    }

    override fun removeInvalidCharacter(input: String): String {
        return CharacterUtil.filterNumberHyphen(input)
    }
}

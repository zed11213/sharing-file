package jp.co.jsbank.mb.bankingapp.ui.widgets.textField

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.MaterialTheme
import androidx.compose.material.OutlinedTextField
import androidx.compose.material.Text
import androidx.compose.material.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusEvent
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import jp.co.jsbank.mb.bankingapp.theme.H6
import jp.co.jsbank.mb.bankingapp.utils.CharacterUtil
import jp.co.jsbank.mb.bankingapp.utils.CharacterUtil.ConvertType
import jp.co.jsbank.mb.bankingapp.utils.CharacterUtil.fullWidthHyphenToMacron
import jp.co.jsbank.mb.bankingapp.utils.CharacterUtil.fullWidthMacronToHyphen
import jp.co.jsbank.mb.bankingapp.utils.CharacterUtil.halfWidthMacronToHyphen
import jp.co.jsbank.mb.bankingapp.utils.HalfToFullUtils
import jp.co.jsbank.mb.bankingapp.utils.KanaUtil.toDbc
import jp.co.jsbank.mb.bankingapp.utils.KanaUtil.toSbc

open class ComInputWidget(
    val value: String,
    val placeholder: String = "",
    val onChange: (String) -> Unit,
    val enabled: Boolean = true,
    val isError: Boolean = false,
    val errMsg: String = "",
    val keyboardType: KeyboardType = KeyboardType.Text,
    val maxLines: Int = 1,
    val maxLength: Int = Int.MAX_VALUE,
    val minLength: Int = Int.MAX_VALUE,
    val unfocusedBorderColor: Color = Color.Transparent,
    val focusedBorderColor: Color = Color.Transparent,
    val cursorColor: Color = Color.Transparent,
    val fontSize: TextUnit = H6,
    val textAlign: TextAlign = TextAlign.Start,
    val isPassword: Boolean = false,
    val isOption: Boolean = false,
    val backgroundChange: Boolean = true,
    val maxHalfLength: Int = Int.MAX_VALUE,
    val onImeAction: () -> Unit,
) : AbstractInputWidget(), Buildable {

    override fun appendConvertOptions() {

    }

    override fun isHalfWidthOnly(): Boolean {
        return convertOptions.contains(ConvertType.ToHalfWidth)
    }

    override fun isContainInvalidCharacter(input: String): Boolean {
        return CharacterUtil.containsEmoji(input)
    }

    override fun removeInvalidCharacter(input: String): String {
        return input
    }

    @Composable
    override fun Build() {

        val input = remember(value) {
            mutableStateOf(value)
        }

        val focusedBackgroundColor = if (isOption) Color(0xFFF5F5F5) else Color(0x1AE84F4F)
        val unfocusedBackgroundColor = if (isOption) Color(0xFFF5F5F5) else Color(0x1AE84F4F)

        var background by remember {
            mutableStateOf(focusedBackgroundColor)
        }

        val localFocusManager = LocalFocusManager.current

        Column(Modifier.fillMaxWidth()) {
            OutlinedTextField(
                value = input.value,
                onValueChange = {
                    // 絵文字入力禁止
                    if (CharacterUtil.containsEmoji(input.value)) {
                        return@OutlinedTextField
                    }

                    if (isHalfWidthOnly()) {
                        if (HalfToFullUtils.fullToHalfChar(it).length <= maxHalfLength) {
                            input.value = it
                            onChange.invoke(input.value)
                        }
                    } else {
                        if (it.length <= maxLength) {
                            input.value = it
                            onChange.invoke(input.value)
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        BorderStroke(
                            1.dp,
                            color = if (isError) Color(0xFFFF003B) else Color.Transparent
                        )
                    )
                    .background(background)
                    .height(if (maxLines > 1) (maxLines * 25).dp else 55.dp)
                    .onFocusEvent {
                        background = if (it.isFocused) {
                            focusedBackgroundColor
                        } else {
                            if (input.value.isBlank() || !backgroundChange) unfocusedBackgroundColor
                            else Color(0xFFF5F5F5)
                        }

                        if (it.isFocused) {
                            return@onFocusEvent
                        }

                        if (input.value.isBlank()) {
                            return@onFocusEvent
                        }

                        // 入力禁止文字を外す(絵文字以外)
                        input.value = removeInvalidCharacter(input.value)

                        // 文字変換
                        if (convertOptions.isNotEmpty()) {
                            input.value = convertText(input.value, convertOptions)
                        }
                        onChange.invoke(input.value)
                    },
                enabled = enabled,
                placeholder = {
                    Text(
                        text = placeholder,
                        color = Color.Gray,
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = textAlign
                    )
                },
//            isError = isError,
                keyboardOptions = KeyboardOptions(
                    keyboardType = keyboardType,
                    imeAction = ImeAction.Done
                ),
                keyboardActions = KeyboardActions(
                    onDone = {
                        localFocusManager.clearFocus()
                        onImeAction()
                    },
                ),
                textStyle = TextStyle(fontSize = fontSize, textAlign = textAlign),
                maxLines = maxLines,
                shape = MaterialTheme.shapes.small,
                colors = TextFieldDefaults.outlinedTextFieldColors(
                    unfocusedBorderColor = unfocusedBorderColor,
                    focusedBorderColor = focusedBorderColor,
                    cursorColor = cursorColor,
                ),
                visualTransformation = if (isPassword)
                    PasswordVisualTransformation() else VisualTransformation.None
            )
        }
    }

    private fun convertText(input: String, convertOptions :List<ConvertType>, isDebug:Boolean = false): String{
        if (input.isBlank() || convertOptions.isEmpty()) {
            return input
        }
        var output = input
        for (opt in convertOptions) {
            output = when (opt) {
                ConvertType.ToFullWidth -> HalfToFullUtils.toFullWidth(output)
                ConvertType.ToHalfWidth -> HalfToFullUtils.toHalfWidth(output)
                ConvertType.ToHalfPeriod -> CharacterUtil.toHalfPeriod(output)
                ConvertType.ToUpperAiueo_HalfOnly -> HalfToFullUtils.toUpperAiueo_Half(output)
                ConvertType.ToUpperAlphabet_HalfOnly -> CharacterUtil.toUpperAlphabet_Half(output)
                ConvertType.FullMacronToHyphen -> fullWidthMacronToHyphen(output)
                ConvertType.HalfMacronToHyphen -> halfWidthMacronToHyphen(output)
                ConvertType.FullHyphenToMacron -> fullWidthHyphenToMacron(output)
                ConvertType.FillZero2 -> if(output.length == 1 ) "0$output" else output
                else -> output
            }
        }
//        if (isDebug) println("转换前:$input")
//        if (isDebug) println("转换后:$output")
        return output
    }
}

package jp.co.jsbank.mb.bankingapp.ui.widgets.textField

import jp.co.jsbank.mb.bankingapp.utils.CharacterUtil

open class HalfWidthKanaInputWidget(
    value: String,
    onChange: (String) -> Unit,
    enabled: Boolean = true,
    placeholder: String = "",
    isError: Boolean = false,
    isOption: Boolean = false,
    maxLength: Int = Int.MAX_VALUE,
    maxHalfLength: Int = Int.MAX_VALUE,
) : HalfWidthInputWidget(
    value = value,
    placeholder = placeholder,
    maxLength = maxLength,
    maxHalfLength = maxHalfLength,
    enabled = enabled,
    isError = isError,
    isOption = isOption,
    onChange = onChange,
) {
    override fun appendConvertOptions() {
        super.appendConvertOptions()
        //// 小文字　ｧｨｩｪｫｬｭｮ を大文字に変換
        convertOptions.add(CharacterUtil.ConvertType.ToUpperAiueo_HalfOnly)
        //// 英字を大文字に変換
        convertOptions.add(CharacterUtil.ConvertType.ToUpperAlphabet_HalfOnly)
        //// 、(読点)	。 (句点)｀(グレイブアクセント)	・(中点)	を.(ピリオド)に変換
        convertOptions.add(CharacterUtil.ConvertType.ToHalfPeriod)
        //// 長音をハイフンに変換
        convertOptions.add(CharacterUtil.ConvertType.HalfMacronToHyphen)
    }
}

package jp.co.jsbank.mb.bankingapp.ui.widgets.textField

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.ContentAlpha
import androidx.compose.material.MaterialTheme
import androidx.compose.material.OutlinedTextField
import androidx.compose.material.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import jp.co.jsbank.mb.bankingapp.theme.H6
import org.jetbrains.annotations.NotNull

/**
 * テキストボックス
 *
 * @param value 入力テキストの内容
 * @param onChange コールバック
 * @param enabled　有効状態
 * @param placeholder テキストフィールドがフォーカスされ、入力テキストが空のときに表示されるオプションのプレースホルダ
 * @param isError テキストフィールドの現在値がエラー状態にあるかどうかを示します
 * @param errMsg エラーメッセージ
 * @param keyboardType ソフトキーボードの種類
 * @param maxLines 最大表示行数
 * @param maxLength 最大入力桁数
 * @param shape テキストフィールドの境界線の形状
 * @param unfocusedBorderColor 非焦点の時、境界線の色
 * @param focusedBorderColor　焦点の時、境界線の色
 * @param cursorColor　カーソルの色
 * @param fontSize 文字サイズ
 * @param textAlign 文字方向
 * @param focusedBackgroundColor 焦点の時、背景色
 * @param unfocusedBackgroundColor 非焦点の時、背景色
 * @param isConvertAllAngles 全角カナ変換フラグ
 * @param isConvertHalfAngles 半角カナ変換フラグ
 * @param maxHalfLength 半角サイズ
 * @param isCompletion 補0フラグ
 * @param isCharactersChange 小文字 大文字変換フラグ「true:変更する」
 * @return テキストボックス
 */
@Composable
fun TextsWidget(
    @NotNull value: String,
    @NotNull onChange: (String) -> Unit,
    enabled: Boolean = true,
    placeholder: String = "",
    isError: Boolean = false,
    errMsg: String = "",
    keyboardType: KeyboardType = KeyboardType.Text,
    maxLines: Int = 1,
    maxLength: Int = Int.MAX_VALUE,
    shape: Shape = MaterialTheme.shapes.small,
    unfocusedBorderColor: Color = MaterialTheme.colors.onSurface.copy(alpha = ContentAlpha.disabled),
    focusedBorderColor: Color = MaterialTheme.colors.primary.copy(alpha = ContentAlpha.high),
    cursorColor: Color = MaterialTheme.colors.primary,
    fontSize: TextUnit = H6,
    textAlign: TextAlign = TextAlign.Start,
    focusedBackgroundColor: Color = Color(0x1AE84F4F),
    unfocusedBackgroundColor: Color = Color(0x1AE84F4F),
    isConvertAllAngles: Boolean = false,
    isConvertHalfAngles: Boolean = false,
    maxHalfLength: Int = Int.MAX_VALUE,
    isCompletion: Boolean = false,
    isCharactersChange: Boolean = false,
) {
    val input = remember(value) {
        mutableStateOf(value)
    }

    var background by remember {
        mutableStateOf(focusedBackgroundColor)
    }

    val localFocusManager = LocalFocusManager.current

    Column(Modifier.fillMaxWidth()) {
        OutlinedTextField(
            readOnly = true,
            value = input.value,
            onValueChange = {},
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    BorderStroke(
                        1.dp,
                        color = if (isError) Color(0xFFFF003B) else Color.Transparent
                    )
                )
                .background(Color(0xFFF3F2EE)),
            enabled = enabled,
            textStyle = TextStyle(fontSize = fontSize, textAlign = textAlign),
            maxLines = maxLines,
            colors = TextFieldDefaults.outlinedTextFieldColors(
                unfocusedBorderColor = unfocusedBorderColor,
                focusedBorderColor = unfocusedBorderColor,
                cursorColor = unfocusedBorderColor,
            ),
        )
    }
}


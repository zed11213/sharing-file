package jp.co.jsbank.mb.bankingapp.ui.widgets.textField

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.focus.FocusManager
import androidx.compose.ui.focus.onFocusEvent
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import jp.co.jsbank.mb.bankingapp.theme.H6
import jp.co.jsbank.mb.bankingapp.utils.HalfToFullUtils
import jp.co.jsbank.mb.bankingapp.utils.KanaUtil.toDbc
import jp.co.jsbank.mb.bankingapp.utils.KanaUtil.toSbc
import org.jetbrains.annotations.NotNull
import java.util.Locale

/**
 * テキストボックス
 *
 * @param value 入力テキストの内容
 * @param onChange コールバック
 * @param enabled　有効状態
 * @param placeholder テキストフィールドがフォーカスされ、入力テキストが空のときに表示されるオプションのプレースホルダ
 * @param isError テキストフィールドの現在値がエラー状態にあるかどうかを示します
 * @param errMsg エラーメッセージ
 * @param keyboardType ソフトキーボードの種類
 * @param maxLines 最大表示行数
 * @param maxLength 最大入力桁数
 * @param shape テキストフィールドの境界線の形状
 * @param unfocusedBorderColor 非焦点の時、境界線の色
 * @param focusedBorderColor　焦点の時、境界線の色
 * @param cursorColor　カーソルの色
 * @param fontSize 文字サイズ
 * @param textAlign 文字方向
 * @param focusedBackgroundColor 焦点の時、背景色
 * @param unfocusedBackgroundColor 非焦点の時、背景色
 * @param isConvertAllAngles 全角カナ変換フラグ
 * @param isConvertHalfAngles 半角カナ変換フラグ
 * @param maxHalfLength 半角サイズ
 * @param isCompletion 補0フラグ
 * @return テキストボックス
 */
@Composable
fun TextWidget(
    @NotNull value: String,
    @NotNull onChange: (String) -> Unit,
    enabled: Boolean = true,
    placeholder: String = "",
    isError: Boolean = false,
    errMsg: String = "",
    keyboardType: KeyboardType = KeyboardType.Text,
    maxLines: Int = 1,
    maxLength: Int = Int.MAX_VALUE,
    minLength: Int = Int.MAX_VALUE,
    shape: Shape = MaterialTheme.shapes.small,
    unfocusedBorderColor: Color = MaterialTheme.colors.onSurface.copy(alpha = ContentAlpha.disabled),
    focusedBorderColor: Color = MaterialTheme.colors.primary.copy(alpha = ContentAlpha.high),
    cursorColor: Color = MaterialTheme.colors.primary,
    fontSize: TextUnit = H6,
    textAlign: TextAlign = TextAlign.Start,
    focusedBackgroundColor: Color = Color(0x1AE84F4F),
    unfocusedBackgroundColor: Color = Color(0x1AE84F4F),
    isPassword: Boolean = false,
    backgroundChange: Boolean = true,
    isConvertAllAngles: Boolean = false,
    isConvertHalfAngles: Boolean = false,
    maxHalfLength: Int = Int.MAX_VALUE,
    isHalfLength: Boolean = false,
    isCompletion: Boolean = false,
    isPersonName: Boolean = false,
    isNumberHyphen: Boolean = false,
    isSpace: Boolean = false,
    onImeAction: () -> Unit,
    lowerCase: Boolean = false,
) {
    val input = remember(value) {
        mutableStateOf(value)
    }

    var background by remember {
        mutableStateOf(focusedBackgroundColor)
    }

    val localFocusManager = LocalFocusManager.current

    Column(Modifier.fillMaxWidth()) {
        OutlinedTextField(
            value = input.value,
            onValueChange = {
                var isEmoji = false
                var isNumHyp = true
                var isSpaceFullOrHalf = true
                it.forEach { char ->
                    val type = Character.getType(char)
                    if (type == Character.SURROGATE.toInt() || type == Character.OTHER_SYMBOL.toInt()) {
                        isEmoji = true
                    }
                    if (isSpace) {
                        if (" 　".contains(char)) {
                            isSpaceFullOrHalf = false
                        }
                    }
                }

                if (isNumberHyphen) {
                    val filtered = it.filter { "0123456789-０１２３４５６７８９－".contains(it) }
                    isNumHyp = it == filtered
                }

                if (!isEmoji && isNumHyp && isSpaceFullOrHalf) {
                    if (isConvertHalfAngles || isHalfLength) {
                        if (HalfToFullUtils.fullToHalfChar(it).length <= maxHalfLength) {
                            input.value = it
                            onChange.invoke(input.value)
                        }
                    } else {
                        if (it.length <= maxLength) {
                            input.value = it
                            onChange.invoke(input.value)
                        }
                    }
                }
                //2025/01/16 全角英文を半角変換　 インバン利用登録 追加 start
                if (lowerCase && input.value.isNotBlank() ) {
                    input.value = input.value.lowercase(Locale.getDefault())
                }
                //2025/01/16 全角英文を半角変換　 インバン利用登録 追加 end
            },
            modifier = Modifier
                .fillMaxWidth()
                .border(
                    BorderStroke(
                        1.dp,
                        color = if (isError) Color(0xFFFF003B) else Color.Transparent
                    )
                )
                .background(background)
                .height(if (maxLines > 1) (maxLines * 25).dp else 55.dp)
                .onFocusEvent {
                    background = if (it.isFocused) {
                        focusedBackgroundColor
                    } else {
                        if (input.value.isBlank() || !backgroundChange) unfocusedBackgroundColor
                        else Color(0xFFF5F5F5)
                    }

                    // 全角カナ変換
                    if (isConvertAllAngles && input.value.isNotBlank() && !it.isFocused) {
                        input.value = if (isPersonName) {
                            toSbc(HalfToFullUtils.halfToFullCharName(input.value))
                        } else {
                            toSbc(HalfToFullUtils.halfToFullChar(input.value))
                        }

                        // カナの小文字の場合、大文字に変換する
//                        if (isCharactersChange && input.value.isNotBlank() && !it.isFocused) {
//                            input.value = smallToBigChar(input.value)
//                        }

                        if (isHalfLength) {
                            if (HalfToFullUtils.fullToHalfChar(input.value).length > maxHalfLength) {
                                input.value = if (isPersonName) {
                                    toSbc(HalfToFullUtils.halfToFullCharName(input.value.substring(0, maxHalfLength)))
                                } else {
                                    toSbc(HalfToFullUtils.halfToFullChar(input.value.substring(0, maxHalfLength)))
                                }
                                onChange.invoke(input.value)
                            }
                        }
                        onChange.invoke(input.value)
                    }

                    // 半角カナ変換
                    if (isConvertHalfAngles && input.value.isNotBlank() && !it.isFocused) {
                        input.value = if (isPersonName) {
                            toDbc(HalfToFullUtils.fullToHalfCharName(input.value))
                        } else {
                            toDbc(HalfToFullUtils.fullToHalfChar(input.value))
                        }

                        if (input.value.length > maxHalfLength) {
                            input.value = input.value.substring(0, maxHalfLength)
                            onChange.invoke(input.value)
                        } else {
                            onChange.invoke(input.value)
                        }
                    }

                    // 補0
                    if (isCompletion && input.value.length == 1 && !it.isFocused) {
                        input.value = "0" + input.value
                        onChange.invoke(input.value)
                    }
                    // 全角英文を半角変換　2025/01/16 追加
                    if (lowerCase && input.value.isNotBlank() && !it.isFocused) {
                        input.value = input.value.lowercase()
                    }
                },
            enabled = enabled,
            placeholder = {
                Text(
                    text = placeholder,
                    color = Color.Gray,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = textAlign
                )
            },
//            isError = isError,
            keyboardOptions = KeyboardOptions(
                keyboardType = keyboardType,
                imeAction = ImeAction.Done
            ),
            keyboardActions = KeyboardActions(
                onDone = {
                    localFocusManager.clearFocus()
                    onImeAction()
                },
            ),
            textStyle = TextStyle(fontSize = fontSize, textAlign = textAlign),
            maxLines = maxLines,
            shape = shape,
            colors = TextFieldDefaults.outlinedTextFieldColors(
                unfocusedBorderColor = unfocusedBorderColor,
                focusedBorderColor = focusedBorderColor,
                cursorColor = cursorColor,
            ),
            visualTransformation = if (isPassword)
                PasswordVisualTransformation() else VisualTransformation.None
        )
    }
}

/**
 * 他の場所をクリックすると自動的にキーボードを隠すことができます
 */
fun Modifier.autoCloseKeyboard(): Modifier = composed {
    val localFocusManager: FocusManager = LocalFocusManager.current
    pointerInput(Unit) {
        detectTapGestures(
            onPress = {
                localFocusManager.clearFocus()
            }
        )
    }
}

package jp.co.jsbank.mb.bankingapp.ui.widgets.textField

import jp.co.jsbank.mb.bankingapp.utils.CharacterUtil
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil

/**
 * 入力ボックス
 *
 * @param value 入力テキストの内容
 * @param onChange コールバック
 * @param enabled　有効状態
 * @param placeholder テキストフィールドがフォーカスされ、入力テキストが空のときに表示されるオプションのプレースホルダ
 * @param maxLength 最大入力桁数
 * @param shape テキストフィールドの境界線の形状
 * @return テキストボックス
 */
class PersonName(
    value: String,
    placeholder: String = "",
    onChange: (String) -> Unit,
    enabled: Boolean = true,
    isError: Boolean = false,
    isOption: Boolean = false,
) : FullWidthInputWidget(
    value = value,
    placeholder = placeholder,
    maxLength = ConstUtil.FULL_PERSON_NAME_MAX_LENGTH,
    enabled = enabled,
    isError = isError,
    isOption = isOption,
    onChange = onChange
) {
    override fun appendConvertOptions() {
        super.appendConvertOptions()
        // ハイフンを全角長音u30FCに変換する
        convertOptions.add(CharacterUtil.ConvertType.FullHyphenToMacron)
    }
}


package jp.co.jsbank.mb.bankingapp.ui.widgets.textField

import jp.co.jsbank.mb.bankingapp.utils.CharacterUtil

open class OrganizationName(
    value: String,
    onChange: (String) -> Unit,
    enabled: Boolean = true,
    placeholder: String = "",
    isError: Boolean = false,
    isOption: Boolean = false,
    maxLength: Int = Int.MAX_VALUE,
) : FullWidthInputWidget(
    value = value,
    placeholder = placeholder,
    maxLength = maxLength,
    enabled = enabled,
    isError = isError,
    isOption = isOption,
    onChange = onChange,
) {
    override fun appendConvertOptions() {
        super.appendConvertOptions()
        // ハイフンを全角長音u30FCに変換する
        convertOptions.add(CharacterUtil.ConvertType.FullHyphenToMacron)
    }
}
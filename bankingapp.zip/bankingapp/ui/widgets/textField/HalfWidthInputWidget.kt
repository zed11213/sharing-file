package jp.co.jsbank.mb.bankingapp.ui.widgets.textField

import jp.co.jsbank.mb.bankingapp.utils.CharacterUtil

open class HalfWidthInputWidget(
    value: String,
    onChange: (String) -> Unit,
    enabled: Boolean = true,
    placeholder: String = "",
    isError: Boolean = false,
    isOption: Boolean = false,
    maxLength: Int = Int.MAX_VALUE,
    maxHalfLength: Int = Int.MAX_VALUE,
) : ComInputWidget(
    value = value,
    placeholder = placeholder,
    maxLength = maxLength,
    maxHalfLength = maxHalfLength,
    enabled = enabled,
    isError = isError,
    isOption = isOption,
    onChange = onChange,
    onImeAction = { }) {

    override fun appendConvertOptions() {
        // 半角変換
        convertOptions.add(CharacterUtil.ConvertType.ToHalfWidth)
    }
}

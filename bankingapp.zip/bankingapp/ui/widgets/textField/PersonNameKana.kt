package jp.co.jsbank.mb.bankingapp.ui.widgets.textField

import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Shape
import jp.co.jsbank.mb.bankingapp.utils.CharacterUtil
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil

/**
 * 入力ボックス
 *
 * @param value 入力テキストの内容
 * @param onChange コールバック
 * @param enabled　有効状態
 * @param placeholder テキストフィールドがフォーカスされ、入力テキストが空のときに表示されるオプションのプレースホルダ
 * @param maxLength 最大入力桁数
 * @param shape テキストフィールドの境界線の形状
 * @return テキストボックス
 */
class PersonNameKana(
    value: String,
    placeholder: String = "",
    onChange: (String) -> Unit,
    enabled: Boolean = true,
    isError: Boolean = false,
    isOption: Boolean = false,
) : HalfWidthKanaInputWidget(
    value = value,
    placeholder = placeholder,
    maxLength = ConstUtil.FULL_PERSON_NAME_MAX_LENGTH,
    maxHalfLength = ConstUtil.HALF_PERSON_NAME_MAX_LENGTH,
    enabled = enabled,
    isError = isError,
    isOption = isOption,
    onChange = onChange
)

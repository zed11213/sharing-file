package jp.co.jsbank.mb.bankingapp.ui.widgets.textField

import jp.co.jsbank.mb.bankingapp.utils.ConstUtil
import jp.co.jsbank.mb.bankingapp.utils.CharacterUtil

/*
 *  号室(カナ)
 *
 */
open class AddressRoomKana(
    value: String,
    onChange: (String) -> Unit,
    enabled: Boolean = true,
    placeholder: String = "",
    isError: Boolean = false,
    maxLength: Int = Int.MAX_VALUE,
) : AddressKana(
    value = value,
    placeholder = placeholder,
    maxLength = maxLength,
    maxHalfLength = ConstUtil.HALF_BUILDING_NAME_MAX_LENGTH,
    onChange = onChange,
    isError = isError,
    isOption = true,
    enabled = enabled,
) {
    override fun isContainInvalidCharacter(input: String): Boolean {
        return CharacterUtil.containsEmoji(input) || CharacterUtil.containsSpace(input)
    }

    override fun removeInvalidCharacter(input: String): String {
        return CharacterUtil.removeSpace(input)
    }
}

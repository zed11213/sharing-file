package jp.co.jsbank.mb.bankingapp.ui.widgets.textField

import jp.co.jsbank.mb.bankingapp.utils.CharacterUtil
import androidx.compose.runtime.*

interface Buildable {
    @Composable
    fun Build()
}

abstract class AbstractInputWidget() {
    val convertOptions = mutableListOf<CharacterUtil.ConvertType>()
    init {
        appendConvertOptions()
    }

    abstract fun appendConvertOptions()
    //半角か
    abstract fun isHalfWidthOnly() : Boolean

    //禁止文字が含めたか
    abstract fun isContainInvalidCharacter(input: String) : Boolean

    //
    abstract fun removeInvalidCharacter(input: String) : String
}

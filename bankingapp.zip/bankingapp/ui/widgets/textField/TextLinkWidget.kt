package jp.co.jsbank.mb.bankingapp.ui.widgets.textField

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import jp.co.jsbank.mb.bankingapp.theme.H6
import org.jetbrains.annotations.NotNull

/**
 * テキストボックス
 *
 * @param value 入力テキストの内容
 * @param onChange コールバック
 * @param enabled　有効状態
 * @param placeholder テキストフィールドがフォーカスされ、入力テキストが空のときに表示されるオプションのプレースホルダ
 * @param isError テキストフィールドの現在値がエラー状態にあるかどうかを示します
 * @param errMsg エラーメッセージ
 * @param keyboardType ソフトキーボードの種類
 * @param maxLines 最大表示行数
 * @param maxLength 最大入力桁数
 * @param shape テキストフィールドの境界線の形状
 * @param unfocusedBorderColor 非焦点の時、境界線の色
 * @param focusedBorderColor　焦点の時、境界線の色
 * @param cursorColor　カーソルの色
 * @param fontSize 文字サイズ
 * @param textAlign 文字方向
 * @param focusedBackgroundColor 焦点の時、背景色
 * @param unfocusedBackgroundColor 非焦点の時、背景色
 * @param isConvertAllAngles 全角カナ変換フラグ
 * @param isConvertHalfAngles 半角カナ変換フラグ
 * @param maxHalfLength 半角サイズ
 * @param isCompletion 補0フラグ
 * @param isCharactersChange 小文字 大文字変換フラグ「true:変更する」
 * @return テキストボックス
 */
@Composable
fun TextLinkWidget(
    @NotNull value: String,
    @NotNull url: String,
    isError: Boolean = false,
    maxLines: Int = 1,
    fontSize: TextUnit = H6,
    textAlign: TextAlign = TextAlign.Center,

) {

        val uriHandler = LocalUriHandler.current

        Column(Modifier.fillMaxWidth()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { uriHandler.openUri(url) }
                    .background(Color(0xFFF3F2EE))
                    .border(1.dp, Color(0xFFD9D9D9), RoundedCornerShape(4.dp))
                    .padding(horizontal = 24.dp, vertical = 12.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = value,
                    color = Color.Blue,
                    fontSize = fontSize,
                    textAlign = TextAlign.Start,
                    maxLines = maxLines,
                )
            }
        }

}


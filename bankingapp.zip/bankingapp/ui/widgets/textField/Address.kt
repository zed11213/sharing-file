package jp.co.jsbank.mb.bankingapp.ui.widgets.textField

open class Address(
    value: String,
    onChange: (String) -> Unit,
    enabled: Boolean = true,
    placeholder: String = "",
    isError: Boolean = false,
    isOption: Boolean = false,
    maxLength: Int = Int.MAX_VALUE,
) : FullWidthInputWidget(
    value = value,
    placeholder = placeholder,
    maxLength = maxLength,
    enabled = enabled,
    isError = isError,
    isOption = isOption,
    onChange = onChange,
)

package jp.co.jsbank.mb.bankingapp.ui.widgets.card

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import jp.co.jsbank.mb.bankingapp.bean.common.CheckPointsBean

/**
 * 注意点リストの共通カード
 *
 * @param modifier 修飾子
 * @param data 注意点リスト
 */
@Composable
fun CardCheckPoints(
    modifier: Modifier = Modifier,
    data: List<CheckPointsBean>,
) {
    Card(
        shape = RoundedCornerShape(10.dp),
        elevation = 0.dp,
        backgroundColor = Color(0x1ACE3F52),
        modifier = modifier.fillMaxWidth()
    ) {
        LazyColumn(
            modifier = Modifier.padding(horizontal = 8.dp),
            state = rememberLazyListState(), content = {
                items(count = data.size, itemContent = { index ->
                    Row(
                        modifier = Modifier.padding(vertical = 5.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxHeight()
                                .padding(horizontal = 10.dp),
                        ) {
                            Icon(
                                data[index].icon,
                                contentDescription = "",
                                tint = data[index].iconColor,
                                modifier = Modifier.size(data[index].iconSize)
                            )
                        }
                        Column {
                            Text(text = data[index].content, fontSize = data[index].fontSize)
                        }
                    }
                })
            }
        )
    }
}

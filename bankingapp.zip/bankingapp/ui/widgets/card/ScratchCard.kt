package jp.co.jsbank.mb.bankingapp.ui.widgets.card

import android.view.MotionEvent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Card
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.pointerInteropFilter
import androidx.compose.ui.res.imageResource
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.bean.common.DraggedPath
import jp.co.jsbank.mb.bankingapp.utils.showToast
import org.jetbrains.annotations.NotNull

/**
 *
 *
 * @param modifier 修飾子
 * @param title タイトル
 * @param content 内容
 * @param imageId 画像ID
 * @param onTap クリックの動作
 */
@ExperimentalComposeUiApi
@Composable
fun ScratchCardScreen(
    @NotNull image: Int,
    @NotNull onClick: (Offset) -> Unit,
) {
    val overlayImage = ImageBitmap.imageResource(id = R.drawable.scratch)
    val baseImage = ImageBitmap.imageResource(id = image)

    val currentPathState = remember { mutableStateOf(DraggedPath(path = Path())) }
    val movedOffsetState = remember { mutableStateOf<Offset?>(null) }

    Card(
        Modifier
            .fillMaxWidth()
            .clipToBounds()
            .clip(RoundedCornerShape(size = 16.dp)),
        elevation = 2.dp,
    ) {
        ScratchingCanvas(
            overlayImage = overlayImage,
            baseImage = baseImage,
//            modifier = Modifier.align(Alignment.Center),
            movedOffset = movedOffsetState.value,
            onMovedOffset = { x, y ->
                movedOffsetState.value = Offset(x, y)
                onClick.invoke(movedOffsetState.value!!)
            },
            currentPath = currentPathState.value.path,
            currentPathThickness = currentPathState.value.width,
        )
    }
}

@ExperimentalComposeUiApi
@Composable
fun ScratchingCanvas(
    overlayImage: ImageBitmap,
    baseImage: ImageBitmap,
    modifier: Modifier = Modifier,
    movedOffset: Offset?,
    onMovedOffset: (Float, Float) -> Unit,
    currentPath: Path,
    currentPathThickness: Float,
) {
    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(120.dp)
            .clipToBounds()
            .clip(RoundedCornerShape(size = 16.dp))
            .pointerInteropFilter {
                when (it.action) {
                    MotionEvent.ACTION_DOWN -> {
                        false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        currentPath.moveTo(it.x, it.y)
                        onMovedOffset(it.x, it.y)
                        true
                    }
                    else -> {
                        false
                    }
                }
            }
            .pointerInput(Unit) {
                detectDragGestures { _, _ ->
                    showToast("888888888888888888888888888888888")
                }
                detectDragGesturesAfterLongPress { _, _ ->
                    showToast("77777777777777777777777777777777")
                }
                detectTapGestures {
                    showToast("999999999999999999999999999999999")
                }
            }

    ) {
        val canvasWidth = size.width.toInt()
        val canvasHeight = size.height.toInt()
        val imageSize = IntSize(width = canvasWidth, height = canvasHeight)

        // Overlay Image to be scratched
        drawImage(
            image = overlayImage,
            dstSize = imageSize
        )

        movedOffset?.let {
            currentPath.addOval(oval = Rect(it, currentPathThickness))
        }

        clipPath(path = currentPath, clipOp = ClipOp.Intersect) {
            // Base Image after scratching
            drawImage(
                image = baseImage,
                dstSize = imageSize
            )
        }
    }
}

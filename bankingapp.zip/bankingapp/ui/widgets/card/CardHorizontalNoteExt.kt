package jp.co.jsbank.mb.bankingapp.ui.widgets.card

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Card
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import jp.co.jsbank.mb.bankingapp.theme.H3
import jp.co.jsbank.mb.bankingapp.theme.H7
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.click

/**
 * 左は文字、右は画像のカード(クリック可能)
 *
 * @param modifier 修飾子
 * @param title タイトル
 * @param maintitle メインタイトル
 * @param content 内容
 * @param imageId 画像ID
 * @param onTap クリックの動作
 */
@Composable
fun CardHorizontalNoteExt(
    modifier: Modifier,
    title: String,
    titleFontSize: TextUnit = H7,
    maintitle: String,
    maintitleFontSize: TextUnit = H3,
    titleColor: Color = Color(0xFFCE3F52),
    content: String,
    imageId: Int,
    onTap: () -> Unit = {},
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        elevation = 10.dp,
        backgroundColor = Color.White,
        modifier = modifier
            .fillMaxWidth()
            .click { onTap.invoke() }
    ) {
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier
                    .padding(vertical = 20.dp, horizontal = 10.dp)
                    .weight(0.6f)
            ) {
                Text(
                    text = title,
                    fontSize = titleFontSize,
                    fontWeight = FontWeight.Bold,
                    color = titleColor,
                    modifier = Modifier.padding(bottom = 5.dp)
                )
                Text(
                    text = maintitle,
                    fontSize = maintitleFontSize,
                    fontWeight = FontWeight.Bold,
                    color = titleColor,
                    modifier = Modifier.padding(bottom = 5.dp)
                )
                Text(text = content, fontSize = H7)
            }
            Column(
                modifier = Modifier
                    .padding(30.dp, 10.dp, 10.dp, 10.dp)
                    .fillMaxWidth()
                    .weight(0.4f)
            ) {
                Image(
                    contentScale = ContentScale.FillWidth,
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.CenterHorizontally),
                    painter = painterResource(id = imageId),
                    contentDescription = ""
                )
            }
        }
    }
}

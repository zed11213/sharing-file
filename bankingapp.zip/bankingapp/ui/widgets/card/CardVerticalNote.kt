package jp.co.jsbank.mb.bankingapp.ui.widgets.card

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Card
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import jp.co.jsbank.mb.bankingapp.system.MyApp
import jp.co.jsbank.mb.bankingapp.theme.H5
import jp.co.jsbank.mb.bankingapp.theme.H7
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.click

/**
 * 上は画像、下は文字のカード(クリック可能)
 *
 * @param modifier 修飾子
 * @param title タイトル
 * @param content 内容
 * @param imageId 画像ID
 * @param onTap クリックの動作
 */
@Composable
fun CardVerticalNote(
    modifier: Modifier,
    title: String,
    titleColor: Color = Color(0xFFCE3F52),
    content: String,
    imageId: Int,
    imageSize: Int,
    width: Dp = MyApp.SCREEN_WIDTH.dp,
    onTap: () -> Unit = {},
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        elevation = 10.dp,
        backgroundColor = Color.White,
        modifier = modifier.width(width)
            .fillMaxSize()
            .click { onTap.invoke() }
    ) {
        Column(
            modifier = Modifier
                .padding(vertical = 20.dp, horizontal = 10.dp)
                .fillMaxSize()
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Image(
                    modifier = Modifier.requiredSize(imageSize.dp),
                    contentScale = ContentScale.FillWidth,
                    painter = painterResource(id = imageId),
                    contentDescription = ""
                )
            }
            Column(
                modifier = Modifier.fillMaxWidth().padding(top = 10.dp)
            ) {
                Text(
                    text = title,
                    fontSize = H5,
                    fontWeight = FontWeight.Bold,
                    color = titleColor,
                    modifier = Modifier.padding(bottom = 5.dp)
                )
                Text(text = content, fontSize = H7)
            }
        }
    }
}

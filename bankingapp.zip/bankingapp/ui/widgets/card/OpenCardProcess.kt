package jp.co.jsbank.mb.bankingapp.ui.widgets.card

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Card
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import jp.co.jsbank.mb.bankingapp.ui.widgets.common.Circular
import jp.co.jsbank.mb.bankingapp.ui.widgets.common.VerticalDottedLine
import jp.co.jsbank.mb.bankingapp.ui.widgets.common.VerticalLine

/**
 * プロセス流れ.
 *
 * @param count 合計ノード数
 * @param state 現在のノード
 * @param cardType カードタイプ
 * @param imageSize 現在のノードの画像サイズ
 */
@Composable
fun OpenCardProcess(
    count: Int = 4,
    state: Int = 1,
    cardType: Int = 0,
    imageSize: Int = 100,
    content: String = "",
    imageId: Int = 0,
    titleList: List<String>,
) {
    Column(
        modifier = Modifier
            .background(Color.White)
            .fillMaxWidth()
    ) {
        LazyColumn(state = rememberLazyListState(), content = {
            items(count = count, itemContent = { index ->
                if (state == index + 1) {
                    Card(
                        shape = RoundedCornerShape(10.dp),
                        elevation = 0.dp,
                        modifier = Modifier
                            .padding(20.dp, 0.dp, 20.dp, 0.dp)
                    ) {
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .background(Color(0x1ACE3F52))
                        ) {
                            Column(
                                Modifier
                                    .weight(1f)
                                    .fillMaxWidth()
                                    .align(Alignment.CenterVertically)
                            ) {
                                Circular(index + 1, titleList[index])
                                Row(
                                    Modifier
                                        .align(Alignment.CenterHorizontally)
                                        .padding(20.dp, 10.dp, 0.dp, 20.dp)
                                ) {
                                    Text(
                                        text = content,
                                        overflow = TextOverflow.Ellipsis,
                                        fontSize = 12.sp,
                                        modifier = Modifier
                                            .align(Alignment.CenterVertically),
                                    )
                                }
                            }
                            Column(
                                Modifier
                                    .weight(1f)
                                    .fillMaxWidth().align(Alignment.CenterVertically)
                            ) {
                                Row(
                                    Modifier
                                        .align(Alignment.CenterHorizontally)
                                        .padding(0.dp, 10.dp, 0.dp, 10.dp)
                                ) {
                                    Image(
                                        contentScale = ContentScale.Fit,
//                                        modifier = Modifier.size(imageSize.dp),
                                        painter = painterResource(id = imageId),
                                        contentDescription = ""
                                    )
                                }
                            }
                        }
                    }
                } else if (index + 1 == count && cardType == 1) {
                    Card(
                        shape = RoundedCornerShape(10.dp),
                        elevation = 2.dp,
                        modifier = Modifier
                            .padding(20.dp, 0.dp, 20.dp, 2.dp)
                            .background(Color.White)
                            .height(80.dp)
                    ) {
                        Row(
                            Modifier
                                .background(Color(0x1A949391))
                                .fillMaxWidth()
                                .align(Alignment.CenterHorizontally)
                        ) {
                            Circular(
                                index + 1,
                                titleList[index],
                                numColor = Color(0xB3949391),
                                backGroundColor = Color.LightGray,
                                labelColor = Color(0xB3949391)
                            )
                        }
                    }
                } else {
                    Card(
                        shape = RoundedCornerShape(10.dp),
                        elevation = 2.dp,
                        modifier = Modifier
                            .padding(20.dp, 0.dp, 20.dp, 0.dp)
                            .background(Color.White)
                            .height(80.dp)
                    ) {
                        Row(
                            Modifier
                                .fillMaxSize()
                        ) {
                            Column(
                                Modifier
                                    .weight(1f)
                                    .background(Color(0x1A949391))
                                    .fillMaxSize()
                                    .align(Alignment.CenterVertically)
                            ) {
                                Circular(
                                    index + 1,
                                    titleList[index],
                                    numColor = Color(0xB3949391),
                                    backGroundColor = Color.LightGray,
                                    labelColor = Color(0xB3949391)
                                )
                            }
                            Column(
                                Modifier
                                    .weight(1f)
                                    .background(Color(0x1A949391))
                                    .fillMaxSize()
                            ) {}
                        }
                    }
                }
                if (count != index + 1) {
                    if (state > index + 1) {
                        VerticalLine()
                    } else {
                        VerticalDottedLine()
                    }
                }
            })
        })
    }
}

package jp.co.jsbank.mb.bankingapp.ui.widgets.card

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Card
import androidx.compose.material.Divider
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import java.time.format.DateTimeFormatter
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.bean.main.home.mbnt.mbnt0101.Anncmnt
import jp.co.jsbank.mb.bankingapp.system.master.AnncmntType.Companion.getAnncmntTypeName
import jp.co.jsbank.mb.bankingapp.system.master.ReadFlg
import jp.co.jsbank.mb.bankingapp.theme.H6
import jp.co.jsbank.mb.bankingapp.theme.H7
import jp.co.jsbank.mb.bankingapp.theme.general_label_color
import jp.co.jsbank.mb.bankingapp.theme.inactive_font_color
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.click
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.DATE_FORMAT_YYYY_MM_DD_SPOT
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.DATE_FORMAT_YYYY_MM_DD_T_HH_MM_SS_MI

/**
 * お知らせリストの共通カード
 *
 * @param modifier 修飾子
 * @param data お知らせリスト
 * @param onTap クリックの動作
 */
@Composable
fun CardAnnouncementsList(
    modifier: Modifier,
    data: MutableList<Anncmnt>,
    onTap: (Int) -> Unit = {},
) {
    Card(
        shape = RoundedCornerShape(10.dp),
        elevation = 10.dp,
        backgroundColor = Color.White,
        modifier = modifier.fillMaxWidth()
    ) {
        LazyColumn(state = rememberLazyListState(), content = {
            items(count = data.size, itemContent = { index ->
                Column(
                    modifier = Modifier
                        .padding(
                            horizontal = 10.dp, vertical = 15.dp
                        )
                        .click { onTap.invoke(index) }
                ) {
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.CenterHorizontally)
                    ) {
                        Column(modifier = Modifier.align(Alignment.CenterVertically)) {
                            Row(
                                modifier = Modifier
                                    .align(Alignment.CenterHorizontally)
                            ) {
                                if (data[index].readFlag != ReadFlg.ALREADY_READ.code) {
                                    Column(modifier = Modifier.padding(end = 5.dp)) {
                                        Image(
                                            contentScale = ContentScale.Fit,
                                            painter = painterResource(
                                                id = R.drawable.elliptical
                                            ),
                                            contentDescription = ""
                                        )
                                    }
                                } else {
                                    Spacer(modifier = Modifier.width(15.dp))
                                }
                                val formatter = DateTimeFormatter.ofPattern(DATE_FORMAT_YYYY_MM_DD_T_HH_MM_SS_MI)
                                val parsedDate = formatter.parse(data[index].anncmntDateAndTime)
                                val displayFormatter = DateTimeFormatter.ofPattern(DATE_FORMAT_YYYY_MM_DD_SPOT)
                                val date = displayFormatter.format(parsedDate)
                                Text(
                                    text = date,
                                    modifier = Modifier.padding(start = 5.dp),
                                    color = if (data[index].readFlag != ReadFlg.ALREADY_READ.code)
                                        general_label_color else inactive_font_color,
                                    fontSize = H7
                                )
                            }
                        }
                        Column(modifier = Modifier.align(Alignment.CenterVertically)) {
                            Card(
                                shape = RoundedCornerShape(10.dp),
                                elevation = 0.dp,
                                border = BorderStroke(1.dp, color = Color.Gray)
                            ) {
                                Text(
                                    text = getAnncmntTypeName(data[index].anncmntType),
                                    modifier = Modifier.padding(horizontal = 25.dp),
                                    color = if (data[index].readFlag != ReadFlg.ALREADY_READ.code)
                                        general_label_color else inactive_font_color,
                                )
                            }
                        }
                    }
                    Row(modifier = Modifier.padding(start = 15.dp, top = 5.dp)) {
                        Text(
                            text = data[index].anncmntTitle,
                            color = if (data[index].readFlag != ReadFlg.ALREADY_READ.code)
                                general_label_color else inactive_font_color,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis,
                            fontSize = H6
                        )
                    }
                }
                if (index < data.size - 1) {
                    Divider(
                        modifier = Modifier.padding(
                            horizontal = 10.dp
                        )
                    )
                }
            })
        })
    }
}

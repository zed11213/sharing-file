package jp.co.jsbank.mb.bankingapp.ui.widgets.card

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Card
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import coil.compose.rememberImagePainter
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.theme.H5
import jp.co.jsbank.mb.bankingapp.theme.prominent_label_color
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.IconButton
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.click

/**
 * 書類アップロードカード
 *
 * @param iconId アイコンID
 * @param unSelectText 画像なしの分限
 */
@OptIn(ExperimentalComposeUiApi::class, coil.annotation.ExperimentalCoilApi::class)
@Composable
fun DocumentUpLoadCard(
    iconId: Int = R.drawable.mbop1401_card,
    unSelectText: String = "",
    selectText: String = "",
    data: Any?,
    onClick: () -> Unit = {},
    onClear: () -> Unit = {},
) {

    Box {
        Card(
            shape = RoundedCornerShape(10.dp),
            elevation = 5.dp,
            modifier = Modifier
                .padding(vertical = 10.dp, horizontal = 8.dp)
                .height(90.dp)
                .click {
                    // 写真を撮る、又は、アルバムから選択するを呼び出す
                    onClick()
                }
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(
                    modifier = Modifier.weight(1.0f),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    if (data != null) {
                        Image(painter = rememberImagePainter(data = data), contentDescription = "")
                    } else {
                        Image(
                            contentScale = ContentScale.Fit,
                            painter = painterResource(id = iconId),
                            contentDescription = ""
                        )
                    }
                }
                Column(
                    modifier = Modifier.weight(2.0f),
                    horizontalAlignment = Alignment.Start,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = if (data != null) selectText else unSelectText,
                        color = prominent_label_color,
                        fontSize = H5,
                    )
                }
            }
        }
        if (data != null) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                Box(
                    modifier = Modifier
                        .size(20.dp)
                        .clip(CircleShape)
                        .border(1.dp, prominent_label_color, CircleShape)
                        .background(Color.Transparent)
                        .align(Alignment.CenterVertically)
                ) {
                    IconButton(image = R.drawable.close, imageSize = 10.dp) {
                        onClear()
                    }
                }
            }
        }
    }
}

package jp.co.jsbank.mb.bankingapp.ui.widgets.appBar

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.os.Build
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.app.ActivityCompat
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.system.MainActivity.Companion.ACTIVITY
import jp.co.jsbank.mb.bankingapp.theme.H5
import jp.co.jsbank.mb.bankingapp.theme.app_bar_background_color
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.IconButton

/**
 * PDFアプリバー
 *
 * @param onDownload PDFで保存のイベント
 */
@SuppressLint("ObsoleteSdkInt")
@Composable
fun PdfAppBar(
    onDownload: () -> Unit
) {
    // アプリバー
    TopAppBar(
        modifier = Modifier.fillMaxWidth(),
        backgroundColor = app_bar_background_color,
        elevation = 0.dp
    ) {
        Row(
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp)
        ) {
            // 戻るボタン
            IconButton(
                rightText = stringResource(id = R.string.common_page_topBar_button_return),
                textSize = H5,
                image = R.drawable.icon_back,
                imageSize = 15.dp
            ) {
                MainActivity.NAVCTRL?.navigateUp()
            }
            // PDFで保存
            IconButton(
                rightText = stringResource(id = R.string.common_page_topBar_pdf_download),
                textSize = H5,
                image = R.drawable.pdf_download,
                imageSize = 25.dp
            ) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    onDownload.invoke()
                } else {
                    val permissionsStorage = arrayOf(
                        Manifest.permission.READ_EXTERNAL_STORAGE,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE
                    )
                    val permission = ActivityCompat.checkSelfPermission(
                        ACTIVITY!!,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE
                    )

                    if (permission != PackageManager.PERMISSION_GRANTED) {
                        ActivityCompat.requestPermissions(
                            ACTIVITY!!, permissionsStorage,
                            1
                        )
                    } else {
                        onDownload.invoke()
                    }
                }
            }
        }
    }
}

package jp.co.jsbank.mb.bankingapp.ui.widgets.barchart

import java.lang.Float.max
import java.lang.Float.min

data class BarChartData(
    val balanceInfoList: List<BalanceInfo> = listOf(),
    val padBy: Float = 10f,
    val startAtZero: Boolean = true
) {
    init {
        require(padBy in 0f..100f)
    }

    private val yMinMax: Pair<Float, Float>
        get() {
            val minDepositAmount = balanceInfoList.minByOrNull { it.depositAmount }?.depositAmount ?: 0f
            val maxDepositAmount = balanceInfoList.maxByOrNull { it.depositAmount }?.depositAmount ?: 0f
            val minInvestedAmount = balanceInfoList.minByOrNull { it.investedAmount }?.investedAmount ?: 0f
            val maxInvestedAmount = balanceInfoList.maxByOrNull { it.investedAmount }?.investedAmount ?: 0f

            val min = min(minDepositAmount.toFloat(), minInvestedAmount.toFloat()) / 10000
            val max = max(maxDepositAmount.toFloat(), maxInvestedAmount.toFloat()) / 10000

            return min to max
        }
    internal val maxYValue: Float
        get() {
            return yMinMax.second
        }

    internal val minYValue: Float
        get() {
            return if (startAtZero) {
                0f
            } else {
                yMinMax.first - ((yMinMax.second - yMinMax.first) * padBy / 100f)
            }
        }

    data class BalanceInfo(
        val depositAmount: Long = 0L,
        val investedAmount: Long = 0L,
        val balance: Long = 0L,
        val balanceMonth: String = "",
        var xPos: Float = 0f,
        var yPos: Float = 0f
    )
}

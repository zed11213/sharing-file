package jp.co.jsbank.mb.bankingapp.ui.widgets.barchart

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Card
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.theme.H3
import jp.co.jsbank.mb.bankingapp.theme.H8
import jp.co.jsbank.mb.bankingapp.theme.general_label_color
import jp.co.jsbank.mb.bankingapp.utils.FmtMicrometerUtil

@Composable
fun BarChartScreenContent(balanceInfoList: List<BarChartData.BalanceInfo>) {

    val curBalanceInfoList = remember(balanceInfoList) {
        balanceInfoList
    }

    val selectedIndex = remember { mutableStateOf(5) }

    Column(
        modifier = Modifier.padding(vertical = 8.dp)
    ) {
        Card(
            modifier = Modifier
                .padding(start = 16.dp, top = 0.dp, end = 50.dp, bottom = 10.dp)
                .weight(0.35f)
                .fillMaxWidth(),
            elevation = 10.dp,
            shape = RoundedCornerShape(20.dp),
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.SpaceBetween,
            ) {
                Row {
                    Text(
                        text = (
                            if (balanceInfoList.isNotEmpty())
                                balanceInfoList[selectedIndex.value].balanceMonth
                            else ""
                            ) + stringResource(id = R.string.balancePage_total),
                        fontSize = H8, color = general_label_color
                    )
                }
                Row(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.Bottom
                        ) {
                            Column {
                                Text(
                                    text = (
                                        if (balanceInfoList.isNotEmpty())
                                            balanceInfoList[selectedIndex.value].balanceMonth
                                        else ""
                                        ) + stringResource(id = R.string.balancePage_balance),
                                    fontSize = H8, color = general_label_color
                                )
                            }
                            Column {
                                Row(horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.Bottom) {
                                    Text(
                                        text = FmtMicrometerUtil.fmtMicrometer(
                                            if (balanceInfoList.isNotEmpty())
                                                balanceInfoList[selectedIndex.value].balance.toLong().toString()
                                            else "0"
                                        ),
                                        fontSize = H3,
                                        color = general_label_color
                                    )
                                    Text(
                                        text =
                                        stringResource(
                                            id = R.string.common_card_label_Yen
                                        ),
                                        fontSize = H8,
                                        color = general_label_color,
                                    )
                                }
                            }
                        }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Row(horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(
                                        modifier = Modifier.padding(end = 10.dp),
                                        text = stringResource(id = R.string.balancePage_deposit),
                                        fontSize = H8,
                                        color = general_label_color
                                    )
                                    Text(
                                        text = FmtMicrometerUtil.fmtMicrometer(
                                            if (balanceInfoList.isNotEmpty())
                                                balanceInfoList[selectedIndex.value].depositAmount.toLong().toString()
                                            else "0"
                                        ) +
                                            stringResource(id = R.string.common_card_label_Yen),
                                        fontSize = H8,
                                        color = general_label_color
                                    )
                                }
                                Row(
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier
                                        .padding(top = 10.dp),
                                ) {
                                    Text(
                                        modifier = Modifier.padding(end = 10.dp),
                                        text = stringResource(id = R.string.balancePage_invested),
                                        fontSize = H8,
                                        color = general_label_color
                                    )
                                    Text(
                                        text = FmtMicrometerUtil.fmtMicrometer(
                                            if (balanceInfoList.isNotEmpty())
                                                balanceInfoList[selectedIndex.value].investedAmount.toLong().toString()
                                            else "0"
                                        ) +
                                            stringResource(id = R.string.common_card_label_Yen),
                                        fontSize = H8,
                                        color = general_label_color
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
        BarChartRow(
            modifier = Modifier
                .weight(0.5f)
                .padding(bottom = 20.dp, start = 0.dp, end = 15.dp),
            curBalanceInfoList,
            onSelectedIndexChange = {
                selectedIndex.value = it
            }
        )
    }
}

@Composable
private fun BarChartRow(
    modifier: Modifier,
    curBalanceInfoList: List<BarChartData.BalanceInfo>,
    onSelectedIndexChange: (Int) -> Unit = {},
) {
    Row(
        modifier = modifier.fillMaxWidth()
    ) {
        BarChart(
            balanceInfoList = curBalanceInfoList,
            onSelectedIndexChange = {
                onSelectedIndexChange(it)
            }
        )
    }
}

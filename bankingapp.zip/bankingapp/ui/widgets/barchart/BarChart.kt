package jp.co.jsbank.mb.bankingapp.ui.widgets.barchart

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.AnimationSpec
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.animation.simpleChartAnimation
import jp.co.jsbank.mb.bankingapp.system.MyApp.Companion.SCREEN_WIDTH
import jp.co.jsbank.mb.bankingapp.ui.widgets.drawer.*
import jp.co.jsbank.mb.bankingapp.utils.BarChartUtil.axisAreas
import jp.co.jsbank.mb.bankingapp.utils.BarChartUtil.barDrawableArea
import jp.co.jsbank.mb.bankingapp.utils.BarChartUtil.forEachWithArea
import jp.co.jsbank.mb.bankingapp.utils.SizeUtil

@Composable
fun BarChart(
    balanceInfoList: List<BarChartData.BalanceInfo>,
    modifier: Modifier = Modifier,
    animation: AnimationSpec<Float> = simpleChartAnimation(),
    barDrawer: BarDrawer = SimpleBarDrawer(),
    xAxisDrawer: XAxisDrawer = SimpleXAxisDrawer(),
    yAxisDrawer: YAxisDrawer = SimpleYAxisDrawer(),
    labelDrawer: LabelDrawer = SimpleValueDrawer(),
    onSelectedIndexChange: (Int) -> Unit = {},
) {

    val transitionAnimation = remember(balanceInfoList) { Animatable(initialValue = 0f) }

    LaunchedEffect(balanceInfoList) {
        transitionAnimation.animateTo(1f, animationSpec = animation)
    }

    val progress = transitionAnimation.value

    val selectedIndex = remember { mutableStateOf(5) }

    Box {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Image(painter = painterResource(id = R.drawable.deposit_amount_barchart), contentDescription = null)
            Text(
                modifier = Modifier.padding(start = 5.dp, end = 20.dp),
                text = stringResource(id = R.string.balancePage_deposit_amount)
            )
            Image(painter = painterResource(id = R.drawable.invested_amount_barchart), contentDescription = null)
            Text(
                modifier = Modifier.padding(start = 5.dp, end = 20.dp),
                text = stringResource(id = R.string.balancePage_invested_amount)
            )
        }
        Canvas(
            modifier = modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures(
                        onTap = {
                            val i = identifyClickItem(it.x)
                            if (i >= 0) {
                                selectedIndex.value = i
                                onSelectedIndexChange(i)
                            }
                        }
                    )
                }
                .drawBehind {
                    drawIntoCanvas { canvas ->
                        val (xAxisArea) = axisAreas(
                            drawScope = this,
                            totalSize = size,
                            xAxisDrawer = xAxisDrawer,
                            labelDrawer = labelDrawer
                        )
                        val barDrawableArea = barDrawableArea(xAxisArea)

                        // Draw xAxis line.
                        xAxisDrawer.drawAxisLine(
                            drawScope = this,
                            canvas = canvas,
                            drawableArea = xAxisArea
                        )
                        // Draw each bar.
                        BarChartData(balanceInfoList = balanceInfoList).forEachWithArea(
                            this,
                            barDrawableArea,
                            progress,
                            labelDrawer,
                        ) { barArea, index, bar ->
                            bar.xPos = barArea[0].left
                            barDrawer.drawBar(
                                drawScope = this,
                                canvas = canvas,
                                barArea = barArea,
                                balanceInfo = bar,
                                selected = selectedIndex.value == index
                            )
                        }
                    }
                }
        ) {
            /**
             *  Typically we could draw everything here, but because of the lack of canvas.drawText
             *  APIs we have to use Android's `nativeCanvas` which seems to be drawn behind
             *  Compose's canvas.
             */
            drawIntoCanvas { canvas ->
                val (xAxisArea, yAxisArea) = axisAreas(
                    drawScope = this,
                    totalSize = size,
                    xAxisDrawer = xAxisDrawer,
                    labelDrawer = labelDrawer
                )
                val barDrawableArea = barDrawableArea(xAxisArea)

                BarChartData(balanceInfoList = balanceInfoList).forEachWithArea(
                    this,
                    barDrawableArea,
                    progress,
                    labelDrawer
                ) { barArea, _, bar ->
                    labelDrawer.drawLabel(
                        drawScope = this,
                        canvas = canvas,
                        label = bar.balanceMonth,
                        barAreaList = barArea,
                        xAxisArea = xAxisArea
                    )
                }

                yAxisDrawer.drawAxisLabels(
                    drawScope = this,
                    canvas = canvas,
                    minValue = BarChartData(balanceInfoList = balanceInfoList).minYValue,
                    maxValue = BarChartData(balanceInfoList = balanceInfoList).maxYValue,
                    xDrawableArea = xAxisArea,
                    yDrawableArea = yAxisArea
                )
            }
        }
    }
}

private fun identifyClickItem(x: Float): Int {
    val itemWith = SizeUtil.dp2px((SCREEN_WIDTH - 80).toFloat()) / 6
    return if (x / itemWith < 6) ((x / itemWith).toInt()) else -1
}

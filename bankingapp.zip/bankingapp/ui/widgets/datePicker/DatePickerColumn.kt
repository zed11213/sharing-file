package jp.co.jsbank.mb.bankingapp.ui.widgets.datePicker

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.Surface
import androidx.compose.material.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.click
import kotlinx.coroutines.launch

@Composable
fun DatePickerColumn(
    pairList: List<Pair<Int, String>>,
    itemHeight: Dp,
    itemWidth: Dp? = null,
    valueState: MutableState<Int>,
    focusColor: Color = Color.Black,
    unFocusColor: Color = Color(0xFFC5C7CF),
) {
    val dataPickerCoroutineScope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    var value by valueState
    LazyColumn(
        state = listState,
        modifier = Modifier
            .height(itemHeight * 6)
            .padding(top = itemHeight / 2, bottom = itemHeight / 2)
    ) {
        item {
            Surface(Modifier.height(itemHeight)) {}
        }
        item {
            Surface(Modifier.height(itemHeight)) {}
        }
        itemsIndexed(items = pairList, key = { _, pair -> pair.first }) { index, pair ->
            val widthModifier = itemWidth?.let { Modifier.width(itemWidth) } ?: Modifier
            Box(
                modifier = Modifier
                    .height(itemHeight)
                    .then(widthModifier)
                    .click {
                        dataPickerCoroutineScope.launch {
                            listState.animateScrollToItem(index = index)
                        }
                    }
                    .padding(start = 5.dp, end = 5.dp),
                Alignment.Center
            ) {
                Text(
                    text = pair.second,
                    color =
                    if (listState.firstVisibleItemIndex == index) focusColor
                    else unFocusColor
                )
            }
        }
        item {
            Surface(Modifier.height(itemHeight)) {}
        }
        item {
            Surface(Modifier.height(itemHeight)) {}
        }
    }

    /**
     * スライドイベント
     */
    if (listState.isScrollInProgress) {
        LaunchedEffect(Unit) {
            // 一度だけ呼び出されます。スクロール開始に相当します。
        }
        // stateがスクロールされている場合、presholStartOffsetは初期化されて記憶され、変更されません。
        val preScrollStartOffset by remember { mutableStateOf(listState.firstVisibleItemScrollOffset) }
        val preItemIndex by remember { mutableStateOf(listState.firstVisibleItemIndex) }
        val isScrollDown = when {
            listState.firstVisibleItemIndex > preItemIndex -> {
                // 最初の可視itemのindexは、スクロール開始時の最初の可視itemのindexよりも大きく、下にスクロールしたことを示します。
                true
            }
            listState.firstVisibleItemIndex < preItemIndex -> {
                // 最初の可視itemのindexは、スクロール開始時に最初に可視itemのindexよりも小さく、スクロールしたことを示します。
                false
            }
            else -> {
                // 最初の可視itemのindexは、スクロール開始時に最初の可視itemのindexに等しく、item offsetと比較する
                listState.firstVisibleItemScrollOffset > preScrollStartOffset
            }
        }

        DisposableEffect(Unit) {
            onDispose {
                // スライド終了時にステータスに値を割り当て、自動的に位置合わせします。
                value = pairList[listState.firstVisibleItemIndex].first
                dataPickerCoroutineScope.launch {
                    listState.animateScrollToItem(listState.firstVisibleItemIndex)
                }
            }
        }
    }

    // 初期値の選択
    LaunchedEffect(Unit) {
        var initIndex = 0
        for (index in pairList.indices) {
            if (value == pairList[index].first) {
                initIndex = index
                break
            }
        }
        dataPickerCoroutineScope.launch {
            listState.animateScrollToItem(initIndex)
        }
    }
}

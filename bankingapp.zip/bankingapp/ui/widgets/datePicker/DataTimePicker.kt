package jp.co.jsbank.mb.bankingapp.ui.widgets.datePicker

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.Divider
import androidx.compose.material.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.util.*
import jp.co.jsbank.mb.bankingapp.utils.*

@Composable
fun DataTimePicker(
    year: Int,
    month: Int,
    day: Int = 1,
    type: Int = 0,
) {
    val itemHeight = 50.dp
    Box(
        modifier = Modifier
            .wrapContentHeight()
            .fillMaxWidth(),
        Alignment.Center
    ) {
        Row(
            Modifier
                .wrapContentHeight()
                .fillMaxWidth()
                .background(MaterialTheme.colors.surface),
            Arrangement.SpaceEvenly,
            Alignment.CenterVertically
        ) {
            val selectYear = rememberSaveable { mutableStateOf(year) }
            val years = LinkedList<Pair<Int, String>>().apply {
                for (i in 2200 downTo 1900) {
                    add(Pair(i, "${i}年"))
                }
            }
            DatePickerColumn(years, itemHeight, 70.dp, selectYear)
//            LogPrintUtil.error(selectYear.toString())

            // 月
            val selectMonth = rememberSaveable { mutableStateOf(month) }
            val months = ArrayList<Pair<Int, String>>(12).apply {
                for (i in 1..12) {
                    add(Pair(i, "${i}月"))
                }
            }
            DatePickerColumn(months, itemHeight, 50.dp, selectMonth)
//            LogPrintUtil.error(selectMonth.toString())

            // 年月のみ場合、日のセレクトが表示しない
            if (type == 0) {
                //  月の日数
                val selectDay = rememberSaveable { mutableStateOf(day) }
                val dayCountOfMonth = DateUtil.getDayCountOfMonth(selectYear.value, selectMonth.value)
                val dayOfMonList = getDayMaxCount(count = dayCountOfMonth)

                // 日
                DatePickerColumn(
                    pairList = dayOfMonList,
                    itemHeight = itemHeight,
                    valueState = selectDay
                )
//                LogPrintUtil.error(dayCountOfMonth.toString())
            }
        }

        Column {
            Divider(
                Modifier.padding(
                    start = 15.dp,
                    end = 15.dp,
                    bottom = itemHeight
                ),
                thickness = 1.dp
            )
            Divider(
                Modifier.padding(
                    start = 15.dp,
                    end = 15.dp
                ),
                thickness = 1.dp
            )
        }
    }
}

@Composable
private fun getDayMaxCount(count: Int): ArrayList<Pair<Int, String>> {
    return ArrayList<Pair<Int, String>>().apply {
        for (i in 1..count)
            add(Pair(i, "${i}日"))
    }
}

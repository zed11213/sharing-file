package jp.co.jsbank.mb.bankingapp.ui.widgets.tabBar

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Card
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.bean.common.ElectronicDeliveryTabBean
import jp.co.jsbank.mb.bankingapp.system.MyApp.Companion.SCREEN_WIDTH
import jp.co.jsbank.mb.bankingapp.theme.*
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.click
import androidx.compose.ui.text.font.FontWeight

/**
 * 電子交付用のタブ
 *
 * @param title タイトル
 * @param dataList データリスト
 * @param selectedColor 選択するタブの文字の色
 * @param unSelectedColor 選択しないタブの文字の色
 * @param selectedIndex 選択するタブインデックス
 * @param onClick クリックイベント
 */
@Composable
fun ElectronicDeliveryTab(
    title1: String = stringResource(id = R.string.mbdr_tab_label_deposit_number), // お預り番号
    title2: String = stringResource(id = R.string.mbdr_tab_label_account_number), // 口座番号
    dataList: List<ElectronicDeliveryTabBean>,
    selectedColor: Color = prominent_label_color,
    unSelectedColor: Color = account_detail_label_color,
    selectedIndex: Int = 0,
    showDepositNumber: Boolean = true, //追加：お預り番号を表示するかどうか
    showAccountNo: Boolean = true, // 口座番号を表示するかどうか
    onClick: (Int) -> Unit
) {

    LazyRow(state = rememberLazyListState(), content = {
        items(count = dataList.size, itemContent = { index ->
            Card(
                modifier = Modifier
                    .width((SCREEN_WIDTH / 2 - 10).dp)
                    .wrapContentSize()
                    .click {
                        onClick.invoke(index)
                    },
                elevation = if (selectedIndex == index) 1.dp else 0.dp,
                backgroundColor = if (selectedIndex == index) Color.White else app_bar_background_color,
                shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
            ) {
                Column(
                    modifier = Modifier
                        .padding(10.dp)
                        .fillMaxWidth()
                ) {
                    // 種類
                    Row(horizontalArrangement = Arrangement.Absolute.Right, verticalAlignment = Alignment.Top) {
                        Text(
                            color = if (selectedIndex == index) selectedColor else unSelectedColor,
                            text = dataList[index].type,
                            fontWeight = FontWeight.Bold,
                            fontSize = H7,
                            modifier = Modifier
                                .padding(start = 10.dp, end = 0.dp)
                        )
                    }

                    // 口座番号、お預り番号
                    Row(horizontalArrangement = Arrangement.Absolute.Center, verticalAlignment = Alignment.Bottom) {
                        if (showAccountNo) {
                            // 口座番号（左下、スーパードリームMBDR0101, MBDR0201では非表示）
                            Column(
                                horizontalAlignment = Alignment.Start, // 左側に寄せる
                                modifier = Modifier.padding(start = 0.dp, bottom = 0.dp))
                            {
                                Text(
                                    color = if (selectedIndex == index) selectedColor else unSelectedColor,
                                    text = title2, // 口座番号label
                                    fontSize = H8,
                                    modifier = Modifier
                                        .padding(start = 0.dp)
                                )

                                Text(
                                    color = if (selectedIndex == index) selectedColor else unSelectedColor,
                                    text = dataList[index].accountNo, // 口座番号
                                    fontWeight = FontWeight.Bold,
                                    fontSize = H3,
                                    modifier = Modifier
                                        .padding(start = 0.dp)
                                )
                            }
                        }

                        // お預り番号
                        Column(
                            horizontalAlignment = Alignment.End, // 右側に寄せる
                            modifier = Modifier.padding(end = 0.dp, bottom = 0.dp))
                        {
                            // お預り番号（右下、「定期積金満期のご案内」では非表示）
                            if (showDepositNumber) {
                                Text(
                                    color = if (selectedIndex == index) selectedColor else unSelectedColor,
                                    text = title1, // お預り番号label
                                    fontSize = H8,
                                    modifier = Modifier
                                        .padding(end = 0.dp)
                                )

                                Text(
                                    color = if (selectedIndex == index) selectedColor else unSelectedColor,
                                    text = dataList[index].code, // お預り番号
                                    fontWeight = FontWeight.Bold,
                                    fontSize = H3, // フォントサイズ統一（口座番号と同じ）
                                    modifier = Modifier
                                        .padding(end = 0.dp)
                                )
                            }
                        }
                    }
                }
            }
        })
    })
}

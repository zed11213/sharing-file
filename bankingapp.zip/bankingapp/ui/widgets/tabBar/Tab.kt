package jp.co.jsbank.mb.bankingapp.ui.widgets.tabBar

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Divider
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import jp.co.jsbank.mb.bankingapp.theme.H6
import jp.co.jsbank.mb.bankingapp.theme.account_detail_label_color
import jp.co.jsbank.mb.bankingapp.theme.prominent_label_color
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.click

/**
 * タブバー
 */
@Composable
fun Tab(
    modifier: Modifier = Modifier,
    state: Int = 1,
    list: List<String>
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 10.dp)
    ) {

        list.forEachIndexed { index, s ->
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                Row(
                    Modifier
                        .fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        s,
                        fontSize = 13.sp,
                        color = if (state == index + 1) Color(0xFF121212) else Color(0xFFDEDEDE)
                    )
                }
                Divider(
                    modifier = Modifier.padding(
                        horizontal = 10.dp,
                        vertical = 5.dp
                    ),
                    color = if (state >= index + 1) Color(0xFFE6AAAB) else Color(0xFFDEDEDE), thickness = 3.dp
                )
            }
        }
    }
}

@Composable
fun SwitchTab(
    modifier: Modifier = Modifier,
    tabType: Int = 0,
    firstType: String = "",
    secondType: String = "",
    firstOnClick: () -> Unit,
    secondOnClick: () -> Unit,
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(100))
            .background(Color(0xFFD9D8D4))
            .wrapContentSize()
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(2.dp)
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(100))
                    .background(
                        if (tabType == 0) Color.White else Color.Transparent
                    )
                    .wrapContentSize()
                    .click {
                        firstOnClick.invoke()
                    }
            ) {
                Text(
                    color = if (tabType == 0) prominent_label_color
                    else account_detail_label_color,
                    text = firstType,
                    fontSize = H6,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(horizontal = 40.dp, vertical = 7.dp),
                )
            }
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(100))
                    .background(
                        if (tabType == 1) Color.White else Color.Transparent
                    )
                    .wrapContentSize()
                    .click {
                        secondOnClick.invoke()
                    }
            ) {
                Text(
                    color = if (tabType == 1) prominent_label_color
                    else account_detail_label_color,
                    text = secondType,
                    fontSize = H6,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(horizontal = 40.dp, vertical = 7.dp),
                )
            }
        }
    }
}

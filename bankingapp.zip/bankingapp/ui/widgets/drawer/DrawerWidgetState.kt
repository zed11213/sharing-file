package jp.co.jsbank.mb.bankingapp.ui.widgets.drawer

import android.os.Parcelable
import java.time.LocalDate
import kotlinx.android.parcel.Parcelize

/**
 * ステータス.
 */
data class DrawerWidgetState(

    /**
     * 初期化フラグ
     */
    var initFlag: Boolean = true,

    /**
     * 期間終了日ダイアログ
     */
    var dateToDialogFlag: Boolean = false,

    /**
     * 期間開始日(画面表示用)
     */
    var dateFrom: LocalDate = LocalDate.now().plusMonths(-5),

    /**
     * 期間終了日(画面表示用)
     */
    var dateTo: LocalDate = LocalDate.now(),
)

@Parcelize
data class DataInfo(

    /**
     * 期間開始日(画面表示用)
     */
    var dateFrom: LocalDate = LocalDate.now().plusMonths(-5),

    /**
     * 期間終了日(画面表示用)
     */
    var dateTo: LocalDate = LocalDate.now(),
) : Parcelable

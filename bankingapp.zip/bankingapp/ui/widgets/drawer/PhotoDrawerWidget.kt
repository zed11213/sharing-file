package jp.co.jsbank.mb.bankingapp.ui.widgets.drawer

import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.theme.H5
import jp.co.jsbank.mb.bankingapp.theme.general_label_color
import jp.co.jsbank.mb.bankingapp.theme.inactive_font_color
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.click
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.SELECT_PHOTO
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.TAKE_PHOTO
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

/**
 * 写真を撮る、画像を選択する引き出し
 *
 * @param drawerState 引き出しステータス
 * @param backClick コールバック
 * @param scope スコープ
 * @param content 内容
 */
@OptIn(ExperimentalMaterialApi::class)
@Composable
fun PhotoDrawerWidget(
    drawerState: BottomDrawerState = rememberBottomDrawerState(BottomDrawerValue.Closed),
    backClick: (Int) -> Unit,
    scope: CoroutineScope = rememberCoroutineScope(),
    content: @Composable () -> Unit,
) {
    MaterialTheme {
        BottomDrawer(
            drawerState = drawerState,
            drawerBackgroundColor = Color.Transparent,
            drawerElevation = 100.dp,
            gesturesEnabled = false,
            drawerContent = {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp),
                    elevation = 4.dp
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth(),
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.Start,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 20.dp, vertical = 10.dp)
                                .weight(1.0f)
                        ) {
                            Text(
                                text = stringResource(id = R.string.mbop1401_page_drawer_title),
                                color = inactive_font_color,
                                fontSize = H5
                            )
                        }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 20.dp, vertical = 5.dp)
                                .weight(1.0f)
                                .click {
                                    // 写真を撮る
                                    backClick(TAKE_PHOTO)
                                }
                        ) {
                            Text(
                                text = stringResource(id = R.string.mbop1401_page_take_photo),
                                color = general_label_color,
                                fontSize = H5
                            )
                        }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 20.dp, vertical = 5.dp)
                                .weight(1.0f)
                                .click {
                                    // アルバムから選択する
                                    backClick(SELECT_PHOTO)
                                }
                        ) {
                            Text(
                                text = stringResource(id = R.string.mbop1401_page_select_photo),
                                color = general_label_color,
                                fontSize = H5
                            )
                        }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 20.dp, vertical = 5.dp)
                                .weight(1.0f)
                                .click {
                                    scope.launch {
                                        drawerState.close()
                                    }
                                }
                        ) {
                            Text(
                                text = stringResource(id = R.string.mbop1401_page_cancel),
                                color = general_label_color,
                                fontSize = H5
                            )
                        }
                    }
                }
            }
        ) {
            content()
        }
    }
}

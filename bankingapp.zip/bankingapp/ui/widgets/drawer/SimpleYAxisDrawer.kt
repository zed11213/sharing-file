package jp.co.jsbank.mb.bankingapp.ui.widgets.drawer

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Canvas
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.PaintingStyle
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import jp.co.jsbank.mb.bankingapp.system.MyApp.Companion.SCREEN_WIDTH
import jp.co.jsbank.mb.bankingapp.theme.H8
import jp.co.jsbank.mb.bankingapp.theme.simple_light_gray_color
import jp.co.jsbank.mb.bankingapp.theme.text_color
import jp.co.jsbank.mb.bankingapp.utils.BarChartUtil.getAxisStep
import jp.co.jsbank.mb.bankingapp.utils.BarChartUtil.getStep
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.DOT
import jp.co.jsbank.mb.bankingapp.utils.FmtMicrometerUtil.fmtMicrometer
import jp.co.jsbank.mb.bankingapp.utils.toLegacyInt

typealias LabelFormatter = (value: Float) -> String

class SimpleYAxisDrawer(
    private val labelTextSize: TextUnit = H8,
    private val labelTextColor: Color = text_color,
    private val labelValueFormatter: LabelFormatter = { value -> "%.1f".format(value) },
    private val axisLineThickness: Dp = 1.dp,
    private val axisLineColor: Color = simple_light_gray_color
) : YAxisDrawer {
    private val axisLinePaint = Paint().apply {
        isAntiAlias = true
        color = axisLineColor
        style = PaintingStyle.Stroke
    }
    private val textPaint = android.graphics.Paint().apply {
        isAntiAlias = true
        color = labelTextColor.toLegacyInt()
    }
    private val textBounds = android.graphics.Rect()

    override fun drawAxisLine(
        drawScope: DrawScope,
        canvas: Canvas,
        drawableArea: Rect
    ) = with(drawScope) {
        val lineThickness = axisLineThickness.toPx()
        val x = drawableArea.right - (lineThickness / 2f)

        canvas.drawLine(
            p1 = Offset(
                x = x,
                y = drawableArea.top
            ),
            p2 = Offset(
                x = x,
                y = drawableArea.bottom
            ),
            paint = axisLinePaint.apply {
                strokeWidth = lineThickness
            }
        )
    }

    override fun drawAxisLabels(
        drawScope: DrawScope,
        canvas: Canvas,
        xDrawableArea: Rect,
        yDrawableArea: Rect,
        minValue: Float,
        maxValue: Float
    ) = with(drawScope) {
        val labelPaint = textPaint.apply {
            textSize = labelTextSize.toPx()
            textAlign = android.graphics.Paint.Align.LEFT
        }
        var newMaxValue = maxValue
        if (maxValue < 1) newMaxValue *= 10000
        val totalHeight = yDrawableArea.height
        if (newMaxValue.toInt() != 0 && maxValue < 1 && maxValue * 10000 < 10) {
            newMaxValue = 9f
        }
        val average = getAxisStep(newMaxValue.toDouble())
        val labelCount = getStep(newMaxValue.toDouble())

        for (i in 0..labelCount) {
            val value = average * i
            val label = labelValueFormatter(value.toFloat())
            val x = (SCREEN_WIDTH - 95).dp.toPx()
            val y = yDrawableArea.bottom - (i * (totalHeight / labelCount)) + (textBounds.height() / 2f)
            labelPaint.getTextBounds(label, 0, label.length, textBounds)
            if (labelCount * average > 0) {
                if (i in 1 until labelCount) {
                    for (j in (xDrawableArea.left).toInt()..(xDrawableArea.right - 32).toInt()) {
                        if (j % 10 == 0) {
                            canvas.drawLine(
                                p1 = Offset(
                                    x = j.toFloat(),
                                    y = y - 12
                                ),
                                p2 = Offset(
                                    x = if ((j + 5).toFloat() > (xDrawableArea.right - 32))
                                        xDrawableArea.right - 32
                                    else (j + 5).toFloat(),
                                    y = y - 12
                                ),
                                paint = axisLinePaint.apply {
                                    strokeWidth = 0.5.dp.toPx()
                                }
                            )
                        }
                    }
                }
            }

            if (i == 0) {
                canvas.nativeCanvas.drawText("0", x, y, labelPaint)
            } else {
                if (i < labelCount && labelCount * average > 0) {
                    if (maxValue < 1) {
                        if (label.split(DOT)[1].takeLast(1) == "0") {
                            canvas.nativeCanvas.drawText("${fmtMicrometer(label.split(DOT)[0])}円", x, y, labelPaint)
                        } else {
                            canvas.nativeCanvas.drawText("${label}円", x, y, labelPaint)
                        }
                    } else {
                        if (label.toDouble() >= 1) {
                            if (label.split(DOT)[1].takeLast(1) == "0") {
                                canvas.nativeCanvas.drawText(
                                    "${fmtMicrometer(label.split(DOT)[0])}万円",
                                    x,
                                    y,
                                    labelPaint
                                )
                            } else {
                                canvas.nativeCanvas.drawText("${(label)}万円", x, y, labelPaint)
                            }
                        } else {
                            canvas.nativeCanvas.drawText(
                                "${(fmtMicrometer((label.toDouble() * 10000).toString().split(DOT)[0]))}円",
                                x,
                                y,
                                labelPaint
                            )
                        }
                    }
                }
            }
        }
    }
}

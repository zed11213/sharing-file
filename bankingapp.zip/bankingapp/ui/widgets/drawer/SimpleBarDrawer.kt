package jp.co.jsbank.mb.bankingapp.ui.widgets.drawer

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Canvas
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.PaintingStyle
import androidx.compose.ui.graphics.drawscope.DrawScope
import jp.co.jsbank.mb.bankingapp.theme.*
import jp.co.jsbank.mb.bankingapp.ui.widgets.barchart.BarChartData

class SimpleBarDrawer : BarDrawer {
    private val barPaint = Paint().apply {
        this.isAntiAlias = true
    }
    private val selectedLineColor: Color = prominent_label_color

    private val selectedLinePaint = Paint().apply {
        isAntiAlias = true
        color = selectedLineColor
        style = PaintingStyle.Stroke
    }

    override fun drawBar(
        drawScope: DrawScope,
        canvas: Canvas,
        barArea: List<Rect>,
        balanceInfo: BarChartData.BalanceInfo,
        selected: Boolean,
    ) {
        barArea.forEachIndexed { index, item ->
            if (index < 2) {
                canvas.drawRect(
                    item,
                    barPaint.apply {
                        color = if (index == 0) {
                            if (selected) deposit_amount_label_color else deposit_amount_label_color_unSelect
                        } else {
                            if (selected) prominent_label_color else prominent_label_color_unSelect
                        }
                    }
                )
            } else {
                if (selected) {
                    for (j in (item.top).toInt()..(item.bottom).toInt()) {
                        if (j % 10 == 0) {
                            canvas.drawLine(
                                p1 = Offset(
                                    x = item.left,
                                    y = j.toFloat()
                                ),
                                p2 = Offset(
                                    x = item.left,
                                    y = if ((j + 5).toFloat() > item.bottom)
                                        item.bottom
                                    else (j + 5).toFloat()
                                ),
                                paint = selectedLinePaint.apply {
                                    strokeWidth = 2f
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

package jp.co.jsbank.mb.bankingapp.ui.widgets.drawer

import android.annotation.SuppressLint
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.logic.common.DrawerWidgetLogic
import jp.co.jsbank.mb.bankingapp.theme.H5
import jp.co.jsbank.mb.bankingapp.theme.general_label_color
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.PrimaryButton
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.click
import jp.co.jsbank.mb.bankingapp.ui.widgets.dialog.DatePickerDiaLog
import jp.co.jsbank.mb.bankingapp.ui.widgets.select.DateSelectWidget
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.DATE_FORMAT_CHARACTERS_YYYY_MM
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.DATE_FORMAT_CHARACTERS_yyyy_MM
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

@SuppressLint("WeekBasedYear")
@OptIn(ExperimentalMaterialApi::class)
@Composable
fun DrawerWidget(
    drawerState: BottomDrawerState = rememberBottomDrawerState(BottomDrawerValue.Closed),
    backClick: (DataInfo) -> Unit,
    scope: CoroutineScope = rememberCoroutineScope(),
    viewModel: DrawerWidgetLogic = hiltViewModel(),
    dateTo: LocalDate = LocalDate.now(),
    content: @Composable () -> Unit,
) {
    val viewStates = viewModel.viewStates

    if (viewStates.initFlag) {
        viewModel.doInit(dateTo)
    }

    // 期間終了日ダイアログ
    if (viewStates.dateToDialogFlag) {
        DatePickerDiaLog(
            text = stringResource(id = R.string.balance_date_picker_dialog_date_to_day),
            type = 1,
            value = viewStates.dateTo,
            onDateSelected = {
                viewModel.changeDateDuration(it)
            },
            onDismissRequest = {
                viewModel.closeDateToDialog()
            }
        )
    }
    MaterialTheme {
        BottomDrawer(
            drawerState = drawerState,
            drawerBackgroundColor = Color.Transparent,
            drawerElevation = 100.dp,
            gesturesEnabled = false,
            drawerContent = {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(500.dp),
                    shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
                    elevation = 4.dp
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth(),
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 20.dp, vertical = 10.dp)
                        ) {
                            Spacer(Modifier)
                            Text(
                                text = stringResource(id = R.string.balance_date_picker_dialog_scope_assignment),
                                color = general_label_color,
                                fontSize = H5
                            )
                            Icon(
                                Icons.Default.Close,
                                contentDescription = "",
                                tint = Color(0xFFE84F4F),
                                modifier = Modifier
                                    .click {
                                        scope.launch { drawerState.close() }
                                    },
                            )
                        }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 20.dp, vertical = 5.dp)
                        ) {
                            Text(
                                text = stringResource(id = R.string.balance_date_picker_dialog_remark),
                                color = general_label_color,
                                fontSize = H5
                            )
                        }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.fillMaxWidth()) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 20.dp, vertical = 5.dp)
                                ) {
                                    Text(stringResource(id = R.string.balance_date_picker_dialog_date_from))
                                }
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(50.dp)
                                        .padding(horizontal = 20.dp, vertical = 0.dp)
                                ) {
                                    DateSelectWidget(
                                        value = viewStates.dateFrom.format(
                                            DateTimeFormatter.ofPattern(DATE_FORMAT_CHARACTERS_YYYY_MM)
                                        ),
                                        enabled = false,
                                        disabledShowValue = true
                                    ) {}
                                }
                            }
                        }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.fillMaxWidth()) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 20.dp, vertical = 5.dp)
                                ) {
                                    Text(stringResource(id = R.string.balance_date_picker_dialog_date_to))
                                }
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(50.dp)
                                        .padding(horizontal = 20.dp, vertical = 0.dp)
                                ) {
                                    DateSelectWidget(
                                        viewStates.dateTo.format(
                                            DateTimeFormatter.ofPattern(DATE_FORMAT_CHARACTERS_yyyy_MM)
                                        ),
                                    ) {
                                        viewModel.openDateToDialog()
                                    }
                                }
                            }
                        }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 20.dp, vertical = 25.dp)
                        ) {
                            PrimaryButton(text = stringResource(R.string.common_page_button_set)) {
                                backClick(DataInfo(dateFrom = viewStates.dateFrom, viewStates.dateTo))
                                scope.launch { drawerState.close() }
                            }
                        }
                    }
                }
            }
        ) {
            content()
        }
    }
}

package jp.co.jsbank.mb.bankingapp.ui.widgets.drawer

import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Canvas
import androidx.compose.ui.graphics.drawscope.DrawScope
import jp.co.jsbank.mb.bankingapp.ui.widgets.barchart.BarChartData

interface BarDrawer {
    fun drawBar(
        drawScope: DrawScope,
        canvas: Canvas,
        barArea: List<Rect>,
        balanceInfo: BarChartData.BalanceInfo,
        selected: Boolean
    )
}

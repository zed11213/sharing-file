package jp.co.jsbank.mb.bankingapp.ui.widgets.drawer

import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Canvas
import androidx.compose.ui.graphics.drawscope.DrawScope

interface YAxisDrawer {
    fun drawAxisLine(
        drawScope: DrawScope,
        canvas: Canvas,
        drawableArea: Rect
    )

    fun drawAxisLabels(
        drawScope: DrawScope,
        canvas: Canvas,
        xDrawableArea: Rect,
        yDrawableArea: Rect,
        minValue: Float,
        maxValue: Float
    )
}

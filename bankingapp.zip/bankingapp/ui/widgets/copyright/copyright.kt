package jp.co.jsbank.mb.bankingapp.ui.widgets.copyright

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp
import jp.co.jsbank.mb.bankingapp.R

/**
 * 著作権
 *
 * @param modifier 修飾子
 */
@Composable
fun Copyright(
    modifier: Modifier = Modifier,
    text: String = stringResource(id = R.string.common_johnan_copyright),
    size: TextUnit = 10.sp
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = text,
            fontSize = size,
            textAlign = TextAlign.Center
        )
    }
}

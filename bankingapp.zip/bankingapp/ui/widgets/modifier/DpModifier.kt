package jp.co.jsbank.mb.bankingapp.ui.widgets.modifier

import android.content.res.Resources
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * DP.
 *
 */
class DpModifier() {
    fun Int.wdp(): Dp {
        val screenDp =
            Resources.getSystem().displayMetrics.widthPixels / Resources.getSystem().displayMetrics.density
        return (this.toFloat() / 400 * screenDp).dp
    }

    fun Int.wsp(): TextUnit {
        val screenDp =
            Resources.getSystem().displayMetrics.widthPixels / Resources.getSystem().displayMetrics.density
        return (this.toFloat() / 750 * screenDp).sp
    }

    fun Int.hdp(): Dp {
        val screenDp =
            Resources.getSystem().displayMetrics.heightPixels / Resources.getSystem().displayMetrics.density
        return (this.toFloat() / 400 * screenDp).dp
    }

    fun Int.hsp(): TextUnit {
        val screenDp =
            Resources.getSystem().displayMetrics.heightPixels / Resources.getSystem().displayMetrics.density
        return (this.toFloat() / 750 * screenDp).sp
    }
}

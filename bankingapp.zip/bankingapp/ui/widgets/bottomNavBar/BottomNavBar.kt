package jp.co.jsbank.mb.bankingapp.ui.widgets.bottomNavBar

import androidx.compose.foundation.background
import androidx.compose.material.BottomNavigation
import androidx.compose.material.BottomNavigationItem
import androidx.compose.material.Icon
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.currentBackStackEntryAsState
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.BottomNavRoute
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName

@Composable
fun BottomNavBar(navCtrl: NavHostController) {
    val bottomNavList = listOf(
        BottomNavRoute.Home,
        BottomNavRoute.Balance,
        BottomNavRoute.Help,
        BottomNavRoute.Menu
    )
    BottomNavigation {
        val navBackStackEntry by navCtrl.currentBackStackEntryAsState()
        val currentDestination = navBackStackEntry?.destination
        bottomNavList.forEach { screen ->
            BottomNavigationItem(
                modifier = Modifier.background(Color.White),
                icon = {
                    Icon(
                        painter = painterResource(
                            id = when (screen.routeName) {
                                RouteName.HOME -> {
                                    R.drawable.bottom_home
                                }
                                RouteName.BALANCE -> {
                                    R.drawable.bottom_balance
                                }
                                RouteName.HELP -> {
                                    R.drawable.bottom_help
                                }
                                else -> R.drawable.bottom_menu
                            }
                        ),
                        contentDescription = null,
                    )
                },
                label = { Text(text = stringResource(screen.stringId)) },
                selected = currentDestination?.hierarchy?.any {
                    (
                        if (it.route != RouteName.HOME &&
                            it.route != RouteName.BALANCE &&
                            it.route != RouteName.HELP &&
                            it.route != RouteName.MENU
                        ) MainActivity.BOTTOMBAR_ID else it.route
                        ) == screen.routeName
                } == true,
                onClick = {
                    if (currentDestination?.route != screen.routeName
//                        && MainActivity.BOTTOMBAR_ID != screen.routeName
                    ) {
                        navCtrl.navigate(screen.routeName) {
                            popUpTo(navCtrl.graph.findStartDestination().id) {
                                saveState = false
                            }
                            launchSingleTop = true
                            restoreState = true
                        }
                    }
                },
                selectedContentColor = Color(0xFFCE3F52),
                unselectedContentColor = Color(0xFF949391)
            )
        }
    }
}

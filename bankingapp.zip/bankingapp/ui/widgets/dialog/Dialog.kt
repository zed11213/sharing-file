package jp.co.jsbank.mb.bankingapp.ui.widgets.dialog

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ClipboardManager
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.system.MyApp
import jp.co.jsbank.mb.bankingapp.system.MyApp.Companion.SCREEN_HEIGHT
import jp.co.jsbank.mb.bankingapp.theme.*
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.AppButton
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.IconButton
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.PrimaryButton
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.SingleTextButton
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.click
import jp.co.jsbank.mb.bankingapp.ui.widgets.common.MediumTitle
import jp.co.jsbank.mb.bankingapp.ui.widgets.common.TextContent
import jp.co.jsbank.mb.bankingapp.ui.widgets.copyright.Copyright
import jp.co.jsbank.mb.bankingapp.ui.widgets.datePicker.DatePickerColumn
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.DELIVERY_SELECT
import jp.co.jsbank.mb.bankingapp.utils.DateUtil
import jp.co.jsbank.mb.bankingapp.utils.PreferenceUtil
import jp.co.jsbank.mb.bankingapp.utils.showToast
import java.time.LocalDate
import java.time.LocalDate.now
import java.util.*

/**
 * ダイアログ.
 *
 * @param title タイトル
 * @param content 表示内容
 * @param cancelText キャンセルボタン名称
 * @param confirmText 確定ボタン名称
 * @param onConfirmClick 確定ボタンクッリクバックアップ
 * @param onDismiss キャンセルボタンバックアップ
 */
@Composable
fun SampleAlertDialog(
    title: String,
    content: String,
    cancelText: String = "いいえ",
    confirmText: String = "はい",
    hasCancel: Boolean = true,
    onConfirmClick: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        properties = DialogProperties(dismissOnClickOutside = false),
        title = {},
        text = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth()
            ) {
                if (title.isNotBlank()) {
                    Box(modifier = Modifier.padding(bottom = 20.dp)) {
                        MediumTitle(title = title)
                    }
                }
                Box(modifier = Modifier.padding(bottom = 40.dp)) {
                    TextContent(text = content, textAlign = TextAlign.Start)
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    PrimaryButton(
                        text = confirmText,
                        modifier = if (confirmText.length > 3) Modifier.weight(2.0f) else Modifier
                            .weight(1.0f)
                            .padding(end = 10.dp)
                    ) {
                        onConfirmClick.invoke()
                    }
                    if (hasCancel) {
                        AppButton(
                            text = cancelText,
                            modifier = Modifier
                                .weight(1.0f)
                                .padding(start = 10.dp),
                            bgColor = Color(0xFF949391),
                            textColor = Color.White
                        ) {
                            onDismiss.invoke()
                        }
                    }
                }
            }
        },
        onDismissRequest = onDismiss,
        confirmButton = {},
        modifier = Modifier
            .padding(horizontal = 0.dp)
            .fillMaxWidth()
            .wrapContentHeight()
    )
}

/**
 * 普通な内容一覧のダイアログ.
 *
 * @param title タイトル
 * @param content 表示内容
 * @param onDismiss キャンセルボタンバックアップ
 */
@Composable
fun SimpleDetailDialog(
    title: String,
    content: String,
    onDismiss: () -> Unit
) {
    AlertDialog(
        properties = DialogProperties(dismissOnClickOutside = false),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                MediumTitle(title = title)
                Box(contentAlignment = Alignment.CenterEnd, modifier = Modifier.fillMaxWidth()) {
                    Icon(
                        Icons.Default.Close, contentDescription = "close",
                        modifier = Modifier
                            .click {
                                onDismiss.invoke()
                            },
                        tint = Color.Red
                    )
                }
            }
        },
        text = {
            TextContent(text = content)
        },
        onDismissRequest = onDismiss,
        confirmButton = { },
        modifier = Modifier
            .padding(horizontal = 10.dp)
            .fillMaxWidth()
            .wrapContentHeight(),
        shape = RoundedCornerShape(20.dp),
    )
}

/**
 * ヘッダ部が画像のダイアログ.
 *
 * @param image 画像ID
 * @param imageSize 画像サイズ
 * @param title タイトル
 * @param content 表示内容
 * @param errorCode エラーコード
 * @param buttonLabel ボタンラベル
 * @param onButtonClick ボタンバックアップ
 */
@Composable
fun ImageHeadDialog(
    image: Int,
    imageSize: Int,
    title: String,
    content: String,
    errorCode: String = "",
    buttonLabel: String,
    onButtonClick: () -> Unit
) {
    val context = LocalContext.current
    val launcher =
        rememberLauncherForActivityResult(contract = ActivityResultContracts.StartActivityForResult()) {}
    val clipboardManager = LocalClipboardManager.current
    AlertDialog(
        properties = DialogProperties(dismissOnClickOutside = false),
        title = {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                Image(
                    modifier = Modifier.requiredSize(imageSize.dp),
                    painter = painterResource(id = image),
                    contentDescription = ""
                )
            }
        },
        text = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth()
            ) {
                if (title.isNotBlank()) {
                    Box(modifier = Modifier.padding(bottom = 20.dp)) {
                        MediumTitle(title = title)
                    }
                }
                Box(modifier = Modifier.padding(bottom = 40.dp)) {
                    val msgSplit = content.split("\n\n")
                    when (msgSplit.size) {
                        0, 1 -> {
                            TextContent(text = content, textAlign = TextAlign.Start, fontSize = 12.sp)
                        }
                        2 -> {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .fillMaxWidth()
                            ) {
                                TextContent(
                                    text = msgSplit[0],
                                    textAlign = TextAlign.Start,
                                )
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        horizontalArrangement = Arrangement.Center,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        TextContent(
                                            text = msgSplit[1],
                                            fontSize = 12.sp,
                                            textAlign = TextAlign.Start,
                                        )
                                        copy(clipboardManager, msgSplit[1])
                                    }
                                }
                            }
                        }
                        3 -> {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .fillMaxWidth()
                            ) {
                                TextContent(
                                    text = msgSplit[0],
                                    textAlign = TextAlign.Start,
                                )
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        horizontalArrangement = Arrangement.Center,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        TextContent(
                                            text = msgSplit[1],
                                            fontSize = 12.sp,
                                            textAlign = TextAlign.Start,
                                        )
                                        copy(clipboardManager, msgSplit[1])
                                    }
                                }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                ) {
                                    TextContent(
                                        text = msgSplit[2].split("\n")[0],
                                        textAlign = TextAlign.Start,
                                    )
                                }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                ) {
                                    TextContent(
                                        modifier = Modifier
                                            .clickable {
                                                if (ContextCompat.checkSelfPermission(
                                                        context,
                                                        Manifest.permission.CALL_PHONE
                                                    ) ==
                                                    PackageManager.PERMISSION_GRANTED
                                                ) {
                                                    val intent = Intent(Intent.ACTION_DIAL).apply {
                                                        data = Uri.parse("tel:" + msgSplit[2].split("\n")[1])
                                                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                                    }
                                                    launcher.launch(intent)
                                                } else {
                                                    ActivityCompat.requestPermissions(
                                                        context as Activity,
                                                        arrayOf(Manifest.permission.CALL_PHONE),
                                                        1
                                                    )
                                                }
                                            },
                                        text = msgSplit[2].split("\n")[1],
                                        color = Color(0xFF587FCB),
                                        textAlign = TextAlign.Start,
                                    )
                                }
                            }
                        }
                    }
                }
                PrimaryButton(text = buttonLabel, modifier = Modifier.padding(horizontal = 20.dp)) {
                    onButtonClick.invoke()
                }
            }
        },
        onDismissRequest = onButtonClick,
        confirmButton = { },
        modifier = Modifier
            .padding(horizontal = 10.dp)
            .fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
    )
}

/**
 * ヘッダ部が画像のダイアログ.
 *
 * @param image 画像ID
 * @param imageSize 画像サイズ
 * @param title タイトル
 * @param content 表示内容
 * @param errorCode エラーコード
 * @param buttonLabel ボタンラベル
 * @param onButtonClick ボタンバックアップ
 */
@Composable
fun ImageHeadLandscapeDialog(
    image: Int,
    imageSize: Int,
    title: String,
    content: String,
    errorCode: String = "",
    buttonLabel: String,
    onButtonClick: () -> Unit
) {
    val context = LocalContext.current
    val launcher =
        rememberLauncherForActivityResult(contract = ActivityResultContracts.StartActivityForResult()) {}
    val clipboardManager = LocalClipboardManager.current
    AlertDialog(
        properties = DialogProperties(dismissOnClickOutside = false),
        title = {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                Image(
                    modifier = Modifier.requiredSize(imageSize.dp),
                    painter = painterResource(id = image),
                    contentDescription = ""
                )
            }
        },
        text = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth()
            ) {
                if (title.isNotBlank()) {
                    Box(modifier = Modifier.padding(bottom = 5.dp)) {
                        MediumTitle(title = title, fontSize = 16.sp)
                    }
                }
                Box(modifier = Modifier.padding(bottom = 5.dp)) {
                    val msgSplit = content.split("\n\n")
                    when (msgSplit.size) {
                        0, 1 -> {
                            TextContent(text = content, textAlign = TextAlign.Start, fontSize = 12.sp)
                        }
                        2 -> {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .fillMaxWidth()
                            ) {
                                TextContent(
                                    text = msgSplit[0],
                                    textAlign = TextAlign.Start,
                                    fontSize = 12.sp
                                )
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        horizontalArrangement = Arrangement.Center,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        TextContent(
                                            text = msgSplit[1],
                                            textAlign = TextAlign.Start,
                                            fontSize = 10.sp
                                        )
                                        copy(clipboardManager, msgSplit[1])
                                    }
                                }
                            }
                        }
                        3 -> {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .fillMaxWidth()
                            ) {
                                TextContent(
                                    text = msgSplit[0],
                                    textAlign = TextAlign.Start,
                                    fontSize = 12.sp
                                )
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        horizontalArrangement = Arrangement.Center,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        TextContent(
                                            text = msgSplit[1],
                                            textAlign = TextAlign.Start,
                                            fontSize = 10.sp
                                        )
                                        copy(clipboardManager, msgSplit[1])
                                    }
                                }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                ) {
                                    TextContent(
                                        text = msgSplit[2].split("\n")[0],
                                        textAlign = TextAlign.Start,
                                        fontSize = 12.sp
                                    )
                                }
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                ) {
                                    TextContent(
                                        modifier = Modifier
                                            .clickable {
                                                if (ContextCompat.checkSelfPermission(
                                                        context,
                                                        Manifest.permission.CALL_PHONE
                                                    ) ==
                                                    PackageManager.PERMISSION_GRANTED
                                                ) {
                                                    val intent = Intent(Intent.ACTION_DIAL).apply {
                                                        data = Uri.parse("tel:" + msgSplit[2].split("\n")[1])
                                                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                                                    }
                                                    launcher.launch(intent)
                                                } else {
                                                    ActivityCompat.requestPermissions(
                                                        context as Activity,
                                                        arrayOf(Manifest.permission.CALL_PHONE),
                                                        1
                                                    )
                                                }
                                            },
                                        text = msgSplit[2].split("\n")[1],
                                        textAlign = TextAlign.Start,
                                        color = Color(0xFF587FCB),
                                        fontSize = 12.sp
                                    )
                                }
                            }
                        }
                    }
                }
                PrimaryButton(text = buttonLabel, modifier = Modifier.padding(horizontal = 20.dp), width = 1f) {
                    onButtonClick.invoke()
                }
            }
        },
        onDismissRequest = onButtonClick,
        confirmButton = { },
        modifier = Modifier
            .padding(horizontal = 10.dp)
            .fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
    )
}

@Composable
private fun copy(
    clipboardManager: ClipboardManager,
    errorCode: String
) {
    IconButton(
        rightText = stringResource(id = R.string.common_dialog_button_copy),
        image = R.drawable.copy,
        imageSize = 14.dp,
        textColor = prominent_label_color,
        textSize = H7
    ) {
        var tempStr = ""
        showToast("コピーされました")
        tempStr = if (errorCode.contains("：")) {
            errorCode.split("：")[1].ifBlank { "" }
        } else {
            errorCode.split(":")[1].ifBlank { "" }
        }
        clipboardManager.setText(AnnotatedString(tempStr))
    }
}

/**
 * ボディ部が画像のダイアログ.
 *
 * @param image 画像ID
 * @param imageSize 画像サイズ
 * @param title タイトル
 * @param content 表示内容
 * @param buttonLabel ボタンラベル
 * @param onButtonClick ボタンバックアップ
 */
@Composable
fun ImageBodyDialog(
    image: Int,
    imageSize: Int,
    title: String,
    content: String,
    buttonLabel: String,
    onButtonClick: () -> Unit,
    copyright: Boolean = false,
) {
    AlertDialog(
        properties = DialogProperties(dismissOnClickOutside = false),
        text = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth()
            ) {
                MediumTitle(title = title, modifier = Modifier.padding(top = 20.dp, bottom = 20.dp))
                Box(modifier = Modifier.padding(bottom = 20.dp)) {
                    Image(
                        modifier = Modifier.requiredSize(imageSize.dp),
                        painter = painterResource(id = image),
                        contentDescription = ""
                    )
                }
                Box(modifier = Modifier.padding(bottom = 40.dp)) {
                    TextContent(text = content)
                }
                PrimaryButton(text = buttonLabel, modifier = Modifier.padding(horizontal = 20.dp)) {
                    onButtonClick.invoke()
                }
            }
        },
        onDismissRequest = onButtonClick,
        dismissButton = {
            if (copyright)
                Box(
                    modifier = Modifier
                        .padding(0.dp, 0.dp, 0.dp, 0.dp)
                        .fillMaxWidth()
                ) {
                    Copyright(
                        modifier = Modifier.background(copyright_background_color),
                        text = stringResource(id = R.string.common_copyright)
                    )
                }
        },
        confirmButton = { },
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
    )
}

/**
 * ヘッダ部が画像のダイアログ.
 *
 * @param image 画像ID
 * @param imageSize 画像サイズ
 * @param firstTitle タイトル
 * @param content 表示内容
 * @param firstButtonLabel ボタンラベル
 * @param secondButtonLabel ボタンラベル
 * @param callBackButtonLabel ボタンラベル
 * @param firstButtonClick ボタンラベル
 * @param secondButtonClick ボタンラベル
 * @param callBackButtonClick ボタンバックアップ
 */
@Composable
fun ImageMultiButtonDialog(
    image: Int,
    imageSize: Int,
    firstTitle: String,
    content: String,
    firstButtonLabel: String,
    secondButtonLabel: String,
    secondButtonType: Int = 0,
    copyright: Boolean = false,
    callBackButtonLabel: String,
    firstButtonClick: () -> Unit,
    secondButtonClick: () -> Unit,
    callBackButtonClick: () -> Unit,
) {
    AlertDialog(
        properties = DialogProperties(dismissOnClickOutside = false),
        text = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .padding(top = 20.dp)
                        .weight(0.5f)
                ) {
                    MediumTitle(title = firstTitle)
                }
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(2.0f),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        modifier = Modifier.requiredSize(imageSize.dp),
                        painter = painterResource(id = image),
                        contentDescription = ""
                    )
                }
                Box(
                    modifier = Modifier
                        .padding(top = 20.dp)
                        .weight(1f)
                ) {
                    TextContent(text = content, textAlign = TextAlign.Start, fontSize = H7)
                }
                PrimaryButton(
                    text = firstButtonLabel,
                    modifier = Modifier
                        .padding(horizontal = 20.dp)
                        .weight(1f)
                ) {
                    firstButtonClick.invoke()
                }
                if (secondButtonType == 0) {
                    PrimaryButton(
                        text = secondButtonLabel,
                        modifier = Modifier
                            .padding(horizontal = 20.dp)
                            .weight(1f)
                    ) {
                        secondButtonClick.invoke()
                    }
                } else {
                    AppButton(
                        text = secondButtonLabel,
                        modifier = Modifier
                            .padding(horizontal = 20.dp)
                            .weight(1f)
                    ) {
                        secondButtonClick.invoke()
                    }
                }
                SingleTextButton(
                    text = callBackButtonLabel,
                    modifier = Modifier
                        .padding(horizontal = 20.dp)
                        .weight(1f)
                ) {
                    callBackButtonClick.invoke()
                }
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 0.dp),
                    contentAlignment = Alignment.Center
                ) {
                }
            }
        },
        dismissButton = {
            if (copyright)
                Box(
                    modifier = Modifier
                        .padding(0.dp, 0.dp, 0.dp, 0.dp)
                        .fillMaxWidth()
                ) {
                    Copyright(
                        modifier = Modifier.background(copyright_background_color),
                        text = stringResource(id = R.string.common_copyright)
                    )
                }
        },
        onDismissRequest = callBackButtonClick,
        confirmButton = { },
        modifier = Modifier
            .fillMaxWidth()
            .height((SCREEN_HEIGHT * 0.8).dp),
        shape = RoundedCornerShape(20.dp),
    )
}

/**
 * ヘッダ部が画像、フッター部が二つブタンのダイアログ.
 *
 * @param image 画像ID
 * @param imageSize 画像サイズ
 * @param title タイトル
 * @param content 表示内容
 * @param contentAlign 表示内容並ぶ
 * @param buttonLabel ボタンラベル
 * @param onButtonClick ボタンバックアップ
 * @param onDismiss キャンセルの動作
 */
@Composable
fun ImageHeadMultiButtonDialog(
    image: Int,
    imageSize: Int,
    title: String,
    content: String,
    contentAlign: TextAlign = TextAlign.Start,
    buttonLabel: String,
    onButtonClick: () -> Unit,
    onDismiss: () -> Unit,
) {
    AlertDialog(
        properties = DialogProperties(dismissOnClickOutside = false),
        title = {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                Image(
                    modifier = Modifier.requiredSize(imageSize.dp),
                    painter = painterResource(id = image),
                    contentDescription = ""
                )
            }
        },
        text = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth()
            ) {
                if (title.isNotBlank()) {
                    Box(modifier = Modifier.padding(bottom = 20.dp)) {
                        MediumTitle(title = title)
                    }
                }
                Box(modifier = Modifier.padding(bottom = 40.dp)) {
                    TextContent(text = content, textAlign = contentAlign)
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    PrimaryButton(
                        text = buttonLabel,
                        modifier = Modifier
                            .weight(1.0f)
                            .padding(end = 10.dp)
                    ) {
                        onButtonClick.invoke()
                    }
                    AppButton(
                        text = "キャンセル",
                        modifier = Modifier
                            .weight(1.0f)
                            .padding(start = 10.dp),
                        bgColor = Color(0xFF949391),
                        textColor = Color.White
                    ) {
                        onDismiss.invoke()
                    }
                }
            }
        },
        onDismissRequest = onDismiss,
        confirmButton = { },
        modifier = Modifier
            .padding(horizontal = 10.dp)
            .fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
    )
}

/**
 * タイムピックダイアログ.
 *
 * @param text 表示名称
 * @param onDateSelected 選択した日付
 * @param onDismissRequest ダイアログクローズ
 */
@SuppressLint("WeekBasedYear")
@Composable
fun DatePickerDiaLog(
    text: String = "",
    type: Int = 0,
    value: LocalDate,
    onDateSelected: (LocalDate) -> Unit,
    onDismissRequest: () -> Unit
) {
    val years = LinkedList<Pair<Int, String>>().apply {
        for (i in now().year downTo 1900) {
            add(Pair(i, "${i}年"))
        }
    }
    val selDate = remember { mutableStateOf(value) }
    val selectYear = rememberSaveable { mutableStateOf(selDate.value.year) }
    val selectMonth = rememberSaveable { mutableStateOf(selDate.value.monthValue) }
    val selectDay = rememberSaveable { mutableStateOf(selDate.value.dayOfMonth) }

    Dialog(onDismissRequest = { onDismissRequest() }, properties = DialogProperties()) {
        Column(
            modifier = Modifier
                .wrapContentSize()
                .background(
                    color = MaterialTheme.colors.surface,
                    shape = RoundedCornerShape(size = 16.dp)
                )
        ) {
            Column(
                Modifier
                    .defaultMinSize(minHeight = 72.dp)
                    .fillMaxWidth()
                    .background(
                        color = Color.White,
                        shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)
                    )
                    .padding(16.dp)
            ) {
                Text(
                    text = text,
                    style = MaterialTheme.typography.caption,
                    color = Color.Black
                )

                Spacer(modifier = Modifier.size(24.dp))
            }

            val itemHeight = 60.dp
            Box(
                modifier = Modifier
                    .wrapContentHeight()
                    .fillMaxWidth(),
                Alignment.Center
            ) {
                Row(
                    Modifier
                        .wrapContentHeight()
                        .fillMaxWidth()
                        .background(MaterialTheme.colors.surface),
                    Arrangement.SpaceEvenly,
                    Alignment.CenterVertically
                ) {
                    DatePickerColumn(years, itemHeight, 70.dp, selectYear)

                    // 月
                    val months = ArrayList<Pair<Int, String>>(12).apply {
                        for (i in 1..12) {
                            add(Pair(i, "${i}月"))
                        }
                    }
                    DatePickerColumn(months, itemHeight, 50.dp, selectMonth)

                    // 年月のみ場合、日のセレクトが表示しない
                    if (type == 0) {
                        //  月の日数
                        val dayCountOfMonth = DateUtil.getDayCountOfMonth(selectYear.value, selectMonth.value)
                        val dayOfMonList = getDayMaxCount(count = dayCountOfMonth)

                        if (selectDay.value > dayCountOfMonth) selectDay.value = dayCountOfMonth
                        // 日
                        DatePickerColumn(
                            pairList = dayOfMonList,
                            itemHeight = itemHeight,
                            valueState = selectDay
                        )
                    }
                }

                Column {
                    Divider(
                        Modifier.padding(
                            start = 15.dp,
                            end = 15.dp,
                            bottom = itemHeight
                        ),
                        thickness = 1.dp
                    )
                    Divider(
                        Modifier.padding(
                            start = 15.dp,
                            end = 15.dp
                        ),
                        thickness = 1.dp
                    )
                }
            }

            Spacer(modifier = Modifier.size(8.dp))

            Row(
                modifier = Modifier
                    .align(Alignment.End)
                    .padding(bottom = 16.dp, end = 16.dp)
            ) {
                TextButton(
                    onClick = onDismissRequest
                ) {
                    Text(
                        text = stringResource(id = R.string.datePickerDiaLog_page_button_close),
                        style = MaterialTheme.typography.button,
                        color = Color(0xFFCE3F52)
                    )
                }
                val dayCountOfMonth = DateUtil.getDayCountOfMonth(selectYear.value, selectMonth.value)
                if (selectDay.value > dayCountOfMonth) selectDay.value = dayCountOfMonth
                TextButton(
                    onClick = {
                        onDateSelected(LocalDate.of(selectYear.value, selectMonth.value, selectDay.value))
                        onDismissRequest()
                    }
                ) {
                    Text(
                        text = stringResource(id = R.string.datePickerDiaLog_page_button_select),
                        style = MaterialTheme.typography.button,
                        color = Color(0xFFCE3F52)
                    )
                }
            }
        }
    }
}

/**
 * ヘッダ部が画像のダイアログ.
 *
 * @param firstTitle タイトル
 * @param contentFirst 表示内容1
 * @param contentSecond 表示内容2
 * @param firstButtonLabel ボタンラベル
 * @param secondButtonLabel ボタンラベル
 * @param callBackButtonLabel ボタンラベル
 * @param firstButtonClick ボタンラベル
 * @param secondButtonClick ボタンラベル
 * @param callBackButtonClick ボタンバックアップ
 */
@Composable
fun ImageMultiButtonDialog(
    firstTitle: String,
    contentFirst: String,
    contentSecond: String,
    firstButtonLabel: String,
    secondButtonLabel: String = "",
    secondButtonType: Int = 0,
    callBackButtonLabel: String,
    hasSecond: Boolean = true,
    copyright: Boolean = false,
    firstButtonClick: () -> Unit,
    secondButtonClick: () -> Unit = {},
    callBackButtonClick: () -> Unit,
) {
    AlertDialog(
        properties = DialogProperties(dismissOnClickOutside = false),
        text = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .padding(top = 30.dp)
                        .weight(0.5f)
                ) {
                    MediumTitle(title = firstTitle)
                }
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1.5f),
                    contentAlignment = Alignment.Center
                ) {
                    TextContent(text = contentFirst, textAlign = TextAlign.Start, fontSize = H8)
                }
                Box(
                    modifier = Modifier
                        .padding(bottom = 0.dp)
                        .weight(1.4f)
                ) {
                    TextContent(text = contentSecond, textAlign = TextAlign.Start, fontSize = H8)
                }
                PrimaryButton(
                    text = firstButtonLabel,
                    modifier = Modifier
                        .padding(horizontal = 20.dp)
                        .weight(1.0f)
                ) {
                    firstButtonClick.invoke()
                }
                if (hasSecond) {
                    if (secondButtonType == 0) {
                        PrimaryButton(
                            text = secondButtonLabel,
                            modifier = Modifier
                                .padding(horizontal = 20.dp)
                                .weight(1f)
                        ) {
                            secondButtonClick.invoke()
                        }
                    } else {
                        AppButton(
                            text = secondButtonLabel,
                            modifier = Modifier
                                .padding(horizontal = 20.dp)
                                .weight(1f)
                        ) {
                            secondButtonClick.invoke()
                        }
                    }
                }
                SingleTextButton(
                    text = callBackButtonLabel,
                    modifier = Modifier
                        .padding(horizontal = 20.dp)
                        .weight(1f)
                ) {
                    callBackButtonClick.invoke()
                }
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 0.dp),
                    contentAlignment = Alignment.Center
                ) {
                }
            }
        },
        dismissButton = {
            if (copyright)
                Box(
                    modifier = Modifier
                        .padding(0.dp, 0.dp, 0.dp, 0.dp)
                        .fillMaxWidth()
                ) {
                    Copyright(
                        modifier = Modifier.background(copyright_background_color),
                        text = stringResource(id = R.string.common_copyright)
                    )
                }
        },
        onDismissRequest = callBackButtonClick,
        confirmButton = { },
        modifier = Modifier
            .fillMaxWidth()
            .height((SCREEN_HEIGHT * 0.8).dp),
        shape = RoundedCornerShape(20.dp),
    )
}

@Composable
private fun getDayMaxCount(count: Int): ArrayList<Pair<Int, String>> {
    return ArrayList<Pair<Int, String>>().apply {
        for (i in 1..count)
            add(Pair(i, "${i}日"))
    }
}

/**
 * チェックボックス含むダイアログ.
 *
 * @param image 画像ID
 * @param imageSize 画像サイズ
 * @param content 表示内容
 * @param buttonLabel ボタンラベル
 * @param checkBoxLabel チェックボックスラベル
 * @param onButtonClick ボタンバックアップ
 */
@Composable
fun ContentCheckDialog(
    image: Int,
    imageSize: Int,
    content: String,
    buttonLabel: String,
    checkBoxLabel: String,
    onButtonClick: () -> Unit
) {
    var isCheck by remember { mutableStateOf(false) }

    AlertDialog(
        properties = DialogProperties(dismissOnClickOutside = false),
        title = {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                Image(
                    modifier = Modifier.requiredSize(imageSize.dp),
                    painter = painterResource(id = image),
                    contentDescription = ""
                )
            }
        },
        text = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth()
            ) {
                Box(modifier = Modifier.padding(bottom = 10.dp)) {
                    TextContent(text = content, textAlign = TextAlign.Start, fontSize = H5)
                }
                // チェックボックス
                Box(
                    modifier = Modifier
                        .padding(top = 0.dp)
                        .align(Alignment.CenterHorizontally),
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .click {
                                isCheck = !isCheck
                                PreferenceUtil.setPreferenceBooleanValue(DELIVERY_SELECT, isCheck)
                            },
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = isCheck,
                            onCheckedChange = {
                                isCheck = it
                                PreferenceUtil.setPreferenceBooleanValue(DELIVERY_SELECT, isCheck)
                            },
                            colors = CheckboxDefaults.colors(
                                uncheckedColor = prominent_label_color,
                                checkedColor = prominent_label_color,
                            )
                        )
                        Text(
                            text = checkBoxLabel,
                            fontSize = H7,
                        )
                    }
                }
                PrimaryButton(text = buttonLabel, modifier = Modifier.padding(horizontal = 20.dp)) {
                    onButtonClick.invoke()
                }
            }
        },
        onDismissRequest = onButtonClick,
        confirmButton = { },
        modifier = Modifier
            .padding(horizontal = 10.dp)
            .fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
    )
}

/**
 * チェックボックス含むダイアログ.
 *
 * @param image 画像ID
 * @param imageSize 画像サイズ
 * @param content 表示内容
 * @param buttonLabel ボタンラベル
 * @param checkBoxLabel チェックボックスラベル
 * @param onButtonClick ボタンバックアップ
 */
@Composable
fun CheckConsentDialog(
    title: String,
    content: String,
    buttonLabel: String,
    callBackButtonLabel: String,
    checkBoxLabel: String,
    onButtonClick: () -> Unit,
    callBackButtonClick: () -> Unit
) {
    var isCheck by remember { mutableStateOf(false) }

    AlertDialog(
        properties = DialogProperties(dismissOnClickOutside = false),
        title = {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.Top ) {
                TextContent(text = title, textAlign = TextAlign.Start, fontSize = H8)
            }
        },
        text = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth()
            ) {
                TextContent(text = content, textAlign = TextAlign.Start, fontSize = H8)

                // チェックボックス
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .click {
                            isCheck = !isCheck
                        },
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = isCheck,
                        onCheckedChange = {
                            isCheck = it
                        },
                        colors = CheckboxDefaults.colors(
                            uncheckedColor = prominent_label_color,
                            checkedColor = prominent_label_color,
                        )
                    )
                    Text(
                        text = checkBoxLabel,
                        fontSize = H7,
                    )
                }

                AppButton(
                    text = buttonLabel,
                    textColor = Color.White,
                    bgColor = if (isCheck) radio_button_select_bg_color else inactive_button_bg_color
                ) {
                    if (isCheck)
                        onButtonClick.invoke()
                }
                SingleTextButton(
                    text = callBackButtonLabel,
                    modifier = Modifier
                        .padding(horizontal = 20.dp)
                        .weight(1f)
                ) {
                    callBackButtonClick.invoke()
                }
            }
        },
        onDismissRequest = callBackButtonClick,
        confirmButton = { },
        modifier = Modifier
            .padding(horizontal = 10.dp)
            .height(
                (MyApp.SCREEN_HEIGHT * 0.9).dp
            )
            .fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
    )
}

/**
 * ローディングダイアログ.
 *
 * @param size 画像サイズ
 */
@Composable
fun LoadingDialog(
    size: Dp = 80.dp,
) {
    var showDialog by remember { mutableStateOf(false) }
    Dialog(
        onDismissRequest = { showDialog = false },
        DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false)
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(size)
                .background(Color.White, shape = RoundedCornerShape(8.dp))
        ) {
            CircularProgressIndicator(
                color = Color.Black,
                strokeWidth = 3.dp
            )
        }
    }
}

/**
 * ヘッダ部が画像のダイアログ.
 *
 * @param image 画像ID
 * @param imageSize 画像サイズ
 * @param firstTitle タイトル
 * @param content 表示内容
 * @param firstButtonLabel ボタンラベル
 * @param callBackButtonLabel ボタンラベル
 * @param firstButtonClick ボタンラベル
 * @param callBackButtonClick ボタンバックアップ
 */
@Composable
fun ImageMultiButton2Dialog(
    image: Int,
    imageSize: Int,
    firstTitle: String,
    content: String,
    content2: String,
    firstButtonLabel: String,
    secondButtonLabel: String,
    copyright: Boolean = false,
    firstButtonClick: () -> Unit,
    secondButtonClick: () -> Unit,
) {
    AlertDialog(
        properties = DialogProperties(dismissOnClickOutside = false),
        text = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .padding(top = 20.dp)
                        .weight(0.5f)
                ) {
                    MediumTitle(title = firstTitle)
                }
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(2.0f),
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        modifier = Modifier.requiredSize(imageSize.dp),
                        painter = painterResource(id = image),
                        contentDescription = ""
                    )
                }
                Box(
                    modifier = Modifier
                        .padding(top = 20.dp)
                        .weight(1f)
                ) {
                    TextContent(text = content, textAlign = TextAlign.Start, fontSize = H7)
                }
                PrimaryButton(
                    text = firstButtonLabel,
                    modifier = Modifier
                        .padding(horizontal = 20.dp)
                        .weight(1f)
                ) {
                    firstButtonClick.invoke()
                }
                Box(
                    modifier = Modifier
                        .padding(top = 20.dp)
                        .weight(1f)
                ) {
                    TextContent(text = content2, textAlign = TextAlign.Start, fontSize = H7)
                }
                PrimaryButton(
                    text = secondButtonLabel,
                    modifier = Modifier
                        .padding(horizontal = 20.dp)
                        .weight(1f)
                ) {
                    secondButtonClick.invoke()
                }
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 0.dp),
                    contentAlignment = Alignment.Center
                ) {
                }
            }
        },
        dismissButton = {
            if (copyright)
                Box(
                    modifier = Modifier
                        .padding(0.dp, 0.dp, 0.dp, 0.dp)
                        .fillMaxWidth()
                ) {
                    Copyright(
                        modifier = Modifier.background(copyright_background_color),
                        text = stringResource(id = R.string.common_copyright)
                    )
                }
        },
        onDismissRequest = secondButtonClick,
        confirmButton = { },
        modifier = Modifier
            .fillMaxWidth()
            .height((SCREEN_HEIGHT * 0.8).dp),
        shape = RoundedCornerShape(20.dp),
    )
}

/**
 * ログアウトのダイアログ.
 *
 * @param firstTitle タイトル
 * @param contentFirst 表示内容1
 * @param firstButtonLabel ボタンラベル
 * @param secondButtonLabel ボタンラベル
 * @param firstButtonClick ボタンラベル
 * @param secondButtonClick ボタンラベル
 * @param callBackButtonClick ボタンバックアップ
 */
@Composable
fun LogOutDialog(
    firstTitle: String,
    contentFirst: String,
    firstButtonLabel: String,
    secondButtonLabel: String = "",
    firstButtonClick: () -> Unit,
    secondButtonClick: () -> Unit = {},
    callBackButtonClick: () -> Unit,
) {
    AlertDialog(
        properties = DialogProperties(dismissOnClickOutside = false),
        text = {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .padding(top = 30.dp)
                        .weight(0.5f)
                ) {
                    MediumTitle(title = firstTitle)
                }
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(0.5f),
                    contentAlignment = Alignment.Center
                ) {
                    TextContent(text = contentFirst, textAlign = TextAlign.Start, fontSize = H6)
                }
                PrimaryButton(
                    text = firstButtonLabel,
                    modifier = Modifier
                        .padding(horizontal = 10.dp)
                        .weight(0.75f)
                ) {
                    firstButtonClick.invoke()
                }
                AppButton(
                    text = secondButtonLabel,
                    modifier = Modifier
                        .padding(horizontal = 10.dp)
                        .weight(0.5f)
                ) {
                    secondButtonClick.invoke()
                }
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 0.dp),
                    contentAlignment = Alignment.Center
                ) {
                }
            }
        },
        onDismissRequest = callBackButtonClick,
        confirmButton = { },
        modifier = Modifier
            .fillMaxWidth()
            .height((SCREEN_HEIGHT * 0.4).dp),
        shape = RoundedCornerShape(10.dp),
    )
}

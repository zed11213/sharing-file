package jp.co.jsbank.mb.bankingapp.ui.widgets.noData

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.theme.H5
import jp.co.jsbank.mb.bankingapp.theme.inactive_font_color

/**
 * 明細部データが0件
 *
 * @param msg 0件メッセージ
 */
@Composable
fun NoData(
    msg: String = stringResource(id = R.string.common_label_no_data),
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            text = msg,
            color = inactive_font_color,
            fontSize = H5
        )
    }
}

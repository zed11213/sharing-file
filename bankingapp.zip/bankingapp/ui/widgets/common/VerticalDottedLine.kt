package jp.co.jsbank.mb.bankingapp.ui.widgets.common

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Card
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/**
 * 通過しないノードの線.
 */
@Composable
fun VerticalDottedLine() {
    Card(
        shape = RoundedCornerShape(10.dp),
        elevation = 0.dp,
        modifier = Modifier
            .padding(0.dp, 2.dp, 20.dp, 0.dp)
            .height(30.dp)
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .padding(60.dp, 5.dp, 0.dp, 0.dp)
        ) {
            drawRect(
                color = Color.Gray,
                topLeft = Offset(0f, 0f),
                size = Size(10f, 10f)
            )
        }
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .padding(60.dp, 10.dp, 0.dp, 0.dp)
        ) {
            drawRect(
                color = Color.Gray,
                topLeft = Offset(0f, 11f),
                size = Size(10f, 10f)
            )
        }
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .padding(60.dp, 15.dp, 0.dp, 0.dp)
        ) {
            drawRect(
                color = Color.Gray,
                topLeft = Offset(0f, 22f),
                size = Size(10f, 10f)
            )
        }
    }
}

package jp.co.jsbank.mb.bankingapp.ui.widgets.common

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.util.AttributeSet
import android.view.View
import androidx.appcompat.widget.AppCompatButton

/**
 * 多重タップ防止ボタンビュークラスです.
 */
@SuppressLint("ViewConstructor")
class SafetyButton : AppCompatButton {
    constructor(context: Context?) : super(context!!) {}
    constructor(context: Context?, attrs: AttributeSet?) : super(context!!, attrs) {}
    constructor(context: Context?, attrs: AttributeSet?, defStyleAttr: Int) : super(context!!, attrs, defStyleAttr) {}

    /**
     * ボタンタップ遅延タイム.
     */
    private val DELAY_TIME = 1000L

    /**
     * ブロック中.
     */
    private val BLOCK = true

    /**
     * 未ブロック.
     */
    private val UNBLOCK = false
    /**
     * ロック状態を取得します.
     */
    /**
     * ビューブロック状態です.
     */
    var isLock = UNBLOCK
        private set

    override fun setOnClickListener(l: OnClickListener?) {
        super.setOnClickListener(object : OnClickListener {
            override fun onClick(v: View?) {
                if (isLock == BLOCK) { // ブロック中
                    return // 何もしないで終了
                }
                if (v != null) {
                    v.isEnabled = false
                }
                Handler().postDelayed({
                    if (v != null) {
                        v.isEnabled = true
                    }
                }, DELAY_TIME)
                l?.onClick(v)
            }
        })
    }

    /**
     * ロック解除します.
     */
    fun unlock() {
        isLock = UNBLOCK
    }
}

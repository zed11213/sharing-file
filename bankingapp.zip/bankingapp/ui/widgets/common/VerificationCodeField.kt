package jp.co.jsbank.mb.bankingapp.ui.widgets.common

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import jp.co.jsbank.mb.bankingapp.theme.date_select_disable_bg_color
import jp.co.jsbank.mb.bankingapp.theme.input_frame_background_color

/**
 * @param digits 暗証番号桁数
 * @param horizontalMargin 横幅
 * @param inputCallback コールバック
 */
@Composable
fun VerificationCodeField(
    digits: Int,
    horizontalMargin: Dp = 10.dp,
    inputCallback: (content: String) -> Unit = {},
    itemScope: @Composable (text: String, focused: Boolean) -> Unit
) {
    val localFocusManager = LocalFocusManager.current
    var content by remember { mutableStateOf("") }
    Box {
        Row(
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.background(
                if (content.length == digits)
                    date_select_disable_bg_color else input_frame_background_color
            )
        ) {
            repeat(digits) {
                if (it != 0) {
                    Spacer(modifier = Modifier.width(horizontalMargin))
                }
                val text = content.getOrNull(it)?.toString() ?: ""
                val focused = it == content.length
                itemScope(text, focused)
            }
        }
        BasicTextField(
            value = content,
            onValueChange = {
                if (it.length <= digits) {
                    content = it
                    inputCallback(it)
                }
            },
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Number,
                imeAction = ImeAction.Done
            ),
            keyboardActions = KeyboardActions(
                onDone = {
                    localFocusManager.clearFocus()
                },
            ),
            modifier = Modifier
                .drawWithContent { }
                .matchParentSize(),
        )
    }
}

@Composable
fun SimpleVerificationCodeItem(text: String, focused: Boolean) {

    Box(
        modifier = Modifier.size(55.dp, 55.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text.ifEmpty { "＿" },
            fontSize = 24.sp,
            textAlign = TextAlign.Center,
            maxLines = 1,
        )
    }
}

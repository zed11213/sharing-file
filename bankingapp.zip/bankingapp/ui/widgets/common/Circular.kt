package jp.co.jsbank.mb.bankingapp.ui.widgets.common

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * 普通なプロセス流れノード.
 *
 * @param value ラベル
 * @param labelColor ラベルの色
 */
@Composable
fun Circular(
    index: Int = 1,
    value: String = "",
    backGroundColor: Color = Color(0xFFCE3F52),
    numColor: Color = Color.White,
    labelColor: Color = Color(0xFF121212),
) {
    Row(
        Modifier
            .padding(20.dp, 20.dp, 0.dp, 0.dp)
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .border(0.dp, backGroundColor, CircleShape)
                .background(backGroundColor)
                .align(Alignment.CenterVertically)
        ) {
            Text(
                color = Color.White,
                text = "$index",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .background(backGroundColor)
                    .align(Alignment.Center),
            )
        }
        Text(
            text = value,
            overflow = TextOverflow.Ellipsis,
            fontSize = 15.sp,
            color = labelColor,
            fontWeight = FontWeight.Bold,
            modifier = Modifier
                .align(Alignment.CenterVertically)
                .padding(10.dp, 0.dp, 0.dp, 0.dp),
        )
    }
}

/**
 * 最後のプロセス流れノード.
 *
 * @param value ラベル
 * @param labelColor ラベルの色
 */
@Composable
fun LastCircular(
    value: String = "",
    labelColor: Color = Color(0xFF121212),
) {

    Box(
        modifier = Modifier.fillMaxSize()
    ) {
        Text(
            text = value,
            overflow = TextOverflow.Ellipsis,
            fontSize = 18.sp,
            color = labelColor,
            fontWeight = FontWeight.Bold,
            modifier = Modifier
                .align(Alignment.CenterStart)
                .padding(20.dp, 0.dp, 0.dp, 0.dp),
        )
    }
}

package jp.co.jsbank.mb.bankingapp.ui.pages.splash

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.hilt.navigation.compose.hiltViewModel
import com.google.accompanist.systemuicontroller.rememberSystemUiController
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.logic.splash.mbco6201.MBCO6201Logic
import jp.co.jsbank.mb.bankingapp.theme.app_start_bg_color
import jp.co.jsbank.mb.bankingapp.ui.widgets.dialog.ImageHeadDialog
import jp.co.jsbank.mb.bankingapp.ui.widgets.dialog.SampleAlertDialog

/**
 * アプリ起動のローディング画面
 *
 * @param onNextPage 次への画面を遷移する動作
 * @param viewModel ロジック
 */
@Composable
fun MBCO6201Page(onNextPage: () -> Unit, viewModel: MBCO6201Logic = hiltViewModel()) {

    val viewStates = viewModel.viewStates

    // ステータスバーの色の変更
    rememberSystemUiController().setStatusBarColor(app_start_bg_color)

    // 復元ダイアログフラグ
    if (viewStates.isRecoveryFlag) {
        SampleAlertDialog(
            title = "",
            content = stringResource(id = R.string.common_label_recovery),
            onConfirmClick = {
                onNextPage.invoke()
            },
            onDismiss = {
                // ローカルDBで保存した復元データを削除する
                viewModel.delete()
                if (!viewStates.errorFlag) {
                    onNextPage.invoke()
                }
            }
        )
    }

    if (viewStates.recoveryErrorFlag) {
        ImageHeadDialog(
            image = R.drawable.error_info,
            imageSize = 100,
            title = stringResource(R.string.mbsu0302_imageHeadDialog_title),
            content = stringResource(R.string.common_recovery_error_message),
            buttonLabel = stringResource(R.string.common_dialog_button_close),
            onButtonClick = {
                viewModel.closeErrorDialog()
                onNextPage.invoke()
            }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(app_start_bg_color),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        LaunchedEffect(Unit) {
            viewModel.doAppStartLogic {
                onNextPage.invoke()
            }
        }

        Image(
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .fillMaxWidth(),
            painter = painterResource(id = R.drawable.splash_body),
            contentDescription = "image"
        )
    }
}

package jp.co.jsbank.mb.bankingapp.ui.pages.splash

/**
 * MBCO6201テータス
 */
data class MBCO6201PageState(
    /**
     * エラーフラグ
     */
    var errorFlag: Boolean = false,

    /**
     * 復元ダイアログフラグ
     */
    var isRecoveryFlag: Boolean = false,

    /**
     * 復元エラーフラグ
     */
    var recoveryErrorFlag: Boolean = false,
)

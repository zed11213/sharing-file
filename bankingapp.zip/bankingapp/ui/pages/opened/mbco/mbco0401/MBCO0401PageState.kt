package jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbco.mbco0401

import jp.co.jsbank.mb.bankingapp.system.master.EkycCard

/**
 * MBCO0401ステータ
 */
data class MBCO0401PageState(

    /**
     * 通帳デザイン
     */
    var ekycCardPattern: EkycCard = EkycCard.MEMBER,
)

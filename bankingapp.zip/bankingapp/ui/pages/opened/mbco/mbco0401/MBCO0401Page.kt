package jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbco.mbco0401

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Card
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.logic.opened.mbco.mbco0401.MBCO0401Logic
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.system.master.EkycCard
import jp.co.jsbank.mb.bankingapp.theme.H5
import jp.co.jsbank.mb.bankingapp.theme.H6
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.AppButton
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.PrimaryButton
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.click
import jp.co.jsbank.mb.bankingapp.ui.widgets.tabBar.Tab
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil
import jp.co.jsbank.mb.bankingapp.utils.PreferenceUtil
import jp.co.jsbank.mb.bankingapp.utils.RouteUtil
import jp.co.jsbank.mb.bankingapp.utils.RouteUtil.back

/**
 * MBCO0401　本人確認書類選択
 *
 * @param viewModel ロジック
 */
@Composable
fun MBCO0401Page(
    viewModel: MBCO0401Logic = hiltViewModel(),
) {
    val viewStates = viewModel.viewStates

    Column(
        Modifier
            .fillMaxWidth()
            .background(Color.White)
    ) {
        Row(
            modifier = Modifier
                .weight(0.5f)
                .padding(20.dp, 0.dp, 20.dp, 0.dp)
        ) {
            if (PreferenceUtil.getPreferenceBooleanValue(ConstUtil.EKYC_TYPE))
                Tab(
                    state = 1,
                    list = listOf(
                        stringResource(R.string.common_tab_process_second),
                        stringResource(R.string.common_tab_process_first),
                        stringResource(R.string.common_tab_process_fifth),
                    )
                )
            else
                Tab(
                    state = 2,
                    list = listOf(
                        stringResource(R.string.common_tab_process_4th),
                        stringResource(R.string.common_tab_process_second),
                        stringResource(R.string.common_tab_process_first),
                        stringResource(R.string.common_tab_process_fifth),
                    )
                )
        }

        Row(
            Modifier
                .fillMaxWidth()
                .weight(0.5f)
        ) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 15.dp)
            ) {
                Text(
                    text = stringResource(id = R.string.mbco0401_page_title),
                    Modifier
                        .padding(0.dp, 0.dp, 0.dp, 0.dp)
                        .align(Alignment.Center),
                    textAlign = TextAlign.Center,
                    fontSize = H5,
                )
            }
        }

        Row(
            Modifier
                .fillMaxWidth()
                .weight(0.3f)
        ) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 15.dp)
            ) {
                Text(
                    text = stringResource(id = R.string.mbco0401_page_first_help_message),
                    Modifier
                        .padding(0.dp, 0.dp, 0.dp, 0.dp)
                        .align(Alignment.CenterStart),
                    textAlign = TextAlign.Start,
                    fontSize = H6,
                )
            }
        }

        Card(
            shape = RoundedCornerShape(20.dp),
            elevation = 2.dp,
            border = BorderStroke(
                1.dp,
                color = if (viewStates.ekycCardPattern == EkycCard.MEMBER)
                    Color.Red else Color.White
            ),
            modifier = Modifier
                .padding(20.dp, 20.dp, 20.dp, 0.dp)
                .weight(1f)
                .click {
                    viewModel.onBankbookPatternChange(EkycCard.MEMBER)
                }
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 15.dp)
            ) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .weight(1.7f)
                        .align(Alignment.CenterVertically)
                ) {
                    Text(
                        text = stringResource(id = R.string.mbco0401_page_label_member),
                        fontSize = H6,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Column(
                    Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(vertical = 10.dp)
                        .align(Alignment.CenterVertically)
                ) {
                    Image(
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth(),
                        painter = painterResource(id = R.drawable.ekyc_member),
                        contentDescription = "image"
                    )
                }
            }
        }

        Card(
            shape = RoundedCornerShape(20.dp),
            border = BorderStroke(
                1.dp,
                color = if (viewStates.ekycCardPattern == EkycCard.DRIVER)
                    Color.Red else Color.White
            ),
            elevation = 2.dp,
            modifier = Modifier
                .padding(20.dp, 20.dp, 20.dp, 0.dp)
                .weight(1f)
                .click {
                    viewModel.onBankbookPatternChange(EkycCard.DRIVER)
                }
        ) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(start = 15.dp, end = 10.dp)
            ) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(end = 20.dp)
                        .weight(1.7f)
                        .align(Alignment.CenterVertically)
                ) {
                    Text(
                        text = stringResource(id = R.string.mbco0401_page_label_driver),
                        fontSize = H6,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Column(
                    Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .padding(vertical = 10.dp)
                        .align(Alignment.CenterVertically)
                ) {
                    Image(
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth(),
                        painter = painterResource(id = R.drawable.ekyc_driver),
                        contentDescription = "image"
                    )
                }
            }
        }

        Spacer(modifier = Modifier.weight(0.2f))

        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .background(color = Color.White)
                .padding(horizontal = 50.dp)
                .weight(2f)
        ) {
            Column(
                modifier = Modifier
                    .background(color = Color.White)
                    .fillMaxWidth()
            ) {
                PrimaryButton(text = stringResource(id = R.string.common_page_button_next)) {
                    PreferenceUtil.setPreferenceStringValue(
                        ConstUtil.EKYC_CARD_TYPE,
                        viewStates.ekycCardPattern.toString()
                    )
                    // MBCO0402　本人確認書類の撮影へ遷移する
                    RouteUtil.navTo(
                        RouteName.MBCO0402Page
                    )
                }
                Spacer(modifier = Modifier.height(20.dp))
                if (!MainActivity.IS_EKYC_SHOOT_AGAIN_FLAG) {
                    AppButton(text = stringResource(id = R.string.common_page_button_return)) {
                        MainActivity.NAVCTRL?.back()
                    }
                }
            }
        }
    }
}

package jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbco.mbco0301

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.google.accompanist.systemuicontroller.rememberSystemUiController
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.logic.opened.mbco.mbco0301.MBCO0301Logic
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.theme.*
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.AppButton
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.PrimaryButton
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.click
import jp.co.jsbank.mb.bankingapp.ui.widgets.tabBar.Tab
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.DATA
import jp.co.jsbank.mb.bankingapp.utils.PreferenceUtil
import jp.co.jsbank.mb.bankingapp.utils.RouteUtil.back

/**
 * MBCO0301　電話番号認証
 *
 * @param viewModel ロジック
 */
@Composable
fun MBCO0301Page(
    viewModel: MBCO0301Logic = hiltViewModel(),
) {
    val viewStates = viewModel.viewStates
    val type = MainActivity.NAVCTRL?.currentBackStackEntry?.arguments?.get(DATA).toString()
    // ステータスバーの色の変更
    rememberSystemUiController().setStatusBarColor(Color.White)

    Column(
        Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
    ) {
        Column(
            modifier = Modifier
        ) {
            if (PreferenceUtil.getPreferenceBooleanValue(ConstUtil.EKYC_TYPE))
                Tab(
                    state = 2,
                    list = listOf(
                        stringResource(R.string.common_tab_process_second),
                        stringResource(R.string.common_tab_process_first),
                        stringResource(R.string.common_tab_process_fifth)
                    )
                )
            else
                Tab(
                    state = 3,
                    list = listOf(
                        stringResource(R.string.common_tab_process_4th),
                        stringResource(R.string.common_tab_process_second),
                        stringResource(R.string.common_tab_process_first),
                        stringResource(R.string.common_tab_process_fifth)
                    )
                )
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(
                    start = 10.dp, end = 10.dp
                ),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    text = stringResource(id = R.string.mbco0301_page_title),
                    color = general_label_color,
                    fontSize = H5
                )
            }
            Row(
                modifier = Modifier.padding(top = 20.dp)
            ) {
                Image(
                    contentScale = ContentScale.Fit,
                    painter = painterResource(
                        id = R.drawable.phone_authentication
                    ),
                    contentDescription = ""
                )
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 20.dp)
            ) {
                Text(
                    text = stringResource(R.string.mbco0301_page_first_help_message),
                    color = general_label_color,
                    fontSize = H6
                )
            }
        }

        Row(
            Modifier
                .fillMaxWidth()
        ) {}
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 10.dp, end = 10.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 10.dp),
            ) {
                Text(
                    text = stringResource(R.string.mbco0301_page_label_registered_telephone_number),
                    color = general_label_color,
                    fontSize = H6
                )
            }
            viewStates.phoneList.forEachIndexed { index, item ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 10.dp)
                        .background(input_frame_background_color)
                        .border(
                            BorderStroke(
                                1.dp,
                                color = if (viewStates.phonePattern == index) Color.Red else Color.White
                            )
                        )
                        .click {
                            viewModel.onPhonePatternChange(index)
                        },
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    if (PreferenceUtil.getPreferenceBooleanValue(ConstUtil.EKYC_TYPE)) {
                        Text(
                            text = item.substring(0, item.length - 4) + "****",
                            color = general_label_color,
                            fontSize = H3,
                            modifier = Modifier.padding(vertical = 10.dp)
                        )
                    } else {
                        Text(
                            text = item,
                            color = general_label_color,
                            fontSize = H3,
                            modifier = Modifier.padding(vertical = 10.dp)
                        )
                    }
                }
            }
        }
        Row(
            Modifier
                .fillMaxWidth()
        ) {}
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .padding(80.dp, 40.dp, 80.dp, 40.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
            ) {
                PrimaryButton(text = stringResource(R.string.mbco0301_page_button_telephone_number_authentication)) {
                    viewModel.telephoneAuthentication(type)
                }
                Spacer(modifier = Modifier.height(20.dp))
                if (MainActivity.SHOW_RETURN_BUTTON_FLAG &&
                    MainActivity.RECOVERY_ID != RouteName.MBCO0301Page
                ) {
                    AppButton(text = stringResource(R.string.common_page_button_return)) {
                        MainActivity.NAVCTRL?.back()
                    }
                }
            }
        }
    }
}

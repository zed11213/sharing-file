package jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbco.mbco0301

/**
 * MBCO0301ステータ
 */
data class MBCO0301PageState(

    /**
     * 電話リスト
     */
    var phoneList: MutableList<String> = mutableListOf(),

    /**
     * 電話タイプ
     */
    var phonePattern: Int = 0,
)

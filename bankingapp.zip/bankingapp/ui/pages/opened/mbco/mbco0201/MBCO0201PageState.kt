package jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbco.mbco0201

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

/**
 * MBCO0201ステータ
 */
data class MBCO0201PageState(

    /**
     * タイプ
     */
    var type: String = "",

    /**
     * メールアドレス
     */
    var mailAddress: String = "",

    /**
     * 確認メールアドレス
     */
    var confirmEmailAddress: String = "",

    /**
     * エラーフラグ
     */
    var errorFlag: Boolean = false,

    /**
     * エラーメッセージ内容
     */
    var errMsgList: List<String> = listOf(),

    /**
     * MBCO0201 errorBean
     */
    var errorBean: MBCO0201ErrorInformation = MBCO0201ErrorInformation(),
)

@Parcelize
data class MBCO0201ErrorInformation(
    /**
     * メールアドレス(エラーフラグ)
     */
    var mailAddressErrorFlag: Boolean = false,
    /**
     * 確認メールアドレス(エラーフラグ)
     */
    var confirmEmailAddressErrorFlag: Boolean = false,

) : Parcelable

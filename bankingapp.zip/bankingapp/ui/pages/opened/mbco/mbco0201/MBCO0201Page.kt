package jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbco.mbco0201

import android.annotation.SuppressLint
import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.Card
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.google.accompanist.systemuicontroller.rememberSystemUiController
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.logic.opened.mbco.mbco0201.MBCO0201Logic
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.system.master.RestoreRoute
import jp.co.jsbank.mb.bankingapp.theme.H5
import jp.co.jsbank.mb.bankingapp.theme.H7
import jp.co.jsbank.mb.bankingapp.theme.general_background_color
import jp.co.jsbank.mb.bankingapp.theme.general_label_color
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.AppButton
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.HitPreventionButton
import jp.co.jsbank.mb.bankingapp.ui.widgets.error.EditErrorListWidget
import jp.co.jsbank.mb.bankingapp.ui.widgets.tabBar.Tab
import jp.co.jsbank.mb.bankingapp.ui.widgets.textField.TextWidget
import jp.co.jsbank.mb.bankingapp.ui.widgets.textField.autoCloseKeyboard
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil
import jp.co.jsbank.mb.bankingapp.utils.PreferenceUtil
import jp.co.jsbank.mb.bankingapp.utils.RouteUtil.back
import jp.co.jsbank.mb.bankingapp.utils.ToContinuousHitPrevention
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * MBCO0201　メールアドレス入力
 *
 * @param viewModel ロジック
 */
@SuppressLint("CoroutineCreationDuringComposition")
@Composable
fun MBCO0201Page(
    viewModel: MBCO0201Logic = hiltViewModel(),
) {
    val viewStates = viewModel.viewStates
    val scrollState = rememberScrollState()
    val coroutineScope = rememberCoroutineScope()
    ToContinuousHitPrevention._sending.value = true

    // ステータスバーの色の変更
    rememberSystemUiController().setStatusBarColor(Color.White)

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .autoCloseKeyboard(),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            if (PreferenceUtil.getPreferenceBooleanValue(ConstUtil.EKYC_TYPE))
                Tab(
                    state = 2,
                    list = listOf(
                        stringResource(R.string.common_tab_process_second),
                        stringResource(R.string.common_tab_process_first),
                        stringResource(R.string.common_tab_process_fifth)
                    )
                )
            else
                Tab(
                    state = 3,
                    list = listOf(
                        stringResource(R.string.common_tab_process_4th),
                        stringResource(R.string.common_tab_process_second),
                        stringResource(R.string.common_tab_process_first),
                        stringResource(R.string.common_tab_process_fifth)
                    )
                )

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(
                        start = 10.dp, top = 20.dp, end = 10.dp, bottom = 10.dp
                    ),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = stringResource(R.string.mbsu0501_page_title),
                        color = general_label_color,
                        fontSize = H5
                    )
                }

                // 入力エラー情報
                if (viewStates.errorFlag) {
                    EditErrorListWidget(viewStates.errMsgList)
                    coroutineScope.launch {
                        scrollState.animateScrollTo(0)
                    }
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Text(
                        text = stringResource(R.string.mbsu0501_page_label_email_input),
                        color = general_label_color,
                        fontSize = H7
                    )
                }
                Row(
                    modifier = Modifier
                        .padding(top = 10.dp),
                ) {
                    Column(
                        modifier = Modifier
                            .weight(0.75f)
                    ) {
                        TextWidget(
                            onImeAction = {},
                            value = viewStates.mailAddress,
                            onChange = {
                                viewStates.mailAddress = it
                            },
                            placeholder = "jsbank@aaa.com",
                            enabled = true,
                            keyboardType = KeyboardType.Email,
                            unfocusedBorderColor = Color.Transparent,
                            focusedBorderColor = Color.Transparent,
                        )
                    }
                    Column(
                        modifier = Modifier
                            .weight(0.25f)
                    ) {
                    }
                }
            }
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Text(
                        text = stringResource(R.string.mbsu0501_page_label_email_input_again),
                        color = general_label_color,
                        fontSize = H7
                    )
                }
                Row(
                    modifier = Modifier
                        .padding(top = 10.dp),
                ) {
                    Column(
                        modifier = Modifier
                            .weight(0.75f)
                    ) {
                        TextWidget(
                            onImeAction = {},
                            value = viewStates.confirmEmailAddress,
                            onChange = {
                                viewStates.confirmEmailAddress = it
                            },
                            placeholder = "jsbank@aaa.com",
                            enabled = true,
                            keyboardType = KeyboardType.Email,
                            unfocusedBorderColor = Color.Transparent,
                            focusedBorderColor = Color.Transparent,
                        )
                    }
                    Column(
                        modifier = Modifier
                            .weight(0.25f)
                            .padding(start = 10.dp, end = 0.dp)
                    ) {
                        HitPreventionButton(text = stringResource(R.string.mbsu0501_page_button_send)) {
                            //ボタン非活性化
                            ToContinuousHitPrevention._sending.value = false
                            coroutineScope.launch{
                                withContext(Dispatchers.Default){
                                    // メールチェック
                                    viewModel.emailCheck()
                                }
                                //ボタン活性化
                                ToContinuousHitPrevention._sending.value = true
                            }
                        }
                    }
                }
            }
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp)
            ) {
                Text(
                    text = stringResource(R.string.mbsu0501_page_label_email_first_help_message),
                    color = general_label_color,
                    fontSize = H7
                )
                Text(
                    text = stringResource(R.string.mbsu0501_page_label_email_second_help_message),
                    color = general_label_color,
                    fontSize = H7
                )
            }
        }

        Card(
            shape = RoundedCornerShape(10.dp),
            elevation = 0.dp,
            backgroundColor = general_background_color,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp, 0.dp, 16.dp, 60.dp)
        ) {
            Row(
                modifier = Modifier
                    .padding(0.dp, 10.dp, 20.dp, 10.dp)
            ) {
                Column {
                    Image(
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(20.dp),
                        painter = painterResource(id = R.drawable.warning_red_circle),
                        contentDescription = ""
                    )
                }
                Column(
                    modifier = Modifier.padding(
                        start = 10.dp,
                        end = 10.dp
                    )
                ) {
                    Text(
                        text = stringResource(R.string.mbsu0501_page_label_email_3rd_help_message),
                        fontSize = H7
                    )
                }
            }
        }

        Column {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .padding(70.dp, 0.dp, 70.dp, 40.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                ) {
                    if (MainActivity.SHOW_RETURN_BUTTON_FLAG &&
                        MainActivity.RECOVERY_ID != RestoreRoute.RESTORE_MBCO0201.code
                    ) {
                        AppButton(text = stringResource(R.string.common_page_button_return)) {
                            MainActivity.NAVCTRL?.back()
                        }
                    }
                }
            }
        }
    }
}

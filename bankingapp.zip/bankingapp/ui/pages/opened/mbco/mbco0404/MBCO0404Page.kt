package jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbco.mbco0404

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.google.accompanist.systemuicontroller.rememberSystemUiController
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.bean.common.CheckPointsBean
import jp.co.jsbank.mb.bankingapp.theme.H5
import jp.co.jsbank.mb.bankingapp.theme.H6
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.PrimaryButton
import jp.co.jsbank.mb.bankingapp.ui.widgets.card.CardCheckPoints
import jp.co.jsbank.mb.bankingapp.ui.widgets.tabBar.Tab
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil
import jp.co.jsbank.mb.bankingapp.utils.PreferenceUtil

/**
 * MBCO0404　まばたきチェック
 * */
@Composable
fun MBCO0404Page() {
    // ステータスバーの色の変更
    rememberSystemUiController().setStatusBarColor(Color.White)

    Column(
        Modifier
            .fillMaxWidth()
            .background(Color.White)
    ) {
        Row(
            modifier = Modifier
                .weight(0.5f)
                .padding(20.dp, 0.dp, 20.dp, 0.dp)
        ) {
            if (PreferenceUtil.getPreferenceBooleanValue(ConstUtil.EKYC_TYPE))
                Tab(
                    state = 1,
                    list = listOf(
                        stringResource(R.string.common_tab_process_second),
                        stringResource(R.string.common_tab_process_first),
                        stringResource(R.string.common_tab_process_fifth),
                    )
                )
            else
                Tab(
                    state = 2,
                    list = listOf(
                        stringResource(R.string.common_tab_process_4th),
                        stringResource(R.string.common_tab_process_second),
                        stringResource(R.string.common_tab_process_first),
                        stringResource(R.string.common_tab_process_fifth),
                    )
                )
        }

        Row(
            Modifier
                .fillMaxWidth()
                .weight(0.5f)
        ) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 15.dp)
            ) {
                Text(
                    text = stringResource(id = R.string.mbco0404_page_title_member),
                    Modifier
                        .padding(0.dp, 0.dp, 0.dp, 0.dp)
                        .align(Alignment.Center),
                    textAlign = TextAlign.Center,
                    fontSize = H5,
                )
            }
        }

        Row(
            Modifier
                .fillMaxWidth()
                .weight(1.5f),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                contentScale = ContentScale.Crop,
                modifier = Modifier,
                painter = painterResource(id = R.drawable.ekyc_face),
                contentDescription = ""
            )
        }

        Row(
            Modifier
                .fillMaxWidth()
                .weight(1.0f)
        ) {
            Box(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 15.dp)
            ) {
                Text(
                    text = stringResource(id = R.string.mbco0404_page_first_help_message),
                    Modifier
                        .padding(0.dp, 0.dp, 0.dp, 0.dp)
                        .align(Alignment.CenterStart),
                    textAlign = TextAlign.Start,
                    fontSize = H6,
                )
            }
        }

        val list: List<CheckPointsBean> = listOf(
            CheckPointsBean(content = stringResource(id = R.string.mbco0404_page_label_prompt_information_first)),
            CheckPointsBean(content = stringResource(id = R.string.mbco0404_page_label_prompt_information_5th)),
            CheckPointsBean(content = stringResource(id = R.string.mbco0404_page_label_prompt_information_3rd)),
            CheckPointsBean(content = stringResource(id = R.string.mbco0404_page_label_prompt_information_4th))
        )
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 15.dp)
                .weight(2f)
        ) {
            CardCheckPoints(data = list)
        }

        Spacer(modifier = Modifier.weight(0.2f))

        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .background(color = Color.White)
                .padding(horizontal = 50.dp)
                .weight(1f)
        ) {
            Column(
                modifier = Modifier
                    .background(color = Color.White)
                    .fillMaxWidth()
            ) {
                PrimaryButton(text = stringResource(id = R.string.common_ekyc_button_shadow_begins)) {
                }
            }
        }
    }
}

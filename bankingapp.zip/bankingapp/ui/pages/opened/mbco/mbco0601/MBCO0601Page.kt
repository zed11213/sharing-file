package jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbco.mbco0601

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.google.accompanist.systemuicontroller.rememberSystemUiController
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.logic.opened.mbco.mbco0601.MBCO0601Logic
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.theme.H5
import jp.co.jsbank.mb.bankingapp.theme.H6
import jp.co.jsbank.mb.bankingapp.theme.general_label_color
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.AppButton
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.IconButton
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.PrimaryButton
import jp.co.jsbank.mb.bankingapp.ui.widgets.error.EditErrorListWidget
import jp.co.jsbank.mb.bankingapp.ui.widgets.tabBar.Tab
import jp.co.jsbank.mb.bankingapp.ui.widgets.textField.TextWidget
import jp.co.jsbank.mb.bankingapp.ui.widgets.textField.autoCloseKeyboard
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil
import jp.co.jsbank.mb.bankingapp.utils.PreferenceUtil
import jp.co.jsbank.mb.bankingapp.utils.RouteUtil
import jp.co.jsbank.mb.bankingapp.utils.RouteUtil.back
import jp.co.jsbank.mb.bankingapp.utils.WebConstUtil.WEB_VIEW_MBCO0601_INTERNET_BANKING_PASSWORD_HELP
import jp.co.jsbank.mb.bankingapp.utils.WebConstUtil.WEB_VIEW_URL_CONST

/**
 * MBCO0601画面（ログインパスワード設定）
 *
 * @param viewModel ロジック
 */
@Composable
fun MBCO0601Page(
    viewModel: MBCO0601Logic = hiltViewModel(),
) {
    // ステータスバーの色の変更
    rememberSystemUiController().setStatusBarColor(Color.White)
    // ステータス
    val viewStates = viewModel.viewStates
    val scrollState = rememberScrollState()
    val coroutineScope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(scrollState)
            .autoCloseKeyboard()
    ) {
        Row {
            Tab(
                state = 3,
                list = listOf(
                    stringResource(R.string.common_tab_process_4th),
                    stringResource(R.string.common_tab_process_second),
                    stringResource(R.string.common_tab_process_first),
                    stringResource(R.string.common_tab_process_fifth),
                )
            )
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Text(
                text = stringResource(R.string.mbco0601_imageHeadDialog_title),
                color = general_label_color,
                fontSize = H5
            )
        }

        // 入力エラー情報
        if (viewStates.errorFlag) {
            EditErrorListWidget(viewStates.errMsgList)
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.padding(vertical = 16.dp)
            ) {
                Image(
                    contentScale = ContentScale.Fit,
                    painter = painterResource(
                        id = R.drawable.mbco0601_card
                    ),
                    contentDescription = ""
                )
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp)
            ) {
                Text(
                    text = stringResource(R.string.mbco0601_imageHeadDialog_content),
                    color = general_label_color,
                    fontSize = H6
                )
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
            ) {
                IconButton(
                    rightText = stringResource(R.string.mbco0601_imageHeadDialog_buttonLabel),
                    image = R.drawable.error_red_filled_circle,
                    imageSize = 16.dp
                ) {
                    RouteUtil.navTo(
                        RouteName.WEB_VIEW_PAGE + WEB_VIEW_URL_CONST + WEB_VIEW_MBCO0601_INTERNET_BANKING_PASSWORD_HELP
                    )
                }
            }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(
                    text = stringResource(R.string.mbco0601_page_label_password_set),
                    color = general_label_color,
                    fontSize = H6
                )
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 5.dp),
            ) {
                // 2025/01/20 共同化ためインバン利用登録修正　start
                TextWidget(
                    onImeAction = {},
                    value = viewStates.password,
                    onChange = {
                        viewStates.password = it
                    },
                    placeholder = stringResource(R.string.mbsu0601_page_label_four_digit),
                    maxLength = 12,
                    minLength = 6,
                    keyboardType = KeyboardType.Password,
                    unfocusedBorderColor = Color.Transparent,
                    focusedBorderColor = Color.Transparent,
                    isPassword = true,
                    isError = viewStates.errorBean.passwordErrorFlag,
                    lowerCase = true,
                )
                // 2025/01/20 共同化ためインバン利用登録修正　end
            }
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 16.dp, top = 16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(
                    text = stringResource(R.string.mbco0601_page_label_password_set_help),
                    color = general_label_color,
                    fontSize = H6
                )
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 5.dp),
            ) {
                // 2025/01/20 共同化ためインバン利用登録修正　start
                TextWidget(
                    onImeAction = {},
                    value = viewStates.confirmPassword,
                    onChange = {
                        viewStates.confirmPassword = it
                    },
                    placeholder = stringResource(R.string.mbsu0601_page_label_four_digit),
                    maxLength = 12,
                    minLength = 6,
                    keyboardType = KeyboardType.Password,
                    unfocusedBorderColor = Color.Transparent,
                    focusedBorderColor = Color.Transparent,
                    isPassword = true,
                    isError = viewStates.errorBean.confirmPasswordErrorFlag,
                    lowerCase = true,
                )
                // 2025/01/20 共同化ためインバン利用登録修正　end
            }
        }
        Row(
            Modifier
                .fillMaxWidth()
        ) {}
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .padding(horizontal = 60.dp, vertical = 40.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
            ) {
                PrimaryButton(text = stringResource(R.string.common_page_button_next)) {
                    // パスワードチェック
                    viewModel.passwordCheck(coroutineScope, scrollState)
                }
                Spacer(modifier = Modifier.height(20.dp))
                AppButton(text = stringResource(R.string.common_page_button_return)) {
                    PreferenceUtil.setPreferenceBooleanValue(ConstUtil.OPENED_EDIT_INFO_FLAG, false)
                    MainActivity.NAVCTRL?.back()
                }
            }
        }
    }
}

package jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbco.mbco0601

/**
 * MBCO0601ステータス
 */
data class MBCO0601PageState(

    /**
     * パスワード
     */
    var password: String = "",

    /**
     * 確認パスワード
     */
    var confirmPassword: String = "",

    /**
     * エラーフラグ
     */
    var errorFlag: Boolean = false,

    /**
     * エラーメッセージ内容
     */
    var errMsgList: List<String> = listOf(),

    /**
     * MBCO0601 errorBean
     */
    var errorBean: MBCO0601ErrorInformation = MBCO0601ErrorInformation(),
)

data class MBCO0601ErrorInformation(
    /**
     * パスワード(エラーフラグ)
     */
    var passwordErrorFlag: Boolean = false,
    /**
     * 確認パスワード(エラーフラグ)
     */
    var confirmPasswordErrorFlag: Boolean = false,

)

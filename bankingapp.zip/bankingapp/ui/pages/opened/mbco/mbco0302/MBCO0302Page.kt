package jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbco.mbco0302

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material.Divider
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.google.accompanist.systemuicontroller.rememberSystemUiController
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.logic.opened.mbco.mbco0302.MBCO0302Logic
import jp.co.jsbank.mb.bankingapp.theme.H5
import jp.co.jsbank.mb.bankingapp.theme.H6
import jp.co.jsbank.mb.bankingapp.theme.general_dividing_line_color
import jp.co.jsbank.mb.bankingapp.theme.general_label_color
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.AppButton
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.PrimaryButton
import jp.co.jsbank.mb.bankingapp.ui.widgets.common.SimpleVerificationCodeItem
import jp.co.jsbank.mb.bankingapp.ui.widgets.common.VerificationCodeField
import jp.co.jsbank.mb.bankingapp.ui.widgets.dialog.ImageHeadDialog
import jp.co.jsbank.mb.bankingapp.ui.widgets.error.EditErrorListWidget
import jp.co.jsbank.mb.bankingapp.ui.widgets.tabBar.Tab
import jp.co.jsbank.mb.bankingapp.ui.widgets.textField.autoCloseKeyboard
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil
import jp.co.jsbank.mb.bankingapp.utils.PreferenceUtil

/**
 * MBCO0302　認証番号入力
 *
 * @param viewModel ロジック
 */
@Composable
fun MBCO0302Page(
    viewModel: MBCO0302Logic = hiltViewModel(),
) {
    val viewStates = viewModel.viewStates
    // ステータスバーの色の変更
    rememberSystemUiController().setStatusBarColor(Color.White)

    if (viewStates.achievedFlag) {
        ImageHeadDialog(
            image = R.drawable.confirmed,
            imageSize = 100,
            title = stringResource(R.string.mbsu0602_achieved_imageHeadDialog_title),
            content = stringResource(R.string.mbsu0602_achieved_imageHeadDialog_content),
            buttonLabel = stringResource(R.string.mbsu0602_achieved_imageHeadDialog_buttonLabel),
            onButtonClick = {
                viewModel.closeAchievedDialog()
            }
        )
    }

    Column(
        Modifier
            .fillMaxSize()
            .autoCloseKeyboard()
    ) {
        Column {
            if (PreferenceUtil.getPreferenceBooleanValue(ConstUtil.EKYC_TYPE))
                Tab(
                    state = 2,
                    list = listOf(
                        stringResource(R.string.common_tab_process_second),
                        stringResource(R.string.common_tab_process_first),
                        stringResource(R.string.common_tab_process_fifth)
                    )
                )
            else
                Tab(
                    state = 3,
                    list = listOf(
                        stringResource(R.string.common_tab_process_4th),
                        stringResource(R.string.common_tab_process_second),
                        stringResource(R.string.common_tab_process_first),
                        stringResource(R.string.common_tab_process_fifth)
                    )
                )
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(
                    start = 10.dp, top = 20.dp, end = 10.dp, bottom = 0.dp
                ),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    text = stringResource(R.string.mbco0302_page_title),
                    color = general_label_color,
                    fontSize = H5
                )
            }

            // 入力エラー情報
            if (viewStates.errMsgList.isNotEmpty()) {
                EditErrorListWidget(viewStates.errMsgList)
            }

            Row(
                modifier = Modifier.padding(top = 20.dp)
            ) {
                Image(
                    contentScale = ContentScale.Fit,
                    painter = painterResource(
                        id = R.drawable.phone_authentication
                    ),
                    contentDescription = ""
                )
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 20.dp)
            ) {
                Text(
                    text = stringResource(R.string.mbco0302_page_first_help_message),
                    color = general_label_color,
                    fontSize = H6
                )
            }
        }
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 10.dp, top = 20.dp, end = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Row(
                modifier = Modifier
                    .padding(top = 10.dp)
                    .fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                VerificationCodeField(4, inputCallback = {
                    viewModel.onPhoneCodeChange(it)
                }) { text, focused ->
                    SimpleVerificationCodeItem(text, focused)
                }
            }
        }
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .padding(80.dp, 40.dp, 80.dp, 0.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
            ) {
                PrimaryButton(text = stringResource(R.string.mbco0302_page_button_confirmation)) {
                    // 認証番号チェック
                    viewModel.phoneCodeCheck(viewStates.type)
                }
            }
        }
        // 分割線
        Divider(
            Modifier.padding(horizontal = 10.dp, vertical = 30.dp),
            thickness = 2.dp,
            color = general_dividing_line_color
        )
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 10.dp, end = 10.dp, top = 10.dp)
        ) {
            Text(
                text = stringResource(R.string.mbco0302_page_second_help_message),
                color = general_label_color,
                fontSize = H6
            )
        }
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .padding(80.dp, 60.dp, 80.dp, 0.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
            ) {
                AppButton(text = stringResource(R.string.mbco0302_page_button_to_change)) {
                    viewModel.callBack()
                }
            }
        }
    }
}

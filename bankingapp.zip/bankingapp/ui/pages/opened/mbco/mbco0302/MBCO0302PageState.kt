package jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbco.mbco0302

/**
 * MBCO0302ステータ
 */
data class MBCO0302PageState(

    /**
     * ダイアログフラグ.
     */
    var flag: Boolean = false,

    /**
     * 1日の上限に達した場合ダイアログフラグ
     */
    var achievedFlag: Boolean = false,

    /**
     * OTP.
     */
    var otp: String = "",

    /**
     * エラーフラグ
     */
    var errorFlag: Boolean = false,

    /**
     * エラーメッセージ内容
     */
    var errorMessage: String = "",

    /**
     * エラーメッセージ内容
     */
    var errMsgList: List<String> = listOf(),

    /**
     * タイプ
     */
    var type: String = "",

    /**
     * 電話番号
     */
    var phoneNumber: String = "",
)

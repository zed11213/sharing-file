package jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbco.mbco0501

/**
 * MBCO0501ステータ
 */
data class MBCO0501PageState(

    /**
     * キャッシュカードの暗証番号.
     */
    var cashCardNumber: String = "",

    /**
     * キャッシュカードの暗証番号（再度入力）.
     */
    var cashCardNumberAgain: String = "",

    /**
     * MBCO0501 errorBean
     */
    var errorBean: MBCO0501ErrorInformation = MBCO0501ErrorInformation(),

    /**
     * エラーメッセージフラグ
     */
    var isError: Boolean = false,

    /**
     * エラーメッセージ内容
     */
    var errMsgList: List<String> = listOf(),

    /**
     * タイプ.
     */
    var type: String = "",

    /**
     * ダイアログ.
     */
    var openDialogFlag: Boolean = false,
)

data class MBCO0501ErrorInformation(
    /**
     * キャッシュカードの暗証番号(エラーフラグ)
     */
    var cashCardNumberErrorFlag: Boolean = false,
    /**
     * キャッシュカードの暗証番号(エラーフラグ)
     */
    var cashCardNumberAgainErrorFlag: Boolean = false,
)

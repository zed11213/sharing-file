package jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbco.mbco0501

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.AlertDialog
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.DialogProperties
import androidx.hilt.navigation.compose.hiltViewModel
import com.google.accompanist.systemuicontroller.rememberSystemUiController
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.bean.common.CheckPointsBean
import jp.co.jsbank.mb.bankingapp.logic.opened.mbco.mbco0501.MBCO0501Logic
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.theme.H5
import jp.co.jsbank.mb.bankingapp.theme.H6
import jp.co.jsbank.mb.bankingapp.theme.H7
import jp.co.jsbank.mb.bankingapp.theme.general_label_color
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.AppButton
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.PrimaryButton
import jp.co.jsbank.mb.bankingapp.ui.widgets.card.CardCheckPoints
import jp.co.jsbank.mb.bankingapp.ui.widgets.common.MediumTitle
import jp.co.jsbank.mb.bankingapp.ui.widgets.common.TextContent
import jp.co.jsbank.mb.bankingapp.ui.widgets.error.EditErrorListWidget
import jp.co.jsbank.mb.bankingapp.ui.widgets.tabBar.Tab
import jp.co.jsbank.mb.bankingapp.ui.widgets.textField.TextWidget
import jp.co.jsbank.mb.bankingapp.ui.widgets.textField.autoCloseKeyboard
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil
import jp.co.jsbank.mb.bankingapp.utils.PreferenceUtil
import jp.co.jsbank.mb.bankingapp.utils.RouteUtil
import jp.co.jsbank.mb.bankingapp.utils.RouteUtil.back

/**
 * MBCO0501画面（CC暗証番号設定）
 *
 * @param viewModel ロジック
 */
@Composable
fun MBCO0501Page(
    viewModel: MBCO0501Logic = hiltViewModel()
) {
    val viewStates = viewModel.viewStates
    val scrollState = rememberScrollState()
    val coroutineScope = rememberCoroutineScope()
    // ステータスバーの色の変更
    rememberSystemUiController().setStatusBarColor(Color.White)

    // 申込完了ダイアログ
    if (viewModel.viewStates.openDialogFlag) {
        AlertDialog(
            properties = DialogProperties(dismissOnClickOutside = false),
            text = {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier
                        .fillMaxWidth()
                ) {
                    MediumTitle(
                        title = stringResource(id = R.string.mbco0501_page_dialog_title),
                        modifier = Modifier.padding(top = 20.dp, bottom = 20.dp),
                        fontSize = H7
                    )
                    Box(modifier = Modifier.padding(bottom = 40.dp)) {
                        TextContent(
                            text = stringResource(id = R.string.mbco0501_page_dialog_content),
                            fontSize = H7
                        )
                    }
                    PrimaryButton(
                        text = stringResource(id = R.string.common_dialog_button_next),
                        modifier = Modifier.padding(horizontal = 20.dp)
                    ) {
                        viewModel.closeDialog()
                        // MBCO0601　IBパスワード登録
                        RouteUtil.navTo(
                            RouteName.MBCO0601Page
                        )
                    }
                }
            },
            dismissButton = {},
            onDismissRequest = { viewModel.closeDialog() },
            confirmButton = { },
            modifier = Modifier
                .padding(horizontal = 10.dp)
                .fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
        )
    }

    Column(
        Modifier
            .fillMaxWidth()
            .verticalScroll(scrollState)
            .autoCloseKeyboard()
    ) {

        // タブ情報
        if (PreferenceUtil.getPreferenceBooleanValue(ConstUtil.EKYC_TYPE))
            Tab(
                state = 2,
                list = listOf(
                    stringResource(R.string.common_tab_process_second),
                    stringResource(R.string.common_tab_process_first),
                    stringResource(R.string.common_tab_process_fifth)
                )
            )
        else
            Tab(
                state = 3,
                list = listOf(
                    stringResource(R.string.common_tab_process_4th),
                    stringResource(R.string.common_tab_process_second),
                    stringResource(R.string.common_tab_process_first),
                    stringResource(R.string.common_tab_process_fifth)
                )
            )

        // タイトル：キャッシュカードの暗証番号
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, top = 12.dp, end = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Text(
                text = stringResource(R.string.mbco0501_page_title),
                color = general_label_color,
                fontSize = H5
            )
        }

        // 入力エラー情報
        if (viewStates.isError) {
            EditErrorListWidget(viewStates.errMsgList.distinct())
        }

        // ヘッダ部の文言
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 16.dp, bottom = 26.dp)
        ) {

            // 画像
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 32.dp),
                horizontalArrangement = Arrangement.Center
            ) {
                Image(
                    contentScale = ContentScale.Crop,
                    modifier = Modifier,
                    painter = painterResource(id = R.drawable.cash_card_pin_input),
                    contentDescription = ""
                )
            }
            // 画面説明文言
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 32.dp)
            ) {
                Text(
                    text = stringResource(R.string.mbco0501_page_help_message),
                    color = general_label_color,
                    fontSize = H6
                )
            }
        }

        // 2025/01/20 共同化ため カード暗証番号 連番数字4桁を追加　start
        // チェックリスト
        val list: List<CheckPointsBean> = listOf(
            CheckPointsBean(content = stringResource(id = R.string.mbco0501_page_label_prompt_information_1st)),
            CheckPointsBean(content = stringResource(id = R.string.mbco0501_page_label_prompt_information_2nd)),
            CheckPointsBean(content = stringResource(id = R.string.mbco0501_page_label_prompt_information_3rd)),
            CheckPointsBean(content = stringResource(id = R.string.mbco0501_page_label_prompt_information_4th)),
            CheckPointsBean(content = stringResource(id = R.string.mbco0501_page_label_sequential_numbers_4th)),
            CheckPointsBean(content = stringResource(id = R.string.mbco0501_page_label_prompt_information_5th)),
            CheckPointsBean(content = stringResource(id = R.string.mbco0501_page_label_prompt_information_6th)),
        )
        // 2025/01/20 共同化ため カード暗証番号　連番数字4桁を追加　end
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .height(240.dp)
                .padding(start = 16.dp, top = 12.dp, end = 16.dp, bottom = 26.dp)
        ) {
            CardCheckPoints(data = list)
        }

        // キャッシュカードの暗証番号
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 16.dp, bottom = 20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(
                    text = stringResource(R.string.mbsu0501_page_label_cash_card_pin),
                    color = general_label_color,
                    fontSize = H6
                )
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 5.dp),
            ) {
                TextWidget(
                    onImeAction = {},
                    value = viewStates.cashCardNumber,
                    onChange = {
                        viewStates.cashCardNumber = it
                    },
                    placeholder = stringResource(R.string.mbsu0501_page_label_four_digit),
                    maxLength = 4,
                    keyboardType = KeyboardType.Number,
                    unfocusedBorderColor = Color.Transparent,
                    focusedBorderColor = Color.Transparent,
                    isPassword = true,
                    isError = viewStates.errorBean.cashCardNumberErrorFlag
                )
            }
        }

        // 確認のため再度入力してください。
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 16.dp, bottom = 20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(
                    text = stringResource(R.string.mbsu0501_page_label_cash_card_pin_again),
                    color = general_label_color,
                    fontSize = H6
                )
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 5.dp),
            ) {
                TextWidget(
                    onImeAction = {},
                    value = viewStates.cashCardNumberAgain,
                    onChange = {
                        viewStates.cashCardNumberAgain = it
                    },
                    placeholder = stringResource(R.string.mbsu0501_page_label_four_digit),
                    maxLength = 4,
                    keyboardType = KeyboardType.Number,
                    unfocusedBorderColor = Color.Transparent,
                    focusedBorderColor = Color.Transparent,
                    isPassword = true,
                    isError = viewStates.errorBean.cashCardNumberAgainErrorFlag
                )
            }
        }

        // 処理ボタン
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(50.dp, 20.dp, 50.dp, 30.dp)
        ) {
            PrimaryButton(text = stringResource(R.string.common_page_button_next)) {
                viewModel.doNext(coroutineScope, scrollState)
            }
            Spacer(modifier = Modifier.height(20.dp))
            AppButton(text = stringResource(R.string.common_page_button_return)) {
                PreferenceUtil.setPreferenceBooleanValue(ConstUtil.OPENED_EDIT_INFO_FLAG, false)
                MainActivity.NAVCTRL?.back()
            }
        }
    }
}

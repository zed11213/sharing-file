package jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbco.mbco0202

/**
 * MBCO0202ステータ
 */
data class MBCO0202PageState(

    /**
     * メールアドレス
     */
    var emailAddress: String = "",

    /**
     * トランザクションコード
     */
    var transactionCode: String = "",

    /**
     * タイプ
     */
    var type: String = "",

    /**
     * 確認番号
     */
    var confirmationCode: String = "",

    /**
     * エラーメッセージ内容
     */
    var errMsgList: List<String> = listOf(),
)

package jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbco.mbco0202

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.google.accompanist.systemuicontroller.rememberSystemUiController
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.logic.opened.mbco.mbco0202.MBCO0202Logic
import jp.co.jsbank.mb.bankingapp.system.Config.isRetail
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.theme.H5
import jp.co.jsbank.mb.bankingapp.theme.H6
import jp.co.jsbank.mb.bankingapp.theme.H7
import jp.co.jsbank.mb.bankingapp.theme.general_label_color
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.AppButton
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.IconButton
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.PrimaryButton
import jp.co.jsbank.mb.bankingapp.ui.widgets.error.EditErrorListWidget
import jp.co.jsbank.mb.bankingapp.ui.widgets.tabBar.Tab
import jp.co.jsbank.mb.bankingapp.ui.widgets.textField.TextWidget
import jp.co.jsbank.mb.bankingapp.ui.widgets.textField.autoCloseKeyboard
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.HALF_HYPHEN
import jp.co.jsbank.mb.bankingapp.utils.PreferenceUtil
import jp.co.jsbank.mb.bankingapp.utils.RouteUtil
import jp.co.jsbank.mb.bankingapp.utils.RouteUtil.back
import jp.co.jsbank.mb.bankingapp.utils.WebConstUtil.WEB_VIEW_MBCO0202_CASH_CARD_POST_CODE_UN_KNOW
import jp.co.jsbank.mb.bankingapp.utils.WebConstUtil.WEB_VIEW_MBCO0202_OPEN_ACCOUNT_BIZ_POST_CODE_UN_KNOW
import jp.co.jsbank.mb.bankingapp.utils.WebConstUtil.WEB_VIEW_MBCO0202_OPEN_ACCOUNT_POST_CODE_UN_KNOW
import jp.co.jsbank.mb.bankingapp.utils.WebConstUtil.WEB_VIEW_URL_CONST

/**
 * MBCO0202　確認番号入力
 *
 * @param viewModel ロジック
 */
@Composable
fun MBCO0202Page(
    viewModel: MBCO0202Logic = hiltViewModel(),
) {
    val viewStates = viewModel.viewStates
    // ステータスバーの色の変更
    rememberSystemUiController().setStatusBarColor(Color.White)

    Column(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp)
            .verticalScroll(rememberScrollState())
            .autoCloseKeyboard(),
    ) {
        Column {
            if (PreferenceUtil.getPreferenceBooleanValue(ConstUtil.EKYC_TYPE))
                Tab(
                    state = 2,
                    list = listOf(
                        stringResource(R.string.common_tab_process_second),
                        stringResource(R.string.common_tab_process_first),
                        stringResource(R.string.common_tab_process_fifth)
                    )
                )
            else
                Tab(
                    state = 3,
                    list = listOf(
                        stringResource(R.string.common_tab_process_4th),
                        stringResource(R.string.common_tab_process_second),
                        stringResource(R.string.common_tab_process_first),
                        stringResource(R.string.common_tab_process_fifth)
                    )
                )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    text = stringResource(R.string.mbsu0502_page_label_confirmation_number),
                    color = general_label_color,
                    fontSize = H5
                )
            }

            // 入力エラー情報
            if (viewStates.errMsgList.isNotEmpty()) {
                EditErrorListWidget(viewStates.errMsgList)
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 10.dp),
            ) {
                Text(
                    text = stringResource(R.string.mbsu0502_page_label_number_input_help),
                    color = general_label_color,
                    fontSize = H7
                )
            }

            Row(
                modifier = Modifier
                    .padding(top = 10.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(
                    modifier = Modifier
                        .weight(0.1f),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = viewStates.transactionCode + HALF_HYPHEN,
                        color = general_label_color,
                        fontSize = H6
                    )
                }
                Column(
                    modifier = Modifier
                        .weight(0.9f)
                        .padding(start = 10.dp)
                ) {
                    TextWidget(
                        onImeAction = {},
                        value = "",
                        onChange = {
                            viewStates.confirmationCode = it
                        },
                        placeholder = "6桁の確認番号入力",
                        enabled = true,
                        maxLength = 6,
                        keyboardType = KeyboardType.Number,
                        unfocusedBorderColor = Color.Transparent,
                        focusedBorderColor = Color.Transparent,
                        isError = viewStates.errMsgList.isNotEmpty()
                    )
                }
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(0.dp, 0.dp, 0.dp, 0.dp),
            ) {
                IconButton(
                    rightText = stringResource(R.string.mbsu0502_page_button_no_email),
                    image = R.drawable.error_red_filled_circle,
                    imageSize = 16.dp
                ) {
                    if (viewStates.type == ConstUtil.MAIL_CONFIRM_TYPE_CASH_CARD) {
                        RouteUtil.navTo(
                            RouteName.WEB_VIEW_PAGE + WEB_VIEW_URL_CONST + WEB_VIEW_MBCO0202_CASH_CARD_POST_CODE_UN_KNOW
                        )
                    } else {
                        if (isRetail()) {
                            RouteUtil.navTo(
                                RouteName.WEB_VIEW_PAGE + WEB_VIEW_URL_CONST +
                                    WEB_VIEW_MBCO0202_OPEN_ACCOUNT_POST_CODE_UN_KNOW
                            )
                        } else {
                            RouteUtil.navTo(
                                RouteName.WEB_VIEW_PAGE + WEB_VIEW_URL_CONST +
                                    WEB_VIEW_MBCO0202_OPEN_ACCOUNT_BIZ_POST_CODE_UN_KNOW
                            )
                        }
                    }
                }
            }
            Box(
                contentAlignment = Alignment.BottomCenter,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 60.dp, vertical = 10.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                ) {
                    PrimaryButton(text = stringResource(R.string.common_page_button_next)) {
                        // チェック
                        viewModel.errorCheck(viewStates.type)
                    }
                    Spacer(modifier = Modifier.height(20.dp))
                    AppButton(text = stringResource(R.string.mbsu0502_page_button_send_again)) {
                        MainActivity.NAVCTRL?.back()
                    }
                }
            }
        }
    }
}

package jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbco.mbco0403

/**
 * MBCO0403ステータ
 */
data class MBCO0403PageState(

    /**
     * ダイアログフラグ.
     */
    var flag: Boolean = false,
)

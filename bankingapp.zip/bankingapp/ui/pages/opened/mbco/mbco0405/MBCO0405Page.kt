package jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbco.mbco0405

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.google.accompanist.systemuicontroller.rememberSystemUiController
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.logic.opened.mbco.mbco0405.MBCO0405Logic
import jp.co.jsbank.mb.bankingapp.system.master.PersonalityFlag
import jp.co.jsbank.mb.bankingapp.theme.*
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.IconButton
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.PrimaryButton
import jp.co.jsbank.mb.bankingapp.ui.widgets.error.EditErrorListWidget
import jp.co.jsbank.mb.bankingapp.ui.widgets.tabBar.Tab
import jp.co.jsbank.mb.bankingapp.ui.widgets.textField.PersonName
import jp.co.jsbank.mb.bankingapp.ui.widgets.textField.TextWidget
import jp.co.jsbank.mb.bankingapp.ui.widgets.textField.autoCloseKeyboard
import jp.co.jsbank.mb.bankingapp.utils.*
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.EKYC_TYPE

/**
 * MBCO0405	読み取り結果
 *
 * @param viewModel MBCO0405ロジック
 */
@Composable
fun MBCO0405Page(
    viewModel: MBCO0405Logic = hiltViewModel(),
) {
    // ステータスバーの色の変更
    rememberSystemUiController().setStatusBarColor(Color.White)
    // ステータ
    val viewStates = viewModel.viewStates
    val scrollState = rememberScrollState()
    val coroutineScope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .autoCloseKeyboard()
    ) {
        Column {
            if (PreferenceUtil.getPreferenceBooleanValue(EKYC_TYPE))
                Tab(
                    state = 1,
                    list = listOf(
                        stringResource(R.string.common_tab_process_second),
                        stringResource(R.string.common_tab_process_first),
                        stringResource(R.string.common_tab_process_fifth),
                    )
                )
            else
                Tab(
                    state = 2,
                    list = listOf(
                        stringResource(R.string.common_tab_process_4th),
                        stringResource(R.string.common_tab_process_second),
                        stringResource(R.string.common_tab_process_first),
                        stringResource(R.string.common_tab_process_fifth),
                    )
                )
        }
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    text = stringResource(R.string.mbco0405_page_title),
                    color = general_label_color,
                    fontSize = H5
                )
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 16.dp, top = 10.dp, end = 16.dp),
            ) {
                Text(
                    text = stringResource(R.string.mbco0405_page_first_reading_result),
                    color = general_label_color,
                    fontSize = H6
                )
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
            ) {
                Text(
                    text = stringResource(R.string.mbco0405_page_second_reading_result),
                    color = general_label_color,
                    fontSize = H6
                )
            }

            // エラーがある場合、エラーメッセージ内容が表示する
            if (viewStates.isError) {
                EditErrorListWidget(viewStates.errMsgList)
            }

            if (!PreferenceUtil.getPreferenceBooleanValue(EKYC_TYPE)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 16.dp, top = 16.dp, end = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stringResource(R.string.mbco0405_page_label_name),
                        color = general_label_color,
                        fontSize = H6
                    )
                    IconButton(
                        rightText = stringResource(R.string.common_page_style_help),
                        image = R.drawable.error_red_filled_circle,
                        imageSize = 14.dp
                    ) {
                        RouteUtil.navTo(
                            RouteName.WEB_VIEW_PAGE + WebConstUtil.WEB_VIEW_URL_CONST + WebConstUtil.WEB_VIEW_HELP_STYLE
                        )
                    }
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 16.dp, top = 5.dp, end = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        modifier = Modifier
                            .weight(0.45f),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        PersonName(
                            value = viewStates.lastName,
                            onChange = {
                                viewStates.lastName = it
                            },
                            placeholder = "城南",
                            isError = viewStates.errorBean.lastNameErrorFlag,
                        ).Build()
                    }
                    Spacer(modifier = Modifier.weight(0.1f))
                    Column(
                        modifier = Modifier
                            .weight(0.45f),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        PersonName(
                            value = viewStates.firstName,
                            onChange = {
                                viewStates.firstName = it
                            },
                            placeholder = "太郎",
                            isError = viewStates.errorBean.firstNameErrorFlag,
                        ).Build()
                    }
                }
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 16.dp, top = 16.dp, end = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = stringResource(R.string.mbco0405_page_label_year),
                    color = general_label_color,
                    fontSize = H6
                )
                IconButton(
                    rightText = stringResource(R.string.mbco0405_page_label_year_description),
                    image = R.drawable.error_red_filled_circle,
                    imageSize = 14.dp
                ) {
                    RouteUtil.navTo(
                        RouteName.WEB_VIEW_PAGE + WebConstUtil.WEB_VIEW_URL_CONST + WebConstUtil.WEB_VIEW_YEAR_CHECK
                    )
                }
            }

            Row(
                modifier = Modifier
                    .padding(start = 16.dp, top = 5.dp, end = 16.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(
                    modifier = Modifier
                        .weight(0.2f),
                    verticalArrangement = Arrangement.Center,
                ) {
                    Text(
                        text = stringResource(R.string.mbop0601_page_label_anno_domini),
                        color = general_label_color,
                        fontSize = H6
                    )
                }
                Column(
                    modifier = Modifier
                        .weight(0.4f),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    TextWidget(
                        onImeAction = {},
                        value = viewStates.year,
                        onChange = {
                            viewStates.year = it
                        },
                        placeholder = "1990",
                        maxLength = 4,
                        keyboardType = KeyboardType.Number,
                        unfocusedBorderColor = Color.Transparent,
                        focusedBorderColor = Color.Transparent,
                        isError = viewStates.errorBean.yearErrorFlag,
                        textAlign = TextAlign.End
                    )
                }
                Column(
                    modifier = Modifier
                        .weight(0.15f),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = stringResource(R.string.common_label_year),
                        color = general_label_color,
                        fontSize = H6
                    )
                }
                Column(
                    modifier = Modifier
                        .weight(0.3f),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    TextWidget(
                        onImeAction = {},
                        value = viewStates.month,
                        onChange = {
                            viewStates.month = it
                        },
                        placeholder = "10",
                        maxLength = 2,
                        keyboardType = KeyboardType.Number,
                        unfocusedBorderColor = Color.Transparent,
                        focusedBorderColor = Color.Transparent,
                        isCompletion = true,
                        isError = viewStates.errorBean.monthErrorFlag,
                        textAlign = TextAlign.End
                    )
                }
                Column(
                    modifier = Modifier
                        .weight(0.15f),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = stringResource(R.string.common_label_month),
                        color = general_label_color,
                        fontSize = H6
                    )
                }
                Column(
                    modifier = Modifier
                        .weight(0.3f),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    TextWidget(
                        onImeAction = {},
                        value = viewStates.day,
                        onChange = {
                            viewStates.day = it
                        },
                        placeholder = "10",
                        maxLength = 2,
                        keyboardType = KeyboardType.Number,
                        unfocusedBorderColor = Color.Transparent,
                        focusedBorderColor = Color.Transparent,
                        isCompletion = true,
                        isError = viewStates.errorBean.dayErrorFlag,
                        textAlign = TextAlign.End
                    )
                }
                Column(
                    modifier = Modifier
                        .weight(0.15f),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = stringResource(R.string.common_label_day),
                        color = general_label_color,
                        fontSize = H6
                    )
                }
            }
            // 人格区分
            val personType = PreferenceUtil.getPreferenceStringValue(ConstUtil.PERSONALITY_FLAG).toString()
            if (!PreferenceUtil.getPreferenceBooleanValue(EKYC_TYPE) &&
                personType != PersonalityFlag.INDIVIDUAL_BUSINESS.code
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 16.dp, top = 16.dp, end = 16.dp),
                ) {
                    Text(
                        text = stringResource(R.string.mbco0405_page_label_postcode),
                        color = general_label_color,
                        fontSize = H6
                    )
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 16.dp, top = 5.dp, end = 16.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextWidget(
                        onImeAction = {},
                        value = viewStates.postCode,
                        onChange = {
                            viewStates.postCode = it
                        },
                        placeholder = stringResource(R.string.mbcc0401_page_label_postCode_placeholder),
                        maxLength = 7,
                        keyboardType = KeyboardType.Number,
                        unfocusedBorderColor = Color.Transparent,
                        focusedBorderColor = Color.Transparent,
                        isError = viewStates.errorBean.postCodeErrorFlag,
                    )
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 16.dp, top = 4.dp, end = 16.dp),
                ) {
                    IconButton(
                        rightText = stringResource(R.string.mbco0405_page_label_postCode_help_first),
                        image = R.drawable.error_red_filled_circle,
                        imageSize = 16.dp
                    ) {
                        WebBrowserUtil().setWebUrl(WebConstUtil.WEB_VIEW_POST_CODE)
                    }
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 16.dp, end = 16.dp),
                ) {
                    Text(
                        text = stringResource(R.string.mbco0405_page_label_postCode_help_first_info),
                        modifier = Modifier.padding(start = 20.dp),
                        color = input_tip_color,
                        fontSize = H7
                    )
                }
            }
        }
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .padding(horizontal = 60.dp, vertical = 20.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
            ) {
                PrimaryButton(text = stringResource(R.string.common_page_button_next)) {
                    viewModel.doNext(coroutineScope, scrollState)
                }
            }
        }
    }
}

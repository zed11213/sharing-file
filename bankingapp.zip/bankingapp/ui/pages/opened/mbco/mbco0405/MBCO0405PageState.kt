package jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbco.mbco0405

/**
 * MBCO0405ステータ
 */
data class MBCO0405PageState(

    /**
     * 姓.
     */
    var lastName: String = "",

    /**
     * 名.
     */
    var firstName: String = "",

    /**
     * 年
     */
    var year: String = "",

    /**
     * 月
     */
    var month: String = "",

    /**
     * 日
     */
    var day: String = "",

    /**
     * 郵便番号
     */
    var postCode: String = "",

    /**
     * MBCO0405 errorBean
     */
    var errorBean: MBCO0405ErrorInformation = MBCO0405ErrorInformation(),

    /**
     * 入力エラーフラグ
     */
    var isError: Boolean = false,

    /**
     * エラーメッセージ内容
     */
    var errMsgList: List<String> = listOf(),
)

/**
 * MBCO0405エラー情報
 */
data class MBCO0405ErrorInformation(

    /**
     * 姓(エラーフラグ)
     */
    var lastNameErrorFlag: Boolean = false,

    /**
     * 名前(エラーフラグ)
     */
    var firstNameErrorFlag: Boolean = false,

    /**
     * 年(エラーフラグ)
     */
    var yearErrorFlag: Boolean = false,

    /**
     * 月(エラーフラグ)
     */
    var monthErrorFlag: Boolean = false,

    /**
     * 日(エラーフラグ)
     */
    var dayErrorFlag: Boolean = false,

    /**
     * 郵便番号(エラーフラグ)
     */
    var postCodeErrorFlag: Boolean = false,
)

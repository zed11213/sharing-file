package jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbco.mbco0405

/**
 * MBCO0405ステータ
 */
data class MBCO0405PageState(

    /**
     * 姓.
     */
    var lastName: String = "",

    /**
     * 名.
     */
    var firstName: String = "",

    /**
     * 年
     */
    var year: String = "",

    /**
     * 月
     */
    var month: String = "",

    /**
     * 日
     */
    var day: String = "",

    /**
     * 郵便番号
     */
    var postCode: String = "",
    /**
     * 住所
     */
    var address: String = "",
    /**
     * 性別
     */
    var gender: String = "",

    /**
     * 性別表示フラグ
     */
    var genderFlg: Boolean = true,

    /**
     * MBCO0405 errorBean
     */
    var errorBean: MBCO0405ErrorInformation = MBCO0405ErrorInformation(),

    /**
     * 入力エラーフラグ
     */
    var isError: Boolean = false,

    /**
     * エラーメッセージ内容
     */
    var errMsgList: List<String> = listOf(),

    /**
     * 注意コード誘導メッセージフラグ
     */
    var showDialogFlag: Boolean = false,
    /**
     * 誘導メッセージ
     */
    var sorryMessage : String = ""
)

/**
 * MBCO0405エラー情報
 */
data class MBCO0405ErrorInformation(

    /**
     * 姓(エラーフラグ)
     */
    var lastNameErrorFlag: Boolean = false,

    /**
     * 名前(エラーフラグ)
     */
    var firstNameErrorFlag: Boolean = false,

    /**
     * 年(エラーフラグ)
     */
    var yearErrorFlag: Boolean = false,

    /**
     * 月(エラーフラグ)
     */
    var monthErrorFlag: Boolean = false,

    /**
     * 日(エラーフラグ)
     */
    var dayErrorFlag: Boolean = false,

    /**
     * 郵便番号(エラーフラグ)
     */
    var postCodeErrorFlag: Boolean = false,

    /**
     * 住所(エラーフラグ)
     */
    var addressErrorFlag: Boolean = false,

    /**
     * 性別(エラーフラグ)
     */
    var genderErrorFlag: Boolean = false,
)

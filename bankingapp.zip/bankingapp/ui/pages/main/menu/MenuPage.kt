package jp.co.jsbank.mb.bankingapp.ui.pages.main.menu

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material.Divider
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color.Companion.White
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.google.accompanist.systemuicontroller.rememberSystemUiController
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.system.Config.isRetail
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.theme.*
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.click
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.FROM_MENU
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.USER
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.USER_NO_DONE
import jp.co.jsbank.mb.bankingapp.utils.PreferenceUtil
import jp.co.jsbank.mb.bankingapp.utils.RouteUtil

/**
 * メニュー画面.
 *
 */
@Composable
fun MenuPage() {
    // ステータスバーの色の変更
    rememberSystemUiController().setStatusBarColor(app_bar_background_color)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(app_bar_background_color)
            .verticalScroll(rememberScrollState()),
    ) {
        Spacer(modifier = Modifier.height(30.dp))

        // 　ヘッダ
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    text = stringResource(id = R.string.menu_page_title),
                    fontSize = H5,
                    color = general_label_color
                )
            }
        }

        Spacer(modifier = Modifier.height(50.dp))

        Column(
            modifier = Modifier
                .background(White)
                .fillMaxWidth()
        ) {
            // 預金一覧
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .click {
                        RouteUtil.navTo(
                            RouteName.MBDP0101Page,
                        )
                    }
            ) {
                ColumnItem(stringResource(id = R.string.menu_page_deposit_list))
            }

            Divider(
                modifier = Modifier.padding(horizontal = 16.dp),
                thickness = 1.dp,
                color = general_dividing_line_color
            )
            // お知らせ一覧
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .click {
                        RouteUtil.navTo(
                            RouteName.MBNT0101Page,
                            if (MainActivity.IS_ANNOUNCEMENTS_IMPORTANT_FLAG) 0 else 1
                        )
                    }
            ) {
                ColumnItem(stringResource(id = R.string.menu_page_notice_list))
            }

            Divider(
                modifier = Modifier.padding(horizontal = 16.dp),
                thickness = 1.dp,
                color = general_dividing_line_color
            )
            // かんたん申込
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .click {
                        RouteUtil.navTo(
                            RouteName.MBNT0101Page,
                            3
                        )
                    }
            ) {
                ColumnItem(stringResource(id = R.string.menu_page_easy_application))
            }
        }

        // 利用者flag
        val userFlag = PreferenceUtil.getPreferenceStringValue(USER)
        if (!(userFlag == USER_NO_DONE || userFlag == ConstUtil.USER_DONE)) {
            Spacer(modifier = Modifier.height(38.dp))

            // 口座管理
            Column(modifier = Modifier.padding(bottom = 8.dp)) {
                Row(modifier = Modifier.padding(start = 16.dp)) {
                    Text(
                        text = stringResource(id = R.string.menu_page_account_management),
                        fontSize = H8,
                        color = account_detail_label_color
                    )
                }
            }
        }

        Column(
            modifier = Modifier
                .background(White)
                .fillMaxWidth()
        ) {
            // 2025/01/16 共同化ためWeb通帳への切替廃　start
//            if (isRetail()) {
//                // Web通帳切替え
//                Column(
//                    modifier = Modifier
//                        .fillMaxWidth()
//                        .click {
//                            RouteUtil.navTo(
//                                RouteName.MBST1201Page,
//                            )
//                        }
//                ) {
//                    ColumnItem(stringResource(id = R.string.menu_page_web_passbook_switching))
//                }
//                Divider(
//                    modifier = Modifier.padding(horizontal = 16.dp),
//                    thickness = 1.dp,
//                    color = general_dividing_line_color
//                )
//            }
           // 2025/01/16 共同化ためWeb通帳への切替廃　end
            if ((userFlag != USER_NO_DONE && userFlag != ConstUtil.USER_DONE)) {
                // 追加口座登録
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .click {
                            RouteUtil.navTo(RouteName.MBST0801Page)
                        }
                ) {
                    ColumnItem(stringResource(id = R.string.menu_page_add_account))
                }
                Divider(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    thickness = 1.dp,
                    color = general_dividing_line_color
                )
                // 口座削除
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .click {
                            RouteUtil.navTo(
                                RouteName.MBST0901Page,
                            )
                        }
                ) {
                    ColumnItem(stringResource(id = R.string.menu_page_delete_account))
                }
                Divider(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    thickness = 1.dp,
                    color = general_dividing_line_color
                )
                // 2025/01/16 共同化ため解約済口座削除　start
                // 解約済口座削除
//                Column(
//                    modifier = Modifier
//                        .fillMaxWidth()
//                        .click {
//                            RouteUtil.navTo(
//                                RouteName.MBST0903Page,
//                            )
//                        }
//                ) {
//                    ColumnItem(stringResource(id = R.string.menu_page_delete_canceled_account))
//                }
                // 2025/01/16 共同化ため解約済口座削除　end
            }
        }

        Spacer(modifier = Modifier.height(38.dp))

        // アプリ設定
        Column(modifier = Modifier.padding(bottom = 8.dp)) {
            Row(modifier = Modifier.padding(start = 16.dp)) {
                Text(
                    text = stringResource(id = R.string.menu_page_app_setting),
                    fontSize = H8,
                    color = account_detail_label_color
                )
            }
        }

        Column(
            modifier = Modifier
                .background(White)
                .fillMaxWidth()
        ) {
            // 通知設定
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .click {
                        RouteUtil.navTo(
                            RouteName.MBST1801Page,
                        )
                    }
            ) {
                ColumnItem(stringResource(id = R.string.menu_page_notice_setting))
            }
            Divider(
                modifier = Modifier.padding(horizontal = 16.dp),
                thickness = 1.dp,
                color = general_dividing_line_color
            )
            // 通帳証書デザイン変更
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .click {
                        RouteUtil.navTo(
                            RouteName.MBLG0302Page,
                            FROM_MENU
                        )
                    }
            ) {
                ColumnItem(stringResource(id = R.string.menu_page_passbook_design_change))
            }
        }

        Spacer(modifier = Modifier.height(38.dp))

        // アプリについて
        Column(modifier = Modifier.padding(bottom = 8.dp)) {
            Row(modifier = Modifier.padding(start = 16.dp)) {
                Text(
                    text = stringResource(id = R.string.menu_page_about_app),
                    fontSize = H8,
                    color = account_detail_label_color
                )
            }
        }

        Column(
            modifier = Modifier
                .background(White)
                .fillMaxWidth()
        ) {
            // 利用案内 TODO
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .click {
                        RouteUtil.navTo(
                            RouteName.MBLG0301Page,
                            FROM_MENU
                        )
                    }
            ) {
                ColumnItem(stringResource(id = R.string.menu_page_usage_guide))
            }
            Divider(
                modifier = Modifier.padding(horizontal = 16.dp),
                thickness = 1.dp,
                color = general_dividing_line_color
            )
            // 利用規定
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .click {
                        RouteUtil.navTo(
                            RouteName.MBST1501Page,
                        )
                    }
            ) {
                ColumnItem(stringResource(id = R.string.menu_page_usage_rule))
            }
            Divider(
                modifier = Modifier.padding(horizontal = 16.dp),
                thickness = 1.dp,
                color = general_dividing_line_color
            )
            // ライセンス表示
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .click {
                        RouteUtil.navTo(
                            RouteName.MBST1601Page,
                        )
                    }
            ) {
                ColumnItem(
                    stringResource(id = R.string.menu_page_license_display)
                )
            }
            Divider(
                modifier = Modifier.padding(horizontal = 16.dp),
                thickness = 1.dp,
                color = general_dividing_line_color
            )
            // 個人情報のお取り扱いについて
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .click {
                        RouteUtil.navTo(
                            RouteName.MBST1701Page,
                        )
                    }
            ) {
                ColumnItem(
                    stringResource(id = R.string.menu_page_about_personal_information)
                )
            }
        }

        Spacer(modifier = Modifier.height(120.dp))
    }
}

@Composable
fun ColumnItem(text: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp, horizontal = 16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = text,
                fontSize = H5,
                color = general_label_color
            )
        }
        Column {
            Image(
                contentScale = ContentScale.Fit,
                painter = painterResource(R.drawable.right),
                contentDescription = "",
            )
        }
    }
}

package jp.co.jsbank.mb.bankingapp.ui.pages.main.help

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material.Text
import androidx.compose.material.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.google.accompanist.systemuicontroller.rememberSystemUiController
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.system.Config
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.theme.*
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.FloatingActionButton
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.IconButton
import jp.co.jsbank.mb.bankingapp.ui.widgets.webview.WebView
import jp.co.jsbank.mb.bankingapp.utils.RouteUtil.back
import jp.co.jsbank.mb.bankingapp.utils.ToLoginUtil
import jp.co.jsbank.mb.bankingapp.utils.WebBrowserUtil
import jp.co.jsbank.mb.bankingapp.utils.WebConstUtil
import jp.co.jsbank.mb.bankingapp.utils.WebConstUtil.WEB_VIEW_HELP_DEVICE_CHANGE

/**
 * お困りの時
 */
@Composable
fun HelpPage() {
    // ステータスバーの色の変更
    rememberSystemUiController().setStatusBarColor(app_bar_background_color)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(app_bar_background_color),
    ) {
        // アプリバー
        TopAppBar(
            modifier = Modifier
                .padding(horizontal = 10.dp, vertical = 10.dp)
                .height(30.dp),
            elevation = 0.dp,
            backgroundColor = app_bar_background_color,
        ) {
            Box(
                contentAlignment = Alignment.Center
            ) {
                if (MainActivity.PASSWORD_TO_HELP_FLAG) {
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        IconButton(
                            rightText = stringResource(id = R.string.common_page_topBar_button_return),
                            image = R.drawable.icon_back,
                            textSize = H5,
                            imageSize = 16.dp
                        ) {
                            if (MainActivity.IS_BACK_GROUND) {
                                ToLoginUtil.openLogin("1")
                            } else {
                                MainActivity.PASSWORD_TO_HELP_FLAG = false
                            }
                            MainActivity.NAVCTRL?.back()
                        }
                    }
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth()
                    ) {
                    }
                }
                Text(
                    text = stringResource(id = R.string.help),
                    color = app_bar_title_color,
                    textAlign = TextAlign.Center,
                    fontSize = H5,
                )
            }
        }
        WebView(url = WEB_VIEW_HELP_DEVICE_CHANGE)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(10.dp, 10.dp, 10.dp, 10.dp),
        verticalArrangement = Arrangement.Bottom,
        horizontalAlignment = Alignment.End,
    ) {
        FloatingActionButton(text = stringResource(id = R.string.common_page_float_button), size = 100.dp) {
            if (Config.isRetail()) {
                WebBrowserUtil().setWebUrl(WebConstUtil.WEB_LINK_MBSU0101_CHATBOT)
            } else {
                WebBrowserUtil().setWebUrl(WebConstUtil.WEB_LINK_MBSU0101_BIZ_CHATBOT)
            }
        }
    }
}

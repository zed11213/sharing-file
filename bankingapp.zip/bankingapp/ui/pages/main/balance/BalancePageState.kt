package jp.co.jsbank.mb.bankingapp.ui.pages.main.balance

import java.time.LocalDate
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.bean.common.CodeBean
import jp.co.jsbank.mb.bankingapp.bean.main.balance.BalanceResponseBean
import jp.co.jsbank.mb.bankingapp.bean.main.home.BalanceInformation
import jp.co.jsbank.mb.bankingapp.ui.widgets.barchart.BarChartData

/**
 * 収支グラフステータス.
 */
data class BalancePageState(

    /**
     * 残高情報
     */
    var accountInfoList: MutableList<BalanceInformation> = mutableListOf(),

    /**
     * 科目種別リスト
     */
    var subjectInfoList: MutableList<CodeBean> = mutableListOf(),

    /**
     * 選択された科目
     */
    var selectedSubject: CodeBean = CodeBean(),

    /**
     * 選択された科目の背景
     */
    var backgroundImage: Int = R.drawable.usually_account_details_background,

    /**
     * 科目別口座情報
     */
    val subjectBalanceMap: MutableMap<String, MutableList<BalanceInformation>> = mutableMapOf(),

    /**
     * 選択された科目の口座情報リスト
     */
    var subjectBalanceInfoList: MutableList<BalanceInformation> = mutableListOf(),

    /**
     * 口座番号(検索用)
     */
    var accountNumber: String = "",

    /**
     * 店番(検索用)
     */
    var branchNumber: String = "",

    /**
     * 開始日(検索用)
     */
    var dateFrom: LocalDate = LocalDate.of(
        LocalDate.now().plusMonths(-5).year,
        LocalDate.now().plusMonths(-5).month,
        1
    ),

    /**
     * 終了日(検索用)
     */
    var dateTo: LocalDate = LocalDate.of(
        LocalDate.now().year,
        LocalDate.now().month,
        LocalDate.now().month.length(LocalDate.now().isLeapYear)
    ),

    /**
     * 更新時間
     */
    var updateTime: String = "",

    /**
     * 収支グラフ情報（全部）
     */
    var allBalanceInfoList: List<BalanceResponseBean> = listOf(),

    /**
     * 収支グラフ情報（期間）
     */
    var balanceInfoList: List<BarChartData.BalanceInfo> = listOf(),

    /**
     * エラーフラグ
     */
    var errorFlag: Boolean = false,
)

package jp.co.jsbank.mb.bankingapp.ui.pages.main.balance

import android.annotation.SuppressLint
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.paint
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import java.time.format.DateTimeFormatter
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.logic.main.balance.BalanceLogic
import jp.co.jsbank.mb.bankingapp.system.master.Subject
import jp.co.jsbank.mb.bankingapp.theme.H7
import jp.co.jsbank.mb.bankingapp.theme.H8
import jp.co.jsbank.mb.bankingapp.theme.general_label_color
import jp.co.jsbank.mb.bankingapp.theme.prominent_label_color
import jp.co.jsbank.mb.bankingapp.ui.widgets.barchart.BarChartScreenContent
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.IconButton
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.click
import jp.co.jsbank.mb.bankingapp.ui.widgets.drawer.DrawerWidget
import jp.co.jsbank.mb.bankingapp.ui.widgets.dropDown.GraphDropDownWidget
import jp.co.jsbank.mb.bankingapp.ui.widgets.noData.NoData
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.DATE_FORMAT_CHARACTERS_YYYY_M
import kotlinx.coroutines.launch

/**
 * 収支グラフ画面.
 *
 * @param viewModel トップロジック
 */
@SuppressLint("WeekBasedYear")
@OptIn(ExperimentalMaterialApi::class)
@Composable
fun BalancePage(
    viewModel: BalanceLogic = hiltViewModel()
) {
    val viewStates = viewModel.viewStates

    val state = rememberBottomDrawerState(BottomDrawerValue.Closed)
    val scope = rememberCoroutineScope()

    DrawerWidget(
        drawerState = state,
        scope = scope,
        dateTo = viewStates.dateTo,
        backClick = {
            viewModel.changeDateDuration(it)
        }
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row {
                Column(
                    modifier = Modifier
                        .paint(
                            painterResource(id = viewStates.backgroundImage),
                            contentScale = ContentScale.FillWidth,
                            alignment = Alignment.TopCenter
                        )
                ) {
                    // 科目切替
                    Row(
                        modifier = Modifier.weight(1.0f),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Spacer(modifier = Modifier.weight(0.8f))
                        Column(modifier = Modifier.weight(1.4f)) {
                            GraphDropDownWidget(
                                value = viewStates.selectedSubject.value,
                                placeholder = stringResource(R.string.mbcc0401_page_label_select),
                                itemList = viewStates.subjectInfoList,
                                backGround = Color.Transparent,
                                selectedBackGround = Color.Transparent,
                                selectedTextColor = if (
                                    viewStates.selectedSubject.code == Subject.CHECKING_ACCOUNT.code
                                )
                                    Color.Black else Color.White,
                                onClick = {
                                    viewModel.switchSubject(it)
                                },
                            )
                        }
                        Spacer(modifier = Modifier.weight(0.8f))
                    }
                    // 口座切替
                    Row(
                        modifier = Modifier
                            .weight(0.8f)
                            .padding(horizontal = 40.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        LazyRow(
                            state = rememberLazyListState(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            content = {
                                items(count = viewStates.subjectBalanceInfoList.size, itemContent = { index ->
                                    Card(
                                        shape = RoundedCornerShape(100.dp),
                                        elevation = 0.dp,
                                        modifier = Modifier.click {
                                            // 口座情報切替
                                            viewModel.switchAccountInfo(index)
                                        },
                                        backgroundColor = if (viewStates.subjectBalanceInfoList[index].selected)
                                            MaterialTheme.colors.surface else Color.Transparent,
                                        border = BorderStroke(
                                            1.dp,
                                            if (viewStates.subjectBalanceInfoList[index].selected) {
                                                Color.White
                                            } else {
                                                if (viewStates.selectedSubject.code == Subject.CHECKING_ACCOUNT.code)
                                                    Color.Black else Color.White
                                            }
                                        )
                                    ) {
                                        Text(
                                            modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp),
                                            text = viewStates.subjectBalanceInfoList[index].branchName + " " +
                                                viewStates.subjectBalanceInfoList[index].accountNumber,
                                            fontSize = H7,
                                            color = if (viewStates.subjectBalanceInfoList[index].selected) {
                                                prominent_label_color
                                            } else {
                                                if (viewStates.selectedSubject.code == Subject.CHECKING_ACCOUNT.code)
                                                    Color.Black else Color.White
                                            }
                                        )
                                    }
                                })
                            }
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    if (viewStates.allBalanceInfoList.isNullOrEmpty()) {
                        Row(
                            modifier = Modifier
                                .weight(8.0f)
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
                                .background(Color.White),
                            horizontalArrangement = Arrangement.Center,
                        ) {
                            NoData()
                        }
                    } else {
                        Row(
                            modifier = Modifier
                                .weight(8.0f)
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
                                .background(Color.White),
                            horizontalArrangement = Arrangement.Center,
                        ) {
                            Column(
                                modifier = Modifier
                                    .padding(16.dp, 10.dp, 16.dp, 0.dp)
                                    .fillMaxWidth()
                            ) {
                                // 時間検索条件の切替
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .weight(0.7f),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    IconButton(image = R.drawable.chevron_left) {
                                        viewModel.switchDateDuration("1")
                                    }
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        IconButton(image = R.drawable.calendar) {
                                            scope.launch { state.expand() }
                                        }
                                        Text(
                                            text = viewStates.dateFrom.format(
                                                DateTimeFormatter.ofPattern(DATE_FORMAT_CHARACTERS_YYYY_M)
                                            ) + " ~ " + viewStates.dateTo.format(
                                                DateTimeFormatter.ofPattern(DATE_FORMAT_CHARACTERS_YYYY_M)
                                            ),
                                            modifier = Modifier.click { scope.launch { state.expand() } }
                                        )
                                    }
                                    IconButton(image = R.drawable.chevron_right) {
                                        viewModel.switchDateDuration("2")
                                    }
                                }
                                // 具体的な情報
                                Row(
                                    modifier = Modifier
                                        .weight(7.0f)
                                ) {
                                    BarChartScreenContent(viewStates.balanceInfoList)
                                }
                                // 情報取得時刻
                                Row(
                                    modifier = Modifier
                                        .weight(0.5f)
                                        .fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End
                                ) {
                                    Text(
                                        text = stringResource(id = R.string.balancePage_get_info_time) +
                                            " " + viewStates.updateTime,
                                        fontSize = H8,
                                        color = general_label_color
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

package jp.co.jsbank.mb.bankingapp.ui.pages.main.home

import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.CircularProgressIndicator
import androidx.compose.material.Scaffold
import androidx.compose.material.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.navigation.NavBackStackEntry
import com.google.accompanist.systemuicontroller.rememberSystemUiController
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.bean.login.mblg.mblg0201.NoticeDeposit
import jp.co.jsbank.mb.bankingapp.bean.main.home.mbdp.mbdp0301.TermDepositDetails
import jp.co.jsbank.mb.bankingapp.logic.main.home.HomeLogic
import jp.co.jsbank.mb.bankingapp.system.Config
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.system.MainActivity.Companion.IS_ANNOUNCEMENTS_IMPORTANT_FLAG
import jp.co.jsbank.mb.bankingapp.system.MyApp
import jp.co.jsbank.mb.bankingapp.system.master.BankbookDesign
import jp.co.jsbank.mb.bankingapp.system.master.GeneralAccountFlag
import jp.co.jsbank.mb.bankingapp.system.master.Subject
import jp.co.jsbank.mb.bankingapp.theme.*
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.FloatingActionButton
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.Icon3rdButton
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.IconButton
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.click
import jp.co.jsbank.mb.bankingapp.ui.widgets.card.CardAnnouncementsList
import jp.co.jsbank.mb.bankingapp.ui.widgets.card.CardHorizontalNote
import jp.co.jsbank.mb.bankingapp.ui.widgets.card.CardHorizontalNoteExt
import jp.co.jsbank.mb.bankingapp.ui.widgets.copyright.Copyright
import jp.co.jsbank.mb.bankingapp.ui.widgets.dialog.CheckConsentDialog
import jp.co.jsbank.mb.bankingapp.ui.widgets.dialog.LogOutDialog
import jp.co.jsbank.mb.bankingapp.utils.*
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.DOT
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.HALF_HYPHEN
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.SPLASH
import jp.co.jsbank.mb.bankingapp.utils.WebConstUtil.HOME_PAGE
import jp.co.jsbank.mb.bankingapp.utils.WebConstUtil.WEB_VIEW_DIGITAL_INVOICE
import java.util.Comparator
import java.util.stream.Collectors

/**
 * トップ画面.
 *
 * @param viewModel トップロジック
 */
@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun HomePage(
    viewModel: HomeLogic = hiltViewModel()
) {

    val viewStates = viewModel.viewStates
    val coroutineScope = rememberCoroutineScope()
    val scrollState = rememberScrollState()
    var coordinates by remember { mutableStateOf(0f) }
    var refresh by remember {
        mutableStateOf(
            observe(MainActivity.NAVCTRL?.currentBackStackEntry!!)
        )
    }
    if (refresh == "1") {
        viewModel.getNotice()
        refresh = "0"
        MainActivity.NAVCTRL?.previousBackStackEntry?.savedStateHandle?.set("refresh", "0")
    }
    val designType = PreferenceUtil.getPreferenceStringValue(ConstUtil.DESIGN_TYPE)

    // ステータスバーの色の変更
    rememberSystemUiController().setStatusBarColor(app_bar_background_color)

    val lifecycleObserver = remember(viewModel) {
        LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                if (MainActivity.IS_BACK_GROUND) {
                    viewModel.closeCouponDialogFlag()
                }
            }
        }
    }
    val lifecycleOwner = LocalLifecycleOwner.current
    lifecycleOwner.lifecycle.addObserver(lifecycleObserver)

    Scaffold(
        content = {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(app_bar_background_color)
                    .verticalScroll(scrollState)
            ) {
                // トップ
                TopContent(viewModel)
                // スクロール可能なカード
                ScrollableContent(
                    homePageState = viewStates,
                    logic = viewModel,
                    state = viewStates.indexState,
                    coroutineScope,
                    coordinates,
                    scrollState
                )
                if (viewStates.type == 3 || viewStates.type == 6) {
                    Column(
                        modifier = Modifier.onGloballyPositioned { layoutCoordinates ->
                            coordinates = layoutCoordinates.positionInRoot().y
                        }
                    ) {
                        Certificates(
                            viewStates,
                            designType,
                            homeLogic = viewModel
                        )
                    }
                }
//                Text(text = "st = ${viewModel.viewStates.termDepositLoadStatus} st = ${viewModel.viewStates.noticeDepositLoadStatus}")
                // 証書一覧
//                if ((viewStates.type == 3 && viewStates.regularDepositList.isNotEmpty()) ||
//                    (viewStates.type == 6 && viewStates.notificationDeposit.isNotEmpty())
//                )
//
//                else if((viewStates.type == 3 && viewStates.termDepositLoadStatus == LoadStatus.ERROR) ||
//                    (viewStates.type == 6 && viewStates.noticeDepositLoadStatus == LoadStatus.ERROR)){
//                    Box(
//                        contentAlignment = Alignment.Center,
//                        modifier = Modifier
//                            .padding(start = 40.dp)
//                            .fillMaxWidth()
//                            .height(20.dp)
//                            .background(Color.Transparent, shape = RoundedCornerShape(8.dp))
//                    ) {
//                        Text(text = "ロード失敗しました")
//                    }
//
//                } else if ((viewStates.type == 3 && viewStates.termDepositLoadStatus != LoadStatus.COMPLETE) ||
//                    (viewStates.type == 6 && viewStates.noticeDepositLoadStatus != LoadStatus.COMPLETE)){
//                    Box(
//                        contentAlignment = Alignment.Center,
//                        modifier = Modifier
//                            .padding(start = 20.dp)
//                            .size(20.dp)
//                            .background(Color.Transparent, shape = RoundedCornerShape(8.dp))
//                    ) {
//                        CircularProgressIndicator(
//                            color = Color.Black,
//                            strokeWidth = 2.dp
//                        )
//                    }
//                }
                // お知らせ
                Notice(viewModel)
                // 新機能
                NewConvenientFunction()
                // 各種お申込み（児童手当キャンペーンなど）
                ChildAllowanceCampaign(viewStates, viewModel)
                // 各種機能
                ConvenientFunction()
                Row(
                    modifier =
                    Modifier
                        .fillMaxWidth()
                        .padding(start = 10.dp, top = 80.dp, end = 10.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = stringResource(id = R.string.homePage_label_login_last),
                            color = text_color,
                            fontSize = H7
                        )
                    }
                    Column(
                        modifier =
                        Modifier.padding(start = 10.dp)
                    ) {
                        Text(
                            text = viewStates.lastLoginTime,
                            color = text_color,
                            fontSize = H7
                        )
                    }
                }
                // Copyright
                Row(
                    modifier = Modifier.padding(top = 20.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Copyright(
                        modifier = Modifier
                            .background(copyright_background_color)
                            .padding(10.dp),
                    )
                }
            }
        },
        floatingActionButton = {
            Column(
                modifier = Modifier
//                    .padding(bottom = 70.dp),
                    .padding(bottom = 10.dp),
                verticalArrangement = Arrangement.Bottom,
                horizontalAlignment = Alignment.End,
            ) {
                FloatingActionButton(text = stringResource(id = R.string.common_page_float_button), size = 100.dp) {
                    if (Config.isRetail()) {
                        WebBrowserUtil().setWebUrl(WebConstUtil.WEB_LINK_MBSU0101_CHATBOT)
                    } else {
                        WebBrowserUtil().setWebUrl(WebConstUtil.WEB_LINK_MBSU0101_BIZ_CHATBOT)
                    }
                }
            }
        }
    )
}

/**
 * トップ
 *
 */
@Composable
fun TopContent(logic: HomeLogic) {
    Row(
        modifier =
        Modifier
            .fillMaxWidth()
            .padding(start = 10.dp, top = 20.dp, end = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            modifier =
            Modifier
                .click(
                    onClick = {
                        RouteUtil.navTo(
                            RouteName.MBST0101Page,
                        )
                    }
                )
        ) {
            Image(
                painter = painterResource(id = R.drawable.user_management),
                modifier = Modifier.requiredSize(30.dp),
                contentDescription = null,
                contentScale = ContentScale.Crop
            )
        }
        Column {
            Row {
                Column(
                    modifier = Modifier
                        .click {
                            logic.openLogoutDialogFlag()
                        }
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.logoutlogo),
                        modifier = Modifier.requiredSize(30.dp),
                        contentDescription = null,
                        contentScale = ContentScale.Crop
                    )
                }
            }
        }
        // ログアウトダイアログ
        if (logic.viewStates.logoutDialogFlag) {
            LogOutDialog(
                firstTitle = stringResource(id = R.string.homePage_logout_title),
                contentFirst = stringResource(id = R.string.homePage_logout_content),
                firstButtonLabel = stringResource(id = R.string.homePage_logout_firstButton),
                secondButtonLabel = stringResource(id = R.string.homePage_logout_secondButton),
                firstButtonClick = {
                    RouteUtil.navTo(
                        RouteName.MBLG0101Page,
                    )
                    MainActivity.LOG_OUT_FLAG = true
                },
                secondButtonClick = {
                    logic.closeLogoutDialogFlag()
                },
            ) {
            }
        }
    }
    Row(
        modifier =
        Modifier
            .fillMaxWidth()
            .padding(start = 10.dp, top = 10.dp, end = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Row {
                Column {
                    Text(
                        text = logic.viewStates.updateTime,
                        color = text_color,
                        fontSize = H7
                    )
                }
                Column(modifier = Modifier.padding(start = 4.dp)) {
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = stringResource(id = R.string.homePage_button_update),
                            color = text_color,
                            fontSize = H7
                        )
                        Image(
                            painter = painterResource(id = R.drawable.refresh),
                            modifier = Modifier
                                .requiredSize(14.dp)
                                .click {
                                    logic.getAccountInfo()
                                },
                            contentDescription = null,
                            contentScale = ContentScale.Crop
                        )
                    }
                }
            }
        }
        Column {
            IconButton(
                leftText = stringResource(id = R.string.homePage_button_deposits),
                image = R.drawable.right,
                imageSize = 16.dp
            ) {
                RouteUtil.navTo(
                    RouteName.MBDP0101Page,
                )
            }
        }
    }
}

/**
 * 証書一覧
 *
 */
@Composable
fun Certificates(state: HomePageState, designType: String? , homeLogic: HomeLogic) {
    val curBranchAccount = state.branchAccount.first { branch -> branch.topSelected }
    LaunchedEffect( curBranchAccount) {
        if (state.type == 3) {
            homeLogic.loadTermIfNeeded(curBranchAccount.accountNumber, curBranchAccount.branchNumber, curBranchAccount.cifNumber)
        } else if (state.type == 6){
            homeLogic.loadNotifyIfNeeded(curBranchAccount.accountNumber, curBranchAccount.branchNumber, curBranchAccount.cifNumber)
        }
    }
    Row(
        modifier =
        Modifier
            .fillMaxWidth()
            .padding(start = 10.dp, top = 30.dp, end = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = stringResource(id = R.string.homePage_label_deeds),
                color = general_label_color,
                fontSize = H4
            )
        }
        Column {
            if (state.type == 3) {
                IconButton(
                    leftText = stringResource(id = R.string.homePage_button_announcement),
                    image = R.drawable.right,
                    imageSize = 16.dp
                ) {
                    RouteUtil.navTo(
                        RouteName.MBNT0101Page,
                        2
                    )
                }
            }
        }
    }
    // 定期預金証書一覧
    if (state.type == 3 ){
        //Log.i("acc","定期預金証書一覧 ${state.termCertificateStates.size}")

        when( val cerState = state.termCertificateStates.firstOrNull{ it.account == curBranchAccount.accountNumber}){
            null -> {

            }
            else -> {
                when {
                    cerState.isLoading -> {
                        Box(
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            CircularProgressIndicator(
                                color = Color.Black,
                                strokeWidth = 3.dp,
                                modifier = Modifier.padding(start = 8.dp)
                            )
                        }
                    }
                    cerState.complete ->{
                        CertificatesList(
                            state.regularDepositList
                                .filter { b ->
                                    b.generalAccountFlag == GeneralAccountFlag.IS_GENERAL.code &&
                                        b.branchNumber == curBranchAccount.branchNumber && b.accountNumber == curBranchAccount.accountNumber
                                }.distinctBy { it.detailId },
                            designType
                        )
                    }
                }
            }
        }
    }

    // 通知預金証書一覧
    if (state.type == 6){
        //Log.i("acc","通知預金証書一覧 ${state.noticeCertificateStates.size}")

        when( val cerState = state.noticeCertificateStates.firstOrNull{ it.account == curBranchAccount.accountNumber}){
            null -> {

            }
            else -> {
                when {
                    cerState.isLoading -> {
                        Box(
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            CircularProgressIndicator(
                                color = Color.Black,
                                strokeWidth = 3.dp,
                                modifier = Modifier.padding(start = 8.dp)
                            )
                        }
                    }
                    cerState.complete ->{
                        NotifyCertificatesList(
                            state.scrollableAccountShow[state.index].accountNumber,
                            state.scrollableAccountShow[state.index].branchName,
                            state.notificationDeposit.filter { b ->
                                b.branchNumber == curBranchAccount.branchNumber && b.accountNumber == curBranchAccount.accountNumber
                            }.distinctBy { it.detailId },
                            designType
                        )
                    }
                }
            }
        }
    }
}

/**
 * 児童手当キャンペーン
 *
 */
@Composable
fun ChildAllowanceCampaign(viewStates: HomePageState, homeLogic: HomeLogic) {
/*
    Row(
        modifier =
            Modifier
                .fillMaxWidth()
                .padding(start = 10.dp, top = 10.dp, end = 10.dp),
    ) {
        CardHorizontalNote(
            modifier = Modifier, title = stringResource(id = R.string.homePage_NewSystem_title),
            content = stringResource(id = R.string.homePage_NewSystem_content),
            imageId = R.drawable.newsystem,
        ) {
            WebBrowserUtil().setWebUrl(WebConstUtil.WEB_LINK_NEWSYSTEM)
        }
    }
*/
    Row(
        modifier =
        Modifier
            .fillMaxWidth()
            .padding(start = 10.dp, top = 30.dp, end = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = stringResource(id = R.string.homePage_label_application_function),
                color = general_label_color,
                fontSize = H4
            )
        }
    }
    if (Config.isRetail()) {
        if (viewStates.childAllowanceCampaignList.size > 0) {
            Row(
                modifier =
                Modifier
                    .fillMaxWidth()
                    .padding(start = 10.dp, top = 10.dp, end = 10.dp),
            ) {
                CardHorizontalNoteExt(
                    modifier = Modifier, title = stringResource(id = R.string.homePage_childAllowanceCampaign_title),
                    maintitle = stringResource(id = R.string.homePage_childAllowanceCampaign_maintitle),
                    content = stringResource(id = R.string.homePage_childAllowanceCampaign_content),
                    imageId = R.drawable.kidsdream,
                ) {
                    homeLogic.getChildAllowanceCampaign(viewStates.childAllowanceCampaignList[0])
                }
            }
        }
    }
    if (Config.isRetail()) {
        Row(
            modifier =
            Modifier
                .fillMaxWidth()
                .padding(start = 10.dp, top = 10.dp, end = 10.dp),
        ) {
            CardHorizontalNoteExt(
                modifier = Modifier, title = stringResource(id = R.string.homePage_CouponService_title),
                maintitle = stringResource(id = R.string.homePage_CouponService_maintitle),
                maintitleFontSize = H5,
                content = stringResource(id = R.string.homePage_CouponService_content),
                imageId = R.drawable.coupon,
            ) {
                homeLogic.openCouponDialogFlag()
            }
        }
        if (homeLogic.viewStates.couponDialogFlag) {
            CheckConsentDialog(
                title = stringResource(id = R.string.homePage_CouponService_dialog_title),
                content = stringResource(id = R.string.homePage_CouponService_dialog_content),
                buttonLabel = stringResource(id = R.string.common_dialog_button_next),
                callBackButtonLabel = stringResource(id = R.string.common_dialog_button_close),
                checkBoxLabel = stringResource(id = R.string.homePage_CouponService_dialog_label_checkbox),
                onButtonClick = {
                    homeLogic.closeCouponDialogFlag()
                    WebBrowserUtil().setWebUrl(WebConstUtil.WEB_LINK_COUPON_SERVICE)
                },
                callBackButtonClick = {
                    homeLogic.closeCouponDialogFlag()
                }
            )
        }
    }
    if (Config.isRetail()) {
        Row(
            modifier =
            Modifier
                .fillMaxWidth()
                .padding(start = 10.dp, top = 10.dp, end = 10.dp),
        ) {
            CardHorizontalNote(
                modifier = Modifier, title = stringResource(id = R.string.homePage_cardHorizontalNote_iDeCo),
                content = stringResource(id = R.string.homePage_cardHorizontalNote_iDeCo_content),
                imageId = R.drawable.sinamonn,
            ) {
//            WebBrowserUtil().setWebUrl(WebConstUtil.WEB_VIEW_IDECO)
                RouteUtil.navTo(
                    RouteName.WEB_VIEW_PAGE + WebConstUtil.WEB_VIEW_URL_CONST + WebConstUtil.WEB_VIEW_IDECO
                )
            }
        }
    }
    if (Config.isRetail()) {
        Row(
            modifier =
            Modifier
                .fillMaxWidth()
                .padding(start = 10.dp, top = 10.dp, end = 10.dp),
        ) {
            CardHorizontalNote(
                modifier = Modifier, title = stringResource(id = R.string.homePage_bicycleInsurance_title),
                content = stringResource(id = R.string.homePage_bicycleInsurance_content),
                imageId = R.drawable.bicycle,
            ) {
                WebBrowserUtil().setWebUrl(WebConstUtil.WEB_LINK_BICYCLE_INSURANCE)
            }
        }
    }

    Row(
        modifier =
        Modifier
            .fillMaxWidth()
            .padding(start = 10.dp, top = 10.dp, end = 10.dp),
    ) {
        CardHorizontalNote(
            modifier = Modifier, title = stringResource(id = R.string.homePage_cardHorizontalNote_fourth_title),
            content = stringResource(id = R.string.homePage_cardHorizontalNote_fourth_content),
            imageId = R.drawable.reception_info,
        ) {
            PreferenceUtil.setPreferenceBooleanValue(ConstUtil.EASY_RECEPTION_PAGE_HOME, true)
            RouteUtil.navTo(
                RouteName.MBNT0101Page,
                3
            )
        }
    }
}

/**
 * お知らせ
 *
 */
@Composable
fun Notice(homeLogic: HomeLogic) {
    // ステータス
    val state = homeLogic.viewStates
    val announcements = state.announcementsList
    Row(
        modifier =
        Modifier
            .fillMaxWidth()
            .padding(start = 10.dp, top = 30.dp, end = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = stringResource(id = R.string.homePage_label_announcement),
                color = general_label_color,
                fontSize = H4
            )
        }
        Column {
            Icon3rdButton(
                text = stringResource(id = R.string.homePage_button_information_list),
                count = state.dataCount,
                image = R.drawable.right,
                imageSize = 16.dp
            ) {
                RouteUtil.navTo(
                    RouteName.MBNT0101Page,
                    if (IS_ANNOUNCEMENTS_IMPORTANT_FLAG) 0 else 1
                )
            }
        }
    }
    if (announcements.isNotEmpty())
        Row(
            modifier =
            Modifier
                .fillMaxWidth()
                .padding(start = 10.dp, top = 10.dp, end = 10.dp)
                .height(if (announcements.size <= 2) 100.dp * announcements.size else 200.dp),
        ) {
            CardAnnouncementsList(modifier = Modifier, data = announcements, onTap = { index ->
                homeLogic.goDetail(index)
            })
        }
}
/**
 * 新機能
 *
 */
@Composable
fun NewConvenientFunction() {
    val context = LocalContext.current
    Row(
        modifier =
            Modifier
                .fillMaxWidth()
                .padding(start = 10.dp, top = 30.dp, end = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = stringResource(id = R.string.homePage_label_newconvenience_function),
                color = general_label_color,
                fontSize = H4
            )
        }
    }
    if (Config.isRetail()) {
        Row(
            modifier =
                Modifier
                    .fillMaxWidth()
                    .padding(start = 10.dp, top = 10.dp, end = 10.dp),
        ) {
            CardHorizontalNote(
                modifier = Modifier, title = stringResource(id = R.string.homePage_bankpay_title),
                content = stringResource(id = R.string.homePage_bankpay_content),
                imageId = R.drawable.bankpay,
            ) {
//               RouteUtil.navTo(
//                    RouteName.WEB_VIEW_PAGE + WebConstUtil.WEB_VIEW_URL_CONST + WebConstUtil.WEB_VIEW_WALL_PAPER
//                )
                launchBankPay(context)
            }
        }
    }
}
private fun launchBankPay(context: Context) {
//    val packageName = "jp.jpba.bankpay"
    val packageName = "jp.gr.bankpay"
    val pm = context.packageManager
    val intent = pm.getLaunchIntentForPackage(packageName)

    if (intent != null) {
        // アプリがインストールされているので起動
        context.startActivity(intent)
    } else {
        // アプリが未インストールの場合はGoogle Playストアへ誘導
        try {
            context.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName"))
            )
        } catch (e: ActivityNotFoundException) {
            context.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("https://google.com"))
            )
        }
    }
}

/**
 * 便利機能
 *
 */
@Composable
fun ConvenientFunction() {
    Row(
        modifier =
        Modifier
            .fillMaxWidth()
            .padding(start = 10.dp, top = 30.dp, end = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = stringResource(id = R.string.homePage_label_convenience_function),
                color = general_label_color,
                fontSize = H4
            )
        }
    }
    if (Config.isRetail()) {
        Row(
            modifier =
            Modifier
                .fillMaxWidth()
                .padding(start = 10.dp, top = 10.dp, end = 10.dp),
        ) {
            CardHorizontalNote(
                modifier = Modifier, title = stringResource(id = R.string.homePage_cardHorizontalNote_WallPaper),
                content = stringResource(id = R.string.homePage_cardHorizontalNote_WallPaper_content),
                imageId = R.drawable.wallpaper,
            ) {
                RouteUtil.navTo(
                    RouteName.WEB_VIEW_PAGE + WebConstUtil.WEB_VIEW_URL_CONST + WebConstUtil.WEB_VIEW_WALL_PAPER
                )
            }
        }
    }
    if(!Config.isRetail()){
        Row(
            modifier =
            Modifier
                .fillMaxWidth()
                .padding(start = 10.dp, top = 10.dp, end = 10.dp),
        ) {
            CardHorizontalNote(
                modifier = Modifier, title = stringResource(id = R.string.homePage_digitalInvoice_title),
                content = stringResource(id = R.string.homePage_digitalInvoice_content),
                imageId = R.drawable.invoice,
            ) {
                WebBrowserUtil().setWebUrl(WEB_VIEW_DIGITAL_INVOICE)
            }
        }
    }
    Row(
        modifier =
        Modifier
            .fillMaxWidth()
            .padding(start = 10.dp, top = 10.dp, end = 10.dp),
    ) {
        CardHorizontalNote(
            modifier = Modifier, title = stringResource(id = R.string.homePage_label_home),
            content = stringResource(id = R.string.homePage_label_home_content),
            imageId = R.drawable.home_page,
        ) {
            WebBrowserUtil().setWebUrl(HOME_PAGE)
        }
    }
    if (Config.isRetail()) {
        Row(
            modifier =
            Modifier
                .fillMaxWidth()
                .padding(start = 10.dp, top = 10.dp, end = 10.dp),
        ) {
            CardHorizontalNote(
                modifier = Modifier, title = stringResource(id = R.string.homePage_internetBanking_title),
                content = stringResource(id = R.string.homePage_internetBanking_content),
                imageId = R.drawable.internet_banking,
            ) {
                WebBrowserUtil().setWebUrl(WebConstUtil.WEB_VIEW_SHINKIN_IB)
            }
        }
    }
    Row(
        modifier =
        Modifier
            .fillMaxWidth()
            .padding(start = 10.dp, top = 10.dp, end = 10.dp),
    ) {
        CardHorizontalNote(
            modifier = Modifier, title = stringResource(id = R.string.homePage_cardHorizontalNote_3rd_title),
            content = stringResource(id = R.string.homePage_cardHorizontalNote_3rd_content),
            imageId = R.drawable.design,
        ) {
            RouteUtil.navTo(
                RouteName.MBLG0302Page,
                ConstUtil.FROM_MENU
            )
        }
    }
    // 2025/01/20 共同化ためweb通帳切り替え廃止　start
//    if (Config.isRetail()) {
//        Row(
//            modifier =
//            Modifier
//                .fillMaxWidth()
//                .padding(start = 10.dp, top = 10.dp, end = 10.dp),
//        ) {
//            CardHorizontalNote(
//                modifier = Modifier, title = stringResource(id = R.string.homePage_cardHorizontalNote_title),
//                content = stringResource(id = R.string.homePage_cardHorizontalNote_content),
//                imageId = R.drawable.web_passbook,
//            ) {
//                RouteUtil.navTo(
//                    RouteName.MBST1201Page,
//                )
//            }
//        }
//    }
    // 2025/01/20 共同化ためweb通帳切り替え廃止　end
}

/**
 * 定期預金証書一覧
 *
 */
@Composable
fun CertificatesList(data: List<TermDepositDetails>, designType: String?) {
    //Log.i("施策6","CertificatesList")
    val sortData = data.stream().sorted(Comparator.comparing(TermDepositDetails::subNo)).collect(Collectors.toList())
    Row(
        modifier =
        Modifier
            .fillMaxSize()
            .padding(start = 10.dp, top = 5.dp, end = 10.dp)
            .height(130.dp * sortData.size),
    ) {
        LazyColumn(
            modifier =
            Modifier
                .fillMaxSize(),
            state = rememberLazyListState(),
            verticalArrangement = Arrangement.spacedBy(15.dp)
        ) {
            items(count = sortData.size, itemContent = { index ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .click {
                            // 日付フォーマット
                            val param = sortData[index]
                            param.maturityDate = sortData[index].maturityDate.replace(SPLASH, HALF_HYPHEN)
                            param.lotteryDate = sortData[index].lotteryDate.replace(SPLASH, HALF_HYPHEN)
                            param.interestRate = sortData[index].interestRate.replace("%", "")
                            RouteUtil.navTo(
                                RouteName.MBDP0701Page + "/${param.toJson()}"
                            )
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Image(
                        painter =
                        painterResource(
                            id = if (designType == BankbookDesign.JAPANESE_PATTERN_DESIGN.code)
                                R.drawable.certificate
                            else R.drawable.certificate_cinnamole
                        ),
                        modifier = Modifier.fillMaxWidth(),
                        contentDescription = null,
                        contentScale = ContentScale.FillWidth
                    )
                    Column(
                        modifier = Modifier
                            .width(MyApp.SCREEN_WIDTH.dp - 60.dp)
                            .click {
                                // 日付フォーマット
                                val param = sortData[index]
                                param.maturityDate = sortData[index].maturityDate.replace(SPLASH, HALF_HYPHEN)
                                param.lotteryDate = sortData[index].lotteryDate.replace(SPLASH, HALF_HYPHEN)
                                param.interestRate = sortData[index].interestRate.replace("%", "")
                                RouteUtil.navTo(
                                    RouteName.MBDP0701Page + "/${param.toJson()}"
                                )
                            },
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(start = 12.dp, top = 10.dp, end = 10.dp)
                                .fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // 2025/01/28 共同化ため取引明細表示 口座番号を追加　start
                            Text(
                                text = sortData[index].accountNumber,
                                color = general_label_color,
                                fontWeight = FontWeight.Bold,
                                fontSize = H6
                            )
                            if (sortData[index].subNo.isNotBlank() && sortData[index].subNo != "000" ){
                                Text(
                                    text = " " + sortData[index].subNo.takeLast(2),
                                    color = general_label_color,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = H6
                                )
                            }else {
                                Text(
                                    text = "",
                                    color = general_label_color,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = H6
                                )
                            }
                            // 2025/01/28 共同化ため取引明細表示修正　end
                            Text(
                                text = sortData[index].superRegularType,
                                color = general_label_color,
                                fontWeight = FontWeight.Bold,
                                fontSize = H6,
                                modifier = Modifier
                                    .padding(start = 12.dp)
                            )
                        }
                        Row(
                            modifier = Modifier
                                .padding(start = 12.dp, top = 5.dp, end = 10.dp)
                                .fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = stringResource(id = R.string.homePage_label_amount_of_deposit),
                                    fontSize = H7,
                                    color = general_label_color,
                                )
                                Text(
                                    modifier = Modifier
                                        .padding(top = 5.dp),
                                    text = stringResource(id = R.string.homePage_label_due_date),
                                    fontSize = H7,
                                    color = general_label_color,
                                )
                            }
                            Column(
                                horizontalAlignment = Alignment.End
                            ) {
                                Row(
                                    verticalAlignment = Alignment.Bottom
                                ) {
                                    Text(
                                        text = FmtMicrometerUtil.fmtMicrometer(sortData[index].balanceOfLedger),
                                        fontSize = H5,
                                        fontWeight = FontWeight.Bold,
                                        color = general_label_color,
                                    )
                                    Text(
                                        text = stringResource(id = R.string.common_card_label_Yen),
                                        fontSize = H7,
                                        color = general_label_color,
                                    )
                                }
                                Text(
                                    modifier = Modifier
                                        .padding(top = 5.dp),
                                    text = sortData[index].maturityDate.replace(HALF_HYPHEN, ".")
                                        .substring(2, sortData[index].maturityDate.length),
                                    fontSize = H7,
                                    color = general_label_color,
                                    textAlign = TextAlign.End
                                )
                            }
                        }
                    }
                }
            })
        }
    }
}

/**
 * 通知預金証書一覧
 *
 */
@Composable
fun NotifyCertificatesList(
    bankAccountNumber: String,
    branchName: String,
    data: List<NoticeDeposit>,
    designType: String?
) {
    val sortData = data.stream().sorted(Comparator.comparing(NoticeDeposit::subNo)).collect(Collectors.toList())
    Row(
        modifier =
        Modifier
            .fillMaxSize()
            .padding(start = 10.dp, top = 5.dp, end = 10.dp)
            .height(130.dp * sortData.size),
    ) {
        LazyColumn(
            modifier =
            Modifier
                .fillMaxSize(),
            state = rememberLazyListState(),
            verticalArrangement = Arrangement.spacedBy(15.dp),
            content = {
                items(count = sortData.size, itemContent = { index ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .click {
                                val param = sortData[index]
                                param.documentaryEvidenceType = Subject.DEPOSIT_DEPOSIT.code
                                param.accountNumber = bankAccountNumber
                                param.branchName = branchName
                                param.initialContractDate = sortData[index].initialContractDate.replace(HALF_HYPHEN, DOT)
                                param.contractDate = sortData[index].contractDate.replace(HALF_HYPHEN, DOT)
                                RouteUtil.navTo(
                                    RouteName.MBDP1101Page + "/${param.toJson()}"
                                )
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Image(
                            painter = painterResource(
                                id = if (designType == BankbookDesign.JAPANESE_PATTERN_DESIGN.code)
                                    R.drawable.notify_certificate
                                else R.drawable.notify_certificate_cinnamole
                            ),
                            modifier = Modifier,
                            contentDescription = null,
                            contentScale = ContentScale.FillBounds
                        )
                        Column(
                            modifier = Modifier
                                .width(MyApp.SCREEN_WIDTH.dp - 60.dp)
                                .click {
                                    val param = sortData[index]
                                    param.documentaryEvidenceType = Subject.DEPOSIT_DEPOSIT.code
                                    param.accountNumber = bankAccountNumber
                                    param.branchName = branchName
                                    param.initialContractDate = sortData[index].initialContractDate.replace(HALF_HYPHEN, DOT)
                                    param.contractDate = sortData[index].contractDate.replace(HALF_HYPHEN, DOT)
                                    RouteUtil.navTo(
                                        RouteName.MBDP1101Page + "/${param.toJson()}"
                                    )
                                },
                            verticalArrangement = Arrangement.Center,
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Row(
                                modifier = Modifier
                                    .padding(start = 12.dp, top = 1.dp, end = 10.dp)
                                    .fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // 2025/01/28 共同化ため取引明細表示 口座番号を追加　start
                                Text(
                                    text = sortData[index].accountNumber,
                                    color = general_label_color,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = H6
                                )
                                // 通帳式定期の場合
                                if (sortData[index].subNo.isNotBlank() && sortData[index].subNo != "000" ) {
                                    Text(
                                        text = " " + sortData[index].subNo.takeLast(2),
                                        color = general_label_color,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = H6
                                    )
                                }else {
                                    Text(
                                        text = "",
                                        color = general_label_color,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = H6
                                    )
                                }
                                // 2025/01/28 共同化ため取引明細表示 口座番号を追加　end

                                Text(
                                    text = stringResource(id = R.string.homePage_label_deposit_deposit),
                                    color = general_label_color,
                                    fontSize = H6,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier
                                        .padding(start = 12.dp)
                                )
                            }
                            Row(
                                modifier = Modifier
                                    .padding(start = 12.dp, top = 5.dp, end = 10.dp)
                                    .fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = stringResource(id = R.string.homePage_label_amount_of_deposit),
                                        fontSize = H7,
                                        color = general_label_color,
                                    )
                                }
                                Column(
                                    horizontalAlignment = Alignment.End
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.Bottom
                                    ) {
                                        Text(
                                            text = if (sortData[index].fundedBalance.isNotBlank())
                                                FmtMicrometerUtil.fmtMicrometer(
                                                    sortData[index].fundedBalance
                                                ) else "",
                                            fontSize = H5,
                                            fontWeight = FontWeight.Bold,
                                            color = general_label_color,
                                        )
                                        Text(
                                            text = stringResource(id = R.string.common_card_label_Yen),
                                            fontSize = H7,
                                            color = general_label_color,
                                        )
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(15.dp))
                        }
                    }
                })
            }
        )
    }
}

private fun observe(currentBackStackEntry: NavBackStackEntry): String? {
    return currentBackStackEntry.savedStateHandle.getLiveData<String>("refresh").value
}

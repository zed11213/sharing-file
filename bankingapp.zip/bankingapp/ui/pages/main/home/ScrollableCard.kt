package jp.co.jsbank.mb.bankingapp.ui.pages.main.home

import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Card
import androidx.compose.material.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import io.realm.Realm
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.bean.main.home.BalanceInformation
import jp.co.jsbank.mb.bankingapp.logic.main.home.HomeLogic
import jp.co.jsbank.mb.bankingapp.repositories.api.async.LoadStatus
import jp.co.jsbank.mb.bankingapp.repositories.db.common.deleteAll
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.EPassBookMBOP1401
import jp.co.jsbank.mb.bankingapp.system.MyApp
import jp.co.jsbank.mb.bankingapp.system.MyApp.Companion.SCREEN_HEIGHT
import jp.co.jsbank.mb.bankingapp.system.MyApp.Companion.SCREEN_WIDTH
import jp.co.jsbank.mb.bankingapp.system.master.AccountType
import jp.co.jsbank.mb.bankingapp.system.master.BankbookDesign
import jp.co.jsbank.mb.bankingapp.system.master.DissolutionFlag
import jp.co.jsbank.mb.bankingapp.system.master.Subject
import jp.co.jsbank.mb.bankingapp.theme.*
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.BranchButton
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.ImageButton
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.click
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.DETAIL_CLOSE_FLAG
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.TAB_TYPE
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.TOP_CARD_INDEX
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.TOP_CERTIFICATES_FLAG
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.TOP_TO_DETAIL_CARD_INDEX
import jp.co.jsbank.mb.bankingapp.utils.FmtMicrometerUtil
import jp.co.jsbank.mb.bankingapp.utils.PreferenceUtil
import jp.co.jsbank.mb.bankingapp.utils.RouteUtil
import jp.co.jsbank.mb.bankingapp.utils.toJson
import kotlin.math.roundToInt
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

/**
 * スクロール可能なカード
 *
 * @param homePageState トップ画面ステータス
 * @param logic トップ画面ロジック
 * @param state リストステータス
 */
@Composable
fun ScrollableContent(
    homePageState: HomePageState,
    logic: HomeLogic = hiltViewModel(),
    state: LazyListState = rememberLazyListState(),
    homeCoroutineScope: CoroutineScope,
    coordinates: Float,
    scrollState: ScrollState
) {
    //Log.i("ScrollableContent","create")
    val tabType = PreferenceUtil.getPreferenceStringValue(TAB_TYPE)
    //Log.i("ScrollableContent","tabType = $tabType")
    if (!tabType.isNullOrEmpty()) {
        homePageState.tabType = tabType.toInt()
        PreferenceUtil.setPreferenceStringValue(TAB_TYPE, "")
    }
    val topIndex = PreferenceUtil.getPreferenceStringValue(TOP_CARD_INDEX)
    //Log.i("ScrollableContent","topIndex = $topIndex")
    if (!topIndex.isNullOrBlank()) {
        val topCardIndex = if (topIndex == "99") {
            0
        } else {
            topIndex.toInt() + 1
        }
        //Log.i("ScrollableContent","topCardIndex = $topCardIndex")
        PreferenceUtil.setPreferenceStringValue(TOP_CARD_INDEX, "")
        LaunchedEffect(Unit) {
            state.scrollToItem(topCardIndex, -SCREEN_WIDTH / 16)
            logic.slide(homePageState.scrollableAccountShow[topCardIndex], topCardIndex, 0)
        }
    }

    val detailCloseFlag = PreferenceUtil.getPreferenceBooleanValue(DETAIL_CLOSE_FLAG)
    if (detailCloseFlag) {
        val topToDetailIndex = PreferenceUtil.getPreferenceStringValue(TOP_TO_DETAIL_CARD_INDEX)
        if (!topToDetailIndex.isNullOrBlank()) {
            PreferenceUtil.setPreferenceStringValue(TOP_TO_DETAIL_CARD_INDEX, "")
            logic.slide(homePageState.scrollableAccountShow[topToDetailIndex.toInt()], topToDetailIndex.toInt(), 0)
        }
    }
    if (PreferenceUtil.getPreferenceBooleanValue(TOP_CERTIFICATES_FLAG) && coordinates > 0) {
        PreferenceUtil.setPreferenceBooleanValue(TOP_CERTIFICATES_FLAG, false)
        LaunchedEffect(Unit) {
            homeCoroutineScope.launch {
                scrollState.animateScrollTo(
                    coordinates.roundToInt()
                )
            }
        }
    }

    Column {
        Row(
            modifier = Modifier
                .padding(start = 8.dp, end = 8.dp)
                .fillMaxWidth()
        ) {
            val data = homePageState.scrollableAccountShow
            val coroutineScope = rememberCoroutineScope()
            val preItemIndex by remember { mutableStateOf(state.firstVisibleItemIndex) }
            if (state.isScrollInProgress) {
                DisposableEffect(Unit) {
                    onDispose {
                        if (state.firstVisibleItemIndex >= preItemIndex) {
                            if (state.firstVisibleItemScrollOffset > SCREEN_WIDTH * 7 / 8 - 6) {
                                logic.slide(
                                    data[state.firstVisibleItemIndex + 1],
                                    state.firstVisibleItemIndex + 1,
                                    2
                                )
                                coroutineScope.launch {
                                    state.animateScrollToItem(
                                        state.firstVisibleItemIndex + 1,
                                        -SCREEN_WIDTH / 16
                                    )
                                }
                            } else {
                                logic.slide(data[state.firstVisibleItemIndex], state.firstVisibleItemIndex, 2)
                                coroutineScope.launch {
                                    state.animateScrollToItem(state.firstVisibleItemIndex, -SCREEN_WIDTH / 16)
                                }
                            }
                        } else {
                            if (state.firstVisibleItemScrollOffset < SCREEN_WIDTH * 7 / 8 - 6) {
                                logic.slide(
                                    data[state.firstVisibleItemIndex],
                                    state.firstVisibleItemIndex,
                                    1
                                )
                                coroutineScope.launch {
                                    state.animateScrollToItem(
                                        state.firstVisibleItemIndex,
                                        -SCREEN_WIDTH / 16
                                    )
                                }
                            } else {
                                logic.slide(data[state.firstVisibleItemIndex + 1], state.firstVisibleItemIndex + 1, 1)
                                coroutineScope.launch {
                                    state.animateScrollToItem(state.firstVisibleItemIndex + 1, -SCREEN_WIDTH / 16)
                                }
                            }
                        }
                    }
                }
            }
            LazyRow(state = state, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                itemsIndexed(data) { _, it ->
                    SpotifyLaneItem(it, logic, homeCoroutineScope, coordinates, scrollState)
                }
            }
        }
        // 口座情報
        Row(
            modifier =
            Modifier
                .fillMaxWidth()
                .padding(start = 10.dp, top = 10.dp, end = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            val data = homePageState.branchAccount
            AccountList(
                logic,
                data = data
            )
        }
    }
}

@Composable
fun SpotifyLaneItem(
    account: BalanceInformation,
    logic: HomeLogic,
    homeCoroutineScope: CoroutineScope,
    coordinates: Float,
    scrollState: ScrollState
) {
    //Log.i("SpotifyLaneItem","subjectNameCode = ${account.subjectNameCode}")
    //Log.i("SpotifyLaneItem"," account num = ${account.accountNumber}")

    // デザインタイプ
    val designType = PreferenceUtil.getPreferenceStringValue(ConstUtil.DESIGN_TYPE)
    // ロカールDB
    val dbService: Realm = MyApp.INSTANCE
    Column(
        modifier =
        Modifier
            .click(
                onClick = {}
            )
    ) {
        Box(modifier = Modifier) {
            Image(
                painter = painterResource(
                    id = when (account.subjectNameCode) {
                        "1" -> if (designType == BankbookDesign.JAPANESE_PATTERN_DESIGN.code)
                            R.drawable.account_card_comprehensive else R.drawable.account_card_comprehensive_cinnamole
                        Subject.ORDINARY_DEPOSIT.code -> if (designType == BankbookDesign.JAPANESE_PATTERN_DESIGN.code)
                            R.drawable.account_card_usually else R.drawable.account_card_usually_cinnamole
                        Subject.FIXED_SAVINGS.code -> if (designType == BankbookDesign.JAPANESE_PATTERN_DESIGN.code)
                            R.drawable.account_card_regular else R.drawable.account_card_regular_cinnamole
                        Subject.INSTALLMENT.code -> if (designType == BankbookDesign.JAPANESE_PATTERN_DESIGN.code)
                            R.drawable.account_card_deposit else R.drawable.account_card_deposit_cinnamole
                        Subject.CHECKING_ACCOUNT.code -> if (designType == BankbookDesign.JAPANESE_PATTERN_DESIGN.code)
                            R.drawable.account_card_current else R.drawable.account_card_current_cinnamole
                        Subject.DEPOSIT_DEPOSIT.code -> if (designType == BankbookDesign.JAPANESE_PATTERN_DESIGN.code)
                            R.drawable.account_card_notice else R.drawable.account_card_notice_cinnamole
                        else -> if (designType == BankbookDesign.JAPANESE_PATTERN_DESIGN.code)
                            R.drawable.account_card_pay_tax else R.drawable.account_card_pay_tax_cinnamole
                    }
                ),
                modifier = Modifier
                    .width((SCREEN_WIDTH - 40).dp)
                    .click {
                        if (account.subjectNameCode != Subject.FIXED_SAVINGS.code &&
                            account.subjectNameCode != Subject.DEPOSIT_DEPOSIT.code
                        ) {
                            dbService.deleteAll(EPassBookMBOP1401::class.java)
                            // 明細表示ボタンは、リスト表示・通帳表示のどちらか直前で表示したほうを表示する。
                            // 初回はリスト表示。
                            logic.goToDetail(account)
                        } else
                            homeCoroutineScope.launch {
                                scrollState.animateScrollTo(
                                    coordinates.roundToInt()
                                )
                            }
                    },
                contentDescription = null,
                contentScale = ContentScale.FillWidth,
            )
            // 口座情報
            CardAccountInfo(account, designType, logic)
            // 金額情報
            AmountInfo(account, logic, designType)
            if (logic.viewStates.tutorialFlag &&
                !PreferenceUtil.getPreferenceBooleanValue(ConstUtil.PASSBOOK_HELP_FLAG)
            ) {
                Column(
                    modifier = Modifier
                        .padding(top = 75.dp)
                        .width((SCREEN_WIDTH - 40).dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.tutorial),
                        contentDescription = null,
                        contentScale = ContentScale.FillWidth,
                        modifier = Modifier
                            .fillMaxSize()
                            .click { logic.tutorialClick() }
                    )
                }
            } else if (logic.viewStates.tutorial2Flag &&
                !PreferenceUtil.getPreferenceBooleanValue(ConstUtil.PASSBOOK_HELP_FLAG)
            ) {
                Column(
                    modifier = Modifier
                        .padding(top = 170.dp)
                        .width((SCREEN_WIDTH - 40).dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.tutorial_2),
                        contentDescription = null,
                        contentScale = ContentScale.FillWidth,
                        modifier = Modifier
                            .fillMaxSize()
                            .click { logic.tutorial2Click() }
                    )
                }
            }
        }
    }
}

/**
 * 口座情報
 *
 * @param account 口座情報
 * @param designType デザインタイプ
 * @param logic ロジック
 */
@Composable
fun CardAccountInfo(account: BalanceInformation, designType: String?, logic: HomeLogic) {
    Card(
        modifier = Modifier
            .padding(start = 1.dp, top = (10 * SCREEN_HEIGHT / SCREEN_WIDTH).dp)
            .width((SCREEN_WIDTH - 42).dp),
        backgroundColor = if (account.subjectNameCode == Subject.DEPOSIT_DEPOSIT.code ||
            account.subjectNameCode == Subject.FIXED_SAVINGS.code || designType == BankbookDesign.CINNAMOLE_DESIGN.code
        )
            Color.Transparent else Color.White,
        shape = RoundedCornerShape(0),
        elevation = 0.dp
    ) {
        Row {
            Column(
                modifier = Modifier
                    .padding(start = 10.dp, top = 6.dp, bottom = 6.dp)
                    .weight(0.35f),
            ) {
                Text(
                    text = stringResource(id = R.string.scrollableCard_label_subjects),
                    fontSize = H7,
                    color = if (Subject.FIXED_SAVINGS.code == account.subjectNameCode ||
                        Subject.DEPOSIT_DEPOSIT.code == account.subjectNameCode
                    ) account_detail_label_color else account_card_label_color,
                )
                Text(
                    modifier = Modifier
                        .padding(top = 6.dp),
                    text = account.subjectNameValue,
                    fontSize = H7,
                    color = general_label_color,
                )
            }
            Column(
                modifier = Modifier
                    .padding(top = 6.dp, bottom = 6.dp, start = 0.dp)
                    .weight(0.43f),
            ) {
                Text(
                    text = stringResource(id = R.string.scrollableCard_label_branch_name),
                    fontSize = H7,
                    color = if (Subject.FIXED_SAVINGS.code == account.subjectNameCode ||
                        Subject.DEPOSIT_DEPOSIT.code == account.subjectNameCode
                    ) account_detail_label_color else account_card_label_color,
                )
                Text(
                    modifier = Modifier
                        .padding(top = 6.dp),
                    text = account.branchName.replace(stringResource(id = R.string.mbdr1101_page_label_branch), ""),
                    fontSize = H7,
                    color = general_label_color,
                )
            }
            Column(
                modifier = Modifier
                    .padding(top = 6.dp, bottom = 6.dp, start = 0.dp)
                    .weight(0.10f),
            ) {
                Text(
                    text = stringResource(id = R.string.scrollableCard_label_shop),
                    fontSize = H7,
                    color = if (Subject.FIXED_SAVINGS.code == account.subjectNameCode ||
                        Subject.DEPOSIT_DEPOSIT.code == account.subjectNameCode
                    ) account_detail_label_color else account_card_label_color,
                )
                Text(
                    modifier = Modifier
                        .padding(top = 6.dp),
                    text = account.branchNumber,
                    fontSize = H7,
                    color = general_label_color,
                )
            }
            Column(
                modifier = Modifier
                    .padding(top = 6.dp, bottom = 6.dp, start = 10.dp)
                    .weight(0.26f),
            ) {
                Text(
                    text = stringResource(id = R.string.scrollableCard_label_account_number),
                    fontSize = H7,
                    color = if (Subject.FIXED_SAVINGS.code == account.subjectNameCode ||
                        Subject.DEPOSIT_DEPOSIT.code == account.subjectNameCode
                    ) account_detail_label_color else account_card_label_color,
                )
                Text(
                    modifier = Modifier
                        .padding(top = 6.dp),
                    text = if(logic.viewStates.type == 1 &&
                        ((logic.viewStates.tabType == 1 && account.linkedAccountType == AccountType.FIXED_SAVINGS.code)
                            ||((logic.viewStates.tabType == 0 && account.linkedAccountType == AccountType.ORDINARY_DEPOSIT.code))))
                            account.linkedAccountNumber else account.accountNumber,
                    fontSize = H7,
                    color = general_label_color,
                )
            }
        }
    }
}

/**
 * 金額情報
 *
 */
@Composable
fun AmountInfo(
    account: BalanceInformation,
    logic: HomeLogic,
    designType: String?
) {
    val dp =
        if (designType == BankbookDesign.JAPANESE_PATTERN_DESIGN.code) {
            if ((SCREEN_HEIGHT.toFloat()) < 600) {
                0.175
            } else if (600 < (SCREEN_HEIGHT.toFloat()) && (SCREEN_HEIGHT.toFloat()) < 700) {
                0.154
            } else {
                0.156
            }
        } else {
            if ((SCREEN_HEIGHT.toFloat()) < 600) {
                0.175
            } else if (600 < (SCREEN_HEIGHT.toFloat()) && (SCREEN_HEIGHT.toFloat()) < 700) {
                0.155
            } else {
                0.16
            }
        }
    //Log.i("acc", "BalanceInformation =  ${account.toJson()}")
    Column(
        modifier = Modifier
            .padding(start = 15.dp, top = ((SCREEN_HEIGHT) * dp).dp)
            .width((SCREEN_WIDTH - 55).dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {

            if (account.subjectNameCode == "1" && account.regularBalance.isNotBlank())
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(100))
                        .background(general_account_tab_background_color)
                        .align(Alignment.CenterVertically)
                        .wrapContentSize()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(100))
                                .background(
                                    if (logic.viewStates.tabType == 0) Color.White else Color.Transparent
                                )
                                .wrapContentSize()
                                .click { logic.tabSwitching(0) }
                        ) {
                            Text(
                                color = when {
                                    logic.viewStates.tabType == 0 -> prominent_label_color
                                    designType == BankbookDesign.CINNAMOLE_DESIGN.code -> Color.Black
                                    else -> Color.White
                                },
                                text = stringResource(id = R.string.scrollableCard_label_local),
                                fontSize = H6,
                                modifier = Modifier
                                    .align(Alignment.Center)
                                    .padding(horizontal = 10.dp, vertical = 1.dp),
                            )
                        }
                        if (account.subjectNameCode == Subject.COMPREHENSIVE_ACCOUNT.code && account.linkedAccountType.isNotEmpty()){
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(100))
                                    .background(
                                        if (logic.viewStates.tabType == 1) Color.White else Color.Transparent
                                    )
                                    .wrapContentSize()
                                    .click { logic.tabSwitching(1) }
                            ) {
                                Text(
                                    color = when {
                                        logic.viewStates.tabType == 1 -> prominent_label_color
                                        designType == BankbookDesign.CINNAMOLE_DESIGN.code -> Color.Black
                                        else -> Color.White
                                    },
                                    text = stringResource(id = R.string.scrollableCard_label_periodic),
                                    fontSize = H6,
                                    modifier = Modifier
                                        .align(Alignment.Center)
                                        .padding(horizontal = 10.dp, vertical = 1.dp),
                                )
                            }
                        }
                    }
                }
            else
                Text(
                    text = stringResource(id = R.string.scrollableCard_label_amount_indication),
                    fontSize = H7,
                    color = if (account.subjectNameCode == Subject.CHECKING_ACCOUNT.code ||
                        account.subjectNameCode == Subject.FIXED_SAVINGS.code ||
                        account.subjectNameCode == Subject.DEPOSIT_DEPOSIT.code ||
                        designType == BankbookDesign.CINNAMOLE_DESIGN.code
                    ) Color.Black else Color.White
                )
            if (logic.viewStates.showFlag)
                Image(
                    modifier = Modifier
                        .padding(start = 5.dp)
                        .click {
                            logic.viewChange(logic.viewStates.showFlag)
                        },
                    contentScale = ContentScale.Fit,
                    painter = painterResource(
                        id = if (account.subjectNameCode == Subject.CHECKING_ACCOUNT.code ||
                            account.subjectNameCode == Subject.FIXED_SAVINGS.code ||
                            account.subjectNameCode == Subject.DEPOSIT_DEPOSIT.code ||
                            designType == BankbookDesign.CINNAMOLE_DESIGN.code
                        ) R.drawable.black_view else R.drawable.view
                    ),
                    contentDescription = ""
                )
            else
                Image(
                    modifier = Modifier
                        .padding(start = 5.dp)
                        .click {
                            logic.viewChange(logic.viewStates.showFlag)
                        },
                    contentScale = ContentScale.Fit,
                    painter = painterResource(
                        id = if (account.subjectNameCode == Subject.CHECKING_ACCOUNT.code ||
                            account.subjectNameCode == Subject.FIXED_SAVINGS.code ||
                            account.subjectNameCode == Subject.DEPOSIT_DEPOSIT.code ||
                            designType == BankbookDesign.CINNAMOLE_DESIGN.code
                        ) R.drawable.black_close_view else R.drawable.close_view
                    ),
                    contentDescription = ""
                )
        }
        Row(
            verticalAlignment = Alignment.Bottom,
            modifier = Modifier.padding(top = 20.dp)
        ) {
            if (logic.viewStates.showFlag)
            // 金額フォーマット表示
                Text(
                    text = if (account.dissolutionFlg == DissolutionFlag.VALIDATE.code) {
                        FmtMicrometerUtil.fmtMicrometer(if(logic.viewStates.type == 1 &&
                            ((logic.viewStates.tabType == 1 && account.linkedAccountType == AccountType.FIXED_SAVINGS.code)
                                ||((logic.viewStates.tabType == 0 && account.linkedAccountType == AccountType.ORDINARY_DEPOSIT.code))))
                                account.regularBalance else account.balance)
                    } else {
                        stringResource(id = R.string.common_label_canceled)
                    },
                    fontSize = 24.sp,
                    color =
                    if (account.subjectNameCode == Subject.CHECKING_ACCOUNT.code ||
                        account.subjectNameCode == Subject.FIXED_SAVINGS.code ||
                        account.subjectNameCode == Subject.DEPOSIT_DEPOSIT.code ||
                        designType == BankbookDesign.CINNAMOLE_DESIGN.code
                    ) Color.Black else Color.White
                ) else
                Text(
                    text = "–,–––,–––",
                    fontSize = 24.sp,
                    color =
                    if (account.subjectNameCode == Subject.CHECKING_ACCOUNT.code ||
                        account.subjectNameCode == Subject.FIXED_SAVINGS.code ||
                        account.subjectNameCode == Subject.DEPOSIT_DEPOSIT.code ||
                        designType == BankbookDesign.CINNAMOLE_DESIGN.code
                    ) Color.Black else Color.White
                )
            Text(
                text = stringResource(id = R.string.common_card_label_Yen),
                fontSize = H7,
                color =
                if (account.subjectNameCode == Subject.CHECKING_ACCOUNT.code ||
                    account.subjectNameCode == Subject.FIXED_SAVINGS.code ||
                    account.subjectNameCode == Subject.DEPOSIT_DEPOSIT.code ||
                    designType == BankbookDesign.CINNAMOLE_DESIGN.code
                ) Color.Black else Color.White,
                modifier = Modifier.padding(start = 10.dp),
            )
        }
    }
}

/**
 * 口座情報
 *
 */
@Composable
fun AccountList(logic: HomeLogic, data: List<BalanceInformation>) {
    //Log.i("AccountList","data =  ${data.size}")
    // 利用者flag
    val userFlag = PreferenceUtil.getPreferenceStringValue(ConstUtil.USER)
    var newData = data
    //Log.i("AccountList","tabType= ${logic.viewStates.tabType } type = ${logic.viewStates.type} data =  ${data.size}")
    data.forEach {
        //Log.i("acc"," d  subjectNameCode = ${it.subjectNameCode}")
        //Log.i("acc"," d  accountNumber = ${it.accountNumber}")
        //Log.i("acc"," d  accountType = ${it.accountType}")
        //Log.i("acc"," d  fundingBalance = ${it.fundingBalance}")
        //Log.i("acc"," d  linkedAccountType = ${it.linkedAccountType}")
        //Log.i("acc"," d  linkedAccountNumber = ${it.linkedAccountNumber}")
    }
    if (logic.viewStates.type == 1){
        newData = if (logic.viewStates.tabType == 1) {
                data.filter{ it.accountType == AccountType.FIXED_SAVINGS.code }

            } else {
                data.filter { it.accountType == AccountType.ORDINARY_DEPOSIT.code }
            }
        if(!newData.any { it.topSelected}){
            newData.first().topSelected = true
        }
    }

    Column {
        LazyRow(
            modifier =
            Modifier
                .fillMaxSize(),
            state = rememberLazyListState(initialFirstVisibleItemIndex = logic.viewStates.scrollState),
            content = {
                items(count = newData.size, itemContent = { index ->
                    Column(
                        modifier = Modifier
                            .padding(start = 5.dp)
                    ) {
                        BranchButton(
                            text = newData[index].branchName + " " + newData[index].accountNumber,
                            textColor =
                            if (newData[index].topSelected) {
                                text_color
                            } else {
                                when (logic.viewStates.type) {
                                    1 -> general_account_switching_button_label_color
                                    2 -> ordinary_deposit_switching_button_label_color
                                    3 -> periodic_deposit_switching_button_label_color
                                    4 -> mpf_switching_button_label_color
                                    5 -> current_account_switching_button_label_color
                                    6 -> notification_deposit_switching_button_label_color
                                    else -> tax_reserve_deposit_switching_button_label_color
                                }
                            },
                            backgroundColor =
                            if (newData[index].topSelected) {
                                when (logic.viewStates.type) {
                                    1 -> selected_general_account_switching_button_background_color
                                    2 -> selected_ordinary_deposit_switching_button_background_color
                                    3 -> selected_periodic_deposit_switching_button_background_color
                                    4 -> selected_mpf_switching_button_background_color
                                    5 -> selected_current_account_switching_button_background_color
                                    6 -> selected_notification_deposit_switching_button_background_color
                                    else -> selected_tax_reserve_deposit_switching_button_background_color
                                }
                            } else {
                                when (logic.viewStates.type) {
                                    1 -> general_account_switching_button_background_color
                                    2 -> ordinary_deposit_switching_button_background_color
                                    3 -> periodic_deposit_switching_button_background_color
                                    4 -> mpf_switching_button_background_color
                                    5 -> current_account_switching_button_background_color
                                    6 -> notification_deposit_switching_button_background_color
                                    else -> tax_reserve_deposit_switching_button_background_color
                                }
                            }
                        ) {
                            logic.switchBranch(logic.viewStates.index, index, newData[index])
                        }
                    }
                    if ((userFlag != ConstUtil.USER_NO_DONE && userFlag != ConstUtil.USER_DONE)) {
                        if (index == newData.size - 1){
                            Column(modifier = Modifier.padding(start = 5.dp)) {
                                ImageButton(
                                    image =
                                    when (logic.viewStates.type) {
                                        1 -> R.drawable.comprehensive_plus
                                        2 -> R.drawable.usually_plus
                                        3 -> R.drawable.regular_plus
                                        4 -> R.drawable.deposit_plus
                                        5 -> R.drawable.current_plus
                                        6 -> R.drawable.notice_plus
                                        else -> R.drawable.pay_tax_plus
                                    },
                                    backgroundColor =
                                    when (logic.viewStates.type) {
                                        1 -> general_account_switching_button_background_color
                                        2 -> ordinary_deposit_switching_button_background_color
                                        3 -> periodic_deposit_switching_button_background_color
                                        4 -> mpf_switching_button_background_color
                                        5 -> current_account_switching_button_background_color
                                        6 -> notification_deposit_switching_button_background_color
                                        else -> tax_reserve_deposit_switching_button_background_color
                                    },
                                    imageSize = 20.dp
                                ) {
                                    RouteUtil.navTo(RouteName.MBST0801Page)
                                }
                            }
                        }
                    }
                })
            }
        )
    }
}

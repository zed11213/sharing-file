package jp.co.jsbank.mb.bankingapp.ui.pages.main.home

sealed class CertificateLoadState<out T> {
    object Idle : CertificateLoadState<Nothing>()
    object Loading : CertificateLoadState<Nothing>()
    data class Loaded<T>(val data:T) : CertificateLoadState<T>()
    data class Error(val error: Throwable) : CertificateLoadState<Nothing>()
}

package jp.co.jsbank.mb.bankingapp.ui.pages.main.home

data class NoticeCertificateState (
    val account:String,
    val isLoading: Boolean = false,
    var complete: Boolean = false,
    val error:String? = null
)

package jp.co.jsbank.mb.bankingapp.ui.pages.main.home

import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.runtime.mutableStateMapOf
import jp.co.jsbank.mb.bankingapp.bean.login.mblg.mblg0201.NoticeDeposit
import jp.co.jsbank.mb.bankingapp.bean.main.home.BalanceInformation
import jp.co.jsbank.mb.bankingapp.bean.main.home.mbdp.mbdp0301.TermDepositDetails
import jp.co.jsbank.mb.bankingapp.bean.main.home.mbnt.mbnt0101.Anncmnt
import jp.co.jsbank.mb.bankingapp.bean.main.menu.mbst.mbst1201.MBST1201Bean
import jp.co.jsbank.mb.bankingapp.repositories.api.async.LoadStatus

/**
 * トップステータス.
 */
data class HomePageState(

    /**
     * すべて口座.
     */
    var allAccount: MutableList<BalanceInformation> = mutableListOf(),

    /**
     * スクロール可能な口座.
     */
    var scrollableAccount: MutableList<BalanceInformation> = mutableListOf(),

    /**
     * スクロール可能な口座（表示用）.
     */
    var scrollableAccountShow: MutableList<BalanceInformation> = mutableListOf(),

    /**
     * ブランチ口座.
     */
    var branchAccount: MutableList<BalanceInformation> = mutableListOf(),

    /**
     * 定期預金の証書一覧.
     */
    var regularDepositList: MutableList<TermDepositDetails> = mutableListOf(),

    /**
     * 渡すパラメータ.
     */
    var data: MBST1201Bean = MBST1201Bean(),

    /**
     * 通知預金の証書一覧.
     */
    var notificationDeposit: MutableList<NoticeDeposit> = mutableListOf(),

    /**
     * お知らせ一覧.
     */
    var noticeList: MutableList<Anncmnt> = mutableListOf(),

    /**
     * 更新時間.
     */
    var updateTime: String = "",

    /**
     * お知らせ.
     */
    var announcementsList: MutableList<Anncmnt> = mutableListOf(),

    /**
     * お知らせ件数.
     */
    var dataCount: Int = 0,

    var type: Int = 1,

    var index: Int = 0,

    var showFlag: Boolean = true,

    var tabType: Int = 0,

    var tutorialFlag: Boolean = true,

    var tutorial2Flag: Boolean = false,

    val indexState: LazyListState = LazyListState(),

    /**
     * エラーメッセージ内容
     */
    var errorMessage: String = "",

    /**
     * 前回ログイン時間.
     */
    var lastLoginTime: String = "",

    var slideIndex: Int = 0,

    /**
     * ログアウトダイアログ
     */
    var logoutDialogFlag: Boolean = false,

    /**
     * クーポン留意事項ダイアログ
     */
    var couponDialogFlag: Boolean = false,

    /**
     * 児童手当キャンペーン
     */
    var childAllowanceCampaignList: MutableList<Anncmnt> = mutableListOf(),

    /**
     * 口座情報のscroll
     */
    var scrollState: Int = 0,

    val termCertificateStates:List<TermCertificateState> = emptyList(),
    val noticeCertificateStates:List<NoticeCertificateState> = emptyList()
)

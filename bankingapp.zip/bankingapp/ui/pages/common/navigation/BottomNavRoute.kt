package jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation

import androidx.annotation.StringRes
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Person
import androidx.compose.ui.graphics.vector.ImageVector
import jp.co.jsbank.mb.bankingapp.R

/**
 * コンストラクタ.
 *
 * @param routeName ルート名称
 * @param stringId ルートId
 * @param icon アイコン
 */
sealed class BottomNavRoute(
    var routeName: String,
    @StringRes var stringId: Int,
    var icon: ImageVector
) {
    object Home : BottomNavRoute(RouteName.HOME, R.string.home, Icons.Default.Home)
    object Balance : BottomNavRoute(RouteName.BALANCE, R.string.balance, Icons.Default.Menu)
    object Help : BottomNavRoute(RouteName.HELP, R.string.help, Icons.Default.Favorite)
    object Menu : BottomNavRoute(RouteName.MENU, R.string.menu, Icons.Default.Person)
}

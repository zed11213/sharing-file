package jp.co.jsbank.mb.bankingapp.ui.pages.common

import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.padding
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavType
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.navArgument
import com.google.accompanist.insets.navigationBarsPadding
import com.google.accompanist.insets.statusBarsPadding
import com.google.accompanist.navigation.animation.AnimatedNavHost
import com.google.accompanist.navigation.animation.composable
import com.google.accompanist.navigation.animation.rememberAnimatedNavController
import com.google.accompanist.pager.ExperimentalPagerApi
import jp.co.jsbank.mb.bankingapp.repositories.db.common.findAll
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.EPassBookAB0701
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.system.MainActivity.Companion.BOTTOMBAR_ID
import jp.co.jsbank.mb.bankingapp.system.MainActivity.Companion.IS_EKYC_SHOOT_AGAIN_FLAG
import jp.co.jsbank.mb.bankingapp.system.MainActivity.Companion.NAVCTRL
import jp.co.jsbank.mb.bankingapp.system.MainActivity.Companion.PASSWORD_TO_HELP_FLAG
import jp.co.jsbank.mb.bankingapp.system.MainActivity.Companion.RECOVERY_API_ERROR_FLAG
import jp.co.jsbank.mb.bankingapp.system.MainActivity.Companion.RECOVERY_ID
import jp.co.jsbank.mb.bankingapp.system.MyApp
import jp.co.jsbank.mb.bankingapp.system.master.BottomBarShowScreenId.Companion.getBottomBarShowScreenId
import jp.co.jsbank.mb.bankingapp.system.master.PersonalityFlag
import jp.co.jsbank.mb.bankingapp.system.master.RestoreRoute
import jp.co.jsbank.mb.bankingapp.system.master.RestoreRoute.Companion.getRestoreRouteName
import jp.co.jsbank.mb.bankingapp.ui.pages.cashCard.mbcc.mbcc0101.MBCC0101Page
import jp.co.jsbank.mb.bankingapp.ui.pages.cashCard.mbcc.mbcc0102.MBCC0102Page
import jp.co.jsbank.mb.bankingapp.ui.pages.cashCard.mbcc.mbcc0103.MBCC0103Page
import jp.co.jsbank.mb.bankingapp.ui.pages.cashCard.mbcc.mbcc0201.MBCC0201Page
import jp.co.jsbank.mb.bankingapp.ui.pages.cashCard.mbcc.mbcc0301.MBCC0301Page
import jp.co.jsbank.mb.bankingapp.ui.pages.cashCard.mbcc.mbcc0401.MBCC0401Page
import jp.co.jsbank.mb.bankingapp.ui.pages.cashCard.mbcc.mbcc0501.MBCC0501Page
import jp.co.jsbank.mb.bankingapp.ui.pages.cashCard.mbcc.mbcc0901.MBCC0901Page
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mblg.mblg0101.MBLG0101Page
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mblg.mblg0201.MBLG0201Page
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mblg.mblg0301.MBLG0301Page
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mblg.mblg0302.MBLG0302Page
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mblg.mblg0303.MBLG0303Page
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mblg.mblg0304.MBLG0304Page
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mblg.mblg0305.MBLG0305Page
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mblg.mblg0306.MBLG0306Page
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mblg.mblg0601.MBLG0601Page
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mblg.mblg1001.MBLG1001Page
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mblg.mblg2002.MBLG2002Page
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mbsu.mbsu0101.MBSU0101Page
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mbsu.mbsu0102.MBSU0102Page
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mbsu.mbsu0103.MBSU0103Page
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mbsu.mbsu0105.MBSU0105Page
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mbsu.mbsu0106.MBSU0106Page
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mbsu.mbsu0201.MBSU0201Page
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mbsu.mbsu0202.MBSU0202Page
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mbsu.mbsu0301.MBSU0301Page
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mbsu.mbsu0302.MBSU0302Page
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mbsu.mbsu0303.MBSU0303Page
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mbsu.mbsu0304.MBSU0304Page
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mbsu.mbsu0305.MBSU0305Page
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mbsu.mbsu0306.MBSU0306Page
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mbsu.mbsu0307.MBSU0307Page
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mbsu.mbsu0308.MBSU0308Page
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mbsu.mbsu0309.MBSU0309Page
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mbsu.mbsu0401.MBSU0401Page
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mbsu.mbsu0501.MBSU0501Page
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mbsu.mbsu0502.MBSU0502Page
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mbsu.mbsu0601.MBSU0601Page
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mbsu.mbsu0602.MBSU0602Page
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mbsu.mbsu2001.MBSU2001Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.balance.BalancePage
import jp.co.jsbank.mb.bankingapp.ui.pages.main.help.HelpPage
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.HomePage
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.mbdp.mbdp0101.MBDP0101Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.mbdp.mbdp0201.MBDP0201Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.mbdp.mbdp0201.MBDP0201TablePage
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.mbdp.mbdp0301.MBDP0301Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.mbdp.mbdp0301.MBDP0301TablePage
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.mbdp.mbdp0401.MBDP0401Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.mbdp.mbdp0401.MBDP0401TablePage
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.mbdp.mbdp0501.MBDP0501Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.mbdp.mbdp0501.MBDP0501TablePage
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.mbdp.mbdp0701.MBDP0701Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.mbdp.mbdp0901.MBDP0901Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.mbdp.mbdp1101.MBDP1101Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.mbdp.mbdp1301.MBDP1301Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.mbdp.mbdp1401.MBDP1401Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.mbdr.mbdr0101.MBDR0101Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.mbdr.mbdr0201.MBDR0201Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.mbdr.mbdr0301.MBDR0301Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.mbdr.mbdr0401.MBDR0401Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.mbdr.mbdr0501.MBDR0501Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.mbdr.mbdr0601.MBDR0601Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.mbdr.mbdr0701.MBDR0701Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.mbdr.mbdr0801.MBDR0801Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.mbdr.mbdr0901.MBDR0901Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.mbdr.mbdr1001.MBDR1001Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.mbdr.mbdr1101.MBDR1101Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.mbdr.mbdr1201.MBDR1201Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.mbdr.mbdr1301.MBDR1301Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.mbdr.mbdr1401.MBDR1401Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.mbdr.mbdr1501.MBDR1501Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.mbdr.mbdr1601.MBDR1601Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.mbdr.mbdr1701.MBDR1701Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.mbdr.mbdr1801.MBDR1801Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.mbdr.mbdr1901.MBDR1901Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.mbdr.mbdr2101.MBDR2101Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.mblg.mblg0501.MBLG0501Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.mblg.mblg0502.MBLG0502Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.mblg.mblg0505.MBLG0505Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.mblg.mblg0507.MBLG0507Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.mbnt.mbnt0101.MBNT0101Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.mbnt.mbnt0201.MBNT0201Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.mbrc.mbrc0101.MBRC0101Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.mbrc.mbrc0201.MBRC0201Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.mbrc.mbrc0202.MBRC0202Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.mbrc.mbrc0204.MBRC0204Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.mbrc.mbrc0301.MBRC0301Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.menu.MenuPage
import jp.co.jsbank.mb.bankingapp.ui.pages.main.menu.mbst.mbst0101.MBST0101Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.menu.mbst.mbst0301.MBST0301ConfirmPage
import jp.co.jsbank.mb.bankingapp.ui.pages.main.menu.mbst.mbst0301.MBST0301NewPage
import jp.co.jsbank.mb.bankingapp.ui.pages.main.menu.mbst.mbst0301.MBST0301Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.menu.mbst.mbst0401.MBST0401Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.menu.mbst.mbst0402.MBST0402Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.menu.mbst.mbst0501.MBST0501Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.menu.mbst.mbst0502.MBST0502Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.menu.mbst.mbst0503.MBST0503Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.menu.mbst.mbst0601.MBST0601Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.menu.mbst.mbst0801.MBST0801Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.menu.mbst.mbst0802.MBST0802Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.menu.mbst.mbst0901.MBST0901Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.menu.mbst.mbst0903.MBST0903Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.menu.mbst.mbst0904.MBST0904Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.menu.mbst.mbst1101.MBST1101Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.menu.mbst.mbst1201.MBST1201Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.menu.mbst.mbst1501.MBST1501Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.menu.mbst.mbst1601.MBST1601Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.menu.mbst.mbst1701.MBST1701Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.menu.mbst.mbst1801.MBST1801Page
import jp.co.jsbank.mb.bankingapp.ui.pages.main.menu.mbst.mbst1901.MBST1901Page
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbco.mbco0201.MBCO0201Page
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbco.mbco0202.MBCO0202Page
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbco.mbco0301.MBCO0301Page
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbco.mbco0302.MBCO0302Page
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbco.mbco0401.MBCO0401Page
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbco.mbco0402.MBCO0402Page
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbco.mbco0403.MBCO0403Page
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbco.mbco0404.MBCO0404Page
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbco.mbco0405.MBCO0405Page
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbco.mbco0501.MBCO0501Page
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbco.mbco0601.MBCO0601Page
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0101.MBOP0101Page
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0102.MBOP0102Page
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0103.MBOP0103Page
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0201.MBOP0201Page
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0202.MBOP0202Page
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0203.MBOP0203Page
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0301.MBOP0301Page
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0401.MBOP0401Page
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0601.MBOP0601Page
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0602.MBOP0602Page
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0603.MBOP0603Page
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0604.MBOP0604Page
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0605.MBOP0605Page
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0606.MBOP0606Page
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0607.MBOP0607Page
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0608.MBOP0608Page
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0609.MBOP0609Page
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0610.MBOP0610Page
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0611.MBOP0611Page
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0612.MBOP0612Page
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0613.MBOP0613Page
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0701.MBOP0701Page
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0702.MBOP0702Page
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0703.MBOP0703Page
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0704.MBOP0704Page
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0705.MBOP0705Page
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0706.MBOP0706Page
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop1001.MBOP1001Page
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop1002.MBOP1002Page
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop1003.MBOP1003Page
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop1201.MBOP1201Page
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop1401.MBOP1401Page
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop1501.MBOP1501Page
import jp.co.jsbank.mb.bankingapp.ui.widgets.bottomNavBar.BottomNavBar
import jp.co.jsbank.mb.bankingapp.ui.widgets.webview.WebView
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.ACTIVITY_FLAG_NO_ACCESS_NO_LOGIN
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.ALTERNATE_FLG
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.ANNCMNT_ID
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.ANNCMNT_TYPE
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.APPLY_ID
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.CONFIRM_FLG
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.DATA
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.DATA_LIST
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.DOCUMENT_TYPE
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.INPUT_DATA
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.PARAM_1
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.PARAM_2
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.PARAM_3
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.PARAM_4
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.PARAM_5
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.PARAM_6
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.PARAM_7
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.READ_FLAG
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.STORE
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.TYPE
import jp.co.jsbank.mb.bankingapp.utils.PreferenceUtil

@OptIn(ExperimentalComposeUiApi::class, androidx.compose.animation.ExperimentalAnimationApi::class)
@ExperimentalPagerApi
@RequiresApi(Build.VERSION_CODES.O)
@Composable
fun AppScaffold() {
    NAVCTRL = rememberAnimatedNavController()
    val navBackStackEntry by NAVCTRL!!.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination

    // BottomBarIdをローカルに保存する
    when (currentDestination?.route.toString()) {
        RouteName.HOME -> {
            BOTTOMBAR_ID = RouteName.HOME
        }
        RouteName.BALANCE -> {
            BOTTOMBAR_ID = RouteName.BALANCE
        }
        RouteName.HELP -> {
            BOTTOMBAR_ID = RouteName.HELP
        }
        RouteName.MENU -> {
            BOTTOMBAR_ID = RouteName.MENU
        }
        else -> {
            BOTTOMBAR_ID = BOTTOMBAR_ID
        }
    }
    val activityFlag = PreferenceUtil.getPreferenceStringValue(
        ConstUtil.ACTIVITY_FLAG
    ) == ConstUtil.ACTIVITY_FLAG_ACCESS_LOGIN

    // 画面別BottomBar表示フラグ取得
    val isShowBottomBar: Boolean = when (getBottomBarShowScreenId(currentDestination?.route.toString())) {
        "" -> {
            false
        }
        RouteName.MBRC0101Page, RouteName.MBRC0201Page, RouteName.MBRC0202Page,
        RouteName.MBRC0204Page, RouteName.MBRC0301Page -> {
            activityFlag
        }
        RouteName.HELP -> { !PASSWORD_TO_HELP_FLAG }
        else -> {
            true
        }
    }

    // 復元画面を取得
    fun getRecoveryScreenRouteName(): String {
        val screenId = getRestoreRouteName(RECOVERY_ID)
        Log.d("Recovery", "RECOVERY_ID=$RECOVERY_ID, screenId=$screenId")
        return when (screenId) {
            RouteName.MBCO0202Page -> {
                RouteName.MBCO0201Page + "/{data}"
            }
            RouteName.MBCO0302Page -> {
                RouteName.MBCO0301Page + "/{data}"
            }
            RouteName.MBOP0703Page, RouteName.MBOP0705Page -> {
                RouteName.MBOP0701Page
            }
            RouteName.MBCO0401Page, RouteName.MBCO0501Page, RouteName.MBCO0601Page -> {
                RouteName.MBOP0401Page
            }
            RouteName.MBOP0602Page -> {
                RouteName.MBOP0602Page
            }
            RouteName.MBOP0608Page -> {
                RouteName.MBOP0608Page + "/{data}"
            }
            RouteName.MBOP0609Page -> {
                RouteName.MBOP0609Page + "/{data}"
            }
            RouteName.MBOP0604Page -> {
                RouteName.MBOP0604Page
            }
            RouteName.MBOP0605Page -> {
                RouteName.MBOP0605Page
            }
            RouteName.MBOP0607Page -> {
                RouteName.MBOP0607Page + "/{data}"
            }
            // 読取結果画面の次画面へ回復
            RouteName.MBCO0405Page -> {
                val recoveryInfo = MyApp.INSTANCE.findAll(EPassBookAB0701::class.java)
                if (recoveryInfo.isNotEmpty()) {
                    Log.d("Recovery", "personType=${recoveryInfo[0]?.personType}, screenId=${recoveryInfo[0]?.screenId}")
                    when (recoveryInfo[0]?.personType) {
                        // 法人の場合、本人確認 - 1.書類アップロード（法人）へ遷移する
                        PersonalityFlag.CORPORATION.code -> {
                            RECOVERY_ID = RestoreRoute.RESTORE_MBOP1401.code
                            RouteName.MBOP1401Page
                        }
                        // 個人事業主の場合、MBOP0203　ガイド（情報入力）
                        PersonalityFlag.INDIVIDUAL_BUSINESS.code -> {
                            RECOVERY_ID = RestoreRoute.RESTORE_MBOP0203.code
                            RouteName.MBOP0203Page
                        }
                        // 個人の場合、MBOP0203　ガイド（情報入力）
                        PersonalityFlag.INDIVIDUAL_OTHER.code -> {
                            RECOVERY_ID = RestoreRoute.RESTORE_MBOP0203.code
                            RouteName.MBOP0203Page
                        }
                        // MBCC0103　ガイド（情報入力）
                        else -> {
                            RECOVERY_ID = RestoreRoute.RESTORE_MBCC0103.code
                            RouteName.MBCC0103Page
                        }
                    }
                } else {
                    RouteName.MBCO0405Page
                }
            }
            else -> {
                screenId
            }
        }
    }

    // 起動画面を取得
    fun getStartDestination(): String {
        val recoveryScreenInfo = MyApp.INSTANCE.findAll(EPassBookAB0701::class.java)
        val showAgreementFlag = PreferenceUtil.getPreferenceBooleanValue(ConstUtil.SHOW_AGREEMENT_FLAG)
        return if (recoveryScreenInfo.isNotEmpty()) {
            // 復元処理API異常フラグがtrue場合
            if (RECOVERY_API_ERROR_FLAG) {
                // MBSU0101　はじめまして画面
                RouteName.MBSU0101Page
            } else {
                // 復元画面取得
                RECOVERY_ID = recoveryScreenInfo[0]?.screenId ?: ""
                getRecoveryScreenRouteName()
            }
        } else {
            if (MainActivity.ACTIVITY_FLAG != ACTIVITY_FLAG_NO_ACCESS_NO_LOGIN) {
                // ログイン画面へ遷移する
                RouteName.MBLG0101Page
            } else {
                if (!showAgreementFlag) {
                    // 初回アプリ起動後に利用規定
                    RouteName.MBSU0105Page
                } else {
                    // MBSU0101　はじめまして画面
                    RouteName.MBSU0101Page
//                    RouteName.MBRC0202Page
                }
            }
        }
    }

    // EKYC画面を取得
    fun getEkycDestination(): String {
        return if (IS_EKYC_SHOOT_AGAIN_FLAG) {
            // MBCO0401　本人確認書類選択
            RouteName.MBCO0401Page
        } else {
            // MBCO0405　読取結果
            RouteName.MBCO0405Page
        }
    }

    Scaffold(
        modifier = Modifier
            .statusBarsPadding()
            .navigationBarsPadding(),
        bottomBar = {
            if (isShowBottomBar) {
                BottomNavBar(navCtrl = NAVCTRL!!)
            }
        },
        content = {
            AnimatedNavHost(
                modifier = Modifier.background(MaterialTheme.colors.background)
                    .padding(bottom = if (isShowBottomBar) 56.dp else 0.dp),
                navController = NAVCTRL!!,
                startDestination = if (MainActivity.IS_EKYC_BACK_FLAG) getEkycDestination() else getStartDestination(),
                enterTransition = {
                    slideInHorizontally(
                        initialOffsetX = { fullWidth -> fullWidth },
                        animationSpec = tween(500)
                    )
                },
                exitTransition = {
                    slideOutHorizontally(
                        targetOffsetX = { fullWidth -> fullWidth },
                        animationSpec = tween(500)
                    )
                },
                popEnterTransition = {
                    slideInHorizontally(
                        initialOffsetX = { fullWidth -> fullWidth },
                        animationSpec = tween(500)
                    )
                },
                popExitTransition = {
                    slideOutHorizontally(
                        targetOffsetX = { fullWidth -> fullWidth },
                        animationSpec = tween(500)
                    )
                }
            ) {
                composable(route = RouteName.HOME) {
                    HomePage()
                }
                composable(route = RouteName.BALANCE) {
                    BalancePage()
                }
                composable(route = RouteName.HELP) {
                    HelpPage()
                }
                composable(route = RouteName.MENU) {
                    MenuPage()
                }

                // WebView
                composable(
                    route = RouteName.WEB_VIEW + "?url={url}",
                    arguments = listOf(navArgument("url") { type = NavType.StringType })
                ) {
                    val url = it.arguments?.getString("url")
                    if (url != null) {
                        WebView(url = url)
                    }
                }

                // WebViewPage
                composable(
                    route = RouteName.WEB_VIEW_PAGE + "?title={title}&url={url}",
                    arguments = listOf(
                        navArgument("title") { nullable = true },
                        navArgument("url") { type = NavType.StringType }
                    )
                ) {
                    val title = it.arguments?.getString("title")
                    val url = it.arguments?.getString("url")
                    WebViewPage(title ?: "", url ?: "")
                }

                /************************** MBSU **************************/
                // MBSU0101Page
                composable(route = RouteName.MBSU0101Page) {
                    MBSU0101Page()
                }

                // MBSU0102Page
                composable(route = RouteName.MBSU0102Page) {
                    MBSU0102Page()
                }

                // MBSU0103Page
                composable(route = RouteName.MBSU0103Page) {
                    MBSU0103Page()
                }

                // MBSU0105Page
                composable(route = RouteName.MBSU0105Page) {
                    MBSU0105Page()
                }

                // MBSU0106Page
                composable(route = RouteName.MBSU0106Page) {
                    MBSU0106Page()
                }

                // MBSU0201Page
                composable(
                    route = RouteName.MBSU0201Page
                ) {
                    MBSU0201Page()
                }

                // MBSU0202Page
                composable(route = RouteName.MBSU0202Page) {
                    MBSU0202Page()
                }

                // MBSU0301Page
                composable(
                    route = RouteName.MBSU0301Page
                ) {
                    MBSU0301Page()
                }

                // MBSU0302Page
                composable(
                    route = RouteName.MBSU0302Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBSU0302Page()
                }

                // MBSU0309Page
                composable(
                    route = RouteName.MBSU0309Page
                ) {
                    MBSU0309Page()
                }
                // MBSU0309Page
                composable(
                    route = RouteName.MBSU0309Page + "/{inputData}",
                    arguments = listOf(
                        navArgument(INPUT_DATA) { defaultValue = "" }
                    )
                ) {
                    MBSU0309Page()
                }
                // MBSU2001Page
                composable(route = RouteName.MBSU2001Page) {
                    MBSU2001Page()
                }

                // MBSU0303Page
                composable(
                    route = RouteName.MBSU0303Page
                ) {
                    MBSU0303Page()
                }

                // MBSU0304Page
                composable(
                    route = RouteName.MBSU0304Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBSU0304Page()
                }

                // MBSU0305Page
                composable(route = RouteName.MBSU0305Page) {
                    MBSU0305Page()
                }

                // MBSU0306Page
                composable(
                    route = RouteName.MBSU0306Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBSU0306Page()
                }

                // MBSU0307Page
                composable(
                    route = RouteName.MBSU0307Page
                ) {
                    MBSU0307Page()
                }

                // MBSU0308Page
                composable(
                    route = RouteName.MBSU0308Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBSU0308Page()
                }

                // MBSU0401Page
                composable(route = RouteName.MBSU0401Page) {
                    MBSU0401Page()
                }

                // MBSU0501Page
                composable(route = RouteName.MBSU0501Page) {
                    MBSU0501Page()
                }

                // MBSU0502Page
                composable(
                    route = RouteName.MBSU0502Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBSU0502Page()
                }

                // MBSU0601Page
                composable(
                    route = RouteName.MBSU0601Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBSU0601Page()
                }

                // MBSU0602Page
                composable(
                    route = RouteName.MBSU0602Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBSU0602Page()
                }

                /************************** MBLG **************************/
                // MBLG0101Page
                composable(route = RouteName.MBLG0101Page) {
                    MBLG0101Page()
                }
                // MBLG0201Page
                composable(route = RouteName.MBLG0201Page) {
                    MBLG0201Page()
                }
                // MBLG0301Page
                composable(
                    route = RouteName.MBLG0301Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBLG0301Page()
                }
                // MBLG0302Page
                composable(
                    route = RouteName.MBLG0302Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBLG0302Page()
                }
                // MBLG0303Page
                composable(route = RouteName.MBLG0303Page) {
                    MBLG0303Page()
                }
                // MBLG0304Page
                composable(route = RouteName.MBLG0304Page) {
                    MBLG0304Page()
                }
                // MBLG0305Page
                composable(
                    route = RouteName.MBLG0305Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBLG0305Page()
                }
                // MBLG0306Page
                composable(route = RouteName.MBLG0306Page) {
                    MBLG0306Page()
                }
                // MBLG0601Page
                composable(route = RouteName.MBLG0601Page) {
                    MBLG0601Page()
                }
                // MBLG1001Page
                composable(route = RouteName.MBLG1001Page) {
                    MBLG1001Page()
                }

                // MBLG2002Page
                composable(route = RouteName.MBLG2002Page) {
                    MBLG2002Page()
                }

                /************************** MBST **************************/
                // MBST0101Page
                composable(route = RouteName.MBST0101Page) {
                    MBST0101Page()
                }
                // MBST0301Page
                composable(route = RouteName.MBST0301Page) {
                    MBST0301Page()
                }
                // MBST0301Page
                composable(route = RouteName.MBST0301NewPage) {
                    MBST0301NewPage()
                }
                // MBST0301Page
                composable(
                    route = RouteName.MBST0301ConfirmPage + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBST0301ConfirmPage()
                }
                // MBST0401Page
                composable(route = RouteName.MBST0401Page) {
                    MBST0401Page()
                }
                // MBST0402Page
                composable(
                    route = RouteName.MBST0402Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBST0402Page()
                }
                // MBST0501Page
                composable(route = RouteName.MBST0501Page) {
                    MBST0501Page()
                }
                // MBST0502Page
                composable(route = RouteName.MBST0502Page) {
                    MBST0502Page()
                }
                // MBST0503Page
                composable(
                    route = RouteName.MBST0503Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBST0503Page()
                }
                // MBST0601Page
                composable(
                    route = RouteName.MBST0601Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBST0601Page()
                }
                // MBST0801Page
                composable(
                    route = RouteName.MBST0801Page
                ) {
                    MBST0801Page()
                }
                // MBST0802Page
                composable(
                    route = RouteName.MBST0802Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBST0802Page()
                }
                // MBST0901Page
                composable(route = RouteName.MBST0901Page) {
                    MBST0901Page()
                }
                // MBST0903Page
                composable(route = RouteName.MBST0903Page) {
                    MBST0903Page()
                }
                // MBST0904Page
                composable(
                    route = RouteName.MBST0904Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBST0904Page()
                }
                // MBST1101Page
                composable(route = RouteName.MBST1101Page) {
                    MBST1101Page()
                }
                // MBST1201Page
                composable(route = RouteName.MBST1201Page) {
                    MBST1201Page()
                }
                // MBST1501Page
                composable(route = RouteName.MBST1501Page) {
                    MBST1501Page()
                }
                // MBST1601Page
                composable(route = RouteName.MBST1601Page) {
                    MBST1601Page()
                }
                // MBST1701Page
                composable(route = RouteName.MBST1701Page) {
                    MBST1701Page()
                }
                // MBST1801Page
                composable(route = RouteName.MBST1801Page) {
                    MBST1801Page()
                }
                // MBST1901Page
                composable(route = RouteName.MBST1901Page) {
                    MBST1901Page()
                }

                /************************** MBDP **************************/

                // MBDP0101Page
                composable(
                    route = RouteName.MBDP0101Page
                ) {
                    MBDP0101Page()
                }

                // MBDP0201Page
                composable(
                    route = RouteName.MBDP0201Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBDP0201Page()
                }

                // MBLG0501Page
                composable(
                    route = RouteName.MBLG0501Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBLG0501Page()
                }

                // MBDP0201TablePage
                composable(
                    route = RouteName.MBDP0201TablePage + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBDP0201TablePage()
                }

                // MBDP0301Page
                composable(
                    route = RouteName.MBDP0301Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBDP0301Page()
                }

                // MBDP0301TablePage
                composable(
                    route = RouteName.MBDP0301TablePage + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBDP0301TablePage()
                }

                // MBLG0502Page
                composable(
                    route = RouteName.MBLG0502Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBLG0502Page()
                }

                // MBDP1401Page
                composable(
                    route = RouteName.MBDP1401Page +
                        "/{value}/{dateFrom}/{dateTo}",
                    arguments = listOf(
                        navArgument("value") { defaultValue = "" },
                        navArgument("dateFrom") { defaultValue = "" },
                        navArgument("dateTo") { defaultValue = "" },
                    )
                ) {
                    MBDP1401Page()
                }

                // MBDP0401Page
                composable(
                    route = RouteName.MBDP0401Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBDP0401Page()
                }

                // MBLG0505Page
                composable(
                    route = RouteName.MBLG0505Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBLG0505Page()
                }

                // MBDP0401TablePage
                composable(
                    route = RouteName.MBDP0401TablePage + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBDP0401TablePage()
                }

                // MBDP0501Page
                composable(
                    route = RouteName.MBDP0501Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBDP0501Page()
                }

                // MBLG0507Page
                composable(
                    route = RouteName.MBLG0507Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBLG0507Page()
                }
                // MBDP0501TablePage
                composable(
                    route = RouteName.MBDP0501TablePage + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBDP0501TablePage()
                }

                // MBDP1301Page
                composable(
                    route = RouteName.MBDP1301Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBDP1301Page()
                }

                // MBDP0901Page
                composable(
                    route = RouteName.MBDP0901Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBDP0901Page()
                }

                // MBDP0701Page
                composable(
                    route = RouteName.MBDP0701Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBDP0701Page()
                }

                // MBDP1101Page
                composable(
                    route = RouteName.MBDP1101Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBDP1101Page()
                }

                /************************** MBOP **************************/

                // MBOP0101Page
                composable(
                    route = RouteName.MBOP0101Page
                ) {
                    MBOP0101Page()
                }

                // MBOP0102Page
                composable(
                    route = RouteName.MBOP0102Page
                ) {
                    MBOP0102Page()
                }

                // MBOP0103Page
                composable(
                    route = RouteName.MBOP0103Page
                ) {
                    MBOP0103Page()
                }

                // MBOP0201Page
                composable(
                    route = RouteName.MBOP0201Page
                ) {
                    MBOP0201Page()
                }

                // MBOP0202Page
                composable(
                    route = RouteName.MBOP0202Page
                ) {
                    MBOP0202Page()
                }

                // MBOP0203Page
                composable(
                    route = RouteName.MBOP0203Page
                ) {
                    MBOP0203Page()
                }

                // MBOP0301Page
                composable(
                    route = RouteName.MBOP0301Page
                ) {
                    MBOP0301Page()
                }

                // MBOP0401Page
                composable(
                    route = RouteName.MBOP0401Page
                ) {
                    MBOP0401Page()
                }

                // MBOP0601Page
                composable(
                    route = RouteName.MBOP0601Page
                ) {
                    MBOP0601Page()
                }

                // MBOP0602Page
                composable(
                    route = RouteName.MBOP0602Page
                ) {
                    MBOP0602Page()
                }

                // MBOP0603Page
                composable(
                    route = RouteName.MBOP0603Page
                ) {
                    MBOP0603Page()
                }

                // MBOP0604Page
                composable(
                    route = RouteName.MBOP0604Page
                ) {
                    MBOP0604Page()
                }

                // MBOP0605Page
                composable(
                    route = RouteName.MBOP0605Page
                ) {
                    MBOP0605Page()
                }

                // MBOP0606Page
                composable(
                    route = RouteName.MBOP0606Page
                ) {
                    MBOP0606Page()
                }

                // MBOP0607Page
                composable(
                    route = RouteName.MBOP0607Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBOP0607Page()
                }

                // MBOP0608Page
                composable(
                    route = RouteName.MBOP0608Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBOP0608Page()
                }

                // MBOP0609Page
                composable(
                    route = RouteName.MBOP0609Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBOP0609Page()
                }

                // MBOP0610Page
                composable(
                    route = RouteName.MBOP0610Page
                ) {
                    MBOP0610Page()
                }

                // MBOP0611Page
                composable(
                    route = RouteName.MBOP0611Page
                ) {
                    MBOP0611Page()
                }

                // MBOP0612Page
                composable(
                    route = RouteName.MBOP0612Page
                ) {
                    MBOP0612Page()
                }

                // MBOP0613Page
                composable(
                    route = RouteName.MBOP0613Page
                ) {
                    MBOP0613Page()
                }

                // MBOP0701Page
                composable(
                    route = RouteName.MBOP0701Page
                ) {
                    MBOP0701Page()
                }

                // MBOP0702Page
                composable(
                    route = RouteName.MBOP0702Page + "/{dataList}",
                    arguments = listOf(
                        navArgument(DATA_LIST) { defaultValue = "" }
                    )
                ) {
                    MBOP0702Page()
                }

                // MBOP0703Page
                composable(
                    route = RouteName.MBOP0703Page + "/{data}/{alternateFlg}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" },
                        navArgument(ALTERNATE_FLG) { defaultValue = "" }
                    )
                ) {
                    MBOP0703Page()
                }

                // MBOP0704Page
                composable(
                    route = RouteName.MBOP0704Page + "/{dataList}",
                    arguments = listOf(
                        navArgument(DATA_LIST) { defaultValue = "" }
                    )
                ) {
                    MBOP0704Page()
                }

                // MBOP0705Page
                composable(
                    route = RouteName.MBOP0705Page
                ) {
                    MBOP0705Page()
                }

                // MBOP0706Page
                composable(
                    route = RouteName.MBOP0706Page
                ) {
                    MBOP0706Page()
                }

                // MBOP1001Page
                composable(
                    route = RouteName.MBOP1001Page
                ) {
                    MBOP1001Page()
                }

                // MBOP1002Page
                composable(
                    route = RouteName.MBOP1002Page
                ) {
                    MBOP1002Page()
                }

                // MBOP1003Page
                composable(
                    route = RouteName.MBOP1003Page
                ) {
                    MBOP1003Page()
                }

                // MBOP1201Page
                composable(
                    route = RouteName.MBOP1201Page
                ) {
                    MBOP1201Page()
                }

                // MBOP1401Page
                composable(
                    route = RouteName.MBOP1401Page
                ) {
                    MBOP1401Page()
                }

                // MBOP1501Page
                composable(
                    route = RouteName.MBOP1501Page
                ) {
                    MBOP1501Page()
                }

                /************************** MBCO **************************/
                // MBCO0201Page
                composable(
                    route = RouteName.MBCO0201Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBCO0201Page()
                }

                // MBCO0202Page
                composable(
                    route = RouteName.MBCO0202Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBCO0202Page()
                }

                // MBCO0301Page
                composable(
                    route = RouteName.MBCO0301Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBCO0301Page()
                }

                // MBCO0302Page
                composable(
                    route = RouteName.MBCO0302Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBCO0302Page()
                }

                // MBCO0401Page
                composable(
                    route = RouteName.MBCO0401Page
                ) {
                    MBCO0401Page()
                }

                // MBCO0402Page
                composable(
                    route = RouteName.MBCO0402Page
                ) {
                    MBCO0402Page()
                }

                // MBCO0403Page
                composable(
                    route = RouteName.MBCO0403Page
                ) {
                    MBCO0403Page()
                }

                // MBCO0404Page
                composable(
                    route = RouteName.MBCO0404Page
                ) {
                    MBCO0404Page()
                }

                // MBCO0405Page
                composable(
                    route = RouteName.MBCO0405Page
                ) {
                    MBCO0405Page()
                }

                // MBCO0501Page
                composable(
                    route = RouteName.MBCO0501Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBCO0501Page()
                }

                // MBCO0601Page
                composable(
                    route = RouteName.MBCO0601Page
                ) {
                    MBCO0601Page()
                }

                /************************** MBCC **************************/
                // MBCC0101Page
                composable(
                    route = RouteName.MBCC0101Page
                ) {
                    MBCC0101Page()
                }

                // MBCC0102Page
                composable(
                    route = RouteName.MBCC0102Page
                ) {
                    MBCC0102Page()
                }

                // MBCC0103Page
                composable(
                    route = RouteName.MBCC0103Page
                ) {
                    MBCC0103Page()
                }

                // jp.co.jsbank.mb.bankingapp.ui.pages.cashCard.mbcc.mbcc0201.MBCC0201Page
                composable(
                    route = RouteName.MBCC0201Page
                ) {
                    MBCC0201Page()
                }

                // MBCC0301Page
                composable(
                    route = RouteName.MBCC0301Page
                ) {
                    MBCC0301Page()
                }

                // MBCC0401Page
                composable(
                    route = RouteName.MBCC0401Page
                ) {
                    MBCC0401Page()
                }

                // MBCC0501Page
                composable(
                    route = RouteName.MBCC0501Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBCC0501Page()
                }

                // MBCC0901Page
                composable(
                    route = RouteName.MBCC0901Page
                ) {
                    MBCC0901Page()
                }

                /************************** MBDR **************************/
                // MBDR0101画面-スーパードリームお利息計算書（自継用）
                composable(
                    route = RouteName.MBDR0101Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBDR0101Page()
                }

                // MBDR0201画面-スーパードリーム期日のご案内
                composable(
                    route = RouteName.MBDR0201Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBDR0201Page()
                }

                // MBDR0301画面-定期積金満期のご案内
                composable(
                    route = RouteName.MBDR0301Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBDR0301Page()
                }

                // MBDR0401画面-定期預金等期日のご案内
                composable(
                    route = RouteName.MBDR0401Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBDR0401Page()
                }

                // MBDR0501画面-自動継続定期預金お利息計算書（自動継続定期）
                composable(
                    route = RouteName.MBDR0501Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBDR0501Page()
                }

                // MBDR0601画面-自動継続定期預金お利息計算書（大口定期）
                composable(
                    route = RouteName.MBDR0601Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBDR0601Page()
                }

                // MBDR0701画面-定期預金等期日のご案内（自由金利）
                composable(
                    route = RouteName.MBDR0701Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBDR0701Page()
                }

                // MBDR0801画面-お借入れが終了されたお客様へ
                composable(
                    route = RouteName.MBDR0801Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBDR0801Page()
                }

                // MBDR0901画面-城南総合口座決算のお知らせ
                composable(
                    route = RouteName.MBDR0901Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBDR0901Page()
                }

                // MBDR1001画面-融資期日案内
                composable(
                    route = RouteName.MBDR1001Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBDR1001Page()
                }

                // MBDR1101画面-城南自動送金サービス取扱期間終了のご案内
                composable(
                    route = RouteName.MBDR1101Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBDR1101Page()
                }

                // MBDR1201画面-財形年金預金年金額お受け取りのご案内
                composable(
                    route = RouteName.MBDR1201Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBDR1201Page()
                }

                // MBDR1301画面-証貸変動金利通知
                composable(
                    route = RouteName.MBDR1301Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBDR1301Page()
                }

                // MBDR1401画面-ご返済のお知らせ
                composable(
                    route = RouteName.MBDR1401Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBDR1401Page()
                }

                // MBDR1501画面-当座勘定照合表
                composable(
                    route = RouteName.MBDR1501Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBDR1501Page()
                }

                // MBDR1601画面-当座勘定照合表兼当座勘定決算のお知らせ
                composable(
                    route = RouteName.MBDR1601Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBDR1601Page()
                }

                // MBDR1701画面-貸金庫使用料期日案内
                composable(
                    route = RouteName.MBDR1701Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBDR1701Page()
                }

                // MBDR1801画面-割引手形計算明細表
                composable(
                    route = RouteName.MBDR1801Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBDR1801Page()
                }

                // MBDR1901画面-融資返済明細表
                composable(
                    route = RouteName.MBDR1901Page
                ) {
                    MBDR1901Page()
                }

                // MBDR2101画面-財産形成預金残高通知書
                composable(
                    route = RouteName.MBDR2101Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBDR2101Page()
                }

                /************************** MBNT **************************/
                // MBNT0101Page
                composable(
                    route = RouteName.MBNT0101Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBNT0101Page()
                }

                // MBNT0201Page
                composable(
                    route = RouteName.MBNT0201Page + "/{anncmntId}/{anncmntType}/{documentType}/{applyId}/{readFlag}/{confirmFlg}", // ktlint-disable max-line-length
                    arguments = listOf(
                        navArgument(ANNCMNT_ID) { defaultValue = "" },
                        navArgument(ANNCMNT_TYPE) { defaultValue = "" },
                        navArgument(DOCUMENT_TYPE) { defaultValue = "" },
                        navArgument(APPLY_ID) { defaultValue = "" },
                        navArgument(READ_FLAG) { defaultValue = "" },
                        navArgument(CONFIRM_FLG) { defaultValue = "" }
                    )
                ) {
                    MBNT0201Page()
                }

                /************************** MBRC **************************/
                // MBRC0101Page
                composable(
                    route = RouteName.MBRC0101Page
                ) {
                    MBRC0101Page()
                }

                // MBRC0201Page
                composable(
                    route = RouteName.MBRC0201Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" }
                    )
                ) {
                    MBRC0201Page()
                }

/*                // MBRC0202Page
                composable(
                    route = RouteName.MBRC0202Page
                ) {
                    MBRC0202Page()
                }*/

                // MBRC0202Page
                composable(
                    route = RouteName.MBRC0202Page +
                        "/{data}/{inputData}/{anncmntId}/{type}/{store}/{param1}/{param2}/{param3}/{param4}/{param5}/{param6}/{param7}", // ktlint-disable max-line-length
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" },
                        navArgument(INPUT_DATA) { defaultValue = "" },
                        navArgument(ANNCMNT_ID) { defaultValue = "" },
                        navArgument(TYPE) { defaultValue = "" },
                        navArgument(STORE) { defaultValue = "" },
                        navArgument(PARAM_1) { defaultValue = "" },
                        navArgument(PARAM_2) { defaultValue = "" },
                        navArgument(PARAM_3) { defaultValue = "" },
                        navArgument(PARAM_4) { defaultValue = "" },
                        navArgument(PARAM_5) { defaultValue = "" },
                        navArgument(PARAM_6) { defaultValue = "" },
                        navArgument(PARAM_7) { defaultValue = "" },
                    )
                ) {
                    MBRC0202Page()
                }

                // MBRC0204Page
                composable(
                    route = RouteName.MBRC0204Page + "/{data}",
                    arguments = listOf(
                        navArgument(DATA) { defaultValue = "" },
                    )
                ) {
                    MBRC0204Page()
                }

                // MBRC0301Page
                composable(
                    route = RouteName.MBRC0301Page + "/{param1}/{param2}/{param3}/{param4}",
                    arguments = listOf(
                        navArgument(PARAM_1) { defaultValue = "" },
                        navArgument(PARAM_2) { defaultValue = "" },
                        navArgument(PARAM_3) { defaultValue = "" },
                        navArgument(PARAM_4) { defaultValue = "" }
                    )
                ) {
                    MBRC0301Page()
                }
            }
        }
    )
}

package jp.co.jsbank.mb.bankingapp.ui.pages.common.state

/**
 * 共通メッセージ表示
 */
data class POPWindowsState(

    /**
     * エラーダイアログフラグ
     */
    var errorFlag: Boolean = false,
)

package jp.co.jsbank.mb.bankingapp.ui.pages.common.state

/**
 * ローディング
 */
data class LoadingState(

    /**
     * ローディングダイアログフラグ
     */
    var loadingFlag: Boolean = false,
)

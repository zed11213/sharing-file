package jp.co.jsbank.mb.bankingapp.ui.pages.common.state

/**
 * 共通メッセージ表示
 */
data class ToLoginState(

    /**
     * エラーダイアログフラグ
     */
    var errorScreenFlag: Boolean = false,

    /**
     * エラーフラグ
     */
    var errorFlag: Boolean = false,

    /**
     * アプリのパスワード
     */
    var password: String = "",

    /**
     * パスワード入力エラーフラグ
     */
    var passwordErr: Boolean = false,

    /**
     * サーバエラーメッセージ内容
     */
    var serverErrorMessage: String = "",

    /**
     * 承認待ちダイアログ
     */
    var showDialogFlag: Boolean = false,

    /**
     * AZ0911のエラーフラグ
     */
    var az0911ErrorFlg: Boolean = false,

    var screenFlg: Boolean = false,
)

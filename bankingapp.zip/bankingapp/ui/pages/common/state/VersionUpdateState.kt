package jp.co.jsbank.mb.bankingapp.ui.pages.common.state

/**
 * 共通メッセージ表示
 */
data class VersionUpdateState(

    /**
     * エラーダイアログフラグ
     */
    var errorFlag: Boolean = false,
)

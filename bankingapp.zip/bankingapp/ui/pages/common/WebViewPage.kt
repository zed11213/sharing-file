package jp.co.jsbank.mb.bankingapp.ui.pages.common

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.Text
import androidx.compose.material.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.theme.H5
import jp.co.jsbank.mb.bankingapp.theme.app_bar_title_color
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.IconButton
import jp.co.jsbank.mb.bankingapp.ui.widgets.webview.WebView
import jp.co.jsbank.mb.bankingapp.utils.RouteUtil.back
import jp.co.jsbank.mb.bankingapp.utils.ToLoginUtil
import org.jetbrains.annotations.NotNull

/**
 * webView.
 *
 * @param title タイトル
 * @param url パス
 */
@Composable
fun WebViewPage(
    @NotNull title: String = "",
    @NotNull url: String = "",
) {
    Column(
        Modifier
            .fillMaxWidth()
            .background(Color.White)
    ) {
        // アプリバー
        TopAppBar(
            modifier = Modifier
                .padding(horizontal = 5.dp)
                .height(35.dp),
            backgroundColor = Color.White,
            elevation = 0.dp
        ) {
            Box(
                contentAlignment = Alignment.Center
            ) {
                Row(
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {}
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            leftText = stringResource(id = R.string.common_page_topBar_button_close),
                            textSize = H5,
                            image = R.drawable.close,
                            imageSize = 22.dp
                        ) {
                            if (MainActivity.IS_BACK_GROUND) {
                                ToLoginUtil.openLogin("1")
                            }
                            MainActivity.NAVCTRL?.back()
                        }
                    }
                }
                Text(
                    text = title,
                    color = app_bar_title_color,
                    textAlign = TextAlign.Center,
                    fontSize = H5,
                )
            }
        }
        WebView(url)
    }
}

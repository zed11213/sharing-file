package jp.co.jsbank.mb.bankingapp.ui.pages.common

import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.click

/**
 * コンストラクタ.
 *
 * @param title タイトル
 * @param backGroundColor バックグラウンド色
 * @param elevation 標高
 * @param leftIcon leftアイコン
 * @param rightIcon rightアイコン
 * @param onLeftClick leftクッリク
 * @param onRightClick Rightクッリク
 */
@Composable
fun TopAppBar(
    title: String = "",
    backGroundColor: Color = MaterialTheme.colors.primary,
    elevation: Dp = AppBarDefaults.TopAppBarElevation,
    leftIcon: ImageVector? = null,
    rightIcon: ImageVector? = null,
    onLeftClick: () -> Unit = {},
    onRightClick: () -> Unit = {}
) {

    TopAppBar(
        backgroundColor = backGroundColor,
        modifier = Modifier.height(54.dp),
        elevation = elevation,
    ) {
        Box(
            contentAlignment = Alignment.Center
        ) {
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (leftIcon == null)
                    Spacer(modifier = Modifier.size(10.dp))
                else
                    Icon(
                        leftIcon, contentDescription = "",
                        modifier = Modifier
                            .click {
                                onLeftClick()
                            }
                            .padding(start = 10.dp),
                        tint = MaterialTheme.colors.background
                    )
                rightIcon?.let {
                    Icon(
                        rightIcon, contentDescription = null,
                        Modifier
                            .click {
                                onRightClick()
                            }
                            .padding(end = 10.dp),
                        tint = MaterialTheme.colors.background
                    )
                }
            }
            Text(
                text = title,
                textAlign = TextAlign.Center,
                fontSize = 18.sp,
                color = Color.White
            )
        }
    }
}

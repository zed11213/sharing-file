package jp.co.jsbank.mb.bankingapp.ui.pages.common

import android.os.Process
import androidx.compose.runtime.Composable
import androidx.compose.ui.res.stringResource
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.system.MyApp
import jp.co.jsbank.mb.bankingapp.ui.widgets.dialog.ImageHeadDialog
import kotlin.system.exitProcess

@Composable
fun CrashDialogPage() {
    ImageHeadDialog(
        image = R.drawable.error_info,
        imageSize = 100,
        title = stringResource(R.string.mblg0304_imageHeadDialog_title),
        content = MyApp.CONTEXT.getString(R.string.MSG_ID_SYSTEM_ERROR),
        buttonLabel = stringResource(id = R.string.common_dialog_button_close),
        onButtonClick = {
            Process.killProcess(Process.myPid())
            exitProcess(0)
        }
    )
}

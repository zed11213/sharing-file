package jp.co.jsbank.mb.bankingapp.ui.pages.common

import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.runtime.*
import com.google.accompanist.pager.ExperimentalPagerApi
import jp.co.jsbank.mb.bankingapp.system.MainActivity.Companion.APP_START_PAGE_FLAG
import jp.co.jsbank.mb.bankingapp.system.MainActivity.Companion.IS_EKYC_BACK_FLAG
import jp.co.jsbank.mb.bankingapp.theme.JsBankTheme
import jp.co.jsbank.mb.bankingapp.ui.pages.splash.MBCO6201Page
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.PAGE_NO_DESTROY_FLAG
import jp.co.jsbank.mb.bankingapp.utils.PreferenceUtil

@ExperimentalPagerApi
@RequiresApi(Build.VERSION_CODES.O)
@Composable
fun StartPage() {
    var isSplash by remember { mutableStateOf(true) }
    val noDestroy = PreferenceUtil.getPreferenceBooleanValue(PAGE_NO_DESTROY_FLAG)
    JsBankTheme {
        if (IS_EKYC_BACK_FLAG) {
            AppScaffold()
        } else {
            if (isSplash && !noDestroy) {
                APP_START_PAGE_FLAG = true
                MBCO6201Page(onNextPage = { isSplash = false })
            } else {
                APP_START_PAGE_FLAG = false
                PreferenceUtil.setPreferenceBooleanValue(PAGE_NO_DESTROY_FLAG, false)
                AppScaffold()
            }
        }
    }
}

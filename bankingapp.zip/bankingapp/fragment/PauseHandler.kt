package jp.co.jsbank.mb.bankingapp.fragment

import android.os.Handler
import android.os.Message
import android.util.Log
import androidx.annotation.NonNull
import java.util.*

/**
 * アクティビティが Pause 中にフラグメント切り替えを防ぐためのハンドラ
 */
internal class PauseHandler(@NonNull clazz: Class<out SmartReplaceableFragment?>, @NonNull callback: Callback) :
    Handler() {
    /**
     * 処理対象クラス名.
     */
    private val clazz: Class<out SmartReplaceableFragment?>

    /**
     * ポーズ中を示すフラグ.
     */
    private var paused = false

    /**
     * コールバックオブジェクト.
     */
    @NonNull
    private val callback: Callback

    /**
     * コールバックインタフェース.
     */
    internal interface Callback {
        fun processMessage(@NonNull message: Message?)
    }

    /**
     * レジューム状態を通知します.
     */
    fun resume() {
        paused = false
        val queue = queue
        if (queue != null) {
            Log.d(TAG, "resume is called(Queue entries = " + queue.size + ")")
        }
        var message: Message?
        if (queue != null) {
            while (queue.pollFirst().also { message = it } != null) {
                Log.d(TAG, "send message from queue")
                sendMessage(message!!)
            }
        }
    }

    /**
     * ポーズ状態に設定します.
     */
    fun pause() {
        paused = true
    }

    /**
     * キューに積まれたメッセージをクリアします.
     */
    fun clearMessage() {
        queue?.clear()
    }

    /**
     * {@inheritDoc}
     */
    override fun handleMessage(message: Message) {
        if (paused) {
            Log.d(TAG, "push message to queue")
            val copied = Message()
            copied.copyFrom(message)
            val queue = queue
            queue?.push(copied)
            if (queue != null) {
                Log.d(TAG, "queue entries = " + queue.size)
            }
        } else {
            Log.d(TAG, "process message")
            callback.processMessage(message)
        }
    }

    /**
     * キューを取得します.
     *
     * @return 取得したキュー
     */
    @get:NonNull
    private val queue: Deque<Message>?
        get() {
            val queue = queueMap[clazz]
            queue
                ?: createQueue()
            return queue
        }

    /**
     * 新たにキューを生成します.
     *
     * @return 生成したキュー
     */
    @NonNull
    private fun createQueue(): Deque<Message> {
        //  新しいキューを作成
        val queue: Deque<Message> = ArrayDeque()
        queueMap[clazz] = queue
        return queue
    }

    companion object {
        /**
         * ログのタグ.
         */
        private val TAG = PauseHandler::class.java.name

        /**
         * メッセージキューのマップ.
         */
        private val queueMap: MutableMap<Class<out SmartReplaceableFragment?>, Deque<Message>> =
            HashMap<Class<out SmartReplaceableFragment?>, Deque<Message>>()
    }

    init {
        Log.d(TAG, "PauseHandler is created.(class = $clazz)")
        this.clazz = clazz
        this.callback = callback
    }
}

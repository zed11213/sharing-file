package jp.co.jsbank.mb.bankingapp.fragment

import androidx.annotation.LayoutRes
import jp.co.jsbank.mb.bankingapp.R

/**
 * 書類撮影時のプログレスエリアのフラグメントです.
 */
class DocumentCaptureProgressAreaFragment : ProgressAreaFragment() {
    /**
     * フラグメントレイアウトのリソース ID を取得します.
     *
     * @return 取得したレイアウト ID
     */
    @get:LayoutRes
    override val layoutId: Int
        get() = R.layout.document_progress_view
}

package jp.co.jsbank.mb.bankingapp.fragment

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import androidx.annotation.NonNull
import androidx.annotation.Nullable
import androidx.core.app.ActivityCompat
import androidx.fragment.app.Fragment
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.system.ekyc.BundleKeyDefinitions.APP_KEY_MATCHING_ID_RESULT
import jp.co.jsbank.mb.bankingapp.system.ekyc.IntroductionActivity
import jp.co.jsbank.mb.bankingapp.ui.widgets.common.SafetyButton
import jp.co.jsbank.mb.bankingapp.utils.PreferenceManagerUtil
import jp.co.polarify.onboarding.sdk.PolarifyKycSdkFactory
import jp.co.polarify.onboarding.sdk.types.callback.GetMatchingIDCallback
import jp.co.polarify.onboarding.sdk.types.internal.ErrorResult
import jp.co.polarify.onboarding.sdk.types.result.GetMatchingIDResult

/**
 * 書類撮影前・ホーム画面を生成フラグメントです.
 */
class HomeFlowFragment : Fragment(), ActivityCompat.OnRequestPermissionsResultCallback {
    /**
     * 登録を始めるボタンです.
     */
    private var button: SafetyButton? = null

    /**
     * 次へ進む時ネット通信Progressです.
     */
    private var progressBar: ProgressBar? = null

    @Nullable
    override fun onCreateView(
        @NonNull inflater: LayoutInflater,
        @Nullable container: ViewGroup?,
        @Nullable savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_home_flow, container, false)
    }

    override fun onViewCreated(@NonNull view: View, @Nullable savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        progressBar = view.findViewById(R.id.waiting_progress_bar_id)
        // 登録を始めるボタン
        button = view.findViewById(R.id.start_register_button)
        button?.setOnClickListener {
            progressBar?.visibility = View.VISIBLE
            matchingID
        }
    }

    /**
     * イントロダクションを開始します.
     */
    private fun startIntroduction() {
        val introType: IntroductionActivity.IntroductionType = introductionType
        startIntroductionActivity(introType)
    }

    /**
     * イントロダクションタイプを取得します.
     *
     * @return イントロダクションタイプ
     */
    private val introductionType: IntroductionActivity.IntroductionType
        get() = IntroductionActivity.IntroductionType.FIRST

    /**
     * イントロダクションを開始します.
     *
     * @param type イントロダクションの種類
     */
    private fun startIntroductionActivity(@NonNull type: IntroductionActivity.IntroductionType) {
        val intent = Intent(context, IntroductionActivity::class.java)
        intent.putExtra(IntroductionActivity.KEY_INTRODUCTION_TYPE, type)
        Log.d(TAG, "send IntroductionActivity start intent")
        startActivity(intent)
    }

    /**
     * 照合用 ID 取得を行います.
     */
    private val matchingID: Unit
        get() {
            val context: Context = requireContext()
            val factory = PolarifyKycSdkFactory()
            factory.getInstance(context).getMatchingID(object : GetMatchingIDCallback {
                override fun onSuccess(@NonNull result: GetMatchingIDResult) {
                    Log.d(TAG, "getMatchingID is onSuccess(ID = " + result.id + ")")
                    PreferenceManagerUtil.putGetMatchingIDResult(context, APP_KEY_MATCHING_ID_RESULT, result)
                    startIntroduction()
                    button?.unlock()
                    progressBar!!.visibility = View.INVISIBLE
                }

                override fun onError(@NonNull errorResult: ErrorResult) {
                    button?.unlock()
                    progressBar!!.visibility = View.INVISIBLE
                }
            })
        }

    companion object {
        /**
         * ログのタグ.
         */
        private val TAG = HomeFlowFragment::class.java.name
    }
}

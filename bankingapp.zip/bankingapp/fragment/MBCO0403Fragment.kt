package jp.co.jsbank.mb.bankingapp.fragment

import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Message
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.IdRes
import androidx.annotation.NonNull
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.bean.common.CheckPointsBean
import jp.co.jsbank.mb.bankingapp.system.ekyc.TutorialActivity
import jp.co.jsbank.mb.bankingapp.theme.H5
import jp.co.jsbank.mb.bankingapp.theme.H6
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.PrimaryButton
import jp.co.jsbank.mb.bankingapp.ui.widgets.card.CardCheckPoints
import jp.co.jsbank.mb.bankingapp.ui.widgets.tabBar.Tab
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil
import jp.co.jsbank.mb.bankingapp.utils.LogPrintUtil
import jp.co.jsbank.mb.bankingapp.utils.PreferenceUtil
import jp.co.polarify.onboarding.sdk.PolarifyKycSdkFactory
import jp.co.polarify.onboarding.sdk.types.callback.SelfieCaptureCallback
import jp.co.polarify.onboarding.sdk.types.internal.ErrorResult
import jp.co.polarify.onboarding.sdk.types.paramters.MatchingParameters
import jp.co.polarify.onboarding.sdk.types.result.FaceCaptureResult
import jp.co.polarify.onboarding.sdk.types.result.GetMatchingIDResult

/**
 * MBCO0403　顔の撮影１
 */
class MBCO0403Fragment : TutorialFragment() {
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return ComposeView(requireContext()).apply {
            setContent {
                MBCO0403Page()
            }
        }
    }

    override fun processMessage(message: Message?) {
        if (message != null) {
            when (message.what) {
                SelfieTutorialFragment.FRAGMENT_REPLACE_ID -> replaceNextFragment()
                SelfieTutorialFragment.SELFIE_PROGRESS_ID -> replaceSelfieProgressAreaFragment()
            }
        }
    }

    /**
     * 次に表示するフラグメントに切り替えます.
     */
    private fun replaceNextFragment() {
        val manager: FragmentManager? = fragmentManager
        if (manager == null) {
            val message = "Cannot get FragmentManager"
            throw IllegalStateException(message)
        }
        // フラグメント切り替えトランザクションの取得
        val transaction: FragmentTransaction = manager.beginTransaction()
        // 次に表示するフラグメントを取得
        val fragment: Fragment = nextFragment
        transaction.replace(R.id.fragment_container, fragment)
        val progressAreaFragment: Fragment = RequestProgressAreaFragment()
        transaction.replace(R.id.progress_container, progressAreaFragment)
        transaction.commit()
    }

    /**
     * 次に表示するフラグメントを取得します.
     *
     * @return 取得したフラグメント
     */
    @get:NonNull
    val nextFragment: Fragment
        get() = SelfieConfirmationFragment()

    @Composable
    fun MBCO0403Page() {
        Column(
            Modifier
                .fillMaxWidth()
                .background(Color.White)
        ) {
            Row(
                modifier = Modifier
                    .weight(0.5f)
                    .padding(20.dp, 0.dp, 20.dp, 0.dp)
            ) {
                if (PreferenceUtil.getPreferenceBooleanValue(ConstUtil.EKYC_TYPE))
                    Tab(
                        state = 1,
                        list = listOf(
                            stringResource(R.string.common_tab_process_second),
                            stringResource(R.string.common_tab_process_first),
                            stringResource(R.string.common_tab_process_fifth),
                        )
                    )
                else
                    Tab(
                        state = 2,
                        list = listOf(
                            stringResource(R.string.common_tab_process_4th),
                            stringResource(R.string.common_tab_process_second),
                            stringResource(R.string.common_tab_process_first),
                            stringResource(R.string.common_tab_process_fifth),
                        )
                    )
            }

            Row(
                Modifier
                    .fillMaxWidth()
                    .weight(0.5f)
            ) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 15.dp)
                ) {
                    Text(
                        text = stringResource(id = R.string.mbco0403_page_title_member),
                        Modifier
                            .padding(0.dp, 0.dp, 0.dp, 0.dp)
                            .align(Alignment.Center),
                        textAlign = TextAlign.Center,
                        fontSize = H5,
                    )
                }
            }

            Row(
                Modifier
                    .fillMaxWidth()
                    .weight(1.5f),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Image(
                    contentScale = ContentScale.Crop,
                    modifier = Modifier,
                    painter = painterResource(id = R.drawable.ekyc_face),
                    contentDescription = ""
                )
            }

            Row(
                Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 15.dp)
                ) {
                    Text(
                        text = stringResource(id = R.string.mbco0403_page_first_help_message),
                        Modifier
                            .padding(0.dp, 0.dp, 0.dp, 0.dp)
                            .align(Alignment.CenterStart),
                        textAlign = TextAlign.Start,
                        fontSize = H6,
                    )
                }
            }

            val list: List<CheckPointsBean> = listOf(
                CheckPointsBean(content = stringResource(id = R.string.mbco0403_page_label_prompt_information_first)),
                CheckPointsBean(content = stringResource(id = R.string.mbco0403_page_label_prompt_information_5th)),
                CheckPointsBean(content = stringResource(id = R.string.mbco0403_page_label_prompt_information_second)),
                CheckPointsBean(content = stringResource(id = R.string.mbco0403_page_label_prompt_information_3rd)),
                CheckPointsBean(content = stringResource(id = R.string.mbco0403_page_label_prompt_information_4th))
            )
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 15.dp)
                    .weight(2f)
            ) {
                CardCheckPoints(data = list)
            }

            Spacer(modifier = Modifier.weight(0.2f))

            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .background(color = Color.White)
                    .padding(horizontal = 50.dp)
                    .weight(1f)
            ) {
                Column(
                    modifier = Modifier
                        .background(color = Color.White)
                        .fillMaxWidth()
                ) {
                    PrimaryButton(text = stringResource(id = R.string.common_ekyc_button_shadow_begins)) {
                        startSelfie()
                    }
                }
            }
        }
    }

    /**
     * セルフィー画像の取得を行います.
     */
    private fun startSelfie() {
        val context: Context? = context
        if (context == null) {
            val message = "Cannot get Context"
            throw IllegalStateException(message)
        }
        startSelfie(context)
    }

    /**
     * セルフィー画像の取得を行います.
     *
     * @param context コンテキスト
     */
    private fun startSelfie(@NonNull context: Context) {
        val result: GetMatchingIDResult? = matchingIDResult
        if (result == null) {
            val message = "Cannot get GetMatchingIDResult"
            throw IllegalStateException(message)
        }
        val parameters = MatchingParameters(result)
        noUserCancelableStartSelfie(context, parameters)
    }

    /**
     * セルフィープログレスエリアのフラグメントの切り替えを行います.
     */
    private fun replaceSelfieProgressAreaFragment() {
        val fragment: Fragment = SelfieProgressAreaFragment()
        replaceFragment(R.id.progress_container, fragment)
    }

    /**
     * 指定された ID の View のフラグメントを切り替えます.
     *
     * @param id       フラグメントを切り替える View の ID
     * @param fragment 切り替えるフラグメント
     */
    private fun replaceFragment(@IdRes id: Int, @NonNull fragment: Fragment?) {
        val manager: FragmentManager? = fragmentManager
        if (manager == null) {
            val message = "Cannot get FragmentManager"
            throw IllegalStateException(message)
        }
        val transaction: FragmentTransaction = manager.beginTransaction()
        if (fragment != null) {
            transaction.replace(id, fragment).commit()
        }
    }

    /**
     * ユーザーキャンセルなしのセルフィ撮影を行います.
     *
     * @param context    コンテキスト
     * @param parameters パラメータオブジェクト
     */
    private fun noUserCancelableStartSelfie(@NonNull context: Context, @NonNull parameters: MatchingParameters) {
        val factory = PolarifyKycSdkFactory()
        factory.getInstance(context).startSelfie(
            parameters,
            object : SelfieCaptureCallback {
                override fun onSuccess(@NonNull result: FaceCaptureResult) {
                    val image = result.image
                    // セルフィー画像の通知
                    TutorialActivity.setSelfieImage(image)
                    sendMessage(SelfieTutorialFragment.FRAGMENT_REPLACE_ID)
                }

                override fun onError(@NonNull errorResult: ErrorResult) {
                    val message = "startSelfie is onError. code = " + errorResult.code
                    LogPrintUtil.error(message)
                }
            }
        )
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        if (requestCode == 101) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                context?.let { startSelfie(it) }
            } else {
                activity?.let {
                }
            }
        }
    }
}

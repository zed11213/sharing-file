package jp.co.jsbank.mb.bankingapp.fragment

import android.Manifest
import android.app.AlertDialog
import android.content.Context
import android.content.DialogInterface
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.util.DisplayMetrics
import android.util.Log
import android.util.Size
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.ViewTreeObserver
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.annotation.IdRes
import androidx.annotation.NonNull
import androidx.annotation.Nullable
import androidx.annotation.RawRes
import androidx.annotation.StringRes
import androidx.annotation.WorkerThread
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.app.ActivityCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.load.resource.gif.GifDrawable
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.system.MyApp.Companion.CONTEXT
import jp.co.jsbank.mb.bankingapp.system.ekyc.BundleKeyDefinitions
import jp.co.jsbank.mb.bankingapp.system.ekyc.TutorialActivity
import jp.co.jsbank.mb.bankingapp.system.master.DocumentKind
import jp.co.jsbank.mb.bankingapp.ui.widgets.common.SafetyButton
import jp.co.jsbank.mb.bankingapp.utils.CalendarChangeUtil
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.EKYC_INFO_ADDRESS
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.EKYC_INFO_ADDRESS1
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.EKYC_INFO_ADDRESS2
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.EKYC_INFO_ADDRESS3
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.EKYC_INFO_BIRTHDATE
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.EKYC_INFO_FIRST_NAME
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.EKYC_INFO_LAST_NAME
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.EKYC_INFO_POSTALCODE
import jp.co.jsbank.mb.bankingapp.utils.PreferenceManagerUtil
import jp.co.jsbank.mb.bankingapp.utils.PreferenceUtil
import jp.co.polarify.onboarding.sdk.PolarifyKycSdkFactory
import jp.co.polarify.onboarding.sdk.types.callback.DocumentCaptureCallback
import jp.co.polarify.onboarding.sdk.types.callback.DocumentOcrCaptureCallback
import jp.co.polarify.onboarding.sdk.types.common.DocumentType
import jp.co.polarify.onboarding.sdk.types.common.RectPoints
import jp.co.polarify.onboarding.sdk.types.internal.ErrorResult
import jp.co.polarify.onboarding.sdk.types.internal.NextActionNotifier
import jp.co.polarify.onboarding.sdk.types.paramters.DocumentCaptureParameters
import jp.co.polarify.onboarding.sdk.types.paramters.GuidePositionParameters
import jp.co.polarify.onboarding.sdk.types.result.CaptureMResult
import jp.co.polarify.onboarding.sdk.types.result.CaptureResult
import jp.co.polarify.onboarding.sdk.types.result.DocumentOcrResult
import jp.co.polarify.onboarding.sdk.types.result.DocumentResult
import jp.co.polarify.onboarding.sdk.types.result.OcrResultCode

/**
 * 書類撮影のチュートリアル画面フラグメントの共通基底クラスです.
 */
abstract class DocumentCaptureTutorialFragment : SmartReplaceableFragment() {
    /**
     * カメラビューのサイズ.
     */
    @Nullable
    private var cameraSize: Size? = null

    /**
     * 撮影を始めるボタンです.
     */
    private var startCaptureButton: SafetyButton? = null

    /**
     * 書類選択に戻るボタンです.
     */
    private var cancelCaptureButton: SafetyButton? = null

    /**
     * 次へ進む時ネット通信Progressです.
     */
    private var progressBar: ProgressBar? = null

    /**
     * OCR権限なし場合保存フラグのキー文字列.
     */
    private var isNoUsageRights = false

    /**
     * notifier.finish()が選択されたときのフラグ.
     */
    private var isNotifierFinish = false

    /**
     * 撮影を行う書類種別を取得します.
     *
     * @param documentKind 本人確認書類種類
     * @return 撮影を行う書類種別
     */
    @NonNull
    protected abstract fun getDocumentType(@NonNull documentKind: DocumentKind?): DocumentType

    @Nullable
    override fun onCreateView(
        @NonNull inflater: LayoutInflater,
        @Nullable container: ViewGroup?,
        @Nullable savedInstanceState: Bundle?
    ): View? {
        if (container == null) {
            Log.e(TAG, "container is null")
            return null
        }
        val tutorialContainer = container.findViewById<FrameLayout>(R.id.fragment_container)
        return inflater.inflate(R.layout.fragment_tutorial, tutorialContainer, false)
    }

    override fun onViewCreated(@NonNull view: View, @Nullable savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initializeViews(view)
        assignOpeningMessage(view)
        assignGifAnimation()
    }

    /**
     * ビューの初期設定を行います.
     *
     * @param root ルートビュー
     */
    open fun initializeViews(@NonNull root: View) {
        val constraintLayout: ConstraintLayout = root.findViewById(R.id.constraint_layout)
        constraintLayout.viewTreeObserver
            .addOnGlobalLayoutListener(object : ViewTreeObserver.OnGlobalLayoutListener {
                override fun onGlobalLayout() {
                    cameraSize = Size(root.width, root.height)
                    constraintLayout.viewTreeObserver
                        .removeOnGlobalLayoutListener(this) // ViewTreeObserver は毎回取得しないといけない
                    val arguments: Bundle = arguments ?: return
                    val isStartCapture = arguments.getBoolean(BundleKeyDefinitions.APP_KEY_DIRECT_START_CAPTURE)
                    if (isStartCapture) {
                        checkCameraPermission()
                    }
                }
            })
        progressBar = root.findViewById(R.id.waiting_progress_bar_id)
        startCaptureButton = root.findViewById(R.id.tutorial_button) // 撮影画面へ遷移するボタン
        cancelCaptureButton = root.findViewById(R.id.cancel_button) // 書類選択に戻るボタン

        // 撮影画面へ遷移するボタン
        startCaptureButton?.setOnClickListener {
            progressBar?.visibility = View.VISIBLE
            checkCameraPermission()
        }
        // 書類選択に戻るボタン
        cancelCaptureButton?.setOnClickListener {
            MainActivity.IS_EKYC_SHOOT_AGAIN_FLAG = true
            TutorialActivity.getResults()
        }
    }

    /**
     * 処理開始時のメッセージを表示します.
     *
     * @param root ルートビュー
     */
    private fun assignOpeningMessage(@NonNull root: View) {
        val textView = root.findViewById<TextView>(R.id.tutorial_text)
        @StringRes val id = openingMessageId
        textView.setText(id)
    }

    /**
     * 処理開始時に表示するメッセージのリソース ID を取得します.
     *
     * @return 取得したメッセージのリソース ID
     */
    @get:StringRes
    protected abstract val openingMessageId: Int

    /**
     * GIF アニメーションの設定を行います.
     */
    private fun assignGifAnimation() {
        // GIF アニメーションを表示する View の ID を取得
        @RawRes val id = gifId
        setGifByGlide(id)
    }

    /**
     * GIF アニメーションのリソース ID を取得します.
     *
     * @return 取得した GIF アニメーションのリソース ID
     */
    @get:RawRes
    protected abstract val gifId: Int

    /**
     * カメラ起動します．
     */
    private fun startCapture() {
        Log.d(TAG, "startCapture is called")
        val activity: TutorialActivity = tutorialActivity ?: return
        val documentKind: DocumentKind =
            DocumentKind.getDocumentKind(
                PreferenceManagerUtil.getInt(
                    activity,
                    BundleKeyDefinitions.APP_KEY_CAPTURE_KIND
                )
            )
        val documentType = getDocumentType(documentKind)
        val guidePoints = getGuidePoint(activity, documentType)
        // 自動、ユーザーキャンセルなし
        startCaptureAutomatically(activity, documentType, guidePoints)
    }

    /**
     * 書類種別がOCRありかどうかを判定します.
     *
     * @param documentType 書類種別
     * @return true: 書類種別（OCRあり）
     */
    private fun checkFrontOcr(documentType: DocumentType): Boolean {
        return when (documentType) {
            DocumentType.FRONTOCR, DocumentType.FRONTHOCR, DocumentType.FRONTMOCR -> true
            else -> false
        }
    }
    /**
     * 自動シャッターで書類撮影を行います(ユーザーキャンセルなし).
     *
     * @param activity     アクティビティ
     * @param documentType 書類種別
     * @param guidePoints  ガイド枠の四点座標
     */
    private fun startCaptureAutomatically(
        @NonNull activity: TutorialActivity,
        @NonNull documentType: DocumentType,
        @NonNull guidePoints: RectPoints
    ) {
        val factory = PolarifyKycSdkFactory()
//        factory.getInstance(activity).stopCapture()
        val parameters = DocumentCaptureParameters(
            documentType, guidePoints,
            cameraSize!!
        )
        if (checkFrontOcr(documentType)) {
            factory.getInstance(activity).startCapture(
                parameters,
                object : DocumentOcrCaptureCallback {
                    @WorkerThread
                    override fun onCaptureError(@NonNull result: CaptureResult, @NonNull notifier: NextActionNotifier) {
                        val handler: Handler = object : Handler(Looper.getMainLooper()) {
                            override fun handleMessage(msg: Message) {
                                if (msg.what == OCR_RETAKE_DIALOG_ID) {
                                    showRetakeOcrResult(result, notifier, activity, factory)
                                }
                            }
                        }
                        handler.sendMessage(handler.obtainMessage(OCR_RETAKE_DIALOG_ID))
                        startCaptureButton?.unlock()
                        progressBar!!.visibility = View.INVISIBLE
                    }

                    override fun onSuccess(@NonNull documentResult: DocumentResult) {
                        val message = "startOcrCapture is success"
                        Log.d(TAG, message)
                        // Toast.showLong(activity, message)
                        if (isNoUsageRights) {
                            // startCapture API実行してOCR権限無しエラー「NO_USAGE_RIGHTS」が通知された場合、
                            // onCaptureError側でTOP画面へ遷移済みの為ここでは何もしない.
                            isNoUsageRights = false
                            startCaptureButton?.unlock()
                            progressBar!!.visibility = View.INVISIBLE
                            return
                        }
                        onImageCaptured(activity, documentResult)
                        Handler().postDelayed({
                            // resultをキャストする
                            val ocrResult = documentResult as DocumentOcrResult
                            // 画面遷移を待ってから結果を表示する
                            showOcrResult(activity, ocrResult)
                        }, DELAY_TIME)
                        startCaptureButton?.unlock()
                        progressBar!!.visibility = View.INVISIBLE
                    }

                    override fun onError(@NonNull errorResult: ErrorResult) {
                        val message = "startOcrCapture is failed. code = " + errorResult.code
                        Log.e(TAG, message)
                        if (!errorResult.equals(ErrorResult.USER_CANCELLED)) {
                            // エラーダイアログの表示
                            showErrorDialog(activity, errorResult, factory)
                            startCaptureButton?.unlock()
                            progressBar!!.visibility = View.INVISIBLE
                            return
                        }
                        startCaptureButton?.unlock()
                        progressBar!!.visibility = View.INVISIBLE
                    }
                }
            )
        } else {
            factory.getInstance(activity).startCapture(
                parameters,
                object : DocumentCaptureCallback {
                    override fun onSuccess(@NonNull documentResult: DocumentResult) {
                        val message = "startCapture is success"
                        Log.d(TAG, message)
                        onImageCaptured(activity, documentResult)
                        startCaptureButton?.unlock()
                        progressBar!!.visibility = View.INVISIBLE
                    }

                    override fun onCaptureError(errorResult: CaptureResult, p1: NextActionNotifier) {
                        val message = "startCapture is failed. code = " + errorResult.ocrResult.resultCode
                        Log.e(TAG, message)
                        startCaptureButton?.unlock()
                        progressBar!!.visibility = View.INVISIBLE
                    }

                    override fun onError(@NonNull errorResult: ErrorResult) {
                        val message = "startCapture is failed. code = " + errorResult.code
                        Log.e(TAG, message)
                        if (!errorResult.equals(ErrorResult.USER_CANCELLED)) {
                            // エラーダイアログの表示
                            showErrorDialog(activity, errorResult, factory)
                            startCaptureButton?.unlock()
                            progressBar!!.visibility = View.INVISIBLE
                            return
                        }
                        startCaptureButton?.unlock()
                        progressBar!!.visibility = View.INVISIBLE
                    }
                }
            )
        }
    }

    /**
     * ガイド枠の四点座標を取得します.
     *
     * @param context コンテキスト
     * @param type    書類種別
     * @return 取得したガイド枠の四点座標
     */
    @NonNull
    private fun getGuidePoint(@NonNull context: Context, @NonNull type: DocumentType): RectPoints {
        // 枠が文言に被らないように高さを調整// dpをpxに変換// カメラプレビュー表示領域の高さ
        val size = size
        val parameter = GuidePositionParameters(type, size)
        val polarifyKycSdkFactory = PolarifyKycSdkFactory()
        val result = polarifyKycSdkFactory.getInstance(context).getGuidePosition(parameter)
        return result.rectPoints
    }

    /**
     * プレビュー時の画面サイズを取得します.
     *
     * @return プレビュー時の画面サイズ
     */
    @get:NonNull
    private val size: Size
        get() {
            // カメラプレビュー表示領域の高さ
            val cameraSizeHeight = cameraSize!!.height
            // dpをpxに変換
            val displayMetrics: DisplayMetrics = CONTEXT.resources.displayMetrics
            val messageHeight = CONTENTS * displayMetrics.density
            // 枠が文言に被らないように高さを調整
            val newHeight = (cameraSizeHeight - messageHeight).toInt()
            return Size(cameraSize!!.width, newHeight)
        }

    /**
     * キャンセルダイアログを 1 秒後に表示します.
     */
    private fun showDelayedDialog() {
        val activity: TutorialActivity = tutorialActivity
            // 取得失敗
            ?: return
        // アクティビティの取得
        Handler().postDelayed({ showCancelDialog(activity) }, DELAY_TIME)
    }

    /**
     * キャンセルダイアログを表示します.
     *
     * @param activity アクティビティ
     */
    private fun showCancelDialog(@NonNull activity: TutorialActivity) {
        startCaptureButton?.unlock()
        progressBar!!.visibility = View.INVISIBLE
    }

    /**
     * TutorialActivity を取得します.
     *
     * @return 取得した TutorialActivity
     */
    @get:Nullable
    private val tutorialActivity: TutorialActivity?
        get() {
            val activity: FragmentActivity? = activity
            if (activity !is TutorialActivity) {
                Log.e(TAG, "Cannot get TutorialActivity")
                return null
            }
            return activity
        }

    /**
     * 画像がキャプチャされた時の処理を行います.
     *
     * @param activity アクティビティ
     * @param result   キャプチャ結果
     */
    private fun onImageCaptured(@NonNull activity: TutorialActivity, @NonNull result: DocumentResult) {
        // キャプチャ画像をアクティビティに通知
        notifyDocumentResult(activity, result)
        // フラグメント切り替えのメッセージを発行
        sendMessage(FRAGMENT_REPLACE_ID)
    }

    /**
     * メッセージの処理を行います.
     *
     * @param message 処理対象メッセージ
     */
    override fun processMessage(message: Message?) {
        if (message != null) {
            if (message.what != FRAGMENT_REPLACE_ID) {
                return
            }
        }
        replaceNextFragment()
    }

    /**
     * 次に表示するフラグメントの切り替えを行います.
     */
    private fun replaceNextFragment() {
        val fragment: Fragment = nextFragment
        replaceFragment(R.id.fragment_container, fragment)
    }

    /**
     * 次に表示するフラグメントを取得します.
     *
     * @return 取得したフラグメント
     */
    @get:NonNull
    protected abstract val nextFragment: Fragment

    /**
     * フラグメントを置き換えます.
     *
     * @param id       置き換え場所のリソース ID
     * @param fragment 置き換えるフラグメント
     */
    private fun replaceFragment(@IdRes id: Int, @NonNull fragment: Fragment?) {
        val manager: FragmentManager? = getFragmentManager()
        if (manager == null) {
            val message = "Cannot get FragmentManager"
            Log.e(TAG, message)
            throw IllegalStateException(message)
        }
        val transaction: FragmentTransaction = manager.beginTransaction()
        transaction.addToBackStack(null)
        if (fragment != null) {
            transaction.replace(id, fragment).commit()
        }
    }

    /**
     * キャプチャー結果をアクティビティに通知します.
     *
     * @param activity アクティビティ
     * @param result   キャプチャー結果
     */
    protected abstract fun notifyDocumentResult(@NonNull activity: TutorialActivity?, @NonNull result: DocumentResult?)

    /**
     * Glide でGIF を表示させます.
     *
     * @param resource GIF ファイルのリソース
     */
    private fun setGifByGlide(@RawRes resource: Int) {
        Glide.with(this).load(resource).listener(object : RequestListener<Drawable?> {
            /**
             * 画像の読み込み失敗時に呼び出されます.
             */
            override fun onLoadFailed(
                e: GlideException?,
                model: Any?,
                target: Target<Drawable?>?,
                isFirstResource: Boolean
            ): Boolean {
                return false
            }

            /**
             * 画像の読み込み成功時に呼び出されます.
             */
            override fun onResourceReady(
                @NonNull resource: Drawable?,
                @NonNull model: Any,
                @NonNull target: Target<Drawable?>,
                @NonNull dataSource: DataSource,
                isFirstResource: Boolean
            ): Boolean {
                return if (resource !is GifDrawable) {
                    false
                } else {
                    resource.setLoopCount(1)
                    false
                }
            }
        }).into(view?.findViewById(R.id.tutorial_gif) as ImageView)
    }

    /**
     * 撮影開始前にカメラ権限を確認.
     */
    private fun checkCameraPermission() {
        val activity: FragmentActivity? = activity
        if (activity == null) {
            Log.e(TAG, "Cannot get Activity")
            return
        }
        isNoUsageRights = false
        val cameraPermission = Manifest.permission.CAMERA
        if (ActivityCompat.checkSelfPermission(activity, cameraPermission) !== PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(activity, arrayOf(cameraPermission), PERMISSION_REQUEST_CAMERA)
            startCaptureButton?.unlock()
            progressBar!!.visibility = View.INVISIBLE
        } else {
            startCapture()
        }
    }

    override fun onPause() {
        super.onPause()
        // 仕様不明のところが多くて、念のため、ここでボタンとインジケータを初期状態にします.
        startCaptureButton?.unlock()
        progressBar!!.visibility = View.INVISIBLE
    }

    /**
     * 再撮影時の処理です.
     *
     * @param result   撮影結果
     * @param notifier 通知オブジェクト
     */
    private fun retake(
        @NonNull result: CaptureMResult,
        @NonNull notifier: NextActionNotifier,
        factory: PolarifyKycSdkFactory,
        context: Context
    ) {
        val handler: Handler = object : Handler(Looper.getMainLooper()) {
            override fun handleMessage(msg: Message) {
                if (msg.what == OCR_RETAKE_DIALOG_ID) {
                    showRetakeResult(result, notifier, factory, context)
                }
            }
        }
        handler.sendMessage(handler.obtainMessage(OCR_RETAKE_DIALOG_ID))
    }

    /**
     * OCR実行失敗結果ダイアログを表示します.
     *
     * @param result   書類撮影実行結果
     * @param notifier コールバックオブジェクト
     * @param context  コンテキスト
     */
    private fun showRetakeOcrResult(
        @NonNull result: CaptureResult,
        @NonNull notifier: NextActionNotifier,
        @NonNull context: Context,
        factory: PolarifyKycSdkFactory
    ) {
        if (result.ocrResult == null) {
            // 書類撮影に失敗(手動のケース)
            retake(result as CaptureMResult, notifier, factory, context)
            return
        }
        val message: String = CONTEXT.getString(R.string.MSG_ID_MB010001H)
        // 撮影画面にダイアログを表示するのでresultのアクティビティを使う
        AlertDialog.Builder(result.activity, R.style.DialogStyle)
            .setTitle(R.string.common_error_title)
            .setMessage(message)
            .setCancelable(false)
            .setPositiveButton(
                R.string.ok_dialog_text
            ) { dialog, _ ->
                // 再撮影
                notifier.retake()
                dialog.dismiss()
            }.setNegativeButton(
                R.string.cancel_capture_text
            ) { dialog, _ ->
                factory.getInstance(context).stopCapture()
                dialog.dismiss()
                MainActivity.IS_EKYC_SHOOT_AGAIN_FLAG = true
                TutorialActivity.getResults()
            }.create().show() // ダイアログを生成・表示
    }

    /**
     * 手動撮影時の結果を表示します.
     *
     * @param result   書類撮影実行結果
     * @param notifier コールバックオブジェクト
     */
    private fun showRetakeResult(
        @NonNull result: CaptureMResult,
        @NonNull notifier: NextActionNotifier,
        factory: PolarifyKycSdkFactory,
        context: Context
    ) {
        val message: String = CONTEXT.getString(R.string.MSG_ID_MB010001H)
        // 撮影画面にダイアログを表示するのでresultのアクティビティを使う
        AlertDialog.Builder(result.activity, R.style.DialogStyle)
            .setTitle(R.string.common_error_title)
            .setMessage(message)
            .setCancelable(false)
            .setPositiveButton(
                R.string.ok_dialog_text
            ) { dialog, _ ->
                // 再撮影
                notifier.retake()
                dialog.dismiss()
            }.setNegativeButton(
                R.string.cancel_capture_text
            ) { dialog, _ ->
                factory.getInstance(context).stopCapture()
                dialog.dismiss()
                MainActivity.IS_EKYC_SHOOT_AGAIN_FLAG = true
                TutorialActivity.getResults()
            }.create().show()
    }

    /**
     * OCR処理結果を表示します.
     *
     * @param context コンテキスト
     * @param result  OCR処理結果
     */
    private fun showOcrResult(@NonNull context: Context, @NonNull result: DocumentOcrResult) {
        if (result.ocrResult == null) {
            Log.e(TAG, "OcrResult is null")
            return
        }
        if (result.ocrResult!!.resultCode != OcrResultCode.SUCCESS.getInt()) {
            Log.e(TAG, "OcrResultCode is not success")
            return
        }
        // OCR処理結果を保存する
        // 姓
        PreferenceUtil.setPreferenceStringValue(
            EKYC_INFO_LAST_NAME, result.ocrResult!!.map?.get("lastName").toString()
        )
        // 名
        PreferenceUtil.setPreferenceStringValue(
            EKYC_INFO_FIRST_NAME, result.ocrResult!!.map?.get("firstName").toString()
        )
        // 生年月日
        PreferenceUtil.setPreferenceStringValue(
            EKYC_INFO_BIRTHDATE, CalendarChangeUtil.calendarChange(result.ocrResult!!.map?.get("birthDate").toString())
        )
        // 住所
        PreferenceUtil.setPreferenceStringValue(
            EKYC_INFO_ADDRESS, result.ocrResult!!.map?.get("address").toString()
        )
        // 都道府県
        PreferenceUtil.setPreferenceStringValue(
            EKYC_INFO_ADDRESS1, result.ocrResult!!.map?.get("address1").toString()
        )
        // 市区町村
        PreferenceUtil.setPreferenceStringValue(
            EKYC_INFO_ADDRESS2, result.ocrResult!!.map?.get("address2").toString()
        )
        // 町域
        PreferenceUtil.setPreferenceStringValue(
            EKYC_INFO_ADDRESS3, result.ocrResult!!.map?.get("address3").toString()
        )
        // 郵便番号
        PreferenceUtil.setPreferenceStringValue(
            EKYC_INFO_POSTALCODE, result.ocrResult!!.map?.get("postalCode").toString()
        )
    }

    /**
     * OCRの結果を整形します.
     *
     * @param map OCR処理結果
     * @return OCR処理結果を整形した文字列
     */
    @NonNull
    private fun mapToString(@NonNull map: Map<*, *>?): String {
        val str = map.toString()
        return str.replace(",", "\n")
    }

    /**
     * エラーダイアログを表示します.
     *
     * @param context コンテキスト
     * @param result  エラー
     */
    fun showErrorDialog(@NonNull context: Context?, @NonNull result: ErrorResult, factory: PolarifyKycSdkFactory) {
        val message = CONTEXT.getString(R.string.MSG_ID_MB010001H)
        Handler().postDelayed({
            AlertDialog.Builder(context, R.style.DialogStyle)
                .setTitle(R.string.common_error_title)
                .setMessage(message)
                .setCancelable(false)
                .setPositiveButton(
                    R.string.ok_dialog_text,
                    DialogInterface.OnClickListener { dialog, _ ->
                        // ダイアログを非表示にする
                        dialog.dismiss()
                        if (result.equals(ErrorResult.TIMEOUT_ERROR)) {
                            // タイムアウトした場合はOKを押すと再撮影開始
                            startCapture()
                            return@OnClickListener
                        }
                    }
                ).setNegativeButton(
                    R.string.cancel_capture_text
                ) { dialog, _ ->
                    if (context != null) {
                        factory.getInstance(context).stopCapture()
                    }
                    dialog.dismiss()
                    MainActivity.IS_EKYC_SHOOT_AGAIN_FLAG = true
                    TutorialActivity.getResults()
                }.create().show()
        }, DELAY_TIME)
    }

    companion object {
        /**
         * ログのタグ.
         */
        private val TAG = DocumentCaptureTutorialFragment::class.java.name

        /**
         * フラグメントリプレスメッセージ ID.
         */
        const val FRAGMENT_REPLACE_ID = 1001

        /**
         * OCR後の再撮影するかどうかの確認ダイアログに切り替えるメッセージID.
         */
        const val OCR_RETAKE_DIALOG_ID = 1000

        /**
         * カメラ要求コード
         */
        private const val PERMISSION_REQUEST_CAMERA = 100

        /**
         * メッセージ表示領域の高さ.
         */
        private const val CONTENTS = 80

        /**
         * ダイアログ表示遅延時間(単位 ミリ秒).
         */
        private const val DELAY_TIME: Long = 1000
    }
}

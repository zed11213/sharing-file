package jp.co.jsbank.mb.bankingapp.fragment

import android.os.Message
import androidx.annotation.NonNull
import androidx.fragment.app.Fragment

/**
 * アクティビティの状態に依存せず切り替えられるフラグメントの抽象基底クラスです.
 * アクティビティがポーズ中にフラグメント切り替えを実行しないようにメッセージをキューイングします。
 */
abstract class SmartReplaceableFragment : Fragment() {
    /**
     * ポーズ中にメッセージをキューイングするハンドラ.
     */
    private val handler: PauseHandler = PauseHandler(
        javaClass,
        object : PauseHandler.Callback {
            override fun processMessage(@NonNull message: Message?) {
                this@SmartReplaceableFragment.processMessage(message)
            }
        }
    )

    override fun onPause() {
        super.onPause()
        handler.pause()
    }

    override fun onResume() {
        super.onResume()
        handler.resume()
    }

    /**
     * メッセージをキューイングします.
     *
     * @param what メッセージ ID
     */
    protected fun sendMessage(what: Int) {
        val message: Message = handler.obtainMessage(what)
        handler.sendMessage(message)
    }

    /**
     * ポーズ状態から解除されたとき、キューイングされていた個々のメッセージの処理を行います.
     *
     * @param message 処理対象メッセージ
     */
    protected abstract fun processMessage(@NonNull message: Message?)

    /**
     * ハンドラに送られたメッセージを削除します.
     */
    fun clearMessage() {
        handler.clearMessage()
    }
}

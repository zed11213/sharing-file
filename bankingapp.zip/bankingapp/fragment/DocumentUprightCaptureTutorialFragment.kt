package jp.co.jsbank.mb.bankingapp.fragment

import android.util.DisplayMetrics
import android.view.View
import android.widget.ImageView
import androidx.annotation.NonNull
import jp.co.jsbank.mb.bankingapp.R

/**
 * 書類正面撮影のチュートリアル画面のフラグメントクラスです.
 */
abstract class DocumentUprightCaptureTutorialFragment : DocumentCaptureTutorialFragment() {
    /**
     * ビューの初期設定を行います.
     *
     * @param root ルートビュー
     */
    override fun initializeViews(@NonNull root: View) {
        super.initializeViews(root)
        val dm: DisplayMetrics = resources.displayMetrics
        val width = dm.widthPixels
        val imageView = root.findViewById<ImageView>(R.id.tutorial_gif)
        imageView.setPadding(width / 3, 0, 0, 0)
    }
}

package jp.co.jsbank.mb.bankingapp.fragment

import android.graphics.Bitmap
import android.os.Bundle
import androidx.annotation.NonNull
import androidx.fragment.app.Fragment
import jp.co.jsbank.mb.bankingapp.fragment.helper.DocumentFaceCropper
import jp.co.jsbank.mb.bankingapp.fragment.helper.FaceCropper
import jp.co.jsbank.mb.bankingapp.system.ekyc.BundleKeyDefinitions.APP_KEY_DIRECT_START_CAPTURE
import jp.co.jsbank.mb.bankingapp.system.ekyc.TutorialActivity
import jp.co.jsbank.mb.bankingapp.system.master.DocumentKind
import jp.co.jsbank.mb.bankingapp.system.master.EkycCard
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil
import jp.co.jsbank.mb.bankingapp.utils.PreferenceUtil
import jp.co.polarify.onboarding.sdk.types.common.DocumentType

/**
 * 書類表の撮影の確認を行うフラグメントです.
 */
class DocumentFrontConfirmationFragment : DocumentUprightConfirmationFragment() {
    /**
     * 撮影を行う書類種別を取得します.
     *
     * @param documentKind 本人確認書類種類
     * @return 撮影を行う書類種別
     */
    @NonNull
    override fun getDocumentType(@NonNull documentKind: DocumentKind?): DocumentType {
        return when (documentKind) {
            DocumentKind.DRIVER_LICENSE_CARD_OCR -> DocumentType.FRONTOCR
            DocumentKind.MY_NUMBER_CARD_OCR -> DocumentType.FRONTMOCR
            else -> DocumentType.FRONT
        }
    }

    @get:NonNull
    override val previousFragment: Fragment
        get() {
            val fragment: Fragment = DocumentFrontCaptureTutorialFragment()
            val arguments = Bundle()
            arguments.putBoolean(APP_KEY_DIRECT_START_CAPTURE, true)
            fragment.arguments = arguments
            return fragment
        }

    /**
     * 顔切り出しオブジェクトを生成します.
     *
     * @return 生成した顔切り出しオブジェクト
     */
    override fun createFaceCropper(): FaceCropper<DocumentConfirmationFragment?> {
        return DocumentFaceCropper(this)
    }

    /**
     * 次に表示するフラグメントを取得します.
     *
     * @return 取得したフラグメント
     */
    @get:NonNull
    override val nextFragment: Fragment
        get() = if (PreferenceUtil.getPreferenceStringValue(ConstUtil.EKYC_CARD_TYPE) == EkycCard.MEMBER.toString()) {
            DocumentTiltedCaptureTutorialFragment()
        } else {
            DocumentBackCaptureTutorialFragment()
        }

    /**
     * アクティビティから書類画像を取得します.
     *
     * @param activity アクティビティ
     * @return 取得した書類画像
     */
    override fun getDocumentImage(activity: TutorialActivity?): Bitmap? {
        return activity?.frontDocumentImage
    }

    /**
     * アクティビティから補正済み書類画像を取得します.
     *
     * @param activity アクティビティ
     * @return 取得した補正済み書類画像
     */
    override fun getCorrectedImage(activity: TutorialActivity?): Bitmap? {
        return activity?.frontCorrectedImage
    }
}

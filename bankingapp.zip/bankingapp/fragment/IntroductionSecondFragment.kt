package jp.co.jsbank.mb.bankingapp.fragment

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.annotation.NonNull
import androidx.annotation.Nullable
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.system.ekyc.BundleKeyDefinitions
import jp.co.jsbank.mb.bankingapp.system.ekyc.TutorialActivity

/**
 * イントロダクション画面を生成フラグメントです.
 */
class IntroductionSecondFragment : Fragment(), BundleKeyDefinitions {
    @Nullable
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val introductionContainer = container?.findViewById<FrameLayout>(R.id.introduction_container)
        return inflater.inflate(R.layout.document_introduction_second, introductionContainer, false)
    }

    override fun onViewCreated(@NonNull view: View, @Nullable savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val gifMovie: Int = R.raw.drive_license_random
        val imageView = view.findViewById<ImageView>(R.id.introduction_gif)
        Glide.with(this).load(gifMovie).into(imageView)

        // 表面の撮影をするボタン
        val nextButton = view.findViewById<Button>(R.id.start_capture_button)
        nextButton.setOnClickListener { onStartCaptureButtonClick() }
    }

    /**
     * 「まずは表面の撮影をする」ボタンタップ処理.
     */
    private fun onStartCaptureButtonClick() {
        val intent = Intent(context, TutorialActivity::class.java)
        startActivity(intent)
    }
}

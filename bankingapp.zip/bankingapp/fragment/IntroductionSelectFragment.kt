package jp.co.jsbank.mb.bankingapp.fragment

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RadioGroup
import androidx.annotation.NonNull
import androidx.annotation.Nullable
import androidx.fragment.app.Fragment
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.system.ekyc.BundleKeyDefinitions
import jp.co.jsbank.mb.bankingapp.system.ekyc.BundleKeyDefinitions.*
import jp.co.jsbank.mb.bankingapp.system.ekyc.IntroductionActivity
import jp.co.jsbank.mb.bankingapp.system.master.DocumentKind
import jp.co.jsbank.mb.bankingapp.ui.widgets.common.SafetyButton
import jp.co.jsbank.mb.bankingapp.utils.PreferenceManagerUtil

/**
 * 撮影方法の選択を行うイントロダクション画面を生成するフラグメントです.
 */
class IntroductionSelectFragment : Fragment(), BundleKeyDefinitions {
    /**
     * 自動・手動切替用ラジオグループ.
     */
    private var modeRadio: RadioGroup? = null

    /**
     * ユーザーキャンセル切替用ラジオグループ.
     */
    private var userCancelRadio: RadioGroup? = null

    /**
     * 書類種別切替用ラジオグループ.
     */
    private var typeRadio: RadioGroup? = null

    @Nullable
    override fun onCreateView(
        @NonNull inflater: LayoutInflater,
        @Nullable container: ViewGroup?,
        @Nullable savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.document_introduction_select, container, false)
    }

    override fun onViewCreated(@NonNull view: View, @Nullable savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initializeLayout(view)
        // 次へ進むボタン
        val button: SafetyButton = view.findViewById(R.id.config_next_button)
        button.setOnClickListener {
            val intent = Intent(context, IntroductionActivity::class.java)

            // 書類種別の設定
            setCaptureConfig()
            intent.putExtra(
                IntroductionActivity.KEY_INTRODUCTION_TYPE,
                IntroductionActivity.IntroductionType.SECOND
            )
            Log.d(TAG, "send IntroductionActivity start intent")
            startActivity(intent)
        }
    }

    /**
     * UIの初期化を行います.
     *
     * @param view ビュー
     */
    private fun initializeLayout(@NonNull view: View) {
        userCancelRadio = view.findViewById(R.id.user_cancel_radio_group)
        typeRadio = view.findViewById(R.id.type_radio_group)
    }

    /**
     * 自動/手動と書類種別の設定を行います.
     */
    private fun setCaptureConfig() {
        context?.let { PreferenceManagerUtil.putBoolean(it, APP_KEY_IS_MANUAL, true) }
        context?.let { PreferenceManagerUtil.putBoolean(it, APP_KEY_USER_CANCEL, false) }
        when (typeRadio!!.checkedRadioButtonId) {
            R.id.driver_license_card_ocr -> context?.let {
                PreferenceManagerUtil.putInt(
                    it,
                    APP_KEY_CAPTURE_KIND,
                    DocumentKind.DRIVER_LICENSE_CARD_OCR.ordinal
                )
            }
            R.id.my_number_card_ocr -> context?.let {
                PreferenceManagerUtil.putInt(
                    it,
                    APP_KEY_CAPTURE_KIND,
                    DocumentKind.MY_NUMBER_CARD_OCR.ordinal
                )
            }
            else -> {
                Log.e(TAG, "Invalid Type.")
                context?.let {
                    PreferenceManagerUtil.putInt(
                        it,
                        APP_KEY_CAPTURE_KIND,
                        DocumentKind.DRIVER_LICENSE_CARD_OCR.ordinal
                    )
                }
            }
        }
    }

    companion object {
        /**
         * ログのタグ.
         */
        private val TAG = IntroductionSelectFragment::class.java.name
    }
}

package jp.co.jsbank.mb.bankingapp.fragment

import android.graphics.drawable.Drawable
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.annotation.NonNull
import androidx.annotation.Nullable
import androidx.annotation.RawRes
import androidx.fragment.app.FragmentActivity
import com.bumptech.glide.Glide
import com.bumptech.glide.load.DataSource
import com.bumptech.glide.load.engine.GlideException
import com.bumptech.glide.load.resource.gif.GifDrawable
import com.bumptech.glide.request.RequestListener
import com.bumptech.glide.request.target.Target
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.system.ekyc.TutorialActivity
import jp.co.polarify.onboarding.sdk.types.result.GetMatchingIDResult

/**
 * チュートリアル画面を生成フラグメントです.
 */
abstract class TutorialFragment : SmartReplaceableFragment() {
    /**
     * 照合用 ID を取得します。
     *
     * @return 取得した照合用 ID
     */
    /**
     * 照合用 ID.
     */
    @get:Nullable
    protected var matchingIDResult: GetMatchingIDResult? = null
        private set

    override fun onCreate(@Nullable savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val activity: FragmentActivity? = activity
        if (activity !is TutorialActivity) {
            Log.e(TAG, "Cannot get TutorialActivity")
            return
        }
        val tutorialActivity: TutorialActivity = activity
        matchingIDResult = tutorialActivity.matchingIDResult
    }

    @Nullable
    override fun onCreateView(
        @NonNull inflater: LayoutInflater,
        @Nullable container: ViewGroup?,
        @Nullable savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_tutorial, container, false)
    }

    /**
     * Glide でGIF を表示させます.
     *
     * @param resource GIF ファイルのリソース
     */
    fun setGifByGlide(@RawRes resource: Int) {
        Glide.with(this).load(resource).listener(object : RequestListener<Drawable?> {
            /**
             * 画像の読み込み失敗時に呼び出されます.
             */
            override fun onLoadFailed(
                e: GlideException?,
                model: Any?,
                target: Target<Drawable?>?,
                isFirstResource: Boolean
            ): Boolean {
                return false
            }

            /**
             * 画像の読み込み成功時に呼び出されます.
             */
            override fun onResourceReady(
                @NonNull resource: Drawable?,
                @NonNull model: Any,
                @NonNull target: Target<Drawable?>,
                @NonNull dataSource: DataSource,
                isFirstResource: Boolean
            ): Boolean {
                return if (resource !is GifDrawable) {
                    false
                } else {
                    resource.setLoopCount(1)
                    false
                }
            }
        }).into(view?.findViewById(R.id.tutorial_gif) as ImageView)
    }

    companion object {
        /**
         * ログのタグ.
         */
        private val TAG = TutorialFragment::class.java.name
    }
}

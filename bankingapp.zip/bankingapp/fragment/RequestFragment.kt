package jp.co.jsbank.mb.bankingapp.fragment

import android.app.AlertDialog
import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ProgressBar
import androidx.annotation.IdRes
import androidx.annotation.LayoutRes
import androidx.annotation.NonNull
import androidx.annotation.Nullable
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.system.ekyc.TutorialActivity
import jp.co.jsbank.mb.bankingapp.ui.widgets.common.SafetyButton
import jp.co.polarify.onboarding.sdk.PolarifyKycSdkFactory
import jp.co.polarify.onboarding.sdk.types.callback.DeleteMatchingDataCallback
import jp.co.polarify.onboarding.sdk.types.callback.GetFaceVerificationCallback
import jp.co.polarify.onboarding.sdk.types.internal.BundleKeyDefinitions
import jp.co.polarify.onboarding.sdk.types.internal.ErrorResult
import jp.co.polarify.onboarding.sdk.types.paramters.MatchingParameters
import jp.co.polarify.onboarding.sdk.types.result.GetMatchingIDResult
import jp.co.polarify.onboarding.sdk.types.result.VerificationResults
import kotlin.jvm.internal.Intrinsics

/**
 * 申し込み確認画面を生成フラグメントです.
 */
abstract class RequestFragment(@field:LayoutRes @param:LayoutRes private val layoutId: Int) :
    Fragment(),
    BundleKeyDefinitions {
    /**
     * 申し込みボタン.
     */
    private var requestButton: SafetyButton? = null

    /**
     * 次へ進む時ネット通信Progress.
     */
    private var progressBar: ProgressBar? = null

    /**
     * 照合用 ID.
     */
    @Nullable
    private var matchingIDResult: GetMatchingIDResult? = null

    /**
     * フラグメントの置き換えフラグ TODO:暫定対応
     */
    private var isCalled = false

    @Nullable
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val requestContainer = container?.findViewById<FrameLayout>(R.id.fragment_container)
        val rootView = inflater.inflate(layoutId, requestContainer, false)
        setCapturedPhoto(rootView)
        return rootView
    }

    override fun onViewCreated(@NonNull view: View, @Nullable savedInstanceState: Bundle?) {
        Intrinsics.checkParameterIsNotNull(view, "view")
        super.onViewCreated(view, savedInstanceState)
        assignMatchingIdResult()
        // プログレスバーの取得
        progressBar = view.findViewById(progressBarId)
        // 申し込みボタンの取得
        requestButton = view.findViewById(requestButtonId)
        requestButton?.setOnClickListener {
            progressBar?.visibility = View.VISIBLE
            faceVerification
        }
    }

    /**
     * プログレスバーのリソース ID を取得します.
     *
     * @return 取得したプログレスバーのリソース ID
     */
    @get:IdRes
    protected abstract val progressBarId: Int

    /**
     * 申し込みボタンのリソース ID を取得します.
     *
     * @return 取得した申し込みボタンのリソース ID
     */
    @get:IdRes
    protected abstract val requestButtonId: Int

    /**
     * 照合用 ID の設定を行います.
     */
    private fun assignMatchingIdResult() {
        val activity: TutorialActivity = tutorialActivity ?: return
        matchingIDResult = activity.matchingIDResult
        if (matchingIDResult == null) {
            Log.e(TAG, "Cannot get GetMatchingIDResult")
        }
    }

    /**
     * 撮影画像をセットします.
     *
     * @param rootView ルートビュー
     */
    protected abstract fun setCapturedPhoto(@NonNull rootView: View?)

    /**
     * 照合要求処理を開始します.
     */
    private val faceVerification: Unit
        get() {
            val parameter = MatchingParameters(matchingIDResult!!)
            val factory = PolarifyKycSdkFactory()
            context?.let {
                factory.getInstance(it).getFaceVerification(
                    parameter,
                    object : GetFaceVerificationCallback {
                        override fun onSuccess(@NonNull results: VerificationResults) {
                            Log.d(TAG, "getFaceVerification is onSuccess")
                            Handler().postDelayed({
                                // 成功ダイアログを表示
                                showSuccessDialog(results)
                            }, DELAY_TIME)
                            requestButton?.unlock()
                            progressBar!!.visibility = View.INVISIBLE
                        }

                        override fun onError(@NonNull errorResult: ErrorResult) {
                            Log.e(TAG, "getFaceVerification is Error. code = " + errorResult.code)
                            Handler().postDelayed({ showErrorDialog(errorResult) }, DELAY_TIME)
                            requestButton?.unlock()
                            progressBar!!.visibility = View.INVISIBLE
                        }
                    }
                )
            }
        }

    /**
     * 成功ダイアログを表示します.
     *
     * @param results 検証結果
     */
    protected fun showSuccessDialog(@NonNull results: VerificationResults) {
        val message = getSuccessMessage(results)
        AlertDialog.Builder(context, R.style.DialogStyle)
            .setTitle("Result")
            .setMessage(message)
            .setPositiveButton("OK") { _, _ -> deleteFace() }.create()
            .show()
    }

    /**
     * 成功ダイアログに表示するメッセージ文字列を取得します.
     *
     * @param results 検証結果
     * @return 取得したメッセージ文字列
     */
    @NonNull
    private fun getSuccessMessage(@NonNull results: VerificationResults): String {
        val builder = StringBuilder()
        val list = results.list
        for (element in list) {
            val type = element.type
            val result = element.verificationResult
            val message = "type:$type\nresult:$result\n"
            builder.append(message)
        }
        return builder.toString()
    }

    /**
     * TutorialActivity のインスタンスを取得します.
     *
     * @return 取得した TutorialActivity インスタンス。インスタンスが存在しない場合は null を返します。
     */
    @get:Nullable
    protected val tutorialActivity: TutorialActivity?
        get() {
            val activity: FragmentActivity? = activity
            if (activity !is TutorialActivity) {
                Log.e(TAG, "Cannot get TutorialActivity")
                return null
            }
            return activity
        }

    /**
     * サーバの顔画像を削除します.
     */
    private fun deleteFace() {
        val parameters = MatchingParameters(matchingIDResult!!)
        val context: Context? = this.context
        if (context == null) {
            Intrinsics.throwNpe()
        }
        val factory = PolarifyKycSdkFactory()
        if (context != null) {
            factory.getInstance(context).deleteMatchingData(
                parameters,
                object : DeleteMatchingDataCallback {
                    override fun onSuccess() {
                        val message = "deleteMatchingData is onSuccess"
                        Log.d(TAG, message)
                        replaceFragment()
                        requestButton?.unlock()
                        progressBar!!.visibility = View.INVISIBLE
                    }

                    override fun onError(@NonNull result: ErrorResult) {
                        Intrinsics.checkParameterIsNotNull(result, "result")
                        val message = "deleteMatchingData is onError. code = " + result.code
                        Log.e(TAG, message)
                        replaceFragment()
                        requestButton?.unlock()
                        progressBar!!.visibility = View.INVISIBLE
                    }
                }
            )
        }
    }

    /**
     * フラグメントを置き換えます.
     */
    private fun replaceFragment() {
        if (isCalled) {
            isCalled = false
            return
        }
        // プログレスエリアを消すために現在のViewから親の親まで取得し、VisibilityをOFFにする
        val parent = view?.parent?.parent as ViewGroup
        val progressArea = parent.findViewById<View>(R.id.progress_container)
        if (progressArea == null) {
            Log.e(TAG, "Cannot get View")
            return
        }
        progressArea.visibility = View.GONE
        val manager: FragmentManager? = getFragmentManager()
        if (manager == null) {
            Log.e(TAG, "Cannot get FragmentManager")
            return
        }
        val transaction: FragmentTransaction = manager.beginTransaction()
        transaction.addToBackStack(null)
        transaction.replace(R.id.fragment_container, RequestResultFragment())
        transaction.commit()
        isCalled = true
    }

    /**
     * エラーダイアログを表示します.
     *
     * @param result エラー
     */
    fun showErrorDialog(@NonNull result: ErrorResult) {
        val message = result.message
        AlertDialog.Builder(activity, R.style.DialogStyle)
            .setTitle(R.string.common_error_title)
            .setMessage(message)
            .setCancelable(false)
            .setPositiveButton(
                R.string.ok_dialog_text
            ) { dialog, _ ->
                dialog.dismiss()
            }.create().show()
    }

    companion object {
        /**
         * ログのタグ.
         */
        private val TAG = RequestFragment::class.java.name

        /**
         * ダイアログ表示遅延時間(単位 ミリ秒).
         */
        private const val DELAY_TIME: Long = 1000
    }
}

package jp.co.jsbank.mb.bankingapp.fragment

import android.graphics.Bitmap
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.annotation.NonNull
import androidx.fragment.app.Fragment
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.fragment.helper.NullFaceCropper
import jp.co.jsbank.mb.bankingapp.system.ekyc.BundleKeyDefinitions.APP_KEY_DIRECT_START_CAPTURE
import jp.co.jsbank.mb.bankingapp.system.ekyc.TutorialActivity
import jp.co.jsbank.mb.bankingapp.system.master.DocumentKind
import jp.co.polarify.onboarding.sdk.types.common.DocumentType

/**
 * 書類裏の撮影の確認を行うフラグメントです.
 */
open class DocumentBackConfirmationFragment : DocumentUprightConfirmationFragment() {

    /**
     * 撮影を行う書類種別を取得します.
     *
     * @param documentKind 本人確認書類種類
     * @return 撮影を行う書類種別
     */
    @NonNull
    override fun getDocumentType(@NonNull documentKind: DocumentKind?): DocumentType {
        return when (documentKind) {
            DocumentKind.DRIVER_LICENSE_CARD_OCR -> DocumentType.BACK
            DocumentKind.MY_NUMBER_CARD_OCR -> DocumentType.BACKM
            else -> DocumentType.BACK
        }
    }

    /**
     * 確認画面の文言メッセージを表示します.
     *
     * @param view ビュー
     */
    override fun showConfirmationMessage(view: View?) {
        val message = view?.findViewById<TextView>(R.id.confirmation_message)
        if (message != null) {
            message.setText(R.string.document_confirmation_back)
            message.visibility = View.VISIBLE
        }
    }

    @get:NonNull
    override val previousFragment: Fragment
        get() {
            val fragment: Fragment = DocumentBackCaptureTutorialFragment()
            val arguments = Bundle()
            arguments.putBoolean(APP_KEY_DIRECT_START_CAPTURE, true)
            fragment.arguments = arguments
            return fragment
        }

    /**
     * 顔切り出しオブジェクトを生成します.
     *
     * @return 生成した顔切り出しオブジェクト
     */
    override fun createFaceCropper(): NullFaceCropper {
        // 裏面には顔画像は無いので、何もしない顔切り出しオブジェクトを生成
        return NullFaceCropper(this)
    }

    /**
     * 次に表示するフラグメントを取得します.
     *
     * @return 取得したフラグメント
     */
    @get:NonNull
    override val nextFragment: Fragment
        get() = DocumentTiltedCaptureTutorialFragment()

    /**
     * アクティビティから書類画像を取得します.
     *
     * @param activity アクティビティ
     * @return 取得した書類画像
     */
    override fun getDocumentImage(activity: TutorialActivity?): Bitmap? {
        return activity?.backDocumentImage
    }

    /**
     * アクティビティから補正済み書類画像を取得します.
     *
     * @param activity アクティビティ
     * @return 取得した補正済み書類画像
     */
    override fun getCorrectedImage(activity: TutorialActivity?): Bitmap? {
        return activity?.backDocumentImage
    }
}

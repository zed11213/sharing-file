package jp.co.jsbank.mb.bankingapp.fragment

import android.app.AlertDialog
import android.content.Context
import android.content.DialogInterface
import android.graphics.Bitmap
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.ViewTreeObserver
import android.view.animation.AnimationUtils
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.ProgressBar
import androidx.annotation.IdRes
import androidx.annotation.NonNull
import androidx.annotation.Nullable
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.system.MyApp
import jp.co.jsbank.mb.bankingapp.system.ekyc.BundleKeyDefinitions
import jp.co.jsbank.mb.bankingapp.system.ekyc.BundleKeyDefinitions.APP_KEY_DIRECT_START_CAPTURE
import jp.co.jsbank.mb.bankingapp.system.ekyc.TutorialActivity
import jp.co.jsbank.mb.bankingapp.system.master.EkycResult
import jp.co.jsbank.mb.bankingapp.ui.widgets.common.SafetyButton
import jp.co.jsbank.mb.bankingapp.utils.*
import jp.co.polarify.onboarding.sdk.PolarifyKycSdkFactory
import jp.co.polarify.onboarding.sdk.types.callback.SelfieCaptureCallback
import jp.co.polarify.onboarding.sdk.types.callback.UserCancelableSelfieCaptureCallback
import jp.co.polarify.onboarding.sdk.types.internal.ErrorResult
import jp.co.polarify.onboarding.sdk.types.internal.UserCancelNotifier
import jp.co.polarify.onboarding.sdk.types.paramters.MatchingParameters
import jp.co.polarify.onboarding.sdk.types.result.FaceCaptureResult
import jp.co.polarify.onboarding.sdk.types.result.GetMatchingIDResult
import jp.co.polarify.onboarding.sdk.types.result.UserCancelResult

/**
 * セルフィの撮影確認を行うフラグメントです.
 */
class SelfieConfirmationFragment : SmartReplaceableFragment() {
    /**
     * 登録を始めるボタンです.
     */
    private var nextButton: SafetyButton? = null

    /**
     * セルフィー画像登録オブジェクト.
     */
    @Nullable
    private var selfieRegister: SelfieRegister? = null

    /**
     * 次へ進む時ネット通信Progress.
     */
    private var progressBar: ProgressBar? = null

    @Nullable
    override fun onCreateView(
        @NonNull inflater: LayoutInflater,
        @Nullable container: ViewGroup?,
        @Nullable savedInstanceState: Bundle?
    ): View? {
        if (container == null) {
            Log.e(TAG, "container is null")
            return null
        }

        // セルフィー画像登録オブジェクトの生成
        selfieRegister = SelfieRegister(this)
        val tutorialContainer = container.findViewById<FrameLayout>(R.id.fragment_container)
        return inflater.inflate(R.layout.selfie_confirmation_preview, tutorialContainer, false)
    }

    override fun onViewCreated(@NonNull view: View, @Nullable savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        showConfirmationPreview(view)
        val confirmationPreview = view.findViewById<View>(R.id.selfie_confirmation_preview)
        confirmationPreview.viewTreeObserver.addOnGlobalLayoutListener(object :
                ViewTreeObserver.OnGlobalLayoutListener {
                override fun onGlobalLayout() {
                    // ViewTreeObserver は毎回取得しないといけない
                    confirmationPreview.viewTreeObserver.removeOnGlobalLayoutListener(this)
                }
            })

        // 次へ進むボタン
        nextButton = view.findViewById(R.id.next_button_id)
        progressBar = view.findViewById(R.id.waiting_progress_bar_id)
        nextButton?.setOnClickListener {
//            val manager: FragmentManager? = getFragmentManager()
//            if (manager == null) {
//                val message = "Cannot get FragmentManager"
//                Log.e(TAG, message)
//                throw IllegalStateException(message)
//            }
//            // フラグメント切り替えトランザクションの取得
//            val transaction: FragmentTransaction = manager.beginTransaction()
//            // 次に表示するフラグメントを取得
//            val fragment: Fragment = nextFragment
//            transaction.replace(R.id.fragment_container, fragment)
//            val progressAreaFragment: Fragment = nextProgressAreaFragment
//            transaction.replace(R.id.progress_container, progressAreaFragment)
//            val parent = view.parent?.parent as ViewGroup
//            val progressArea = parent.findViewById<View>(R.id.progress_container)
//            progressArea!!.visibility = View.GONE
//            transaction.commit()
            doOnNext()
        }

        // 撮り直しボタン
        val retakeButton = view.findViewById<Button>(R.id.selfie_photo_retake)
        retakeButton.setOnClickListener {
            // 前のフラグメントに戻る
            replacePreviousFragment()
        }
        replaceSelfieProgressAreaFragment()
    }

    /**
     * アクテイビティが持つセルフィー画像を取得します.
     *
     * @param activity アクティビティ
     * @return 取得したセルフィー画像
     */


    /**
     * アクテイビティが持つセルフィー画像を取得します.
     *
     * @param activity アクティビティ
     * @return 取得したまばたき画像
     */
    @Nullable
    private fun getLivenessImage(@NonNull activity: TutorialActivity): Bitmap? {
        return activity.livenessImage
    }

    /**
     * アクテイビティが持つ書類表画像を取得します.
     *
     * @param activity アクティビティ
     * @return 取得したセルフィー画像
     */
    @Nullable
    private fun getFrontDocumentImage(@NonNull activity: TutorialActivity): Bitmap? {
        return activity.frontDocumentImage
    }

    /**
     * アクテイビティが持つ書類斜め画像を取得します.
     *
     * @param activity アクティビティ
     * @return 取得したセルフィー画像
     */
    @Nullable
    private fun getTiltedDocumentImage(@NonNull activity: TutorialActivity): Bitmap? {
        return activity.tiltedDocumentImage
    }

    /**
     * アクテイビティが持つ書類斜め画像を取得します.
     *
     * @param activity アクティビティ
     * @return 取得したセルフィー画像
     */
    @Nullable
    private fun getBackDocumentImage(@NonNull activity: TutorialActivity): Bitmap? {
        return activity.backDocumentImage
    }


    /**
     * セルフィー画像をビューにセットします.
     *
     * @param activity アクティビティ
     */
    private fun setSelfieImage(@NonNull activity: TutorialActivity) {
        val image = getSelfieImage(activity)
        if (image != null) {
            PreferenceUtil.setPreferenceStringValue(ConstUtil.EKYC_IMAGE_SELF, bitmapToBase64(image))
        }
    }

    /**
     * まばたき画像をビューにセットします.
     *
     * @param activity アクティビティ
     */
    private fun setLivenessImage(@NonNull activity: TutorialActivity) {
        val image = getLivenessImage(activity)
        if (image != null) {
            PreferenceUtil.setPreferenceStringValue(ConstUtil.EKYC_IMAGE_LIVENESS, bitmapToBase64(image))
        }
    }

    /**
     * 書類表画像をビューにセットします.
     *
     * @param activity アクティビティ
     */
    private fun setFrontDocumentImage(@NonNull activity: TutorialActivity) {
        val image = getFrontDocumentImage(activity)
        if (image != null) {
            PreferenceUtil.setPreferenceStringValue(ConstUtil.EKYC_IMAGE_FRONT, bitmapToBase64(image))
        }
    }

    /**
     * 書類斜め画像をビューにセットします.
     *
     * @param activity アクティビティ
     */
    private fun setTiltedDocumentImage(@NonNull activity: TutorialActivity) {
        val image = getTiltedDocumentImage(activity)
        if (image != null) {
            PreferenceUtil.setPreferenceStringValue(ConstUtil.EKYC_IMAGE_TILTED, bitmapToBase64(image))
        }
    }

    /**
     * 書類裏画像をビューにセットします.
     *
     * @param activity アクティビティ
     */
    private fun setBackDocumentImage(@NonNull activity: TutorialActivity) {
        val image = getBackDocumentImage(activity)
        if (image != null) {
            PreferenceUtil.setPreferenceStringValue(ConstUtil.EKYC_IMAGE_BACK, bitmapToBase64(image))
        }
    }

    /**
     * TutorialActivity のインスタンスを取得します.
     *
     * @return 取得した TutorialActivity のインスタンス
     */

    private fun doOnNext() {
        setSelfieImage(tutorialActivity!!)
        setLivenessImage(tutorialActivity!!)
        setFrontDocumentImage(tutorialActivity!!)
        setTiltedDocumentImage(tutorialActivity!!)
        setBackDocumentImage(tutorialActivity!!)

        MainActivity.IS_EKYC_SHOOT_AGAIN_FLAG = false
        TutorialActivity.getResults()

        // EKYC確認結果を保存する
        PreferenceUtil.setPreferenceStringValue(ConstUtil.EKYC_RESULT, EkycResult.OK.code)
    }

    /**
     * 確認画面を表示します.
     *
     * @param root ルートビュー
     */
    private fun showConfirmationPreview(@NonNull root: View) {
        Handler(Looper.getMainLooper()).postDelayed({
            val imageView = root.findViewById<ImageView>(R.id.captured_photo)
            val image = selfieImage
            imageView.setImageBitmap(image)

            val parent = view?.parent?.parent as ViewGroup
            val progressArea = parent.findViewById<View>(R.id.progress_container)
            progressArea!!.visibility = View.VISIBLE
        }, DELAY_BEFORE_TASK_TIME)

        // 確認画面を左側からスライドさせます
        val context: Context? = context
        val slideLeft = AnimationUtils.loadAnimation(context, jp.co.polarify.onboarding.sdk.R.anim.slide_left)
        val constraintLayout: ConstraintLayout = root.findViewById(R.id.selfie_confirmation_preview)
        constraintLayout.startAnimation(slideLeft)
    }

    /**
     * 前のフラグメントに戻ります.
     */
    private fun replacePreviousFragment() {
        val manager: FragmentManager? = getFragmentManager()
        if (manager == null) {
            val message = "Cannot get FragmentManager"
            Log.e(TAG, message)
            throw IllegalStateException(message)
        }
        val fragment: Fragment = previousFragment
        val transaction: FragmentTransaction = manager.beginTransaction()
        transaction.replace(R.id.fragment_container, fragment).commit()
    }

    /**
     * 次に表示するフラグメントに切り替えます.
     */
    private fun replaceNextFragment() {
        TutorialActivity.getResults()
    }

    /**
     * ライブネス撮影開始要求をします.
     */
    fun startLiveness() {
        startLiveness(requireContext(), matchingIdResult)
    }

    /**
     * ライブネス撮影を開始します.
     *
     * @param context コンテキスト
     * @param result  マッチング ID
     */
    private fun startLiveness(@NonNull context: Context, @NonNull result: GetMatchingIDResult?) {
        val parameter = MatchingParameters(result!!)
        val isUserCancel: Boolean = PreferenceManagerUtil.getBoolean(context, BundleKeyDefinitions.APP_KEY_USER_CANCEL)
        if (isUserCancel) {
            userCancelableStartLiveness(context, parameter)
            return
        }
        noUserCancelableStartLiveness(context, parameter)
    }

    /**
     * ユーザーキャンセルありのライブネス撮影を行います.
     *
     * @param context   コンテキスト
     * @param parameter パラメータオブジェクト
     */
    private fun userCancelableStartLiveness(@NonNull context: Context, @NonNull parameter: MatchingParameters) {
        val factory = PolarifyKycSdkFactory()
        factory.getInstance(context).startSelfie(
            parameter,
            object : UserCancelableSelfieCaptureCallback {
                override fun onUserCancel(@NonNull result: UserCancelResult, @NonNull notifier: UserCancelNotifier) {
//                    val message = "startLiveness.onUserCancel is called."
//                    // Toast.showLong(context, message)
//                    Log.d(TAG, message)
//                    when (result.type) {
//                        CancelType.BACK_KEY,
//                        CancelType.PROGRESS_BUTTON -> showUserCancelDialog(result.activity, notifier)
//                        CancelType.TIMEOUT -> showTimeoutDialog(result.activity, notifier)
//                    }
                }

                override fun onSuccess(@NonNull result: FaceCaptureResult) {
                    val message = "startLiveness is onSuccess"
                    Log.d(TAG, message)
                    sendMessage(FRAGMENT_REPLACE_ID)
                }

                override fun onError(@NonNull errorResult: ErrorResult) {
                    val message = "startLiveness is onError. code = " + errorResult.code
                    Log.e(TAG, message)
                    if (!errorResult.equals(ErrorResult.USER_CANCELLED)) {
                        // エラーダイアログの表示
                        showErrorDialog(errorResult)
                        return
                    }
                }
            }
        )
    }

    /**
     * ユーザーキャンセルなしのライブネス撮影を行います.
     *
     * @param context   コンテキスト
     * @param parameter パラメータオブジェクト
     */
    private fun noUserCancelableStartLiveness(@NonNull context: Context, @NonNull parameter: MatchingParameters) {
        val factory = PolarifyKycSdkFactory()
        factory.getInstance(context).startSelfie(
            parameter,
            object : SelfieCaptureCallback {
                override fun onSuccess(@NonNull livenessCaptureResult: FaceCaptureResult) {
                    val image = livenessCaptureResult.image
                    TutorialActivity.setLivenessImage(image)
                    val message = "startLiveness is onSuccess"
                    Log.d(TAG, message)
                    sendMessage(FRAGMENT_REPLACE_ID)
                }

                override fun onError(@NonNull errorResult: ErrorResult) {
                    val message = "startLiveness is onError. code = " + errorResult.code
                    Log.e(TAG, message)
                    if (!errorResult.equals(ErrorResult.USER_CANCELLED)) {
                        // エラーダイアログの表示
                        showErrorDialog(errorResult)
                        return
                    }
                }
            }
        )
    }

    /**
     * セルフィー画像登録が成功したときに呼び出されます.
     */
    fun registerFaceOfSelfieOnSuccess() {
        nextButton?.unlock()
        progressBar!!.visibility = View.INVISIBLE
    }

    /**
     * セルフィー画像登録が失敗したときに呼び出されます.
     *
     * @param result エラー
     */
    fun registerFaceOfSelfieOnError(@NonNull result: ErrorResult) {
        Handler().postDelayed({
            // エラーダイアログの表示
            AlertDialog.Builder(activity, R.style.DialogStyle)
                .setTitle(R.string.common_error_title)
                .setMessage(result.message)
                .setCancelable(false)
                .setPositiveButton(
                    R.string.ok_dialog_text
                ) { dialog, _ ->
                    dialog.dismiss() // ダイアログを非表示にする
                }.create().show() // ダイアログを生成・表示
        }, DELAY_TIME)
        nextButton?.unlock()
        progressBar!!.visibility = View.INVISIBLE
    }

    /**
     * メッセージの処理を行います.
     *
     * @param message 処理対象メッセージ
     */
    override fun processMessage(message: Message?) {
        if (message != null) {
            when (message.what) {
                FRAGMENT_REPLACE_ID -> replaceNextFragment()
            }
        }
    }

    /**
     * セルフィープログレスエリアのフラグメントの切り替えを行います.
     */
    private fun replaceSelfieProgressAreaFragment() {
        val fragment: Fragment = selfieProgressAreaFragment
        replaceFragment(R.id.progress_container, fragment)
    }

    /**
     * セルフィープログレスエリアのフラグメントを取得します.
     *
     * @return 取得したフラグメント
     */
    @get:Nullable
    val selfieProgressAreaFragment: Fragment
        get() = SelfieProgressAreaFragment()

    /**
     * 指定された ID の View のフラグメントを切り替えます.
     *
     * @param id       フラグメントを切り替える View の ID
     * @param fragment 切り替えるフラグメント
     */
    private fun replaceFragment(@IdRes id: Int, @NonNull fragment: Fragment?) {
        progressBar!!.visibility = View.INVISIBLE
        val manager: FragmentManager? = getFragmentManager()
        if (manager == null) {
            val message = "Cannot get FragmentManager"
            Log.e(TAG, message)
            throw IllegalStateException(message)
        }
        val transaction: FragmentTransaction = manager.beginTransaction()
        if (fragment != null) {
            transaction.replace(id, fragment).commit()
        }
    }

    /**
     * 次に表示するフラグメントを取得します.
     *
     * @return 取得したフラグメント
     */
    @get:NonNull
    val nextFragment: Fragment
        get() = MBCO0404Fragment()

    /**
     * プログレスエリアのフラグメントを取得します.
     *
     * @return 取得したフラグメント
     */
    @get:Nullable
    val nextProgressAreaFragment: Fragment
        get() = RequestProgressAreaFragment()

    /**
     * 前のフラグメントを取得します.
     *
     * @return 取得したフラグメント
     */
    @get:NonNull
    val previousFragment: Fragment
        get() {
            val fragment: Fragment = SelfieTutorialFragment()
            val arguments = Bundle()
            arguments.putBoolean(APP_KEY_DIRECT_START_CAPTURE, true)
            fragment.arguments = arguments
            return fragment
        }

    @get:Nullable
    private val selfieImage: Bitmap?
        get() = getImage(object : ImageGetter {
            override fun execute(activity: TutorialActivity?): Bitmap? {
                return activity?.let { getSelfieImage(it) }
            }
        })

    /**
     * アクティビティからセルフィ画像を取得します.
     *
     * @param activity アクティビティ
     * @return 取得したセルフィ画像
     */
    fun getSelfieImage(@NonNull activity: TutorialActivity): Bitmap? {
        return activity.selfieImage
    }

    private interface ImageGetter {
        fun execute(@NonNull activity: TutorialActivity?): Bitmap?
    }

    @Nullable
    private fun getImage(@NonNull getter: ImageGetter): Bitmap? {
        val activity: TutorialActivity = tutorialActivity ?: return null
        return getter.execute(activity)
    }

    /**
     * TutorialActivity のインスタンスを取得します.
     *
     * @return 取得した TutorialActivity のインスタンス
     */
    @get:Nullable
    val tutorialActivity: TutorialActivity?
        get() {
            val activity: FragmentActivity? = activity
            if (activity !is TutorialActivity) {
                Log.e(TAG, "Cannot get Activity")
                return null
            }
            return activity
        }

    @get:Nullable
    val matchingIdResult: GetMatchingIDResult?
        get() {
            val activity: TutorialActivity = tutorialActivity ?: return null
            return activity.matchingIDResult
        }

    /**
     * エラーダイアログを表示します.
     *
     * @param result エラー
     */
    fun showErrorDialog(@NonNull result: ErrorResult) {
        val message = MyApp.CONTEXT.getString(R.string.MSG_ID_MB010003V)
        Handler().postDelayed({
            AlertDialog.Builder(activity, R.style.DialogStyle)
                .setTitle(R.string.common_error_title)
                .setMessage(message)
                .setCancelable(false)
                .setPositiveButton(
                    R.string.ok_dialog_text,
                    DialogInterface.OnClickListener { dialog, _ ->
                        dialog.dismiss()
                        if (result.equals(ErrorResult.TIMEOUT_ERROR)) {
                            startLiveness()
                            return@OnClickListener
                        }
                    }
                ).create().show()
        }, DELAY_TIME)
    }

    companion object {
        /**
         * ログのタグ.
         */
        private val TAG = SelfieConfirmationFragment::class.java.name

        /**
         * 指定タスクを実行前の遅延.
         */
        private const val DELAY_BEFORE_TASK_TIME = 350L

        /**
         * フラグメントリプレスメッセージ ID.
         */
        const val FRAGMENT_REPLACE_ID = 1001

        /**
         * ダイアログ表示遅延時間(単位 ミリ秒).
         */
        private const val DELAY_TIME: Long = 1000
    }
}

package jp.co.jsbank.mb.bankingapp.fragment

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import androidx.annotation.NonNull
import androidx.annotation.Nullable
import androidx.fragment.app.Fragment
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.system.ekyc.BundleKeyDefinitions
import jp.co.jsbank.mb.bankingapp.system.ekyc.IntroductionActivity

/**
 * イントロダクション画面を生成フラグメントです.
 */
class IntroductionFirstFragment : Fragment(), BundleKeyDefinitions {
    @Nullable
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val introductionContainer = container?.findViewById<FrameLayout>(R.id.introduction_container)
        return inflater.inflate(R.layout.document_introduction_first, introductionContainer, false)
    }

    override fun onViewCreated(@NonNull view: View, @Nullable savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // 次の書類撮影イントロダクションへ進むボタン
        val nextButton = view.findViewById<Button>(R.id.next_button)
        nextButton.setOnClickListener {
            val intent = Intent(context, IntroductionActivity::class.java)
            intent.putExtra(IntroductionActivity.KEY_INTRODUCTION_TYPE, IntroductionActivity.IntroductionType.SELECT)
            Log.d(TAG, "send IntroductionActivity start intent")
            startActivity(intent)
        }
    }

    companion object {
        /**
         * ログのタグ.
         */
        private val TAG = IntroductionFirstFragment::class.java.name
    }
}

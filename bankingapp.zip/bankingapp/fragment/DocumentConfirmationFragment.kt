package jp.co.jsbank.mb.bankingapp.fragment

import android.content.Context
import android.graphics.Bitmap
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.ViewTreeObserver
import android.view.animation.AnimationUtils
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.ProgressBar
import androidx.annotation.DrawableRes
import androidx.annotation.NonNull
import androidx.annotation.Nullable
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.fragment.helper.FaceCropper
import jp.co.jsbank.mb.bankingapp.system.ekyc.BundleKeyDefinitions
import jp.co.jsbank.mb.bankingapp.system.ekyc.TutorialActivity
import jp.co.jsbank.mb.bankingapp.system.master.DocumentKind
import jp.co.jsbank.mb.bankingapp.ui.widgets.common.SafetyButton
import jp.co.jsbank.mb.bankingapp.utils.PreferenceManagerUtil
import jp.co.polarify.onboarding.sdk.types.common.DocumentType
import jp.co.polarify.onboarding.sdk.types.result.GetMatchingIDResult

/**
 * 書類の撮影確認を行うフラグメントです.
 */
abstract class DocumentConfirmationFragment : Fragment() {
    /**
     * 登録を始めるボタンです.
     */
    private var nextButton: SafetyButton? = null

    /**
     * 次へ進む時ネット通信Progressです.
     */
    private var progressBar: ProgressBar? = null

    @Nullable
    override fun onCreateView(
        @NonNull inflater: LayoutInflater,
        @Nullable container: ViewGroup?,
        @Nullable savedInstanceState: Bundle?
    ): View? {
        if (container == null) {
            Log.e(TAG, "container is null")
            return null
        }
        val tutorialContainer = container.findViewById<FrameLayout>(R.id.fragment_container)
        return inflater.inflate(R.layout.document_confirmation_preview, tutorialContainer, false)
    }

    override fun onViewCreated(@NonNull view: View, @Nullable savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        showConfirmationPreview(view)
        showConfirmationMessage(view)
        val confirmationPreview = view.findViewById<View>(R.id.confirmation_preview)
        confirmationPreview.viewTreeObserver.addOnGlobalLayoutListener(object :
                ViewTreeObserver.OnGlobalLayoutListener {
                override fun onGlobalLayout() {
                    // ViewTreeObserver は毎回取得しないといけない
                    confirmationPreview.viewTreeObserver.removeOnGlobalLayoutListener(this)
                }
            })
        progressBar = view.findViewById(R.id.waiting_progress_bar_id)

        // 次へ進むボタン
        nextButton = view.findViewById(R.id.next_button_id)
        nextButton?.setOnClickListener {
            progressBar?.visibility = View.VISIBLE
            val cropper: FaceCropper<DocumentConfirmationFragment?>? = createFaceCropper()
            cropper?.execute()
        }

        // 撮り直しボタン
        val retakeButton = view.findViewById<Button>(R.id.retake_button_id)
        retakeButton.setOnClickListener {
            // 前のフラグメントに戻る
            replacePreviousFragment()
        }
    }

    /**
     * 確認画面の文言メッセージを表示します.
     *
     * @param view ビュー
     */
    protected abstract fun showConfirmationMessage(@NonNull view: View?)

    /**
     * 確認画面を表示します.
     *
     * @param root ルートビュー
     */
    private fun showConfirmationPreview(@NonNull root: View) {
        Handler(Looper.getMainLooper()).postDelayed({
            val imageView = root.findViewById<ImageView>(R.id.captured_photo)
            val image = documentImage
            imageView.setImageBitmap(image)
        }, DELAY_BEFORE_TASK_TIME)

        // 確認画面を左側からスライドさせます
        val context: Context? = context
        val slideLeft = AnimationUtils.loadAnimation(context, jp.co.polarify.onboarding.sdk.R.anim.slide_left)
        val constraintLayout: ConstraintLayout = root.findViewById(R.id.confirmation_preview)
        constraintLayout.startAnimation(slideLeft)
    }

    /**
     * 撮影を行う書類種別を取得します.
     *
     * @param documentKind 本人確認書類種類
     * @return 撮影を行う書類種別
     */
    @NonNull
    abstract fun getDocumentType(@NonNull documentKind: DocumentKind?): DocumentType

    /**
     * 書類種別を取得します.
     *
     * @return 取得した書類種別
     */
    @get:NonNull
    val documentType: DocumentType
        get() {
            val documentKind: DocumentKind? = context?.let {
                PreferenceManagerUtil.getInt(
                    it,
                    BundleKeyDefinitions.APP_KEY_CAPTURE_KIND
                )
            }?.let {
                DocumentKind.getDocumentKind(
                    it
                )
            }
            return getDocumentType(documentKind)
        }

    /**
     * 前のフラグメントに戻ります.
     */
    private fun replacePreviousFragment() {
        val manager: FragmentManager? = getFragmentManager()
        if (manager == null) {
            val message = "Cannot get FragmentManager"
            Log.e(TAG, message)
            throw IllegalStateException(message)
        }
        val fragment: Fragment = previousFragment
        val transaction: FragmentTransaction = manager.beginTransaction()
        transaction.replace(R.id.fragment_container, fragment).commit()
    }

    /**
     * 失敗例の画像イメージのリソース ID を取得します.
     *
     * @return 取得した画像イメージリソース ID
     */
    @get:DrawableRes
    protected abstract val failPatternImageId: Int

    /**
     * 次に表示するフラグメントに切り替えます.
     */
    fun replaceNextFragment() {
        val manager: FragmentManager? = getFragmentManager()
        if (manager == null) {
            val message = "Cannot get FragmentManager"
            Log.e(TAG, message)
            throw IllegalStateException(message)
        }
        // フラグメント切り替えトランザクションの取得
        val transaction: FragmentTransaction = manager.beginTransaction()
        // 次に表示するフラグメントを取得
        val fragment: Fragment = nextFragment
        transaction.replace(R.id.fragment_container, fragment)
        val progressAreaFragment: Fragment? = nextProgressAreaFragment
        if (progressAreaFragment != null) {
            transaction.replace(R.id.progress_container, progressAreaFragment)
        }
        val parent = view?.parent?.parent as ViewGroup
        val progressArea = parent.findViewById<View>(R.id.progress_container)
        // 説明画面で、プログラムを表示しない
        if (TutorialActivity.selfFlag) {
            progressArea!!.visibility = View.GONE
            TutorialActivity.setSelfFlag(false)
        } else {
            progressArea!!.visibility = View.VISIBLE
        }
        transaction.commit()
    }

    /**
     * 次に表示するフラグメントを取得します.
     *
     * @return 取得したフラグメント
     */
    @get:NonNull
    protected abstract val nextFragment: Fragment

    /**
     * プログレスエリアのフラグメントを取得します.
     *
     * @return 取得したフラグメント
     */
    @get:Nullable
    protected open val nextProgressAreaFragment: Fragment?
        get() = null

    /**
     * 前のフラグメントを取得します.
     *
     * @return 取得したフラグメント
     */
    @get:NonNull
    protected abstract val previousFragment: Fragment

    @get:Nullable
    private val documentImage: Bitmap?
        get() = getImage(object : ImageGetter {
            override fun execute(@NonNull activity: TutorialActivity?): Bitmap? {
                return getDocumentImage(activity)
            }
        })

    /**
     * アクティビティから書類画像を取得します.
     *
     * @param activity アクティビティ
     * @return 取得した書類画像
     */
    protected abstract fun getDocumentImage(@NonNull activity: TutorialActivity?): Bitmap?

    /**
     * 補正済み画像を取得します.
     *
     * @return 取得した補正済み画像
     */
    @get:Nullable
    val correctedImage: Bitmap?
        get() = getImage(object : ImageGetter {
            override fun execute(@NonNull activity: TutorialActivity?): Bitmap? {
                return getCorrectedImage(activity)
            }
        })

    /**
     * アクティビティから補正済み書類画像を取得します.
     *
     * @param activity アクティビティ
     * @return 取得した補正済み書類画像
     */
    abstract fun getCorrectedImage(@NonNull activity: TutorialActivity?): Bitmap?
    private interface ImageGetter {
        fun execute(@NonNull activity: TutorialActivity?): Bitmap?
    }

    @Nullable
    private fun getImage(@NonNull getter: ImageGetter): Bitmap? {
        val activity: TutorialActivity = tutorialActivity ?: return null
        return getter.execute(activity)
    }

    /**
     * TutorialActivity のインスタンスを取得します.
     *
     * @return 取得した TutorialActivity のインスタンス
     */
    @get:Nullable
    val tutorialActivity: TutorialActivity?
        get() {
            val activity: FragmentActivity? = activity
            if (activity !is TutorialActivity) {
                Log.e(TAG, "Cannot get Activity")
                return null
            }
            return activity
        }

    @get:Nullable
    val matchingIdResult: GetMatchingIDResult?
        get() {
            val activity: TutorialActivity = tutorialActivity ?: return null
            return activity.matchingIDResult
        }

    /**
     * 顔切り出しオブジェクトを生成します.
     *
     * @return 生成した顔切り出しオブジェクト
     */
    protected abstract fun createFaceCropper(): FaceCropper<DocumentConfirmationFragment?>?

    /**
     * 書類撮影開始要求が成功したときに呼び出されます.
     */
    fun registerFaceOfDocumentOnSuccess() {
        nextButton?.unlock()
        progressBar!!.visibility = View.INVISIBLE
    }

    /**
     * 書類撮影開始要求が失敗したときに呼び出されます.
     */
    fun registerFaceOfDocumentOnError() {
        nextButton?.unlock()
        progressBar!!.visibility = View.INVISIBLE
    }

    companion object {
        /**
         * ログのタグ.
         */
        private val TAG = DocumentConfirmationFragment::class.java.name

        /**
         * 指定タスクを実行前の遅延.
         */
        private const val DELAY_BEFORE_TASK_TIME = 350L
    }
}

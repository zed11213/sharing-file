package jp.co.jsbank.mb.bankingapp.fragment

import androidx.annotation.LayoutRes
import jp.co.jsbank.mb.bankingapp.R

/**
 * セルフィー撮影画面のプログレスエリアのフラグメントです.
 */
class SelfieProgressAreaFragment : ProgressAreaFragment() {
    /**
     * フラグメントレイアウトのリソース ID を取得します.
     *
     * @return 取得したレイアウト ID
     */
    @get:LayoutRes
    override val layoutId: Int
        get() = R.layout.selfie_child_progress
}

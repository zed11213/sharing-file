package jp.co.jsbank.mb.bankingapp.fragment

import android.util.Log
import androidx.annotation.NonNull
import jp.co.jsbank.mb.bankingapp.system.ekyc.TutorialActivity
import jp.co.polarify.onboarding.sdk.PolarifyKycSdkFactory
import jp.co.polarify.onboarding.sdk.types.callback.RegisterSelfieCallback
import jp.co.polarify.onboarding.sdk.types.internal.ErrorResult
import jp.co.polarify.onboarding.sdk.types.paramters.MatchingParameters
import jp.co.polarify.onboarding.sdk.types.result.GetMatchingIDResult
import jp.co.polarify.onboarding.sdk.types.result.RegisterSelfieResult

/**
 * セルフィー画像登録 処理を行うクラスです.
 */
class SelfieRegister internal constructor(@NonNull fragment: SelfieConfirmationFragment) {
    /**
     * フラグメント.
     */
    @NonNull
    private val fragment: SelfieConfirmationFragment = fragment

    /**
     * セルフィー画像登録を実行します.
     */
    fun execute() {
        val activity: TutorialActivity? = fragment.tutorialActivity
        if (activity == null) {
            Log.e(TAG, "Cannot get activity")
            throw IllegalStateException("Cannot get activity")
        }
        val matchingIDResult: GetMatchingIDResult = fragment.matchingIdResult ?: return
        val matchingParameters = MatchingParameters(matchingIDResult)
        val factory = PolarifyKycSdkFactory()
        factory.getInstance(activity).registerFaceOfSelfie(
            matchingParameters,
            object : RegisterSelfieCallback {
                override fun onSuccess(result: RegisterSelfieResult) {
                    fragment.startLiveness() // ライブネス開始要求
                    fragment.registerFaceOfSelfieOnSuccess()
                }

                override fun onError(@NonNull errorResult: ErrorResult) {
                    fragment.registerFaceOfSelfieOnError(errorResult)
                }
            }
        )
    }

    companion object {
        /**
         * ログのタグ.
         */
        private val TAG = SelfieRegister::class.java.name
    }
}

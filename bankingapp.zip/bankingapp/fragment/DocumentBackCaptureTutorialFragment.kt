package jp.co.jsbank.mb.bankingapp.fragment

import androidx.annotation.NonNull
import androidx.annotation.RawRes
import androidx.annotation.StringRes
import androidx.fragment.app.Fragment
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.system.ekyc.TutorialActivity
import jp.co.jsbank.mb.bankingapp.system.master.DocumentKind
import jp.co.polarify.onboarding.sdk.types.common.DocumentType
import jp.co.polarify.onboarding.sdk.types.result.DocumentResult

/**
 * 本人確認書類うら-チュートリアル画面を生成フラグメントです.
 */
class DocumentBackCaptureTutorialFragment : DocumentUprightCaptureTutorialFragment() {
    /**
     * 撮影を行う書類種別を取得します.
     *
     * @param documentKind 本人確認書類種類
     * @return 撮影を行う書類種別
     */
    @NonNull
    override fun getDocumentType(@NonNull documentKind: DocumentKind?): DocumentType {
        return when (documentKind) {
            DocumentKind.DRIVER_LICENSE_CARD_OCR -> DocumentType.BACK
            DocumentKind.MY_NUMBER_CARD_OCR -> DocumentType.BACKM
            else -> DocumentType.BACK
        }
    }

    /**
     * 処理開始時に表示するメッセージのリソース ID を取得します.
     *
     * @return 取得したメッセージのリソース ID
     */
    @get:StringRes
    override val openingMessageId: Int
        get() = R.string.back_capture_tutorial_text

    /**
     * キャプチャー結果をアクティビティに通知します.
     *
     * @param activity アクティビティ
     * @param result   キャップチャー結果
     */
    override fun notifyDocumentResult(activity: TutorialActivity?, result: DocumentResult?) {
        if (result != null) {
            activity?.notifyBackImages(result)
        }
    }

    /**
     * 次に表示するフラグメントを取得します.
     *
     * @return 取得したフラグメント
     */
    @get:NonNull
    override val nextFragment: Fragment
        get() = DocumentBackConfirmationFragment()

    /**
     * GIF アニメーションのリソース ID を取得します.
     *
     * @return 取得した GIF アニメーションのリソース ID
     */
    @get:RawRes
    override val gifId: Int
        get() = R.raw.drive_license_back_shooting
}

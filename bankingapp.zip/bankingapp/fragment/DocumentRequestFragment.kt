package jp.co.jsbank.mb.bankingapp.fragment

import android.graphics.Bitmap
import android.util.Log
import android.view.View
import android.widget.ImageView
import androidx.annotation.NonNull
import androidx.annotation.Nullable
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.system.ekyc.TutorialActivity
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.EKYC_IMAGE_BACK
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.EKYC_IMAGE_FRONT
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.EKYC_IMAGE_SELF
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.EKYC_IMAGE_TILTED
import jp.co.jsbank.mb.bankingapp.utils.PreferenceUtil
import jp.co.jsbank.mb.bankingapp.utils.bitmapToBase64

/**
 * 書類撮影申し込み確認画面のフラグメントです.
 */
class DocumentRequestFragment : RequestFragment(R.layout.fragment_request) {
    /**
     * プログレスバーのリソース ID を取得します.
     *
     * @return 取得したプログレスバーのリソース ID
     */
    override val progressBarId: Int
        get() = R.id.waiting_progress_bar_id

    /**
     * 申し込みボタンのリソース ID を取得します.
     *
     * @return 取得した申し込みボタンのリソース ID
     */
    override val requestButtonId: Int
        get() = R.id.request_button

    /**
     * 撮影画像をセットします.
     *
     * @param rootView ルートビュー
     */
    override fun setCapturedPhoto(rootView: View?) {
        val activity: TutorialActivity? = tutorialActivity
        if (activity == null) {
            val message = "Cannot get TutorialActivity"
            Log.e(TAG, message)
            throw IllegalStateException(message)
        }
        if (rootView != null) {
            setSelfieImage(rootView, activity)
        }
        if (rootView != null) {
            setFrontDocumentImage(rootView, activity)
        } // 書類表画像をビューにセット
        if (rootView != null) {
            setTiltedDocumentImage(rootView, activity)
        } // 書類斜め画像をビューにセット
        if (rootView != null) {
            setBackDocumentImage(rootView, activity)
        } // 書類裏画像をビューにセット
    }

    /**
     * セルフィー画像をビューにセットします.
     *
     * @param root     ルートビュー
     * @param activity アクティビティ
     */
    private fun setSelfieImage(@NonNull root: View, @NonNull activity: TutorialActivity) {
        val image = getSelfieImage(activity)
        if (image != null) {
            PreferenceUtil.setPreferenceStringValue(EKYC_IMAGE_SELF, bitmapToBase64(image))
        }
        val view = root.findViewById<ImageView>(R.id.captured_photo_face)
        view.setImageBitmap(image)
    }

    /**
     * アクテイビティが持つセルフィー画像を取得します.
     *
     * @param activity アクティビティ
     * @return 取得したセルフィー画像
     */
    @Nullable
    private fun getSelfieImage(@NonNull activity: TutorialActivity): Bitmap? {
        return activity.selfieImage
    }

    /**
     * 書類表画像をビューにセットします.
     *
     * @param rootView ルートビュー
     * @param activity アクティビティ
     */
    private fun setFrontDocumentImage(@NonNull rootView: View, @NonNull activity: TutorialActivity) {
        val image = getFrontDocumentImage(activity)
        if (image != null) {
            PreferenceUtil.setPreferenceStringValue(EKYC_IMAGE_FRONT, bitmapToBase64(image))
        }
        val view = rootView.findViewById<ImageView>(R.id.captured_photo_license_front)
        view.setImageBitmap(image)
    }

    /**
     * アクテイビティが持つ書類表画像を取得します.
     *
     * @param activity アクティビティ
     * @return 取得したセルフィー画像
     */
    @Nullable
    private fun getFrontDocumentImage(@NonNull activity: TutorialActivity): Bitmap? {
        return activity.frontDocumentImage
    }

    /**
     * 書類斜め画像をビューにセットします.
     *
     * @param rootView ルートビュー
     * @param activity アクティビティ
     */
    private fun setTiltedDocumentImage(@NonNull rootView: View, @NonNull activity: TutorialActivity) {
        val image = getTiltedDocumentImage(activity)
        if (image != null) {
            PreferenceUtil.setPreferenceStringValue(EKYC_IMAGE_TILTED, bitmapToBase64(image))
        }
        val view = rootView.findViewById<ImageView>(R.id.captured_photo_license_tilted)
        view.setImageBitmap(image)
    }

    /**
     * アクテイビティが持つ書類斜め画像を取得します.
     *
     * @param activity アクティビティ
     * @return 取得したセルフィー画像
     */
    @Nullable
    private fun getTiltedDocumentImage(@NonNull activity: TutorialActivity): Bitmap? {
        return activity.tiltedDocumentImage
    }

    /**
     * 書類裏画像をビューにセットします.
     *
     * @param rootView ルートビュー
     * @param activity アクティビティ
     */
    private fun setBackDocumentImage(@NonNull rootView: View, @NonNull activity: TutorialActivity) {
        val image = getBackDocumentImage(activity)
        if (image != null) {
            PreferenceUtil.setPreferenceStringValue(EKYC_IMAGE_BACK, bitmapToBase64(image))
        }
        val view = rootView.findViewById<ImageView>(R.id.captured_photo_license_back)
        view.setImageBitmap(image)
    }

    /**
     * アクテイビティが持つ書類斜め画像を取得します.
     *
     * @param activity アクティビティ
     * @return 取得したセルフィー画像
     */
    @Nullable
    private fun getBackDocumentImage(@NonNull activity: TutorialActivity): Bitmap? {
        return activity.backDocumentImage
    }

    companion object {
        /**
         * ログのタグ.
         */
        private val TAG = DocumentRequestFragment::class.java.name
    }
}

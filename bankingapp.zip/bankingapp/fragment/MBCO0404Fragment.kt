package jp.co.jsbank.mb.bankingapp.fragment

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Bitmap
import android.os.Bundle
import android.os.Handler
import android.os.Message
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.NonNull
import androidx.annotation.Nullable
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.bean.common.CheckPointsBean
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.system.ekyc.TutorialActivity
import jp.co.jsbank.mb.bankingapp.system.master.EkycResult
import jp.co.jsbank.mb.bankingapp.theme.H5
import jp.co.jsbank.mb.bankingapp.theme.H6
import jp.co.jsbank.mb.bankingapp.ui.widgets.button.PrimaryButton
import jp.co.jsbank.mb.bankingapp.ui.widgets.card.CardCheckPoints
import jp.co.jsbank.mb.bankingapp.ui.widgets.tabBar.Tab
import jp.co.jsbank.mb.bankingapp.utils.*
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.UNMATCH
import jp.co.polarify.onboarding.sdk.PolarifyKycSdkFactory
import jp.co.polarify.onboarding.sdk.types.callback.GetFaceVerificationCallback
import jp.co.polarify.onboarding.sdk.types.callback.RegisterSelfieCallback
import jp.co.polarify.onboarding.sdk.types.callback.UserCancelableSelfieCaptureCallback
import jp.co.polarify.onboarding.sdk.types.common.CancelType
import jp.co.polarify.onboarding.sdk.types.internal.ErrorResult
import jp.co.polarify.onboarding.sdk.types.internal.UserCancelNotifier
import jp.co.polarify.onboarding.sdk.types.paramters.MatchingParameters
import jp.co.polarify.onboarding.sdk.types.result.FaceCaptureResult
import jp.co.polarify.onboarding.sdk.types.result.GetMatchingIDResult
import jp.co.polarify.onboarding.sdk.types.result.RegisterSelfieResult
import jp.co.polarify.onboarding.sdk.types.result.UserCancelResult
import jp.co.polarify.onboarding.sdk.types.result.VerificationResults

class MBCO0404Fragment : SmartReplaceableFragment() {

    /**
     * ボタンクリックフラグ.
     */
    private var buttonHasClick: Boolean = false
    override fun processMessage(message: Message?) {
        if (message != null) {
            when (message.what) {
                SelfieConfirmationFragment.FRAGMENT_REPLACE_ID -> replaceNextFragment()
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return ComposeView(requireContext()).apply {
            setContent {
                MBCO0404Page()
            }
        }
    }

    @Composable
    fun MBCO0404Page() {
        Column(
            Modifier
                .fillMaxWidth()
                .background(Color.White)
        ) {
            Row(
                modifier = Modifier
                    .weight(0.5f)
                    .padding(20.dp, 0.dp, 20.dp, 0.dp)
            ) {
                if (PreferenceUtil.getPreferenceBooleanValue(ConstUtil.EKYC_TYPE))
                    Tab(
                        state = 1,
                        list = listOf(
                            stringResource(R.string.common_tab_process_second),
                            stringResource(R.string.common_tab_process_first),
                            stringResource(R.string.common_tab_process_fifth),
                        )
                    )
                else
                    Tab(
                        state = 2,
                        list = listOf(
                            stringResource(R.string.common_tab_process_4th),
                            stringResource(R.string.common_tab_process_second),
                            stringResource(R.string.common_tab_process_first),
                            stringResource(R.string.common_tab_process_fifth),
                        )
                    )
            }

            Row(
                Modifier
                    .fillMaxWidth()
                    .weight(0.5f)
            ) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 15.dp)
                ) {
                    Text(
                        text = stringResource(id = R.string.mbco0404_page_title_member),
                        Modifier
                            .padding(0.dp, 0.dp, 0.dp, 0.dp)
                            .align(Alignment.Center),
                        textAlign = TextAlign.Center,
                        fontSize = H5,
                    )
                }
            }

            Row(
                Modifier
                    .fillMaxWidth()
                    .weight(1.5f),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Image(
                    contentScale = ContentScale.Crop,
                    modifier = Modifier,
                    painter = painterResource(id = R.drawable.ekyc_face),
                    contentDescription = ""
                )
            }

            Row(
                Modifier
                    .fillMaxWidth()
                    .weight(1.0f)
            ) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 15.dp)
                ) {
                    Text(
                        text = stringResource(id = R.string.mbco0404_page_first_help_message),
                        Modifier
                            .padding(0.dp, 0.dp, 0.dp, 0.dp)
                            .align(Alignment.CenterStart),
                        textAlign = TextAlign.Start,
                        fontSize = H6,
                    )
                }
            }

            val list: List<CheckPointsBean> = listOf(
                CheckPointsBean(content = stringResource(id = R.string.mbco0404_page_label_prompt_information_first)),
                CheckPointsBean(content = stringResource(id = R.string.mbco0404_page_label_prompt_information_5th)),
                CheckPointsBean(content = stringResource(id = R.string.mbco0404_page_label_prompt_information_3rd)),
                CheckPointsBean(content = stringResource(id = R.string.mbco0404_page_label_prompt_information_4th))
            )
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 15.dp)
                    .weight(2f)
            ) {
                CardCheckPoints(data = list)
            }

            Spacer(modifier = Modifier.weight(0.2f))

            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .background(color = Color.White)
                    .padding(horizontal = 50.dp)
                    .weight(1f)
            ) {
                Column(
                    modifier = Modifier
                        .background(color = Color.White)
                        .fillMaxWidth()
                ) {
                    PrimaryButton(text = stringResource(id = R.string.common_ekyc_button_shadow_begins)) {
                        execute()
                    }
                }
            }
        }
    }

    /**
     * 次に表示するフラグメントに切り替えます.
     */
    private fun replaceNextFragment() {
        // 写真を保存する
        setSelfieImage(tutorialActivity!!)
        setLivenessImage(tutorialActivity!!)
        setFrontDocumentImage(tutorialActivity!!)
        setTiltedDocumentImage(tutorialActivity!!)
        setBackDocumentImage(tutorialActivity!!)
        getFaceVerification()
    }

    private fun getFaceVerification() {
        val parameter = MatchingParameters(matchingIdResult!!)
        val factory = PolarifyKycSdkFactory()
        var result = EkycResult.OK.code
        context?.let {
            factory.getInstance(it).getFaceVerification(
                parameter,
                object : GetFaceVerificationCallback {
                    override fun onSuccess(@NonNull results: VerificationResults) {
                        results.list.forEach { res ->
                            when (res.verificationResult) {
                                UNMATCH -> {
                                    result = EkycResult.NG.code
                                }
                            }
                        }

                        if (result != EkycResult.OK.code) {
                            returnTypeSelectDialog()
                        } else {
                            MainActivity.IS_EKYC_SHOOT_AGAIN_FLAG = false
                            TutorialActivity.getResults()
                        }

                        // EKYC確認結果を保存する
                        PreferenceUtil.setPreferenceStringValue(ConstUtil.EKYC_RESULT, result)
                    }

                    override fun onError(@NonNull errorResult: ErrorResult) {
                        LogPrintUtil.error(errorResult.message)
                    }
                }
            )
        }
    }

    /**
     * セルフィー画像をビューにセットします.
     *
     * @param activity アクティビティ
     */
    private fun setSelfieImage(@NonNull activity: TutorialActivity) {
        val image = getSelfieImage(activity)
        if (image != null) {
            PreferenceUtil.setPreferenceStringValue(ConstUtil.EKYC_IMAGE_SELF, bitmapToBase64(image))
        }
    }

    /**
     * まばたき画像をビューにセットします.
     *
     * @param activity アクティビティ
     */
    private fun setLivenessImage(@NonNull activity: TutorialActivity) {
        val image = getLivenessImage(activity)
        if (image != null) {
            PreferenceUtil.setPreferenceStringValue(ConstUtil.EKYC_IMAGE_LIVENESS, bitmapToBase64(image))
        }
    }

    /**
     * 書類表画像をビューにセットします.
     *
     * @param activity アクティビティ
     */
    private fun setFrontDocumentImage(@NonNull activity: TutorialActivity) {
        val image = getFrontDocumentImage(activity)
        if (image != null) {
            PreferenceUtil.setPreferenceStringValue(ConstUtil.EKYC_IMAGE_FRONT, bitmapToBase64(image))
        }
    }

    /**
     * 書類斜め画像をビューにセットします.
     *
     * @param activity アクティビティ
     */
    private fun setTiltedDocumentImage(@NonNull activity: TutorialActivity) {
        val image = getTiltedDocumentImage(activity)
        if (image != null) {
            PreferenceUtil.setPreferenceStringValue(ConstUtil.EKYC_IMAGE_TILTED, bitmapToBase64(image))
        }
    }

    /**
     * 書類裏画像をビューにセットします.
     *
     * @param activity アクティビティ
     */
    private fun setBackDocumentImage(@NonNull activity: TutorialActivity) {
        val image = getBackDocumentImage(activity)
        if (image != null) {
            PreferenceUtil.setPreferenceStringValue(ConstUtil.EKYC_IMAGE_BACK, bitmapToBase64(image))
        }
    }

    /**
     * アクテイビティが持つセルフィー画像を取得します.
     *
     * @param activity アクティビティ
     * @return 取得したセルフィー画像
     */
    @Nullable
    private fun getSelfieImage(@NonNull activity: TutorialActivity): Bitmap? {
        return activity.selfieImage
    }

    /**
     * アクテイビティが持つセルフィー画像を取得します.
     *
     * @param activity アクティビティ
     * @return 取得したまばたき画像
     */
    @Nullable
    private fun getLivenessImage(@NonNull activity: TutorialActivity): Bitmap? {
        return activity.livenessImage
    }

    /**
     * アクテイビティが持つ書類表画像を取得します.
     *
     * @param activity アクティビティ
     * @return 取得したセルフィー画像
     */
    @Nullable
    private fun getFrontDocumentImage(@NonNull activity: TutorialActivity): Bitmap? {
        return activity.frontDocumentImage
    }

    /**
     * アクテイビティが持つ書類斜め画像を取得します.
     *
     * @param activity アクティビティ
     * @return 取得したセルフィー画像
     */
    @Nullable
    private fun getTiltedDocumentImage(@NonNull activity: TutorialActivity): Bitmap? {
        return activity.tiltedDocumentImage
    }

    /**
     * アクテイビティが持つ書類斜め画像を取得します.
     *
     * @param activity アクティビティ
     * @return 取得したセルフィー画像
     */
    @Nullable
    private fun getBackDocumentImage(@NonNull activity: TutorialActivity): Bitmap? {
        return activity.backDocumentImage
    }

    /**
     * 次に表示するフラグメントを取得します.
     *
     * @return 取得したフラグメント
     */
    @get:NonNull
    val nextFragment: Fragment?
        get() = null

    /**
     * TutorialActivity のインスタンスを取得します.
     *
     * @return 取得した TutorialActivity のインスタンス
     */
    @get:Nullable
    val tutorialActivity: TutorialActivity?
        get() {
            val activity: FragmentActivity? = activity
            if (activity !is TutorialActivity) {
                return null
            }
            return activity
        }

    @get:Nullable
    val matchingIdResult: GetMatchingIDResult?
        get() {
            val activity: TutorialActivity = tutorialActivity ?: return null
            return activity.matchingIDResult
        }

    /**
     * ライブネス撮影開始要求をします.
     */
    fun startLiveness() {
        startLiveness(requireContext(), matchingIdResult)
    }

    /**
     * ライブネス撮影を開始します.
     *
     * @param context コンテキスト
     * @param result  マッチング ID
     */
    private fun startLiveness(@NonNull context: Context, @NonNull result: GetMatchingIDResult?) {
        val parameter = MatchingParameters(result!!)
        noUserCancelableStartLiveness(context, parameter)
    }

    /**
     * ユーザーキャンセルなしのライブネス撮影を行います.
     *
     * @param context   コンテキスト
     * @param parameter パラメータオブジェクト
     */
    private fun noUserCancelableStartLiveness(@NonNull context: Context, @NonNull parameter: MatchingParameters) {
        val factory = PolarifyKycSdkFactory()
        factory.getInstance(context).startSelfie(parameter, object: UserCancelableSelfieCaptureCallback {
            override fun onError(errorResult: ErrorResult) {
                val message = "startLiveness is onError. code = " + errorResult.code
                LogPrintUtil.error(message)
            }

            override fun onSuccess(result: FaceCaptureResult) {
                val image = result.image
                // セルフィー画像の通知
                TutorialActivity.setLivenessImage(image)
                val message = "startLiveness is onSuccess"
                LogPrintUtil.debug(message)
                sendMessage(SelfieConfirmationFragment.FRAGMENT_REPLACE_ID)
            }

            override fun onUserCancel(result: UserCancelResult, notifier: UserCancelNotifier) {
                val message = "startLiveness.onUserCancel is called."
                LogPrintUtil.debug(message)
                when (result.type) {
                    CancelType.BACK_KEY,
                    CancelType.PROGRESS_BUTTON -> showUserCancelDialog(result.activity, notifier)
                    else -> {
                    }
                }
            }
        })
//        factory.getInstance(context).startLiveness(
//            parameter,
//            object : UserCancelableLivenessCallback {
//                override fun onSuccess(@NonNull livenessCaptureResult: LivenessCaptureResult) {
//                    val image = livenessCaptureResult.image
//                    // セルフィー画像の通知
//                    TutorialActivity.setLivenessImage(image)
//                    val message = "startLiveness is onSuccess"
//                    LogPrintUtil.debug(message)
//                    sendMessage(SelfieConfirmationFragment.FRAGMENT_REPLACE_ID)
//                }
//
//                override fun onError(@NonNull errorResult: ErrorResult) {
//                    val message = "startLiveness is onError. code = " + errorResult.code
//                    LogPrintUtil.error(message)
//                }
//
//                override fun onUserCancel(@NonNull result: UserCancelResult, @NonNull notifier: UserCancelNotifier) {
//                    val message = "startLiveness.onUserCancel is called."
//                    LogPrintUtil.debug(message)
//                    when (result.type) {
//                        CancelType.BACK_KEY,
//                        CancelType.PROGRESS_BUTTON -> showUserCancelDialog(result.activity, notifier)
//                        else -> {
//                        }
//                    }
//                }
//            }
//        )
    }

    /**
     * セルフィー画像登録を実行します.
     */
    fun execute() {
        val activity: TutorialActivity = tutorialActivity ?: throw IllegalStateException("Cannot get activity")
        val matchingIDResult: GetMatchingIDResult = matchingIdResult ?: return
        val matchingParameters = MatchingParameters(matchingIDResult)
        val factory = PolarifyKycSdkFactory()
        if (!buttonHasClick) {
            buttonHasClick = true
            factory.getInstance(activity).registerFaceOfSelfie(
                matchingParameters,
                object : RegisterSelfieCallback {
                    override fun onError(@NonNull errorResult: ErrorResult) {
                        buttonHasClick = false
                        val message = "startSelfie is onError. code = " + errorResult.code
                        LogPrintUtil.error(message)
                        return
                    }

                    override fun onSuccess(result: RegisterSelfieResult) {
                        buttonHasClick = false
                        // ライブネス開始要求
                        startLiveness()
                    }
                }
            )
        }
    }

    /**
     * キャンセルダイアログを表示します.
     *
     * @param activity アクティビティ
     * @param notifier 通知オブジェクト
     */
    private fun showUserCancelDialog(@NonNull activity: Activity, @NonNull notifier: UserCancelNotifier) {
        if (activity.isDestroyed) {
            return
        }
        Handler().postDelayed({
            AlertDialog.Builder(activity, R.style.DialogStyle)
                .setTitle(R.string.dialog_title)
                .setMessage(R.string.dialog_text)
                .setCancelable(false)
                .setPositiveButton(
                    R.string.dialog_button_continue
                ) { dialog, _ ->
                    notifier.proceed()
                    dialog.dismiss()
                }
                .setNegativeButton(
                    R.string.dialog_button_return
                ) { dialog, _ ->
                    ReturnDestinationConfirmerUtil.execute(requireContext(), null)
                    notifier.finish()
                    dialog.dismiss()
                }.create().show()
        }, 1000)
    }

    /**
     * 免許証/マイナンバーカードの選択画面に戻り.
     */
    private fun returnTypeSelectDialog() {
        MainActivity.IS_EKYC_SHOOT_AGAIN_FLAG = true
        AlertDialog.Builder(context, R.style.DialogStyle)
            .setTitle(R.string.common_error_title)
            .setMessage(R.string.MSG_ID_MB010003V)
            .setPositiveButton("再撮影する") { _, _ ->
                TutorialActivity.getResults()
            }.create()
            .show()
    }
}

package jp.co.jsbank.mb.bankingapp.fragment

import android.graphics.Bitmap
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.annotation.NonNull
import androidx.fragment.app.Fragment
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.fragment.helper.DocumentFaceCropper
import jp.co.jsbank.mb.bankingapp.fragment.helper.FaceCropper
import jp.co.jsbank.mb.bankingapp.system.ekyc.BundleKeyDefinitions.APP_KEY_DIRECT_START_CAPTURE
import jp.co.jsbank.mb.bankingapp.system.ekyc.TutorialActivity
import jp.co.jsbank.mb.bankingapp.system.master.DocumentKind
import jp.co.polarify.onboarding.sdk.types.common.DocumentType

/**
 * 書類表の斜め撮影の確認を行うフラグメントです.
 */
class DocumentTiltedConfirmationFragment : DocumentConfirmationFragment() {
    /**
     * 確認画面の文言メッセージを表示します.
     *
     * @param view ビュー
     */
    override fun showConfirmationMessage(view: View?) {
        TutorialActivity.setSelfFlag(true)
        val message = view?.findViewById<TextView>(R.id.confirmation_message)
        if (message != null) {
            message.setText(R.string.document_confirmation_tilted)
            message.visibility = View.VISIBLE
        }
    }

    /**
     * 撮影を行う書類種別を取得します.
     *
     * @param documentKind 本人確認書類種類
     * @return 撮影を行う書類種別
     */
    @NonNull
    override fun getDocumentType(@NonNull documentKind: DocumentKind?): DocumentType {
        return when (documentKind) {
            DocumentKind.DRIVER_LICENSE_CARD_OCR -> DocumentType.TILTED
            DocumentKind.MY_NUMBER_CARD_OCR -> DocumentType.TILTEDM
            else -> DocumentType.TILTED
        }
    }

    @get:NonNull
    override val previousFragment: Fragment
        get() {
            val fragment: Fragment = DocumentTiltedCaptureTutorialFragment()
            val arguments = Bundle()
            arguments.putBoolean(APP_KEY_DIRECT_START_CAPTURE, true)
            fragment.arguments = arguments
            return fragment
        }

    /**
     * プログレスエリアのフラグメントを取得します.
     *
     * @return 取得したフラグメント
     */
    override val nextProgressAreaFragment: Fragment?
        get() = null

    /**
     * 顔切り出しオブジェクトを生成します.
     *
     * @return 生成した顔切り出しオブジェクト
     */
    override fun createFaceCropper(): FaceCropper<DocumentConfirmationFragment?> {
        return DocumentFaceCropper(this)
    }

    /**
     * 失敗例の画像イメージのリソース ID を取得します.
     *
     * @return 取得した画像イメージリソース ID
     */
    override val failPatternImageId: Int
        get() = R.drawable.drive_license_fail_pattern_diagonal

    /**
     * 次に表示するフラグメントを取得します.
     *
     * @return 取得したフラグメント
     */
    @get:NonNull
    override val nextFragment: Fragment
        get() = MBCO0403Fragment()

    /**
     * アクティビティから書類画像を取得します.
     *
     * @param activity アクティビティ
     * @return 取得した書類画像
     */
    override fun getDocumentImage(activity: TutorialActivity?): Bitmap? {
        return activity?.tiltedDocumentImage
    }

    /**
     * アクティビティから補正済み書類画像を取得します.
     *
     * @param activity アクティビティ
     * @return 取得した補正済み書類画像
     */
    override fun getCorrectedImage(activity: TutorialActivity?): Bitmap? {
        return activity?.tiltedCorrectedImage
    }
}

package jp.co.jsbank.mb.bankingapp.fragment

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import androidx.annotation.NonNull
import androidx.annotation.Nullable
import androidx.fragment.app.Fragment
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.system.MainActivity

/**
 * 撮影した画像の申し込み結果画面を生成フラグメントです.
 */
class RequestResultFragment : Fragment() {
    @Nullable
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        val requestContainer = container?.findViewById<FrameLayout>(R.id.fragment_container)
        return inflater.inflate(R.layout.fragment_request_result, requestContainer, false)
    }

    override fun onViewCreated(@NonNull view: View, @Nullable savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // 閉じるボタン
        val closeButton = view.findViewById<Button>(R.id.close_button)
        closeButton.setOnClickListener { onCloseClick() }
    }

    /**
     * 「閉じる」ボタンタップ処理.
     */
    private fun onCloseClick() {
        val intent = Intent(context, MainActivity::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        startActivity(intent)
    }
}

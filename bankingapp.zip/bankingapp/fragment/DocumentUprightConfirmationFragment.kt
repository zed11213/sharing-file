package jp.co.jsbank.mb.bankingapp.fragment

import android.view.View
import android.widget.TextView
import jp.co.jsbank.mb.bankingapp.R

/**
 * 表面や裏面などの正面撮影をする書類の撮影確認を行うフラグメントです.
 */
abstract class DocumentUprightConfirmationFragment : DocumentConfirmationFragment() {
    /**
     * 失敗例の画像イメージのリソース ID を取得します.
     *
     * @return 取得した画像イメージリソース ID
     */
    override val failPatternImageId: Int
        get() = R.drawable.drive_license_fail_pattern

    /**
     * 確認画面の例エラー文言を表示するかどうか.
     *
     * @param view ビュー
     */
    override fun showConfirmationMessage(view: View?) {
        val message = view?.findViewById<TextView>(R.id.confirmation_message)
        if (message != null) {
            message.visibility = View.VISIBLE
        }
    }
}

package jp.co.jsbank.mb.bankingapp.fragment

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.NonNull
import androidx.annotation.Nullable
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction
import jp.co.jsbank.mb.bankingapp.R

/**
 * ホーム画面です.
 */
class HomeTopFragment : Fragment() {
    @Nullable
    override fun onCreateView(
        @NonNull inflater: LayoutInflater,
        @Nullable container: ViewGroup?,
        @Nullable savedInstanceState: Bundle?
    ): View {
        val view: View = inflater.inflate(R.layout.fragment_home_top, container, false)
        view.findViewById<View>(R.id.opening_account_button).setOnClickListener {
            replaceFragment(
                HomeFlowFragment()
            )
        }
        view.findViewById<View>(R.id.privacy_policy).setOnClickListener {
            replaceFragment(
                PrivacyPolicyFragment()
            )
        }
        return view
    }

    /**
     * 指定のフラグメントに切り替えます.
     *
     * @param fragment 切り替えるフラグメント
     */
    private fun replaceFragment(@NonNull fragment: Fragment?) {
        val manager: FragmentManager? = getFragmentManager()
        if (manager == null) {
            Log.e(TAG, "Cannot get FragmentManager")
            return
        }
        val transaction: FragmentTransaction = manager.beginTransaction()
        if (fragment != null) {
            transaction.replace(R.id.container, fragment).commit()
        }
    }

    companion object {
        /**
         * ログのタグ.
         */
        private val TAG = HomeTopFragment::class.java.name
    }
}

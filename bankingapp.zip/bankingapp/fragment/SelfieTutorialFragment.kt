package jp.co.jsbank.mb.bankingapp.fragment

import android.app.AlertDialog
import android.content.Context
import android.content.DialogInterface
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Message
import android.util.Log
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import androidx.annotation.IdRes
import androidx.annotation.NonNull
import androidx.annotation.Nullable
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.system.MyApp
import jp.co.jsbank.mb.bankingapp.system.ekyc.BundleKeyDefinitions
import jp.co.jsbank.mb.bankingapp.system.ekyc.TutorialActivity
import jp.co.jsbank.mb.bankingapp.ui.widgets.common.SafetyButton
import jp.co.polarify.onboarding.sdk.PolarifyKycSdkFactory
import jp.co.polarify.onboarding.sdk.types.callback.SelfieCaptureCallback
import jp.co.polarify.onboarding.sdk.types.internal.ErrorResult
import jp.co.polarify.onboarding.sdk.types.paramters.MatchingParameters
import jp.co.polarify.onboarding.sdk.types.result.FaceCaptureResult
import jp.co.polarify.onboarding.sdk.types.result.GetMatchingIDResult

/**
 * 自動撮影のチュートリアル画面を生成フラグメントです.
 */
class SelfieTutorialFragment : TutorialFragment(), BundleKeyDefinitions {
    /**
     * バックボタンでもどってきた場合はtrueになり、処理時にfalseに戻します.
     */
    private var backPressedFlag = false

    /**
     * 撮影開始時にtrueになりバックボタンで戻った場合はfalseになります.
     */
    private var captureSuccessFlag = false

    /**
     * 撮影を始めるボタンです.
     */
    private var button: SafetyButton? = null

    /**
     * 次へ進む時ネット通信Progressです.
     */
    private var progressBar: ProgressBar? = null

    /**
     * プログレス切り替え用ハンドラ.
     */
    private val progressHandler = Handler()
    override fun onViewCreated(@NonNull view: View, @Nullable savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val textView = view.findViewById<TextView>(R.id.tutorial_text)
        textView.setText(R.string.selfie_tutorial_text)
        setGifByGlide(R.raw.phone_vertical)
        progressBar = view.findViewById(R.id.waiting_progress_bar_id)
        button = view.findViewById(R.id.tutorial_button)
        val arguments: Bundle? = arguments
        if (arguments != null) {
            val isStartCapture = arguments.getBoolean(BundleKeyDefinitions.APP_KEY_DIRECT_START_CAPTURE)
            // 再撮影の場合セルフィ画面を表示する
            if (isStartCapture) {
                startSelfie()
            }
        }
        button?.setOnClickListener {
            startSelfie()
            captureSuccessFlag = true
            view.viewTreeObserver.addOnWindowFocusChangeListener { hasFocus ->
                clearMessage()
                if (captureSuccessFlag) {
                    if (!backPressedFlag) {
                        if (hasFocus) {
                            sendMessage(LIVENESS_PROGRESS_ID)
                        }
                    } else {
                        sendMessage(SELFIE_PROGRESS_ID)
                        backPressedFlag = false
                    }
                } else {
                    sendMessage(SELFIE_PROGRESS_ID)
                }
            }
        }
        replaceSelfieProgressAreaFragment()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        Log.d(TAG, "onRequestPermissionsResult")
        if (requestCode == PERMISSION_REQUEST_AUTH) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                context?.let { startSelfie(it) }
            } else {
                activity?.let {
                }
            }
        }
    }

    /**
     * セルフィー画像の取得を行います.
     */
    private fun startSelfie() {
        progressBar!!.visibility = View.VISIBLE
        val context: Context? = context
        if (context == null) {
            val message = "Cannot get Context"
            Log.e(TAG, message)
            throw IllegalStateException(message)
        }
        startSelfie(context)
    }

    /**
     * セルフィー画像の取得を行います.
     *
     * @param context コンテキスト
     */
    private fun startSelfie(@NonNull context: Context) {
        Log.d(TAG, "startSelfie is called")
        val result: GetMatchingIDResult? = matchingIDResult
        if (result == null) {
            val message = "Cannot get GetMatchingIDResult"
            Log.e(TAG, message)
            throw IllegalStateException(message)
        }
        val parameters = MatchingParameters(result)
        noUserCancelableStartSelfie(context, parameters)
    }

    /**
     * ユーザーキャンセルなしのセルフィ撮影を行います.
     *
     * @param context    コンテキスト
     * @param parameters パラメータオブジェクト
     */
    private fun noUserCancelableStartSelfie(@NonNull context: Context, @NonNull parameters: MatchingParameters) {
        val factory = PolarifyKycSdkFactory()
        factory.getInstance(context).startSelfie(
            parameters,
            object : SelfieCaptureCallback {
                override fun onSuccess(@NonNull result: FaceCaptureResult) {
                    val image = result.image
                    TutorialActivity.setSelfieImage(image) // セルフィー画像の通知
                    sendMessage(FRAGMENT_REPLACE_ID)
                    val message = "startSelfie is onSuccess"
                    Log.d(TAG, message)
                    button?.unlock()
                    progressBar!!.visibility = View.INVISIBLE
                }

                override fun onError(@NonNull errorResult: ErrorResult) {
                    val message = "startSelfie is onError. code = " + errorResult.code
                    Log.e(TAG, message)
                    progressHandler.removeCallbacksAndMessages(null)
                    clearMessage()
                    sendMessage(SELFIE_PROGRESS_ID)
                    captureSuccessFlag = false
                    if (!errorResult.equals(ErrorResult.USER_CANCELLED)) {
                        // エラーダイアログの表示
                        showErrorDialog(context, errorResult)
                        return
                    }
                }
            }
        )
    }

    /**
     * メッセージの処理を行います.
     *
     * @param message 処理対象メッセージ
     */
    override fun processMessage(message: Message?) {
        if (message != null) {
            when (message.what) {
                FRAGMENT_REPLACE_ID -> replaceNextFragment()
                SELFIE_PROGRESS_ID -> replaceSelfieProgressAreaFragment()
            }
        }
    }

    /**
     * 次に表示するフラグメントに切り替えます.
     */
    private fun replaceNextFragment() {
        val manager: FragmentManager? = getFragmentManager()
        if (manager == null) {
            val message = "Cannot get FragmentManager"
            Log.e(TAG, message)
            throw IllegalStateException(message)
        }
        val transaction: FragmentTransaction = manager.beginTransaction()
        val fragment: Fragment = nextFragment
        transaction.replace(R.id.fragment_container, fragment)
        val progressAreaFragment: Fragment = RequestProgressAreaFragment()
        transaction.replace(R.id.progress_container, progressAreaFragment)
        transaction.commit()
    }

    /**
     * 次に表示するフラグメントを取得します.
     *
     * @return 取得したフラグメント
     */
    @get:NonNull
    val nextFragment: Fragment
        get() = SelfieConfirmationFragment()

    /**
     * セルフィープログレスエリアのフラグメントの切り替えを行います.
     */
    private fun replaceSelfieProgressAreaFragment() {
        val fragment: Fragment = selfieProgressAreaFragment
        replaceFragment(R.id.progress_container, fragment)
    }

    /**
     * セルフィープログレスエリアのフラグメントを取得します.
     *
     * @return 取得したフラグメント
     */
    @get:Nullable
    val selfieProgressAreaFragment: Fragment
        get() = SelfieProgressAreaFragment()

    /**
     * 指定された ID の View のフラグメントを切り替えます.
     *
     * @param id       フラグメントを切り替える View の ID
     * @param fragment 切り替えるフラグメント
     */
    private fun replaceFragment(@IdRes id: Int, @NonNull fragment: Fragment?) {
        val manager: FragmentManager? = getFragmentManager()
        if (manager == null) {
            val message = "Cannot get FragmentManager"
            Log.e(TAG, message)
            throw IllegalStateException(message)
        }
        val transaction: FragmentTransaction = manager.beginTransaction()
        if (fragment != null) {
            transaction.replace(id, fragment).commit()
        }
    }

    override fun onPause() {
        // 仕様不明のところが多くて、念のため、ここでボタンとインジケータを初期状態にします.
        button?.unlock()
        progressBar!!.visibility = View.INVISIBLE
        super.onPause()
    }

    /**
     * エラーダイアログを表示します.
     *
     * @param context コンテキスト
     * @param result  エラー
     */
    fun showErrorDialog(@NonNull context: Context?, @NonNull result: ErrorResult) {
        val message = MyApp.CONTEXT.getString(R.string.MSG_ID_MB010003V)
        Handler().postDelayed({
            AlertDialog.Builder(context, R.style.DialogStyle)
                .setTitle(R.string.common_error_title)
                .setMessage(message)
                .setCancelable(false)
                .setPositiveButton(
                    R.string.ok_dialog_text,
                    DialogInterface.OnClickListener { dialog, _ ->
                        dialog.dismiss()
                        if (result.equals(ErrorResult.TIMEOUT_ERROR) ||
                            result.equals(ErrorResult.FACE_RECOGNITION_ERROR)
                        ) {
                            // タイムアウトした/撮影した写真で顔が認識できなかった場合はOKを押すと再撮影開始
                            startSelfie()
                            return@OnClickListener
                        }
                    }
                ).create().show()
        }, DELAY_TIME)
    }

    companion object {
        /**
         * ログのタグ.
         */
        private val TAG = SelfieTutorialFragment::class.java.name

        /**
         * フラグメントリプレスメッセージ ID.
         */
        const val FRAGMENT_REPLACE_ID = 1001

        /**
         * ライブネスプログレスに切り替えるメッセージID.
         */
        const val LIVENESS_PROGRESS_ID = 1003

        /**
         * セルフィープログレスに切り替えるメッセージID.
         */
        const val SELFIE_PROGRESS_ID = 1004

        /**
         * ダイアログ表示遅延時間(単位 ミリ秒).
         */
        private const val DELAY_TIME: Long = 1000

        /**
         * カメラ要求コード(認証).
         */
        private const val PERMISSION_REQUEST_AUTH = 101
    }
}

package jp.co.jsbank.mb.bankingapp.fragment.helper

import androidx.annotation.NonNull
import jp.co.jsbank.mb.bankingapp.fragment.DocumentConfirmationFragment

/**
 * 何もしない顔切り出しクラスです.
 */
class NullFaceCropper
/**
 * コンストラクタ.
 *
 * @param fragment フラグメント
 */
(@NonNull fragment: DocumentConfirmationFragment?) : FaceCropper<DocumentConfirmationFragment?>(fragment) {
    /**
     * 顔切り出しを実行します.
     */
    override fun execute() {
        this.fragment?.replaceNextFragment()
    }
}

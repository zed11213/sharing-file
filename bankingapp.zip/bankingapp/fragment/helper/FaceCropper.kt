package jp.co.jsbank.mb.bankingapp.fragment.helper

import androidx.annotation.NonNull
import androidx.fragment.app.Fragment

/**
 * 顔切り出しを行うクラスの抽象基底クラスです.
 */
abstract class FaceCropper<FRAGMENT : Fragment?>
/**
 * コンストラクタ.
 *
 * @param fragment フラグメント
 */ internal constructor(
    @field:NonNull @get:NonNull @param:NonNull protected val fragment: FRAGMENT
) {
    /**
     * フラグメントを取得します.
     *
     * @return 取得したフラグメント
     */

    /**
     * 顔切り出しを実行します.
     */
    abstract fun execute()
}

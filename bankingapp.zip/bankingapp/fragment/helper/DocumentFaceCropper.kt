package jp.co.jsbank.mb.bankingapp.fragment.helper

import android.graphics.Bitmap
import android.util.Log
import androidx.annotation.NonNull
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.fragment.DocumentConfirmationFragment
import jp.co.jsbank.mb.bankingapp.system.ekyc.TutorialActivity
import jp.co.polarify.onboarding.sdk.PolarifyKycSdkFactory
import jp.co.polarify.onboarding.sdk.types.callback.AddingDocumentsCallback
import jp.co.polarify.onboarding.sdk.types.common.DocumentType
import jp.co.polarify.onboarding.sdk.types.internal.ErrorResult
import jp.co.polarify.onboarding.sdk.types.paramters.AddingDocumentsParameters
import jp.co.polarify.onboarding.sdk.types.result.GetMatchingIDResult

/**
 * 書類画像の顔切り出し処理を行うクラスです.
 */
class DocumentFaceCropper
/**
 * コンストラクタ.
 *
 * @param fragment フラグメント
 */
(@NonNull fragment: DocumentConfirmationFragment?) : FaceCropper<DocumentConfirmationFragment?>(fragment) {
    /**
     * 顔切り出しを実行します.
     */
    override fun execute() {
        val fragment: DocumentConfirmationFragment? = fragment
        val activity: TutorialActivity? = fragment?.tutorialActivity
        if (activity == null) {
            Log.e(TAG, "Cannot get context")
            throw IllegalStateException("Cannot get context")
        }
        val image: Bitmap = fragment.correctedImage
            ?: return
        val documentType: DocumentType = fragment.documentType
        val matchingIdResult: GetMatchingIDResult? = fragment.matchingIdResult
        val parameters = matchingIdResult?.let { AddingDocumentsParameters(it, documentType, image) }
        val factory = PolarifyKycSdkFactory()
        if (parameters != null) {
            factory.getInstance(activity).registerFaceOfDocument(
                parameters,
                object : AddingDocumentsCallback {
                    override fun onSuccess() {
                        fragment.replaceNextFragment()
                        fragment.registerFaceOfDocumentOnSuccess()
                    }

                    override fun onError(@NonNull errorResult: ErrorResult) {
                        fragment.registerFaceOfDocumentOnError()
                        activity.runOnUiThread(
                            Runnable {
                                showErrorHandlerDialog(activity, errorResult)
                            }
                        )
                    }
                }
            )
        }
    }

    /**
     * 対象のエラーダイアログを表示します.
     *
     * @param activity    アクティビティ
     * @param errorResult エラー
     */
    private fun showErrorHandlerDialog(@NonNull activity: TutorialActivity, @NonNull errorResult: ErrorResult) {
        val builder: android.app.AlertDialog.Builder = android.app.AlertDialog.Builder(activity, R.style.DialogStyle)
        val message = errorResult.message
        if (errorResult.equals(ErrorResult.SERVER_CONNECTION_ERROR)) {
            builder.setTitle(R.string.common_error_title).setMessage(message)
                .setPositiveButton(
                    R.string.ok
                ) { dialog, _ ->
                    dialog.dismiss()
                }
        }
        builder.create().show()
    }

    companion object {
        /**
         * ログのタグ.
         */
        private val TAG = DocumentConfirmationFragment::class.java.name
    }
}

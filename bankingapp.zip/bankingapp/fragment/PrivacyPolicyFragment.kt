package jp.co.jsbank.mb.bankingapp.fragment

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.annotation.NonNull
import androidx.annotation.Nullable
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction
import jp.co.jsbank.mb.bankingapp.R

class PrivacyPolicyFragment : Fragment() {
    @Nullable
    override fun onCreateView(
        @NonNull inflater: LayoutInflater,
        @Nullable container: ViewGroup?,
        @Nullable savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_privacy_policy, container, false)
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onViewCreated(@NonNull view: View, @Nullable savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val webView = view.findViewById<WebView>(R.id.privacyPolicyView)
        webView.loadUrl("file:///android_asset/$POLICY_FILE")
        val webSettings = webView.settings
        webSettings.javaScriptEnabled = true
        webView.addJavascriptInterface(
            object : Any() {
                // policy.htmlのJavaScriptクリックイベント
                @JavascriptInterface
                fun performClick() {
                    val fragment = HomeTopFragment()
                    val manager: FragmentManager? = getFragmentManager()
                    val transaction: FragmentTransaction = manager!!.beginTransaction()
                    transaction.replace(R.id.container, fragment)
                    transaction.commit()
                }
            },
            "close"
        )
    }

    companion object {
        /**
         * 利用規定ファイル名.
         */
        private const val POLICY_FILE = "policy.html"
    }
}

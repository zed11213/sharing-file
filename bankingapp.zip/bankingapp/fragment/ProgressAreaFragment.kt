package jp.co.jsbank.mb.bankingapp.fragment

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.annotation.LayoutRes
import androidx.annotation.NonNull
import androidx.annotation.Nullable
import androidx.fragment.app.Fragment
import jp.co.jsbank.mb.bankingapp.R

/**
 * プログレスエリアの抽象フラグメントです.
 */
abstract class ProgressAreaFragment : Fragment() {
    @Nullable
    override fun onCreateView(
        @NonNull inflater: LayoutInflater,
        @Nullable container: ViewGroup?,
        @Nullable savedInstanceState: Bundle?
    ): View? {
        if (container == null) {
            Log.e(TAG, "container is null")
            return null
        }
        val progressContainer = container.findViewById<FrameLayout>(R.id.progress_container)
        @LayoutRes val id = layoutId
        return inflater.inflate(id, progressContainer, false)
    }

    /**
     * フラグメントレイアウトのリソース ID を取得します.
     *
     * @return 取得したレイアウト ID
     */
    @get:LayoutRes
    protected abstract val layoutId: Int

    companion object {
        /**
         * ログのタグ.
         */
        private val TAG = ProgressAreaFragment::class.java.name
    }
}

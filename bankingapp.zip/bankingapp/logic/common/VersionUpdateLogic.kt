package jp.co.jsbank.mb.bankingapp.logic.common

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import jp.co.jsbank.mb.bankingapp.ui.pages.common.state.VersionUpdateState

/**
 * バージョン更新ダイアログロジック
 */
@HiltViewModel
class VersionUpdateLogic @Inject constructor() : ViewModel() {

    var viewStates by mutableStateOf(VersionUpdateState())
        private set

    /**
     * ダイアログを開
     */
    fun openErrorDialog() {
        viewStates = viewStates.copy(errorFlag = true)
    }

    /**
     * ダイアログを閉じる
     */
    fun closeErrorDialog() {
        viewStates = viewStates.copy(errorFlag = false)
    }
}

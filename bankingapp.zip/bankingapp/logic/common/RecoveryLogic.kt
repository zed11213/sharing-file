package jp.co.jsbank.mb.bankingapp.logic.common

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.gson.Gson
import io.realm.Realm
import java.util.*
import javax.inject.Inject
import jp.co.jsbank.mb.bankingapp.bean.common.RestorationInfoBean
import jp.co.jsbank.mb.bankingapp.bean.opened.mbop.mbop0602.MBOP0602ResponseBean
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.repositories.db.common.create
import jp.co.jsbank.mb.bankingapp.repositories.db.common.deleteAll
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.AccountOpeningAB0707
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.EPassBookAB0701
import jp.co.jsbank.mb.bankingapp.system.MyApp
import jp.co.jsbank.mb.bankingapp.utils.*
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.API_METHOD_TYPE_POST
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map

class RecoveryLogic @Inject constructor(
    private var webService: RestService
) : ViewModel() {

    /**
     * ロカールDB
     */
    private var dbService: Realm = MyApp.INSTANCE

    /**
     * 復元処理
     */
    suspend fun restorationProcess(receiptNumber: String): Boolean {
        PreferenceUtil.setScreenIDAndEventID("MBCO6201", "E01")
        var result = false
        viewModelScope.async {
            val bean = RestorationInfoBean(receiptNumber = receiptNumber)
            flow {
                ApiRequestUtil.setApiParam(API_METHOD_TYPE_POST, bean.toJson())
                emit(webService.AB0701())
            }.map {
                // 復元情報格納
                dbService.deleteAll(EPassBookAB0701::class.java)
                val ab0701 = EPassBookAB0701()
                ab0701.id = UUID.randomUUID().toString()
                // 人格区分
                ab0701.personType = it.resultDto?.personType.toString()
                // 画面ID
                ab0701.screenId = it.resultDto?.screenId.toString()
                // 口座開設申込情報（個人）
                ab0701.individual = Gson().toJson(it.resultDto?.individual)
                // 口座開設申込情報（法人）
                ab0701.corporation = Gson().toJson(it.resultDto?.corporation)
                // 口座開設申込情報（個人事業主）
                ab0701.soleProprietor = Gson().toJson(it.resultDto?.soleProprietor)
                dbService.create(ab0701)

                // レスポンスからCiF情報をRealmに保存
                val responseBean = MBOP0602ResponseBean()
                // 生年月日
                responseBean.birthday = it.resultDto?.birthday.toString()
                // 番地
                responseBean.addrDetail3 = it.resultDto?.addrDetail3.toString()
                // 住所方書
                responseBean.addressDetail = it.resultDto?.addressDetail.toString()
                // 電話番号１
                responseBean.phoneNumber1 = it.resultDto?.phoneNumber1.toString()

                // CIF照会
                dbService.deleteAll(AccountOpeningAB0707::class.java)
                val ab0707 = AccountOpeningAB0707()
                ab0707.id = UUID.randomUUID().toString()
                ab0707.cifInformation = responseBean.toJson()
                dbService.create(ab0707)

                result = true
            }.catch {
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }.await()
        return result
    }
}

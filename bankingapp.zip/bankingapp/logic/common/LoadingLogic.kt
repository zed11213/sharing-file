package jp.co.jsbank.mb.bankingapp.logic.common

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import jp.co.jsbank.mb.bankingapp.ui.pages.common.state.LoadingState

/**
 * ローディング
 */
@HiltViewModel
class LoadingLogic @Inject constructor() : ViewModel() {

    var viewStates by mutableStateOf(LoadingState())
        private set

    /**
     * ローディングダイアログを開
     */
    fun openLoadingDialog() {
        viewStates = viewStates.copy(loadingFlag = true)
    }

    /**
     * ローディングダイアログを閉じる
     */
    fun closeLoadingDialog() {
        viewStates = viewStates.copy(loadingFlag = false)
    }
}

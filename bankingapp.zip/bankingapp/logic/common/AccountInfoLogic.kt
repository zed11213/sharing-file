package jp.co.jsbank.mb.bankingapp.logic.common

import android.util.Log
import androidx.compose.runtime.mutableStateMapOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.gson.Gson
import io.realm.Realm
import jp.co.jsbank.mb.bankingapp.bean.basic.BasicBean
import java.util.*
import java.util.stream.Collectors
import javax.inject.Inject
import jp.co.jsbank.mb.bankingapp.bean.common.TermDepositDetailsInfoBean
import jp.co.jsbank.mb.bankingapp.bean.login.mblg.mblg0201.NoticeDeposit
import jp.co.jsbank.mb.bankingapp.bean.main.home.mbdp.mbdp0301.TermDepositDetails
import jp.co.jsbank.mb.bankingapp.bean.main.home.mbdp.mbdp1101.MBDP1101ResponseBean
import jp.co.jsbank.mb.bankingapp.bean.main.home.mbnt.mbnt0101.MBNT0101RequestBean
import jp.co.jsbank.mb.bankingapp.bean.main.menu.mbst.mbst1201.MBST1201Bean
import jp.co.jsbank.mb.bankingapp.logic.main.home.ViewModelBus
import jp.co.jsbank.mb.bankingapp.repositories.api.async.LoadStatus
import jp.co.jsbank.mb.bankingapp.repositories.api.async.RequestListener
import jp.co.jsbank.mb.bankingapp.repositories.api.async.RequestTask
import jp.co.jsbank.mb.bankingapp.repositories.api.async.RequestTaskGroup
import jp.co.jsbank.mb.bankingapp.repositories.api.async.SchedulerManager
import jp.co.jsbank.mb.bankingapp.repositories.api.request.AsyncRestService
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.repositories.db.common.create
import jp.co.jsbank.mb.bankingapp.repositories.db.common.deleteAll
import jp.co.jsbank.mb.bankingapp.repositories.db.common.findAll
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.EPassBookAB0401
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.EPassBookAB0403
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.EPassBookAB0405
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.EPassBookAB1001
import jp.co.jsbank.mb.bankingapp.system.MainActivity.Companion.IS_ANNOUNCEMENTS_IMPORTANT_FLAG
import jp.co.jsbank.mb.bankingapp.system.MyApp
import jp.co.jsbank.mb.bankingapp.system.master.MobileMsgType
import jp.co.jsbank.mb.bankingapp.system.master.Subject
import jp.co.jsbank.mb.bankingapp.theme.mpf_switching_button_label_color
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.CertificateLoadState
import jp.co.jsbank.mb.bankingapp.utils.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.job
import kotlinx.coroutines.launch
import kotlin.collections.forEach
import kotlin.collections.map
import kotlin.collections.set
import kotlin.collections.toMutableList
import kotlin.text.get

/**
 * 口座情報取得
 */
class AccountInfoLogic @Inject constructor(
    private var webService: RestService,
    private var asyncWebService : AsyncRestService
) : ViewModel(), RequestListener {

    // ロカールDB
    private var dbService: Realm = MyApp.INSTANCE

    /**
     * エラーメッセージリスト
     */
    private var errorFlag: Boolean = false

    /**
     * 口座情報
     */
    private var accountList: List<MBST1201Bean> = listOf()

    private var schedulerManager: SchedulerManager = SchedulerManager()

    private val _cacheNoticeDeposit = mutableStateMapOf<String,CertificateLoadState<List<NoticeDeposit>>>()
    private val _cacheTermDeposit = mutableStateMapOf<String,CertificateLoadState<List<TermDepositDetails>>>()
    val cacheNoticeDeposit: Map<String, CertificateLoadState<List<NoticeDeposit>>> = _cacheNoticeDeposit
    val cacheTermDeposit: Map<String, CertificateLoadState<List<TermDepositDetails>>> = _cacheTermDeposit

    /**
     * トップ情報取得
     */
    suspend fun getAccountInfo(): Boolean {
        errorFlag = false
        // 画面IDとイベントID設定
        PreferenceUtil.setScreenIDAndEventID("MBLG0201", "E01")
        // 口座一覧と各口座の残高取得
        StopWatch.start("計測開始")
        getSubjectBalanceInfo()
        // お知らせ一覧取得

//        // 修正後
        if (errorFlag) return true else {
            dbService.deleteAll(EPassBookAB0403::class.java)
            dbService.deleteAll(EPassBookAB0405::class.java)

            val fixedAccountListAsync = accountList.filter {
                // 定期預金
                it.subjectNameCode == Subject.FIXED_SAVINGS.code
            }.toList().groupBy {
                it.accountNumber + it.branchNumber
            }.values.mapNotNull { it.firstOrNull() }

            val noticeAccountList = accountList.filter {
                // 通知預金
                it.subjectNameCode == Subject.DEPOSIT_DEPOSIT.code
            }.toList().groupBy {
                it.accountNumber + it.branchNumber
            }.values.mapNotNull { it.firstOrNull() }

//            startGetTermDepositDetailsInfo(fixedAccountListAsync)
//            startGetNoticeDepositListInfo(noticeAccountList)
//            schedulerManager.start()
//            StopWatch.time("home")
        }

        return errorFlag
    }
    fun getAccountList():List<MBST1201Bean>{
        return accountList
    }
    suspend fun refreshAccountInfo(): Boolean {
        errorFlag = false
        // 画面IDとイベントID設定
        PreferenceUtil.setScreenIDAndEventID("MBLG0201", "E01")
        // 口座一覧と各口座の残高取得
        getSubjectBalanceInfo()
        // お知らせ一覧取得

        if (errorFlag) return true else {
            dbService.deleteAll(EPassBookAB0403::class.java)
            dbService.deleteAll(EPassBookAB0405::class.java)

//            val fixedAccountListAsync = accountList.filter {
//                // 定期預金
//                it.subjectNameCode == Subject.FIXED_SAVINGS.code
//            }.toList().groupBy {
//                it.accountNumber + it.branchNumber
//            }.values.mapNotNull { it.firstOrNull() }

//            val noticeAccountList = accountList.filter {
                // 通知預金
//                it.subjectNameCode == Subject.DEPOSIT_DEPOSIT.code
//            }.toList().groupBy {
//                it.accountNumber + it.branchNumber
//            }.values.mapNotNull { it.firstOrNull() }

//            startGetTermDepositDetailsInfo(fixedAccountListAsync)
//            startGetNoticeDepositListInfo(noticeAccountList)
//            schedulerManager.start()
            StopWatch.time("home")

        }
        return errorFlag
    }
    /**
     * 口座一覧と各口座の残高取得
     */
    private suspend fun getSubjectBalanceInfo() {
        viewModelScope.async {
            flow {
                ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST)
                emit(webService.AB0401())
            }.map {
                // RealmDBに保存する
                accountList = it.resultDto?.accountInfoResponseDtoList!!

                dbService.deleteAll(EPassBookAB0401::class.java)
                val ab0401 = EPassBookAB0401()
                ab0401.id = UUID.randomUUID().toString()
                ab0401.subjectTotalBalance = Gson().toJson(it.resultDto?.subjectTotalBalance!!)
                ab0401.allAccountsTotalBalance = Gson().toJson(it.resultDto?.allAccountsTotalBalance!!)
                ab0401.balanceInformationList = Gson().toJson(it.resultDto?.accountInfoResponseDtoList!!)
                dbService.create(ab0401)
            }.catch {
                errorFlag = true
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }.await()
    }

    /**
     * お知らせ一覧取得
     */
    suspend fun getAnnouncementInfo(): Boolean {
        val param = MBNT0101RequestBean()
        viewModelScope.async {
            flow {
                ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, param.toJson())
                emit(webService.AB1001())
            }.map {
                val importantCount = it.resultDto?.anncmntList!!
                    .filter { b -> b.mobileMsgType == MobileMsgType.IMPORTANT.code }.count()
                IS_ANNOUNCEMENTS_IMPORTANT_FLAG = importantCount > 0
                dbService.deleteAll(EPassBookAB1001::class.java)
                val ab1001 = EPassBookAB1001()
                ab1001.id = UUID.randomUUID().toString()
                ab1001.anncmntList = Gson().toJson(it.resultDto?.anncmntList!!)
                ab1001.dataCount = it.resultDto?.dataCount!!
                dbService.create(ab1001)
            }.catch {
                errorFlag = true
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }.await()
        return errorFlag
    }

    /**
     * 定期預金明細取得
     *
     * @param bankAccountNumber 口座番号
     * @param branchNumber 店番
     */
    private suspend fun getTermDepositDetailsInfo(bankAccountNumber: String, branchNumber: String, cifNo: String) {
        Log.i("thread","account:${bankAccountNumber} branchNumber:${branchNumber} cifNumber:${cifNo}")

        viewModelScope.async {
            val bean = TermDepositDetailsInfoBean()
            bean.accountNumber = bankAccountNumber
            bean.branchNumber = branchNumber
            bean.cifNumber = cifNo
            flow {
                ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, bean.toJson())
                emit(webService.AB0403())
            }.map {
                Log.i("thread","account:${bankAccountNumber} success")
                val realmRegularDepositInfo = dbService.findAll(EPassBookAB0403::class.java)
                var detailList: MutableList<TermDepositDetails> = mutableListOf()
                if (realmRegularDepositInfo.isNotEmpty()) {
                    detailList = realmRegularDepositInfo[0]?.termDepositDetails
                        ?.fromJson<List<TermDepositDetails>>()?.toMutableList()!!
                }
                val ab0403 = EPassBookAB0403()
                ab0403.id = UUID.randomUUID().toString()
                val result = it.resultDto!!.map { r -> r.copy(accountNumber = bankAccountNumber) }.toMutableList().stream().sorted(
                    Comparator.comparing(
                        TermDepositDetails::subNo
                    )
                ).collect(Collectors.toList())
                detailList.addAll(result)
                ab0403.termDepositDetails = Gson().toJson(detailList)
                dbService.deleteAll(EPassBookAB0403::class.java)
                dbService.create(ab0403)
            }.catch {
                errorFlag = true
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }.await()
    }

    /**
     * 定期預金明細取得
     *
     * @param bankAccountNumber 口座番号
     * @param branchNumber 店番
     */
    suspend fun asyncGetTermDepositDetailsInfo(bankAccountNumber: String, branchNumber: String, cifNo: String): String {
        Log.i("thread","account:${bankAccountNumber} branchNumber:${branchNumber} cifNumber:${cifNo}")

        val error = viewModelScope.async {
            var ret = ""
            val bean = TermDepositDetailsInfoBean()
            bean.accountNumber = bankAccountNumber
            bean.branchNumber = branchNumber
            bean.cifNumber = cifNo
            flow {
                ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, bean.toJson())
                emit(asyncWebService.AB0403Async(bean))
            }.map {
                Log.i("thread","account:${bankAccountNumber} success")
                val realmRegularDepositInfo = dbService.findAll(EPassBookAB0403::class.java)
                var detailList: MutableList<TermDepositDetails> = mutableListOf()
                if (realmRegularDepositInfo.isNotEmpty()) {
                    detailList = realmRegularDepositInfo[0]?.termDepositDetails
                        ?.fromJson<List<TermDepositDetails>>()?.toMutableList()!!
                }
                val ab0403 = EPassBookAB0403()
                ab0403.id = UUID.randomUUID().toString()
                val result = it.resultDto!!.map { r -> r.copy(accountNumber = bankAccountNumber) }.toMutableList().stream().sorted(
                    Comparator.comparing(
                        TermDepositDetails::subNo
                    )
                ).collect(Collectors.toList())
                detailList.addAll(result)
                ab0403.termDepositDetails = Gson().toJson(detailList)
                dbService.deleteAll(EPassBookAB0403::class.java)
                dbService.create(ab0403)

            }.catch {
                errorFlag = true
                Log.i("thread","account:${bankAccountNumber} error = ${it.message.toString()}")
                ret = it.message.toString()
//                throw Exception(it.message.toString())
//                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
            ret
        }.await()
        return error
    }

    suspend fun asyncGetTermDeposit(bankAccountNumber: String, branchNumber: String, cifNo: String ): String {
        Log.i("thread","account:${bankAccountNumber} branchNumber:${branchNumber} cifNumber:${cifNo}")

        val error = viewModelScope.async {
            var ret = ""
            val bean = TermDepositDetailsInfoBean()
            bean.accountNumber = bankAccountNumber
            bean.branchNumber = branchNumber
            bean.cifNumber = cifNo
            flow {
                ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, bean.toJson())
                emit(asyncWebService.AB0403Async(bean))
            }.map {
                Log.i("thread","account:${bankAccountNumber} success")
                val realmRegularDepositInfo = dbService.findAll(EPassBookAB0403::class.java)
                var detailList: MutableList<TermDepositDetails> = mutableListOf()
                if (realmRegularDepositInfo.isNotEmpty()) {
                    detailList = realmRegularDepositInfo[0]?.termDepositDetails
                        ?.fromJson<List<TermDepositDetails>>()?.toMutableList()!!
                }
                val ab0403 = EPassBookAB0403()
                ab0403.id = UUID.randomUUID().toString()
                val result = it.resultDto!!.map { r -> r.copy(accountNumber = bankAccountNumber) }.toMutableList().stream().sorted(
                    Comparator.comparing(
                        TermDepositDetails::subNo
                    )
                ).collect(Collectors.toList())

                _cacheTermDeposit[bankAccountNumber] = CertificateLoadState.Loaded(result.toMutableList())

                detailList.addAll(result)
                ab0403.termDepositDetails = Gson().toJson(detailList)
                dbService.deleteAll(EPassBookAB0403::class.java)
                dbService.create(ab0403)

            }.catch {
                errorFlag = true
                Log.i("thread","account:${bankAccountNumber} error = ${it.message.toString()}")
                ret = it.message.toString()

                _cacheTermDeposit[bankAccountNumber] = CertificateLoadState.Error(Exception("error"))
//                throw Exception(it.message.toString())
//                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
            ret
        }.await()
        return error
    }

    private suspend fun getTermDepositDetailsInfoAsync(accounts: List<MBST1201Bean>){

        val job = viewModelScope.launch {
            val chunkSize = 5
            try {
                accounts.chunked(chunkSize).forEach{ group ->
                    coroutineScope {
                        group.map { account ->
//                            Log.i("thread","")
                            async(Dispatchers.IO) {
                                asyncGetTermDepositDetailsInfo(account.accountNumber,account.branchNumber,account.cifNo)
                            }

                        }.awaitAll()
                    }
                }
            } catch ( e: Exception){

            }
        }
        job.join()
    }

    private suspend fun getInfoAsync(fixed: List<MBST1201Bean>, notice: List<MBST1201Bean>){
        viewModelScope.launch {
            ViewModelBus.eventFlow.emit(Pair("AB0403",LoadStatus.LOADING))
        }
        StopWatch.time("0403 start")
        var isError = false
        val jobFixed = viewModelScope.launch {
            val chunkSize = 15
            try {
                fixed.chunked(chunkSize).forEach{ group ->
                    coroutineScope {
                        group.map { account ->
                            async(Dispatchers.IO) {
                                try {
                                    asyncGetTermDepositDetailsInfo(account.accountNumber,account.branchNumber,account.cifNo)
                                } catch (e: Exception){
                                    Log.i("RequestTask","err = "+e.message!!)
                                }
                            }

                        }.awaitAll()
                    }
                }
            } catch ( e: Exception){
            }
        }
        jobFixed.invokeOnCompletion{ throwable ->
            when (throwable) {
                null -> {
//                    viewModelScope.launch {
//                    ViewModelBus.eventFlow.emit(Pair("AB0403",LoadStatus.COMPLETE))
//                }
                }
                else -> {
                    viewModelScope.launch {
                        ViewModelBus.eventFlow.emit(Pair("AB0403",LoadStatus.ERROR))
                    }
                    Log.i("RequestTask","異常= ${throwable.message}")
                }
            }
        }
        jobFixed.join()

        if (isError == true) {
            return
        }
        StopWatch.time("0403 end")
        viewModelScope.launch {
            ViewModelBus.eventFlow.emit(Pair("AB0403",LoadStatus.COMPLETE))
        }
        StopWatch.time("0405 start")
        viewModelScope.launch {
            ViewModelBus.eventFlow.emit(Pair("AB0405",LoadStatus.LOADING))
        }
        val jobNotice = viewModelScope.launch {
            val chunkSize = 15
            try {
                notice.chunked(chunkSize).forEach{ group ->
                    coroutineScope {
                        group.map { account ->
                            async(Dispatchers.IO) {
                                var error = ""
                                try {
                                    error = if (account.accountNumber == "0003040"){
                                        asyncGetNoticeDepositListInfo(account.accountNumber+"1",account.branchNumber,account.cifNo)
                                    }else {
                                        asyncGetNoticeDepositListInfo(account.accountNumber,account.branchNumber,account.cifNo)
                                    }
                                    if (error.isNotEmpty()){
                                        isError = true
                                        viewModelScope.launch {
                                            ViewModelBus.eventFlow.emit(Pair("AB0405",LoadStatus.ERROR))

                                        }
                                        POPWindowsUtil.postValue(value = error, parmErrorCode = ConstUtil.APP_ERROR_CODE_MBLO0007)
                                    }
                                } catch (e: Exception){
                                    Log.i("RequestTask","err = "+e.message!!)
                                    error = e.message!!

                                }
                            }

                        }.awaitAll()
                    }
                }
            } catch ( e: Exception){
            }
        }
        jobNotice.invokeOnCompletion{ throwable ->
            when (throwable) {
                null -> {
//                    viewModelScope.launch {
//                        ViewModelBus.eventFlow.emit(Pair("AB0405",LoadStatus.COMPLETE))
//                    }
                }
//                is CancellationException -> Log.i("RequestTask","キャンセル= ${throwable.message}")
                else -> {
                    viewModelScope.launch {
                        ViewModelBus.eventFlow.emit(Pair("AB0405",LoadStatus.ERROR))
                    }
                    Log.i("RequestTask","異常= ${throwable.message}")
                }
            }
        }
        jobNotice.join()
        if (isError == true) {
            return
        }
        viewModelScope.launch {
                        ViewModelBus.eventFlow.emit(Pair("AB0405",LoadStatus.COMPLETE))
                    }
        StopWatch.end("計測終了")
    }

    /**
     * 通知預金明細取得
     *
     * @param bankAccountNumber 口座番号
     * @param branchNumber 店番
     */
    private suspend fun getNoticeDepositListInfo(bankAccountNumber: String, branchNumber: String, cifNo: String) {
        viewModelScope.async {
            val bean = TermDepositDetailsInfoBean()
            bean.accountNumber = bankAccountNumber
            bean.branchNumber = branchNumber
            bean.cifNumber = cifNo
            flow {
                ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, bean.toJson())
                emit(webService.AB0405())
            }.map {
                val realmNoticeDepositInfo = dbService.findAll(EPassBookAB0405::class.java)
                var detailList: MutableList<NoticeDeposit> = mutableListOf()
                if (realmNoticeDepositInfo.isNotEmpty()) {
                    detailList = realmNoticeDepositInfo[0]?.noticeDepositList?.fromJson<MBDP1101ResponseBean>()?.noticeDepositList?.toMutableList()!!
                }
                val ab0405 = EPassBookAB0405()
                ab0405.id = UUID.randomUUID().toString()
                val result = it.resultDto
                val noticeDepositList = result!!.noticeDepositList.map { r ->
                    r.copy(accountNumber = bankAccountNumber, branchNumber = branchNumber)
                }.toMutableList()
                detailList.addAll(noticeDepositList)
                result.noticeDepositList = detailList
                ab0405.noticeDepositList = Gson().toJson(result)
                dbService.deleteAll(EPassBookAB0405::class.java)
                dbService.create(ab0405)
            }.catch {
                errorFlag = true
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }.await()
    }

    /**
     * 通知預金明細取得
     *
     * @param bankAccountNumber 口座番号
     * @param branchNumber 店番
     */
    suspend fun asyncGetNoticeDepositListInfo(bankAccountNumber: String, branchNumber: String, cifNo: String) :String {
        val error = viewModelScope.async {
            var ret = ""
            val bean = TermDepositDetailsInfoBean()
            bean.accountNumber = bankAccountNumber
            bean.branchNumber = branchNumber
            bean.cifNumber = cifNo
            flow {
                ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, bean.toJson())
                emit(asyncWebService.AB0405Async(bean))
            }.map {
                val realmNoticeDepositInfo = dbService.findAll(EPassBookAB0405::class.java)
                var detailList: MutableList<NoticeDeposit> = mutableListOf()
                if (realmNoticeDepositInfo.isNotEmpty()) {
                    detailList = realmNoticeDepositInfo[0]?.noticeDepositList?.fromJson<MBDP1101ResponseBean>()?.noticeDepositList?.toMutableList()!!
                }
                val ab0405 = EPassBookAB0405()
                ab0405.id = UUID.randomUUID().toString()
                val result = it.resultDto
                val noticeDepositList = result!!.noticeDepositList.map { r ->
                    r.copy(accountNumber = bankAccountNumber, branchNumber = branchNumber)
                }.toMutableList()
                detailList.addAll(noticeDepositList)
                result.noticeDepositList = detailList
                ab0405.noticeDepositList = Gson().toJson(result)
                dbService.deleteAll(EPassBookAB0405::class.java)
                dbService.create(ab0405)
            }.catch {
                ret = it.message.toString()
//                throw Exception(it.message.toString())
            }.collect()
            ret
        }.await()
        return error
    }

    /**
     * 通知預金明細取得
     *
     * @param bankAccountNumber 口座番号
     * @param branchNumber 店番
     */
    suspend fun asyncGetNoticeDeposit(bankAccountNumber: String, branchNumber: String, cifNo: String) :String {
        val error = viewModelScope.async {
            var ret = ""
            val bean = TermDepositDetailsInfoBean()
            bean.accountNumber = bankAccountNumber
            bean.branchNumber = branchNumber
            bean.cifNumber = cifNo
            flow {
                ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, bean.toJson())
                emit(asyncWebService.AB0405Async(bean))
            }.map {
                val realmNoticeDepositInfo = dbService.findAll(EPassBookAB0405::class.java)
                var detailList: MutableList<NoticeDeposit> = mutableListOf()
                if (realmNoticeDepositInfo.isNotEmpty()) {
                    detailList = realmNoticeDepositInfo[0]?.noticeDepositList?.fromJson<MBDP1101ResponseBean>()?.noticeDepositList?.toMutableList()!!
                }
                val ab0405 = EPassBookAB0405()
                ab0405.id = UUID.randomUUID().toString()
                val result = it.resultDto
                val noticeDepositList = result!!.noticeDepositList.map { r ->
                    r.copy(accountNumber = bankAccountNumber, branchNumber = branchNumber)
                }.toMutableList()

                _cacheNoticeDeposit[bankAccountNumber] = CertificateLoadState.Loaded(noticeDepositList)

                detailList.addAll(noticeDepositList)
                result.noticeDepositList = detailList
                ab0405.noticeDepositList = Gson().toJson(result)
                dbService.deleteAll(EPassBookAB0405::class.java)
                dbService.create(ab0405)
            }.catch {
                ret = it.message.toString()
                _cacheNoticeDeposit[bankAccountNumber] = CertificateLoadState.Error(Exception(it.message.toString()))
//                throw Exception(it.message.toString())
            }.collect()
            ret
        }.await()
        return error
    }

    private fun startGetTermDepositDetailsInfo(accounts: List<MBST1201Bean>){
        val requests = RequestTaskGroup()
        accounts.forEach{ account ->
            var task = RequestTask(
                groupId = "AB0403",
                id = account.accountNumber,
                job = {
                    asyncGetTermDepositDetailsInfo(account.accountNumber, account.branchNumber, account.cifNo)
                }
            )
            requests.tasks.add(task)
        }
        requests.id = "AB0403"
        requests.size = requests.tasks.size
        schedulerManager.putTaskGroup(requests, this)
    }

    private fun startGetNoticeDepositListInfo(accounts: List<MBST1201Bean>){
        val requests = RequestTaskGroup()
        accounts.forEach{ account ->
            var task = RequestTask(
                groupId = "AB0405",
                id = account.accountNumber,
                job = {
                    asyncGetNoticeDepositListInfo(account.accountNumber, account.branchNumber, account.cifNo)
                }
            )
            requests.tasks.add(task)
        }
        requests.id = "AB0405"
        requests.size = requests.tasks.size
        schedulerManager.putTaskGroup(requests, this)
    }

    // 証書一覧取得
    private fun getTermDepositDetailsInfo(account: MBST1201Bean){
        val requests = RequestTaskGroup()
        var task = RequestTask(
            groupId = "AB0403",
            id = account.accountNumber,
            job = {
                asyncGetTermDepositDetailsInfo(account.accountNumber, account.branchNumber, account.cifNo)
            }
        )
        requests.tasks.add(task)
        requests.id = "AB0403"
        requests.size = requests.tasks.size
        schedulerManager.putTaskGroup(requests, this)
    }

    override fun onRequestFinished(groupId: String, taskId: String, finish: Int, total: Int) {
        Log.i("RequestTask","onRequestFinished groupId = $groupId task = $taskId finish=$finish total=$total")
        when(groupId) {
            "AB0403" -> {
                if (finish == total) {
                    viewModelScope.launch {
                        ViewModelBus.eventFlow.emit(Pair(groupId,LoadStatus.COMPLETE))
                    }
                }
            }
            "AB0405" -> {
                if (finish == total) {
                    viewModelScope.launch {
                        ViewModelBus.eventFlow.emit(Pair(groupId,LoadStatus.COMPLETE))
                    }
                }
            }
        }
    }

    override fun onRequestFailed(groupId: String, taskId: String, errorMsg: String) {
        viewModelScope.launch {
            ViewModelBus.eventFlow.emit(Pair(groupId,LoadStatus.ERROR))
        }
    }

    internal suspend fun getTermDepositDetailsInfoA(bankAccountNumber: String, branchNumber: String, cifNo: String) : Boolean {
        Log.i("thread","account:${bankAccountNumber} branchNumber:${branchNumber} cifNumber:${cifNo}")

        return try {
            val bean = TermDepositDetailsInfoBean()
            bean.accountNumber = bankAccountNumber
            bean.branchNumber = branchNumber
            bean.cifNumber = cifNo
            flow {
                ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, bean.toJson())
                emit(asyncWebService.AB0403Async(bean))
            }.map {
                Log.i("thread","account:${bankAccountNumber} success")
                val realmRegularDepositInfo = dbService.findAll(EPassBookAB0403::class.java)
                var detailList: MutableList<TermDepositDetails> = mutableListOf()
                if (realmRegularDepositInfo.isNotEmpty()) {
                    detailList = realmRegularDepositInfo[0]?.termDepositDetails
                        ?.fromJson<List<TermDepositDetails>>()?.toMutableList()!!
                }
                val ab0403 = EPassBookAB0403()
                ab0403.id = UUID.randomUUID().toString()
                val result = it.resultDto!!.map { r -> r.copy(accountNumber = bankAccountNumber) }.toMutableList().stream().sorted(
                    Comparator.comparing(
                        TermDepositDetails::subNo
                    )
                ).collect(Collectors.toList())
                detailList.addAll(result)
                ab0403.termDepositDetails = Gson().toJson(detailList)
                dbService.deleteAll(EPassBookAB0403::class.java)
                dbService.create(ab0403)

            }.collect()
            true
        } catch (e: Exception) {
            false
        }

    }

    internal suspend fun getNoticeDepositListInfoA(bankAccountNumber: String, branchNumber: String, cifNo: String) : Boolean {
        Log.i("thread","account:${bankAccountNumber} branchNumber:${branchNumber} cifNumber:${cifNo}")

        return try {
            val bean = TermDepositDetailsInfoBean()
            bean.accountNumber = bankAccountNumber
            bean.branchNumber = branchNumber
            bean.cifNumber = cifNo
            flow {
                ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, bean.toJson())
                emit(asyncWebService.AB0405Async(bean))
            }.map {
                val realmNoticeDepositInfo = dbService.findAll(EPassBookAB0405::class.java)
                var detailList: MutableList<NoticeDeposit> = mutableListOf()
                if (realmNoticeDepositInfo.isNotEmpty()) {
                    detailList = realmNoticeDepositInfo[0]?.noticeDepositList?.fromJson<MBDP1101ResponseBean>()?.noticeDepositList?.toMutableList()!!
                }
                val ab0405 = EPassBookAB0405()
                ab0405.id = UUID.randomUUID().toString()
                val result = it.resultDto
                val noticeDepositList = result!!.noticeDepositList.map { r ->
                    r.copy(accountNumber = bankAccountNumber, branchNumber = branchNumber)
                }.toMutableList()
                detailList.addAll(noticeDepositList)
                result.noticeDepositList = detailList
                ab0405.noticeDepositList = Gson().toJson(result)
                dbService.deleteAll(EPassBookAB0405::class.java)
                dbService.create(ab0405)
            }.catch {
                it.message.toString()
//                throw Exception(it.message.toString())
            }.collect()
            true
        } catch (e: Exception) {
            false
        }

    }
}

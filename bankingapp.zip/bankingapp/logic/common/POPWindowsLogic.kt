package jp.co.jsbank.mb.bankingapp.logic.common

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.ui.pages.common.state.POPWindowsState
import jp.co.jsbank.mb.bankingapp.utils.ApiRequestUtil
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil
import jp.co.jsbank.mb.bankingapp.utils.ErrorUtil
import jp.co.jsbank.mb.bankingapp.utils.PreferenceUtil
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * 共通メッセージ表示
 */
@HiltViewModel
class POPWindowsLogic @Inject constructor(
    private var webService: RestService,
) : ViewModel() {

    var viewStates by mutableStateOf(POPWindowsState())
        private set

    /**
     * エラーダイアログを開
     */
    fun openErrorDialog() {
        viewStates = viewStates.copy(errorFlag = true)
    }

    /**
     * エラーダイアログを閉じる
     */
    fun closeErrorDialog() {
        viewStates = viewStates.copy(errorFlag = false)
    }

    /**
     * 店舗リストを取得する
     */
    fun getDeptList() {
        // 画面IDとイベントID設定
        PreferenceUtil.setScreenIDAndEventID("MBCO6201", "E01")
        viewModelScope.launch {
            flow {
                ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST)
                emit(webService.AB0112())
            }.map {
                closeErrorDialog()
            }.catch {
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }
    }
}

package jp.co.jsbank.mb.bankingapp.logic.common

import android.annotation.SuppressLint
import android.app.Activity
import android.content.pm.ActivityInfo
import android.nfc.Tag
import android.util.Log
import android.view.Window
import android.view.WindowManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.google.firebase.crashlytics.ktx.crashlytics
import com.google.firebase.ktx.Firebase
import dagger.hilt.android.lifecycle.HiltViewModel
import jp.co.jsbank.mb.bankingapp.fragment.IntroductionFirstFragment
import jp.co.jsbank.mb.bankingapp.system.Config
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.ui.pages.common.state.ToLoginState
import jp.co.jsbank.mb.bankingapp.utils.*
import javax.inject.Inject


/**
 * 共通メッセージ表示
 */
@HiltViewModel
class ToLoginLogic @Inject constructor() : ViewModel() {

    var viewStates by mutableStateOf(ToLoginState())
        private set

    /**
     * エラーダイアログを開
     */
    fun openErrorDialog() {
        viewStates = viewStates.copy(errorScreenFlag = true)
    }

    /**
     * エラーダイアログを閉じる
     */
    fun closeErrorDialog() {
        viewStates = viewStates.copy(errorScreenFlag = false)
    }

    /**
     * 初期化
     */
    init {
        // 生体認証を呼び出す
        doBiometric()
    }

    /**
     * 生体認証を呼び出す
     */
    private fun doBiometric() {
        val biometricEnable = BiometricsUtil().checkBiometricAvailable()
        if (biometricEnable && PreferenceUtil.getPreferenceBooleanValue(ConstUtil.BIOLOGICAL_STATE)) {
            // 生体認証利用可能の場合、顔認証/指紋認証を呼び出して、ログインを行う
            if (!PreferenceUtil.getPreferenceBooleanValue(ConstUtil.EXECUTE_BACKGROUND_FLAG) && MainActivity.IS_BACK_GROUND) {
                BiometricsUtil().biometricAuthenticate()
            }
        } else {
            // リセットフラグ
            PreferenceUtil.setPreferenceStringValue(ConstUtil.BIOMETRIC_RESULT, ConstUtil.BIOMETRIC_RESULT_NOT_ACCESS)
        }
    }

    /**
     * 認証
     */
    fun goAuthentication() {
        when (PreferenceUtil.getPreferenceStringValue(ConstUtil.BIOMETRIC_RESULT)) {
            // 認証成功
            ConstUtil.BIOMETRIC_RESULT_ACCESS_SUCCESS -> {
                // PIN不正カウントリセット
                PreferenceUtil.setPreferenceIntValue(ConstUtil.PASS_ERR_COUNT, 0)
                this.viewStates = this.viewStates.copy(passwordErr = false, password = "")
                MainActivity.IS_BACK_GROUND = false
                MainActivity.TOP_INFO_TIMER_FLAG = true
                if (viewStates.screenFlg) {
                    if (MainActivity.ACTIVITY?.requestedOrientation == ActivityInfo.SCREEN_ORIENTATION_PORTRAIT) {
                        PreferenceUtil.setPreferenceBooleanValue(ConstUtil.PAGE_NO_DESTROY_FLAG, true)
                        MainActivity.ACTIVITY?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                    }
                }
            }
            // 認証失敗
            ConstUtil.BIOMETRIC_RESULT_ACCESS_FAIL -> {
                FirebaseUtil.addLog("生体認証失敗したため、systemInfoClearを実行[ToLoginLogic.kt]")
                // バンキングアプリ初期化
                systemInfoClear()
            }
            // 認証取消す
            ConstUtil.BIOMETRIC_RESULT_ACCESS_CANCEL -> {
                // リセットフラグ
                PreferenceUtil.setPreferenceStringValue(
                    ConstUtil.BIOMETRIC_RESULT,
                    ConstUtil.BIOMETRIC_RESULT_NOT_ACCESS
                )
            }
        }
        PreferenceUtil.setPreferenceBooleanValue(ConstUtil.EXECUTE_BACKGROUND_FLAG, false)
    }

    /**
     * アプリのパスワード入力イベント(3桁目まで)
     */
    fun onPasswordChangeUnderThree(value: Int){
        this.viewStates = this.viewStates.copy(password = (this.viewStates.password + value.toString()))
    }

    /**
     * アプリのパスワード入力イベント(4桁目)
     */
    fun onPasswordChangeFour(value: Int): Boolean{
        var returnFlg = false
        this.viewStates = this.viewStates.copy(password = (this.viewStates.password + value.toString()))
        // アプリのパスワード認証処理を行う
        val checkResult: Boolean = passwordCheck()
        if (checkResult) {
            // PIN不正カウントリセット
            PreferenceUtil.setPreferenceIntValue(ConstUtil.PASS_ERR_COUNT, 0)
            this.viewStates = this.viewStates.copy(passwordErr = false, password = "")
            MainActivity.IS_BACK_GROUND = false
            MainActivity.TOP_INFO_TIMER_FLAG = true
            returnFlg = true
            if (viewStates.screenFlg) {
                if (MainActivity.ACTIVITY?.requestedOrientation == ActivityInfo.SCREEN_ORIENTATION_PORTRAIT) {
                    PreferenceUtil.setPreferenceBooleanValue(ConstUtil.PAGE_NO_DESTROY_FLAG, true)
                    MainActivity.ACTIVITY?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                }
            }
        } else {
            // PINが不正な場合
            // PIN不正カウント設定
            PreferenceUtil.setPreferenceIntValue(
                ConstUtil.PASS_ERR_COUNT,
                PreferenceUtil.getPreferenceIntValue(ConstUtil.PASS_ERR_COUNT) + 1
            )
            if (PreferenceUtil.getPreferenceIntValue(ConstUtil.PASS_ERR_COUNT) >= Config.TRY_COUNT) {
                // プッシュ通知登録成功フラグ
                PreferenceUtil.removePreferenceStringValue(ConstUtil.PUSH_OK_FLAG)
                FirebaseUtil.addLog("PINが不正な場合ため、systemInfoClearを実行[ToLoginLogic.kt]")
                // バンキングアプリ初期化
                systemInfoClear()
            } else {
                this.viewStates = this.viewStates.copy(passwordErr = true, password = "")
            }
        }
        return returnFlg
    }

    /**
     * アプリのパスワード削除イベント
     */
    fun onPasswordDelete() {
        if (viewStates.password.isNotEmpty()) {
            viewStates = viewStates.copy(password = (viewStates.password.substring(0, viewStates.password.length - 1)))
        }
    }

    /**
     * 入力されたPINを検証する
     */
    private fun passwordCheck(): Boolean {
        val list : Array<String> = arrayOf(
            ConstUtil.COMMON_KEY_LABEL
        )
        val jagPeerBean = KeyStoreUtil().getJagInfo(list)
        // 入力されたPINをハッシュする
        val hashPassword: String = CommonKeyAESUtil().encrypt(
            viewStates.password,
            jagPeerBean.jagEncryptedKey
        )
        // 入力されたPINを検証する
        return (hashPassword == KeyStoreUtil().getFromKeyStore(ConstUtil.PIN))
    }
}


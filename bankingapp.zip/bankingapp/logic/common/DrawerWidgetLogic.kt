package jp.co.jsbank.mb.bankingapp.logic.common

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import java.time.LocalDate
import javax.inject.Inject
import jp.co.jsbank.mb.bankingapp.ui.widgets.drawer.DrawerWidgetState

/**
 * 口座情報取得
 */
@OptIn(ExperimentalComposeUiApi::class)
@HiltViewModel
class DrawerWidgetLogic @Inject constructor() : ViewModel() {

    // ログインステータス
    var viewStates by mutableStateOf(DrawerWidgetState())

    /**
     * 初期化
     */
    fun doInit(dateTo: LocalDate) {
        viewStates = viewStates.copy(dateFrom = dateTo.plusMonths(-5), dateTo = dateTo, initFlag = false)
    }

    /**
     * 期間終了日ダイアログ
     */
    fun openDateToDialog() {
        viewStates = viewStates.copy(dateToDialogFlag = true)
    }

    /**
     * 期間終了日ダイアログクルーズ
     */
    fun closeDateToDialog() {
        viewStates = viewStates.copy(dateToDialogFlag = false)
    }

    /**
     * 年月設定
     */
    fun changeDateDuration(dateTo: LocalDate) {
        viewStates = viewStates.copy(dateFrom = dateTo.plusMonths(-5), dateTo = dateTo)
    }
}

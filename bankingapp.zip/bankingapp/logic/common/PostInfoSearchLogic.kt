package jp.co.jsbank.mb.bankingapp.logic.common

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import javax.inject.Inject
import jp.co.jsbank.mb.bankingapp.bean.common.PostCodeRequestBean
import jp.co.jsbank.mb.bankingapp.bean.common.PostCodeResponseBean
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.utils.*
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map

/**
 * 郵便番号の自動検索
 */
class PostInfoSearchLogic @Inject constructor(
    private var webService: RestService
) : ViewModel() {

    /**
     * 口座情報
     */
    private var postInfo: List<PostCodeResponseBean> = listOf()

    /**
     * 郵便番号の自動検索
     */
    suspend fun getPostInfo(
        requestBean: PostCodeRequestBean,
        screenID: String,
        eventID: String
    ): List<PostCodeResponseBean> {
        // 画面IDとイベントID設定
        PreferenceUtil.setScreenIDAndEventID(screenID, eventID)
        getInfo(requestBean)
        return postInfo
    }

    private suspend fun getInfo(
        requestBean: PostCodeRequestBean
    ) {
        viewModelScope.async {
            flow {
                ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, requestBean.toJson())
                emit(webService.AB0710())
            }.map {
                postInfo = it.resultDto!!
            }.catch {
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }.await()
    }
}

package jp.co.jsbank.mb.bankingapp.logic.common

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import io.realm.Realm
import jp.co.jsbank.mb.bankingapp.bean.common.JagPeerBean
import jp.co.jsbank.mb.bankingapp.bean.splash.mbco6201.MBCO6201RequestBean
import jp.co.jsbank.mb.bankingapp.repositories.api.request.gateway.GatewayRestService
import jp.co.jsbank.mb.bankingapp.repositories.db.common.findAll
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.PublicKey
import jp.co.jsbank.mb.bankingapp.system.Config
import jp.co.jsbank.mb.bankingapp.system.master.JagApiServiceCode
import jp.co.jsbank.mb.bankingapp.utils.*
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import java.util.*
import javax.inject.Inject

/**
 * 口座情報取得
 */
class RefreshLogic @Inject constructor(
    private var gatewayWebService: GatewayRestService
) : ViewModel() {
    private var okFlag = false

    suspend fun az0913(): Boolean {
        viewModelScope.async {
            getNewAccessToken()
        }.await()
        return okFlag
    }

    suspend fun az0911(): Boolean {
        viewModelScope.async {
            getRefreshToken()
        }.await()
        return okFlag
    }

    suspend fun az0903(): Boolean {
        viewModelScope.async {
            publicKeyUpdate()
        }.await()
        return okFlag
    }

    /**
     * アクセストークン取得
     */
    private suspend fun getNewAccessToken() {
        val param = MBCO6201RequestBean()
        // JAG PROFILE JWTをローカルに保存する
        val jagProfile = JWTUtil().createJWT(jwtType = 1)
        val list : Array<String> = arrayOf(
            ConstUtil.JAG_RES_TRXID,
            ConstUtil.DEVICE_ID
        )
        val jagPeerBean = KeyStoreUtil().getJagInfo(list)

        // JAG PROFILE JWT
        param.jagProfile = jagProfile
        // デバイスID
        param.jagDeviceId = jagPeerBean.deviceId
        // アプリケーションID
        param.jagApplicationId = Config.getAppId()
        // TRX種別
        param.jagTrxType = ConstUtil.JAG_TRX_TYPE_NRM
        // トランザクションID
        param.jagTrxId = jagPeerBean.jagTrxId
        // API サービス名称
        PreferenceUtil.setPreferenceStringValue(ConstUtil.API_SERVICE_NAME, JagApiServiceCode.AZ0913.value)
        viewModelScope.async {
            flow {
                emit(gatewayWebService.AZ0913(param))
            }.map {
                okFlag = true
                // Jag情報ローカルに保存する
                KeyStoreUtil().jagInfoSave(
                    JagPeerBean(
                        jagTrxId = it.jagTrxId,
                        jagAccessToken = it.jagAccessToken,
                        jagRefreshToken = it.jagRefreshToken
                    )
                )
            }.catch {
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }.await()
    }

    /**
     * アクセストークン取得
     */
    private suspend fun getRefreshToken() {
        val param = MBCO6201RequestBean()
        val list : Array<String> = arrayOf(
            ConstUtil.JAG_RES_TRXID,
            ConstUtil.DEVICE_ID
        )
        val jagPeerBean = KeyStoreUtil().getJagInfo(list)

        // JAG PROFILE JWT
        val jagProfile = JWTUtil().createJWT()
        param.jagProfile = jagProfile
        // デバイスID
        param.jagDeviceId = jagPeerBean.deviceId
        // アプリケーションID
        param.jagApplicationId = Config.getAppId()
        // TRX種別
        param.jagTrxType = ConstUtil.JAG_TRX_TYPE_NRM
        // トランザクションID
        param.jagTrxId = jagPeerBean.jagTrxId
        // API サービス名称
        PreferenceUtil.setPreferenceStringValue(ConstUtil.API_SERVICE_NAME, JagApiServiceCode.AZ0911.value)
        viewModelScope.async {
            flow {
                emit(gatewayWebService.AZ0911(param))
            }.map {
                okFlag = true
                // Jag情報ローカルに保存する
                KeyStoreUtil().jagInfoSave(
                    JagPeerBean(
                        jagTrxId = it.jagTrxId,
                        jagAccessToken = it.jagAccessToken,
                        jagRefreshToken = it.jagRefreshToken
                    )
                )
            }.catch {
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }.await()
    }

    /**
     * アクセストークン取得
     */
    private suspend fun publicKeyUpdate() {
        val publicKeyInfo = Realm.getDefaultInstance().findAll(PublicKey::class.java)
        val param = MBCO6201RequestBean()

        val list : Array<String> = arrayOf(
            ConstUtil.COMMON_KEY_LABEL,
            ConstUtil.DEVICE_ID
        )
        val jagPeerBean = KeyStoreUtil().getJagInfo(list)
        // デバイスID
        val deviceId = jagPeerBean.deviceId
        // 旧公開鍵
        val publicKeyInvalid = RSAUtil().loadPublicKeyByFile()
        // 新公開鍵を作成
        RSAUtil().createNewKey()

        // パラメータを下記よに設定する
        // デバイスID
        param.jagDeviceId = deviceId
        // アプリケーションID
        param.jagApplicationId = Config.getAppId()
        // 旧公開鍵
        param.jagPublicKeyInvalid = publicKeyInvalid
        // 新公開鍵
        param.jagPublicKey = publicKeyInfo[0]!!.publicKey
        // チャレンジトークン
        param.jagChallengeToken = RSAUtil().encryptAESByJavaCrypt(
            deviceId,
            RSAUtil().rsaDecrypt(jagPeerBean.jagEncryptedKey),
            String(Base64.getDecoder().decode(ConstUtil.JAG_ENV_CLIENT_SECRET_KEY))
        )
        param.jagTrxType = ConstUtil.JAG_TRX_TYPE_TCC
        // トランザクションID
        param.jagTrxId = ""
        // API サービス名称
        PreferenceUtil.setPreferenceStringValue(ConstUtil.API_SERVICE_NAME, JagApiServiceCode.AZ0903.value)
        viewModelScope.async {
            flow {
                emit(gatewayWebService.AZ0903(param))
            }.map {
                // 保存したローカルパスワード取得
                val oldPassword = CommonKeyAESUtil().decrypt(
                    KeyStoreUtil().getFromKeyStore(ConstUtil.PIN),
                    jagPeerBean.jagEncryptedKey
                )
                // 新公開鍵を保存
                RSAUtil().createNewKey(saveFlag = true)
                // Jag情報ローカルに保存する
                KeyStoreUtil().jagInfoSave(
                    JagPeerBean(jagTrxId = it.jagTrxId, jagEncryptedKey = it.jagEncryptedKey)
                )
                KeyStoreUtil().saveToKeyStore(
                    ConstUtil.PIN,
                    CommonKeyAESUtil().encrypt(
                        oldPassword,
                        it.jagEncryptedKey
                    )
                )
                // TCC確定
                az0906()
            }.catch {
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }.await()
    }

    /**
     * AZ0906 TCC確定
     */
    private suspend fun az0906() {
        val param = MBCO6201RequestBean()
        val list : Array<String> = arrayOf(
            ConstUtil.JAG_RES_TRXID,
            ConstUtil.COMMON_KEY_LABEL,
            ConstUtil.DEVICE_ID
        )
        val jagPeerBean = KeyStoreUtil().getJagInfo(list)
        // デバイスID
        val deviceId = jagPeerBean.deviceId
        // トランザクションID
        val trxId = jagPeerBean.jagTrxId
        // チャレンジトークン
        val challengeToken = RSAUtil().encryptAESByJavaCrypt(
            trxId,
            RSAUtil().rsaDecrypt(jagPeerBean.jagEncryptedKey),
            String(Base64.getDecoder().decode(ConstUtil.JAG_ENV_CLIENT_SECRET_KEY))
        )

        // パラメータを下記よに設定する
        // デバイスID
        param.jagDeviceId = deviceId
        // アプリケーションID
        param.jagApplicationId = Config.getAppId()
        // トランザクションID
        param.jagTrxId = trxId
        // チャレンジトークン
        param.jagChallengeToken = challengeToken
        // 確定キャンセル要求
        param.jagDoCancel = ConstUtil.JAG_TRX_DO_CONFIRM
        // API サービス名称
        PreferenceUtil.setPreferenceStringValue(ConstUtil.API_SERVICE_NAME, JagApiServiceCode.AZ0906.value)

        viewModelScope.async {
            flow {
                emit(gatewayWebService.AZ0906(param))
            }.map {
                if (it == ConstUtil.API_RESULT_OK) {
                    okFlag = true
                }
            }.catch {
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }.await()
    }
}

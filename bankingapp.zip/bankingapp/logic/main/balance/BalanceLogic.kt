package jp.co.jsbank.mb.bankingapp.logic.main.balance

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import javax.inject.Inject
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.bean.common.AllBalanceInfoBean
import jp.co.jsbank.mb.bankingapp.bean.common.CodeBean
import jp.co.jsbank.mb.bankingapp.bean.main.home.BalanceInformation
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.system.master.Subject
import jp.co.jsbank.mb.bankingapp.ui.pages.main.balance.BalancePageState
import jp.co.jsbank.mb.bankingapp.ui.widgets.barchart.BarChartData
import jp.co.jsbank.mb.bankingapp.ui.widgets.drawer.DataInfo
import jp.co.jsbank.mb.bankingapp.utils.*
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.HALF_HYPHEN
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/**
 * 収支グラフロジック.
 */
@HiltViewModel
class BalanceLogic @Inject constructor(
    private var webService: RestService,
) : ViewModel() {

    var viewStates by mutableStateOf(BalancePageState())
        private set

    /**
     * 初期化
     */
    init {
        viewModelScope.launch {
            LoadingUtil.setLoadingValue(value = true, type = true)
            getAccountInfo()
            if (!viewStates.errorFlag) {
                getAllBalanceInfo()
            }
            getGraphInfo()
            val dtf = DateTimeFormatter.ofPattern("yyyy.MM.dd HH:mm")
            viewStates = viewStates.copy(updateTime = dtf.format(LocalDateTime.now()))
            LoadingUtil.setLoadingValue(value = false)
        }
    }

    /**
     * 口座情報取得
     */
    private suspend fun getAccountInfo() {
        // 画面IDとイベントID設定
        PreferenceUtil.setScreenIDAndEventID("MBDP0121", "E01")
        viewStates = viewStates.copy(errorFlag = false)
        viewModelScope.async {
            flow {
                ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST)
                emit(webService.AB0401())
            }.map {
                it.resultDto?.accountInfoResponseDtoList!!.forEach { balanceInfo ->
                    viewStates.accountInfoList.add(
                        BalanceInformation(
                            accountNumber = balanceInfo.accountNumber,
                            subjectNameCode = balanceInfo.subjectNameCode,
                            subjectNameValue = balanceInfo.subjectNameValue,
                            balance = balanceInfo.balance,
                            fundingBalance = balanceInfo.fundingBalance,
                            branchName = balanceInfo.branchName,
                            branchNumber = balanceInfo.branchNumber,
                        )
                    )
                }
                // 科目種別リストを取得する
                val subjectBalanceMap = mutableMapOf<String, MutableList<BalanceInformation>>()
                // 普通預金
                val ordinaryDepositList =
                    viewStates.accountInfoList.filter { b -> b.subjectNameCode == Subject.ORDINARY_DEPOSIT.code }
                        .toMutableList()
                if (ordinaryDepositList.isNotEmpty()) {
                    viewStates.subjectInfoList.add(
                        CodeBean(
                            Subject.ORDINARY_DEPOSIT.code,
                            Subject.ORDINARY_DEPOSIT.value
                        )
                    )
                    subjectBalanceMap[Subject.ORDINARY_DEPOSIT.code] = ordinaryDepositList
                }
                // 当座預金
                val checkingAccountList =
                    viewStates.accountInfoList.filter { b -> b.subjectNameCode == Subject.CHECKING_ACCOUNT.code }
                        .toMutableList()
                if (checkingAccountList.isNotEmpty()) {
                    viewStates.subjectInfoList.add(
                        CodeBean(
                            Subject.CHECKING_ACCOUNT.code,
                            Subject.CHECKING_ACCOUNT.value
                        )
                    )
                    subjectBalanceMap[Subject.CHECKING_ACCOUNT.code] = checkingAccountList
                }
                // 納税準備預金
                val taxDepositList =
                    viewStates.accountInfoList.filter { b -> b.subjectNameCode == Subject.TAX_DEPOSIT.code }
                        .toMutableList()
                if (taxDepositList.isNotEmpty()) {
                    viewStates.subjectInfoList.add(
                        CodeBean(
                            Subject.TAX_DEPOSIT.code,
                            "納税準備預金"
                        )
                    )
                    subjectBalanceMap[Subject.TAX_DEPOSIT.code] = taxDepositList
                }
                viewStates = viewStates.copy(subjectBalanceMap = subjectBalanceMap)
                if (viewStates.subjectInfoList.isNotEmpty()) {
                    // 選択された科目を設定する
                    viewStates =
                        viewStates.copy(selectedSubject = viewStates.subjectInfoList[0])
                    // 選択された科目の口座情報
                    val subjectBalanceInfoList = subjectBalanceMap[viewStates.selectedSubject.code]!!
                    subjectBalanceInfoList.forEachIndexed { index, item ->
                        item.selected = (index == 0)
                    }
                    viewStates = viewStates.copy(
                        subjectBalanceInfoList = subjectBalanceInfoList,
                        accountNumber = subjectBalanceInfoList[0].accountNumber,
                        branchNumber = subjectBalanceInfoList[0].branchNumber
                    )
                }
            }.catch {
                viewStates = viewStates.copy(errorFlag = true)
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }.await()
    }

    /**
     * 全部のグラフ情報取得
     */
    private suspend fun getAllBalanceInfo() {
        // 画面IDとイベントID設定
        PreferenceUtil.setScreenIDAndEventID("MBDP0121", "E01")
        viewStates = viewStates.copy(errorFlag = false)
        viewModelScope.async {
            val bean = AllBalanceInfoBean()
            bean.accountNumber = viewStates.accountNumber
            bean.branchNumber = viewStates.branchNumber
            bean.accountType = GenericCodeUtil.autoGenericCode(viewStates.selectedSubject.code, 3)
            flow {
                ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, bean.toJson())
                emit(webService.AB0407())
            }.map {
                viewStates = viewStates.copy(allBalanceInfoList = it.resultDto!!)
            }.catch {
                viewStates = viewStates.copy(allBalanceInfoList = listOf(), errorFlag = true)
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }.await()
    }

    /**
     * 期間別グラフ情報取得
     */
    private fun getGraphInfo() {
        val balanceInfoList: MutableList<BarChartData.BalanceInfo> = mutableListOf()
        viewStates.allBalanceInfoList.filter {
            LocalDate.of(it.balanceMonth.split(HALF_HYPHEN)[0].toInt(), it.balanceMonth.split(HALF_HYPHEN)[1].toInt(), 2)
                .compareTo(viewStates.dateFrom) == 0
        }
        balanceInfoList.add(getMonthGraphInfo(viewStates.dateFrom))
        balanceInfoList.add(getMonthGraphInfo(viewStates.dateFrom.plusMonths(1)))
        balanceInfoList.add(getMonthGraphInfo(viewStates.dateFrom.plusMonths(2)))
        balanceInfoList.add(getMonthGraphInfo(viewStates.dateFrom.plusMonths(3)))
        balanceInfoList.add(getMonthGraphInfo(viewStates.dateFrom.plusMonths(4)))
        balanceInfoList.add(getMonthGraphInfo(viewStates.dateFrom.plusMonths(5)))
        viewStates = viewStates.copy(balanceInfoList = balanceInfoList)
    }

    /**
     * 月別グラフ情報取得
     */
    private fun getMonthGraphInfo(date: LocalDate): BarChartData.BalanceInfo {
        val monthGraphInfo = viewStates.allBalanceInfoList.filter {
            it.balanceMonth.split(HALF_HYPHEN)[0].toInt() == date.year &&
                it.balanceMonth.split(HALF_HYPHEN)[1].toInt() == date.monthValue
        }.toList()
        return if (monthGraphInfo.isNotEmpty()) {
            BarChartData.BalanceInfo(
                balanceMonth = "${monthGraphInfo[0].balanceMonth.split(HALF_HYPHEN)[1].toInt()}月",
                depositAmount = monthGraphInfo[0].depositAmount.replace(",", "").toLong(),
                investedAmount = monthGraphInfo[0].investedAmount.replace(",", "").toLong(),
                balance = monthGraphInfo[0].monthlyBalance.replace(",", "").toLong(),
            )
        } else {
            BarChartData.BalanceInfo(
                balanceMonth = "${date.monthValue}月",
            )
        }
    }

    /**
     * 科目切替
     */
    fun switchSubject(targetSubject: CodeBean) {
        viewStates = viewStates.copy(selectedSubject = targetSubject)
        // 科目の背景画像取得
        val backgroundImage = when (targetSubject.code) {
            Subject.ORDINARY_DEPOSIT.code -> R.drawable.usually_account_details_background
            Subject.CHECKING_ACCOUNT.code -> R.drawable.current_account_details_background
            else -> R.drawable.pay_tax_account_details_background
        }
        viewStates = viewStates.copy(backgroundImage = backgroundImage)
        // 選択された科目の口座情報
        val subjectBalanceInfoList = viewStates.subjectBalanceMap[viewStates.selectedSubject.code]!!
        subjectBalanceInfoList.forEachIndexed { index, item ->
            item.selected = (index == 0)
        }
        // 選択された科目の口座情報切替
        viewStates = viewStates.copy(
            subjectBalanceInfoList = subjectBalanceInfoList,
            accountNumber = subjectBalanceInfoList[0].accountNumber,
            branchNumber = subjectBalanceInfoList[0].branchNumber
        )
        // 画面情報切替
        viewModelScope.launch {
            getAllBalanceInfo()
            getGraphInfo()
        }
    }

    /**
     * 口座情報切替
     */
    fun switchAccountInfo(index: Int) {
        val subjectBalanceInfoList = viewStates.subjectBalanceMap[viewStates.selectedSubject.code]!!.map {
            it.copy()
        }.toMutableList()
        subjectBalanceInfoList.forEachIndexed { i, item ->
            item.selected = (index == i)
        }
        viewStates = viewStates.copy(
            subjectBalanceInfoList = subjectBalanceInfoList,
            accountNumber = subjectBalanceInfoList[index].accountNumber,
            branchNumber = subjectBalanceInfoList[index].branchNumber
        )
        // 画面情報切替
        viewModelScope.launch {
            getAllBalanceInfo()
            getGraphInfo()
        }
    }

    /**
     * 日付切替
     *
     * @param type 1:左 2:右
     */
    fun switchDateDuration(type: String) {
        val dateFrom = viewStates.dateFrom
        val dateTo = viewStates.dateTo
        viewStates = if (type == "1") {
            viewStates.copy(
                dateFrom = LocalDate.of(
                    dateFrom.plusMonths(-6).year,
                    dateFrom.plusMonths(-6).month,
                    1
                ),
                dateTo = LocalDate.of(
                    dateTo.plusMonths(-6).year,
                    dateTo.plusMonths(-6).month,
                    dateTo.plusMonths(-6).month.length(dateTo.plusMonths(-6).isLeapYear)
                )
            )
        } else {
            viewStates.copy(
                dateFrom = LocalDate.of(
                    dateFrom.plusMonths(6).year,
                    dateFrom.plusMonths(6).month,
                    1
                ),
                dateTo = LocalDate.of(
                    dateTo.plusMonths(6).year,
                    dateTo.plusMonths(6).month,
                    dateTo.plusMonths(6).month.length(dateTo.plusMonths(6).isLeapYear)
                )
            )
        }

        // 日付変更事件
        getGraphInfo()
    }

    /**
     * 年月設定
     */
    fun changeDateDuration(dataInfo: DataInfo) {
        viewStates = viewStates.copy(
            dateFrom = LocalDate.of(
                dataInfo.dateFrom.year,
                dataInfo.dateFrom.month,
                1
            ),
            dateTo = LocalDate.of(
                dataInfo.dateTo.year,
                dataInfo.dateTo.month,
                dataInfo.dateTo.month.length(dataInfo.dateTo.isLeapYear)
            )
        )
        // 日付変更事件
        getGraphInfo()
    }
}

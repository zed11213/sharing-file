package jp.co.jsbank.mb.bankingapp.logic.main.home

import android.util.Log
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.android.gms.tasks.Tasks.await
import jp.co.jsbank.mb.bankingapp.system.master.AccountType
import com.google.android.play.core.review.ReviewManagerFactory
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import dagger.hilt.android.lifecycle.HiltViewModel
import hilt_aggregated_deps._jp_co_jsbank_mb_bankingapp_system_CrashDialogActivity_GeneratedInjector
import io.realm.Realm
import jp.co.jsbank.mb.bankingapp.bean.login.mblg.mblg0201.NoticeDeposit
import jp.co.jsbank.mb.bankingapp.bean.main.home.BalanceInformation
import jp.co.jsbank.mb.bankingapp.bean.main.home.mbdp.mbdp0301.LatestReceipDetailsDto
import jp.co.jsbank.mb.bankingapp.bean.main.home.mbdp.mbdp0301.LotteryResultsDetailsDto
import jp.co.jsbank.mb.bankingapp.bean.main.home.mbdp.mbdp0301.TermDepositDetails
import jp.co.jsbank.mb.bankingapp.bean.main.home.mbdp.mbdp1101.MBDP1101ResponseBean
import jp.co.jsbank.mb.bankingapp.bean.main.home.mbnt.mbnt0101.Anncmnt
import jp.co.jsbank.mb.bankingapp.bean.main.home.mbnt.mbnt0101.CifNoBean
import jp.co.jsbank.mb.bankingapp.bean.main.home.mbnt.mbnt0101.ElectronicIssueParameter
import jp.co.jsbank.mb.bankingapp.bean.main.menu.mbst.mbst1201.MBST1201Bean
import jp.co.jsbank.mb.bankingapp.logic.common.AccountInfoLogic
import jp.co.jsbank.mb.bankingapp.logic.main.home.mbnt.mbnt0101.getTransitionInfo
import jp.co.jsbank.mb.bankingapp.repositories.api.async.LoadStatus
import jp.co.jsbank.mb.bankingapp.repositories.api.request.AsyncRestService
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.repositories.db.common.findAll
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.EPassBookAB0401
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.EPassBookAB0403
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.EPassBookAB0405
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.EPassBookAB1001
import jp.co.jsbank.mb.bankingapp.system.Config.TOP_INFO_REFRESH_INTERVAL
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.system.MainActivity.Companion.ACTIVITY
import jp.co.jsbank.mb.bankingapp.system.MainActivity.Companion.HOME_INFO_REFRESH_FLAG
import jp.co.jsbank.mb.bankingapp.system.MyApp
import jp.co.jsbank.mb.bankingapp.system.MyApp.Companion.SCREEN_WIDTH
import jp.co.jsbank.mb.bankingapp.system.master.*
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.CertificateLoadState
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.HomePageState
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.NoticeCertificateState
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.TermCertificateState
import jp.co.jsbank.mb.bankingapp.ui.pages.main.home.mbrc.mbrc0201.MBRC0201Parameter
import jp.co.jsbank.mb.bankingapp.utils.*
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.CHECKING_ACCOUNT_READ_FLAG
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.COMPREHENSIVE_ACCOUNT_READ_FLAG
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.HALF_HYPHEN
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.LAST_LOGIN_TIME
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.ORDINARY_DEPOSIT_READ_FLAG
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.TAX_DEPOSIT_READ_FLAG
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import org.jetbrains.annotations.Async
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.*
import java.util.stream.Collectors
import javax.inject.Inject
import kotlin.collections.filter
import kotlin.collections.isNotEmpty

/**
 * トップロジック.
 */
@HiltViewModel
class HomeLogic @Inject constructor(
    webService: RestService,
    asyncWebService: AsyncRestService
) : ViewModel() {

    var viewStates by mutableStateOf(HomePageState())
        private set

    // ロカールDB
    private var dbService: Realm = MyApp.INSTANCE

    private val accountInfoLogic = AccountInfoLogic(webService,asyncWebService)

    /**
     * 初期化.
     */
    init {
        val dtf = DateTimeFormatter.ofPattern("yyyy.MM.dd HH:mm", Locale.JAPAN)
        // 内部レビュー開始日取得フラグがfalse場合、開始タイミング取得する
        if (!PreferenceUtil.getPreferenceBooleanValue(ConstUtil.INTERNAL_REVIEW_START_DATE_FLAG)) {
            PreferenceUtil.setPreferenceStringValue(
                ConstUtil.INTERNAL_REVIEW_START_DATE,
                dtf.format(LocalDateTime.now())
            )
            PreferenceUtil.setPreferenceBooleanValue(ConstUtil.INTERNAL_REVIEW_START_DATE_FLAG, true)
        } else {
//            if (!PreferenceUtil.getPreferenceBooleanValue(ConstUtil.INTERNAL_REVIEW_DIALOG_FLAG)) {
                // 開始タイミング
                val dateFrom = LocalDateTime.parse(
                    PreferenceUtil.getPreferenceStringValue(
                        ConstUtil.INTERNAL_REVIEW_START_DATE
                    ),
                    dtf
                )
                // システムタイミング
                val dateTo = LocalDateTime.parse(
                    dtf.format(LocalDateTime.now()), dtf
                )
                val daysBetween = ChronoUnit.DAYS.between(dateFrom, dateTo)

                // 10日以降
                if (daysBetween >= 10) {
                    launchAppReviewFlow()
                }
//            }
        }
        // 活性化フラグを「認証済、登録済」に設定する
        PreferenceUtil.setPreferenceStringValue(ConstUtil.ACTIVITY_FLAG, ConstUtil.ACTIVITY_FLAG_ACCESS_LOGIN)

        // トップ情報設定
        setAccountInfo()
        // お知らせ一覧取得
        if (!MainActivity.TOP_INFO_TIMER_FLAG) {
            getNotice()
        }
        // トップ情報更新タイマ
        refreshIfo()
    }

    /**
     * 内部プレビューダイアログ.
     */
    private fun launchAppReviewFlow() {
        val manager = ReviewManagerFactory.create(ACTIVITY!!)
        val request = manager.requestReviewFlow()
        val dtf = DateTimeFormatter.ofPattern("yyyy.MM.dd HH:mm", Locale.JAPAN)

        request.addOnCompleteListener { task ->
            if (task.isSuccessful) {
                val reviewInfo = task.result
                val flow = manager.launchReviewFlow(ACTIVITY!!, reviewInfo)
                flow.addOnCompleteListener {
//                    PreferenceUtil.setPreferenceBooleanValue(ConstUtil.INTERNAL_REVIEW_DIALOG_FLAG, true)
                    PreferenceUtil.setPreferenceStringValue(
                        ConstUtil.INTERNAL_REVIEW_START_DATE,
                        dtf.format(LocalDateTime.now())
                    )
                }
            }
        }
    }

    /**
     * トップ情報更新タイマ.
     */
    private fun refreshIfo() {
        Thread {
            val now = Calendar.getInstance()
            val tz: TimeZone = TimeZone.getTimeZone("Asia/Tokyo")
            TimeZone.setDefault(tz)
            now.timeZone = tz
            MainActivity.TOP_INFO_TIMER.cancel()
            MainActivity.TOP_INFO_TIMER = Timer()
            MainActivity.TOP_INFO_TIMER.schedule(
                object : TimerTask() {
                    override fun run() {
                        if (MainActivity.TOP_INFO_TIMER_FLAG) {
                            MainActivity.TOP_INFO_TIMER_FLAG = false
                            getAccountInfo(true)
                        }
                    }
                },
                now.time, TOP_INFO_REFRESH_INTERVAL
            )
        }.start()
    }

    /**
     * 科目コード切替え.
     *
     * @param account 口座情報
     * @param index インデックス
     * @param type スクロールタイプ（0：未　１：左　２：右）
     */
    fun slide(account: BalanceInformation, index: Int, type: Int) {
        //Log.i("Home", "slide to ${account.accountNumber} type =${account.accountType} index = $index type = $type")
        var allAccount: MutableList<BalanceInformation> = mutableListOf()


        // 総合口座（全部）
        val oldComprehensiveAccountList =
            viewStates.allAccount.filter { it.generalAccountFlag == GeneralAccountFlag.NOT_GENERAL.code }.toList()
        val comprehensiveAccountList = getTotalBalance(oldComprehensiveAccountList)
        // 総合口座（普通）
        val ordinaryComprehensiveAccountList =
            comprehensiveAccountList.filter { it.subjectNameCode == Subject.ORDINARY_DEPOSIT.code }.toList()
        // 総合口座（定期）
        val fixedComprehensiveAccountList =
            comprehensiveAccountList.filter { it.subjectNameCode == Subject.FIXED_SAVINGS.code }.toList()
        // 総合以外の口座
        val isGeneralAccountList =
            viewStates.allAccount.filter { it.generalAccountFlag == GeneralAccountFlag.IS_GENERAL.code }.toList()
        if (ordinaryComprehensiveAccountList.isNotEmpty() &&
            account.subjectNameCode == Subject.COMPREHENSIVE_ACCOUNT.code
        ) {
            val mainAccounts = ordinaryComprehensiveAccountList.groupBy {
                it.accountNumber
            }
            // 総合口座
            ordinaryComprehensiveAccountList.forEachIndexed { _, item ->
                //Log.i("acc","acc = ${item.accountNumber}")
                val linkedAccount = fixedComprehensiveAccountList.firstOrNull { it -> it.accountNumber == item.linkedAccountNumber }
                val comprehensiveAccount = BalanceInformation(
                    cifNumber = item.cifNumber,
                    branchNumber = item.branchNumber,
                    subjectNameCode = Subject.COMPREHENSIVE_ACCOUNT.code,
                    subjectNameValue = Subject.COMPREHENSIVE_ACCOUNT.value,
                    branchName = item.branchName,
                    accountNumber = item.accountNumber,
                    accountType = item.accountType,
                    balance = item.balance,
                    fundingBalance = item.fundingBalance,
                    dissolutionFlg = item.dissolutionFlg,
                    regularBalance = linkedAccount?.balance ?: "0",
                    topSelected = item.accountNumber == account.accountNumber || item.accountNumber == account.linkedAccountNumber,
                    linkedAccountType = item.linkedAccountType,
                    linkedBranchNumber = item.linkedBranchNumber,
                    linkedAccountNumber = item.linkedAccountNumber,
                    linkedSubNumber = item.linkedSubNumber,
                )
                //Log.i("Home","add account to all account${comprehensiveAccount.accountNumber}" )
                allAccount.add(comprehensiveAccount)
            }

            if (fixedComprehensiveAccountList.isNotEmpty()){
                fixedComprehensiveAccountList.forEach { it ->
                    val main = mainAccounts[it.linkedAccountNumber]?.get(0)
                    val comprehensiveAccount = BalanceInformation(
                        cifNumber = it.cifNumber,
                        branchNumber = it.branchNumber,
                        subjectNameCode = Subject.COMPREHENSIVE_ACCOUNT.code,
                        subjectNameValue = Subject.COMPREHENSIVE_ACCOUNT.value,
                        branchName = it.branchName,
                        accountNumber = it.accountNumber,
                        accountType = it.accountType,
                        balance = it.balance,
                        fundingBalance = main?.fundingBalance ?:"0",
                        dissolutionFlg = it.dissolutionFlg,
                        regularBalance = main?.balance ?:"0",
                        topSelected = it.accountNumber == account.accountNumber || it.accountNumber == account.linkedAccountNumber,
                        linkedAccountType = it.linkedAccountType,
                        linkedBranchNumber = it.linkedBranchNumber,
                        linkedAccountNumber = it.linkedAccountNumber,
                        linkedSubNumber = it.linkedSubNumber,
                    )
                    //Log.i("Home","add account to all account${comprehensiveAccount.accountNumber}" )
                    allAccount.add(comprehensiveAccount)
                }
            }

        } else {
            // 表示する科目コードを抽出条件として、すべての明細を取得する
            allAccount = isGeneralAccountList.filter {
                it.subjectNameCode == account.subjectNameCode
            }.map { it.copy() }.toMutableList()
            allAccount.first { it.accountNumber == account.accountNumber }.topSelected = true
        }

        //Log.i("allAccount", "all = ${allAccount.size}")

        val newAllAccount: MutableList<BalanceInformation> = mutableListOf()

        val newAllAccountMap = allAccount.map { it.copy() }.groupBy {
            it.branchNumber + HALF_HYPHEN + it.accountNumber
        }
        newAllAccountMap.keys.forEach { branch ->
            newAllAccount.add(newAllAccountMap[branch]!![0])
        }

        //Log.i("acc", "slide branchAccount = ${newAllAccount.size}")
        viewStates = viewStates.copy(
            branchAccount = newAllAccount.stream().sorted(
                Comparator.comparing(
                    BalanceInformation::branchNumber
                )
            ).collect(Collectors.toList())
        )
        if (viewStates.scrollableAccountShow.size > 1 && type != 0) {
            lateinit var scrollState: LazyListState
            var slideIndex = 0
            if (type == 2) {
                val currentIndex = viewStates.scrollableAccount.map {
                    it.subjectNameCode
                }.indexOf(account.subjectNameCode)
                val newIndex = if (currentIndex == viewStates.scrollableAccount.size) {
                    0
                } else {
                    currentIndex
                }
                scrollState =
                    LazyListState(
                        firstVisibleItemIndex = newIndex + 1,
                        firstVisibleItemScrollOffset = -SCREEN_WIDTH / 16
                    )
                slideIndex = newIndex + 1
            } else if (type == 1) {
                val currentIndex = viewStates.scrollableAccount.map {
                    it.subjectNameCode
                }.indexOf(account.subjectNameCode)
                scrollState =
                    LazyListState(
                        firstVisibleItemIndex = currentIndex + 1,
                        firstVisibleItemScrollOffset = -SCREEN_WIDTH / 16
                    )
                slideIndex = currentIndex + 1
            }
            viewStates = viewStates.copy(indexState = scrollState, slideIndex = slideIndex)
        } else if (type == 0) {
            viewStates = viewStates.copy(
                indexState =
                LazyListState(
                    firstVisibleItemIndex = index,
                    firstVisibleItemScrollOffset = -SCREEN_WIDTH / 16
                )
            )
        }

        viewStates = when (account.subjectNameCode) {
            Subject.COMPREHENSIVE_ACCOUNT.code -> viewStates.copy(type = 1, index = index)
            Subject.ORDINARY_DEPOSIT.code -> viewStates.copy(type = 2, index = index)
            Subject.FIXED_SAVINGS.code -> viewStates.copy(type = 3, index = index)
            Subject.INSTALLMENT.code -> viewStates.copy(type = 4, index = index)
            Subject.CHECKING_ACCOUNT.code -> viewStates.copy(type = 5, index = index)
            Subject.DEPOSIT_DEPOSIT.code -> viewStates.copy(type = 6, index = index)
            else -> viewStates.copy(type = 7, index = index)
        }

        // 預金一覧から口座番号取得
        val accountNumber = PreferenceUtil.getPreferenceStringValue(ConstUtil.MBDP0101_ACCOUNT_NUMBER).toString()
        PreferenceUtil.removePreferenceStringValue(ConstUtil.MBDP0101_ACCOUNT_NUMBER)
        if (accountNumber.isNotEmpty()) {
            val scrollIndex = viewStates.branchAccount.indexOfFirst { it.accountNumber == accountNumber }
            if (scrollIndex != -1) {
                viewStates.scrollState = scrollIndex
                switchBranch(viewStates.index, scrollIndex, viewStates.branchAccount[scrollIndex])
            }
        }
    }

    /**
     * 口座切替え.
     */
    fun switchBranch(index: Int, branchIndex: Int, data: BalanceInformation) {
        //Log.i("acc","switchBranch index:${index} branchIndex:${branchIndex} data:${data.toJson()}")
        //Log.i("acc","switchBranch tabType:${viewStates.tabType} type:${viewStates.type}}")
        var filteredBranchAccount = viewStates.branchAccount
        if (viewStates.type == 1) {
            filteredBranchAccount = if (viewStates.tabType == 1) {
                viewStates.branchAccount.filter {
                    it.accountType == AccountType.FIXED_SAVINGS.code
                }.map { it.copy() }.toMutableList()
            } else {
                viewStates.branchAccount.filter {
                    it.accountType == AccountType.ORDINARY_DEPOSIT.code
                }.map { it.copy() }.toMutableList()
            }
        }
        val branchAccount: BalanceInformation = filteredBranchAccount[branchIndex].copy()
        val newScrollableAccount = viewStates.scrollableAccountShow.map { it.copy() }.toMutableList()
        val thisAccountList =
            newScrollableAccount.filter { it.subjectNameCode == newScrollableAccount[index].subjectNameCode }
        if (thisAccountList.size > 1) {
            val lastIndex =
                newScrollableAccount.map { it.subjectNameCode }.lastIndexOf(newScrollableAccount[index].subjectNameCode)
            newScrollableAccount.removeAt(lastIndex)
            newScrollableAccount.add(lastIndex, branchAccount)
            val firstIndex =
                newScrollableAccount.map { it.subjectNameCode }.indexOf(newScrollableAccount[index].subjectNameCode)
            newScrollableAccount.removeAt(firstIndex)
            newScrollableAccount.add(firstIndex, branchAccount)
        } else {
            newScrollableAccount.removeAt(index)
            newScrollableAccount.add(index, branchAccount)
        }

        val newBranchAccount = viewStates.branchAccount.map {
            BalanceInformation().apply {
                this.cifNumber = it.cifNumber
                this.branchNumber = it.branchNumber
                this.branchName = it.branchName
                this.subjectNameCode = it.subjectNameCode
                this.subjectNameValue = it.subjectNameValue
                this.accountNumber = it.accountNumber
                this.accountType = it.accountType
                this.balance = it.balance
                this.balanceTotal = it.balanceTotal
                this.fundingBalance = it.fundingBalance
                this.regularBalance = it.regularBalance
                this.generalAccountFlag = it.generalAccountFlag
                this.linkedAccountType = it.linkedAccountType
                this.linkedBranchNumber = it.linkedBranchNumber
                this.linkedAccountNumber = it.linkedAccountNumber
                this.linkedSubNumber = it.linkedSubNumber
                this.dissolutionFlg = it.dissolutionFlg
                this.selected = it.selected
                this.topSelected = false
            }
        }.toMutableList()
        newBranchAccount.filter { it.accountNumber == data.accountNumber }[0].topSelected = true

        // スクロールステータス
        val currentIndex = viewStates.scrollableAccount.map {
            it.subjectNameCode
        }.indexOf(viewStates.scrollableAccountShow[index].subjectNameCode)
        val newIndex = if (currentIndex == viewStates.scrollableAccount.size) {
            0
        } else {
            currentIndex
        }
        val scrollState =
            LazyListState(
                firstVisibleItemIndex = newIndex + 1,
                firstVisibleItemScrollOffset = -SCREEN_WIDTH / 16
            )
        //Log.i("acc", "switch branchAccount = ${newBranchAccount.size}")
        viewStates = viewStates.copy(
            scrollableAccountShow = newScrollableAccount,
            branchAccount = newBranchAccount.stream().sorted(
                Comparator.comparing(
                    BalanceInformation::branchNumber
                )
            ).collect(Collectors.toList()),
            indexState = scrollState
        )
    }

    fun viewChange(flag: Boolean) {
        viewStates = viewStates.copy(showFlag = !flag)
    }

    fun tabSwitching(tab: Int) {
        //Log.i("acc", "tabSwitching $tab")
        //総合
        if (viewStates.type == 1){
            //表示中アカウント
            var showedAccount = viewStates.branchAccount.filter {
                it.accountType == if(viewStates.tabType == 1) AccountType.FIXED_SAVINGS.code else AccountType.ORDINARY_DEPOSIT.code
            }.map { it.copy() }.toMutableList().firstOrNull{ it.topSelected }

            viewStates = viewStates.copy(tabType = tab)
            var filteredBranchAccount = viewStates.branchAccount.filter {
                it.accountType == if(viewStates.tabType == 1) AccountType.FIXED_SAVINGS.code else AccountType.ORDINARY_DEPOSIT.code
            }.map { it.copy() }.toMutableList()

            var selectedAccount = filteredBranchAccount.firstOrNull() { it ->
                it.accountNumber == showedAccount?.linkedAccountNumber }
            if (selectedAccount == null){
                selectedAccount = filteredBranchAccount.firstOrNull()
                selectedAccount?.topSelected = true
            }
            val branchIndex =  filteredBranchAccount.indexOf(selectedAccount)

            switchBranch(viewStates.index , branchIndex, selectedAccount!!)
        } else {
            viewStates = viewStates.copy(tabType = tab)
        }
    }

    fun tutorialClick() {
        viewStates = viewStates.copy(tutorialFlag = false, tutorial2Flag = true)
    }

    fun tutorial2Click() {
        PreferenceUtil.setPreferenceBooleanValue(ConstUtil.PASSBOOK_HELP_FLAG, true)
        viewStates = viewStates.copy(tutorial2Flag = false)
    }

    /**
     * トップ情報取得.
     */
    fun getAccountInfo(loadingFlag: Boolean = true) {
        // トップ情報取得
        viewModelScope.launch {
            LoadingUtil.setLoadingValue(value = loadingFlag, type = true)
            //Log.i("acc","launch")
            when (accountInfoLogic.getAccountInfo()) {
                true -> {
                }
                else -> {
                    //Log.i("acc","getAccountInfo")

                    setAccountInfo()
                    getNotice()
                }
            }
            LoadingUtil.setLoadingValue(value = false)
        }
    }

    /**
     * トップ情報設定.
     */
    private fun setAccountInfo() {
        //Log.i("acc", "setAccountInfo")
        viewStates.allAccount = mutableListOf()
        viewStates.scrollableAccountShow = mutableListOf()
        viewStates.branchAccount = mutableListOf()
        viewStates.regularDepositList = mutableListOf()
        viewStates.notificationDeposit = mutableListOf()
        // 普通預金情報
        val realmAccountInfo = dbService.findAll(EPassBookAB0401::class.java)
        if (realmAccountInfo.isNotEmpty()) {
            realmAccountInfo[0]?.balanceInformationList?.fromJson<List<Map<String, String>>>()?.forEach {
                viewStates.allAccount.add(
                    BalanceInformation(
                        cifNumber = it["cifNo"] ?: "",
                        branchNumber = it["branchNumber"] ?: "",
                        branchName = it["branchName"] ?: "",
                        subjectNameCode = it["subjectNameCode"] ?: "",
                        subjectNameValue = it["subjectNameValue"] ?: "",
                        accountNumber = it["accountNumber"] ?: "",
                        accountType = it["accountType"] ?: "",
                        balance = it["balance"] ?: "",
                        balanceTotal = it["balanceTotal"] ?: "",
                        fundingBalance = it["fundingBalance"] ?: "",
                        generalAccountFlag = it["generalAccountFlag"] ?: "",
                        linkedAccountType = it["linkedAccountType"] ?: "",
                        linkedBranchNumber = it["linkedBranchNumber"] ?: "",
                        linkedAccountNumber = it["linkedAccountNumber"] ?: "",
                        linkedSubNumber = it["linkedSubNumber"] ?: "",
                        dissolutionFlg = if (it["dissolutionFlg"].isNullOrEmpty())
                            DissolutionFlag.VALIDATE.code else it["dissolutionFlg"].toString(),
                    )
                )
            }
            viewStates.allAccount = viewStates.allAccount.stream().sorted(
                Comparator.comparing(
                    BalanceInformation::branchNumber
                )
            ).collect(Collectors.toList())
            // スクロール可能な口座並ぶ
            val newScrollableAccount: MutableList<BalanceInformation> = mutableListOf()
            // 総合口座（全部）
            val oldComprehensiveAccountList =
                viewStates.allAccount.filter { it.generalAccountFlag == GeneralAccountFlag.NOT_GENERAL.code }.toList()
            val comprehensiveAccountList = getTotalBalance(oldComprehensiveAccountList)

            //Log.i("acc","setAccountInfo 総合口座old:${oldComprehensiveAccountList.size}")
            //Log.i("acc","setAccountInfo 総合口座com:${comprehensiveAccountList.size}")
            comprehensiveAccountList.forEach {
                //Log.i("acc","com:acc=${it.accountNumber} type=${it.accountType} linkType=${it.linkedAccountType}")
            }
            // 総合口座（普通）
            val ordinaryComprehensiveAccountList =
                comprehensiveAccountList.filter { it.subjectNameCode == Subject.ORDINARY_DEPOSIT.code ||
                    (it.accountType == AccountType.FIXED_SAVINGS.code &&
                          it.linkedAccountType == AccountType.ORDINARY_DEPOSIT.code)
                }.toList()

            //Log.i("Account-Home","ordinaryComprehensiveAccountList ${ordinaryComprehensiveAccountList.size}")
            // 普通預金の総合口座がある場合
            if (ordinaryComprehensiveAccountList.isNotEmpty()) {
                val comprehensiveAccount = BalanceInformation(
                    cifNumber = ordinaryComprehensiveAccountList[0].cifNumber,
                    branchNumber = ordinaryComprehensiveAccountList[0].branchNumber,
                    subjectNameCode = Subject.COMPREHENSIVE_ACCOUNT.code,
                    subjectNameValue = Subject.COMPREHENSIVE_ACCOUNT.value,
                    branchName = ordinaryComprehensiveAccountList[0].branchName,
                    accountNumber = ordinaryComprehensiveAccountList[0].accountNumber,
                    accountType = ordinaryComprehensiveAccountList[0].accountType,
                    generalAccountFlag = ordinaryComprehensiveAccountList[0].generalAccountFlag,
                    linkedAccountType = ordinaryComprehensiveAccountList[0].linkedAccountType,
                    linkedBranchNumber = ordinaryComprehensiveAccountList[0].linkedBranchNumber,
                    linkedAccountNumber = ordinaryComprehensiveAccountList[0].linkedAccountNumber,
                    linkedSubNumber = ordinaryComprehensiveAccountList[0].linkedSubNumber,
                    dissolutionFlg = ordinaryComprehensiveAccountList[0].dissolutionFlg,
                    balance = ordinaryComprehensiveAccountList[0].balance,
                    fundingBalance = ordinaryComprehensiveAccountList[0].fundingBalance,
                    regularBalance = "0"
                )

                if (comprehensiveAccount.linkedAccountType == AccountType.FIXED_SAVINGS.code){
                    comprehensiveAccount.regularBalance = comprehensiveAccountList.firstOrNull { it.accountNumber == comprehensiveAccount.linkedAccountNumber }?.balance ?: "0"
                }

                newScrollableAccount.add(0, comprehensiveAccount)
            }
            // 総合以外の口座
            val isGeneralAccountList =
                getTotalBalance(
                    viewStates.allAccount.filter { it.generalAccountFlag == GeneralAccountFlag.IS_GENERAL.code }
                        .toList()
                )
            val accountGroup = isGeneralAccountList.groupBy { it.subjectNameCode }
            accountGroup.keys.forEach {
                // スクロール可能な口座
                viewStates.scrollableAccountShow.add(accountGroup[it]!![0])
                //Log.i("Account-Home","スクロール可能な口座 ${accountGroup[it]!![0].accountNumber}")
            }

            //Log.i("Account-Home","スクロール可能な口座 ${viewStates.scrollableAccountShow.size}")

            // 普通預金
            val ordinaryDepositList =
                viewStates.scrollableAccountShow.filter { it.subjectNameCode == Subject.ORDINARY_DEPOSIT.code }.toList()
            if (ordinaryDepositList.isNotEmpty()) newScrollableAccount.add(ordinaryDepositList[0])
            // 定期預金
            val fixedSavingsList =
                viewStates.scrollableAccountShow.filter { it.subjectNameCode == Subject.FIXED_SAVINGS.code }.toList()
            if (fixedSavingsList.isNotEmpty()) newScrollableAccount.add(fixedSavingsList[0])


            //Log.i("acc"," allAccount = ${viewStates.allAccount.size}")
            viewStates.allAccount.forEach{ acc ->

                //Log.i("acc"," acc = ${acc.toString()}")
            }
            val listTerm =viewStates.allAccount.filter { it.generalAccountFlag == GeneralAccountFlag.IS_GENERAL.code &&
                it.subjectNameCode == Subject.FIXED_SAVINGS.code }.toList()
            //Log.i("acc"," fixedSavingsList = ${listTerm.size}")

            if (listTerm.isNotEmpty()){
                viewStates = viewStates.copy(
                    termCertificateStates = listTerm.map{ term ->
                        //Log.i("acc","load ${term.accountNumber}")
                        TermCertificateState(
                            account = term.accountNumber,
                            isLoading = false,
                            complete = false,
                            error = null
                        )
                    }
                )
            }

            val listNotice =viewStates.allAccount.filter { it.generalAccountFlag == GeneralAccountFlag.IS_GENERAL.code &&
                it.subjectNameCode == Subject.DEPOSIT_DEPOSIT.code }.toList()
            //Log.i("acc"," listNotice = ${listNotice.size}")

            if (listNotice.isNotEmpty()){
                viewStates = viewStates.copy(
                    noticeCertificateStates = listNotice.map{ term ->
                        //Log.i("acc","load ${term.accountNumber}")
                        NoticeCertificateState(
                            account = term.accountNumber,
                            isLoading = false,
                            complete = false,
                            error = null
                        )
                    }
                )
            }

            // 定期積金
            val installmentList =
                viewStates.scrollableAccountShow.filter { it.subjectNameCode == Subject.INSTALLMENT.code }.toList()
            if (installmentList.isNotEmpty()) newScrollableAccount.add(installmentList[0])
            // 当座預金
            val checkingAccountList =
                viewStates.scrollableAccountShow.filter { it.subjectNameCode == Subject.CHECKING_ACCOUNT.code }.toList()
            if (checkingAccountList.isNotEmpty()) newScrollableAccount.add(checkingAccountList[0])
            // 通知預金
            val depositDepositList =
                viewStates.scrollableAccountShow.filter { it.subjectNameCode == Subject.DEPOSIT_DEPOSIT.code }.toList()
            if (depositDepositList.isNotEmpty()) newScrollableAccount.add(depositDepositList[0])
            // 納税準備預金
            val taxDepositList =
                viewStates.scrollableAccountShow.filter { it.subjectNameCode == Subject.TAX_DEPOSIT.code }.toList()
            if (taxDepositList.isNotEmpty()) newScrollableAccount.add(taxDepositList[0])
            viewStates = viewStates.copy(scrollableAccount = newScrollableAccount.map { it.copy() }.toMutableList())
            // スクロールステータス
            var scrollState = LazyListState()
            var initIndex = 0
            if (newScrollableAccount.size > 1) {
                newScrollableAccount.add(0, viewStates.scrollableAccount.last())
                newScrollableAccount.add(viewStates.scrollableAccount.first())
                scrollState =
                    LazyListState(firstVisibleItemIndex = 1, firstVisibleItemScrollOffset = -SCREEN_WIDTH / 16)
                initIndex = 1
            }
            viewStates = viewStates.copy(scrollableAccountShow = newScrollableAccount, indexState = scrollState)

            // 表示する科目取得
            val curSubject = newScrollableAccount[initIndex].subjectNameCode
            viewStates = when (viewStates.scrollableAccount[0].subjectNameCode) {
                Subject.COMPREHENSIVE_ACCOUNT.code -> viewStates.copy(
                    type = 1,
                    index = initIndex,
                    slideIndex = initIndex
                )
                Subject.ORDINARY_DEPOSIT.code -> viewStates.copy(type = 2, index = initIndex, slideIndex = initIndex)
                Subject.FIXED_SAVINGS.code -> viewStates.copy(type = 3, index = initIndex, slideIndex = initIndex)
                Subject.INSTALLMENT.code -> viewStates.copy(type = 4, index = initIndex, slideIndex = initIndex)
                Subject.CHECKING_ACCOUNT.code -> viewStates.copy(type = 5, index = initIndex, slideIndex = initIndex)
                Subject.DEPOSIT_DEPOSIT.code -> viewStates.copy(type = 6, index = initIndex, slideIndex = initIndex)
                else -> viewStates.copy(type = 7, index = initIndex, slideIndex = initIndex)
            }

            var curBranchAllAccount: MutableList<BalanceInformation> = mutableListOf()
            if (ordinaryComprehensiveAccountList.isNotEmpty() && curSubject == Subject.COMPREHENSIVE_ACCOUNT.code) {
//                var newFixedBranchList = mutableListOf<BalanceInformation>()
                //Log.i("Account-Home", "ordinaryComprehensiveAccountList =${ordinaryComprehensiveAccountList.size}")

                // 総合口座
                val mainAccounts = ordinaryComprehensiveAccountList.filter { it ->
                    it.linkedAccountType != AccountType.ORDINARY_DEPOSIT.code
                }.groupBy { it-> it.accountNumber }
                //Log.i("Account-Home", "mainAccounts =${mainAccounts.size}")
                ordinaryComprehensiveAccountList.forEachIndexed { index, item ->
                    val comprehensiveAccount = BalanceInformation(
                        cifNumber = item.cifNumber,
                        branchNumber = item.branchNumber,
                        subjectNameCode = Subject.COMPREHENSIVE_ACCOUNT.code,
                        subjectNameValue = Subject.COMPREHENSIVE_ACCOUNT.value,
                        branchName = item.branchName,
                        accountNumber = item.accountNumber,
                        accountType = item.accountType,
                        balance = item.balance,
                        fundingBalance = item.fundingBalance,
                        dissolutionFlg = item.dissolutionFlg,
                        regularBalance = "0",
                        topSelected = index == 0,
                        linkedAccountType = item.linkedAccountType,
                        linkedBranchNumber = item.linkedBranchNumber,
                        linkedAccountNumber = item.linkedAccountNumber,
                        linkedSubNumber = item.linkedSubNumber,
                    )
                    //Log.i("acc", "linkedAccountType ${comprehensiveAccount.linkedAccountType}")
                    if(comprehensiveAccount.linkedAccountType != AccountType.ORDINARY_DEPOSIT.code){
                        if (comprehensiveAccount.linkedAccountNumber.isNotBlank()){
                            val linkedAccount = ordinaryComprehensiveAccountList.firstOrNull { link -> link.accountNumber == comprehensiveAccount.linkedAccountNumber }
                            comprehensiveAccount.regularBalance = linkedAccount?.balance ?:"0"
                        }
                    } else {
                        //Log.i("acc", "else ${mainAccounts[comprehensiveAccount.linkedAccountNumber]?.get(0)}")
                        comprehensiveAccount.fundingBalance = mainAccounts[comprehensiveAccount.linkedAccountNumber]?.get(0)?.fundingBalance?:"0"
                        comprehensiveAccount.regularBalance = mainAccounts[comprehensiveAccount.linkedAccountNumber]?.get(0)?.balance?:"0"
                    }
                    //Log.i("acc", "curBranchAllAccount.add ${comprehensiveAccount.toJson()}")
                    curBranchAllAccount.add(comprehensiveAccount)
                }
            } else {
                // 表示する科目コードを抽出条件として、すべての明細を取得する
                curBranchAllAccount =
                    isGeneralAccountList.filter { it.subjectNameCode == curSubject }.map { it.copy() }.toMutableList()
                curBranchAllAccount[0].topSelected = true
            }
            val newAllAccountMap = curBranchAllAccount.map { it.copy() }.groupBy {
                it.branchNumber + HALF_HYPHEN + it.accountNumber
            }
            newAllAccountMap.keys.forEach { branch ->
                //Log.i("acc", "group account = $branch ${newAllAccountMap[branch]!![0].toJson()}")
                viewStates.branchAccount.add(newAllAccountMap[branch]!![0])
            }
//            //Log.i("acc", "setaccountinfo branchAccount = ${viewStates.branchAccount.size}")
            viewStates.branchAccount = viewStates.branchAccount.stream().sorted(
                Comparator.comparing(
                    BalanceInformation::branchNumber
                )
            ).collect(Collectors.toList())

            //Log.i("acc", "setaccountinfo viewStates.branchAccount =${viewStates.branchAccount.size}")

        }
        // 定期預金情報
        val realmRegularDepositInfo = dbService.findAll(EPassBookAB0403::class.java)
        if (realmRegularDepositInfo.isNotEmpty()) {
            realmRegularDepositInfo[0]?.termDepositDetails?.fromJson<List<Map<String, String>>>()?.forEach {
                val lotteryResultsDetailsDto: MutableList<LotteryResultsDetailsDto> = mutableListOf()
                val latestReceipDetailsDto: MutableList<LatestReceipDetailsDto> = mutableListOf()
                // 抽選結果明細
                val termDepositDetails = Gson().fromJson(Gson().toJson(it), TermDepositDetails::class.java)
                lotteryResultsDetailsDto.addAll(termDepositDetails.lotteryResults)
                // 最新受領情報
                latestReceipDetailsDto.addAll(termDepositDetails.latestReceiptInfo)
                viewStates.regularDepositList.add(
                    TermDepositDetails(
                        detailId = it["detailId"] ?: "",
                        subNo = it["subNo"] ?: "",
                        typeCode = it["typeCode"] ?: "",
                        balanceOfLedger = it["balanceOfLedger"] ?: "",
                        interestRate = it["interestRate"] ?: "",
                        taxClassName = it["taxClassName"] ?: "",
                        maturityDate = it["maturityDate"] ?: "",
                        periodCodeValue = it["periodCodeValue"] ?: "",
                        interestReceivingMethod = it["interestReceivingMethod"] ?: "",
                        rewardAmountTypeValue = it["rewardAmountTypeValue"] ?: "",
                        interestReceiveAccountType = it["interestReceiveAccountType"] ?: "",
                        irAccountNumber = it["irAccountNumber"] ?: "",
                        contractDate = it["contractDate"] ?: "",
                        transactionClassification = it["transactionClassification"] ?: "",
                        memo = it["memo"] ?: "",
                        lotteryTimes = it["lotteryTimes"] ?: "",
                        handlingGroup = it["handlingGroup"] ?: "",
                        lotteryNoStart = it["lotteryNoStart"] ?: "",
                        lotteryNoEnd = it["lotteryNoEnd"] ?: "",
                        lotteryDate = it["lotteryDate"] ?: "",
                        branchNumber = it["branchNumber"] ?: "",
                        accountNumber = it["accountNumber"] ?: "",
                        startAmount = it["startAmount"] ?: "",
                        superRegularType = it["superRegularType"] ?: "",
                        lotteryResults = lotteryResultsDetailsDto,
                        latestReceiptInfo = latestReceipDetailsDto,
                        generalAccountFlag = it["generalAccountFlag"] ?: ""
                    )
                )
            }
        }

        // 通知預金情報
        val realmNoticeDepositInfo = dbService.findAll(EPassBookAB0405::class.java)
        if (realmNoticeDepositInfo.isNotEmpty()) {
            realmNoticeDepositInfo[0]?.noticeDepositList?.fromJson<MBDP1101ResponseBean>()?.noticeDepositList?.forEach {
                viewStates.notificationDeposit.add(it)
            }
        }
        setNotice()
        val dtf = DateTimeFormatter.ofPattern("yyyy.MM.dd HH:mm", Locale.JAPAN)
        val lastLoginTime = PreferenceUtil.getPreferenceStringValue(LAST_LOGIN_TIME)
        viewStates = viewStates.copy(
            updateTime = dtf.format(LocalDateTime.now()),
            lastLoginTime = lastLoginTime.toString()
        )
    }

    /**
     * 明細表示へ.
     */
    fun goToDetail(data: BalanceInformation) {
        //Log.i("acc","goToDetail　${data.toJson()}")
        PreferenceUtil.setPreferenceBooleanValue(ConstUtil.DETAIL_CLOSE_FLAG, false)
        PreferenceUtil.setPreferenceStringValue(ConstUtil.TOP_TO_DETAIL_CARD_INDEX, viewStates.slideIndex.toString())
//        PreferenceUtil.setPreferenceStringValue(ConstUtil.DETAIL_TRANSITION, RouteName.HOME)
        // 普通預金の場合
        if (Subject.ORDINARY_DEPOSIT.code == data.subjectNameCode) {
            // 初回はリスト表示
            if (!PreferenceUtil.getPreferenceBooleanValue(ORDINARY_DEPOSIT_READ_FLAG)) {
                //Log.i("acc","navTo　MBDP0201Page")
                RouteUtil.navTo(
                    RouteName.MBDP0201Page,
                    args = data,
                )
            } else {
                //Log.i("acc","navTo　MBDP0501Page")
                RouteUtil.navTo(
                    RouteName.MBLG0501Page,
                    args = data,
                )
            }
        } else if (Subject.INSTALLMENT.code == data.subjectNameCode) {
            // 定期積金の場合
            RouteUtil.navTo(
                RouteName.MBDP0901Page,
                args = data,
            )
        } else if (Subject.CHECKING_ACCOUNT.code == data.subjectNameCode) {
            // 当座預金の場合
            // 初回はリスト表示
            if (!PreferenceUtil.getPreferenceBooleanValue(CHECKING_ACCOUNT_READ_FLAG)) {
                RouteUtil.navTo(
                    RouteName.MBDP0401Page,
                    args = data,
                )
            } else {
                RouteUtil.navTo(
                    RouteName.MBLG0505Page,
                    args = data,
                )
            }
        } else if (Subject.TAX_DEPOSIT.code == data.subjectNameCode) {
            // 納税準備預金の場合
            // 初回はリスト表示
            if (!PreferenceUtil.getPreferenceBooleanValue(TAX_DEPOSIT_READ_FLAG)) {
                RouteUtil.navTo(
                    RouteName.MBDP0501Page,
                    args = data,
                )
            } else {
                RouteUtil.navTo(
                    RouteName.MBLG0507Page,
                    args = data,
                )
            }
        } else if (Subject.COMPREHENSIVE_ACCOUNT.code == data.subjectNameCode) {
            // 総合口座の場合
            // 初回はリスト表示
            val bean = MBST1201Bean().apply {
                this.branchNumber = data.branchNumber
                this.subjectNameCode = data.subjectNameCode
                this.subjectNameValue = data.subjectNameValue
                this.branchName = data.branchName
                this.accountNumber = data.accountNumber
                this.accountType = data.accountType
                this.balance = data.balance
                this.regularBalance = data.regularBalance
                this.fundingBalance = data.fundingBalance
                this.linkedAccountType = data.linkedAccountType
                this.linkedBranchNumber = data.linkedBranchNumber
                this.linkedAccountNumber = data.linkedAccountNumber
                this.linkedSubNumber = data.linkedSubNumber
                this.accountFlag = viewStates.tabType.toString()
                this.dissolutionFlg = data.dissolutionFlg
                this.cifNo = data.cifNumber
            }
            if (!PreferenceUtil.getPreferenceBooleanValue(COMPREHENSIVE_ACCOUNT_READ_FLAG)) {
                PreferenceUtil.setPreferenceStringValue(ConstUtil.DETAIL_TAB_TYPE, viewStates.tabType.toString())
                //Log.i("acc", "MBDP0301Page")
                RouteUtil.navTo(
                    RouteName.MBDP0301Page,
                    args = bean,
                )
            } else {
                //Log.i("acc", "MBLG0502Page")
                RouteUtil.navTo(
                    RouteName.MBLG0502Page,
                    args = bean
                )
            }
        }
    }

    /**
     * お知らせ詳細へ
     */
    fun goDetail(index: Int) {
        // 既読フラグ設定
        val detail = viewStates.announcementsList[index]
        // 画面遷移
        when (detail.anncmntType) {
            AnncmntType.MESSAGE.code -> {
                val confirmFlg = detail.confirmFlg.ifBlank { "0" }
                // お知らせ種別ID＝"01：メッセージ"の場合、MBNT0201お知らせ画面へ遷移画面する
                RouteUtil.navTo(
                    RouteName.MBNT0201Page +
                        "/${detail.anncmntId}" +
                        "/${detail.anncmntType}" +
                        "/${detail.documentType}" +
                        "/${detail.applyId}" +
                        "/${detail.readFlag}" +
                        "/$confirmFlg"
                )
            }
            AnncmntType.EASY_RECEPTION.code -> {
                // お知らせ種別ID＝"02：かんたん受付"の場合、
                when (detail.documentType) {
                    BookDocumentType.EASY_RECEPTION_INFORMATION.code -> {
                        // 文書種別＝"B2001：かんたん受付案内"の場合、MBRC0201へ遷移する
                        RouteUtil.navTo(
                            RouteName.MBRC0201Page +
                                "/${
                                MBRC0201Parameter(
                                    anncmntId = detail.anncmntId,
                                    announcementsType = AnnouncementsType.TYPE_AFTER.code,
                                    applyId = detail.applyId,
                                    anncmntType = detail.anncmntType,
                                    documentType = detail.documentType
                                ).toJson()
                                }"
                        )
                    }
                    BookDocumentType.EASY_RECEPTION_APPLICATION.code -> {
                        // 文書種別＝"B2002：かんたん受付申込"の場合、MBRC0301へ遷移する
                        RouteUtil.navTo(
                            RouteName.MBRC0301Page +
                                "/${detail.anncmntId}/${detail.documentType}/${detail.applyId}/${detail.anncmntType}"
                        )
                    }
                }
            }
            else -> {
                // お知らせ種別ID＝"03：電子交付"の場合、文書種別コードにより、遷移画面が変わります
                RouteUtil.navTo(
                    getTransitionInfo(detail.documentType) + "/${
                    ElectronicIssueParameter(
                        title = detail.anncmntTitle,
                        reportId = detail.anncmntId,
                        documentTypeCode = detail.documentType,
                        applyId = detail.applyId,
                        anncmntType = detail.anncmntType
                    ).toJson()
                    }"
                )
            }
        }
    }

    /**
     * 口座金額合計
     */
    private fun getTotalBalance(accountList: List<BalanceInformation>): List<BalanceInformation> {
        val newAccountList = mutableListOf<BalanceInformation>()
        val comprehensiveMap = accountList.groupBy {
            it.subjectNameCode + HALF_HYPHEN + it.branchNumber + HALF_HYPHEN + it.accountNumber
        }
        comprehensiveMap.keys.forEach { key ->
            var balance = 0L
            val item = comprehensiveMap[key]!![0]
            comprehensiveMap[key]?.forEach {

                if (it.balance.isNotBlank()) {
                    balance += it.balance.toLong()
                }
            }
            item.balance = balance.toString()
            newAccountList.add(item)
        }
        return newAccountList.toList()
    }

    private fun setNotice() {
        // お知らせ一覧
        val realmAnnouncementInfo = dbService.findAll(EPassBookAB1001::class.java)
        viewStates.noticeList = mutableListOf()
        if (realmAnnouncementInfo.isNotEmpty()) {
            realmAnnouncementInfo[0]?.anncmntList?.fromJson<List<Map<String, String>>>()?.forEach {
                val cifNoList: MutableList<CifNoBean> = mutableListOf()
                Gson().fromJson<List<CifNoBean>>(
                    it["cifNoList"].toString(),
                    object : TypeToken<List<CifNoBean>>() {}.type
                )?.forEach { cif ->
                    cifNoList.add(CifNoBean(cifNo = cif.cifNo))
                }
                viewStates.noticeList.add(
                    Anncmnt(
                        // お知らせ種別コード
                        anncmntType = it["anncmntType"] ?: "",
                        // 文書種別コード
                        documentType = it["documentType"] ?: "",
                        // お知らせID
                        anncmntId = it["anncmntId"] ?: "",
                        // 申込ID
                        applyId = it["applyId"] ?: "",
                        // 顧客ID
                        customerId = it["customerId"] ?: "",
                        // CIF番号リスト
                        cifNoList = cifNoList,
                        // 受付案内種類
                        receptionGuideType = it["receptionGuideType"] ?: "",
                        // 掲載開始日時
                        anncmntStartDateAndTime = it["anncmntStartDateAndTime"] ?: "",
                        // 掲載終了日時
                        anncmntEndDateAndTime = it["anncmntEndDateAndTime"] ?: "",
                        // 作成日時
                        createTs = it["createTs"] ?: "",
                        // 公開日時
                        anncmntDateAndTime = it["anncmntDateAndTime"] ?: "",
                        // お知らせタイトル
                        anncmntTitle = it["anncmntTitle"] ?: "",
                        // 店番
                        branchCode = it["branchCode"] ?: "",
                        // 口座番号
                        accountNumber = it["accountNumber"] ?: "",
                        // 預金種目
                        accountType = it["accountType"] ?: "",
                        // お気に入りフラグ
                        bookmarkFlg = it["bookmarkFlg"] ?: "",
                        // 既読フラグ
                        readFlag = it["readFlag"] ?: "",
                        // 個別確認結果フラグ
                        confirmFlg = it["confirmFlg"] ?: "",
                        // 帳票最終ダウンロード日時
                        reportLastDlTs = it["reportLastDlTs"] ?: "",
                        // カナ氏名
                        customerName = it["customerName"] ?: "",
                        // 漢字氏名
                        customerKanjiName = it["customerKanjiName"] ?: "",
                        // 生（設立）年月日
                        birthday = it["birthday"] ?: "",
                        // 人格区分
                        personCode = it["personCode"] ?: "",
                        // メッセージ内容種別
                        mobileMsgType = it["mobileMsgType"] ?: "",
                    )
                )
            }

            var list: MutableList<Anncmnt> = mutableListOf()
            // お知らせ一覧
            if (viewStates.noticeList.isNotEmpty()) {
                list = viewStates.noticeList.filter { data ->
                    data.anncmntTitle.contains("特典付き児童手当受給口座キッズドリーム") && data.documentType ==
                        BookDocumentType.EASY_RECEPTION_INFORMATION.code
                }.stream()
                    .sorted(
                        Comparator.comparing(
                            Anncmnt::anncmntDateAndTime, Comparator.reverseOrder()
                        )
                    ).collect(Collectors.toList())
            }
            viewStates = viewStates.copy(
                childAllowanceCampaignList = list
            )
        }
        // 未読↑ > 重要↓ > 公開日時↓ でソート
        val firstAnncmntList = viewStates.noticeList.stream().sorted(
            Comparator.comparing(Anncmnt::readFlag)
                .thenComparing(Anncmnt::mobileMsgType, Comparator.reverseOrder())
                .thenComparing(Anncmnt::anncmntDateAndTime, Comparator.reverseOrder())
        ).collect(Collectors.toList())
        var announcementsList: MutableList<Anncmnt> = mutableListOf()
        // お知らせリスト空白以外場合
        if (firstAnncmntList.isNotEmpty() && firstAnncmntList.size > 0) {
            if (firstAnncmntList.size == 1) {
                announcementsList = firstAnncmntList.subList(0, 1)
            } else if (firstAnncmntList.size >= 2) {
                announcementsList = firstAnncmntList.subList(0, 2)
            }
        }
        var dataCount = 0
        if (realmAnnouncementInfo.isNotEmpty()) {
            dataCount = if (realmAnnouncementInfo[0]?.dataCount.isNullOrBlank())
                0 else realmAnnouncementInfo[0]?.dataCount!!.toInt()
        }
        viewStates = viewStates.copy(
            dataCount = dataCount,
            announcementsList = announcementsList
        )
    }

    fun getNotice() {
        //Log.i("acc","getNotice")
        // お知らせ一覧取得
        viewModelScope.launch {
            // ホームページ情報リフレッシュ
            if (HOME_INFO_REFRESH_FLAG) {
                LoadingUtil.setLoadingValue(value = true, type = true)
                accountInfoLogic.getAccountInfo()
            }
            when (accountInfoLogic.getAnnouncementInfo()) {
                true -> {
                }
                else -> {
                    setNotice()
                    // ホームページ情報リフレッシュ
                    if (HOME_INFO_REFRESH_FLAG) {
                        HOME_INFO_REFRESH_FLAG = false
                        setAccountInfo()
                        LoadingUtil.setLoadingValue(value = false)
                    }
                }
            }
        }
    }

    fun getChildAllowanceCampaign(anncmnt: Anncmnt) {
        // 画面遷移
        RouteUtil.navTo(
            RouteName.MBRC0201Page +
                "/${
                MBRC0201Parameter(
                    anncmntId = anncmnt.anncmntId,
                    announcementsType = AnnouncementsType.TYPE_AFTER.code,
                    applyId = anncmnt.applyId,
                    anncmntType = anncmnt.anncmntType,
                    documentType = anncmnt.documentType
                ).toJson()
                }"
        )
    }

    /**
     * ログアウトダイアログ
     */
    fun openLogoutDialogFlag() {
        viewStates = viewStates.copy(logoutDialogFlag = true)
    }

    /**
     * ログアウトダイアログルーズ
     */
    fun closeLogoutDialogFlag() {
        viewStates = viewStates.copy(logoutDialogFlag = false)
    }

    /**
     * クーポン留意事項ダイアログ
     */
    fun openCouponDialogFlag() {
        viewStates = viewStates.copy(couponDialogFlag = true)
    }

    /**
     * クーポン留意事項ダイアログクローズ
     */
    fun closeCouponDialogFlag() {
        viewStates = viewStates.copy(couponDialogFlag = false)
    }

    suspend fun loadTermIfNeeded(account : String, branch : String, cif : String){
        val state = viewStates.termCertificateStates.firstOrNull { it.account == account }
        if (state != null && (state.isLoading || state.complete)){
            //Log.i("acc", "loadTermIfNeeded ${state.account}")
            return
        }
        updateTermState(account) {
            it.copy(isLoading = true)
        }
//        viewModelScope.
        viewModelScope.launch {
            //Log.i("acc", "start load $account")
            var isSuccess = accountInfoLogic.getTermDepositDetailsInfoA(account,branch,cif)
            //Log.i("acc", "isSuccess $isSuccess")

            if (isSuccess) {
                updateTerm()
                updateTermState(account) {
                    it.copy(isLoading = false, complete = true)
                }
            } else {
                updateTermState(account) {
                    it.copy(isLoading = false, complete = false , error = "load failed")
                }
            }
        }
    }
    fun updateTerm(){
        // 定期預金情報
        viewStates.regularDepositList = mutableListOf()
        val realmRegularDepositInfo = dbService.findAll(EPassBookAB0403::class.java)
        if (realmRegularDepositInfo.isNotEmpty()) {
            realmRegularDepositInfo[0]?.termDepositDetails?.fromJson<List<Map<String, String>>>()?.forEach {
                val lotteryResultsDetailsDto: MutableList<LotteryResultsDetailsDto> = mutableListOf()
                val latestReceipDetailsDto: MutableList<LatestReceipDetailsDto> = mutableListOf()
                // 抽選結果明細
                val termDepositDetails = Gson().fromJson(Gson().toJson(it), TermDepositDetails::class.java)
                lotteryResultsDetailsDto.addAll(termDepositDetails.lotteryResults)
                // 最新受領情報
                latestReceipDetailsDto.addAll(termDepositDetails.latestReceiptInfo)
                if (viewStates.regularDepositList.none { exist -> exist.detailId == it["detailId"]  && exist.accountNumber == it["accountNumber"]  }){
                viewStates.regularDepositList.add(
                    TermDepositDetails(
                        detailId = it["detailId"] ?: "",
                        subNo = it["subNo"] ?: "",
                        typeCode = it["typeCode"] ?: "",
                        balanceOfLedger = it["balanceOfLedger"] ?: "",
                        interestRate = it["interestRate"] ?: "",
                        taxClassName = it["taxClassName"] ?: "",
                        maturityDate = it["maturityDate"] ?: "",
                        periodCodeValue = it["periodCodeValue"] ?: "",
                        interestReceivingMethod = it["interestReceivingMethod"] ?: "",
                        rewardAmountTypeValue = it["rewardAmountTypeValue"] ?: "",
                        interestReceiveAccountType = it["interestReceiveAccountType"] ?: "",
                        irAccountNumber = it["irAccountNumber"] ?: "",
                        contractDate = it["contractDate"] ?: "",
                        transactionClassification = it["transactionClassification"] ?: "",
                        memo = it["memo"] ?: "",
                        lotteryTimes = it["lotteryTimes"] ?: "",
                        handlingGroup = it["handlingGroup"] ?: "",
                        lotteryNoStart = it["lotteryNoStart"] ?: "",
                        lotteryNoEnd = it["lotteryNoEnd"] ?: "",
                        lotteryDate = it["lotteryDate"] ?: "",
                        branchNumber = it["branchNumber"] ?: "",
                        accountNumber = it["accountNumber"] ?: "",
                        startAmount = it["startAmount"] ?: "",
                        superRegularType = it["superRegularType"] ?: "",
                        lotteryResults = lotteryResultsDetailsDto,
                        latestReceiptInfo = latestReceipDetailsDto,
                        generalAccountFlag = it["generalAccountFlag"] ?: ""
                    )
                )}
            }
        }
    }
    fun updateNotice() {
        viewStates.notificationDeposit = mutableListOf()
        // 通知預金情報
        val realmNoticeDepositInfo = dbService.findAll(EPassBookAB0405::class.java)
        if (realmNoticeDepositInfo.isNotEmpty()) {
            realmNoticeDepositInfo[0]?.noticeDepositList?.fromJson<MBDP1101ResponseBean>()?.noticeDepositList?.forEach {
                if(viewStates.notificationDeposit.none{ exist -> exist.detailId == it.detailId && exist.accountNumber == it.accountNumber }){
                    viewStates.notificationDeposit.add(it)
                }
            }
        }
    }
    suspend fun loadNotifyIfNeeded(account : String, branch : String, cif : String){
        val state = viewStates.noticeCertificateStates.firstOrNull { it.account == account }
        if (state != null && (state.isLoading || state.complete)){
            //Log.i("acc", "loadTermIfNeeded ${state.account}")
            return
        }
        updateNoticeState(account) {
            it.copy(isLoading = true)
        }
//        viewModelScope.
        viewModelScope.launch {
            //Log.i("acc", "start load $account")
            var isSuccess = accountInfoLogic.getNoticeDepositListInfoA(account,branch,cif)
            //Log.i("acc", "isSuccess $isSuccess")

            if (isSuccess) {
                updateNotice()
                updateNoticeState(account) {
                    it.copy(isLoading = false, complete = true)
                }
            } else {
                updateNoticeState(account) {
                    it.copy(isLoading = false, complete = false , error = "load failed")
                }
            }
        }
    }

    fun updateTermState(account:String, transform:(TermCertificateState) -> TermCertificateState){
        viewStates = viewStates.copy(
            termCertificateStates = viewStates.termCertificateStates.map{ term ->
                if(term.account == account){
                    transform(term)
                } else {
                    term
                }
            }
        )
    }

    fun updateNoticeState(account:String, transform:(NoticeCertificateState) -> NoticeCertificateState){
        viewStates = viewStates.copy(
            noticeCertificateStates = viewStates.noticeCertificateStates.map{ term ->
                if(term.account == account){
                    transform(term)
                } else {
                    term
                }
            }
        )
    }
}

object ViewModelBus {
    val eventFlow = MutableSharedFlow<Pair<String, LoadStatus>>()
}

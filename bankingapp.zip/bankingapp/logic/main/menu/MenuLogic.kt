package jp.co.jsbank.mb.bankingapp.logic.main.menu

import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

/**
 * メニューロジック
 */
@HiltViewModel
class MenuLogic @Inject constructor() : ViewModel()

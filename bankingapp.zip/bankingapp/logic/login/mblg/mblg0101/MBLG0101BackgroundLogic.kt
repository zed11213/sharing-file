package jp.co.jsbank.mb.bankingapp.logic.login.mblg.mblg0101

import android.annotation.SuppressLint
import android.content.pm.ActivityInfo
import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.google.firebase.crashlytics.ktx.crashlytics
import com.google.firebase.ktx.Firebase
import dagger.hilt.android.lifecycle.HiltViewModel
import jp.co.jsbank.mb.bankingapp.logic.common.ToLoginLogic
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.repositories.api.request.gateway.GatewayRestService
import jp.co.jsbank.mb.bankingapp.system.Config
import jp.co.jsbank.mb.bankingapp.system.Config.TRY_COUNT
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mblg.mblg0101.MBLG0101PageState
import jp.co.jsbank.mb.bankingapp.utils.*
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.PIN
import javax.inject.Inject

/**
 * MBLG0101ロジック
 */
@HiltViewModel
class MBLG0101BackgroundLogic @Inject constructor(
    private var webService: RestService,
    private var gatewayWebService: GatewayRestService
) : ViewModel() {

    /**
     * MBLG0101テータス
     */
    var viewStates by mutableStateOf(MBLG0101PageState())
        private set

    /**
     * 初期化
     */
    init {
        if (PreferenceUtil.getPreferenceStringValue(ConstUtil.ACTIVITY_FLAG) ==
            ConstUtil.ACTIVITY_FLAG_NO_ACCESS_NO_LOGIN ||
            PreferenceUtil.getPreferenceStringValue(ConstUtil.ACTIVITY_FLAG) == ""
        ) {
            // 活性化フラグをtrueに設定する
            PreferenceUtil.setPreferenceStringValue(
                ConstUtil.ACTIVITY_FLAG,
                ConstUtil.ACTIVITY_FLAG_ACCESS_NO_LOGIN
            )
        }
    }

    /**
     * アプリのパスワード入力イベント
     */
    @SuppressLint("ResourceType")
    fun onPasswordChangeUnderThree(value: Int):Boolean {
        this.viewStates = this.viewStates.copy(password = (this.viewStates.password + value.toString()))
        return false
    }

    fun onPasswordChangeFour(value: Int):Boolean {
        var returnFlg = false
        this.viewStates = this.viewStates.copy(password = (this.viewStates.password + value.toString()))
        // アプリのパスワード認証処理を行う
        val checkResult: Boolean = passwordCheck()
        if (checkResult) {
            // PIN不正カウントリセット
            PreferenceUtil.setPreferenceIntValue(ConstUtil.PASS_ERR_COUNT, 0)
            this.viewStates = this.viewStates.copy(passwordErr = false, password = "")
            MainActivity.IS_BACK_GROUND = false
//            MainActivity.TOP_INFO_TIMER_FLAG = true
            returnFlg = true
//            if (viewStates.screenFlg) {
//                if (MainActivity.ACTIVITY?.requestedOrientation == ActivityInfo.SCREEN_ORIENTATION_PORTRAIT) {
//                    PreferenceUtil.setPreferenceBooleanValue(ConstUtil.PAGE_NO_DESTROY_FLAG, true)
//                    MainActivity.ACTIVITY?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
//                }
//            }
        } else {
            // PINが不正な場合
            // PIN不正カウント設定
            PreferenceUtil.setPreferenceIntValue(
                ConstUtil.PASS_ERR_COUNT,
                PreferenceUtil.getPreferenceIntValue(ConstUtil.PASS_ERR_COUNT) + 1
            )
            if (PreferenceUtil.getPreferenceIntValue(ConstUtil.PASS_ERR_COUNT) >= Config.TRY_COUNT) {
                // プッシュ通知登録成功フラグ
                PreferenceUtil.removePreferenceStringValue(ConstUtil.PUSH_OK_FLAG)
                // バンキングアプリ初期化
                FirebaseUtil.addLog("PINが不正な場合ため、systemInfoClearを実行[MBLG0101BackgroundLogic.kt]")
                systemInfoClear()
            } else {
                this.viewStates = this.viewStates.copy(passwordErr = true, password = "")
            }
        }
        return returnFlg
    }

    /**
     * アプリのパスワード削除イベント
     */
    fun onPasswordDelete() {
        if (viewStates.password.isNotEmpty()) {
            viewStates = viewStates.copy(password = (viewStates.password.substring(0, viewStates.password.length - 1)))
        }
    }

    /**
     * 入力されたPINを検証する
     */
    private fun passwordCheck(): Boolean {
        val list : Array<String> = arrayOf(
            ConstUtil.COMMON_KEY_LABEL
        )
        val jagPeerBean = KeyStoreUtil().getJagInfo(list)
        // 入力されたPINをハッシュする
        val hashPassword: String = CommonKeyAESUtil().encrypt(
            viewStates.password,
            jagPeerBean.jagEncryptedKey
        )
        // 入力されたPINを検証する
        return (hashPassword == KeyStoreUtil().getFromKeyStore(PIN))
    }
}

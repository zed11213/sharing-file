package jp.co.jsbank.mb.bankingapp.logic.login.mblg.mblg0101

import android.annotation.SuppressLint
import android.content.pm.ActivityInfo
import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.crashlytics.ktx.crashlytics
import com.google.firebase.ktx.Firebase
import dagger.hilt.android.lifecycle.HiltViewModel
import jp.co.jsbank.mb.bankingapp.bean.common.JagPeerBean
import jp.co.jsbank.mb.bankingapp.bean.login.mblg.mblg0101.MBLG0101RequestBean
import jp.co.jsbank.mb.bankingapp.bean.login.mblg.mblg0304.MBLG0304RequestBean
import jp.co.jsbank.mb.bankingapp.bean.splash.mbco6201.MBCO6201RequestBean
import jp.co.jsbank.mb.bankingapp.logic.common.ToLoginLogic
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.repositories.api.request.gateway.GatewayRestService
import jp.co.jsbank.mb.bankingapp.system.Config
import jp.co.jsbank.mb.bankingapp.system.Config.TRY_COUNT
import jp.co.jsbank.mb.bankingapp.system.JsBankFirebaseMessagingService
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.system.master.JagApiServiceCode
import jp.co.jsbank.mb.bankingapp.system.master.LoginFlg
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mblg.mblg0101.MBLG0101PageState
import jp.co.jsbank.mb.bankingapp.utils.*
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.ACTIVITY_FLAG_ACCESS_LOGIN
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.BIOMETRIC_RESULT
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.BIOMETRIC_RESULT_ACCESS_CANCEL
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.BIOMETRIC_RESULT_ACCESS_FAIL
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.BIOMETRIC_RESULT_ACCESS_SUCCESS
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.BIOMETRIC_RESULT_NOT_ACCESS
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.PIN
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.*
import javax.inject.Inject

/**
 * MBLG0101ロジック
 */
@HiltViewModel
class MBLG0101Logic @Inject constructor(
    private var webService: RestService,
    private var gatewayWebService: GatewayRestService
) : ViewModel() {

    /**
     * MBLG0101テータス
     */
    var viewStates by mutableStateOf(MBLG0101PageState())
        private set

    /**
     * 初期化
     */
    init {
        // 生体認証を呼び出す
        if (!MainActivity.LOG_OUT_FLAG) {
            doBiometric()
        }

        if (PreferenceUtil.getPreferenceStringValue(ConstUtil.ACTIVITY_FLAG) ==
            ConstUtil.ACTIVITY_FLAG_NO_ACCESS_NO_LOGIN ||
            PreferenceUtil.getPreferenceStringValue(ConstUtil.ACTIVITY_FLAG) == ""
        ) {
            // 活性化フラグをtrueに設定する
            PreferenceUtil.setPreferenceStringValue(
                ConstUtil.ACTIVITY_FLAG,
                ConstUtil.ACTIVITY_FLAG_ACCESS_NO_LOGIN
            )
        }

        // ログイン画面表示フラグ
        MainActivity.LOGIN_PAGE_SHOW_FLAG = true
    }

    /**
     * 生体認証を呼び出す
     */
    private fun doBiometric() {
        val biometricEnable = BiometricsUtil().checkBiometricAvailable()
        if (biometricEnable && PreferenceUtil.getPreferenceBooleanValue(ConstUtil.BIOLOGICAL_STATE)) {
            // 生体認証利用可能の場合、顔認証/指紋認証を呼び出して、ログインを行う
            if (!PreferenceUtil.getPreferenceBooleanValue(ConstUtil.EXECUTE_FLAG)) {
                BiometricsUtil().biometricAuthenticate()
            }
        } else {
            // リセットフラグ
            PreferenceUtil.setPreferenceStringValue(BIOMETRIC_RESULT, BIOMETRIC_RESULT_NOT_ACCESS)
        }
    }

    /**
     * 認証
     */
    fun goAuthentication() {
        when (PreferenceUtil.getPreferenceStringValue(BIOMETRIC_RESULT)) {
            // 認証成功
            BIOMETRIC_RESULT_ACCESS_SUCCESS -> {
                // ログイン
                toLogin()
            }
            // 認証失敗
            BIOMETRIC_RESULT_ACCESS_FAIL -> {
                // リセットフラグ
                PreferenceUtil.setPreferenceStringValue(BIOMETRIC_RESULT, BIOMETRIC_RESULT_NOT_ACCESS)
                // プッシュ通知登録成功フラグ
                PreferenceUtil.removePreferenceStringValue(ConstUtil.PUSH_OK_FLAG)
                // 利用者ID、アクセストークン、リフレッシュトークン削除バンキングアプリ初期化
                PreferenceUtil.setPreferenceStringValue(
                    ConstUtil.ACTIVITY_FLAG,
                    ConstUtil.ACTIVITY_FLAG_NO_ACCESS_NO_LOGIN
                )
                MainActivity.IS_BACK_GROUND = false
                MainActivity.IS_MENU_CC_CARD = false
                PreferenceUtil.setPreferenceBooleanValue(ConstUtil.EXECUTE_FLAG, false)
                MainActivity.ACTIVITY_FLAG = ConstUtil.ACTIVITY_FLAG_NO_ACCESS_NO_LOGIN

                FirebaseUtil.addLog("生体認証失敗したため、jagInfoClearを実行[MBLG0101Logic.kt]")
                // トークンクリア
                KeyStoreUtil().jagInfoClear()
                // 利用者設定
                PreferenceUtil.setPreferenceStringValue(ConstUtil.USER, "")
                // PIN不正カウントリセット
                PreferenceUtil.setPreferenceIntValue(ConstUtil.PASS_ERR_COUNT, 0)
                // 公開鍵なしの場合、公開鍵、秘密鍵を生成する
                RSAUtil().initKey()
                // デバイス初回作成
                val uuid = UUID.randomUUID().toString()
                KeyStoreUtil().jagInfoSave(
                    JagPeerBean(deviceId = uuid)
                )
                // 入力情報クリア
                RealmClearUtil.realmClear()
                // 公開鍵登録APIを呼び出す
                az0901()
            }
            // 認証取消す
            BIOMETRIC_RESULT_ACCESS_CANCEL -> {
                // リセットフラグ
                PreferenceUtil.setPreferenceStringValue(BIOMETRIC_RESULT, BIOMETRIC_RESULT_NOT_ACCESS)
            }
        }
        PreferenceUtil.setPreferenceBooleanValue(ConstUtil.EXECUTE_FLAG, false)
    }

    /**
     * アプリのパスワード入力イベント
     */
    @SuppressLint("ResourceType")
    fun onPasswordChangeUnderThree(value: Int) {
        this.viewStates = this.viewStates.copy(password = (this.viewStates.password + value.toString()))
    }

    suspend fun onPasswordChangeFour(value: Int) {
        viewStates = viewStates.copy(password = (viewStates.password + value.toString()))
        // アプリのパスワード認証処理を行う
        val checkResult: Boolean = passwordCheck()
        if (checkResult) {
            // ログイン
            toLoginSuspend()
        } else {
            // PINが不正な場合
            // PIN不正カウント設定
            PreferenceUtil.setPreferenceIntValue(
                ConstUtil.PASS_ERR_COUNT,
                PreferenceUtil.getPreferenceIntValue(ConstUtil.PASS_ERR_COUNT) + 1
            )
            if (PreferenceUtil.getPreferenceIntValue(ConstUtil.PASS_ERR_COUNT) >= TRY_COUNT) {
                // プッシュ通知登録成功フラグ
                PreferenceUtil.removePreferenceStringValue(ConstUtil.PUSH_OK_FLAG)
                // PIN入力が一定回数間違い（５回）
                // 利用者ID、アクセストークン、リフレッシュトークン削除バンキングアプリ初期化
                PreferenceUtil.setPreferenceStringValue(
                    ConstUtil.ACTIVITY_FLAG,
                    ConstUtil.ACTIVITY_FLAG_NO_ACCESS_NO_LOGIN
                )
                MainActivity.IS_BACK_GROUND = false
                MainActivity.IS_MENU_CC_CARD = false
                PreferenceUtil.setPreferenceBooleanValue(ConstUtil.EXECUTE_FLAG, false)
                MainActivity.ACTIVITY_FLAG = ConstUtil.ACTIVITY_FLAG_NO_ACCESS_NO_LOGIN
                // トークンクリア
                KeyStoreUtil().jagInfoClear()
                // 利用者設定
                PreferenceUtil.setPreferenceStringValue(ConstUtil.USER, "")
                // PIN不正カウントリセット
                PreferenceUtil.setPreferenceIntValue(ConstUtil.PASS_ERR_COUNT, 0)
                // 生体認証無効
                PreferenceUtil.setPreferenceBooleanValue(ConstUtil.BIOLOGICAL_STATE, false)
                // 公開鍵なしの場合、公開鍵、秘密鍵を生成する
                RSAUtil().initKey()
                // デバイス初回作成
                val uuid = UUID.randomUUID().toString()
                KeyStoreUtil().jagInfoSave(JagPeerBean(deviceId = uuid))
                // 入力情報クリア
                withContext(Dispatchers.Main){
                    RealmClearUtil.realmClear()
                }
                // 公開鍵登録APIを呼び出す
                az0901()
            } else {
                viewStates = viewStates.copy(passwordErr = true, password = "")
            }
        }
    }

    // ログイン
    private fun toLogin() {
        // PIN不正カウントリセット
        PreferenceUtil.setPreferenceIntValue(ConstUtil.PASS_ERR_COUNT, 0)
        viewStates = viewStates.copy(passwordErr = false)
        viewModelScope.launch {
            LoadingUtil.setLoadingValue(value = true, type = true)
            // 初回ログインフラグ＝０の場合、利用者属性更新APIとログイン履歴登録API呼出
            if (MainActivity.ACTIVITY_FLAG != ACTIVITY_FLAG_ACCESS_LOGIN) {
                // 利用者flag
                val userFlag = PreferenceUtil.getPreferenceStringValue(ConstUtil.USER)
                // 利用者以外場合
                if (userFlag != ConstUtil.USER_NO_DONE && userFlag != ConstUtil.USER_DONE) {
                    // ログイン認証
                    loginAuthentication(LoginFlg.FIRST.code)
                } else {
                    // AZ0911 認可コード取得
                    az0911()
                    // AZ0911のエラーがない場合
                    if (!viewStates.az0911ErrorFlg) {
                        // ログイン認証
                        loginAuthentication(LoginFlg.FIRST.code)
                    }
                }
            } else {
                // 初回ログインフラグ＝１の場合、ログイン履歴登録APIのみ呼出
                loginAuthentication(LoginFlg.NOT_FIRST.code)
            }
            LoadingUtil.setLoadingValue(value = false)
        }
    }

    // ログイン
    private suspend fun toLoginSuspend() {
        // PIN不正カウントリセット
        PreferenceUtil.setPreferenceIntValue(ConstUtil.PASS_ERR_COUNT, 0)
        viewStates = viewStates.copy(passwordErr = false)
        viewModelScope.launch {
            LoadingUtil.setLoadingValue(value = true, type = true)
            // 初回ログインフラグ＝０の場合、利用者属性更新APIとログイン履歴登録API呼出
            if (MainActivity.ACTIVITY_FLAG != ACTIVITY_FLAG_ACCESS_LOGIN) {
                // 利用者flag
                val userFlag = PreferenceUtil.getPreferenceStringValue(ConstUtil.USER)
                // 利用者以外場合
                if (userFlag != ConstUtil.USER_NO_DONE && userFlag != ConstUtil.USER_DONE) {
                    // ログイン認証
                    loginAuthentication(LoginFlg.FIRST.code)
                } else {
                    // AZ0911 認可コード取得
                    az0911()
                    // AZ0911のエラーがない場合
                    if (!viewStates.az0911ErrorFlg) {
                        // ログイン認証
                        loginAuthentication(LoginFlg.FIRST.code)
                    }
                }
            } else {
                // 初回ログインフラグ＝１の場合、ログイン履歴登録APIのみ呼出
                loginAuthentication(LoginFlg.NOT_FIRST.code)
            }
            LoadingUtil.setLoadingValue(value = false)
        }.join()
    }

    /**
     * AZ0901 公開鍵登録
     */
    private fun az0901() {
        val param = MBCO6201RequestBean()
        val list: Array<String> = arrayOf(
            ConstUtil.DEVICE_ID
        )
        val jagPeerBean = KeyStoreUtil().getJagInfo(list)
        // デバイスID
        val deviceId = jagPeerBean.deviceId

        // パラメータを下記よに設定する
        // デバイスID
        param.jagDeviceId = deviceId
        // アプリケーションID
        param.jagApplicationId = Config.getAppId()
        // 公開鍵
        param.jagPublicKey = RSAUtil().loadPublicKeyByFile()
        // チャレンジトークン
        param.jagChallengeToken = RSAUtil().encryptAESByJavaCrypt(
            deviceId,
            String(Base64.getDecoder().decode(ConstUtil.JAG_ENV_SECRET_KEY)),
            String(Base64.getDecoder().decode(ConstUtil.JAG_ENV_CLIENT_SECRET_KEY))
        )
        // TRX種別
        param.jagTrxType = ConstUtil.JAG_TRX_TYPE_TCC
        // トランザクションID
        param.jagTrxId = ""
        // API サービス名称
        PreferenceUtil.setPreferenceStringValue(ConstUtil.API_SERVICE_NAME, JagApiServiceCode.AZ0901.value)

        viewModelScope.launch {
            flow {
                emit(gatewayWebService.AZ0901(param))
            }.map {
                // Jag情報ローカルに保存する
                KeyStoreUtil().jagInfoSave(JagPeerBean(jagTrxId = it.jagTrxId, jagEncryptedKey = it.jagEncryptedKey))
                // TCC確定
                az0906()
            }.catch {
                // デバイスバンディングフラグをtrueに設定する
                PreferenceUtil.setPreferenceBooleanValue(ConstUtil.DEVICE_BINDING_FLAG, false)
                viewStates = viewStates.copy(errorFlag = true)
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }
    }

    /**
     * AZ0906 TCC確定
     */
    private fun az0906() {
        val param = MBCO6201RequestBean()
        val list : Array<String> = arrayOf(
            ConstUtil.JAG_RES_TRXID,
            ConstUtil.DEVICE_ID,
            ConstUtil.COMMON_KEY_LABEL
        )
        val jagPeerBean = KeyStoreUtil().getJagInfo(list)
        // デバイスID
        val deviceId = jagPeerBean.deviceId
        // トランザクションID
        val trxId = jagPeerBean.jagTrxId
        // チャレンジトークン
        val challengeToken = RSAUtil().encryptAESByJavaCrypt(
            trxId,
            RSAUtil().rsaDecrypt(jagPeerBean.jagEncryptedKey),
            String(Base64.getDecoder().decode(ConstUtil.JAG_ENV_CLIENT_SECRET_KEY))
        )

        // パラメータを下記よに設定する
        // デバイスID
        param.jagDeviceId = deviceId
        // アプリケーションID
        param.jagApplicationId = Config.getAppId()
        // トランザクションID
        param.jagTrxId = trxId
        // チャレンジトークン
        param.jagChallengeToken = challengeToken
        // 確定キャンセル要求
        param.jagDoCancel = ConstUtil.JAG_TRX_DO_CONFIRM
        // API サービス名称
        PreferenceUtil.setPreferenceStringValue(ConstUtil.API_SERVICE_NAME, JagApiServiceCode.AZ0906.value)

        viewModelScope.launch {
            flow {
                emit(gatewayWebService.AZ0906(param))
            }.map {
                if (it != ConstUtil.API_RESULT_OK) {
                    viewStates = viewStates.copy(errorFlag = true)
                } else {
                    // デバイスバンディングフラグをtrueに設定する
                    PreferenceUtil.setPreferenceBooleanValue(ConstUtil.DEVICE_BINDING_FLAG, true)
                    // MBLG1001 アプリ初期化通知画面へ遷移する
                    RouteUtil.navTo(
                        RouteName.MBLG1001Page
                    )
                }
            }.catch {
                // デバイスバンディングフラグをtrueに設定する
                PreferenceUtil.setPreferenceBooleanValue(ConstUtil.DEVICE_BINDING_FLAG, false)
                viewStates = viewStates.copy(errorFlag = true)
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }
    }

    /**
     * ログイン認証
     */
    private suspend fun loginAuthentication(loginFlg: String) {
        // 画面IDとイベントID設定
        PreferenceUtil.setScreenIDAndEventID("MBLG0101", "E01")
        val param = MBLG0101RequestBean(loginFlg = loginFlg)
        viewModelScope.async {
            flow {
                ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, param.toJson())
                emit(webService.AB0201())
            }.map {
                // ログイン画面表示フラグ
                MainActivity.LOGIN_PAGE_SHOW_FLAG = false
                // ログイン時間をローカルに保存する
                PreferenceUtil.setPreferenceStringValue(ConstUtil.LAST_LOGIN_TIME, it.resultDto!!.loginTs)
                // プッシュ通知登録
                if (it.resultDto!!.tokenFlg == "0") {
                    if (!JsBankFirebaseMessagingService().isNullFirebaseToken()) {
                        pushInfoSignUp()
                    }
                }
                if (PreferenceUtil.getPreferenceStringValue(ConstUtil.ACTIVITY_FLAG) == ACTIVITY_FLAG_ACCESS_LOGIN) {
                    // MBLG0201_ローディング画面画面へ遷移されること。
                    RouteUtil.navTo(RouteName.MBLG0201Page)
                } else {
                    if (BiometricsUtil().checkBiometricAvailable()) {
                        // 生体認証が利可能の場合、MBLG0303「生体認証有効化確認」へ遷移する
                        RouteUtil.navTo(RouteName.MBLG0303Page)
                    } else {
                        // 上記以外の場合、MBLG0304「Push通知有効化確認」へ遷移する
                        RouteUtil.navTo(RouteName.MBLG0304Page)
                    }
                }
            }.catch {
                viewStates = viewStates.copy(password = "")
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }.await()
    }

    /**
     * プッシュ通知登録
     */
    private suspend fun pushInfoSignUp() {
        // 画面IDとイベントID設定
        PreferenceUtil.setScreenIDAndEventID("MBLG0101", "E01")
        // パラメータ設定
        val requestBean = MBLG0304RequestBean()
        requestBean.identity = PreferenceUtil.getPreferenceStringValue(ConstUtil.PUSH_TOKEN_IDENTIFY).toString()
        requestBean.address = PreferenceUtil.getPreferenceStringValue(ConstUtil.PUSH_TOKEN).toString()
        // サービスを呼び出す
        viewModelScope.async {
            flow {
                ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, requestBean.toJson())
                emit(webService.AB0121())
            }.map {
                MainActivity.PUSH_API_RUN_FLAG = true
                if (it.resultDto != ConstUtil.API_RESULT_OK) {
                    PreferenceUtil.setPreferenceStringValue(ConstUtil.PUSH_OK_FLAG, "1")
                } else {
                    PreferenceUtil.removePreferenceStringValue(ConstUtil.PUSH_OK_FLAG)
                }
            }.catch {
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }.await()
    }

    /**
     * AZ0911 認可コード取得
     */
    private suspend fun az0911() {
        // 画面IDとイベントID設定
        PreferenceUtil.setScreenIDAndEventID("MBLG0101", "E01")
        viewStates = viewStates.copy(az0911ErrorFlg = false)
        MainActivity.AZ0911_ERROR_FLG = true
        viewModelScope.async {
            val param = MBCO6201RequestBean()
            val list : Array<String> = arrayOf(
                ConstUtil.JAG_RES_TRXID,
                ConstUtil.DEVICE_ID
            )
            val jagPeerBean = KeyStoreUtil().getJagInfo(list)

            // JAG PROFILE JWTをローカルに保存する
            val jagProfile = JWTUtil().createJWT()

            // JAG PROFILE JWT
            param.jagProfile = jagProfile
            // デバイスID
            param.jagDeviceId = jagPeerBean.deviceId
            // アプリケーションID
            param.jagApplicationId = Config.getAppId()
            // TRX種別
            param.jagTrxType = ConstUtil.JAG_TRX_TYPE_NRM
            // トランザクションID
            param.jagTrxId = jagPeerBean.jagTrxId
            // API サービス名称
            PreferenceUtil.setPreferenceStringValue(ConstUtil.API_SERVICE_NAME, JagApiServiceCode.AZ0911.value)

            FirebaseUtil.setUser(param.jagDeviceId)

            flow {
                emit(gatewayWebService.AZ0911(param))
            }.map {
                MainActivity.AZ0911_ERROR_FLG = false
                // 活性化フラグをtrueに設定する
                PreferenceUtil.setPreferenceStringValue(
                    ConstUtil.ACTIVITY_FLAG,
                    ConstUtil.ACTIVITY_FLAG_ACCESS_NO_LOGIN
                )
                // Jag情報ローカルに保存する
                KeyStoreUtil().jagInfoSave(
                    JagPeerBean(
                        jagTrxId = it.jagTrxId,
                        jagAccessToken = it.jagAccessToken,
                        jagRefreshToken = it.jagRefreshToken
                    )
                )

                // 利用者場合、状態「利用者初回登録未完了」を「利用者初回登録完了」に変更する
                if (PreferenceUtil.getPreferenceStringValue(ConstUtil.USER).toString().isNotBlank()) {
                    // 利用者設定:初回登録未完了
                    PreferenceUtil.setPreferenceStringValue(ConstUtil.USER, ConstUtil.USER_DONE)
                }
            }.catch {
                MainActivity.AZ0911_ERROR_FLG = true
                viewStates = viewStates.copy(az0911ErrorFlg = true, password = "")
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }.await()
    }

    /**
     * アプリのパスワード削除イベント
     */
    fun onPasswordDelete() {
        if (viewStates.password.isNotEmpty()) {
            viewStates = viewStates.copy(password = (viewStates.password.substring(0, viewStates.password.length - 1)))
        }
    }

    /**
     * 入力されたPINを検証する
     */
    private fun passwordCheck(): Boolean {
        val list : Array<String> = arrayOf(
            ConstUtil.COMMON_KEY_LABEL
        )
        val jagPeerBean = KeyStoreUtil().getJagInfo(list)
        // 入力されたPINをハッシュする
        val hashPassword: String = CommonKeyAESUtil().encrypt(
            viewStates.password,
            jagPeerBean.jagEncryptedKey
        )
        // 入力されたPINを検証する
        return (hashPassword == KeyStoreUtil().getFromKeyStore(PIN))
    }
}

package jp.co.jsbank.mb.bankingapp.logic.login.mblg.mblg2002

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mblg.mblg2002.MBLG2002PageState

/**
 * MBSU2001ロジック
 */
@HiltViewModel
class MBLG2002Logic @Inject constructor(
    private var webService: RestService,
) : ViewModel() {

    // ログインステータス
    var viewStates by mutableStateOf(MBLG2002PageState())
        private set

    fun openErrorDialog() {
        viewStates = viewStates.copy(errorFlag = true)
    }

    fun closeErrorDialog() {
        viewStates = viewStates.copy(errorFlag = false)
    }
}

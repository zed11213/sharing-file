package jp.co.jsbank.mb.bankingapp.logic.login.mblg.mblg0304

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import jp.co.jsbank.mb.bankingapp.bean.login.mblg.mblg0304.MBLG0304RequestBean
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mblg.mblg0304.MBLG0304PageState
import jp.co.jsbank.mb.bankingapp.utils.*
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.API_RESULT_OK
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.FROM_OTHER
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/**
 * MBLG0304ロジック
 */
@HiltViewModel
class MBLG0304Logic @Inject constructor(
    private var webService: RestService
) : ViewModel() {

    /**
     * MBLG0304ステータス
     */
    var viewStates by mutableStateOf(MBLG0304PageState())
        private set

    /**
     * プッシュ通知登録
     */
    fun pushInfoSignUp() {
        // 画面IDとイベントID設定
        PreferenceUtil.setScreenIDAndEventID("MBLG0304", "E02")
        // パラメータ設定
        val requestBean = MBLG0304RequestBean()
        requestBean.identity = PreferenceUtil.getPreferenceStringValue(ConstUtil.PUSH_TOKEN_IDENTIFY).toString()
        requestBean.address = PreferenceUtil.getPreferenceStringValue(ConstUtil.PUSH_TOKEN).toString()
        // サービスを呼び出す
        viewModelScope.launch {
            flow {
                ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, requestBean.toJson())
                emit(webService.AB0121())
            }.map {
                if (it.resultDto != API_RESULT_OK) {
                    PreferenceUtil.setPreferenceStringValue(ConstUtil.PUSH_OK_FLAG, "1")
                } else {
                    PreferenceUtil.removePreferenceStringValue(ConstUtil.PUSH_OK_FLAG)
                }
                RouteUtil.navTo(RouteName.MBLG0301Page, FROM_OTHER)
            }.catch {
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }
    }
}

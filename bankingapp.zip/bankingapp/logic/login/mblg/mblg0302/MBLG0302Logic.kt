package jp.co.jsbank.mb.bankingapp.logic.login.mblg.mblg0302

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import jp.co.jsbank.mb.bankingapp.bean.login.mblg.mblg0302.MBLG0302RequestBean
import jp.co.jsbank.mb.bankingapp.bean.main.menu.mbst.mbst0302.UpdateDesignInfomationReq
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mblg.mblg0302.MBLG0302PageState
import jp.co.jsbank.mb.bankingapp.utils.*
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/**
 * MBLG0302ロジック
 */
@HiltViewModel
class MBLG0302Logic @Inject constructor(
    private var webService: RestService
) : ViewModel() {
    /**
     * MBLG0302テータス
     */
    var viewStates by mutableStateOf(MBLG0302PageState())
        private set

    init {
        val from = MainActivity.NAVCTRL?.currentBackStackEntry?.arguments?.get(ConstUtil.DATA).toString()

        if (from == ConstUtil.FROM_MENU) {
            viewModelScope.launch {
                // 画面IDとイベントID設定
                PreferenceUtil.setScreenIDAndEventID("MBLG0302", "E01")
                flow {
                    ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST)
                    emit(webService.AB1105())
                }.map {
                    viewStates = viewStates.copy(bankbookPattern = it.resultDto!!)
                }.catch {
                    ErrorUtil().apiErrorCatch(it.message.toString())
                }.collect()
            }
        }
        viewStates = viewStates.copy(from = from)
    }

    /**
     * 通帳デザイン選択
     */
    fun onBankbookPatternChange(bankbookPattern: String) {
        viewStates = viewStates.copy(bankbookPattern = bankbookPattern)
    }

    /**
     * 通帳パターン設定
     */
    fun bankbookPatternSignUp(from: String) {
        if (from == ConstUtil.FROM_OTHER) {
            val requestBean = MBLG0302RequestBean(viewStates.bankbookPattern)
            viewModelScope.launch {
                // 画面IDとイベントID設定
                PreferenceUtil.setScreenIDAndEventID("MBLG0302", "E01")
                flow {
                    ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, requestBean.toJson())
                    emit(webService.AB0120())
                }.map {
                    PreferenceUtil.setPreferenceStringValue(ConstUtil.DESIGN_TYPE, viewStates.bankbookPattern)
                    // MBLG0201 ローディングへ遷移する
                    RouteUtil.navTo(
                        RouteName.MBLG0201Page
                    )
                }.catch {
                    ErrorUtil().apiErrorCatch(it.message.toString())
                }.collect()
            }
        } else {
            val requestBean = UpdateDesignInfomationReq()
            requestBean.settingContent = viewStates.bankbookPattern
            viewModelScope.launch {
                // 画面IDとイベントID設定
                PreferenceUtil.setScreenIDAndEventID("MBLG0302", "E01")
                flow {
                    ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, requestBean.toJson())
                    emit(webService.AB1106())
                }.map {
                    PreferenceUtil.setPreferenceStringValue(ConstUtil.DESIGN_TYPE, viewStates.bankbookPattern)
                    RouteUtil.navTo(
                        RouteName.HOME
                    )
                }.catch {
                    ErrorUtil().apiErrorCatch(it.message.toString())
                }.collect()
            }
        }
    }
}

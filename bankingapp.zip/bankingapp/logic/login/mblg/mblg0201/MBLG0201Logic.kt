package jp.co.jsbank.mb.bankingapp.logic.login.mblg.mblg0201

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.*
import javax.inject.Inject
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.logic.common.AccountInfoLogic
import jp.co.jsbank.mb.bankingapp.repositories.api.request.AsyncRestService
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.system.master.BankbookDesign
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mblg.mblg0201.MBLG0201PageState
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mblg.mblg0201.Season
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.DESIGN_TYPE
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.LOGIN_TIME
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.TOP_CARD_INDEX
import jp.co.jsbank.mb.bankingapp.utils.LoadingUtil
import jp.co.jsbank.mb.bankingapp.utils.PreferenceUtil
import jp.co.jsbank.mb.bankingapp.utils.RouteUtil
import kotlinx.coroutines.launch

/**
 * MBLG0201ロジック
 */
@HiltViewModel
class MBLG0201Logic @Inject constructor(
    private var webService: RestService,
    private var asyncWebService: AsyncRestService
) : ViewModel() {

    /**
     * MBLG0201テータス
     */
    var viewStates by mutableStateOf(MBLG0201PageState())

    /**
     * 初期化
     */
    init {
        var curSeason = Season()
        var seasonImageList: List<Int> = listOf()
        // 季節によって、UIを切り替える
        val calendar = Calendar.getInstance()
        val designType = PreferenceUtil.getPreferenceStringValue(DESIGN_TYPE)
        when (calendar.get(Calendar.MONTH)) {
            2, 3, 4 -> {
                curSeason = viewStates.seasonList.first { it.type == "1" }
                seasonImageList =
                    if (designType == BankbookDesign.JAPANESE_PATTERN_DESIGN.code) {
                        viewStates.springImageList
                    } else {
                        listOf(
                            R.drawable.spring_cinnamoroll
                        )
                    }
            }
            5, 6, 7 -> {
                curSeason = viewStates.seasonList.first { it.type == "2" }
                seasonImageList =
                    if (designType == BankbookDesign.JAPANESE_PATTERN_DESIGN.code) {
                        viewStates.summerImageList
                    } else {
                        listOf(
                            R.drawable.summer_cinnamoroll
                        )
                    }
            }
            8, 9, 10 -> {
                curSeason = viewStates.seasonList.first { it.type == "3" }
                seasonImageList =
                    if (designType == BankbookDesign.JAPANESE_PATTERN_DESIGN.code) {
                        viewStates.autumnImageList
                    } else {
                        listOf(
                            R.drawable.autumn_cinnamoroll
                        )
                    }
            }
            11, 1, 0 -> {
                curSeason = viewStates.seasonList.first { it.type == "4" }
                seasonImageList =
                    if (designType == BankbookDesign.JAPANESE_PATTERN_DESIGN.code) {
                        viewStates.winterImageList
                    } else {
                        listOf(
                            R.drawable.winter_cinnamoroll
                        )
                    }
            }
        }
        val index = (seasonImageList.indices).random()
        curSeason.image = seasonImageList[index]
        viewStates = viewStates.copy(season = curSeason, loadingFlag = false)

        getTopPageInfo()
    }

    /**
     * トップ情報取得
     */
    private fun getTopPageInfo() {
        // 画面IDとイベントID設定
        PreferenceUtil.setScreenIDAndEventID("MBLG0201", "E01")
//        viewStates = viewStates.copy(loadingFlag = true)
        // トップ情報取得
        val accountInfoLogic = AccountInfoLogic(webService, asyncWebService)
        viewModelScope.launch {
            LoadingUtil.setLoadingValue(closeFlag = true)
            val result = accountInfoLogic.getAccountInfo()
            LoadingUtil.setLoadingValue(closeFlag = false)
            when (result) {
                true -> {
                }
                else -> {
                    PreferenceUtil.setPreferenceStringValue(TOP_CARD_INDEX, "")
                    // ログイン時間設定
                    val dtf = DateTimeFormatter.ofPattern("yyyy.MM.dd HH:mm", Locale.JAPAN)
                    PreferenceUtil.setPreferenceStringValue(LOGIN_TIME, dtf.format(LocalDateTime.now()))
                    // トップ画面へ遷移する
                    RouteUtil.navTo(
                        RouteName.HOME
                    )
                }
            }
        }
    }
}

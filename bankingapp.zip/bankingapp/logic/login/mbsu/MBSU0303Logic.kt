package jp.co.jsbank.mb.bankingapp.logic.login.mbsu

import androidx.compose.foundation.ScrollState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.system.MyApp.Companion.CONTEXT
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mbsu.mbsu0303.MBSU0303ErrorInformation
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mbsu.mbsu0303.MBSU0303PageState
import jp.co.jsbank.mb.bankingapp.utils.*
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isHalfNum
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.houjin_name_kana
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * MBSU0303ロジック
 */
@HiltViewModel
class MBSU0303Logic @Inject constructor() : ViewModel() {

    // MBSU0303ステータス
    var viewStates by mutableStateOf(MBSU0303PageState())
        private set

    /**
     * 次への処理
     */
    fun doCheck(coroutineScope: CoroutineScope, scrollState: ScrollState) {
        // エラー情報初期化
        val errorBean = MBSU0303ErrorInformation()
        viewStates = viewStates.copy(isError = false)
        viewStates = viewStates.copy(errorBean = errorBean)
        viewStates = viewStates.copy(errMsgList = listOf())

        // 事業先名（半角カナ）の入力チェック
        if (viewStates.requestBean.kanaName.isBlank()) {
            errorBean.kanaNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        CONTEXT.getString(R.string.MSG_ID_MB002014V),
                        CONTEXT.getString(R.string.mbsu0303_page_label_name)
                    )
                )
            )
        } else if (!viewStates.requestBean.kanaName.houjin_name_kana()) {
            // 法人名（半角カナ）のカナチェック
            errorBean.kanaNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        CONTEXT.getString(R.string.MSG_ID_MB002009V),
                        CONTEXT.getString(R.string.mbsu0303_page_label_name)
                    )
                )
            )
        }

        // 設立年の入力チェック
        if (viewStates.requestBean.birthdayYear.isBlank()) {
            errorBean.birthdayYearErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        CONTEXT.getString(R.string.MSG_ID_MB002014V),
                        CONTEXT.getString(R.string.common_message_replace_label_setYear)
                    )
                )
            )
        }
        // 設立月の入力チェック
        if (viewStates.requestBean.birthdayMonth.isBlank()) {
            errorBean.birthdayMonthErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        CONTEXT.getString(R.string.MSG_ID_MB002014V),
                        CONTEXT.getString(R.string.common_message_replace_label_setMonth)
                    )
                )
            )
        }
        // 設立日の入力チェック
        if (viewStates.requestBean.birthdayDay.isBlank()) {
            errorBean.birthdayDayErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        CONTEXT.getString(R.string.MSG_ID_MB002014V),
                        CONTEXT.getString(R.string.common_message_replace_label_setDay)
                    )
                )
            )
        }
        // 設立年月日チェック
        if (viewStates.requestBean.birthdayYear.isNotBlank() &&
            viewStates.requestBean.birthdayMonth.isNotBlank() &&
            viewStates.requestBean.birthdayDay.isNotBlank()
        ) {
            if (!EditCheckUtil.isDayCheck(
                    viewStates.requestBean.birthdayYear,
                    viewStates.requestBean.birthdayMonth,
                    viewStates.requestBean.birthdayDay
                )
            ) {
                errorBean.birthdayYearErrorFlag = true
                errorBean.birthdayMonthErrorFlag = true
                errorBean.birthdayDayErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        MessageReplaceUtils.messageReplace(
                            CONTEXT.getString(R.string.MSG_ID_MB002007V),
                            CONTEXT.getString(R.string.mbsu0303_page_label_set_date)
                        )
                    )
                )
            }
            // 未来日チェック
            else if (EditCheckUtil.isFutureDays(
                    viewStates.requestBean.birthdayYear +
                        viewStates.requestBean.birthdayMonth +
                        viewStates.requestBean.birthdayDay
                )
            ) {
                errorBean.birthdayYearErrorFlag = true
                errorBean.birthdayMonthErrorFlag = true
                errorBean.birthdayDayErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        MessageReplaceUtils.messageReplace(
                            CONTEXT.getString(R.string.MSG_ID_MB002007V),
                            CONTEXT.getString(R.string.mbsu0303_page_label_set_date)
                        )
                    )
                )
            }
        }

        // 郵便番号の入力チェック
        if (viewStates.requestBean.postCode.isBlank()) {
            errorBean.postCodeErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        CONTEXT.getString(R.string.MSG_ID_MB002014V),
                        CONTEXT.getString(R.string.mbsu0303_page_label_postCode)
                    )
                )
            )
        } else if (!viewStates.requestBean.postCode.isHalfNum()) {
            // 郵便番号の半角数字チェック
            errorBean.postCodeErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        CONTEXT.getString(R.string.MSG_ID_MB002012V),
                        CONTEXT.getString(R.string.mbsu0303_page_label_postCode)
                    )
                )
            )
        } else if (!EditCheckUtil.lengthCheck(viewStates.requestBean.postCode, 7)) {
            // 郵便番号の桁数チェック
            errorBean.postCodeErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    CONTEXT.getString(R.string.MSG_ID_MB002003V)
                )
            )
        }
        // 店舗の入力チェック
        if (viewStates.requestBean.shop.isEmpty()) {
            errorBean.shopErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        CONTEXT.getString(R.string.MSG_ID_MB002022V),
                        CONTEXT.getString(R.string.mbsu0303_page_label_shop_name)
                    )
                )
            )
        }
        // 口座番号の入力チェック
        if (viewStates.requestBean.accountNumber.isEmpty()) {
            errorBean.accountNumberErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        CONTEXT.getString(R.string.MSG_ID_MB002014V),
                        CONTEXT.getString(R.string.mbsu0303_page_label_account_number)
                    )
                )
            )
        } else if (!viewStates.requestBean.accountNumber.isHalfNum()) {
            // 口座番号の半角数字チェック
            errorBean.accountNumberErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        CONTEXT.getString(R.string.MSG_ID_MB002012V),
                        CONTEXT.getString(R.string.mbsu0303_page_label_account_number)
                    )
                )
            )
        } else if (!EditCheckUtil.lengthCheck(viewStates.requestBean.accountNumber, 7)) {
            // 口座番号の桁数チェック
            errorBean.accountNumberErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    CONTEXT.getString(R.string.MSG_ID_MB002037V)
                )
            )
        }
        // 暗証番号の入力チェック
        if (viewStates.requestBean.cashCardPassword.isEmpty()) {
            errorBean.cashCardPasswordErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        CONTEXT.getString(R.string.MSG_ID_MB002014V),
                        CONTEXT.getString(R.string.mbsu0303_page_label_cash_card_number)
                    )
                )
            )
        } else if (!viewStates.requestBean.cashCardPassword.isHalfNum()) {
            // キャッシュカード暗証番号（4桁）の半角数字チェック
            errorBean.cashCardPasswordErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        CONTEXT.getString(R.string.MSG_ID_MB002012V),
                        CONTEXT.getString(R.string.mbsu0303_page_label_cash_card_number)
                    )
                )
            )
        } else if (!EditCheckUtil.lengthCheck(viewStates.requestBean.cashCardPassword, 4)) {
            // キャッシュカード暗証番号（4桁）の桁数チェック
            errorBean.cashCardPasswordErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    CONTEXT.getString(R.string.MSG_ID_MB002005V)
                )
            )
        }
        if (!viewStates.isError) {
            // 全角カナを半角カナに変換する
            val bean = viewStates.requestBean
            bean.kanaName = HalfToFullUtils.bigToSmallChar(HalfToFullUtils.fullToHalfCharName(bean.kanaName))
            viewStates = viewStates.copy(requestBean = bean)

            // MBSU0304　情報入力確認
            RouteUtil.navTo(
                RouteName.MBSU0304Page + "/${viewStates.requestBean.toJson()}",
            )
        } else {
            coroutineScope.launch {
                scrollState.animateScrollTo(0)
            }
        }
    }

    /**
     * 郵便番号ダイアログの表示フラグ切替
     */
    fun switchPostCodeAlertDialog() {
        viewStates = viewStates.copy(postCodeShowFlag = !viewStates.postCodeShowFlag)
    }

    /**
     * 口座番号ダイアログの表示フラグ切替
     */
    fun switchAccountNumberShowFlag() {
        viewStates = viewStates.copy(accountNumberShowFlag = !viewStates.accountNumberShowFlag)
    }
}

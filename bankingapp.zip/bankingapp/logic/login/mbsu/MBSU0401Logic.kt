package jp.co.jsbank.mb.bankingapp.logic.login.mbsu

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.system.MyApp.Companion.CONTEXT
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mbsu.mbsu0401.MBSU0401ErrorInformation
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mbsu.mbsu0401.MBSU0401PageState
import jp.co.jsbank.mb.bankingapp.utils.*
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.PIN
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isHalfNum
import javax.inject.Inject

/**
 * MBSU0401ロジック
 */
@HiltViewModel
class MBSU0401Logic @Inject constructor() : ViewModel() {

    // ステータス
    var viewStates by mutableStateOf(MBSU0401PageState())
        private set

    // パスワードをロカールに保存する
    private fun passwordSave() {
        val list : Array<String> = arrayOf(
            ConstUtil.COMMON_KEY_LABEL
        )
        val jagPeerBean = KeyStoreUtil().getJagInfo(list)
        KeyStoreUtil().saveToKeyStore(
            PIN,
            CommonKeyAESUtil().encrypt(
                viewStates.password,
                jagPeerBean.jagEncryptedKey
            )
        )
    }

    // エラーチェック
    fun passwordCheck() {
        // エラー情報初期化
        val errorBean = MBSU0401ErrorInformation()
        viewStates = viewStates.copy(errorFlag = false)
        viewStates = viewStates.copy(errorBean = errorBean)
        viewStates = viewStates.copy(errorMessageList = listOf())

        // パスワードが4桁未満場合：MB003002H
        if (!EditCheckUtil.lengthCheck(viewStates.password, 4)) {
            errorBean.passwordErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(errorFlag = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    CONTEXT.getString(R.string.MSG_ID_MB003002H)
                )
            )
            return
        }

        // パスワードが半角数字以外場合：MB003004V
        if (!viewStates.password.isHalfNum()) {
            errorBean.passwordErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(errorFlag = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    CONTEXT.getString(R.string.MSG_ID_MB003004V)
                )
            )
            return
        }

        // パスワードが一致しない場合：MB003003V
        if (viewStates.password != viewStates.confirmPassword) {
            errorBean.passwordErrorFlag = true
            errorBean.confirmPasswordErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(errorFlag = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    CONTEXT.getString(R.string.MSG_ID_MB003003V)
                )
            )
            return
        }

        if (!viewStates.errorFlag) {
            passwordSave()
            // MBSU0202　ステップ２
            RouteUtil.navTo(
                RouteName.MBSU0202Page,
            )
        }
    }
}

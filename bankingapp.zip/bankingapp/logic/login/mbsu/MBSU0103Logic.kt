package jp.co.jsbank.mb.bankingapp.logic.login.mbsu

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mbsu.mbsu0302.MBSU0302PageState

/**
 * MBSU0103ロジック
 */
@HiltViewModel
class MBSU0103Logic @Inject constructor(
    private var webService: RestService,
) : ViewModel() {

    // ログインステータス
    var viewStates by mutableStateOf(MBSU0302PageState())
        private set

    fun openErrorDialog() {
        viewStates = viewStates.copy(errorFlag = true)
    }

    fun closeErrorDialog() {
        viewStates = viewStates.copy(errorFlag = false)
    }
}

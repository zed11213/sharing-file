package jp.co.jsbank.mb.bankingapp.logic.login.mbsu

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.system.MyApp
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mbsu.mbsu0305.MBSU0305ErrorInformation
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mbsu.mbsu0305.MBSU0305PageState
import jp.co.jsbank.mb.bankingapp.utils.*
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.containsInvalidCharacter
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isFullKanaNotSpace
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isHalfEnglishNum
import javax.inject.Inject

/**
 * MBSU0305ロジック
 */
@HiltViewModel
class MBSU0305Logic @Inject constructor() : ViewModel() {

    // ログインステータス
    var viewStates by mutableStateOf(MBSU0305PageState())
        private set

    /**
     * 次への処理
     */
    fun doCheck() {

        // エラー情報初期化
        val errorBean = MBSU0305ErrorInformation()
        viewStates = viewStates.copy(isError = false)
        viewStates = viewStates.copy(errorBean = errorBean)
        viewStates = viewStates.copy(errMsgList = listOf())

        // お名前の姓の入力チェック
        if (viewStates.requestBean.firstName.isBlank()) {
            errorBean.firstNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002014V),
                        MyApp.CONTEXT.getString(R.string.mbsu0305_page_label_firstName)
                    )
                )
            )
        }

        if (containsInvalidCharacter(viewStates.requestBean.firstName)) {
            errorBean.firstNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002015V)
                )
            )
        }

        // お名前の名の入力チェック
        if (viewStates.requestBean.secondName.isBlank()) {
            errorBean.secondNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002014V),
                        MyApp.CONTEXT.getString(R.string.mbsu0305_page_label_secondName)
                    )
                )
            )
        }

        if (containsInvalidCharacter(viewStates.requestBean.secondName)) {
            errorBean.secondNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002015V)
                )
            )
        }

        // お名前（フリガナ）のセイの入力チェック
        if (viewStates.requestBean.kanaFirstName.isBlank()) {
            errorBean.kanaFirstNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002014V),
                        MyApp.CONTEXT.getString(R.string.mbsu0305_page_label_friganaFirstName)
                    )
                )
            )
        } else if (!viewStates.requestBean.kanaFirstName.isFullKanaNotSpace()) {
            // セイ（半角カナ）の全角カナチェック
            errorBean.kanaFirstNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002008V),
                        MyApp.CONTEXT.getString(R.string.mbsu0305_page_label_friganaFirstName)
                    )
                )
            )
        }
        // お名前（フリガナ）のメイの入力チェック
        if (viewStates.requestBean.kanaSecondName.isBlank()) {
            errorBean.kanaSecondNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002014V),
                        MyApp.CONTEXT.getString(R.string.mbsu0305_page_label_friganaSecondName)
                    )
                )
            )
        } else if (!viewStates.requestBean.kanaSecondName.isFullKanaNotSpace()) {
            // メイ（半角カナ）の全角カナチェック
            errorBean.kanaSecondNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002008V),
                        MyApp.CONTEXT.getString(R.string.mbsu0305_page_label_friganaSecondName)
                    )
                )
            )
        }
        // 利用者認証キーの桁数チェック
        if (viewStates.requestBean.userKey.isEmpty()) {
            errorBean.userKeyErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002014V),
                        MyApp.CONTEXT.getString(R.string.mbsu0305_page_label_authentication_key)
                    )
                )
            )
        } else if (!viewStates.requestBean.userKey.isHalfEnglishNum()) {
            // 利用者認証キーの半角英数字チェック
            errorBean.userKeyErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002027V),
                        MyApp.CONTEXT.getString(R.string.mbsu0305_page_label_authentication_key)
                    )
                )
            )
        } else if (!EditCheckUtil.lengthCheck(viewStates.requestBean.userKey, 16)) {
            // 利用者認証キーの桁数チェック
            errorBean.userKeyErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002026V)
                )
            )
        }

        if (!viewStates.isError) {

            // 全角カナを半角カナに変換する
            val bean = viewStates.requestBean
            bean.kanaFirstName = HalfToFullUtils.fullToHalfCharName(bean.kanaFirstName)
            bean.kanaSecondName = HalfToFullUtils.fullToHalfCharName(bean.kanaSecondName)
            viewStates = viewStates.copy(requestBean = bean)

            RouteUtil.navTo(
                RouteName.MBSU0306Page + "/${viewStates.requestBean.toJson()}",
            )
        }
    }
}

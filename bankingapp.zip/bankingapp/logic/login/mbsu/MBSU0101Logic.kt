package jp.co.jsbank.mb.bankingapp.logic.login.mbsu

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mbsu.mbsu0101.MBSU0101PageState

/**
 * MBSU0101ロジック
 */
@HiltViewModel
class MBSU0101Logic @Inject constructor() : ViewModel() {

    // MBSU0101ステータス
    var viewStates by mutableStateOf(MBSU0101PageState())
        private set

    /**
     * キャッシュカードダイアログ
     */
    fun openCashCardDialog() {
        viewStates = viewStates.copy(cashCardDialogFlag = true)
    }

    /**
     * キャッシュカードダイアログクルーズ
     */
    fun closeCashCardDialog() {
        viewStates = viewStates.copy(cashCardDialogFlag = false)
    }

    /**
     * 利用登録のおすすめダイアログ
     */
    fun openRecommendedRegistrationDialog() {
        viewStates = viewStates.copy(recommendedRegistrationDialogFlag = true)
    }

    /**
     * 利用登録のおすすめダイアログクルーズ
     */
    fun closeRecommendedRegistrationDialog() {
        viewStates = viewStates.copy(recommendedRegistrationDialogFlag = false)
    }
}

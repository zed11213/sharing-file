package jp.co.jsbank.mb.bankingapp.logic.login.mbsu

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.gson.Gson
import dagger.hilt.android.lifecycle.HiltViewModel
import io.realm.Realm
import jp.co.jsbank.mb.bankingapp.bean.common.CifBranchPairListBean
import java.util.*
import javax.inject.Inject
import jp.co.jsbank.mb.bankingapp.bean.common.DepartmentBean
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.repositories.db.common.create
import jp.co.jsbank.mb.bankingapp.repositories.db.common.deleteAll
import jp.co.jsbank.mb.bankingapp.repositories.db.common.findAll
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.EPassBookAB0112
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.system.MyApp
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mbsu.mbsu0309.MBSU0309PageState
import jp.co.jsbank.mb.bankingapp.utils.*
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/**
 * MBSU0309ロジック
 */
@HiltViewModel
class MBSU0309Logic @Inject constructor(
    private var webService: RestService,
) : ViewModel() {

    /**
     * MBSU0309ステータス
     */
    var viewStates by mutableStateOf(MBSU0309PageState())
        private set

    /**
     * ロカールDB
     */
    private var dbService: Realm = MyApp.INSTANCE

    var cifBranchPairListBean: CifBranchPairListBean? = null

    /**
     * 初期化
     */
    init {
        cifBranchPairListBean =
            MainActivity.NAVCTRL?.currentBackStackEntry?.arguments?.get(ConstUtil.INPUT_DATA).toString()
                .fromJson<CifBranchPairListBean>()

        val deptInfo = dbService.findAll(EPassBookAB0112::class.java)
        if (deptInfo.isNotEmpty()) {
            val departmentJsonList = deptInfo[0]?.deptList
            val departmentList = mutableListOf<DepartmentBean>()
            if (departmentJsonList.isNullOrEmpty()) {
                viewModelScope.launch {
                    getDeptList()
                }
            } else {
                departmentJsonList.fromJson<List<Map<String, String>>>()?.forEach { item ->

                    if (cifBranchPairListBean!=null && cifBranchPairListBean!!.cifBranchPairList.isNotEmpty()){
                        if(cifBranchPairListBean!!.cifBranchPairList.any{ it.branchCode == item["branchNumber"] }) {
                            departmentList.add(
                                DepartmentBean(
                                    branchNumber = item["branchNumber"] ?: "",
                                    branchKanjiName = item["branchKanjiName"] ?: ""
                                )
                            )
                        }
                    } else {
                        departmentList.add(
                            DepartmentBean(
                                branchNumber = item["branchNumber"] ?: "",
                                branchKanjiName = item["branchKanjiName"] ?: ""
                            )
                        )
                    }
                }
                viewStates = viewStates.copy(departmentList = departmentList)
            }
        } else {
            viewModelScope.launch {
                getDeptList()
            }
        }
        val departmentJsonList = MainActivity.NAVCTRL?.currentBackStackEntry?.arguments?.get(ConstUtil.DATA).toString()
        val departmentList = mutableListOf<DepartmentBean>()
        departmentJsonList.fromJson<List<Map<String, String>>>()?.forEach { item ->
            departmentList.add(
                DepartmentBean(
                    branchNumber = item["branchNumber"] ?: "",
                    branchKanjiName = item["branchKanjiName"] ?: ""
                )
            )
        }
    }

    /**
     * 店舗リストを取得する
     */
    private suspend fun getDeptList() {
        // 画面IDとイベントID設定
        PreferenceUtil.setScreenIDAndEventID("MBSU0309", "E01")
        viewModelScope.async {
            flow {
                ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST)
                emit(webService.AB0112())
            }.map {
                dbService.deleteAll(EPassBookAB0112::class.java)
                val ab0112 = EPassBookAB0112()
                ab0112.id = UUID.randomUUID().toString()
                ab0112.deptList = Gson().toJson(it.resultDto)
                dbService.create(ab0112)
                if (cifBranchPairListBean == null || cifBranchPairListBean!!.cifBranchPairList.isEmpty()) {
                    viewStates = viewStates.copy(departmentList = it.resultDto!!.toMutableList())
                } else {
                    val list = it.resultDto!!.toMutableList()
                    list.removeIf { item ->
                        !cifBranchPairListBean!!.cifBranchPairList.any { cifBranchPair -> cifBranchPair.branchCode == item.branchNumber }
                    }
                    viewStates = viewStates.copy(departmentList = list)
                }
            }.catch {
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }.await()
    }
}

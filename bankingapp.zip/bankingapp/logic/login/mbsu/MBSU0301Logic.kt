package jp.co.jsbank.mb.bankingapp.logic.login.mbsu

import androidx.compose.foundation.ScrollState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.system.MyApp.Companion.CONTEXT
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mbsu.mbsu0301.MBSU0301ErrorInformation
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mbsu.mbsu0301.MBSU0301PageState
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isHalfNum
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.name_kana
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.lengthCheck
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.numberCheck
import jp.co.jsbank.mb.bankingapp.utils.HalfToFullUtils.bigToSmallChar
import jp.co.jsbank.mb.bankingapp.utils.HalfToFullUtils.fullToHalfCharName
import jp.co.jsbank.mb.bankingapp.utils.MessageReplaceUtils
import jp.co.jsbank.mb.bankingapp.utils.RouteUtil
import jp.co.jsbank.mb.bankingapp.utils.toJson
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * MBSU0301ロジック
 */
@HiltViewModel
class MBSU0301Logic @Inject constructor() : ViewModel() {

    // ログインステータス
    var viewStates by mutableStateOf(MBSU0301PageState())
        private set

    /**
     * 郵便番号ヘルプダイアログ表示切替
     */
    fun postDialogFlag() {
        viewStates = viewStates.copy(showPostDialogFlag = !viewStates.showPostDialogFlag)
    }

    /**
     * 口座番号ヘルプダイアログ表示切替
     */
    fun portDialogFlag() {
        viewStates = viewStates.copy(showPortDialogFlag = !viewStates.showPortDialogFlag)
    }

    // エラーチェック
    fun doNext(coroutineScope: CoroutineScope, scrollState: ScrollState) {
        // エラー情報初期化
        val errorBean = MBSU0301ErrorInformation()
        viewStates = viewStates.copy(isError = false)
        viewStates = viewStates.copy(errorMessageList = listOf())
        viewStates = viewStates.copy(errorBean = errorBean)

        // 姓が空白場合
        if (viewStates.requestBean.firstName.isBlank()) {
            errorBean.firstNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        CONTEXT.getString(R.string.MSG_ID_MB002014V),
                        CONTEXT.getString(R.string.mbsu0301_page_label_firstName)
                    )
                )
            )
        }

        // 姓が半角カナ以外の場合
        if (!viewStates.requestBean.firstName.name_kana()) {
            errorBean.firstNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        CONTEXT.getString(R.string.MSG_ID_MB002009V),
                        CONTEXT.getString(R.string.mbsu0301_page_label_firstName)
                    )
                )
            )
        }

        // メイが空白場合
        if (viewStates.requestBean.secondName.isBlank()) {
            errorBean.secondNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        CONTEXT.getString(R.string.MSG_ID_MB002014V),
                        CONTEXT.getString(R.string.mbsu0301_page_label_secondName)
                    )
                )
            )
        }

        // メイが半角カナ以外の場合
        if (!viewStates.requestBean.secondName.name_kana()) {
            errorBean.secondNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        CONTEXT.getString(R.string.MSG_ID_MB002009V),
                        CONTEXT.getString(R.string.mbsu0301_page_label_secondName)
                    )
                )
            )
        }

        // 年が空白場合
        if (viewStates.requestBean.year.isBlank()) {
            errorBean.yearErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        CONTEXT.getString(R.string.MSG_ID_MB002014V),
                        CONTEXT.getString(R.string.common_message_replace_label_year)
                    )
                )
            )
        }

        // 月が空白場合
        if (viewStates.requestBean.month.isBlank()) {
            errorBean.monthErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        CONTEXT.getString(R.string.MSG_ID_MB002014V),
                        CONTEXT.getString(R.string.common_message_replace_label_month)
                    )
                )
            )
        }

        // 日が空白場合
        if (viewStates.requestBean.day.isBlank()) {
            errorBean.dayErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        CONTEXT.getString(R.string.MSG_ID_MB002014V),
                        CONTEXT.getString(R.string.common_message_replace_label_day)
                    )
                )
            )
        }

        // 2025/01/28 共同化ため 名前の桁数変更  start
        val firstNameSecondName = viewStates.requestBean.firstName +" "+ viewStates.requestBean.secondName
        if (firstNameSecondName.length > 20) {
            // セイ＋ブランク＋メイで20桁を超える場合
            errorBean.firstNameSecondNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        CONTEXT.getString(R.string.MSG_ID_MB002033V),
                        CONTEXT.getString(R.string.mbop0601_page_label_kana_firstName_secondName)
                    )
                )
            )
        }
        // 2025/01/28 共同化ため 名前の桁数変更  end

        // 生年月日チェック
        if (viewStates.requestBean.year.isNotBlank() &&
            viewStates.requestBean.month.isNotBlank() &&
            viewStates.requestBean.day.isNotBlank()
        ) {
            if (!EditCheckUtil.isDayCheck(
                    viewStates.requestBean.year,
                    viewStates.requestBean.month,
                    viewStates.requestBean.day
                )
            ) {
                errorBean.yearErrorFlag = true
                errorBean.monthErrorFlag = true
                errorBean.dayErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            CONTEXT.getString(R.string.MSG_ID_MB002007V),
                            CONTEXT.getString(R.string.mbsu0301_page_label_birthday)
                        )
                    )
                )
            }
            // 未来日チェック
            else if (EditCheckUtil.isFutureDays(
                    viewStates.requestBean.year + viewStates.requestBean.month + viewStates.requestBean.day
                )
            ) {
                errorBean.yearErrorFlag = true
                errorBean.monthErrorFlag = true
                errorBean.dayErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            CONTEXT.getString(R.string.MSG_ID_MB002007V),
                            CONTEXT.getString(R.string.mbsu0301_page_label_birthday)
                        )
                    )
                )
            }
            // 1900年生まれ以降チェック
            else if (!EditCheckUtil.isYearCheck(viewStates.requestBean.year)) {
                errorBean.yearErrorFlag = true
                errorBean.monthErrorFlag = true
                errorBean.dayErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            CONTEXT.getString(R.string.MSG_ID_MB002007V),
                            CONTEXT.getString(R.string.mbsu0301_page_label_birthday)
                        )
                    )
                )
            }
        }

        // 郵便番号の入力チェック
        if (viewStates.requestBean.postCode.isBlank()) {
            errorBean.postCodeErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        CONTEXT.getString(R.string.MSG_ID_MB002014V),
                        CONTEXT.getString(R.string.mbsu0301_page_label_postCode)
                    )
                )
            )
        } else if (!viewStates.requestBean.postCode.isHalfNum()) {
            // 郵便番号の半角数字チェック
            errorBean.postCodeErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        CONTEXT.getString(R.string.MSG_ID_MB002012V),
                        CONTEXT.getString(R.string.mbsu0301_page_label_postCode)
                    )
                )
            )
        } else if (!lengthCheck(viewStates.requestBean.postCode, 7)) {
            // 郵便番号の桁数チェック
            errorBean.postCodeErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    CONTEXT.getString(R.string.MSG_ID_MB002003V)
                )
            )
        }

        // 店舗名が空白場合
        if (viewStates.requestBean.shop.isEmpty()) {
            errorBean.shopErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        CONTEXT.getString(R.string.MSG_ID_MB002022V),
                        CONTEXT.getString(R.string.mbsu0301_page_label_shop_name)
                    )
                )
            )
        }

        // 口座番号が空白場合
        if (!numberCheck(viewStates.requestBean.accountNumber) ||
            !lengthCheck(viewStates.requestBean.accountNumber, 7)
        ) {
            errorBean.accountNumberErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    CONTEXT.getString(R.string.MSG_ID_MB002037V)
                )
            )
        }

        // キャッシュカード暗証番号が空白場合
        if (!numberCheck(viewStates.requestBean.cashCardPassword) ||
            !lengthCheck(viewStates.requestBean.cashCardPassword, 4)
        ) {
            errorBean.cashCardPasswordErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    CONTEXT.getString(R.string.MSG_ID_MB002005V)
                )
            )
        }

        if (!viewStates.isError) {
            // 全角カナを半角カナに変換する
            val bean = viewStates.requestBean
            bean.firstName = bigToSmallChar(fullToHalfCharName(bean.firstName))
            bean.secondName = bigToSmallChar(fullToHalfCharName(bean.secondName))
            viewStates = viewStates.copy(requestBean = bean)

            // MBSU0302　情報入力確認
            RouteUtil.navTo(
                RouteName.MBSU0302Page + "/${viewStates.requestBean.toJson()}",
            )
        } else {
            coroutineScope.launch {
                scrollState.animateScrollTo(0)
            }
        }
    }
}

package jp.co.jsbank.mb.bankingapp.logic.login.mbsu

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mbsu.mbsu2001.MBSU2001PageState

/**
 * MBSU2001ロジック
 */
@HiltViewModel
class MBSU2001Logic @Inject constructor(
    private var webService: RestService,
) : ViewModel() {

    // ログインステータス
    var viewStates by mutableStateOf(MBSU2001PageState())
        private set

    fun openErrorDialog() {
        viewStates = viewStates.copy(errorFlag = true)
    }

    fun closeErrorDialog() {
        viewStates = viewStates.copy(errorFlag = false)
    }

    /**
     * 引継ぎコード照会APIを呼び出す(AB0110)
     */
    fun successionCodeInquiry() {}
}

package jp.co.jsbank.mb.bankingapp.logic.login.mbsu

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mbsu.mbsu0105.MBSU0105PageState

/**
 * MBSU0105ロジック
 */
@HiltViewModel
class MBSU0105Logic @Inject constructor() : ViewModel() {

    // MBSU0105ステータス
    var viewStates by mutableStateOf(MBSU0105PageState())
        private set
}

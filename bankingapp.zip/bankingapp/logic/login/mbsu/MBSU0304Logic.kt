package jp.co.jsbank.mb.bankingapp.logic.login.mbsu

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import jp.co.jsbank.mb.bankingapp.bean.common.JagPeerBean
import jp.co.jsbank.mb.bankingapp.bean.login.mbsu.mbsu0302.MBSU0302RequestBean
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.system.master.UserType
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mbsu.mbsu0303.MBSU0303FormInfo
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mbsu.mbsu0304.MBSU0304PageState
import jp.co.jsbank.mb.bankingapp.utils.*
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * MBSU0304ロジック
 */
@HiltViewModel
class MBSU0304Logic @Inject constructor(
    private var webService: RestService,
) : ViewModel() {

    /**
     * ログインステータス
     */
    var viewStates by mutableStateOf(MBSU0304PageState())
        private set

    /**
     * 初期化
     */
    init {
        val dataBean =
            MainActivity.NAVCTRL?.currentBackStackEntry?.arguments?.get(ConstUtil.DATA).toString()
                .fromJson<MBSU0303FormInfo>()!!
        viewStates = viewStates.copy(requestBean = dataBean)
    }

    /**
     * 口座番号表示フラグの切替
     */
    fun switchAccountNumber() {
        viewStates = viewStates.copy(accountNumberShowFlag = !viewStates.accountNumberShowFlag)
    }

    /**
     * 暗証番号表示フラグの切替
     */
    fun switchCashCardPasswordShowFlag() {
        viewStates = viewStates.copy(cashCardPasswordShowFlag = !viewStates.cashCardPasswordShowFlag)
    }

    /**
     * 本人照合
     */
    suspend fun hostVerification() {
        viewStates = viewStates.copy(errorMessage = "")
        // 画面IDとイベントID設定
        PreferenceUtil.setScreenIDAndEventID("MBSU0304", "E05")
        val param = MBSU0302RequestBean()
        // 人格区分
        param.personType =
            PreferenceUtil.getPreferenceStringValue(ConstUtil.PERSONALITY_FLAG).toString()
        // 利用者区分
        param.userType = UserType.BUSINESS_REPRESENTATIVE.code
        // 店番
        param.branchCode = viewStates.requestBean.shop.split(" ")[0]
        // 口座番号
        param.accountNumber = viewStates.requestBean.accountNumber
        // カナ氏名（姓）
        param.customerLastName = viewStates.requestBean.kanaName
        // 生年月日
        param.birthDay =
            dateAddHyphen(
                viewStates.requestBean.birthdayYear,
                viewStates.requestBean.birthdayMonth,
                viewStates.requestBean.birthdayDay
            )
        // 郵便番号
        param.zipCode = viewStates.requestBean.postCode
        // 暗証番号
        param.ccPinCode = viewStates.requestBean.cashCardPassword
        // 所属
        param.divisionCode = ""
        // 認証キー
        param.authCode = PreferenceUtil.getPreferenceStringValue(ConstUtil.VERIFY_TRX_KEY).toString()
        viewModelScope.launch {
            flow {
                ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, param.toJson())
                emit(webService.AB0103())
            }.map {
                KeyStoreUtil().jagInfoSave(
                    JagPeerBean(
                        customerId = it.resultDto!!.customerId,
                        userId = it.resultDto!!.userId
                    )
                )
                // 依頼番号
                PreferenceUtil.setPreferenceStringValue(ConstUtil.REQUEST_NO, it.resultDto!!.requestNo)
                // CIF番号
                PreferenceUtil.setPreferenceStringValue(ConstUtil.CIF_NO, it.resultDto!!.cifNo)

                // 2025/01/24 共同化ため　1:本人カードは実際は未発行の注意コード有り場合に　start
                if (ConstUtil.CARD_DUMMY_ISSUE_CODE == it.resultDto!!.cardDummyIssue) {
                    openCautionIndicationCodeDialog()
                } else {
                    // MBSU0401　パスワード設定
                    RouteUtil.navTo(
                        RouteName.MBSU0401Page,
                    )
                }
            }.catch {
                viewStates = viewStates.copy(errorFlag = true)
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }.join()
    }

    /**
     * 注意コード誘導メッセージ
     */
    fun openCautionIndicationCodeDialog() {
        viewStates = viewStates.copy(showDialogFlag = true)
    }

    /**
     * 注意コード誘導メッセージダイアログクルーズ
     */
    fun closeAccountOpeningDialogFlag() {
        viewStates = viewStates.copy(showDialogFlag = false)
    }
}

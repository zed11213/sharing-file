package jp.co.jsbank.mb.bankingapp.logic.login.mbsu

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.bean.common.JagPeerBean
import jp.co.jsbank.mb.bankingapp.bean.login.mbsu.mbsu0602.MBSU0602RequestBean
import jp.co.jsbank.mb.bankingapp.bean.splash.mbco6201.MBCO6201RequestBean
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.repositories.api.request.gateway.GatewayRestService
import jp.co.jsbank.mb.bankingapp.system.Config
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.system.MyApp
import jp.co.jsbank.mb.bankingapp.system.master.JagApiServiceCode
import jp.co.jsbank.mb.bankingapp.system.master.PersonalityFlag
import jp.co.jsbank.mb.bankingapp.system.master.UpdateType
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mbsu.mbsu0602.MBSU0602PageState
import jp.co.jsbank.mb.bankingapp.utils.*
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.AUTHENTICATION_RESULT_OK
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.DATE_FORMAT_YYYY_MM_DD
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.MBSU0602_CALL_BACK_COUNT
import jp.co.jsbank.mb.bankingapp.utils.RouteUtil.back
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import javax.inject.Inject

/**
 * MBSU0401ロジック
 */
@HiltViewModel
class MBSU0602Logic @Inject constructor(
    private var webService: RestService,
    private var gatewayWebService: GatewayRestService
) : ViewModel() {

    /**
     * MBSU0602ステータス
     */
    var viewStates by mutableStateOf(MBSU0602PageState())
        private set

    private fun openDialog() {
        viewStates = viewStates.copy(flag = true)
    }

    fun closeDialog() {
        viewStates = viewStates.copy(flag = false)
    }

    private fun openAchievedDialog() {
        viewStates = viewStates.copy(achievedFlag = true)
    }

    fun closeAchievedDialog() {
        viewStates = viewStates.copy(achievedFlag = false)
    }

    init {
        // 遷移元画面渡すパラメータ取得
        val arguments = MainActivity.NAVCTRL?.currentBackStackEntry?.arguments?.get(ConstUtil.DATA)
        viewStates.phoneNumber = arguments.toString()
    }

    /**
     * 電話認証
     */
    private fun certificationCodeAuthentication() {
        viewStates = viewStates.copy(errorMessage = "")
        // 画面IDとイベントID設定
        PreferenceUtil.setScreenIDAndEventID("MBSU0602", "E03")
        val requestBean = MBSU0602RequestBean()
        // 受付番号　TODO 一時対応「YYMMDD+4桁採番」
        requestBean.receiptNumber = "2208050001"
        // 電話番号
        requestBean.phoneNumber = viewStates.phoneNumber
        // IVROTP
        requestBean.ivrOtp = viewStates.phoneCode
        // 依頼番号
        requestBean.requestNo = PreferenceUtil.getPreferenceStringValue(ConstUtil.REQUEST_NO).toString()
        // 人格区分
        requestBean.personType = if (Config.isRetail()) PersonalityFlag.INDIVIDUAL_INITIAL_LOGIN.code
        else PreferenceUtil.getPreferenceStringValue(ConstUtil.PERSONALITY_FLAG).toString()

        // 更新パターン
        requestBean.updateType = UpdateType.UPDATE_TYPE_115.code
        viewModelScope.launch {
            LoadingUtil.setLoadingValue(value = true, type = true)
            // IVR認証
            AB0106(requestBean)
            LoadingUtil.setLoadingValue(value = false)
        }
    }

    // IVR認証
    private suspend fun AB0106(requestBean: MBSU0602RequestBean) {
        viewModelScope.async {
            flow {
                ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, requestBean.toJson())
                emit(webService.AB0106())
            }.map {
                // 認証結果
                if (it.resultDto!!.authenticationResult == AUTHENTICATION_RESULT_OK) {
                    // Jag情報ローカルに保存する
                    KeyStoreUtil().jagInfoSave(
                        JagPeerBean(customerId = it.resultDto!!.customerId, userId = it.resultDto!!.userId)
                    )
                    // AZ0911 認可コード取得
                    az0911()
                }
            }.catch {
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }.await()
    }

    /**
     * AZ0911 認可コード取得
     */
    private suspend fun az0911() {
        viewModelScope.async {
            val param = MBCO6201RequestBean()
            val list : Array<String> = arrayOf(
                ConstUtil.JAG_RES_TRXID,
                ConstUtil.DEVICE_ID
            )
            val jagPeerBean = KeyStoreUtil().getJagInfo(list)

            // JAG PROFILE JWT
            val jagProfile = JWTUtil().createJWT()
            param.jagProfile = jagProfile
            // デバイスID
            param.jagDeviceId = jagPeerBean.deviceId
            // アプリケーションID
            param.jagApplicationId = Config.getAppId()
            // TRX種別
            param.jagTrxType = ConstUtil.JAG_TRX_TYPE_NRM
            // トランザクションID
            param.jagTrxId = jagPeerBean.jagTrxId
            // API サービス名称
            PreferenceUtil.setPreferenceStringValue(ConstUtil.API_SERVICE_NAME, JagApiServiceCode.AZ0911.value)
            flow {
                emit(gatewayWebService.AZ0911(param))
            }.map {
                // 活性化フラグをtrueに設定する
                PreferenceUtil.setPreferenceStringValue(
                    ConstUtil.ACTIVITY_FLAG,
                    ConstUtil.ACTIVITY_FLAG_ACCESS_NO_LOGIN
                )
                // Jag情報ローカルに保存する
                KeyStoreUtil().jagInfoSave(
                    JagPeerBean(
                        jagTrxId = it.jagTrxId,
                        jagAccessToken = it.jagAccessToken,
                        jagRefreshToken = it.jagRefreshToken
                    )
                )
                // ダイアログ表示
                openDialog()
            }.catch {
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }.await()
    }

    // エラーチェック
    fun phoneCodeCheck() {

        // エラー情報初期化
        viewStates = viewStates.copy(errorMessageList = listOf())

        // 認証番号が空白場合
        if (!EditCheckUtil.numberCheck(viewStates.phoneCode) ||
            !EditCheckUtil.lengthCheck(viewStates.phoneCode, 4)
        ) {
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002014V),
                        MyApp.CONTEXT.getString(R.string.mbsu0602_page_label_confirmation_no)
                    )
                )
            )
        }

        if (viewStates.errorMessageList.isEmpty()) {
            certificationCodeAuthentication()
        }
    }

    /**
     * 暗証番号の入力イベント
     */
    fun onPhoneCodeChange(value: String) {
        viewStates = viewStates.copy(phoneCode = value)
    }

    /**
     * かけ直す
     */
    fun callBack() {
        val callBackCount = PreferenceUtil.getPreferenceIntValue(
            MBSU0602_CALL_BACK_COUNT + LocalDate.now().format(
                DateTimeFormatter.ofPattern(DATE_FORMAT_YYYY_MM_DD)
            )
        )
        if (callBackCount >= 10) {
            // 1日の上限に達した場合
            openAchievedDialog()
        } else {
            PreferenceUtil.setPreferenceIntValue(
                MBSU0602_CALL_BACK_COUNT + LocalDate.now().format(
                    DateTimeFormatter.ofPattern(DATE_FORMAT_YYYY_MM_DD)
                ),
                callBackCount + 1
            )
            MainActivity.NAVCTRL?.back()
        }
    }
}

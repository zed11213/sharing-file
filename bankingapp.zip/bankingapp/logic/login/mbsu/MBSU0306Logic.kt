package jp.co.jsbank.mb.bankingapp.logic.login.mbsu

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import jp.co.jsbank.mb.bankingapp.bean.common.JagPeerBean
import jp.co.jsbank.mb.bankingapp.bean.login.mbsu.mbsu0302.MBSU0302RequestBean
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.system.master.UserType
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mbsu.mbsu0305.MBSU0305FormInfo
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mbsu.mbsu0306.MBSU0306PageState
import jp.co.jsbank.mb.bankingapp.utils.*
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * MBSU0306ロジック
 */
@HiltViewModel
class MBSU0306Logic @Inject constructor(
    private var webService: RestService,
) : ViewModel() {

    // ログインステータス
    var viewStates by mutableStateOf(MBSU0306PageState())
        private set

    /**
     * 初期化
     */
    init {
        val dataBean =
            MainActivity.NAVCTRL?.currentBackStackEntry?.arguments?.get(ConstUtil.DATA).toString()
                .fromJson<MBSU0305FormInfo>()!!
        viewStates = viewStates.copy(requestBean = dataBean)
    }

    /**
     * 利用者認証キー表示フラグの切替
     */
    fun switchUserKey() {
        viewStates = viewStates.copy(userKeyShowFlag = !viewStates.userKeyShowFlag)
    }

    /**
     * 本人照合
     */
    fun hostVerification() {
        viewStates = viewStates.copy(errorMessage = "")
        // 画面IDとイベントID設定
        PreferenceUtil.setScreenIDAndEventID("MBSU0306", "E05")
        val param = MBSU0302RequestBean()
        // 人格区分
        param.personType = ""
        // 利用者区分
        param.userType = UserType.BUSINESS_USER.code
        // 店番
        param.branchCode = ""
        // 口座番号
        param.accountNumber = ""
        // 漢字氏名（姓）
        param.customerKanjiLastName = viewStates.requestBean.firstName
        // 漢字氏名（名）
        param.customerKanjiFirstName = viewStates.requestBean.secondName
        // カナ氏名（姓）
        param.customerLastName = viewStates.requestBean.kanaFirstName
        // カナ氏名（名）
        param.customerFirstName = viewStates.requestBean.kanaSecondName
        // 生年月日
        param.birthDay = ""
        // 郵便番号
        param.zipCode = ""
        // 暗証番号
        param.ccPinCode = ""
        // 所属
        param.divisionCode = viewStates.requestBean.userBelong
        // 認証キー
        param.authCode = viewStates.requestBean.userKey
        viewModelScope.launch {
            flow {
                ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, param.toJson())
                emit(webService.AB0103())
            }.map {
                // Jag情報ローカルに保存する
                KeyStoreUtil().jagInfoSave(
                    JagPeerBean(
                        customerId = it.resultDto!!.customerId,
                        userId = it.resultDto!!.userId
                    )
                )
                // 依頼番号
                PreferenceUtil.setPreferenceStringValue(ConstUtil.REQUEST_NO, it.resultDto!!.requestNo)
                // CIF番号
                PreferenceUtil.setPreferenceStringValue(ConstUtil.CIF_NO, it.resultDto!!.cifNo)

                // MBSU0401　パスワード設定
                RouteUtil.navTo(
                    RouteName.MBSU0401Page,
                )
            }.catch {
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }
    }
}

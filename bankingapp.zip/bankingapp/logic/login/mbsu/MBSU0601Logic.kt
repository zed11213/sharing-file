package jp.co.jsbank.mb.bankingapp.logic.login.mbsu

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import jp.co.jsbank.mb.bankingapp.bean.common.JagPeerBean
import jp.co.jsbank.mb.bankingapp.bean.login.mbsu.mbsu0601.MBSU0601RequestBean
import jp.co.jsbank.mb.bankingapp.bean.splash.mbco6201.MBCO6201RequestBean
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.repositories.api.request.gateway.GatewayRestService
import jp.co.jsbank.mb.bankingapp.system.Config
import jp.co.jsbank.mb.bankingapp.system.master.JagApiServiceCode
import jp.co.jsbank.mb.bankingapp.system.master.PersonalityFlag
import jp.co.jsbank.mb.bankingapp.system.master.UpdateType
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mbsu.mbsu0601.MBSU0601PageState
import jp.co.jsbank.mb.bankingapp.utils.*
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.IVR_SKIP_FAIL
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * MBSU0601ロジック
 */
@HiltViewModel
class MBSU0601Logic @Inject constructor(
    private var webService: RestService,
    private var gatewayWebService: GatewayRestService
) : ViewModel() {

    /**
     * ログインステータス
     */
    var viewStates by mutableStateOf(MBSU0601PageState())
        private set

    /**
     * 電話番号選択
     */
    fun onPhonePatternChange(phonePattern: Int) {
        viewStates = viewStates.copy(phonePattern = phonePattern)
    }

    /**
     * 電話認証
     */
    fun telephoneAuthentication() {
        // 画面IDとイベントID設定
        PreferenceUtil.setScreenIDAndEventID("MBSU0601", "E02")
        val requestBean = MBSU0601RequestBean()
        // 人格区分
        requestBean.personType = if (Config.isRetail()) PersonalityFlag.INDIVIDUAL_INITIAL_LOGIN.code
        else PreferenceUtil.getPreferenceStringValue(ConstUtil.PERSONALITY_FLAG).toString()
        // 電話番号
        requestBean.phoneNumber = viewStates.phoneList[viewStates.phonePattern]
        // 更新パターン
        requestBean.updateType = UpdateType.UPDATE_TYPE_115.code
        // CIF番号
        requestBean.cifNumber = PreferenceUtil.getPreferenceStringValue(ConstUtil.CIF_NO).toString()
        // 店番
        requestBean.branchNumber = PreferenceUtil.getPreferenceStringValue(ConstUtil.BRANCH_NO).toString()
        // 依頼番号
        requestBean.requestNo = PreferenceUtil.getPreferenceStringValue(ConstUtil.REQUEST_NO).toString()
        viewModelScope.launch {
            flow {
                ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, requestBean.toJson())
                emit(webService.AB0105())
            }.map {
                if (it.resultDto!!.ivrSkipFlag == IVR_SKIP_FAIL) {
                    // IVRスキップフラグがfalse場合
                    // Jag情報ローカルに保存する
                    KeyStoreUtil().jagInfoSave(
                        JagPeerBean(
                            customerId = it.resultDto!!.customerIdToken,
                            userId = it.resultDto!!.userIdToken
                        )
                    )
                    // ログイン確認画面
                    az0911()
                } else {
                    // MBSU0602　認証番号入力
                    RouteUtil.navTo(
                        RouteName.MBSU0602Page,
                        requestBean.phoneNumber
                    )
                }
            }.catch {
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }
    }

    /**
     * AZ0911 認可コード取得
     */
    private suspend fun az0911() {
        viewModelScope.async {
            val param = MBCO6201RequestBean()

            // JAG PROFILE JWTをローカルに保存する
            val jagProfile = JWTUtil().createJWT()
            val list : Array<String> = arrayOf(
                ConstUtil.JAG_RES_TRXID,
                ConstUtil.DEVICE_ID
            )
            val jagPeerBean = KeyStoreUtil().getJagInfo(list)

            // JAG PROFILE JWT
            param.jagProfile = jagProfile
            // デバイスID
            param.jagDeviceId = jagPeerBean.deviceId
            // アプリケーションID
            param.jagApplicationId = Config.getAppId()
            // TRX種別
            param.jagTrxType = ConstUtil.JAG_TRX_TYPE_NRM
            // トランザクションID
            param.jagTrxId = jagPeerBean.jagTrxId
            // API サービス名称
            PreferenceUtil.setPreferenceStringValue(ConstUtil.API_SERVICE_NAME, JagApiServiceCode.AZ0911.value)
            flow {
                emit(gatewayWebService.AZ0911(param))
            }.map {
                // 活性化フラグをtrueに設定する
                PreferenceUtil.setPreferenceStringValue(
                    ConstUtil.ACTIVITY_FLAG,
                    ConstUtil.ACTIVITY_FLAG_ACCESS_NO_LOGIN
                )
                // Jag情報ローカルに保存する
                KeyStoreUtil().jagInfoSave(
                    JagPeerBean(
                        jagTrxId = it.jagTrxId,
                        jagAccessToken = it.jagAccessToken,
                        jagRefreshToken = it.jagRefreshToken
                    )
                )
                // 確認ダイアログ画面が表示すること
                openDialog()
            }.catch {
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }.await()
    }

    private fun openDialog() {
        viewStates = viewStates.copy(flag = true)
    }

    fun closeDialog() {
        viewStates = viewStates.copy(flag = false)
    }
}

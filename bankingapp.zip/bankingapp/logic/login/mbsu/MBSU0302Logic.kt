package jp.co.jsbank.mb.bankingapp.logic.login.mbsu

import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import jp.co.jsbank.mb.bankingapp.bean.common.JagPeerBean
import jp.co.jsbank.mb.bankingapp.bean.login.mbsu.mbsu0302.MBSU0302RequestBean
import jp.co.jsbank.mb.bankingapp.logic.login.mblg.mblg0101.MBLG0101Logic
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.system.Config
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.system.master.PersonalityFlag
import jp.co.jsbank.mb.bankingapp.system.master.UserType
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mbsu.mbsu0301.CustomerInformation
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mbsu.mbsu0302.MBSU0302PageState
import jp.co.jsbank.mb.bankingapp.utils.*
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.CIF_NO
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.BRANCH_NO
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.REQUEST_NO
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * MBSU0302ロジック
 */
@HiltViewModel
class MBSU0302Logic @Inject constructor(
    private var webService: RestService,
) : ViewModel() {

    // ログインステータス
    var viewStates by mutableStateOf(MBSU0302PageState())
        private set

    init {
        val dataBean = MainActivity.NAVCTRL?.currentBackStackEntry?.arguments
            ?.get(ConstUtil.DATA).toString().fromJson<CustomerInformation>()!!
        viewStates = viewStates.copy(requestBean = dataBean)
    }

    /**
     * ホスト照合
     */
    suspend fun hostVerification() {
        // 画面IDとイベントID設定
        PreferenceUtil.setScreenIDAndEventID("MBSU0302", "E06")
        val param = MBSU0302RequestBean()
        // 人格区分
        param.personType =
            if (Config.isRetail()) PersonalityFlag.INDIVIDUAL_INITIAL_LOGIN.code
            else PreferenceUtil.getPreferenceStringValue(
                ConstUtil.PERSONALITY_FLAG
            ).toString()
        // 利用者区分
        param.userType = UserType.INDIVIDUAL.code
        // 店番
        param.branchCode = viewStates.requestBean.shop.split(" ")[0]
        // 口座番号
        param.accountNumber = viewStates.requestBean.accountNumber
        // カナ氏名（姓）
        param.customerLastName = viewStates.requestBean.firstName
        // カナ氏名（名）
        param.customerFirstName = viewStates.requestBean.secondName
        // 生年月日
        param.birthDay =
            dateAddHyphen(viewStates.requestBean.year, viewStates.requestBean.month, viewStates.requestBean.day)
        // 郵便番号
        param.zipCode = viewStates.requestBean.postCode
        // 暗証番号
        param.ccPinCode = viewStates.requestBean.cashCardPassword
        // 所属
        param.divisionCode = ""
        // 認証キー
        param.authCode = PreferenceUtil.getPreferenceStringValue(ConstUtil.VERIFY_TRX_KEY).toString()
        // デバイスID(プッシュ通知)
        param.deviceId = PreferenceUtil.getPreferenceStringValue(ConstUtil.PUSH_TOKEN_IDENTIFY).toString()
        viewModelScope.launch {
            flow {
                ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, param.toJson())
                emit(webService.AB0103())
            }.map {
                KeyStoreUtil().jagInfoSave(
                    JagPeerBean(
                        customerId = it.resultDto!!.customerId,
                        userId = it.resultDto!!.userId
                    )
                )
                // 依頼番号
                PreferenceUtil.setPreferenceStringValue(REQUEST_NO, it.resultDto!!.requestNo)
                // CIF番号
                PreferenceUtil.setPreferenceStringValue(CIF_NO, it.resultDto!!.cifNo)
                // 店番
                PreferenceUtil.setPreferenceStringValue(BRANCH_NO, param.branchCode)

                // 2025/01/24 共同化ため　1:本人カードは実際は未発行の注意コード有り場合に　start
                if (ConstUtil.CARD_DUMMY_ISSUE_CODE == it.resultDto!!.cardDummyIssue) {
                    openCautionIndicationCodeDialog()
                } else {// 2025/01/24 共同化ため　注意コードが110場合に　end
                    // MBSU0401　パスワード設定
                    RouteUtil.navTo(
                        RouteName.MBSU0401Page,
                    )
                }
            }.catch {
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }.join()
    }

    fun accountShowChange(flag: Boolean) {
        viewStates = viewStates.copy(accountShowFlag = !flag)
    }

    fun passwordShowChange(flag: Boolean) {
        viewStates = viewStates.copy(passwordShowFlag = !flag)
    }

    /**
     * 注意コード誘導メッセージ
     */
    fun openCautionIndicationCodeDialog() {
        viewStates = viewStates.copy(showDialogFlag = true)
    }

    /**
     * 注意コード誘導メッセージダイアログクルーズ
     */
    fun closeAccountOpeningDialogFlag() {
        viewStates = viewStates.copy(showDialogFlag = false)
    }
}

package jp.co.jsbank.mb.bankingapp.logic.login.mbsu

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mbsu.mbsu0102.MBSU0102PageState

/**
 * MBSU0102ロジック
 */
@HiltViewModel
class MBSU0102Logic @Inject constructor() : ViewModel() {

    /**
     * ログインステータス
     */
    var viewStates by mutableStateOf(MBSU0102PageState())
        private set
}

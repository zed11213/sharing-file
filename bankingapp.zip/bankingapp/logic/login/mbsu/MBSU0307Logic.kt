package jp.co.jsbank.mb.bankingapp.logic.login.mbsu

import androidx.compose.foundation.ScrollState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.system.MyApp.Companion.CONTEXT
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mbsu.mbsu0307.MBSU0307ErrorInformation
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mbsu.mbsu0307.MBSU0307PageState
import jp.co.jsbank.mb.bankingapp.utils.*
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isHalfNum
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.houjin_name_kana
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.name_kana
import jp.co.jsbank.mb.bankingapp.utils.HalfToFullUtils.bigToSmallChar
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * MBSU0307ロジック
 */
@HiltViewModel
class MBSU0307Logic @Inject constructor() : ViewModel() {

    // ログインステータス
    var viewStates by mutableStateOf(MBSU0307PageState())
        private set

    /**
     * 郵便番号ダイアログの表示フラグ切替
     */
    fun switchPostCodeAlertDialog() {
        viewStates = viewStates.copy(postCodeShowFlag = !viewStates.postCodeShowFlag)
    }

    /**
     * 口座番号ダイアログの表示フラグ切替
     */
    fun switchAccountNumberShowFlag() {
        viewStates = viewStates.copy(accountNumberShowFlag = !viewStates.accountNumberShowFlag)
    }

    /**
     * 次への処理
     */
    fun doCheck(coroutineScope: CoroutineScope, scrollState: ScrollState) {

        // エラー情報初期化
        val errorBean = MBSU0307ErrorInformation()
        viewStates = viewStates.copy(isError = false)
        viewStates = viewStates.copy(errorBean = errorBean)
        viewStates = viewStates.copy(errMsgList = listOf())

        // セイ（半角カナ）の入力チェック
        if (viewStates.requestBean.firstName.isBlank()) {
            errorBean.firstNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        CONTEXT.getString(R.string.MSG_ID_MB002014V),
                        CONTEXT.getString(R.string.mbsu0307_page_label_firstName)
                    )
                )
            )
        } else if (!viewStates.requestBean.firstName.name_kana()) {
            // セイ（半角カナ）の半角カナチェック
            errorBean.firstNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        CONTEXT.getString(R.string.MSG_ID_MB002009V),
                        CONTEXT.getString(R.string.mbsu0307_page_label_firstName)
                    )
                )
            )
        }

        // メイ（半角カナ）の入力チェック
        if (viewStates.requestBean.secondName.isBlank()) {
            errorBean.secondNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        CONTEXT.getString(R.string.MSG_ID_MB002014V),
                        CONTEXT.getString(R.string.mbsu0307_page_label_secondName)
                    )
                )
            )
        } else if (!viewStates.requestBean.secondName.name_kana()) {
            // メイ（半角カナ）の半角カナチェック
            errorBean.secondNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        CONTEXT.getString(R.string.MSG_ID_MB002009V),
                        CONTEXT.getString(R.string.mbsu0307_page_label_secondName)
                    )
                )
            )
        }

        // 2025/01/28 共同化ため 名前の桁数変更  start
        val firstNameSecondName = viewStates.requestBean.firstName +" "+ viewStates.requestBean.secondName
        if (firstNameSecondName.length > 20) {
            // セイ＋ブランク＋メイで20桁を超える場合
            errorBean.firstNameSecondNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        CONTEXT.getString(R.string.MSG_ID_MB002033V),
                        CONTEXT.getString(R.string.mbop0601_page_label_kana_firstName_secondName)
                    )
                )
            )
        }
        // 2025/01/28 共同化ため 名前の桁数変更  end

        // 屋号（半角カナ）の全角カナチェック
        if (viewStates.requestBean.storeNameKana.isNotBlank()) {
            if (!viewStates.requestBean.storeNameKana.houjin_name_kana()) {
                errorBean.storeNameKanaErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        MessageReplaceUtils.messageReplace(
                            CONTEXT.getString(R.string.MSG_ID_MB002032V),
                            CONTEXT.getString(R.string.mbsu0307_page_label_store_name_kana)
                        )
                    )
                )
            }
        }

        // 生年の入力チェック
        if (viewStates.requestBean.birthdayYear.isBlank()) {
            errorBean.birthdayYearErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        CONTEXT.getString(R.string.MSG_ID_MB002014V),
                        CONTEXT.getString(R.string.common_message_replace_label_year)
                    )
                )
            )
        }

        // 生月の入力チェック
        if (viewStates.requestBean.birthdayMonth.isBlank()) {
            errorBean.birthdayMonthErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        CONTEXT.getString(R.string.MSG_ID_MB002014V),
                        CONTEXT.getString(R.string.common_message_replace_label_month)
                    )
                )
            )
        }

        // 生日の入力チェック
        if (viewStates.requestBean.birthdayDay.isBlank()) {
            errorBean.birthdayDayErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        CONTEXT.getString(R.string.MSG_ID_MB002014V),
                        CONTEXT.getString(R.string.common_message_replace_label_day)
                    )
                )
            )
        }

        // 生年月日チェック
        if (viewStates.requestBean.birthdayYear.isNotBlank() &&
            viewStates.requestBean.birthdayMonth.isNotBlank() &&
            viewStates.requestBean.birthdayDay.isNotBlank()
        ) {
            if (!EditCheckUtil.isDayCheck(
                    viewStates.requestBean.birthdayYear,
                    viewStates.requestBean.birthdayMonth,
                    viewStates.requestBean.birthdayDay
                )
            ) {
                errorBean.birthdayYearErrorFlag = true
                errorBean.birthdayMonthErrorFlag = true
                errorBean.birthdayDayErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        MessageReplaceUtils.messageReplace(
                            CONTEXT.getString(R.string.MSG_ID_MB002007V),
                            CONTEXT.getString(R.string.mbsu0307_page_label_birthday)
                        )
                    )
                )
            }
            // 未来日チェック
            else if (EditCheckUtil.isFutureDays(
                    viewStates.requestBean.birthdayYear +
                        viewStates.requestBean.birthdayMonth +
                        viewStates.requestBean.birthdayDay
                )
            ) {
                errorBean.birthdayYearErrorFlag = true
                errorBean.birthdayMonthErrorFlag = true
                errorBean.birthdayDayErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        MessageReplaceUtils.messageReplace(
                            CONTEXT.getString(R.string.MSG_ID_MB002007V),
                            CONTEXT.getString(R.string.mbsu0307_page_label_birthday)
                        )
                    )
                )
            }
            // 1900年生まれ以降チェック
            else if (!EditCheckUtil.isYearCheck(viewStates.requestBean.birthdayYear)) {
                errorBean.birthdayYearErrorFlag = true
                errorBean.birthdayMonthErrorFlag = true
                errorBean.birthdayDayErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        MessageReplaceUtils.messageReplace(
                            CONTEXT.getString(R.string.MSG_ID_MB002007V),
                            CONTEXT.getString(R.string.mbsu0307_page_label_birthday)
                        )
                    )
                )
            }
        }

        // 郵便番号の入力チェック
        if (viewStates.requestBean.postCode.isBlank()) {
            errorBean.postCodeErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        CONTEXT.getString(R.string.MSG_ID_MB002014V),
                        CONTEXT.getString(R.string.mbsu0307_page_label_postCode)
                    )
                )
            )
        } else if (!viewStates.requestBean.postCode.isHalfNum()) {
            // 郵便番号の半角数字チェック
            errorBean.postCodeErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        CONTEXT.getString(R.string.MSG_ID_MB002012V),
                        CONTEXT.getString(R.string.mbsu0307_page_label_postCode)
                    )
                )
            )
        } else if (!EditCheckUtil.lengthCheck(viewStates.requestBean.postCode, 7)) {
            // 郵便番号の桁数チェック
            errorBean.postCodeErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    CONTEXT.getString(R.string.MSG_ID_MB002003V)
                )
            )
        }

        // 店舗の入力チェック
        if (viewStates.requestBean.shop.isEmpty()) {
            errorBean.shopErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        CONTEXT.getString(R.string.MSG_ID_MB002022V),
                        CONTEXT.getString(R.string.mbsu0307_page_label_shop_name)
                    )
                )
            )
        }

        // 口座番号の入力チェック
        if (viewStates.requestBean.accountNumber.isEmpty()) {
            errorBean.accountNumberErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        CONTEXT.getString(R.string.MSG_ID_MB002014V),
                        CONTEXT.getString(R.string.mbsu0307_page_label_account_number)
                    )
                )
            )
        } else if (!viewStates.requestBean.accountNumber.isHalfNum()) {
            // 口座番号の半角数字チェック
            errorBean.accountNumberErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        CONTEXT.getString(R.string.MSG_ID_MB002012V),
                        CONTEXT.getString(R.string.mbsu0307_page_label_account_number)
                    )
                )
            )
        } else if (!EditCheckUtil.lengthCheck(viewStates.requestBean.accountNumber, 7)) {
            // 口座番号の桁数チェック
            errorBean.accountNumberErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    CONTEXT.getString(R.string.MSG_ID_MB002037V)
                )
            )
        }

        // 暗証番号の入力チェック
        if (viewStates.requestBean.cashCardPassword.isEmpty()) {
            errorBean.cashCardPasswordErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        CONTEXT.getString(R.string.MSG_ID_MB002014V),
                        CONTEXT.getString(R.string.mbsu0307_page_label_cash_card_number)
                    )
                )
            )
        } else if (!viewStates.requestBean.cashCardPassword.isHalfNum()) {
            // キャッシュカード暗証番号（4桁）の半角数字チェック
            errorBean.cashCardPasswordErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        CONTEXT.getString(R.string.MSG_ID_MB002012V),
                        CONTEXT.getString(R.string.mbsu0303_page_label_cash_card_number)
                    )
                )
            )
        } else if (!EditCheckUtil.lengthCheck(viewStates.requestBean.cashCardPassword, 4)) {
            // キャッシュカード暗証番号（4桁）の桁数チェック
            errorBean.cashCardPasswordErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    CONTEXT.getString(R.string.MSG_ID_MB002005V)
                )
            )
        }

        if (!viewStates.isError) {

            // 全角カナを半角カナに変換する
            val bean = viewStates.requestBean
            bean.firstName = bigToSmallChar(HalfToFullUtils.fullToHalfCharName(bean.firstName))
            bean.secondName = bigToSmallChar(HalfToFullUtils.fullToHalfCharName(bean.secondName))
            viewStates = viewStates.copy(requestBean = bean)

            RouteUtil.navTo(
                RouteName.MBSU0308Page + "/${viewStates.requestBean.toJson()}",
            )
        } else {
            coroutineScope.launch {
                scrollState.animateScrollTo(0)
            }
        }
    }
}

package jp.co.jsbank.mb.bankingapp.logic.login.mbsu

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mbsu.mbsu0106.MBSU0106PageState

/**
 * MBSU0106ロジック
 */
@HiltViewModel
class MBSU0106Logic @Inject constructor(
    private var webService: RestService,
) : ViewModel() {

    // ログインステータス
    var viewStates by mutableStateOf(MBSU0106PageState())
        private set

    fun showDetail(index: Int, flag: Boolean) {
        viewStates = when (index) {
            0 -> viewStates.copy(showFlag1 = !flag)
            1 -> viewStates.copy(showFlag7 = !flag)
            else -> viewStates.copy(showFlag18 = !flag)
        }
    }

    /**
     * チェックボックスの切替え
     */
    fun onCheckChange(check: Boolean) {
        viewStates = viewStates.copy(check = !check)
    }
}

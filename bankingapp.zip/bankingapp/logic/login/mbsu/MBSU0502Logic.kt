package jp.co.jsbank.mb.bankingapp.logic.login.mbsu

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.gson.Gson
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.bean.login.mbsu.mbsu0501.MBSU0502Param
import jp.co.jsbank.mb.bankingapp.bean.login.mbsu.mbsu0502.MBSU0502RequestBean
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.system.Config.isRetail
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.system.MyApp
import jp.co.jsbank.mb.bankingapp.system.master.PersonalityFlag
import jp.co.jsbank.mb.bankingapp.system.master.UpdateType
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mbsu.mbsu0502.MBSU0502PageState
import jp.co.jsbank.mb.bankingapp.utils.*
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.USER_DONE
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.USER_NO_DONE
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/**
 * MBSU0502ロジック
 */
@HiltViewModel
class MBSU0502Logic @Inject constructor(
    private var webService: RestService
) : ViewModel() {
    /**
     * ステータス
     */
    var viewStates by mutableStateOf(MBSU0502PageState())
        private set

    private fun openDialog() {
        viewStates = viewStates.copy(flag = true)
    }

    fun closeDialog() {
        viewStates = viewStates.copy(flag = false)
    }

    init {
        // 遷移元画面渡すパラメータ取得
        val arguments = MainActivity.NAVCTRL?.currentBackStackEntry?.arguments?.get(ConstUtil.DATA).toString()
            .fromJson<MBSU0502Param>()!!
        viewStates.emailAddress = arguments.emailAddress
        viewStates.transactionCode = arguments.transactionCode
    }

    // 確認番号認証
    fun errorCheck() {
        // エラー情報初期化
        viewStates = viewStates.copy(errMsgList = listOf())

        // 確認番号が空白場合
        if (viewStates.confirmationCode.isBlank()) {
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002014V),
                        MyApp.CONTEXT.getString(R.string.mbsu0502_page_label_confirmation_no)
                    )
                )
            )
        } else if (!EditCheckUtil.lengthCheck(viewStates.confirmationCode, 6)) {
            // 確認番号は6桁以外
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB007001V),
                        MyApp.CONTEXT.getString(R.string.mbsu0502_page_label_confirmation_no)
                    )
                )
            )
        } else if (!EditCheckUtil.numberCheck(viewStates.confirmationCode)) {
            // 確認番号が半角数字以外
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB007002V),
                        MyApp.CONTEXT.getString(R.string.mbsu0502_page_label_confirmation_no)
                    )
                )
            )
        }

        if (viewStates.errMsgList.isEmpty()) {
            // メール認証
            numberAuthentication()
        }
    }

    // 確認番号認証
    private fun numberAuthentication() {
        // 画面IDとイベントID設定
        PreferenceUtil.setScreenIDAndEventID("MBSU0502", "E04")
        val requestBean = MBSU0502RequestBean()
        // メールアドレス
        requestBean.emailAddress = viewStates.emailAddress
        // メールOTP
        requestBean.mailOtp = viewStates.transactionCode + viewStates.confirmationCode
        // 依頼番号
        requestBean.requestNo = PreferenceUtil.getPreferenceStringValue(ConstUtil.REQUEST_NO).toString()
        // CIF番号
        requestBean.cifNumber = PreferenceUtil.getPreferenceStringValue(ConstUtil.CIF_NO).toString()
        // 受付番号　TODO 一時対応「YYMMDD+4桁採番」
//        requestBean.receiptNumber = "2208050001"
        requestBean.receiptNumber = ""
        // 認証TRXキー
        requestBean.authCode = PreferenceUtil.getPreferenceStringValue(ConstUtil.VERIFY_TRX_KEY).toString()
        // 人格区分
        requestBean.personType =
            if (isRetail()) PersonalityFlag.INDIVIDUAL_INITIAL_LOGIN.code
            else PreferenceUtil.getPreferenceStringValue(ConstUtil.PERSONALITY_FLAG).toString()
        // 更新パターン
        requestBean.updateType = UpdateType.UPDATE_TYPE_105.code

        viewModelScope.launch {
            LoadingUtil.setLoadingValue(value = true, type = true)
            // 認証コード要求
            AB0102(requestBean)
            LoadingUtil.setLoadingValue(value = false)
        }
    }

    // 認証コード要求
    private suspend fun AB0102(requestBean: MBSU0502RequestBean) {
        flow {
            ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, requestBean.toJson())
            emit(webService.AB0102())
        }.map {
            // 利用者flag
            val userFlag = PreferenceUtil.getPreferenceStringValue(ConstUtil.USER)
            if (it.resultDto != null) {
                // 利用者以外場合
                if (userFlag != USER_NO_DONE && userFlag != USER_DONE) {
                    // MBSU0601　電話番号認証
                    RouteUtil.navTo(
                        RouteName.MBSU0601Page,
                        Gson().toJson(it.resultDto!!.phoneNumberList)
                    )
                } else {
                    // 確認ダイアログ画面が表示すること
                    openDialog()
                }
            }
        }.catch {
            ErrorUtil().apiErrorCatch(it.message.toString())
        }.collect()
    }
}

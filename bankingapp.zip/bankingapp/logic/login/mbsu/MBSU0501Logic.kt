package jp.co.jsbank.mb.bankingapp.logic.login.mbsu

import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.bean.login.mbsu.mbsu0501.MBSU0501RequestBean
import jp.co.jsbank.mb.bankingapp.bean.login.mbsu.mbsu0501.MBSU0502Param
import jp.co.jsbank.mb.bankingapp.logic.login.mblg.mblg0101.MBLG0101Logic
import jp.co.jsbank.mb.bankingapp.logic.main.menu.mbst.mbst0401.MBST0401Logic
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.system.Config
import jp.co.jsbank.mb.bankingapp.system.MyApp.Companion.CONTEXT
import jp.co.jsbank.mb.bankingapp.system.master.PersonalityFlag
import jp.co.jsbank.mb.bankingapp.system.master.UpdateTypeMail
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mbsu.mbsu0501.MBSU0501ErrorInformation
import jp.co.jsbank.mb.bankingapp.ui.pages.login.mbsu.mbsu0501.MBSU0501PageState
import jp.co.jsbank.mb.bankingapp.utils.*
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/**
 * MBSU0501ロジック
 */
@HiltViewModel
class MBSU0501Logic @Inject constructor(
    private var webService: RestService,
) : ViewModel() {

    /**
     * MBSU0501ステータス
     */
    var viewStates by mutableStateOf(MBSU0501PageState())
        private set

    private suspend fun emailSend() {
        // 画面IDとイベントID設定
        PreferenceUtil.setScreenIDAndEventID("MBSU0501", "E03")
        val requestBean = MBSU0501RequestBean(
            updateType = UpdateTypeMail.INITIAL_REGISTRATION.code,
            emailAddress = viewStates.mailAddress,
            personType = if (Config.isRetail()) PersonalityFlag.INDIVIDUAL_INITIAL_LOGIN.code
            else PreferenceUtil.getPreferenceStringValue(ConstUtil.PERSONALITY_FLAG).toString()
        )
        viewModelScope.launch{
            flow {
                ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, requestBean.toJson())
                emit(webService.AB0101())
            }.map {
                val param = MBSU0502Param()
                param.emailAddress = viewStates.mailAddress
                param.transactionCode = it.resultDto!!.transactionCode
                // MBSU0502　確認番号入力
                RouteUtil.navTo(
                    RouteName.MBSU0502Page,
                    args = param
                )
            }.catch {
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }.join()
    }

    // エラーチェック
    suspend fun emailCheck() {
        // エラー情報初期化
        val errorBean = MBSU0501ErrorInformation()
        viewStates = viewStates.copy(errorFlag = false)
        viewStates = viewStates.copy(errorBean = errorBean)
        viewStates = viewStates.copy(errMsgList = listOf())

        // 入力されたメールフォーマットの確認
        if (!Regex("^[a-zA-Z0-9._-]+@[a-zA-Z0-9_-]+(\\.[a-zA-Z0-9_-]+)+\$")
            .matches(viewStates.mailAddress)
            ) {
            errorBean.mailAddressErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    CONTEXT.getString(R.string.MSG_ID_MB004006V)
                )
            )
        }

        // メールアドレスと確認メールアドレス不一致
        if (viewStates.mailAddress != viewStates.confirmEmailAddress) {
            errorBean.confirmEmailAddressErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    CONTEXT.getString(R.string.MSG_ID_MB004005V)
                )
            )
        }
        if (viewStates.errMsgList.isEmpty()) {
            viewModelScope.launch {
                // メール送信
                emailSend()
            }.join()
        }
    }

    companion object{
        /**
         * ログのタグ.
         */
        private val TAG = MBSU0501Logic::class.java.name
    }
}

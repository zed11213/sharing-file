package jp.co.jsbank.mb.bankingapp.logic.cashCard.mbcc.mbcc0501

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import jp.co.jsbank.mb.bankingapp.bean.cashCard.mbcc.mbcc0501.MBCC0501RequestBean
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.system.master.UpdateType
import jp.co.jsbank.mb.bankingapp.ui.pages.cashCard.mbcc.mbcc0401.CustomerInformation
import jp.co.jsbank.mb.bankingapp.ui.pages.cashCard.mbcc.mbcc0501.MBCC0501PageState
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.utils.*
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.DATA
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * MBCC0501ロジック
 */
@HiltViewModel
class MBCC0501Logic @Inject constructor(
    private var webService: RestService,
) : ViewModel() {

    // ログインステータス
    var viewStates by mutableStateOf(MBCC0501PageState())

    /**
     * 初期化
     */
    init {
        val dataBean = MainActivity.NAVCTRL?.currentBackStackEntry?.arguments?.get(DATA).toString()
            .fromJson<CustomerInformation>()!!
        viewStates = viewStates.copy(requestBean = dataBean)
    }

    // ホスト照合
    fun hostAuthentication() {
        viewModelScope.launch {
            LoadingUtil.setLoadingValue(value = true, type = true)
            when (hostInfoVerification()) {
                true -> {
                    // 2025/01/24 共同化ため　注意コード追加　start
                    // 注意コードダイアログフラグ設定
                    openCautionIndicationCodeDialog()
                   if (!viewStates.showDialogFlag) {
                       RouteUtil.navTo(
                           RouteName.MBCC0301Page
                       )
                   }
                    // 2025/01/24 共同化ため　注意コード追加　end
                }
                else -> {
                    viewStates = viewStates.copy(errorFlag = true)
                }
            }
            LoadingUtil.setLoadingValue(value = false)
        }
    }

    /**
     * ホスト照合を実施する
     */
    private suspend fun hostInfoVerification(): Boolean {
        viewStates = viewStates.copy(errorFlag = false)

        // ホスト照合
        hostVerification()

        if (viewStates.errorFlag) {
            return false
        } else {
            if (viewStates.errorFlag) {
                return false
            }
        }
        return true
    }

    /**
     * ホスト照合
     */
    private suspend fun hostVerification() {
        // 画面IDとイベントID設定
        PreferenceUtil.setScreenIDAndEventID("MBCC0501", "E04")
        PreferenceUtil.removePreferenceStringValue(ConstUtil.PHONE_FIRST)
        PreferenceUtil.removePreferenceStringValue(ConstUtil.PHONE_SECOND)
        PreferenceUtil.removePreferenceStringValue(ConstUtil.PHONE_THREE)
        PreferenceUtil.removePreferenceStringValue(ConstUtil.CARD_DUMMY_ISSUE)
        val param = MBCC0501RequestBean()
        // 受付番号
        param.receiptNumber = KeyStoreUtil().getFromKeyStore(ConstUtil.CC_RECEIPT_NUMBER)
        // カナ氏名（姓）
        param.customerLastName = viewStates.requestBean.firstName
        // カナ氏名（名）
        param.customerFirstName = viewStates.requestBean.secondName
        // 生年月日
        param.birthday =
            dateAddHyphen(viewStates.requestBean.year, viewStates.requestBean.month, viewStates.requestBean.day)
        // 郵便番号
        param.zipCode = viewStates.requestBean.postCode
        // 職業
        param.occupation = viewStates.requestBean.occupation
        // 職業（その他）
        param.occupationOther = viewStates.requestBean.occupationOther
        // 取引目的
        param.transactPurpose = viewStates.requestBean.transactionPurpose
        // 取引目的（その他）
        param.transactPurposeOther = viewStates.requestBean.transactionPurposeOther
        // 取引種別
        param.transactionType = "02"
        // 店番
        param.branchNumber = viewStates.requestBean.shop.split(" ")[0]
        // 口座番号
        param.accountNumber = viewStates.requestBean.accountNumber
        // 更新パターン
        param.updateType = UpdateType.UPDATE_TYPE_032.code

        viewModelScope.async {
            flow {
                ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, param.toJson())
                emit(webService.AB0805())
            }.map {
                // 電話番号１
                PreferenceUtil.setPreferenceStringValue(ConstUtil.PHONE_FIRST, it.resultDto!!.phoneNumber1)
                // 電話番号２
                PreferenceUtil.setPreferenceStringValue(ConstUtil.PHONE_SECOND, it.resultDto!!.phoneNumber2)
                // 2025/01/16 共同化ため電話番号の登録・表示　電話３追加　start
                // 電話番号３
                PreferenceUtil.setPreferenceStringValue(ConstUtil.PHONE_THREE, it.resultDto!!.phoneNumber3)
                // 2025/01/16 共同化ため電話番号の登録・表示　電話３追加　end
                // 2025/01/24 共同化ため　本人カード仮発行追加　start
                // 本人カード仮発行
                PreferenceUtil.setPreferenceStringValue(ConstUtil.CARD_DUMMY_ISSUE, it.resultDto!!.cardDummyIssue)
                // 2025/01/24 共同化ため　本人カード仮発行追加　end
                // 番地
                PreferenceUtil.setPreferenceStringValue(ConstUtil.ADDRESS, it.resultDto!!.addrDetail3)
                // 方書
                PreferenceUtil.setPreferenceStringValue(ConstUtil.HOSHO, it.resultDto!!.addressDetailKana)
            }.catch {
                viewStates = viewStates.copy(errorFlag = true)
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }.await()
    }

    fun accountShowChange(flag: Boolean) {
        viewStates = viewStates.copy(accountShowFlag = !flag)
    }

    /**
     * 注意コード誘導メッセージ
     */
    fun openCautionIndicationCodeDialog() {
        // 1:本人カードは実際は未発行の注意コード有りの場合
        if (ConstUtil.CARD_DUMMY_ISSUE_CODE == PreferenceUtil.getPreferenceStringValue(ConstUtil.CARD_DUMMY_ISSUE)) {
            viewStates = viewStates.copy(showDialogFlag = true)
        }
    }

    /**
     * 注意コード誘導メッセージダイアログクルーズ
     */
    fun closeAccountOpeningDialogFlag() {
        viewStates = viewStates.copy(showDialogFlag = false)
    }
}

package jp.co.jsbank.mb.bankingapp.logic.cashCard.mbcc.mbcc0102

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import jp.co.jsbank.mb.bankingapp.ui.pages.cashCard.mbcc.mbcc0102.MBCC0102PageState

/**
 * MBOP0102ロジック
 */
@HiltViewModel
class MBCC0102Logic @Inject constructor() : ViewModel() {

    // MBSU0102ステータス
    var viewStates by mutableStateOf(MBCC0102PageState())
        private set
}

package jp.co.jsbank.mb.bankingapp.logic.cashCard.mbcc.mbcc0103

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import jp.co.jsbank.mb.bankingapp.ui.pages.cashCard.mbcc.mbcc0103.MBCC0103PageState

/**
 * MBCC0103ロジック
 */
@HiltViewModel
class MBCC0103Logic @Inject constructor() : ViewModel() {

    /**
     * MBSU0103ステータス
     */
    var viewStates by mutableStateOf(MBCC0103PageState())
        private set
}

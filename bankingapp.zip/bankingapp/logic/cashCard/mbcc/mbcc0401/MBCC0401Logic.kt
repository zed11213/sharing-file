package jp.co.jsbank.mb.bankingapp.logic.cashCard.mbcc.mbcc0401

import androidx.compose.foundation.ScrollState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.system.MyApp
import jp.co.jsbank.mb.bankingapp.system.master.Occupation
import jp.co.jsbank.mb.bankingapp.system.master.TransactPurpose
import jp.co.jsbank.mb.bankingapp.ui.pages.cashCard.mbcc.mbcc0401.CustomerInformation
import jp.co.jsbank.mb.bankingapp.ui.pages.cashCard.mbcc.mbcc0401.MBCC0401ErrorInformation
import jp.co.jsbank.mb.bankingapp.ui.pages.cashCard.mbcc.mbcc0401.MBCC0401PageState
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.utils.*
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.DATE_OF_BIRTH
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isHalfNum
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isPersonNameKana
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isPersonNameOther
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.lengthCheck
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.numberCheck
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

/**
 * MBCC0401ロジック
 */
@HiltViewModel
class MBCC0401Logic @Inject constructor() : ViewModel() {

    // ログインステータス
    var viewStates by mutableStateOf(MBCC0401PageState())
        private set

    /**
     * 初期化
     */
    init {
        var birthday = PreferenceUtil.getPreferenceStringValue(ConstUtil.EKYC_INFO_BIRTHDATE).toString()
        birthday = birthday.replace("年", "")
            .replace("月", "")
            .replace("日", "")
        viewStates = viewStates.copy(
            year = if (birthday.isNotEmpty()) birthday.substring(0, 4) else "",
            month = if (birthday.isNotEmpty()) birthday.substring(4, 6) else "",
            day = if (birthday.isNotEmpty()) birthday.substring(6, 8) else "",
        )
    }

    // エラーチェック
    fun doNext(coroutineScope: CoroutineScope, scrollState: ScrollState) {

        // エラー情報初期化
        val errorBean = MBCC0401ErrorInformation()
        viewStates = viewStates.copy(isError = false)
        viewStates = viewStates.copy(errorMessageList = listOf())
        viewStates = viewStates.copy(errorBean = errorBean)

        // お名前（フリガナ）のセイの入力チェック
        if (viewStates.firstName.isBlank()) {
            errorBean.firstNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002014V),
                        MyApp.CONTEXT.getString(R.string.mbcc0401_page_label_firstName)
                    )
                )
            )
        } else if (!viewStates.firstName.isPersonNameKana()) {
            // セイ（半角カナ）の半角カナチェック
            errorBean.firstNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002031V),
                        MyApp.CONTEXT.getString(R.string.mbcc0401_page_label_firstName)
                    )
                )
            )
        }

        // お名前（フリガナ）のメイの入力チェック
        if (viewStates.secondName.isBlank()) {
            errorBean.secondNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002014V),
                        MyApp.CONTEXT.getString(R.string.mbcc0401_page_label_secondName)
                    )
                )
            )
        } else if (!viewStates.secondName.isPersonNameKana()) {
            // メイ（半角カナ）の半角カナチェック
            errorBean.secondNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002031V),
                        MyApp.CONTEXT.getString(R.string.mbcc0401_page_label_secondName)
                    )
                )
            )
        }

        // 2025/01/28 共同化ため 名前の桁数変更  start
        val firstNameSecondName = viewStates.firstName +" "+ viewStates.secondName
        if (firstNameSecondName.length > 20) {
            // セイ＋ブランク＋メイで20桁を超える場合
            errorBean.firstNameSecondNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002033V),
                        MyApp.CONTEXT.getString(R.string.mbop0601_page_label_kana_firstName_secondName)
                    )
                )
            )
        }
        // 2025/01/28 共同化ため 名前の桁数変更  end

        // 年が空白場合
        if (viewStates.year.isBlank()) {
            errorBean.yearErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002014V),
                        MyApp.CONTEXT.getString(R.string.common_message_replace_label_year)
                    )
                )
            )
        } else if (!lengthCheck(viewStates.year, 4)) {
            errorBean.yearErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002006V)
                )
            )
        }

        // 月が空白場合
        if (viewStates.month.isBlank()) {
            errorBean.monthErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002014V),
                        MyApp.CONTEXT.getString(R.string.common_message_replace_label_month)
                    )
                )
            )
        }

        // 日が空白場合
        if (viewStates.day.isBlank()) {
            errorBean.dayErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002014V),
                        MyApp.CONTEXT.getString(R.string.common_message_replace_label_day)
                    )
                )
            )
        }

        // 年月日
        if (viewStates.year.isNotBlank() &&
            viewStates.month.isNotBlank() &&
            viewStates.day.isNotBlank()
        ) {
            if (!EditCheckUtil.isDayCheck(
                    viewStates.year,
                    viewStates.month,
                    viewStates.day
                )
            ) {
                errorBean.yearErrorFlag = true
                errorBean.monthErrorFlag = true
                errorBean.dayErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002007V),
                            MyApp.CONTEXT.getString(R.string.mbcc0401_page_label_birthday)
                        )
                    )
                )
            }
            // 未来日チェック
            else if (EditCheckUtil.isFutureDays(
                    viewStates.year + viewStates.month + viewStates.day
                )
            ) {
                errorBean.yearErrorFlag = true
                errorBean.monthErrorFlag = true
                errorBean.dayErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002007V),
                            MyApp.CONTEXT.getString(R.string.mbcc0401_page_label_birthday)
                        )
                    )
                )
            }

            // 15歳未満チェック
            else if (LifeAge.getAgeByBirth(
                    viewStates.year + ConstUtil.HALF_HYPHEN + viewStates.month + ConstUtil.HALF_HYPHEN + viewStates.day
                ) < 15
            ) {
                errorBean.yearErrorFlag = true
                errorBean.monthErrorFlag = true
                errorBean.dayErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002025V)
                    )
                )
            }

            // 1900年生まれ以降チェック
            else if (!EditCheckUtil.isYearCheck(viewStates.year)) {
                errorBean.yearErrorFlag = true
                errorBean.monthErrorFlag = true
                errorBean.dayErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002007V),
                            MyApp.CONTEXT.getString(R.string.mbcc0401_page_label_birthday)
                        )
                    )
                )
            }
        }

        // 郵便番号が空白場合
        if (viewStates.postCode.isBlank()) {
            errorBean.postCodeErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbcc0401_page_label_postCode)
                    )
                )
            )
        } else if (!viewStates.postCode.isHalfNum()) {
            // 郵便番号の半角数字チェック
            errorBean.postCodeErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                        MyApp.CONTEXT.getString(R.string.mbcc0401_page_label_postCode)
                    )
                )
            )
        } else if (!lengthCheck(viewStates.postCode, 7)) {
            // 郵便番号の桁数チェック
            errorBean.postCodeErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002003V)
                )
            )
        }

        // ご職業が空白場合
        if (viewStates.occupation.isBlank()) {
            errorBean.occupationErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                        MyApp.CONTEXT.getString(R.string.mbcc0401_page_label_occupation_name)
                    )
                )
            )
        }

        // ご職業がその他、かつ　ご職業（その他）が空白場合
        if (viewStates.occupation == Occupation.OTHERS.code) {
            if (viewStates.occupationOther.isBlank()) {
                errorBean.occupationOtherErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbcc0401_page_label_occupation_other)
                        )
                    )
                )
            } else if (!viewStates.occupationOther.isPersonNameOther()) {
                // ご職業（その他）の全角チェック
                errorBean.occupationOtherErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                            MyApp.CONTEXT.getString(R.string.mbcc0401_page_label_occupation_other)
                        )
                    )
                )
            }
        }

        // 取引目的が空白場合
        if (viewStates.transactionPurpose.isBlank()) {
            errorBean.transactionPurposeErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                        MyApp.CONTEXT.getString(R.string.mbcc0401_page_label_transaction_purpose)
                    )
                )
            )
        }

        // 取引目的がその他、かつ　取引目的（その他）が空白場合
        if (viewStates.transactionPurpose == TransactPurpose.OTHERS.code) {
            // 取引目的（その他）が空白場合
            if (viewStates.transactionPurposeOther.isBlank()) {
                errorBean.transactionPurposeOtherErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbcc0401_page_label_transaction_purpose_other)
                        )
                    )
                )
            } else if (!viewStates.transactionPurposeOther.isPersonNameOther()) {
                // 取引目的（その他）の全角チェック
                errorBean.transactionPurposeOtherErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                            MyApp.CONTEXT.getString(R.string.mbcc0401_page_label_transaction_purpose_other)
                        )
                    )
                )
            }
        }

        // 店舗名が空白場合
        if (viewStates.shop.isEmpty()) {
            errorBean.shopErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                        MyApp.CONTEXT.getString(R.string.mbcc0401_page_label_shop_name)
                    )
                )
            )
        }

        // 口座番号が空白場合
        if (!numberCheck(viewStates.accountNumber) ||
            // 2025/03/20 口座枠数の変更　start
            !lengthCheck(viewStates.accountNumber, 7)
            // 2025/03/20 口座枠数の変更　end
        ) {
            errorBean.accountNumberErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002004V)
                )
            )
        }

        val customerInformation = CustomerInformation(
            shop = viewStates.shop,
            accountNumber = viewStates.accountNumber,
            firstName = viewStates.firstName,
            secondName = viewStates.secondName,
            year = viewStates.year,
            month = viewStates.month,
            day = viewStates.day,
            postCode = viewStates.postCode,
            occupation = viewStates.occupation,
            occupationOther = viewStates.occupationOther,
            transactionPurpose = viewStates.transactionPurpose,
            transactionPurposeOther = viewStates.transactionPurposeOther,
        )

        // 「MBCC0401」で入力した生年月日
        PreferenceUtil.setPreferenceStringValue(
            DATE_OF_BIRTH,
            viewStates.year + viewStates.month + viewStates.day
        )

        if (!viewStates.isError) {
            // MBCC0501　情報入力確認
            RouteUtil.navTo(
                RouteName.MBCC0501Page + "/${customerInformation.toJson()}",
            )
        } else {
            coroutineScope.launch {
                scrollState.animateScrollTo(0)
            }
        }
    }

    fun setOccupation(code: String, value: String) {
        viewStates = viewStates.copy(occupation = code)
        viewStates = viewStates.copy(occupationLabel = value)
        if (code != Occupation.OTHERS.code) viewStates = viewStates.copy(occupationOther = "")
    }

    fun setTransactionPurpose(code: String, value: String) {
        viewStates = viewStates.copy(transactionPurpose = code)
        viewStates = viewStates.copy(transactionPurposeLabel = value)
        if (code != TransactPurpose.OTHERS.code) viewStates = viewStates.copy(transactionPurposeOther = "")
    }
}

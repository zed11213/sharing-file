package jp.co.jsbank.mb.bankingapp.logic.cashCard.mbcc.mbcc0901

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import jp.co.jsbank.mb.bankingapp.ui.pages.cashCard.mbcc.mbcc0901.MBCC0901PageState

/**
 * MBCC0901ロジック
 */
@HiltViewModel
class MBCC0901Logic @Inject constructor() : ViewModel() {

    /**
     * MBCC0901ステータス
     */
    var viewStates by mutableStateOf(MBCC0901PageState())
        private set

    /**
     * 申込完了ダイアログ
     */
    fun openCompletedDialogFlag() {
        viewStates = viewStates.copy(completedDialogFlag = true)
    }

    /**
     * 申込完了ダイアログクルーズ
     */
    fun closeCompletedDialogFlag() {
        viewStates = viewStates.copy(completedDialogFlag = false)
    }
}

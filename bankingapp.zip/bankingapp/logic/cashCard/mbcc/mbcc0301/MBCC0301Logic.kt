package jp.co.jsbank.mb.bankingapp.logic.cashCard.mbcc.mbcc0301

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import jp.co.jsbank.mb.bankingapp.bean.cashCard.mbcc.mbcc0301.MBCC0301RequestBean
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.system.master.UpdateType
import jp.co.jsbank.mb.bankingapp.ui.pages.cashCard.mbcc.mbcc0301.MBCC0301PageState
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.utils.*
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/**
 * MBCC0301ロジック
 */
@HiltViewModel
class MBCC0301Logic @Inject constructor(
    private var webService: RestService
) : ViewModel() {

    // MBCC0301ステータス
    var viewStates by mutableStateOf(MBCC0301PageState())
        private set

    /**
     * 通帳デザイン選択
     */
    fun onBankbookPatternChange(bankbookPattern: String) {
        viewStates = viewStates.copy(cardPattern = bankbookPattern)
    }

    /**
     * 通帳パターン設定
     */
    fun bankbookPatternSignUp() {
        val requestBean = MBCC0301RequestBean()
        // キャッシュカード種類
        requestBean.cashCardType = viewStates.cardPattern
        // 更新パターン
        requestBean.updateType = UpdateType.UPDATE_TYPE_031.code
        // 受付番号
        requestBean.receptionNumber = KeyStoreUtil().getFromKeyStore(ConstUtil.CC_RECEIPT_NUMBER)
        viewModelScope.launch {
            flow {
                ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, requestBean.toJson())
                emit(webService.AB0803())
            }.map {
                RouteUtil.navTo(
                    RouteName.MBCO0501Page,
                    ConstUtil.MAIL_CONFIRM_TYPE_CASH_CARD
                )
            }.catch {
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }
    }
}

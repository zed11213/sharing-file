package jp.co.jsbank.mb.bankingapp.logic.opened.mbop.mbop1003

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import io.realm.Realm
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import javax.inject.Inject
import jp.co.jsbank.mb.bankingapp.bean.common.CorporationBean
import jp.co.jsbank.mb.bankingapp.bean.opened.mbop.mbop1201.MBOP1201RequestBean
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.repositories.db.common.deleteAll
import jp.co.jsbank.mb.bankingapp.repositories.db.common.findAll
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.*
import jp.co.jsbank.mb.bankingapp.system.Config
import jp.co.jsbank.mb.bankingapp.system.MyApp
import jp.co.jsbank.mb.bankingapp.system.master.PersonalityFlag
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop1003.MBOP1003PageState
import jp.co.jsbank.mb.bankingapp.utils.*
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/**
 * MBOP1003ロジック
 */
@HiltViewModel
class MBOP1003Logic @Inject constructor(
    private var webService: RestService
) : ViewModel() {

    /**
     * ステータス
     */
    var viewStates by mutableStateOf(MBOP1003PageState())
        private set

    /**
     * ロカールDB
     */
    private var dbService: Realm = MyApp.INSTANCE

    /**
     * 初期化
     */
    init {
        PreferenceUtil.setPreferenceBooleanValue(ConstUtil.EDIT_FLAG, false)
        val accountOpeningAB0706 = dbService.findAll(AccountOpeningAB0706::class.java)
        if (accountOpeningAB0706.isNotEmpty()) {
            val customerInformation = accountOpeningAB0706[0]?.customerInformation?.fromJson<CorporationBean>()!!
            customerInformation.locationBuildingRoom = if(customerInformation.locationBuildingRoom.startsWith(ConstUtil.FULL_HYPHEN)) {
                customerInformation.locationBuildingRoom.removePrefix(ConstUtil.FULL_HYPHEN)
            } else {
                customerInformation.locationBuildingRoom
            }
            customerInformation.locationBuildingRoomKana = if(customerInformation.locationBuildingRoomKana.startsWith(ConstUtil.HALF_HYPHEN)) {
                customerInformation.locationBuildingRoomKana.removePrefix(ConstUtil.HALF_HYPHEN)
            } else {
                customerInformation.locationBuildingRoomKana
            }
            viewStates = viewStates.copy(corporation = customerInformation)
        }
    }

    /**
     * 情報の入力１
     */
    fun showFirstDetail(flag: Boolean) {
        viewStates = viewStates.copy(showFlag1 = !flag)
    }

    /**
     * 情報の入力２
     */
    fun showSecondDetail(flag: Boolean) {
        viewStates = viewStates.copy(showFlag2 = !flag)
    }

    /**
     * 情報の入力３
     */
    fun showThirdDetail(flag: Boolean) {
        viewStates = viewStates.copy(showFlag3 = !flag)
    }

    /**
     * 情報の入力４
     */
    fun showFourthDetail(flag: Boolean) {
        viewStates = viewStates.copy(showFlag4 = !flag)
    }

    /**
     * 情報の入力５
     */
    fun showFifthDetail(flag: Boolean) {
        viewStates = viewStates.copy(showFlag5 = !flag)
    }

    /**
     * AB0720 申込完了
     */
    fun applicationCompletion() {
        // 画面IDとイベントID設定
        PreferenceUtil.setScreenIDAndEventID("MBOP1003", "E02")
        viewModelScope.launch {
            val bean = MBOP1201RequestBean(
                // 人格区分
                personType = if (Config.isRetail())
                    PersonalityFlag.INDIVIDUAL_OTHER.code
                else
                    PreferenceUtil.getPreferenceStringValue(ConstUtil.PERSONALITY_FLAG).toString(),
                // 受付番号
                receiptNumber = KeyStoreUtil().getFromKeyStore(ConstUtil.RECEIPT_NUMBER),
                // 申込日
                applicationDate = LocalDateTime.now().format(
                    DateTimeFormatter.ofPattern(ConstUtil.DATE_FORMAT_YYYY_MM_DD_T_HH_MM_SS_MI)
                ),
            )
            flow {
                ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, bean.toJson())
                emit(webService.AB0720())
            }.map {
                // 本人情報削除処理
                PreferenceUtil.removePreferenceStringValue(ConstUtil.EKYC_IMAGE_FRONT)
                PreferenceUtil.removePreferenceStringValue(ConstUtil.EKYC_IMAGE_BACK)
                PreferenceUtil.removePreferenceStringValue(ConstUtil.EKYC_IMAGE_TILTED)
                PreferenceUtil.removePreferenceStringValue(ConstUtil.EKYC_IMAGE_SELF)
                PreferenceUtil.removePreferenceStringValue(ConstUtil.EKYC_IMAGE_LIVENESS)
                KeyStoreUtil().saveToKeyStore(
                    ConstUtil.RECEIPT_NUMBER_ISSUE,
                    KeyStoreUtil().getFromKeyStore(ConstUtil.RECEIPT_NUMBER)
                )
                // 受付番号をクリア
                KeyStoreUtil().saveToKeyStore(ConstUtil.RECEIPT_NUMBER, "")
                PreferenceUtil.setPreferenceStringValue(ConstUtil.OPENED_HOPE_DEPARTMENT, "")
                PreferenceUtil.setPreferenceStringValue(ConstUtil.OPENED_DEPARTMENT, "")
                // 入力情報クリア
                dbService.deleteAll(AccountOpeningAB0706::class.java)
                dbService.deleteAll(AccountOpeningAB0703::class.java)
                dbService.deleteAll(AccountOpeningAB0704::class.java)
                dbService.deleteAll(AccountOpeningAB0718::class.java)
                dbService.deleteAll(AccountOpeningAB0719::class.java)
                // MBOP1201　受付番号発行
                RouteUtil.navTo(
                    RouteName.MBOP1201Page,
                )
            }.catch {
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }
    }
}

package jp.co.jsbank.mb.bankingapp.logic.opened.mbop.mbop0607

import androidx.compose.foundation.ScrollState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import io.realm.Realm
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.bean.common.CodeBean
import jp.co.jsbank.mb.bankingapp.bean.common.SoleProprietorBean
import jp.co.jsbank.mb.bankingapp.bean.opened.mbop.mbop0601.MBOP0601RequestBean
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.repositories.db.common.create
import jp.co.jsbank.mb.bankingapp.repositories.db.common.deleteAll
import jp.co.jsbank.mb.bankingapp.repositories.db.common.findAll
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.AccountOpeningAB0706
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.EPassBookAB0701
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.system.MyApp
import jp.co.jsbank.mb.bankingapp.system.master.BusinessDescription
import jp.co.jsbank.mb.bankingapp.system.master.BusinessDescription.Companion.getBusinessDescriptionName
import jp.co.jsbank.mb.bankingapp.system.master.Phone.Companion.getPhoneTypeName
import jp.co.jsbank.mb.bankingapp.system.master.PreferredTrade
import jp.co.jsbank.mb.bankingapp.system.master.PreferredTrade.Companion.getPreferredTradeName
import jp.co.jsbank.mb.bankingapp.system.master.TransactPurpose
import jp.co.jsbank.mb.bankingapp.system.master.TransactPurpose.Companion.getTransactPurposeName
import jp.co.jsbank.mb.bankingapp.system.master.TransactionTrigger.Companion.getTransactionTriggerName
import jp.co.jsbank.mb.bankingapp.system.master.UpdateType
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0607.MBOP0607ErrorInformation
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0607.MBOP0607PageState
import jp.co.jsbank.mb.bankingapp.utils.*
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.MAIL_CONFIRM_TYPE_SOLE_PROPRIETOR
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isHalfNum
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isPersonNameOther
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import java.util.*
import javax.inject.Inject

/**
 * MBOP0607ロジック
 */
@HiltViewModel
class MBOP0607Logic @Inject constructor(
    private var webService: RestService
) : ViewModel() {

    /**
     * ステータス
     */
    var viewStates by mutableStateOf(MBOP0607PageState())
        private set

    /**
     * ロカールDB
     */
    private var dbService: Realm = MyApp.INSTANCE

    // 復元データを取得する
    private fun getRestoreData() {
        val accountOpeningAB0701 = MyApp.INSTANCE.findAll(EPassBookAB0701::class.java)
        if (accountOpeningAB0701.isNotEmpty() && !MainActivity.HAS_RECOVERY_FLAG) {
            val soleProprietorInfo = accountOpeningAB0701[0]?.soleProprietor?.fromJson<SoleProprietorBean>()!!
            viewStates = viewStates.copy(
                // ご自宅の電話番号
                phoneType = soleProprietorInfo.phoneType,
                // ご自宅の電話番号
                phoneTypeLabel = getPhoneTypeName(soleProprietorInfo.phoneType),
                // ご自宅の電話番号1
                phoneFirst = soleProprietorInfo.phoneNumOneFirst,
                // ご自宅の電話番号2
                phoneSecond = soleProprietorInfo.phoneNumOneMid,
                // ご自宅の電話番号3
                phoneThird = soleProprietorInfo.phoneNumOneLast,
                // 事業先電話番号
                businessPhoneType = soleProprietorInfo.businessPhoneType,
                // 事業先電話番号
                businessPhoneTypeLabel = getPhoneTypeName(soleProprietorInfo.businessPhoneType),
                // 事業先電話番号1
                businessPhoneFirst = soleProprietorInfo.businessPhoneNumFirst,
                // 事業先電話番号2
                businessPhoneSecond = soleProprietorInfo.businessPhoneNumMid,
                // 事業先電話番号3
                businessPhoneThird = soleProprietorInfo.businessPhoneNumLast,
                // 取引目的（事業先）
                transactionPurpose = soleProprietorInfo.transactPurpose,
                // 取引目的（事業先）
                transactionPurposeLabel = getTransactPurposeName(soleProprietorInfo.transactPurpose),
                // 取引目的（事業先）（その他）
                transactionPurposeOther = soleProprietorInfo.transactPurposeOther,
                // 取引目的（詳細）
                transactionPurposeDetail = soleProprietorInfo.transactPurposeDetail,
                // 事業内容
                businessContent = soleProprietorInfo.businessDescription,
                // 事業内容
                businessContentLabel = getBusinessDescriptionName(soleProprietorInfo.businessDescription),
                // 事業内容（その他）
                businessContentOther = soleProprietorInfo.businessDescriptionOther,
                // 取扱品目
                itemsHandled = soleProprietorInfo.handingItem,
                // 主要取引先（仕入）
                majorCustomersPurchasing = soleProprietorInfo.mainlyTradePurchase,
                // 主要取引先（販売）
                majorCustomersSales = soleProprietorInfo.mainlyTradeSale,
                // 当金庫との主な取引希望
                preferredTrade = soleProprietorInfo.preferredTrade,
                // 当金庫との主な取引希望
                preferredTradeLabel = getPreferredTradeName(soleProprietorInfo.preferredTrade),
                // 当金庫との主な取引希望（その他）
                preferredTradeOther = soleProprietorInfo.otherBusinessWishes,
                // お取引の理由
                triggerTransaction = soleProprietorInfo.transactionTrigger,
                // お取引の理由
                triggerTransactionLabel = getTransactionTriggerName(soleProprietorInfo.transactionTrigger),
                // 取引金融機関
                financialInstitution = soleProprietorInfo.financialInstitution,
                // 取引金融機関　預金状況
                depositStatus = soleProprietorInfo.financialInstitutionDepositStatus,
                // 取引金融機関　貸金状況
                loanStatus = soleProprietorInfo.financialInstitutionLoanStatus,
            )

            // 復元処理済みフラグ
            MainActivity.HAS_RECOVERY_FLAG = true
            MainActivity.SHOW_RETURN_BUTTON_FLAG = true
        }
    }

    /**
     * エラーチェック
     */
    fun doNext(coroutineScope: CoroutineScope, scrollState: ScrollState) {
        // エラー情報初期化
        val errorBean = MBOP0607ErrorInformation()
        viewStates = viewStates.copy(isError = false)
        viewStates = viewStates.copy(errorBean = errorBean)
        viewStates = viewStates.copy(errorMessageList = listOf())

        // ご自宅の電話番号が空白場合
        if (viewStates.phoneType.isBlank()) {
            errorBean.phoneTypeErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                        MyApp.CONTEXT.getString(R.string.mbop0607_page_label_phone_type)
                    )
                )
            )
        }

        // ご自宅の電話番号が空白場合
        if (viewStates.phoneFirst.isBlank()) {
            errorBean.phoneFirstErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            if (!viewStates.errorMessageList.contains(
                    MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0607_page_label_phone)
                        )
                )
            ) {
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0607_page_label_phone)
                        )
                    )
                )
            }
        } else if (!viewStates.phoneFirst.isHalfNum()) {
            // 電話番号の半角数字チェック
            errorBean.phoneFirstErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            if (!viewStates.errorMessageList.contains(
                    MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                            MyApp.CONTEXT.getString(R.string.mbop0607_page_label_phone)
                        )
                )
            ) {
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                            MyApp.CONTEXT.getString(R.string.mbop0607_page_label_phone)
                        )
                    )
                )
            }
        }

        // ご自宅の電話番号が空白場合
        if (viewStates.phoneSecond.isBlank()) {
            errorBean.phoneSecondErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            if (!viewStates.errorMessageList.contains(
                    MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0607_page_label_phone)
                        )
                )
            ) {
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0607_page_label_phone)
                        )
                    )
                )
            }
        } else if (!viewStates.phoneSecond.isHalfNum()) {
            // 電話番号の半角数字チェック
            errorBean.phoneSecondErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            if (!viewStates.errorMessageList.contains(
                    MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                            MyApp.CONTEXT.getString(R.string.mbop0607_page_label_phone)
                        )
                )
            ) {
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                            MyApp.CONTEXT.getString(R.string.mbop0607_page_label_phone)
                        )
                    )
                )
            }
        }

        // ご自宅の電話番号が空白場合
        if (viewStates.phoneThird.isBlank()) {
            errorBean.phoneThirdErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            if (!viewStates.errorMessageList.contains(
                    MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0607_page_label_phone)
                        )
                )
            ) {
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0607_page_label_phone)
                        )
                    )
                )
            }
        } else if (!viewStates.phoneThird.isHalfNum()) {
            // 電話番号の半角数字チェック
            errorBean.phoneThirdErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            if (!viewStates.errorMessageList.contains(
                    MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                            MyApp.CONTEXT.getString(R.string.mbop0607_page_label_phone)
                        )
                )
            ) {
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                            MyApp.CONTEXT.getString(R.string.mbop0607_page_label_phone)
                        )
                    )
                )
            }
        }

        // 取引目的（事業先）が空白場合
        if (viewStates.transactionPurpose.isBlank()) {
            errorBean.transactionPurposeErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                        MyApp.CONTEXT.getString(R.string.mbop0607_page_label_transaction_purpose)
                    )
                )
            )
        }

        if (viewStates.transactionPurpose == TransactPurpose.OTHERS.code) {
            // 取引目的（事業先）（その他）が空白場合
            if (viewStates.transactionPurposeOther.isBlank()) {
                errorBean.transactionPurposeOtherErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0607_page_label_transaction_purpose_other)
                        )
                    )
                )
            } else if (!viewStates.transactionPurposeOther.isPersonNameOther()) {
                // 取引目的（事業先）（その他）の全角チェック
                errorBean.transactionPurposeOtherErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                            MyApp.CONTEXT.getString(R.string.mbop0607_page_label_transaction_purpose_other)
                        )
                    )
                )
            }
        }

        if (viewStates.transactionPurposeDetail.isNotBlank()) {
            if (!viewStates.transactionPurposeDetail.isPersonNameOther()) {
                // 取引目的（詳細）の全角チェック
                errorBean.transactionPurposeDetailErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                            MyApp.CONTEXT.getString(R.string.mbop0607_page_label_transaction_purpose_detail)
                        )
                    )
                )
            }
        }

        // 事業内容が空白場合
        if (viewStates.businessContent.isBlank()) {
            errorBean.businessContentErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                        MyApp.CONTEXT.getString(R.string.mbop0607_page_label_business_content)
                    )
                )
            )
        }

        if (viewStates.businessContent == BusinessDescription.OTHERS.code) {
            // 事業内容（その他）が空白場合
            if (viewStates.businessContentOther.isBlank()) {
                errorBean.businessContentOtherErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0607_page_label_business_content_other)
                        )
                    )
                )
            } else if (!viewStates.businessContentOther.isPersonNameOther()) {
                // 事業内容（その他）の全角チェック
                errorBean.businessContentOtherErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                            MyApp.CONTEXT.getString(R.string.mbop0607_page_label_business_content_other)
                        )
                    )
                )
            }
        }

        // 取扱品目が空白場合
        if (viewStates.itemsHandled.isBlank()) {
            errorBean.itemsHandledErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0607_page_label_items_handled)
                    )
                )
            )
        } else if (!viewStates.itemsHandled.isPersonNameOther()) {
            // 取扱品目の全角チェック
            errorBean.itemsHandledErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                        MyApp.CONTEXT.getString(R.string.mbop0607_page_label_items_handled)
                    )
                )
            )
        }

        // 主要取引先（仕入）が空白場合
        if (viewStates.majorCustomersPurchasing.isBlank()) {
            errorBean.majorCustomersPurchasingErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0607_page_label_major_customers_purchasing)
                    )
                )
            )
        } else if (!viewStates.majorCustomersPurchasing.isPersonNameOther()) {
            // 主要取引先（仕入）の全角チェック
            errorBean.majorCustomersPurchasingErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                        MyApp.CONTEXT.getString(R.string.mbop0607_page_label_major_customers_purchasing)
                    )
                )
            )
        }

        // 主要取引先（販売）が空白場合
        if (viewStates.majorCustomersSales.isBlank()) {
            errorBean.majorCustomersSalesErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0607_page_label_major_customers_sales)
                    )
                )
            )
        } else if (!viewStates.majorCustomersSales.isPersonNameOther()) {
            // 主要取引先（販売）の全角チェック
            errorBean.majorCustomersSalesErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                        MyApp.CONTEXT.getString(R.string.mbop0607_page_label_major_customers_sales)
                    )
                )
            )
        }

        // 当金庫との主な取引希望が空白場合
        if (viewStates.preferredTrade.isBlank()) {
            errorBean.preferredTradeErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                        MyApp.CONTEXT.getString(R.string.mbop0607_page_label_preferred_trade)
                    )
                )
            )
        }

        if (viewStates.preferredTrade == PreferredTrade.OTHERS.code) {
            // 当金庫との主な取引希望（その他）が空白場合
            if (viewStates.preferredTradeOther.isBlank()) {
                errorBean.preferredTradeOtherErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0607_page_label_preferred_trade_other)
                        )
                    )
                )
            } else if (!viewStates.preferredTradeOther.isPersonNameOther()) {
                // 当金庫との主な取引希望（その他）の全角チェック
                errorBean.preferredTradeOtherErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                            MyApp.CONTEXT.getString(R.string.mbop0607_page_label_preferred_trade_other)
                        )
                    )
                )
            }
        }

        // お取引の理由が空白場合
        if (viewStates.triggerTransaction.isBlank()) {
            errorBean.triggerTransactionErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                        MyApp.CONTEXT.getString(R.string.mbop0607_page_label_trigger_transaction)
                    )
                )
            )
        }

        // 取引金融機関、預金状況、貸金状況どれかが入力された場合は、３つ必須入力となる
        if (viewStates.financialInstitution.isNotBlank() || viewStates.depositStatus.isNotBlank() ||
            viewStates.loanStatus.isNotBlank()
        ) {
            if (viewStates.financialInstitution.isBlank()) {
                errorBean.financialInstitutionErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0607_page_label_financial_institution)
                        )
                    )
                )
            } else {
                if (!viewStates.financialInstitution.isPersonNameOther()) {
                    errorBean.financialInstitutionErrorFlag = true
                    viewStates = viewStates.copy(errorBean = errorBean)
                    viewStates = viewStates.copy(isError = true)
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MessageReplaceUtils.messageReplace(
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                                MyApp.CONTEXT.getString(R.string.mbop0607_page_label_financial_institution)
                            )
                        )
                    )
                }
            }

            // 取引金融機関　預金状況が空白場合
            if (viewStates.depositStatus.isBlank()) {
                errorBean.depositStatusErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0607_page_label_deposit_status)
                        )
                    )
                )
            } else if (!viewStates.depositStatus.isHalfNum()) {
                errorBean.depositStatusErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                            MyApp.CONTEXT.getString(R.string.mbop0607_page_label_deposit_status)
                        )
                    )
                )
            }

            // 取引金融機関　貸金状況が空白場合
            if (viewStates.loanStatus.isBlank()) {
                errorBean.loanStatusErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0607_page_label_loan_status)
                        )
                    )
                )
            } else if (!viewStates.loanStatus.isHalfNum()) {
                errorBean.loanStatusErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                            MyApp.CONTEXT.getString(R.string.mbop0607_page_label_loan_status)
                        )
                    )
                )
            }
        }

        if (!viewStates.isError) {
            // パラメータセット
            paramSet(viewStates.requestBean)
            // 画面IDとイベントID設定
            PreferenceUtil.setScreenIDAndEventID("MBOP0607", "E04")
            // お客様情報入力
            viewModelScope.launch {
                flow {
                    ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, viewStates.requestBean.convertToParams().toJson())
                    emit(webService.AB0706())
                }.map {
                    // 画面入力した情報をRealmに保存する
                    setRealmInfo(viewStates.requestBean.selfempDto)
                    if (PreferenceUtil.getPreferenceBooleanValue(ConstUtil.OPENED_EDIT_INFO_FLAG)) {
                        PreferenceUtil.setPreferenceBooleanValue(ConstUtil.OPENED_EDIT_INFO_FLAG, false)
                        RouteUtil.navTo(
                            RouteName.MBOP1002Page
                        )
                    } else {
                        RouteUtil.navTo(
                            RouteName.MBCO0201Page,
                            MAIL_CONFIRM_TYPE_SOLE_PROPRIETOR
                        )
                    }
                }.catch {
                    ErrorUtil().apiErrorCatch(it.message.toString())
                }.collect()
            }
        } else {
            coroutineScope.launch {
                scrollState.animateScrollTo(0)
            }
        }
    }

    /**
     * 画面入力した情報をRealmに保存する
     */
    fun setRealmInfo(soleProprietor: SoleProprietorBean) {
        val accountOpeningAB0706 = dbService.findAll(AccountOpeningAB0706::class.java)
        if (accountOpeningAB0706.isNotEmpty()) {
            val customerInformation =
                accountOpeningAB0706[0]?.customerInformation?.fromJson<SoleProprietorBean>()!!
            customerInformation.phoneType = viewStates.phoneType
            customerInformation.phoneNumOneFirst = viewStates.phoneFirst
            customerInformation.phoneNumOneMid = viewStates.phoneSecond
            customerInformation.phoneNumOneLast = viewStates.phoneThird
            customerInformation.businessPhoneType = viewStates.businessPhoneType
            customerInformation.businessPhoneNumFirst = viewStates.businessPhoneFirst
            customerInformation.businessPhoneNumMid = viewStates.businessPhoneSecond
            customerInformation.businessPhoneNumLast = viewStates.businessPhoneThird
            customerInformation.transactPurpose = viewStates.transactionPurpose
            customerInformation.transactPurposeOther = viewStates.transactionPurposeOther
            customerInformation.transactPurposeDetail = viewStates.transactionPurposeDetail
            customerInformation.businessDescription = viewStates.businessContent
            customerInformation.businessDescriptionOther = viewStates.businessContentOther
            customerInformation.handingItem = viewStates.itemsHandled
            customerInformation.mainlyTradePurchase = viewStates.majorCustomersPurchasing
            customerInformation.mainlyTradeSale = viewStates.majorCustomersSales
            customerInformation.preferredTrade = viewStates.preferredTrade
            customerInformation.otherBusinessWishes = viewStates.preferredTradeOther
            customerInformation.transactionTrigger = viewStates.triggerTransaction
            customerInformation.financialInstitution = viewStates.financialInstitution
            customerInformation.financialInstitutionDepositStatus = viewStates.depositStatus
            customerInformation.financialInstitutionLoanStatus = viewStates.loanStatus
            dbService.deleteAll(AccountOpeningAB0706::class.java)
            val ab0706 = AccountOpeningAB0706()
            ab0706.id = UUID.randomUUID().toString()
            ab0706.customerInformation = customerInformation.toJson()
            dbService.create(ab0706)
        } else {
            dbService.deleteAll(AccountOpeningAB0706::class.java)
            val ab0706 = AccountOpeningAB0706()
            ab0706.id = UUID.randomUUID().toString()
            ab0706.customerInformation = soleProprietor.toJson()
            dbService.create(ab0706)
        }
    }

    /**
     * 初期化
     */
    init {
        val accountOpeningAB0706 = dbService.findAll(AccountOpeningAB0706::class.java)
        if (accountOpeningAB0706.isNotEmpty()) {
            val customerInformation = accountOpeningAB0706[0]?.customerInformation?.fromJson<SoleProprietorBean>()!!
            viewStates = viewStates.copy(
                phoneType = customerInformation.phoneType,
                phoneTypeLabel = getPhoneTypeName(customerInformation.phoneType),
                phoneFirst = customerInformation.phoneNumOneFirst,
                phoneSecond = customerInformation.phoneNumOneMid,
                phoneThird = customerInformation.phoneNumOneLast,
                businessPhoneType = customerInformation.businessPhoneType,
                businessPhoneTypeLabel = getPhoneTypeName(customerInformation.businessPhoneType),
                businessPhoneFirst = customerInformation.businessPhoneNumFirst,
                businessPhoneSecond = customerInformation.businessPhoneNumMid,
                businessPhoneThird = customerInformation.businessPhoneNumLast,
                transactionPurpose = customerInformation.transactPurpose,
                transactionPurposeLabel = getTransactPurposeName(customerInformation.transactPurpose),
                transactionPurposeOther = customerInformation.transactPurposeOther,
                transactionPurposeDetail = customerInformation.transactPurposeDetail,
                businessContent = customerInformation.businessDescription,
                businessContentLabel = getBusinessDescriptionName(customerInformation.businessDescription),
                businessContentOther = customerInformation.businessDescriptionOther,
                itemsHandled = customerInformation.handingItem,
                majorCustomersPurchasing = customerInformation.mainlyTradePurchase,
                majorCustomersSales = customerInformation.mainlyTradeSale,
                preferredTrade = customerInformation.preferredTrade,
                preferredTradeLabel = getPreferredTradeName(customerInformation.preferredTrade),
                preferredTradeOther = customerInformation.otherBusinessWishes,
                triggerTransaction = customerInformation.transactionTrigger,
                triggerTransactionLabel = getTransactionTriggerName(customerInformation.transactionTrigger),
                financialInstitution = customerInformation.financialInstitution,
                depositStatus = customerInformation.financialInstitutionDepositStatus,
                loanStatus = customerInformation.financialInstitutionLoanStatus,
            )
        }

        // 復元データを取得する
        getRestoreData()
    }

    /**
     * ご自宅の電話番号の切替
     */
    fun onPhoneTypeChange(phoneType: CodeBean) {
        viewStates = viewStates.copy(phoneType = phoneType.code, phoneTypeLabel = phoneType.value)
    }

    /**
     * 事業先電話番号の切替
     */
    fun onBusinessPhoneTypeChange(businessPhoneType: CodeBean) {
        viewStates = viewStates.copy(
            businessPhoneType = businessPhoneType.code,
            businessPhoneTypeLabel = businessPhoneType.value
        )
    }

    /**
     * 取引目的（事業先）の切替
     */
    fun onTransactionPurposeChange(transactionPurpose: CodeBean) {
        viewStates = viewStates.copy(
            transactionPurpose = transactionPurpose.code,
            transactionPurposeLabel = transactionPurpose.value
        )
        if (transactionPurpose.code != TransactPurpose.OTHERS.code)
            viewStates = viewStates.copy(transactionPurposeOther = "")
    }

    /**
     * 事業内容の切替
     */
    fun onBusinessContentChange(businessContent: CodeBean) {
        viewStates = viewStates.copy(
            businessContent = businessContent.code,
            businessContentLabel = businessContent.value
        )
        if (businessContent.code != BusinessDescription.OTHERS.code)
            viewStates = viewStates.copy(businessContentOther = "")
    }

    /**
     * 当金庫との主な取引希望の切替
     */
    fun onPreferredTradeChange(preferredTrade: CodeBean) {
        viewStates = viewStates.copy(
            preferredTrade = preferredTrade.code,
            preferredTradeLabel = preferredTrade.value
        )
        if (preferredTrade.code != PreferredTrade.OTHERS.code)
            viewStates = viewStates.copy(preferredTradeOther = "")
    }

    /**
     * 取引のきっかけの切替
     */
    fun onTriggerTransactionChange(triggerTransaction: CodeBean) {
        viewStates = viewStates.copy(
            triggerTransaction = triggerTransaction.code,
            triggerTransactionLabel = triggerTransaction.value
        )
    }

    /**
     * パラメータセット
     */
    fun paramSet(bean: MBOP0601RequestBean) {
        // 口座開設申込情報（個人事業主）
        val soleProprietor = SoleProprietorBean()
        // 受付番号
        soleProprietor.receiptNumber = KeyStoreUtil().getFromKeyStore(ConstUtil.RECEIPT_NUMBER)
        soleProprietor.updateType = UpdateType.UPDATE_TYPE_025.code
        soleProprietor.phoneType = viewStates.phoneType
        soleProprietor.phoneNumOneFirst = viewStates.phoneFirst
        soleProprietor.phoneNumOneMid = viewStates.phoneSecond
        soleProprietor.phoneNumOneLast = viewStates.phoneThird
        soleProprietor.businessPhoneType = viewStates.businessPhoneType
        soleProprietor.businessPhoneNumFirst = viewStates.businessPhoneFirst
        soleProprietor.businessPhoneNumMid = viewStates.businessPhoneSecond
        soleProprietor.businessPhoneNumLast = viewStates.businessPhoneThird
        soleProprietor.transactPurpose = viewStates.transactionPurpose
        soleProprietor.transactPurposeOther = viewStates.transactionPurposeOther
        soleProprietor.transactPurposeDetail = viewStates.transactionPurposeDetail
        soleProprietor.businessDescription = viewStates.businessContent
        soleProprietor.businessDescriptionOther = viewStates.businessContentOther
        soleProprietor.handingItem = viewStates.itemsHandled
        soleProprietor.mainlyTradePurchase = viewStates.majorCustomersPurchasing
        soleProprietor.mainlyTradeSale = viewStates.majorCustomersSales
        soleProprietor.preferredTrade = viewStates.preferredTrade
        soleProprietor.otherBusinessWishes = viewStates.preferredTradeOther
        soleProprietor.transactionTrigger = viewStates.triggerTransaction
        soleProprietor.financialInstitution = viewStates.financialInstitution
        soleProprietor.financialInstitutionDepositStatus = viewStates.depositStatus
        soleProprietor.financialInstitutionLoanStatus = viewStates.loanStatus
        // 人格区分
        bean.personType = PreferenceUtil.getPreferenceStringValue(ConstUtil.PERSONALITY_FLAG).toString()
        // 受付番号
        bean.receiptNumber = KeyStoreUtil().getFromKeyStore(ConstUtil.RECEIPT_NUMBER)
        // 口座開設申込情報（個人事業主）
        bean.selfempDto = soleProprietor
        // 更新パターン
        bean.updateType = UpdateType.UPDATE_TYPE_025.code
    }
}

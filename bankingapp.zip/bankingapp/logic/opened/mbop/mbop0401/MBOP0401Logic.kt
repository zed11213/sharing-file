package jp.co.jsbank.mb.bankingapp.logic.opened.mbop.mbop0401

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import jp.co.jsbank.mb.bankingapp.bean.cashCard.mbcc.mbcc0301.MBCC0301RequestBean
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.system.master.UpdateType
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0401.MBOP0401PageState
import jp.co.jsbank.mb.bankingapp.utils.*
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/**
 * MBOP0401ロジック
 */
@HiltViewModel
class MBOP0401Logic @Inject constructor(
    private var webService: RestService
) : ViewModel() {

    // MBOP0401ステータス
    var viewStates by mutableStateOf(MBOP0401PageState())
        private set

    /**
     * 通帳デザイン選択
     */
    fun onBankbookPatternChange(bankbookPattern: String) {
        viewStates = viewStates.copy(cardPattern = bankbookPattern)
    }

    /**
     * 通帳パターン設定
     */
    fun bankbookPatternSignUp() {
        // 画面IDとイベントID設定
        PreferenceUtil.setScreenIDAndEventID("MBOP0401", "E02")
        val requestBean = MBCC0301RequestBean()
        // キャッシュカード種類
        requestBean.cashCardType = viewStates.cardPattern
        // 更新パターン
        requestBean.updateType = UpdateType.UPDATE_TYPE_007.code
        // 受付番号
        requestBean.receptionNumber = KeyStoreUtil().getFromKeyStore(ConstUtil.RECEIPT_NUMBER)
        // 人格区分
        requestBean.personType = PreferenceUtil.getPreferenceStringValue(ConstUtil.PERSONALITY_FLAG).toString()
        viewModelScope.launch {
            flow {
                ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, requestBean.toJson())
                emit(webService.AB0803())
            }.map {
                RouteUtil.navTo(
                    RouteName.MBCO0501Page,
                    ConstUtil.MAIL_CONFIRM_TYPE_INDIVIDUAL
                )
            }.catch {
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }
    }
}

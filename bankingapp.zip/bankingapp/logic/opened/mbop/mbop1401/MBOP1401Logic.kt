package jp.co.jsbank.mb.bankingapp.logic.opened.mbop.mbop1401

import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.bean.common.CorporationBean
import jp.co.jsbank.mb.bankingapp.bean.opened.mbop.mbop1401.FileInfo
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.repositories.db.common.findAll
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.EPassBookAB0701
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.system.MyApp
import jp.co.jsbank.mb.bankingapp.system.master.DocumentType
import jp.co.jsbank.mb.bankingapp.system.master.UpdateType
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop1401.MBOP1401PageState
import jp.co.jsbank.mb.bankingapp.utils.*
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.HALF_HYPHEN
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.JPEG
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.PERSONALITY_FLAG
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.RECEIPT_NUMBER
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.ZoneOffset
import javax.inject.Inject

/**
 * MBOP1401ロジック
 */
@HiltViewModel
class MBOP1401Logic @Inject constructor(
    private var webService: RestService
) : ViewModel() {

    /**
     * MBOP1401ステータス
     */
    var viewStates by mutableStateOf(MBOP1401PageState())
        private set

    /**
     * 初期化
     */
    init {
        // 復元データを取得する
        getRestoreData()
    }

    // 復元データを取得する
    private fun getRestoreData() {
        val accountOpeningAB0701 = MyApp.INSTANCE.findAll(EPassBookAB0701::class.java)
        if (accountOpeningAB0701.isNotEmpty() && !MainActivity.HAS_RECOVERY_FLAG) {
            val corporationInfo = accountOpeningAB0701[0]?.corporation?.fromJson<CorporationBean>()!!
            corporationInfo.businessDocuments.forEachIndexed { index, item ->
                viewStates.requestBean.fileStreams.add(
                    FileInfo(
                        documentsType = item.documentsType,
                        fileName = item.fileName,
                        fileStream = item.fileStream
                    ),
                )

                when (index) {
                    0 -> {
                        viewStates = viewStates.copy(
                            certificateOne = mutableStateOf(base64ToBitmap(item.fileStream)),
                            certificateOneBitmap = mutableStateOf(base64ToBitmap(item.fileStream)),
                            certificateOneUri = mutableStateOf(null)
                        )
                    }
                    1 -> {
                        viewStates = viewStates.copy(
                            certificateTwo = mutableStateOf(base64ToBitmap(item.fileStream)),
                            certificateTwoBitmap = mutableStateOf(base64ToBitmap(item.fileStream)),
                            certificateTwoUri = mutableStateOf(null)
                        )
                    }
                    2 -> {
                        viewStates = viewStates.copy(
                            certificateThree = mutableStateOf(base64ToBitmap(item.fileStream)),
                            certificateThreeBitmap = mutableStateOf(base64ToBitmap(item.fileStream)),
                            certificateThreeUri = mutableStateOf(null)
                        )
                    }
                    3 -> {
                        viewStates = viewStates.copy(
                            certificateFour = mutableStateOf(base64ToBitmap(item.fileStream)),
                            certificateFourBitmap = mutableStateOf(base64ToBitmap(item.fileStream)),
                            certificateFourUri = mutableStateOf(null)
                        )
                    }
                    4 -> {
                        viewStates = viewStates.copy(
                            certificateFive = mutableStateOf(base64ToBitmap(item.fileStream)),
                            certificateFiveBitmap = mutableStateOf(base64ToBitmap(item.fileStream)),
                            certificateFiveUri = mutableStateOf(null)
                        )
                    }
                }
            }

            // 復元処理済みフラグ
            MainActivity.HAS_RECOVERY_FLAG = true
            MainActivity.SHOW_RETURN_BUTTON_FLAG = true
        }
    }

    /**
     * 画像クリア
     */
    fun doClear(type: String) {
        when (type) {
            "3" -> viewStates = viewStates.copy(certificateOne = mutableStateOf(null))
            "4" -> viewStates = viewStates.copy(certificateTwo = mutableStateOf(null))
            "5" -> viewStates = viewStates.copy(certificateThree = mutableStateOf(null))
            "6" -> viewStates = viewStates.copy(certificateFour = mutableStateOf(null))
            "7" -> viewStates = viewStates.copy(certificateFive = mutableStateOf(null))
        }
    }

    /**
     * 画像設定
     */
    fun doSet(result: Any?) {
        when (viewStates.focusIndex) {
            "3" -> {
                viewStates = viewStates.copy(certificateOne = mutableStateOf(result))
            }
            "4" -> {
                viewStates = viewStates.copy(certificateTwo = mutableStateOf(result))
            }
            "5" -> {
                viewStates = viewStates.copy(certificateThree = mutableStateOf(result))
            }
            "6" -> {
                viewStates = viewStates.copy(certificateFour = mutableStateOf(result))
            }
            "7" -> {
                viewStates = viewStates.copy(certificateFive = mutableStateOf(result))
            }
        }
    }

    /**
     * 画像設定Bitmap
     */
    fun doSetBitmap(result: Bitmap?) {
        when (viewStates.focusIndex) {
            "3" -> {
                viewStates = viewStates.copy(
                    certificateOneBitmap = mutableStateOf(result),
                    certificateOneUri = mutableStateOf(null)
                )
            }
            "4" -> {
                viewStates = viewStates.copy(
                    certificateTwoBitmap = mutableStateOf(result),
                    certificateTwoUri = mutableStateOf(null)
                )
            }
            "5" -> {
                viewStates = viewStates.copy(
                    certificateThreeBitmap = mutableStateOf(result),
                    certificateThreeUri = mutableStateOf(null)
                )
            }
            "6" -> {
                viewStates = viewStates.copy(
                    certificateFourBitmap = mutableStateOf(result),
                    certificateFourUri = mutableStateOf(null)
                )
            }
            "7" -> {
                viewStates = viewStates.copy(
                    certificateFiveBitmap = mutableStateOf(result),
                    certificateFiveUri = mutableStateOf(null)
                )
            }
        }
    }

    /**
     * 画像設定Uri
     */
    fun doSetUri(result: Uri?) {
        when (viewStates.focusIndex) {
            "3" -> {
                viewStates = viewStates.copy(
                    certificateOneBitmap = mutableStateOf(null),
                    certificateOneUri = mutableStateOf(result)
                )
            }
            "4" -> {
                viewStates = viewStates.copy(
                    certificateTwoBitmap = mutableStateOf(null),
                    certificateTwoUri = mutableStateOf(result)
                )
            }
            "5" -> {
                viewStates = viewStates.copy(
                    certificateThreeBitmap = mutableStateOf(null),
                    certificateThreeUri = mutableStateOf(result)
                )
            }
            "6" -> {
                viewStates = viewStates.copy(
                    certificateFourBitmap = mutableStateOf(null),
                    certificateFourUri = mutableStateOf(result)
                )
            }
            "7" -> {
                viewStates = viewStates.copy(
                    certificateFiveBitmap = mutableStateOf(null),
                    certificateFiveUri = mutableStateOf(result)
                )
            }
        }
    }

    /**
     * フォーカスリセット
     */
    fun resetFocusIndex(focusIndex: String) {
        viewStates = viewStates.copy(focusIndex = focusIndex)
    }

    /**
     * 次への処理
     */
    fun doNext() {
        viewStates = viewStates.copy(errorMessage = "")
        // 登記事項証明書の必須チェック
        if (viewStates.certificateOne.value == null && viewStates.certificateTwo.value == null &&
            viewStates.certificateThree.value == null && viewStates.certificateFour.value == null &&
            viewStates.certificateFive.value == null
        ) {
            viewStates = viewStates.copy(errorMessage = "登記事項証明書を添付してください。")
            return
        }
        var fileStreamOne = ""
        var fileStreamTwo = ""
        var fileStreamThree = ""
        var fileStreamFour = ""
        var fileStreamFive = ""
        if (viewStates.certificateOne.value != null) {
            fileStreamOne = if (viewStates.certificateOneBitmap.value != null)
                bitmapToBase64(viewStates.certificateOneBitmap.value!!)
            else
                uriToBase64(viewStates.certificateOneUri.value!!)

            if (fileStreamOne.isEmpty()) {
                viewStates = viewStates.copy(errorMessage = MyApp.CONTEXT.getString(R.string.MSG_ID_MB005004V))
                return
            }
        }
        if (viewStates.certificateTwo.value != null) {
            fileStreamTwo = if (viewStates.certificateTwoBitmap.value != null)
                bitmapToBase64(viewStates.certificateTwoBitmap.value!!)
            else
                uriToBase64(viewStates.certificateTwoUri.value!!)

            if (fileStreamTwo.isEmpty()) {
                viewStates = viewStates.copy(errorMessage = MyApp.CONTEXT.getString(R.string.MSG_ID_MB005004V))
                return
            }
        }

        if (viewStates.certificateThree.value != null) {
            fileStreamThree = if (viewStates.certificateThreeBitmap.value != null)
                bitmapToBase64(viewStates.certificateThreeBitmap.value!!)
            else
                uriToBase64(viewStates.certificateThreeUri.value!!)

            if (fileStreamThree.isEmpty()) {
                viewStates = viewStates.copy(errorMessage = MyApp.CONTEXT.getString(R.string.MSG_ID_MB005004V))
                return
            }
        }

        if (viewStates.certificateFour.value != null) {
            fileStreamFour = if (viewStates.certificateFourBitmap.value != null)
                bitmapToBase64(viewStates.certificateFourBitmap.value!!)
            else
                uriToBase64(viewStates.certificateFourUri.value!!)

            if (fileStreamFour.isEmpty()) {
                viewStates = viewStates.copy(errorMessage = MyApp.CONTEXT.getString(R.string.MSG_ID_MB005004V))
                return
            }
        }

        if (viewStates.certificateFive.value != null) {
            fileStreamFive = if (viewStates.certificateFiveBitmap.value != null)
                bitmapToBase64(viewStates.certificateFiveBitmap.value!!)
            else
                uriToBase64(viewStates.certificateFiveUri.value!!)

            if (fileStreamFive.isEmpty()) {
                viewStates = viewStates.copy(errorMessage = MyApp.CONTEXT.getString(R.string.MSG_ID_MB005004V))
                return
            }
        }

        // 画面IDとイベントID設定
        PreferenceUtil.setScreenIDAndEventID("MBOP1401", "E02")
        // 人格区分
        viewStates.requestBean.personType = PreferenceUtil.getPreferenceStringValue(PERSONALITY_FLAG).toString()
        // 受付番号
        viewStates.requestBean.receiptNumber = KeyStoreUtil().getFromKeyStore(RECEIPT_NUMBER)
        // 更新パターン
        viewStates.requestBean.updateType = UpdateType.UPDATE_TYPE_017.code
        viewStates.requestBean.fileStreams = mutableListOf()
        // ファイルリスト
        if (viewStates.requestBean.fileStreams.isEmpty()) {
            // 登記事項証明書一
            if (viewStates.certificateOne.value != null) {
                viewStates.requestBean.fileStreams.add(
                    FileInfo(
                        documentsType = DocumentType.CERTIFICATE.code,
                        fileName = DocumentType.CERTIFICATE.code + HALF_HYPHEN + LocalDateTime.now()
                            .toInstant(ZoneOffset.UTC).toEpochMilli().toString() + JPEG,
                        fileStream = fileStreamOne
                    ),
                )
            }
            // 登記事項証明書二
            if (viewStates.certificateTwo.value != null) {
                viewStates.requestBean.fileStreams.add(
                    FileInfo(
                        documentsType = DocumentType.CERTIFICATE.code,
                        fileName = DocumentType.CERTIFICATE.code + HALF_HYPHEN + LocalDateTime.now()
                            .toInstant(ZoneOffset.UTC).toEpochMilli().toString() + JPEG,
                        fileStream = fileStreamTwo
                    ),
                )
            }
            // 登記事項証明書三
            if (viewStates.certificateThree.value != null) {
                viewStates.requestBean.fileStreams.add(
                    FileInfo(
                        documentsType = DocumentType.CERTIFICATE.code,
                        fileName = DocumentType.CERTIFICATE.code + HALF_HYPHEN + LocalDateTime.now()
                            .toInstant(ZoneOffset.UTC).toEpochMilli().toString() + JPEG,
                        fileStream = fileStreamThree
                    ),
                )
            }
            // 登記事項証明書四
            if (viewStates.certificateFour.value != null) {
                viewStates.requestBean.fileStreams.add(
                    FileInfo(
                        documentsType = DocumentType.CERTIFICATE.code,
                        fileName = DocumentType.CERTIFICATE.code + HALF_HYPHEN + LocalDateTime.now()
                            .toInstant(ZoneOffset.UTC).toEpochMilli().toString() + JPEG,
                        fileStream = fileStreamFour
                    ),
                )
            }
            // 登記事項証明書五
            if (viewStates.certificateFive.value != null) {
                viewStates.requestBean.fileStreams.add(
                    FileInfo(
                        documentsType = DocumentType.CERTIFICATE.code,
                        fileName = DocumentType.CERTIFICATE.code + HALF_HYPHEN + LocalDateTime.now()
                            .toInstant(ZoneOffset.UTC).toEpochMilli().toString() + JPEG,
                        fileStream = fileStreamFive
                    ),
                )
            }
        }
        // AB0702 ICOSへ本人確認書類格納を呼び出す
        LoadingUtil.setLoadingValue(value = true, type = false)
        viewModelScope.launch {
            flow {
                ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_PUT, viewStates.requestBean.toJson())
                emit(webService.AB0702())
            }.map {
                LoadingUtil.setLoadingValue(value = false, type = false)
                // ステップ3画面へ遷移する
                RouteUtil.navTo(
                    RouteName.MBOP0203Page,
                )
            }.catch {
                LoadingUtil.setLoadingValue(value = false, type = false)
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }
    }
}

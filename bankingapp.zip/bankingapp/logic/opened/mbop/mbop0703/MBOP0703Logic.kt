package jp.co.jsbank.mb.bankingapp.logic.opened.mbop.mbop0703

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import jp.co.jsbank.mb.bankingapp.bean.opened.mbop.mbop0701.BranchStore
import jp.co.jsbank.mb.bankingapp.bean.opened.mbop.mbop0701.DepartmentStore
import jp.co.jsbank.mb.bankingapp.bean.opened.mbop.mbop0703.MBOP0703RequestBean
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.system.Config.isRetail
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.system.master.CandidateFlag
import jp.co.jsbank.mb.bankingapp.system.master.PersonalityFlag
import jp.co.jsbank.mb.bankingapp.system.master.UpdateType
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0703.MBOP0703PageState
import jp.co.jsbank.mb.bankingapp.utils.*
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.OPENED_EDIT_INFO_FLAG
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.OPENED_HOPE_DEPARTMENT
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.PERSONALITY_FLAG
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.REASON
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.REASON_OTHER
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/**
 * MBOP0703ロジック
 */
@HiltViewModel
class MBOP0703Logic @Inject constructor(
    private var webService: RestService
) : ViewModel() {

    /**
     * ステータス
     */
    var viewStates by mutableStateOf(MBOP0703PageState())
        private set

    init {
        // 遷移元画面渡すパラメータ取得
        val arguments = MainActivity.NAVCTRL?.currentBackStackEntry?.arguments?.get(ConstUtil.DATA)
        val alternateFlg =
            MainActivity.NAVCTRL?.currentBackStackEntry?.arguments?.get(ConstUtil.ALTERNATE_FLG).toString()
        viewStates = viewStates.copy(alternateFlg = alternateFlg)
        if (arguments != null) {
            // 候補有り場合
            viewStates = if (alternateFlg == CandidateFlag.HAS_CANDIDATE.code) {
                viewStates.copy(departmentStore = arguments.toString().fromJson<DepartmentStore>()!!)
            } else {
                viewStates.copy(branchStore = arguments.toString().fromJson<BranchStore>()!!)
            }
        }
    }

    /**
     * 希望店設定
     */
    fun setDepartment() {
        // 画面IDとイベントID設定
        PreferenceUtil.setScreenIDAndEventID("MBOP0703", "E02")
        viewModelScope.launch {
            val personalityFlag = PreferenceUtil.getPreferenceStringValue(PERSONALITY_FLAG).toString()
            val bean = MBOP0703RequestBean(
                receptionNumber = KeyStoreUtil().getFromKeyStore(ConstUtil.RECEIPT_NUMBER),
                personType = PreferenceUtil.getPreferenceStringValue(PERSONALITY_FLAG).toString(),
                hopeDepartmentStore = if (viewStates.alternateFlg == CandidateFlag.HAS_CANDIDATE.code)
                    viewStates.departmentStore.branchNumber else viewStates.branchStore.branchNumber,
                reasonToOpenAccAnotherBranch = PreferenceUtil.getPreferenceStringValue(REASON).toString(),
                reasonToOpenAccAnotherBranchOther = PreferenceUtil.getPreferenceStringValue(REASON_OTHER).toString(),
                updateType = when (personalityFlag) {
                    PersonalityFlag.INDIVIDUAL_OTHER.code -> UpdateType.UPDATE_TYPE_004.code
                    PersonalityFlag.INDIVIDUAL_BUSINESS.code -> UpdateType.UPDATE_TYPE_022.code
                    else -> UpdateType.UPDATE_TYPE_012.code
                }
            )
            flow {
                ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, bean.toJson())
                emit(webService.AB0709())
            }.map {
                PreferenceUtil.setPreferenceStringValue(
                    OPENED_HOPE_DEPARTMENT,
                    if (viewStates.alternateFlg == CandidateFlag.HAS_CANDIDATE.code)
                        viewStates.departmentStore.branchKanjiName else viewStates.branchStore.branchKanjiName
                )
                if (PreferenceUtil.getPreferenceBooleanValue(OPENED_EDIT_INFO_FLAG)) {
                    PreferenceUtil.setPreferenceBooleanValue(OPENED_EDIT_INFO_FLAG, false)
                    RouteUtil.navTo(
                        when {
                            PersonalityFlag.CORPORATION.code == personalityFlag -> RouteName.MBOP1003Page
                            PersonalityFlag.INDIVIDUAL_BUSINESS.code == personalityFlag -> RouteName.MBOP1002Page
                            else -> RouteName.MBOP1001Page
                        }
                    )
                } else {
                    if (isRetail()) {
                        RouteUtil.navTo(
                            RouteName.MBOP0401Page
                        )
                    } else {
                        RouteUtil.navTo(
                            RouteName.MBOP0301Page
                        )
                    }
                }
            }.catch {
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }
    }
}

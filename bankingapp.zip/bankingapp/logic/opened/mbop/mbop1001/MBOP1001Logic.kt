package jp.co.jsbank.mb.bankingapp.logic.opened.mbop.mbop1001

import androidx.compose.foundation.ScrollState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import io.realm.Realm
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import javax.inject.Inject
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.bean.common.Individual
import jp.co.jsbank.mb.bankingapp.bean.opened.mbop.mbop1201.MBOP1201RequestBean
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.repositories.db.common.deleteAll
import jp.co.jsbank.mb.bankingapp.repositories.db.common.findAll
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.*
import jp.co.jsbank.mb.bankingapp.system.Config
import jp.co.jsbank.mb.bankingapp.system.MyApp
import jp.co.jsbank.mb.bankingapp.system.master.Occupation
import jp.co.jsbank.mb.bankingapp.system.master.PersonalityFlag
import jp.co.jsbank.mb.bankingapp.system.master.TransactPurpose
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop1001.MBOP1001ErrorInformation
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop1001.MBOP1001PageState
import jp.co.jsbank.mb.bankingapp.utils.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/**
 * MBOP1001ロジック
 */
@HiltViewModel
class MBOP1001Logic @Inject constructor(
    private var webService: RestService
) : ViewModel() {

    /**
     * MBOP1001ステータス
     */
    var viewStates by mutableStateOf(MBOP1001PageState())
        private set

    /**
     * 暗証番号表示・非表示切替
     */
    fun pinShowChange(flag: Boolean) {
        viewStates = viewStates.copy(pinShowFlag = !flag)
    }

    /**
     * パスワード表示・非表示切替
     */
    fun passwordShowChange(flag: Boolean) {
        viewStates = viewStates.copy(passwordShowFlag = !flag)
    }

    /**
     * ロカールDB
     */
    private var dbService: Realm = MyApp.INSTANCE
    /**
     * 初期化
     */
    fun doInit() {
        PreferenceUtil.setPreferenceBooleanValue(ConstUtil.EDIT_FLAG, false)
        // お客様情報
        val accountOpeningAB0706 = dbService.findAll(AccountOpeningAB0706::class.java)
        // お勤め先情報
        val accountOpeningAB0703 = dbService.findAll(AccountOpeningAB0703::class.java)
        if (accountOpeningAB0706.isNotEmpty()) {
            val customerInformation = accountOpeningAB0706[0]?.customerInformation?.fromJson<Individual>()!!
            viewStates.individual = customerInformation
            if (
                customerInformation.occupation == Occupation.COMPANY_GROUP_OFFICER.code ||
                customerInformation.occupation == Occupation.COMPANY_GROUP_EMPLOYEE.code ||
                customerInformation.occupation == Occupation.CIVIL_SERVANT.code ||
                customerInformation.occupation == Occupation.SELF_EMPLOYED.code ||
                customerInformation.occupation == Occupation.PART_TEMPORARY_CONTRACT_EMPLOYEE.code ||
                customerInformation.occupation == Occupation.OTHERS.code
            ) {
                viewStates.showWorkPlace = true
            } else if (
                customerInformation.occupation == Occupation.STUDENT.code &&
                customerInformation.transactPurpose == TransactPurpose.SALARY_PENSION.code
            ) {
                viewStates.showWorkPlace = true
            } else if (
                customerInformation.occupation == Occupation.HOUSEWIFE_HOUSEHUSBAND.code &&
                customerInformation.transactPurpose == TransactPurpose.SALARY_PENSION.code
            ) {
                if (accountOpeningAB0703.isNotEmpty()) {
                    val workPlaceInformation = accountOpeningAB0703[0]?.workPlaceInformation?.fromJson<Individual>()!!
                    if (workPlaceInformation.wpZipCode.isNotBlank()) {
                        viewStates.showWorkPlace = true
                    }
                }
            }
            if (customerInformation.occupation == Occupation.STUDENT.code) {
                viewStates.showSchool = true
            }
        }
        if (accountOpeningAB0703.isNotEmpty()) {
            val workPlaceInformation = accountOpeningAB0703[0]?.workPlaceInformation?.fromJson<Individual>()!!
            viewStates.workPlaceInformation = workPlaceInformation
        }
        // 学校情報
        val accountOpeningAB0704 = dbService.findAll(AccountOpeningAB0704::class.java)
        if (accountOpeningAB0704.isNotEmpty()) {
            val schoolInformation = accountOpeningAB0704[0]?.schoolInformation?.fromJson<Individual>()!!
            viewStates.schoolInformation = schoolInformation
        }
    }

    /**
     * AB0720 申込完了
     */
    fun applicationCompletion(coroutineScope: CoroutineScope, scrollState: ScrollState) {
        // エラー情報初期化
        val errorBean = MBOP1001ErrorInformation()
        viewStates = viewStates.copy(isError = false, errorBean = errorBean, errMsgList = listOf())
        if (PreferenceUtil.getPreferenceStringValue(ConstUtil.OPENED_DEPARTMENT).toString().isBlank() &&
            PreferenceUtil.getPreferenceStringValue(ConstUtil.OPENED_HOPE_DEPARTMENT).isNullOrBlank()
        ) {
            errorBean.departmentErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002014V),
                        MyApp.CONTEXT.getString(R.string.mbop1001_page_label_desired_store)
                    )
                )
            )
        }
        if (viewStates.showWorkPlace && !(
            viewStates.individual.occupation == Occupation.HOUSEWIFE_HOUSEHUSBAND.code &&
                viewStates.individual.transactPurpose == TransactPurpose.SALARY_PENSION.code
            )
        ) {
            if (viewStates.workPlaceInformation.wpZipCode.isBlank()) {
                errorBean.workPlaceInformationErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002014V),
                            MyApp.CONTEXT.getString(R.string.mbop1001_page_work_place_information)
                        )
                    )
                )
            }
        }
        if (viewStates.showSchool) {
            if (viewStates.schoolInformation.schZipCode.isBlank()) {
                errorBean.schoolInformationErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002014V),
                            MyApp.CONTEXT.getString(R.string.mbop1001_page_school_information_message)
                        )
                    )
                )
            }
        }
        if (KeyStoreUtil().getFromKeyStore(ConstUtil.CC_PASSWORD).isEmpty()) {
            errorBean.ccPasswordErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002014V),
                        MyApp.CONTEXT.getString(R.string.mbop1001_page_label_pin)
                    )
                )
            )
        }
        if (!viewStates.isError) {
            // 画面IDとイベントID設定
            PreferenceUtil.setScreenIDAndEventID("MBOP1001", "E02")
            viewModelScope.launch {
                val bean = MBOP1201RequestBean(
                    // 人格区分
                    personType = if (Config.isRetail())
                        PersonalityFlag.INDIVIDUAL_OTHER.code
                    else
                        PreferenceUtil.getPreferenceStringValue(ConstUtil.PERSONALITY_FLAG).toString(),
                    // 受付番号
                    receiptNumber = KeyStoreUtil().getFromKeyStore(ConstUtil.RECEIPT_NUMBER),
                    // 申込日
                    applicationDate = LocalDateTime.now().format(
                        DateTimeFormatter.ofPattern(ConstUtil.DATE_FORMAT_YYYY_MM_DD_T_HH_MM_SS_MI)
                    ),
                )
                flow {
                    ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, bean.toJson())
                    emit(webService.AB0720())
                }.map {
                    // 本人情報削除処理
                    PreferenceUtil.removePreferenceStringValue(ConstUtil.EKYC_IMAGE_FRONT)
                    PreferenceUtil.removePreferenceStringValue(ConstUtil.EKYC_IMAGE_BACK)
                    PreferenceUtil.removePreferenceStringValue(ConstUtil.EKYC_IMAGE_TILTED)
                    PreferenceUtil.removePreferenceStringValue(ConstUtil.EKYC_IMAGE_SELF)
                    PreferenceUtil.removePreferenceStringValue(ConstUtil.EKYC_IMAGE_LIVENESS)
                    PreferenceUtil.removePreferenceStringValue(ConstUtil.CHOME)
                    KeyStoreUtil().saveToKeyStore(
                        ConstUtil.RECEIPT_NUMBER_ISSUE,
                        KeyStoreUtil().getFromKeyStore(ConstUtil.RECEIPT_NUMBER)
                    )
                    // 受付番号をクリア
                    KeyStoreUtil().saveToKeyStore(ConstUtil.RECEIPT_NUMBER, "")
                    PreferenceUtil.setPreferenceStringValue(ConstUtil.OPENED_HOPE_DEPARTMENT, "")
                    PreferenceUtil.setPreferenceStringValue(ConstUtil.OPENED_DEPARTMENT, "")
                    PreferenceUtil.removePreferenceStringValue(ConstUtil.REASON)
                    PreferenceUtil.removePreferenceStringValue(ConstUtil.REASON_OTHER)
                    // 入力情報クリア
                    dbService.deleteAll(AccountOpeningAB0706::class.java)
                    dbService.deleteAll(AccountOpeningAB0703::class.java)
                    dbService.deleteAll(AccountOpeningAB0704::class.java)
                    dbService.deleteAll(AccountOpeningAB0718::class.java)
                    dbService.deleteAll(AccountOpeningAB0719::class.java)
                    // MBOP1201　受付番号発行
                    RouteUtil.navTo(
                        RouteName.MBOP1201Page,
                    )
                }.catch {
                    ErrorUtil().apiErrorCatch(it.message.toString())
                }.collect()
            }
        } else {
            coroutineScope.launch {
                scrollState.animateScrollTo(0)
            }
        }
    }
}

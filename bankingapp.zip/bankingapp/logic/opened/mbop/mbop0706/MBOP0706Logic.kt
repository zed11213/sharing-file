package jp.co.jsbank.mb.bankingapp.logic.opened.mbop.mbop0706

import androidx.compose.foundation.ScrollState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.bean.common.CodeBean
import jp.co.jsbank.mb.bankingapp.bean.opened.mbop.mbop0701.BranchStore
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.system.MyApp
import jp.co.jsbank.mb.bankingapp.system.master.AnotherStoreOpenReason
import jp.co.jsbank.mb.bankingapp.system.master.CandidateFlag
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0706.MBOP0706ErrorInformation
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0706.MBOP0706PageState
import jp.co.jsbank.mb.bankingapp.utils.*
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isPersonNameOther
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * MBOP0706ロジック
 */
@HiltViewModel
class MBOP0706Logic @Inject constructor(
    private var webService: RestService
) : ViewModel() {

    /**
     * ステータス
     */
    var viewStates by mutableStateOf(MBOP0706PageState())
        private set

    /**
     * 初期化
     */
    init {
        // 画面IDとイベントID設定
        PreferenceUtil.setScreenIDAndEventID("MBOP0706", "E02")
        viewModelScope.launch {
            flow {
                ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST)
                emit(webService.AB0705())
            }.map {
                if (it.resultDto!!.branchList.isNotEmpty()) {
                    val deptList = mutableListOf<BranchStore>()
                    it.resultDto!!.branchList.forEach { item ->
                        deptList.add(
                            BranchStore(
                                bankCode = item.bankCode,
                                branchNumber = item.branchNumber,
                                branchKanjiName = item.branchKanjiName,
                                divisionType = item.divisionType,
                                branchInquiryType = item.branchInquiryType,
                                zipCode = item.zipCode,
                                branchKanjiAddress = item.branchKanjiAddress,
                                phoneNumber = item.phoneNumber,
                                branchGuide = item.branchGuide,
                                latitude = item.latitude,
                                longitude = item.longitude,
                                displayGroupName = item.displayGroupName,
                                displayOrder = item.displayOrder,
                            )
                        )
                    }
                    viewStates = viewStates.copy(deptList = deptList)
                    val newDeptList = if (deptList.size > 16) {
                        deptList.subList(0, 16)
                    } else {
                        deptList
                    }
                    viewStates = viewStates.copy(branchStoreList = newDeptList)
                }
            }.catch {
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }
    }

    /**
     * 経緯度取得
     */
    fun getLongitudeAndLatitude(bean: BranchStore, coroutineScope: CoroutineScope, scrollState: ScrollState) {
        // エラー情報初期化
        val errorBean = MBOP0706ErrorInformation()
        viewStates = viewStates.copy(isError = false)
        viewStates = viewStates.copy(errorBean = errorBean)
        viewStates = viewStates.copy(errorMessageList = listOf())

        // 理由が空白場合
        if (viewStates.reason.isBlank()) {
            errorBean.reasonErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                        MyApp.CONTEXT.getString(R.string.mbop0706_page_label_reason)
                    )
                )
            )
        }

        if (viewStates.reason == AnotherStoreOpenReason.OTHERS.code) {
            // 理由（その他）が空白場合
            if (viewStates.reasonOther.isBlank()) {
                errorBean.reasonOtherErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0706_page_label_reason_other)
                        )
                    )
                )
            } else if (!viewStates.reasonOther.isPersonNameOther()) {
                // 理由（その他）の全角チェック
                errorBean.reasonOtherErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                            MyApp.CONTEXT.getString(R.string.mbop0706_page_label_reason_other)
                        )
                    )
                )
            }
        }
        if (!viewStates.isError) {
            PreferenceUtil.setPreferenceStringValue(ConstUtil.REASON, viewStates.reason)
            PreferenceUtil.setPreferenceStringValue(ConstUtil.REASON_OTHER, viewStates.reasonOther)
            RouteUtil.navTo(RouteName.MBOP0703Page + "/${bean.toJson()}/" + CandidateFlag.NO_CANDIDATE_DOWN.code)
        } else {
            coroutineScope.launch {
                scrollState.animateScrollTo(0)
            }
        }
    }

    /**
     * インターネット支店
     */
//    fun goInternetShop(coroutineScope: CoroutineScope, scrollState: ScrollState) {
//        // エラー情報初期化
//        val errorBean = MBOP0706ErrorInformation()
//        viewStates = viewStates.copy(isError = false)
//        viewStates = viewStates.copy(errorBean = errorBean)
//        viewStates = viewStates.copy(errorMessageList = listOf())
//
//        // 理由が空白場合
//        if (viewStates.reason.isBlank()) {
//            errorBean.reasonErrorFlag = true
//            viewStates = viewStates.copy(errorBean = errorBean)
//            viewStates = viewStates.copy(isError = true)
//            viewStates = viewStates.copy(
//                errorMessageList = viewStates.errorMessageList.plus(
//                    MessageReplaceUtils.messageReplace(
//                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
//                        MyApp.CONTEXT.getString(R.string.mbop0706_page_label_reason)
//                    )
//                )
//            )
//        }
//
//        if (viewStates.reason == AnotherStoreOpenReason.OTHERS.code) {
//            // 理由（その他）が空白場合
//            if (viewStates.reasonOther.isBlank()) {
//                errorBean.reasonOtherErrorFlag = true
//                viewStates = viewStates.copy(errorBean = errorBean)
//                viewStates = viewStates.copy(isError = true)
//                viewStates = viewStates.copy(
//                    errorMessageList = viewStates.errorMessageList.plus(
//                        MessageReplaceUtils.messageReplace(
//                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
//                            MyApp.CONTEXT.getString(R.string.mbop0706_page_label_reason_other)
//                        )
//                    )
//                )
//            } else if (!viewStates.reasonOther.isPersonNameOther()) {
//                // 理由（その他）の全角チェック
//                errorBean.reasonOtherErrorFlag = true
//                viewStates = viewStates.copy(errorBean = errorBean)
//                viewStates = viewStates.copy(isError = true)
//                viewStates = viewStates.copy(
//                    errorMessageList = viewStates.errorMessageList.plus(
//                        MessageReplaceUtils.messageReplace(
//                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
//                            MyApp.CONTEXT.getString(R.string.mbop0706_page_label_reason_other)
//                        )
//                    )
//                )
//            }
//        }
//        if (!viewStates.isError) {
//            PreferenceUtil.setPreferenceStringValue(ConstUtil.REASON, viewStates.reason)
//            PreferenceUtil.setPreferenceStringValue(ConstUtil.REASON_OTHER, viewStates.reasonOther)
//            RouteUtil.navTo(RouteName.MBOP0705Page)
//        } else {
//            coroutineScope.launch {
//                scrollState.animateScrollTo(0)
//            }
//        }
//    }

    /**
     * 明細もっと見る/リストを最小化するの切替
     */
    fun switchShowMore() {
        val showMore = viewStates.showMore
        viewStates = if (showMore) {
            viewStates.copy(
                showMore = false,
                branchStoreList = viewStates.deptList.subList(0, 16)
            )
        } else {
            viewStates.copy(
                showMore = true,
                branchStoreList = viewStates.deptList
            )
        }
    }

    /**
     * 理由の切替
     */
    fun onReasonChange(reason: CodeBean) {
        viewStates = viewStates.copy(
            reason = reason.code,
            reasonLabel = reason.value
        )
        if (reason.code != AnotherStoreOpenReason.OTHERS.code)
            viewStates = viewStates.copy(reasonOther = "")
    }
}

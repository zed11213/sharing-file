package jp.co.jsbank.mb.bankingapp.logic.opened.mbop.mbop0608

import androidx.compose.foundation.ScrollState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import io.realm.Realm
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.bean.common.CodeBean
import jp.co.jsbank.mb.bankingapp.bean.common.Individual
import jp.co.jsbank.mb.bankingapp.bean.common.PostCodeRequestBean
import jp.co.jsbank.mb.bankingapp.bean.common.PostCodeResponseBean
import jp.co.jsbank.mb.bankingapp.bean.common.categoryCodeList
import jp.co.jsbank.mb.bankingapp.logic.common.PostInfoSearchLogic
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.repositories.db.common.create
import jp.co.jsbank.mb.bankingapp.repositories.db.common.deleteAll
import jp.co.jsbank.mb.bankingapp.repositories.db.common.findAll
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.AccountOpeningAB0703
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.AccountOpeningAB0706
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.EPassBookAB0701
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.system.MyApp
import jp.co.jsbank.mb.bankingapp.system.master.*
import jp.co.jsbank.mb.bankingapp.system.master.Phone.Companion.getPhoneTypeName
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0608.MBOP0608ErrorInformation
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0608.MBOP0608PageState
import jp.co.jsbank.mb.bankingapp.utils.*
import jp.co.jsbank.mb.bankingapp.utils.CharacterUtil.addSplitMarkToBuildingRoom
import jp.co.jsbank.mb.bankingapp.utils.CharacterUtil.restoreFromBuildingRoom
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.MAIL_CONFIRM_TYPE_INDIVIDUAL
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.WORK_PLACE_POST_CODE
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isFixedTelePhone
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isHalfAngle
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isHalfNum
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isMobilePhone
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isPersonNameOther
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isPhone
import jp.co.jsbank.mb.bankingapp.utils.HalfToFullUtils.checkBanchiBuildingRoom
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import java.util.*
import javax.inject.Inject

/**
 * MBOP0608ロジック
 */
@HiltViewModel
class MBOP0608Logic @Inject constructor(
    private var webService: RestService
) : ViewModel() {

    /**
     * MBOP0608ステータス
     */
    var viewStates by mutableStateOf(MBOP0608PageState())
        private set

    /**
     * ロカールDB
     */
    private var dbService: Realm = MyApp.INSTANCE

    /**
     * 初期化
     */
    init {
        // 修正処理
        val accountOpeningAB0703 = dbService.findAll(AccountOpeningAB0703::class.java)
        if (accountOpeningAB0703.isNotEmpty()) {
            val workPlaceInformation = accountOpeningAB0703[0]?.workPlaceInformation?.fromJson<Individual>()!!
            // 候補表示フラグの判定：丁目カラムに「丁目」があれば、候補に表示されない
            var candidateFlag = false
            if (workPlaceInformation.wpCity.isNotBlank() && !workPlaceInformation.wpStreet.contains(
                    MyApp.CONTEXT.getString(
                            R.string.common_label_chome
                        )
                )
            ) {
                candidateFlag = true
            }
            // 住所漢字リスト
            val addressList: MutableList<CodeBean> = mutableListOf()
            // 住所漢字丁目なしリスト
            val addressNashiList: MutableList<CodeBean> = mutableListOf()
            // 市区町村プルダウン作成
            addressList.add(
                CodeBean(
                    code = "1",
                    value = workPlaceInformation.wpCity + workPlaceInformation.wpStreet
                )
            )
            addressNashiList.add(
                CodeBean(
                    code = "1",
                    value = workPlaceInformation.wpCity + workPlaceInformation.wpStreet
                )
            )

            // お客様情報
            val accountOpeningAB0706 = dbService.findAll(AccountOpeningAB0706::class.java)

            if (accountOpeningAB0706.isNotEmpty()) {
                val customerInformation = accountOpeningAB0706[0]?.customerInformation?.fromJson<Individual>()!!
                viewStates = viewStates.copy(
                    occupation = customerInformation.occupation,
                    transactPurpose = customerInformation.transactPurpose,
                    // 業種
                    category = if (customerInformation.category.isNotEmpty()) customerInformation.category else "",
                    categoryLabel = if (customerInformation.category.isNotEmpty())
                        categoryCodeList.first { it.code == customerInformation.category }.value else ""
                )
            }
            val wpBuilding = restoreFromBuildingRoom(workPlaceInformation.wpBuilding)
            viewStates = viewStates.copy(
                // お勤め先
                workPlace = workPlaceInformation.wpName,
                // 上場/非上場
                playOrNotPlay = workPlaceInformation.playOrNotPlay,
                playOrNotPlayLabel = PlayOrNotPlay.getName(workPlaceInformation.playOrNotPlay),
                // お勤め先の業種
                category = workPlaceInformation.category,
                categoryLabel = CategoryCode.getName(workPlaceInformation.category),
                // お勤め先の郵便番号
                postCode = workPlaceInformation.wpZipCode,
                postCodeOld = workPlaceInformation.wpZipCode,
                // お勤め先の都道府県
                prefectures = workPlaceInformation.wpPrefecture,
                // お勤め先の市区町村
                municipalities = workPlaceInformation.wpCity,
                // 丁目
                chome = workPlaceInformation.wpStreet,
                // 丁目
                chomeLabel = Chome.getChomeName(workPlaceInformation.wpStreet),
                // お勤め先の番地（全角）
                address = workPlaceInformation.wpAddress.trimEnd(),
                // お勤め先の建物名（全角）
                build = wpBuilding.first,
                // お勤め先の号室（全角）
                room = wpBuilding.second,
                // お勤め先の電話番号タイプ
                phoneType = workPlaceInformation.wpPhoneType,
                // お勤め先の電話番号タイプ
                phoneTypeLabel = getPhoneTypeName(workPlaceInformation.wpPhoneType),
                // お勤め先の電話番号
                phoneFirst = workPlaceInformation.wpPhoneFirst,
                // お勤め先の電話番号
                phoneSecond = workPlaceInformation.wpPhoneMid,
                // お勤め先の電話番号
                phoneThird = workPlaceInformation.wpPhoneLast,
                // ご本人の業務内容
                businessContentName = workPlaceInformation.businessContentName,
                businessContentNameLabel = BusinessContentName.getName(workPlaceInformation.businessContentName),
                // ご本人の業務内容(その他)
                businessContentOtherDescribeAnswer = workPlaceInformation.businessContentOtherDescribeAnswer,
                // 役職
                pstnName = workPlaceInformation.pstnName,
                pstnNameLabel = PstnName.getName(workPlaceInformation.pstnName),
                // 役職(その他)
                pstnOtherDescribeAnswer = workPlaceInformation.pstnOtherDescribeAnswer,
                // 年収
                annualIncome = workPlaceInformation.annualIncome,
                // 店舗名
                shop = workPlaceInformation.branchNumber,
                // 定期・定積口座番号
                account = workPlaceInformation.accountType,
                // 口座番号
                accountNumber = workPlaceInformation.accountNumber,
                // 候補表示フラグ
                candidateFlag = candidateFlag,
                // 市区町村プルダウン
                addressList = addressList,
                addressNashiList = addressNashiList,
                addressShowValue = "1",
                addressShowLabel = workPlaceInformation.wpCity + workPlaceInformation.wpStreet,
                candidateEnabled = false
            )
        } else {
            val dataBean = MainActivity.NAVCTRL?.currentBackStackEntry?.arguments?.get(ConstUtil.DATA)
                .toString().fromJson<Individual>()!!
            viewStates = viewStates.copy(
                account = dataBean.accountType,
                shop = dataBean.branchNumber,
                accountNumber = dataBean.accountNumber,
                occupation = dataBean.occupation,
                transactPurpose = dataBean.transactPurpose
            )
        }

        // 復元データを取得する
        getRestoreData()
    }

    // 復元データを取得する
    private fun getRestoreData() {
        val accountOpeningAB0701 = MyApp.INSTANCE.findAll(EPassBookAB0701::class.java)
        if (accountOpeningAB0701.isNotEmpty() && !MainActivity.HAS_RECOVERY_FLAG) {
            val individualInfo = accountOpeningAB0701[0]?.individual?.fromJson<Individual>()!!
            // 候補表示フラグの判定：丁目カラムに「丁目」があれば、候補に表示されない
            var candidateFlag = false
            if (individualInfo.wpCity.isNotBlank() && !individualInfo.wpStreet.contains(
                    MyApp.CONTEXT.getString(
                            R.string.common_label_chome
                        )
                )
            ) {
                candidateFlag = true
            }
            // 住所漢字リスト
            val addressList: MutableList<CodeBean> = mutableListOf()
            // 住所漢字丁目なしリスト
            val addressNashiList: MutableList<CodeBean> = mutableListOf()
            // 市区町村プルダウン作成
            addressList.add(
                CodeBean(
                    code = "1",
                    value = individualInfo.wpCity + individualInfo.wpStreet
                )
            )
            addressNashiList.add(
                CodeBean(
                    code = "1",
                    value = individualInfo.wpCity + individualInfo.wpStreet
                )
            )
            val wpBuilding = Pair<String, String>("", "") //restoreFromBuildingRoom(individualInfo.wpBuilding)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MyApp.CONTEXT.getString(R.string.mbop0608_page_label_rehabilitation_alert)
                )
            )
            viewStates = viewStates.copy(
                // お勤め先
                workPlace = individualInfo.wpName,
                // 上場/非上場
                playOrNotPlay = individualInfo.playOrNotPlay,
                playOrNotPlayLabel = PlayOrNotPlay.getName(individualInfo.playOrNotPlay),
                // お勤め先の業種
                category = individualInfo.category,
                categoryLabel = CategoryCode.getName(individualInfo.category),
                // お勤め先の郵便番号
                postCode = individualInfo.wpZipCode,
                // お勤め先の都道府県
                prefectures = individualInfo.wpPrefecture,
                // お勤め先の市区町村
                municipalities = individualInfo.wpCity,
                // 丁目
                chome = individualInfo.wpStreet,
                // 丁目
                chomeLabel = Chome.getChomeName(individualInfo.wpStreet),
                // お勤め先の番地（全角）
                address = individualInfo.wpAddress.trimEnd(),
                // お勤め先の建物名（全角）
                build = wpBuilding.first,
                // お勤め先の号室（全角）
                room = wpBuilding.second,
                // お勤め先の電話番号
                phoneType = individualInfo.wpPhoneType,
                // お勤め先の電話番号
                phoneTypeLabel = getPhoneTypeName(individualInfo.wpPhoneType),
                // お勤め先の電話番号1
                phoneFirst = individualInfo.wpPhoneFirst,
                // お勤め先の電話番号2
                phoneSecond = individualInfo.wpPhoneMid,
                // お勤め先の電話番号3
                phoneThird = individualInfo.wpPhoneLast,
                // ご本人の業務内容
                businessContentName = individualInfo.businessContentName,
                businessContentNameLabel = BusinessContentName.getName(individualInfo.businessContentName),
                // ご本人の業務内容(その他)
                businessContentOtherDescribeAnswer = individualInfo.businessContentOtherDescribeAnswer,
                // 役職
                pstnName = individualInfo.pstnName,
                pstnNameLabel = PstnName.getName(individualInfo.pstnName),
                // 役職(その他)
                pstnOtherDescribeAnswer = individualInfo.pstnOtherDescribeAnswer,
                // 年収
                annualIncome = individualInfo.annualIncome,
                // 口座
                account = individualInfo.accountType,
                // 店舗名
                shop = individualInfo.branchNumber,
                // 口座番号
                accountNumber = individualInfo.accountNumber,
                candidateEnabled = false,
                // 候補表示フラグ
                candidateFlag = candidateFlag,
                // 市区町村プルダウン
                addressList = addressList,
                addressNashiList = addressNashiList,
                addressShowValue = "1",
                addressShowLabel = individualInfo.wpCity + individualInfo.wpStreet,
            )
            // 復元処理済みフラグ
            MainActivity.HAS_RECOVERY_FLAG = true
            MainActivity.SHOW_RETURN_BUTTON_FLAG = true
        }
    }

    /**
     * アドレスの切替
     */
    fun onAddressShowChange(addressShow: CodeBean) {
        // 市区町村表示
        viewStates = viewStates.copy(addressShowValue = addressShow.code, addressShowLabel = addressShow.value)
        if (viewStates.addressShowValue.isNotBlank()) {
            // 郵便情報
            if (viewStates.postData.isNotEmpty()) {
                val thisPost = viewStates.postData.first { it.addressCode == addressShow.code }
                viewStates = viewStates.copy(
                    municipalities = thisPost.city + thisPost.addrDetail1,
                    chome = if (viewStates.candidateFlag) "" else thisPost.addrDetail2,
                )
            }
        } else {
            viewStates = viewStates.copy(municipalities = "", chome = "")
        }
    }

    // 2025/01/23 共同化ためマネロン　プルダウンを追加　start
    /**
     *業務内容（名称）
     */
    fun setBusinessContentName(value: String, code: String) {
        viewStates =
            viewStates.copy(businessContentNameLabel = value, businessContentName = code)
        if (code != BusinessContentName.OTHERS.code) {
            viewStates = viewStates.copy(businessContentOtherDescribeAnswer = "")
        }
    }

    /**
     *上場／非上場
     */
    fun setPlayOrNotPlay(value: String, code: String) {
        viewStates =
            viewStates.copy(playOrNotPlayLabel = value, playOrNotPlay = code)
    }

    /**
     *業種
     */
    fun setCategory(value: String, code: String) {
        viewStates =
            viewStates.copy(categoryLabel = value, category = code)
    }

    /**
     *役職（名称）
     */
    fun setPstnName(value: String, code: String) {
        viewStates =
            viewStates.copy(pstnNameLabel = value, pstnName = code)
        if (code != PstnName.OTHERS.code) {
            viewStates = viewStates.copy(pstnOtherDescribeAnswer = "")
        }
    }
    // 2025/01/23 共同化ためマネロン　プルダウンを追加　end
    /**
     * 候補を表示するフラグ切替
     */
    fun onCandidateFlagChange() {
        viewStates = viewStates.copy(
            candidateFlag = !viewStates.candidateFlag,
            addressShowValue = "",
            addressShowLabel = "",
            municipalities = "",
            chome = ""
        )
    }

    /**
     * エラーチェック
     */
    fun doNext(coroutineScope: CoroutineScope, scrollState: ScrollState) {
        viewStates = viewStates.copy(isError = false, errorBean = MBOP0608ErrorInformation(), errMsgList = listOf())

        // ご職業と取引目的に以下を選択した場合
        // 「主婦/主夫」かつ「給与受取/年金受取」
        // お勤め先の入力が無くても次へ進める。任意入力とする。
        var needCheck = true
        if (
            viewStates.occupation == Occupation.HOUSEWIFE_HOUSEHUSBAND.code &&
            viewStates.transactPurpose == TransactPurpose.SALARY_PENSION.code
        ) {
            if (
                viewStates.workPlace.isBlank() && viewStates.postCode.isBlank() &&
                viewStates.prefectures.isBlank() && viewStates.municipalities.isBlank() &&
                viewStates.chome.isBlank() && viewStates.address.isBlank() &&
                viewStates.build.isBlank() &&
                viewStates.room.isBlank() && viewStates.phoneFirst.isBlank() &&
                viewStates.phoneSecond.isBlank() && viewStates.phoneThird.isBlank()

            ) {
                needCheck = false
            }
        }

        if (needCheck) {
            doCheck()
            if (!viewStates.isError) {
                enterCustomerInformation()
            } else {
                coroutineScope.launch {
                    scrollState.animateScrollTo(0)
                }
            }
        } else {
            // 遷移のロジック
            if (PreferenceUtil.getPreferenceBooleanValue(ConstUtil.OPENED_EDIT_INFO_FLAG)) {
                PreferenceUtil.setPreferenceBooleanValue(ConstUtil.OPENED_EDIT_INFO_FLAG, false)
                if (viewStates.postCodeOld != viewStates.postCode) {
                    PreferenceUtil.removePreferenceStringValue(ConstUtil.OPENED_HOPE_DEPARTMENT)
                }
                val requestBean = Individual()
                paramSet(requestBean)
                // 画面入力した情報をRealmに保存する
                setRealmInfo(requestBean)
                RouteUtil.navTo(
                    RouteName.MBOP1001Page
                )
            } else {
                // 「主婦/主夫」かつ「給与受取/年金受取」の場合、画面項目の入力がなければ、MBCO0201メールアドレス入力へ遷移する
                if (viewStates.postCode.isBlank()) {
                    RouteUtil.navTo(
                        RouteName.MBCO0201Page,
                        MAIL_CONFIRM_TYPE_INDIVIDUAL
                    )
                } else {
                    enterCustomerInformation()
                }
            }
        }
    }

    /**
     * 入力チェック
     */
    private fun doCheck() {
        // エラー情報初期化
        val errorBean = MBOP0608ErrorInformation()
        // お勤め先が空白場合
        if (viewStates.workPlace.isBlank()) {
            errorBean.workPlaceErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0608_page_label_work_place)
                    )
                )
            )
        } else if (!viewStates.workPlace.isPersonNameOther()) {
            // ご自宅の番地の全角チェック
            errorBean.workPlaceErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                        MyApp.CONTEXT.getString(R.string.mbop0608_page_label_work_place)
                    )
                )
            )
        }

        // 2025/01/20 共同化ためリスク格付け　業種を追加　start
        // ご業種が空白場合
        if (viewStates.category.isBlank()) {
            errorBean.categoryErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                        MyApp.CONTEXT.getString(R.string.mbop0602_page_label_category)
                    )
                )
            )
        }
        // 2025/01/20 共同化ためリスク格付け　業種を追加　end

        // 郵便番号が空白場合
        if (viewStates.postCode.isBlank()) {
            errorBean.postCodeErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0608_page_label_postCode)
                    )
                )
            )
        } else if (!viewStates.postCode.isHalfNum()) {
            // 郵便番号の半角数字チェック
            errorBean.postCodeErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                        MyApp.CONTEXT.getString(R.string.mbop0608_page_label_postCode)
                    )
                )
            )
        } else if (!EditCheckUtil.lengthCheck(viewStates.postCode, 7)) {
            // 郵便番号の桁数チェック
            errorBean.postCodeErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002003V)
                )
            )
        }

        // お勤め先の市区町村
        if (viewStates.municipalities.isBlank()) {
            errorBean.addressShowErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                        MyApp.CONTEXT.getString(R.string.mbop0608_page_label_municipalities)
                    )
                )
            )
        }

        // お勤め先の番地（全角）
        if (!viewStates.candidateFlag && viewStates.address.isBlank()) {
            errorBean.addressErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0608_page_label_address)
                    )
                )
            )
//        } else if (!viewStates.candidateFlag && !viewStates.address.isPersonNameOther()) {
//        } else if (!viewStates.address.isPersonNameOther()) {
        } else if (!HalfToFullUtils.fullToHalfChar(viewStates.address).isHalfAngle()) {
            // お勤め先の番地の全角カナチェック
            errorBean.addressErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002023V),
                        MyApp.CONTEXT.getString(R.string.mbop0608_page_label_address)
                    )
                )
            )
//        } else if (!viewStates.candidateFlag && viewStates.address.startsWith(ConstUtil.FULL_HYPHEN)) {
        } else if (viewStates.address.startsWith(ConstUtil.FULL_HYPHEN)) {
            // お勤め先の番地の全角カナチェック
            errorBean.addressErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002023V),
                        MyApp.CONTEXT.getString(R.string.mbop0608_page_label_address)
                    )
                )
            )
        }

        // ご自宅の建物名が入力された場合、全角
        if (viewStates.build.isNotBlank() && !viewStates.build.isPersonNameOther()) {
            errorBean.buildErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                        MyApp.CONTEXT.getString(R.string.mbop0608_page_label_build)
                    )
                )
            )
        }

        // ご自宅の号室が入力された場合、全角
        if (viewStates.room.isNotBlank() && !viewStates.room.isPersonNameOther()) {
            errorBean.roomErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                        MyApp.CONTEXT.getString(R.string.mbop0608_page_label_room)
                    )
                )
            )
        }

        if (checkBanchiBuildingRoom(viewStates.address, viewStates.build, viewStates.room)) {
            errorBean.buildErrorFlag = true
            errorBean.roomErrorFlag = true
            errorBean.addressErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002098V)
                )
            )
        }

        // お勤め先の電話番号種別F
        if (viewStates.phoneType.isBlank()) {
            errorBean.phoneTypeErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                        MyApp.CONTEXT.getString(R.string.mbop0608_page_label_phone_type)
                    )
                )
            )
        }

        // お勤め先の電話番号
        if (viewStates.phoneFirst.isBlank()) {
            errorBean.phoneFirstErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0608_page_label_phone)
                    )
                )
            )
        } else if (!viewStates.phoneFirst.isHalfNum()) {
            // 電話番号の半角数字チェック
            errorBean.phoneFirstErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                        MyApp.CONTEXT.getString(R.string.mbop0608_page_label_phone)
                    )
                )
            )
        }

        // お勤め先の電話番号
        if (viewStates.phoneSecond.isBlank()) {
            errorBean.phoneSecondErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            if (!viewStates.errMsgList.contains(
                    MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0608_page_label_phone)
                        )
                )
            ) {
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0608_page_label_phone)
                        )
                    )
                )
            }
        } else if (!viewStates.phoneSecond.isHalfNum()) {
            // 電話番号の半角数字チェック
            errorBean.phoneSecondErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            if (!viewStates.errMsgList.contains(
                    MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                            MyApp.CONTEXT.getString(R.string.mbop0608_page_label_phone)
                        )
                )
            ) {
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                            MyApp.CONTEXT.getString(R.string.mbop0608_page_label_phone)
                        )
                    )
                )
            }
        }

        // お勤め先の電話番号
        if (viewStates.phoneThird.isBlank()) {
            errorBean.phoneThirdErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            if (!viewStates.errMsgList.contains(
                    MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0608_page_label_phone)
                        )
                )
            ) {
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0608_page_label_phone)
                        )
                    )
                )
            }
        } else if (!viewStates.phoneThird.isHalfNum()) {
            // 電話番号の半角数字チェック
            errorBean.phoneThirdErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            if (!viewStates.errMsgList.contains(
                    MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                            MyApp.CONTEXT.getString(R.string.mbop0608_page_label_phone)
                        )
                )
            ) {
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                            MyApp.CONTEXT.getString(R.string.mbop0608_page_label_phone)
                        )
                    )
                )
            }
        }

        if (viewStates.phoneFirst.isNotBlank() && viewStates.phoneSecond.isNotBlank() &&
            viewStates.phoneThird.isNotBlank()
        ) {
            val frequentlyPhone =
                viewStates.phoneFirst + ConstUtil.HALF_HYPHEN + viewStates.phoneSecond +
                    ConstUtil.HALF_HYPHEN + viewStates.phoneThird
            if (viewStates.phoneType == Phone.FIXED_TELEPHONE.code &&
                !(
                    frequentlyPhone.isFixedTelePhone() && frequentlyPhone.isPhone(
                            Phone.FIXED_TELEPHONE.code,
                            frequentlyPhone
                        )
                    )
            ) {
                errorBean.phoneFirstErrorFlag = true
                errorBean.phoneSecondErrorFlag = true
                errorBean.phoneThirdErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002020V)
                    )
                )
            } else if (viewStates.phoneType == Phone.MOBILE_PHONE.code &&
                !(
                    frequentlyPhone.isMobilePhone() && frequentlyPhone.isPhone(
                            Phone.MOBILE_PHONE.code,
                            frequentlyPhone
                        )
                    )
            ) {
                errorBean.phoneFirstErrorFlag = true
                errorBean.phoneSecondErrorFlag = true
                errorBean.phoneThirdErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002019V)
                    )
                )
            }
        }
        // 2025/01/23 共同化ため マネロン対応 start
        // 業務内容（名称）が空の場合
        if (viewStates.businessContentName.isBlank()) {
            errorBean.businessContentNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0608_page_label_business_content_name_select)
                    )
                )
            )
        }

        // 業務内容その他が空の場合
        if (viewStates.businessContentName == BusinessContentName.OTHERS.code) {
            if (viewStates.businessContentOtherDescribeAnswer.isBlank()) {
                errorBean.businessContentOtherDescribeAnswerErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0608_page_label_business_content_other_describe_answer)
                        )
                    )
                )
            }
        }

        // 上場／非上場が空の場合
        if (viewStates.playOrNotPlay.isBlank()) {
            errorBean.playOrNotPlayErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                        MyApp.CONTEXT.getString(R.string.mbop0608_page_label_play_or_not_play)
                    )
                )
            )
        }

        // 役職（名称）が空の場合
        if (viewStates.pstnName.isBlank()) {
            errorBean.pstnNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0608_page_label_pstn_Name)
                    )
                )
            )
        }

        // 役職その他記述回答が空の場合
        if (viewStates.pstnName == PstnName.OTHERS.code) {
            if (viewStates.pstnOtherDescribeAnswer.isBlank()) {
                errorBean.pstnOtherDescribeAnswerErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0608_page_label_pstn_other_describe_answer)
                        )
                    )
                )
            }
        }

        // 役職（名称）が空の場合
        if (viewStates.annualIncome.isBlank()) {
            errorBean.annualIncomeErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0608_page_label_annual_income)
                    )
                )
            )
        }
        // 2025/01/23 共同化ため マネロン対応　を追加 end
    }

    /**
     * 口座開設申込内容を照会する
     */
    private fun enterCustomerInformation() {
        // 画面IDとイベントID設定
        PreferenceUtil.setScreenIDAndEventID("MBOP0608", "E06")
        val requestBean = Individual()
        paramSet(requestBean)
        viewModelScope.launch {
            flow {
                ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, requestBean.convertToParams().toJson())
                emit(webService.AB0703())
            }.map {
                // 画面入力した情報をRealmに保存する
                setRealmInfo(requestBean)
                // 郵便番号
                PreferenceUtil.setPreferenceStringValue(WORK_PLACE_POST_CODE, viewStates.postCode)
                // 遷移のロジック
                if (PreferenceUtil.getPreferenceBooleanValue(ConstUtil.OPENED_EDIT_INFO_FLAG)) {
                    if (viewStates.postCodeOld != viewStates.postCode) {
                        PreferenceUtil.removePreferenceStringValue(ConstUtil.OPENED_HOPE_DEPARTMENT)
                    }
                    // 学校情報
                    // ご職業が学生の場合、MBOP0609学校の入力に遷移する
                    if (viewStates.occupation == Occupation.STUDENT.code) {
                        RouteUtil.navTo(
                            RouteName.MBOP0609Page + "/${requestBean.toJson()}",
                        )
                    } else {
                        PreferenceUtil.setPreferenceBooleanValue(ConstUtil.OPENED_EDIT_INFO_FLAG, false)
                        RouteUtil.navTo(
                            RouteName.MBOP1001Page
                        )
                    }
                } else {
                    PreferenceUtil.setPreferenceBooleanValue(ConstUtil.OPENED_EDIT_INFO_FLAG, false)
                    // ご職業が学生の場合、MBOP0609学校の入力に遷移する
                    if (viewStates.occupation == Occupation.STUDENT.code) {
                        RouteUtil.navTo(
                            RouteName.MBOP0609Page + "/${requestBean.toJson()}",
                        )
                    } else {
                        // MBCO0201　メールアドレス入力
                        RouteUtil.navTo(
                            RouteName.MBCO0201Page,
                            MAIL_CONFIRM_TYPE_INDIVIDUAL
                        )
                    }
                }
            }.catch {
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }
    }

    /**
     * 画面入力した情報をRealmに保存する
     */
    fun setRealmInfo(requestBean: Individual) {
        MyApp.INSTANCE.deleteAll(AccountOpeningAB0703::class.java)
        val ab0703 = AccountOpeningAB0703()
        ab0703.id = UUID.randomUUID().toString()
        requestBean.wpBuilding = addSplitMarkToBuildingRoom(viewStates.build, viewStates.room)
        ab0703.workPlaceInformation = requestBean.toJson()
        MyApp.INSTANCE.create(ab0703)
    }

    /**
     * 郵便番号の自動検索
     */
    fun postInfoSearch() {
        // エラー情報初期化
        val errorBean = MBOP0608ErrorInformation()
        viewStates = viewStates.copy(isError = false, errorBean = errorBean, errMsgList = listOf())

        // 郵便番号が空白場合
        if (viewStates.postCode.isBlank()) {
            errorBean.postCodeErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0608_page_label_postCode)
                    )
                )
            )
        } else if (!viewStates.postCode.isHalfNum()) {
            // 郵便番号の半角数字チェック
            errorBean.postCodeErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                        MyApp.CONTEXT.getString(R.string.mbop0608_page_label_postCode)
                    )
                )
            )
        } else if (!EditCheckUtil.lengthCheck(viewStates.postCode, 7)) {
            // 郵便番号の桁数チェック
            errorBean.postCodeErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002003V)
                )
            )
        }

        if (errorBean.postCodeErrorFlag) return

        // ・都道府県・市区町村・丁目クリア
        cleanAddress()
        viewModelScope.launch {
            val res: List<PostCodeResponseBean> = PostInfoSearchLogic(webService)
                .getPostInfo(PostCodeRequestBean(viewStates.postCode), "MBOP0608", "E02")

            // 住所漢字リスト
            val addressList: MutableList<CodeBean> = mutableListOf()

            // 住所漢字丁目なしリスト
            val addressNashiList: MutableList<CodeBean> = mutableListOf()
            if (res.isNotEmpty()) {
                res.forEach { item ->
                    if (item.address.isNotBlank()) {
                        addressList.add(CodeBean(item.addressCode, item.address))
                    }
                    if (item.addressNashi.isNotBlank()) {
                        addressNashiList.add(CodeBean(item.addressCode, item.addressNashi))
                    }
                }
                var candidateEnabled = true
                var candidateFlag = false
                var showFirstRecordFlag = false
                // 「丁目あり」が０件だった場合に、「丁目なし」のリストより市区町村項目に自動的に１項目を表示する。
                if (addressList.size == 0) {
                    addressList.addAll(addressNashiList)
                    candidateEnabled = false
                    candidateFlag = true
                    showFirstRecordFlag = true
                }
                // 「丁目なし」が０件だった場合、チェックボックスのチェックができないようにする。
                if(addressNashiList.size == 0)
                {
                    candidateEnabled = false
                }
                // 郵便番号の自動検索により、以下の項目が自動反映されます。
                viewStates = viewStates.copy(
                    postData = res,
                    prefectures = if (res.isNotEmpty()) res[0].prefecture else "",
                    addressList = addressList,
                    addressNashiList = addressNashiList,
                    candidateEnabled = candidateEnabled,
                    candidateFlag = candidateFlag,
                    addressShowValue = if (showFirstRecordFlag && addressList.size > 0) addressList[0].code else "",
                    addressShowLabel = if (showFirstRecordFlag && addressList.size > 0) addressList[0].value else "",
                    municipalities = if (showFirstRecordFlag) res[0].city + res[0].addrDetail1 else "",
                    chome = if (showFirstRecordFlag) if (viewStates.candidateFlag) "" else res[0].addrDetail2 else "",
                )
            }
        }
    }

    fun cleanAddress() {
        viewStates = viewStates.copy(
            postData = listOf(),
            prefectures = "",
            addressShowValue = "",
            addressShowLabel = "",
            addressList = listOf(),
            addressNashiList = listOf(),
            municipalities = "",
            chome = "",
            candidateFlag = false,
            candidateEnabled = false,
        )
    }

    /**
     * パラメータセット
     */
    fun paramSet(bean: Individual) {

        // お勤め先
        bean.wpName = viewStates.workPlace
        // 業種
        bean.category = viewStates.category
        // お勤め先の郵便番号
        bean.wpZipCode = viewStates.postCode
        // お勤め先の都道府県
        bean.wpPrefecture = viewStates.prefectures
        // お勤め先の市区町村
        bean.wpCity = viewStates.municipalities
        // 丁目
        bean.wpStreet = viewStates.chome
        // お勤め先の建物名/号室（全角）
        bean.wpBuilding = addSplitMarkToBuildingRoom(viewStates.build, viewStates.room)
        // お勤め先の番地（全角）
        bean.wpAddress = viewStates.address
        // お勤め先の電話番号タイプ
        bean.wpPhoneType = viewStates.phoneType
        // お勤め先の電話番号
        bean.wpPhoneFirst = viewStates.phoneFirst
        // お勤め先の電話番号
        bean.wpPhoneMid = viewStates.phoneSecond
        // お勤め先の電話番号
        bean.wpPhoneLast = viewStates.phoneThird
        // 店舗名
        bean.branchNumber = viewStates.shop
        // 定期・定積口座番号
        bean.accountType = viewStates.account
        // 口座番号
        bean.accountNumber = viewStates.accountNumber
        // 人格区分
        bean.personType = PersonalityFlag.INDIVIDUAL_OTHER.code
        // 受付番号
        bean.receiptNumber = KeyStoreUtil().getFromKeyStore(ConstUtil.RECEIPT_NUMBER)
        // 更新パターン
        bean.updateType = UpdateType.UPDATE_TYPE_003.code

        // 2025/01/23 共同化ため マネロン対応　 start
        // 業務内容（名称）
        bean.businessContentName = viewStates.businessContentName
        // 業務内容その他
        bean.businessContentOtherDescribeAnswer = viewStates.businessContentOtherDescribeAnswer
        // 役職（名称）
        bean.pstnName = viewStates.pstnName
        // 役職その他記述回答
        bean.pstnOtherDescribeAnswer = viewStates.pstnOtherDescribeAnswer
        // 年収
        bean.annualIncome = viewStates.annualIncome
        // 上場／非上場
        bean.playOrNotPlay = viewStates.playOrNotPlay
        // 2025/01/23 共同化ため マネロン対応　 end
    }

    /**
     * 電話番号
     */
    fun setPhoneType(value: String, code: String) {
        viewStates = viewStates.copy(phoneTypeLabel = value)
        viewStates = viewStates.copy(phoneType = code)
    }
}

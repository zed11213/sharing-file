package jp.co.jsbank.mb.bankingapp.logic.opened.mbop.mbop0201

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0201.MBOP0201PageState
import javax.inject.Inject

/**
 * MBOP0201ロジック
 */
@HiltViewModel
class MBOP0201Logic @Inject constructor() : ViewModel() {

    /**
     * MBSU0201ステータス
     */
    var viewStates by mutableStateOf(MBOP0201PageState())
        private set

    /**
     * 地域ダイアログ
     */
    fun openAreaDialogFlag() {
        viewStates = viewStates.copy(areaDialogFlag = true)
    }

    /**
     * 地域ダイアログクルーズ
     */
    fun closeAreaDialogFlag() {
        viewStates = viewStates.copy(areaDialogFlag = false)
    }

    /**
     * 口座開設ダイアログ
     */
    fun openAccountOpeningDialogFlag() {
        viewStates = viewStates.copy(accountOpeningDialogFlag = true)
    }

    /**
     * 口座開設ダイアログクルーズ
     */
    fun closeAccountOpeningDialogFlag() {
        viewStates = viewStates.copy(accountOpeningDialogFlag = false)
    }

    /**
     * 地域ダイアログ
     */
    fun openCorporationAreaDialogFlag() {
        viewStates = viewStates.copy(corporationAreaDialogFlag = true)
    }

    /**
     * 地域ダイアログクルーズ
     */
    fun closeCorporationAreaDialogFlag() {
        viewStates = viewStates.copy(corporationAreaDialogFlag = false)
    }

    /**
     * 外国籍ダイアログ
     */
    fun openForeignNationalityDialogFlag() {
        viewStates = viewStates.copy(foreignNationalityDialogFlag = true)
    }

    /**
     * 外国籍ダイアログルーズ
     */
    fun closeForeignNationalityDialogFlag() {
        viewStates = viewStates.copy(foreignNationalityDialogFlag = false)
    }

    /**
     * 外国籍であった場合の謝絶ダイアログ
     */
    fun openForeignNationalityRefuseDialogFlag() {
        viewStates = viewStates.copy(foreignNationalityRefuseDialogFlag = true)
    }

    /**
     * 外国籍であった場合の謝絶ダイアログルーズ
     */
    fun closeForeignNationalityRefuseDialogFlag() {
        viewStates = viewStates.copy(foreignNationalityRefuseDialogFlag = false)
    }

    /**
     * 訪問ダイアログ
     */
    fun openVisitDialogFlag() {
        viewStates = viewStates.copy(visitDialogFlag = true)
    }

    /**
     * 訪問ダイアログルーズ
     */
    fun closeVisitDialogFlag() {
        viewStates = viewStates.copy(visitDialogFlag = false)
    }
}

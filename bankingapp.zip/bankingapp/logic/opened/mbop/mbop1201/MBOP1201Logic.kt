package jp.co.jsbank.mb.bankingapp.logic.opened.mbop.mbop1201

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop1201.MBOP1201PageState

/**
 * MBOP1201ロジック
 */
@HiltViewModel
class MBOP1201Logic @Inject constructor() : ViewModel() {

    /**
     * MBOP1201ステータス
     */
    var viewStates by mutableStateOf(MBOP1201PageState())
        private set

    /**
     * 申込完了ダイアログ
     */
    fun openCompletedDialogFlag() {
        viewStates = viewStates.copy(completedDialogFlag = true)
    }

    /**
     * 申込完了ダイアログクルーズ
     */
    fun closeCompletedDialogFlag() {
        viewStates = viewStates.copy(completedDialogFlag = false)
    }
}

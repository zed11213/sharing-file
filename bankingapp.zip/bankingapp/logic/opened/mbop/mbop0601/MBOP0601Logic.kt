package jp.co.jsbank.mb.bankingapp.logic.opened.mbop.mbop0601

import androidx.compose.foundation.ScrollState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import io.realm.Realm
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.bean.common.CodeBean
import jp.co.jsbank.mb.bankingapp.bean.common.Individual
import jp.co.jsbank.mb.bankingapp.bean.common.PostCodeRequestBean
import jp.co.jsbank.mb.bankingapp.bean.common.PostCodeResponseBean
import jp.co.jsbank.mb.bankingapp.bean.opened.mbop.mbop0601.MBOP0601RequestBean
import jp.co.jsbank.mb.bankingapp.logic.common.PostInfoSearchLogic
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.repositories.db.common.create
import jp.co.jsbank.mb.bankingapp.repositories.db.common.deleteAll
import jp.co.jsbank.mb.bankingapp.repositories.db.common.findAll
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.AccountOpeningAB0706
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.EPassBookAB0701
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.system.MyApp
import jp.co.jsbank.mb.bankingapp.system.master.*
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0601.MBOP0601ErrorInformation
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0601.MBOP0601PageState
import jp.co.jsbank.mb.bankingapp.utils.*
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.ADDRESS
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.CHOME
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.EKYC_INFO_BIRTHDATE
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.EKYC_INFO_FIRST_NAME
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.EKYC_INFO_LAST_NAME
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.EKYC_INFO_POSTALCODE
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.FULL_HYPHEN
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.HOSHO
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.HALF_HYPHEN
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.OPENED_EDIT_INFO_FLAG
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.PHONE_FIRST
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.PHONE_NUMBER
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.PHONE_SECOND
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.SELF_POST_CODE
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.containsInvalidCharacter
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isFixedTelePhone
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isHalfAngle
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isHalfNum
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isIPTelePhone
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isMobilePhone
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isPersonNameCharacters
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isPersonNameKana
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isPersonNameKanaOther
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isPersonNameOther
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isPhone
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.lengthCheck
import jp.co.jsbank.mb.bankingapp.utils.HalfToFullUtils.checkBuildRoom
import jp.co.jsbank.mb.bankingapp.utils.HalfToFullUtils.checkBuildRoomKana
import jp.co.jsbank.mb.bankingapp.utils.HalfToFullUtils.concatBuildRoom
import jp.co.jsbank.mb.bankingapp.utils.HalfToFullUtils.concatBuildRoomDb
import jp.co.jsbank.mb.bankingapp.utils.HalfToFullUtils.concatBuildRoomKana
import jp.co.jsbank.mb.bankingapp.utils.HalfToFullUtils.concatBuildRoomKanaDb
import jp.co.jsbank.mb.bankingapp.utils.HalfToFullUtils.fullToHalfChar
import jp.co.jsbank.mb.bankingapp.utils.HalfToFullUtils.splitBuildRoom
import jp.co.jsbank.mb.bankingapp.utils.HalfToFullUtils.splitBuildRoomKana
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import java.util.*
import javax.inject.Inject

/**
 * MBOP0601ロジック
 */
@HiltViewModel
class MBOP0601Logic @Inject constructor(
    private var webService: RestService
) : ViewModel() {

    /**
     * MBOP0601ステータス
     */
    var viewStates by mutableStateOf(MBOP0601PageState())
        private set

    /**
     * ロカールDB
     */
    private var dbService: Realm = MyApp.INSTANCE

    /**
     * 初期化
     */
    init {
        // 修正処理
        val accountOpeningAB0706 = dbService.findAll(AccountOpeningAB0706::class.java)
        if (accountOpeningAB0706.isNotEmpty()) {
            val customerInformation = accountOpeningAB0706[0]?.customerInformation?.fromJson<Individual>()!!
            // 候補表示フラグの判定：丁目カラムに「丁目」があれば、候補に表示されない
            var candidateFlag = false
            if (customerInformation.city.isNotBlank() && !customerInformation.addrDetail2.contains(
                    MyApp.CONTEXT.getString(
                            R.string.common_label_chome
                        )
                )
            ) {
                candidateFlag = true
            }
            // 住所漢字リスト
            val addressList: MutableList<CodeBean> = mutableListOf()
            // 住所漢字丁目なしリスト
            val addressNashiList: MutableList<CodeBean> = mutableListOf()
            // 市区町村プルダウン作成
            addressList.add(
                CodeBean(
                    code = "1",
                    value = customerInformation.city + customerInformation.addrDetail2
                )
            )
            addressNashiList.add(
                CodeBean(
                    code = "1",
                    value = customerInformation.city + customerInformation.addrDetail2
                )
            )
            // 住所カナリスト
            val addressKanaList: MutableList<CodeBean> = mutableListOf()
            // 住所カナ丁目なしリスト
            val addressKanaNashiList: MutableList<CodeBean> = mutableListOf()
            // 市区町村カナプルダウン作成
            addressKanaList.add(
                CodeBean(
                    code = "1",
                    value = customerInformation.cityKana + customerInformation.addrDetail2Kana
                )
            )
            addressKanaNashiList.add(
                CodeBean(
                    code = "1",
                    value = customerInformation.cityKana + customerInformation.addrDetail2Kana
                )
            )
            var year = ""
            var month = ""
            var day = ""
            val birthday = customerInformation.birthday.split(HALF_HYPHEN)
            if (customerInformation.birthday.length > 2) {
                year = birthday[0]
                month = birthday[1]
                day = birthday[2]
            }

            val buildRoom = splitBuildRoom(customerInformation.buildingRoom)
            val buildRoomKana = splitBuildRoomKana(customerInformation.buildingRoomKana)

            viewStates = viewStates.copy(
                // 氏名漢字（姓）
                firstName = customerInformation.customerKanjiLastName,
                // 氏名漢字（名）
                secondName = customerInformation.customerKanjiFirstName,
                // 氏名カナ（姓）
                firstKanaName = customerInformation.customerLastName,
                // 氏名カナ（名）
                secondKanaName = customerInformation.customerFirstName,
                // 性別
                sex = customerInformation.gender,
                // 生年月日
                year = year,
                yearOld = year,
                month = month,
                monthOld = month,
                day = day,
                dayOld = day,
                // 郵便番号
                postCode = customerInformation.zipCode,
                postCodeOld = customerInformation.zipCode,
                // 都道府県
                homePrefecture = customerInformation.prefecture,
                // 市区町村
                homeCity = customerInformation.city,
                // 丁目
                chome = customerInformation.addrDetail2,
                chomeOld = customerInformation.addrDetail2,
                // 丁目
                chomeLabel = Chome.getChomeName(customerInformation.addrDetail2),
                // 番地（全角）
                homeAddress = customerInformation.addrDetail3.trimEnd(),
                homeAddressOld = customerInformation.addrDetail3.trimEnd(),
                // 建物名（全角）
                build = buildRoom.first,
                // 号室（全角）
                room = buildRoom.second,
                // 都道府県（半角カナ）
                homePrefectureKana = customerInformation.prefectureKana,
                // 市区町村（半角カナ）
                homeCityKana = customerInformation.cityKana,
                // 丁目（半角カナ）
                chomeKana = customerInformation.addrDetail2Kana,
                chomeKanaOld = customerInformation.addrDetail2Kana,
                // 丁目（半角カナ）
                chomeKanaLabel = ChomeHalf.getChomeHalfName(customerInformation.addrDetail2Kana),
                // 番地（半角カナ）
                homeAddressHalf = customerInformation.addrDetail3Kana.trimEnd(),
                homeAddressHalfOld = customerInformation.addrDetail3Kana.trimEnd(),
                // 建物名（半角カナ）
                buildKana = buildRoomKana.first,
                // 号室（半角カナ）
                roomKana = buildRoomKana.second,
                // 電話番号種別１
                frequentlyPhoneType = customerInformation.phoneType1,
                // 電話番号種別１名
                frequentlyPhoneTypeLabel = Phone.getPhoneTypeName(customerInformation.phoneType1),
                // 電話番号１（上）
                frequentlyPhoneFirst = customerInformation.phoneNumOneFirst,
                // 電話番号１（中）
                frequentlyPhoneSecond = customerInformation.phoneNumOneMid,
                // 電話番号１（下）
                frequentlyPhoneThird = customerInformation.phoneNumOneLast,
                // 電話番号種別２
                phoneType = customerInformation.phoneType2,
                // 電話番号種別２名
                phoneTypeLabel = Phone.getPhoneTypeName(customerInformation.phoneType2),
                // 電話番号２（上）
                phoneFirst = customerInformation.phoneNumTwoFirst,
                // 電話番号２（中）
                phoneSecond = customerInformation.phoneNumTwoMid,
                // 電話番号２（下）
                phoneThird = customerInformation.phoneNumTwoLast,
                // 地区コード
                addressCode = customerInformation.addressCode,
                // 候補表示フラグ
                candidateFlag = candidateFlag,
                // 市区町村プルダウン
                addressList = addressList,
                addressNashiList = addressNashiList,
                addressShowValue = "1",
                addressShowLabel = customerInformation.city + customerInformation.addrDetail2,
                // 市区町村カナプルダウン
                addressKanaList = addressKanaList,
                addressKanaNashiList = addressKanaNashiList,
                addressKanaShowValue = "1",
                addressKanaShowLabel = customerInformation.cityKana + customerInformation.addrDetail2Kana,
                candidateEnabled = false
            )
        } else {
            var birthday = PreferenceUtil.getPreferenceStringValue(EKYC_INFO_BIRTHDATE)
            birthday = birthday?.replace("年", "")
                ?.replace("月", "")
                ?.replace("日", "") ?: ""
            if (birthday.isNotEmpty()) {
                viewStates = viewStates.copy(
                    firstName = PreferenceUtil.getPreferenceStringValue(EKYC_INFO_LAST_NAME).toString(),
                    secondName = PreferenceUtil.getPreferenceStringValue(EKYC_INFO_FIRST_NAME).toString(),
                    year = birthday.substring(0, 4),
                    month = birthday.substring(4, 6),
                    day = birthday.substring(6, 8),
                    postCode = PreferenceUtil.getPreferenceStringValue(EKYC_INFO_POSTALCODE).toString()
                )
            }
        }

        // 復元データを取得する
        getRestoreData()
    }

    /**
     * 復元データを取得する
     */
    private fun getRestoreData() {
        val accountOpeningAB0701 = MyApp.INSTANCE.findAll(EPassBookAB0701::class.java)
        if (accountOpeningAB0701.isNotEmpty() && !MainActivity.HAS_RECOVERY_FLAG) {
            val individualInfo = accountOpeningAB0701[0]?.individual?.fromJson<Individual>()!!
            // 候補表示フラグの判定：丁目カラムに「丁目」があれば、候補に表示されない
            var candidateFlag = false
            if (individualInfo.city.isNotBlank() && !individualInfo.addrDetail2.contains(
                    MyApp.CONTEXT.getString(
                            R.string.common_label_chome
                        )
                )
            ) {
                candidateFlag = true
            }
            // 住所漢字リスト
            val addressList: MutableList<CodeBean> = mutableListOf()
            // 住所漢字丁目なしリスト
            val addressNashiList: MutableList<CodeBean> = mutableListOf()
            // 市区町村プルダウン作成
            addressList.add(
                CodeBean(
                    code = "1",
                    value = individualInfo.city + individualInfo.addrDetail2
                )
            )
            addressNashiList.add(
                CodeBean(
                    code = "1",
                    value = individualInfo.city + individualInfo.addrDetail2
                )
            )
            // 住所カナリスト
            val addressKanaList: MutableList<CodeBean> = mutableListOf()
            // 住所カナ丁目なしリスト
            val addressKanaNashiList: MutableList<CodeBean> = mutableListOf()
            // 市区町村カナプルダウン作成
            addressKanaList.add(
                CodeBean(
                    code = "1",
                    value = individualInfo.cityKana + individualInfo.addrDetail2Kana
                )
            )
            addressKanaNashiList.add(
                CodeBean(
                    code = "1",
                    value = individualInfo.cityKana + individualInfo.addrDetail2Kana
                )
            )
            val buildRoom = splitBuildRoom(individualInfo.buildingRoom)
            val buildRoomKana = splitBuildRoomKana(individualInfo.buildingRoomKana)
            viewStates = viewStates.copy(
                // 姓
                firstName = individualInfo.customerKanjiLastName,
                // 名
                secondName = individualInfo.customerKanjiFirstName,
                // セイ
                firstKanaName = individualInfo.customerLastName,
                // メイ
                secondKanaName = individualInfo.customerFirstName,
                // 性別
                sex = individualInfo.gender,
                // 年
                year = individualInfo.birthday.replace("-", "").substring(0, 4),
                // 月
                month = individualInfo.birthday.replace("-", "").substring(4, 6),
                // 日
                day = individualInfo.birthday.replace("-", "").substring(6, 8),
                // 郵便番号
                postCode = individualInfo.zipCode,
                // ご自宅の都道府県
                homePrefecture = individualInfo.prefecture,
                // ご自宅の市区町村
                homeCity = individualInfo.city,
                // ご自宅の番地（全角）
                homeAddress = individualInfo.addrDetail3.trimEnd(),
                // ご自宅の建物名（全角）
                build = buildRoom.first,
                // ご自宅の号室（全角）
                room = buildRoom.second,
                // ご自宅の都道府県（半角カナ）
                homePrefectureKana = individualInfo.prefectureKana,
                // ご自宅の市区町村（半角カナ）
                homeCityKana = individualInfo.cityKana,
                // ご自宅の番地（半角）
                homeAddressHalf = individualInfo.addrDetail3Kana.trimEnd(),
                // ご自宅の建物名（半角カナ）
                buildKana = buildRoomKana.first,
                // ご自宅の号室（半角カナ）
                roomKana = buildRoomKana.second,
                // 丁目
                chome = individualInfo.addrDetail2,
                // 丁目
                chomeLabel = Chome.getChomeName(individualInfo.addrDetail2),
                // 丁目（半角）
                chomeKana = individualInfo.addrDetail2Kana.replace(HALF_HYPHEN, ""),
                // 丁目（半角カナ）
                chomeKanaLabel = ChomeHalf.getChomeHalfName(individualInfo.addrDetail2Kana),
                // よく使う電話番号
                frequentlyPhoneType = individualInfo.phoneType1,
                // よく使う電話番号名
                frequentlyPhoneTypeLabel = Phone.getPhoneTypeName(individualInfo.phoneType1),
                // よく使う電話番号1
                frequentlyPhoneFirst = individualInfo.phoneNumOneFirst,
                // よく使う電話番号2
                frequentlyPhoneSecond = individualInfo.phoneNumOneMid,
                // よく使う電話番号3
                frequentlyPhoneThird = individualInfo.phoneNumOneLast,
                // 電話番号
                phoneType = individualInfo.phoneType2,
                // 電話番号名
                phoneTypeLabel = Phone.getPhoneTypeName(individualInfo.phoneType2),
                // 電話番号1
                phoneFirst = individualInfo.phoneNumTwoFirst,
                // 電話番号2
                phoneSecond = individualInfo.phoneNumTwoMid,
                // 電話番号3
                phoneThird = individualInfo.phoneNumTwoLast,
                // 地区コード
                addressCode = individualInfo.addressCode,
                // 候補表示フラグ
                candidateFlag = candidateFlag,
                // 市区町村プルダウン
                addressList = addressList,
                addressNashiList = addressNashiList,
                addressShowValue = "1",
                addressShowLabel = individualInfo.city + individualInfo.addrDetail2,
                // 市区町村カナプルダウン
                addressKanaList = addressKanaList,
                addressKanaNashiList = addressKanaNashiList,
                addressKanaShowValue = "1",
                addressKanaShowLabel = individualInfo.cityKana + individualInfo.addrDetail2Kana,
                candidateEnabled = false
            )

            // 復元処理済みフラグ
            MainActivity.HAS_RECOVERY_FLAG = true
            MainActivity.SHOW_RETURN_BUTTON_FLAG = true
        }
    }

    /**
     * ラジオボタン設定
     */
    fun sexSet(index: String) {
        viewStates = viewStates.copy(sex = index)
    }

    /**
     * 番地カナ更新
     */
    fun updateHomeAddressKana(homeAddress: String) {
        viewStates = viewStates.copy(homeAddressHalf = fullToHalfChar(homeAddress))
    }

    /**
     * 号室カナ更新
     */
    fun updateRoomKana(room: String) {
        viewStates = viewStates.copy(roomKana = fullToHalfChar(room))
    }

    /**
     * よく使う電話番号
     */
    fun setFrequentlyPhoneType(value: String, code: String) {
        viewStates = viewStates.copy(frequentlyPhoneTypeLabel = value)
        viewStates = viewStates.copy(frequentlyPhoneType = code)
    }

    /**
     * 電話番号
     */
    fun setPhoneType(value: String, code: String) {
        viewStates = viewStates.copy(phoneTypeLabel = value)
        viewStates = viewStates.copy(phoneType = code)
    }

    /**
     * エラーチェック
     */
    fun doNext(coroutineScope: CoroutineScope, scrollState: ScrollState) {
        // エラー情報初期化
        val errorBean = MBOP0601ErrorInformation()
        viewStates = viewStates.copy(isError = false, errorBean = errorBean, errMsgList = listOf())

        // 姓が空白場合
        if (viewStates.firstName.isBlank()) {
            errorBean.firstNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0601_page_label_firstName)
                    )
                )
            )
        } else if (!viewStates.firstName.isPersonNameCharacters()) {
            errorBean.firstNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                        MyApp.CONTEXT.getString(R.string.mbop0601_page_label_firstName)
                    )
                )
            )
        }

        if (containsInvalidCharacter(viewStates.firstName)) {
            errorBean.firstNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002015V)
                )
            )
        }

        // 名が空白場合
        if (viewStates.secondName.isBlank()) {
            errorBean.secondNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0601_page_label_secondName)
                    )
                )
            )
        } else if (!viewStates.secondName.isPersonNameCharacters()) {
            errorBean.secondNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                        MyApp.CONTEXT.getString(R.string.mbop0601_page_label_secondName)
                    )
                )
            )
        }

        if (containsInvalidCharacter(viewStates.secondName)) {
            errorBean.secondNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002015V)
                )
            )
        }

        // お名前（フリガナ）のセイの入力チェック
        if (viewStates.firstKanaName.isBlank()) {
            errorBean.firstKanaNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0601_page_label_kana_firstName)
                    )
                )
            )
        } else if (!viewStates.firstKanaName.isPersonNameKana()) {
            // セイ（半角カナ）の全角カナチェック
            errorBean.firstKanaNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002031V),
                        MyApp.CONTEXT.getString(R.string.mbop0601_page_label_kana_firstName)
                    )
                )
            )
        }

        // お名前（フリガナ）のメイの入力チェック
        if (viewStates.secondKanaName.isBlank()) {
            errorBean.secondKanaNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0601_page_label_kana_secondName)
                    )
                )
            )
        } else if (!viewStates.secondKanaName.isPersonNameKana()) {
            // メイ（半角カナ）の全角カナチェック
            errorBean.secondKanaNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002031V),
                        MyApp.CONTEXT.getString(R.string.mbop0601_page_label_kana_secondName)
                    )
                )
            )
        }

        // 2025/01/28 共同化ため 名前の桁数変更  start
        val firstNameSecondName = viewStates.firstKanaName +" "+ viewStates.secondKanaName
        if (firstNameSecondName.length > 20) {
            // セイ＋ブランク＋メイで20桁を超える場合
            errorBean.firstNameSecondNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002033V),
                        MyApp.CONTEXT.getString(R.string.mbop0601_page_label_kana_firstName_secondName)
                    )
                )
            )
        }
        // 2025/01/28 共同化ため 名前の桁数変更  end

        // 性別
        if (viewStates.sex.isEmpty()) {
            errorBean.sexErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                        MyApp.CONTEXT.getString(R.string.mbop0601_page_label_sex)
                    )
                )
            )
        }

        // 年
        if (viewStates.year.isEmpty()) {
            errorBean.yearErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.common_message_replace_label_year)
                    )
                )
            )
        } else if (!lengthCheck(viewStates.year, 4)) {
            errorBean.yearErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002006V)
                )
            )
        }

        // 月
        if (viewStates.month.isEmpty()) {
            errorBean.monthErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.common_message_replace_label_month)
                    )
                )
            )
        }

        // 日
        if (viewStates.day.isBlank()) {
            errorBean.dayErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.common_message_replace_label_day)
                    )
                )
            )
        }

        // 生年月日チェック
        if (viewStates.year.isNotBlank() &&
            viewStates.month.isNotBlank() &&
            viewStates.day.isNotBlank()
        ) {
            if (!EditCheckUtil.isDayCheck(
                    viewStates.year,
                    viewStates.month,
                    viewStates.day
                )
            ) {
                errorBean.yearErrorFlag = true
                errorBean.monthErrorFlag = true
                errorBean.dayErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002007V),
                            MyApp.CONTEXT.getString(R.string.mbop0601_page_label_birthday)
                        )
                    )
                )
            }
            // 15歳未満チェック
            else if (LifeAge.getAgeByBirth(
                    viewStates.year + HALF_HYPHEN + viewStates.month + HALF_HYPHEN + viewStates.day
                ) < 15
            ) {
                errorBean.yearErrorFlag = true
                errorBean.dayErrorFlag = true
                errorBean.monthErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002025V)
                    )
                )
            }
            // 1900年生まれ以降チェック
            else if (!EditCheckUtil.isYearCheck(viewStates.year)) {
                errorBean.yearErrorFlag = true
                errorBean.dayErrorFlag = true
                errorBean.monthErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002007V),
                            MyApp.CONTEXT.getString(R.string.mbop0601_page_label_birthday)
                        )
                    )
                )
            }
        }

        // 郵便番号が空白場合
        if (viewStates.postCode.isBlank()) {
            errorBean.postCodeErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0601_page_label_postCode)
                    )
                )
            )
        } else if (!viewStates.postCode.isHalfNum()) {
            // 郵便番号の半角数字チェック
            errorBean.postCodeErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                        MyApp.CONTEXT.getString(R.string.mbop0601_page_label_postCode)
                    )
                )
            )
        } else if (!lengthCheck(viewStates.postCode, 7)) {
            // 郵便番号の桁数チェック
            errorBean.postCodeErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002003V)
                )
            )
        }

        // ご自宅の市区町村が空白場合
        if (viewStates.homeCity.isBlank()) {
            errorBean.addressShowErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                        MyApp.CONTEXT.getString(R.string.mbop0601_page_label_home_city)
                    )
                )
            )
        }

        // ご自宅の番地（全角）が空白場合
        if (!viewStates.candidateFlag && viewStates.homeAddress.isBlank()
        ) {
            errorBean.homeAddressErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0601_page_label_home_address)
                    )
                )
            )
 //       } else if (!viewStates.candidateFlag && !fullToHalfChar(viewStates.homeAddress).isHalfAngle()) {
        } else if (!fullToHalfChar(viewStates.homeAddress).isHalfAngle()) {
            // ご自宅の番地の全角チェック
            errorBean.homeAddressErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002023V),
                        MyApp.CONTEXT.getString(R.string.mbop0601_page_label_home_address)
                    )
                )
            )
//        } else if (!viewStates.candidateFlag && viewStates.homeAddress.startsWith(FULL_HYPHEN)) {
        } else if (viewStates.homeAddress.startsWith(FULL_HYPHEN)) {
            // ご自宅の番地の全角チェック
            errorBean.homeAddressErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002023V),
                        MyApp.CONTEXT.getString(R.string.mbop0601_page_label_home_address)
                    )
                )
            )
        }

        // ご自宅の市区町村（半角カナ）が空白場合
        if (viewStates.homeCityKana.isBlank()) {
            errorBean.addressKanaShowErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                        MyApp.CONTEXT.getString(R.string.mbop0601_page_label_home_city_kana)
                    )
                )
            )
        }

        // 丁目が入力された場合、丁目カナも入力必要です
        if (!viewStates.candidateFlag) {
            if (viewStates.chome.isNotBlank() && viewStates.chomeKana.isBlank()) {
                errorBean.chomeKanaErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                            MyApp.CONTEXT.getString(R.string.mbop0601_page_label_chome_half)
                        )
                    )
                )
            }
        }

        // ご自宅の番地（半角）が空白場合
        if (!viewStates.candidateFlag && viewStates.homeAddressHalf.isBlank()) {
            errorBean.homeAddressHalfErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0601_page_label_home_address_half)
                    )
                )
            )
//        } else if (!viewStates.candidateFlag && !viewStates.homeAddressHalf.isHalfAngle()) {
        } else if (!viewStates.homeAddressHalf.isHalfAngle()) {
            // ご自宅の番地（半角）の半角チェック
            errorBean.homeAddressHalfErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002023V),
                        MyApp.CONTEXT.getString(R.string.mbop0601_page_label_home_address_half)
                    )
                )
            )
//        } else if (!viewStates.candidateFlag && viewStates.homeAddressHalf.startsWith(HYPHEN)) {
        } else if (viewStates.homeAddressHalf.startsWith(HALF_HYPHEN)) {
            // ご自宅の番地（半角）の半角チェック
            errorBean.homeAddressHalfErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002023V),
                        MyApp.CONTEXT.getString(R.string.mbop0601_page_label_home_address_half)
                    )
                )
            )
        }

        // ご自宅の番地（全角）が入力された場合、ご自宅の番地（半角）も入力必要です
        if (viewStates.homeAddressHalf.isBlank() && viewStates.homeAddress.isNotBlank()) {
            errorBean.homeAddressHalfErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0601_page_label_home_address_half)
                    )
                )
            )
        }

        // ご自宅の番地（半角）が入力された場合、ご自宅の番地（全角）も入力必要です
        if (viewStates.homeAddress.isBlank() && viewStates.homeAddressHalf.isNotBlank()) {
            errorBean.homeAddressErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0601_page_label_home_address)
                    )
                )
            )
        }

        // 建物名カナが入力された場合、建物名も入力必要です
        if (viewStates.build.isBlank() && viewStates.buildKana.isNotBlank()) {
            errorBean.buildErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0601_page_label_build)
                    )
                )
            )
        }

        // ご自宅の建物名が入力された場合、ご自宅の建物名カナも入力必要です
        if (viewStates.build.isNotBlank() && viewStates.buildKana.isBlank()) {
            errorBean.buildKanaErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0601_page_label_build_kana)
                    )
                )
            )
        }

        // ご自宅の建物名が入力された場合、全角
        if (viewStates.build.isNotBlank() && !viewStates.build.isPersonNameOther()) {
            errorBean.buildErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                        MyApp.CONTEXT.getString(R.string.mbop0601_page_label_build)
                    )
                )
            )
        }

        // ご自宅の建物名（半角カナ）が入力された場合、全角
        if (viewStates.buildKana.isNotBlank() && !viewStates.buildKana.isPersonNameKanaOther()) {
            errorBean.buildKanaErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002032V),
                        MyApp.CONTEXT.getString(R.string.mbop0601_page_label_build_kana)
                    )
                )
            )
        }

        //--------------------------room

        // 建物名/号室カナが入力された場合、建物名/号室も入力必要です
        if (viewStates.room.isBlank() && viewStates.roomKana.isNotBlank()) {
            errorBean.roomErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0601_page_label_room)
                    )
                )
            )
        }

        // ご自宅の建物名/号室が入力された場合、ご自宅の建物名/号室カナも入力必要です
        if (viewStates.room.isNotBlank() && viewStates.roomKana.isBlank()) {
            errorBean.roomKanaErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0601_page_label_room_kana)
                    )
                )
            )
        }

        // ご自宅の建物名/号室が入力された場合、全角
        if (viewStates.room.isNotBlank() && !viewStates.room.isPersonNameOther()) {
            errorBean.roomErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                        MyApp.CONTEXT.getString(R.string.mbop0601_page_label_room)
                    )
                )
            )
        }

        // ご自宅の建物名/号室（半角カナ）が入力された場合、全角
        if (viewStates.roomKana.isNotBlank() && !viewStates.roomKana.isPersonNameKanaOther()) {
            errorBean.roomKanaErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002032V),
                        MyApp.CONTEXT.getString(R.string.mbop0601_page_label_room_kana)
                    )
                )
            )
        }

        if (checkBuildRoom(viewStates.build, viewStates.room)) {
            errorBean.buildErrorFlag = true
            errorBean.roomErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002098V)
                )
            )
        }

        if (checkBuildRoomKana(viewStates.buildKana, viewStates.roomKana)) {
            errorBean.buildKanaErrorFlag = true
            errorBean.roomKanaErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002099V)
                )
            )
        }

        // よく使う電話番号が空白場合
        if (viewStates.frequentlyPhoneType.isBlank()) {
            errorBean.frequentlyPhoneTypeErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                        MyApp.CONTEXT.getString(R.string.mbop0601_page_label_frequently_phone_type)
                    )
                )
            )
        }

        // よく使う電話番号が空白場合
        if (viewStates.frequentlyPhoneFirst.isBlank()) {
            errorBean.frequentlyPhoneFirstErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0601_page_label_frequently_phone)
                    )
                )
            )
        } else if (!viewStates.frequentlyPhoneFirst.isHalfNum()) {
            // 電話番号の半角数字チェック
            errorBean.frequentlyPhoneFirstErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            if (!viewStates.errMsgList.contains(
                    MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                            MyApp.CONTEXT.getString(R.string.mbop0601_page_label_frequently_phone)
                        )
                )
            ) {
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                            MyApp.CONTEXT.getString(R.string.mbop0601_page_label_frequently_phone)
                        )
                    )
                )
            }
        }

        if (viewStates.frequentlyPhoneSecond.isBlank()) {
            errorBean.frequentlyPhoneSecondErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            if (!viewStates.errMsgList.contains(
                    MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0601_page_label_frequently_phone)
                        )
                )
            ) {
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0601_page_label_frequently_phone)
                        )
                    )
                )
            }
        } else if (!viewStates.frequentlyPhoneSecond.isHalfNum()) {
            // 電話番号の半角数字チェック
            errorBean.frequentlyPhoneSecondErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            if (!viewStates.errMsgList.contains(
                    MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                            MyApp.CONTEXT.getString(R.string.mbop0601_page_label_frequently_phone)
                        )
                )
            ) {
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                            MyApp.CONTEXT.getString(R.string.mbop0601_page_label_frequently_phone)
                        )
                    )
                )
            }
        }

        if (viewStates.frequentlyPhoneThird.isBlank()) {
            errorBean.frequentlyPhoneThirdErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            if (!viewStates.errMsgList.contains(
                    MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0601_page_label_frequently_phone)
                        )
                )
            ) {
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0601_page_label_frequently_phone)
                        )
                    )
                )
            }
        } else if (!viewStates.frequentlyPhoneThird.isHalfNum()) {
            // 電話番号の半角数字チェック
            errorBean.frequentlyPhoneThirdErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            if (!viewStates.errMsgList.contains(
                    MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                            MyApp.CONTEXT.getString(R.string.mbop0601_page_label_frequently_phone)
                        )
                )
            ) {
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                            MyApp.CONTEXT.getString(R.string.mbop0601_page_label_frequently_phone)
                        )
                    )
                )
            }
        }

        if (viewStates.frequentlyPhoneFirst.isNotBlank() && viewStates.frequentlyPhoneSecond.isNotBlank() &&
            viewStates.frequentlyPhoneThird.isNotBlank()
        ) {
            val frequentlyPhone =
                viewStates.frequentlyPhoneFirst + HALF_HYPHEN + viewStates.frequentlyPhoneSecond +
                    HALF_HYPHEN + viewStates.frequentlyPhoneThird
            if (viewStates.frequentlyPhoneType == Phone.FIXED_TELEPHONE.code &&
                !(
                    frequentlyPhone.isFixedTelePhone() && frequentlyPhone.isPhone(
                            Phone.FIXED_TELEPHONE.code,
                            frequentlyPhone
                        )
                    )
            ) {
                errorBean.frequentlyPhoneFirstErrorFlag = true
                errorBean.frequentlyPhoneSecondErrorFlag = true
                errorBean.frequentlyPhoneThirdErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002020V)
                    )
                )
            } else if (viewStates.frequentlyPhoneType == Phone.MOBILE_PHONE.code &&
                !(
                    frequentlyPhone.isMobilePhone() && frequentlyPhone.isPhone(
                            Phone.MOBILE_PHONE.code,
                            frequentlyPhone
                        )
                    )
            ) {
                errorBean.frequentlyPhoneFirstErrorFlag = true
                errorBean.frequentlyPhoneSecondErrorFlag = true
                errorBean.frequentlyPhoneThirdErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002019V)
                    )
                )// 2025/01/29 共同化ため電話番号の登録・表示　start
            } else if (viewStates.frequentlyPhoneType == Phone.IP_PHONE.code &&
                !(
                    frequentlyPhone.isIPTelePhone() && frequentlyPhone.isPhone(
                        Phone.IP_PHONE.code,
                        frequentlyPhone
                    )
                    )
            ) {
                errorBean.frequentlyPhoneFirstErrorFlag = true
                errorBean.frequentlyPhoneSecondErrorFlag = true
                errorBean.frequentlyPhoneThirdErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002034V)
                    )
                )
            }// 2025/01/29 共同化ため電話番号の登録・表示　end
        }

        if ((
            viewStates.phoneFirst.isNotBlank() || viewStates.phoneSecond.isNotBlank() ||
                viewStates.phoneThird.isNotBlank()
            ) && viewStates.phoneType.isBlank()
        ) {
            errorBean.phoneTypeErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                        MyApp.CONTEXT.getString(R.string.mbop0601_page_label_phone_type)
                    )
                )
            )
        }

        // 電話番号タイプが空白以外場合
        if (viewStates.phoneType.isNotBlank()) {
            // 電話番号が空白できない
            if (viewStates.phoneFirst.isBlank()) {
                errorBean.phoneFirstErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0601_page_label_phone)
                        )
                    )
                )
            }

            if (viewStates.phoneSecond.isBlank()) {
                errorBean.phoneSecondErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errMsgList.contains(
                        MessageReplaceUtils.messageReplace(
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                MyApp.CONTEXT.getString(R.string.mbop0601_page_label_phone)
                            )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errMsgList = viewStates.errMsgList.plus(
                            MessageReplaceUtils.messageReplace(
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                MyApp.CONTEXT.getString(R.string.mbop0601_page_label_phone)
                            )
                        )
                    )
                }
            }

            if (viewStates.phoneThird.isBlank()) {
                errorBean.phoneThirdErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errMsgList.contains(
                        MessageReplaceUtils.messageReplace(
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                MyApp.CONTEXT.getString(R.string.mbop0601_page_label_phone)
                            )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errMsgList = viewStates.errMsgList.plus(
                            MessageReplaceUtils.messageReplace(
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                MyApp.CONTEXT.getString(R.string.mbop0601_page_label_phone)
                            )
                        )
                    )
                }
            }

            if (viewStates.phoneFirst.isNotBlank() && viewStates.phoneSecond.isNotBlank() &&
                viewStates.phoneThird.isNotBlank()
            ) {
                val phone = viewStates.phoneFirst + HALF_HYPHEN + viewStates.phoneSecond + HALF_HYPHEN + viewStates.phoneThird
                if (viewStates.phoneType == Phone.FIXED_TELEPHONE.code && !(
                    phone.isFixedTelePhone() && phone.isPhone(
                            Phone.FIXED_TELEPHONE.code,
                            phone
                        )
                    )
                ) {
                    errorBean.phoneFirstErrorFlag = true
                    errorBean.phoneSecondErrorFlag = true
                    errorBean.phoneThirdErrorFlag = true
                    viewStates = viewStates.copy(errorBean = errorBean)
                    viewStates = viewStates.copy(isError = true)
                    if (!viewStates.errMsgList.contains(MyApp.CONTEXT.getString(R.string.MSG_ID_MB002020V))) {
                        viewStates = viewStates.copy(
                            errMsgList = viewStates.errMsgList.plus(
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002020V)
                            )
                        )
                    }
                } else if (viewStates.phoneType == Phone.MOBILE_PHONE.code && !(
                    phone.isMobilePhone() && phone.isPhone(
                            Phone.MOBILE_PHONE.code,
                            phone
                        )
                    )
                ) {
                    errorBean.phoneFirstErrorFlag = true
                    errorBean.phoneSecondErrorFlag = true
                    errorBean.phoneThirdErrorFlag = true
                    viewStates = viewStates.copy(errorBean = errorBean)
                    viewStates = viewStates.copy(isError = true)
                    if (!viewStates.errMsgList.contains(MyApp.CONTEXT.getString(R.string.MSG_ID_MB002019V))) {
                        viewStates = viewStates.copy(
                            errMsgList = viewStates.errMsgList.plus(
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002019V)
                            )
                        )
                    }// 2025/01/29 共同化ため電話番号の登録・表示　start
                } else if (viewStates.phoneType == Phone.IP_PHONE.code &&
                    !(
                        phone.isIPTelePhone() && phone.isPhone(
                            Phone.IP_PHONE.code,
                            phone
                        )
                     )
                ) {
                    errorBean.phoneFirstErrorFlag = true
                    errorBean.phoneSecondErrorFlag = true
                    errorBean.phoneThirdErrorFlag = true
                    viewStates = viewStates.copy(errorBean = errorBean)
                    viewStates = viewStates.copy(isError = true)
                    viewStates = viewStates.copy(
                        errMsgList = viewStates.errMsgList.plus(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002034V)
                        )
                    )
                }// 2025/01/29 共同化ため電話番号の登録・表示　end
            }
        }
        // 2025/01/29 共同化ため電話番号の登録・表示　start
        // よく使う電話番号は電話番号と同一電話種類を２個入力させない仕様、エラー　MB002035V
        if (viewStates.frequentlyPhoneType == viewStates.phoneType) {
            val frequentlyPhone = viewStates.frequentlyPhoneFirst + viewStates.frequentlyPhoneSecond + viewStates.frequentlyPhoneThird
            val phone = viewStates.phoneFirst + viewStates.phoneSecond + viewStates.phoneThird
            //if (frequentlyPhone == phone ) {
                errorBean.phoneTypeErrorFrequentlyPhoneTypeFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errMsgList.contains(MyApp.CONTEXT.getString(R.string.MSG_ID_MB002035V))) {
                    viewStates = viewStates.copy(
                        errMsgList = viewStates.errMsgList.plus(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002035V)
                        )
                    )
                }
            //}
        }
        // 2025/01/29 共同化ため電話番号の登録・表示　end
        if (!viewStates.isError) {
            viewModelScope.launch {
                enterCustomerInformation()
            }
        } else {
            coroutineScope.launch {
                scrollState.animateScrollTo(0)
            }
        }
    }

    /**
     * 口座開設申込内容を照会する
     */
    private suspend fun enterCustomerInformation() {
        // 画面IDとイベントID設定
        PreferenceUtil.setScreenIDAndEventID("MBOP0601", "E06")
        PreferenceUtil.removePreferenceStringValue(ConstUtil.PHONE_FIRST)
        PreferenceUtil.removePreferenceStringValue(ConstUtil.PHONE_SECOND)
        PreferenceUtil.removePreferenceStringValue(ConstUtil.PHONE_THREE)
        // パラメータセット
        paramSet(viewStates.requestBean)

        viewModelScope.async {
            flow {
                ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, viewStates.requestBean.convertToParams().toJson())
                emit(webService.AB0706())
            }.map {
                // 画面入力した情報をRealmに保存する
                setRealmInfo(viewStates.requestBean)
                // 電話番号を保存する
                PreferenceUtil.setPreferenceStringValue(
                    PHONE_FIRST,
                    viewStates.frequentlyPhoneFirst + "-" + viewStates.frequentlyPhoneSecond + "-" +
                        viewStates.frequentlyPhoneThird
                )
                if (viewStates.phoneFirst.isNotBlank() && viewStates.phoneSecond.isNotBlank() &&
                    viewStates.phoneThird.isNotBlank()
                ) {
                    // 電話番号2を保存する
                    PreferenceUtil.setPreferenceStringValue(
                        PHONE_SECOND,
                        viewStates.phoneFirst + "-" + viewStates.phoneSecond + "-" +
                            viewStates.phoneThird
                    )

                }
                // 生年月日
                PreferenceUtil.setPreferenceStringValue(
                    EKYC_INFO_BIRTHDATE,
                    viewStates.year + viewStates.month + viewStates.day
                )
                // 郵便番号
                PreferenceUtil.setPreferenceStringValue(SELF_POST_CODE, viewStates.postCode)
                // 電話番号
                PreferenceUtil.setPreferenceStringValue(
                    PHONE_NUMBER,
                    viewStates.frequentlyPhoneFirst + viewStates.frequentlyPhoneSecond +
                        viewStates.frequentlyPhoneThird
                )
                // 丁目
                PreferenceUtil.setPreferenceStringValue(CHOME, viewStates.chomeKana)
                // 番地
                PreferenceUtil.setPreferenceStringValue(ADDRESS, viewStates.homeAddressHalf)
                // 方書
                PreferenceUtil.setPreferenceStringValue(HOSHO, concatBuildRoomKanaDb(viewStates.buildKana, viewStates.roomKana))
                // 全部店リストを取得する
                getAllDepartmentStoreList()
            }.catch {
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }.await()
    }

    /**
     * 画面入力した情報をRealmに保存する
     */
    fun setRealmInfo(requestBean: MBOP0601RequestBean) {
        // Realm情報更新
        val accountOpeningAB0706 = dbService.findAll(AccountOpeningAB0706::class.java)
        if (accountOpeningAB0706.isNotEmpty()) {
            val customerInformation =
                accountOpeningAB0706[0]?.customerInformation?.fromJson<Individual>()!!
            // 氏名漢字（名）
            customerInformation.customerKanjiFirstName = viewStates.secondName
            // 氏名漢字（姓）
            customerInformation.customerKanjiLastName = viewStates.firstName
            // 氏名カナ（姓）
            customerInformation.customerLastName = viewStates.firstKanaName
            // 氏名カナ（名）
            customerInformation.customerFirstName = viewStates.secondKanaName
            // 性別
            customerInformation.gender = viewStates.sex
            // 生年月日
            customerInformation.birthday =
                dateAddHyphen(viewStates.year, viewStates.month, viewStates.day)
            // 郵便番号
            customerInformation.zipCode = viewStates.postCode
            // 都道府県
            customerInformation.prefecture = viewStates.homePrefecture
            // 市区町村
            customerInformation.city = viewStates.homeCity
            // 丁目
            customerInformation.addrDetail2 = viewStates.chome
            // 番地（全角）
            customerInformation.addrDetail3 = viewStates.homeAddress
            // 建物名・号室（全角）
            customerInformation.buildingRoom = concatBuildRoomDb(viewStates.build, viewStates.room)
            // 都道府県（半角カナ）
            customerInformation.prefectureKana = viewStates.homePrefectureKana
            // 市区町村（半角カナ）
            customerInformation.cityKana = viewStates.homeCityKana
            // 丁目（半角カナ）
            customerInformation.addrDetail2Kana = viewStates.chomeKana
            // 番地（半角カナ）
            customerInformation.addrDetail3Kana = viewStates.homeAddressHalf
            // 建物名・号室（半角カナ）
            customerInformation.buildingRoomKana = concatBuildRoomKanaDb(viewStates.buildKana, viewStates.roomKana)
            // 電話番号種別１
            customerInformation.phoneType1 = viewStates.frequentlyPhoneType
            // 電話番号１（上）
            customerInformation.phoneNumOneFirst = viewStates.frequentlyPhoneFirst
            // 電話番号１（中）
            customerInformation.phoneNumOneMid = viewStates.frequentlyPhoneSecond
            // 電話番号１（下）
            customerInformation.phoneNumOneLast = viewStates.frequentlyPhoneThird
            // 電話番号種別２
            customerInformation.phoneType2 = viewStates.phoneType
            // 電話番号２（上）
            customerInformation.phoneNumTwoFirst = viewStates.phoneFirst
            // 電話番号２（中）
            customerInformation.phoneNumTwoMid = viewStates.phoneSecond
            // 電話番号２（下）
            customerInformation.phoneNumTwoLast = viewStates.phoneThird
            // 地区コード
            customerInformation.addressCode = viewStates.addressCode
            dbService.deleteAll(AccountOpeningAB0706::class.java)
            val ab0706 = AccountOpeningAB0706()
            ab0706.id = UUID.randomUUID().toString()
            ab0706.customerInformation = customerInformation.toJson()
            dbService.create(ab0706)
        } else {
            dbService.deleteAll(AccountOpeningAB0706::class.java)
            val ab0706 = AccountOpeningAB0706()
            ab0706.id = UUID.randomUUID().toString()
            requestBean.individualDto.addrDetail2Kana =
                requestBean.individualDto.addrDetail2Kana.replace("-", "")
            ab0706.customerInformation = requestBean.individualDto.toJson()
            dbService.create(ab0706)
        }
    }

    /**
     * 全部店リストを取得する(AB0112)
     */
    private fun getAllDepartmentStoreList() {
        if (PreferenceUtil.getPreferenceBooleanValue(OPENED_EDIT_INFO_FLAG)) {
            PreferenceUtil.setPreferenceBooleanValue(OPENED_EDIT_INFO_FLAG, false)
            if (viewStates.postCodeOld != viewStates.postCode) {
                PreferenceUtil.removePreferenceStringValue(ConstUtil.OPENED_HOPE_DEPARTMENT)
            }
            // 生年月日、丁目、番地が変更された場合、CC暗証番号がクリアされます
            if (viewStates.yearOld != viewStates.year || viewStates.monthOld != viewStates.month ||
                viewStates.dayOld != viewStates.day || viewStates.chomeOld != viewStates.chome ||
                viewStates.homeAddressOld != viewStates.homeAddress ||
                viewStates.chomeKanaOld != viewStates.chomeKana ||
                viewStates.homeAddressHalfOld != viewStates.homeAddressHalf) {
                KeyStoreUtil().saveToKeyStore(ConstUtil.CC_PASSWORD, "")
                PreferenceUtil.setPreferenceBooleanValue(OPENED_EDIT_INFO_FLAG, true)
            }
            RouteUtil.navTo(
                RouteName.MBOP1001Page
            )
        } else {
            PreferenceUtil.setPreferenceBooleanValue(OPENED_EDIT_INFO_FLAG, false)
            // MBOP0602　ご職業などの入力へ遷移する
            RouteUtil.navTo(RouteName.MBOP0602Page)
        }
    }

    /**
     * 郵便番号の自動検索
     */
    fun postInfoSearch() {
        // エラー情報初期化
        val errorBean = MBOP0601ErrorInformation()
        viewStates = viewStates.copy(isError = false, errorBean = errorBean, errMsgList = listOf())

        // 郵便番号が空白場合
        if (viewStates.postCode.isBlank()) {
            errorBean.postCodeErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0601_page_label_postCode)
                    )
                )
            )
        } else if (!viewStates.postCode.isHalfNum()) {
            // 郵便番号の半角数字チェック
            errorBean.postCodeErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                        MyApp.CONTEXT.getString(R.string.mbop0601_page_label_postCode)
                    )
                )
            )
        } else if (!lengthCheck(viewStates.postCode, 7)) {
            // 郵便番号の桁数チェック
            errorBean.postCodeErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002003V)
                )
            )
        }

        if (errorBean.postCodeErrorFlag) return

        // ・都道府県・市区町村・丁目・都道府県（半角カナ）・市区町村（半角カナ）・丁目（半角）クリア
        cleanAddress()
        viewModelScope.launch {
            val res: List<PostCodeResponseBean> = PostInfoSearchLogic(webService)
                .getPostInfo(PostCodeRequestBean(viewStates.postCode), "MBOP0601", "E02")

            // 住所漢字リスト
            val addressList: MutableList<CodeBean> = mutableListOf()

            // 住所漢字丁目なしリスト
            val addressNashiList: MutableList<CodeBean> = mutableListOf()

            // 住所カナリスト
            val addressKanaList: MutableList<CodeBean> = mutableListOf()

            // 住所カナ丁目なしリスト
            val addressKanaNashiList: MutableList<CodeBean> = mutableListOf()
            res.forEach { item ->
                if (item.address.isNotBlank()) {
                    addressList.add(CodeBean(item.addressCode, item.address))
                    addressKanaList.add(CodeBean(item.addressCode, item.addressKana))
                }
                if (item.addressNashi.isNotBlank()) {
                    addressNashiList.add(CodeBean(item.addressCode, item.addressNashi))
                    addressKanaNashiList.add(CodeBean(item.addressCode, item.addressKanaNashi))
                }
            }
            if (res.isNotEmpty()) {
                var candidateEnabled = true
                var candidateFlag = false
                var showFirstRecordFlag = false
                // 「丁目あり」が０件だった場合に、「丁目なし」のリストより市区町村項目に自動的に１項目を表示する。
                if (addressList.size == 0 || addressKanaList.size == 0) {
                    addressList.addAll(addressNashiList)
                    addressKanaList.addAll(addressKanaNashiList)
                    candidateEnabled = false
                    candidateFlag = true
                    showFirstRecordFlag = true
                }
                // 「丁目なし」が０件だった場合、チェックボックスのチェックができないようにする。
                if(addressNashiList.size == 0)
                {
                    candidateEnabled = false
                }

                // 郵便番号の自動検索により、以下の項目が自動反映されます。
                viewStates = viewStates.copy(
                    postData = res,
                    homePrefecture = if (res.isNotEmpty()) res[0].prefecture else "",
                    addressList = addressList,
                    addressNashiList = addressNashiList,
                    homePrefectureKana = if (res.isNotEmpty()) res[0].prefectureKana else "",
                    addressKanaList = addressKanaList,
                    addressKanaNashiList = addressKanaNashiList,
                    candidateEnabled = candidateEnabled,
                    candidateFlag = candidateFlag,
                    addressShowValue = if (showFirstRecordFlag && addressList.size > 0) addressList[0].code else "",
                    addressShowLabel = if (showFirstRecordFlag && addressList.size > 0) addressList[0].value else "",
                    addressKanaShowValue = if (showFirstRecordFlag && addressKanaList.size > 0)
                        addressKanaList[0].code else "",
                    addressKanaShowLabel = if (showFirstRecordFlag && addressKanaList.size > 0)
                        addressKanaList[0].value else "",
                    homeCity = if (showFirstRecordFlag && res.isNotEmpty()) res[0].city + res[0].addrDetail1 else "",
                    homeCityKana = if (showFirstRecordFlag && res.isNotEmpty())
                        res[0].cityKana + res[0].addrdetail1Kana else "",
                    chome = if (showFirstRecordFlag && res.isNotEmpty())
                        if (viewStates.candidateFlag) "" else res[0].addrDetail2 else "",
                    chomeKana = if (showFirstRecordFlag && res.isNotEmpty())
                        if (viewStates.candidateFlag) "" else when {
                            // 丁目カラムに「ﾁｮｳﾒ」があれば、「-」に変換する
                            res[0].addrdetail2Kana.contains(
                                MyApp.CONTEXT.getString(R.string.common_label_chome_kana)
                            ) -> {
                                res[0].addrdetail2Kana.replace(
                                    MyApp.CONTEXT.getString(R.string.common_label_chome_kana),
                                    ""
                                )
                            }
                            else -> {
                                res[0].addrdetail2Kana
                            }
                        } else "",
                    addressCode = res[0].addressCode
                )
            }
        }
    }

    fun cleanAddress() {
        viewStates = viewStates.copy(
            postData = listOf(),
            homePrefecture = "",
            addressShowValue = "",
            addressShowLabel = "",
            addressList = listOf(),
            addressNashiList = listOf(),
            homePrefectureKana = "",
            addressKanaShowValue = "",
            addressKanaShowLabel = "",
            addressKanaList = listOf(),
            addressKanaNashiList = listOf(),
            homeCity = "",
            homeCityKana = "",
            chome = "",
            chomeKana = "",
            candidateFlag = false,
            candidateEnabled = false,
        )
    }

    /**
     * アドレスの切替
     */
    fun onAddressShowChange(addressShow: CodeBean) {
        // 市区町村表示
        viewStates = viewStates.copy(addressShowValue = addressShow.code, addressShowLabel = addressShow.value)
        if (viewStates.addressShowValue.isNotBlank()) {
            // 市区町村カナ表示
            val addressKanaList = if (viewStates.candidateFlag)
                viewStates.addressKanaNashiList else viewStates.addressKanaList
            val thisAddressKanaShow = addressKanaList.first { it.code == addressShow.code }
            viewStates = viewStates.copy(
                addressKanaShowValue = thisAddressKanaShow.code,
                addressKanaShowLabel = thisAddressKanaShow.value
            )
            // 郵便情報
            if (viewStates.postData.isNotEmpty()) {
                val thisPost = viewStates.postData.first { it.addressCode == addressShow.code }
                viewStates = viewStates.copy(
                    homeCity = thisPost.city + thisPost.addrDetail1,
                    chome = if (viewStates.candidateFlag) "" else thisPost.addrDetail2,
                    homeCityKana = thisPost.cityKana + thisPost.addrdetail1Kana,
                    chomeKana = if (viewStates.candidateFlag) "" else when {
                        // 丁目カラムに「ﾁｮｳﾒ」があれば、「-」に変換する
                        thisPost.addrdetail2Kana.contains(
                            MyApp.CONTEXT.getString(R.string.common_label_chome_kana)
                        ) -> {
                            thisPost.addrdetail2Kana.replace(
                                MyApp.CONTEXT.getString(R.string.common_label_chome_kana),
                                ""
                            )
                        }
                        else -> {
                            thisPost.addrdetail2Kana
                        }
                    },
                    addressCode = thisPost.addressCode
                )
            }
        } else {
            viewStates = viewStates.copy(
                addressKanaShowValue = "",
                addressKanaShowLabel = "",
                homeCity = "",
                chome = "",
                homeCityKana = "",
                chomeKana = "",
                addressCode = ""
            )
        }
    }

    /**
     * 候補を表示するフラグ切替
     */
    fun onCandidateFlagChange() {
        viewStates = viewStates.copy(
            candidateFlag = !viewStates.candidateFlag,
            addressShowValue = "",
            addressShowLabel = "",
            addressKanaShowValue = "",
            addressKanaShowLabel = "",
            homeCity = "",
            chome = "",
            homeCityKana = "",
            chomeKana = "",
            addressCode = ""
        )
    }

    /**
     * アドレスカナの切替
     */
    fun onAddressKanaShowChange(addressKanaShow: CodeBean) {
        // 市区町村カナ表示
        viewStates =
            viewStates.copy(addressKanaShowValue = addressKanaShow.code, addressKanaShowLabel = addressKanaShow.value)
        if (viewStates.addressKanaShowValue.isNotBlank()) {
            // 市区町村表示
            val addressList = if (viewStates.candidateFlag)
                viewStates.addressNashiList else viewStates.addressList
            val thisAddressShow = addressList.first { it.code == addressKanaShow.code }
            viewStates = viewStates.copy(
                addressShowValue = thisAddressShow.code,
                addressShowLabel = thisAddressShow.value
            )
            // 郵便情報
            if (viewStates.postData.isNotEmpty()) {
                val thisPost = viewStates.postData.first { it.addressCode == addressKanaShow.code }
                viewStates = viewStates.copy(
                    homeCity = thisPost.city + thisPost.addrDetail1,
                    chome = if (viewStates.candidateFlag) "" else thisPost.addrDetail2,
                    homeCityKana = thisPost.cityKana + thisPost.addrdetail1Kana,
                    chomeKana = if (viewStates.candidateFlag) "" else when {
                        // 丁目カラムに「ﾁｮｳﾒ」があれば、「-」に変換する
                        thisPost.addrdetail2Kana.contains(
                            MyApp.CONTEXT.getString(R.string.common_label_chome_kana)
                        ) -> {
                            thisPost.addrdetail2Kana.replace(
                                MyApp.CONTEXT.getString(R.string.common_label_chome_kana),
                                ""
                            )
                        }
                        else -> {
                            thisPost.addrdetail2Kana
                        }
                    },
                    addressCode = thisPost.addressCode
                )
            }
        } else {
            viewStates = viewStates.copy(
                addressShowValue = "",
                addressShowLabel = "",
                homeCity = "",
                chome = "",
                homeCityKana = "",
                chomeKana = "",
                addressCode = ""
            )
        }
    }

    /**
     * パラメータセット
     */
    fun paramSet(bean: MBOP0601RequestBean) {

        // 口座開設申込情報（個人）
        val individualBean = Individual()

        // 氏名漢字（名）
        individualBean.customerKanjiFirstName = viewStates.secondName
        // 氏名漢字（姓）
        individualBean.customerKanjiLastName = viewStates.firstName
        // 氏名カナ（姓）
        individualBean.customerLastName = viewStates.firstKanaName
        // 氏名カナ（名）
        individualBean.customerFirstName = viewStates.secondKanaName
        // 性別
        individualBean.gender = viewStates.sex
        // 生年月日
        individualBean.birthday =
            dateAddHyphen(viewStates.year, viewStates.month, viewStates.day)
        // 郵便番号
        individualBean.zipCode = viewStates.postCode
        // 都道府県
        individualBean.prefecture = viewStates.homePrefecture
        // 市区町村
        individualBean.city = viewStates.homeCity
        // 丁目
        individualBean.addrDetail2 = viewStates.chome
        // 建物名・号室（全角）
        individualBean.buildingRoom = concatBuildRoom(viewStates.build, viewStates.room)
        // 番地（全角）
        individualBean.addrDetail3 = viewStates.homeAddress
        // 都道府県（半角カナ）
        individualBean.prefectureKana = viewStates.homePrefectureKana
        // 市区町村（半角カナ）
        individualBean.cityKana = viewStates.homeCityKana
        // 丁目（半角カナ）
        individualBean.addrDetail2Kana = if (viewStates.chomeKana.isNotBlank()) {
            if (viewStates.chomeKana.last().isDigit()) {
                viewStates.chomeKana + HALF_HYPHEN
            } else viewStates.chomeKana
        } else ""
        // 建物名・号室（半角カナ）
        individualBean.buildingRoomKana = concatBuildRoomKana(viewStates.buildKana, viewStates.roomKana)
        // 番地（半角カナ）
        individualBean.addrDetail3Kana = viewStates.homeAddressHalf
        // 電話番号種別１
        individualBean.phoneType1 = viewStates.frequentlyPhoneType
        // 電話番号１（上）
        individualBean.phoneNumOneFirst = viewStates.frequentlyPhoneFirst
        // 電話番号１（中）
        individualBean.phoneNumOneMid = viewStates.frequentlyPhoneSecond
        // 電話番号１（下）
        individualBean.phoneNumOneLast = viewStates.frequentlyPhoneThird
        // 電話番号種別２
        individualBean.phoneType2 = viewStates.phoneType
        // 電話番号２（上）
        individualBean.phoneNumTwoFirst = viewStates.phoneFirst
        // 電話番号２（中）
        individualBean.phoneNumTwoMid = viewStates.phoneSecond
        // 電話番号２（下）
        individualBean.phoneNumTwoLast = viewStates.phoneThird
        // 地区コード
        individualBean.addressCode = viewStates.addressCode
        // 人格区分
        bean.personType = PersonalityFlag.INDIVIDUAL_OTHER.code
        // 受付番号
        bean.receiptNumber = KeyStoreUtil().getFromKeyStore(ConstUtil.RECEIPT_NUMBER)
        // 画面ID
        bean.individualDto = individualBean
        // 更新パターン
        bean.updateType = UpdateType.UPDATE_TYPE_001.code
    }
}

package jp.co.jsbank.mb.bankingapp.logic.opened.mbop.mbop0602

import androidx.compose.foundation.ScrollState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import io.realm.Realm
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.bean.common.*
import jp.co.jsbank.mb.bankingapp.bean.opened.mbop.mbop0602.MBOP0602ResponseBean
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.repositories.db.common.create
import jp.co.jsbank.mb.bankingapp.repositories.db.common.deleteAll
import jp.co.jsbank.mb.bankingapp.repositories.db.common.findAll
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.*
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.system.MyApp
import jp.co.jsbank.mb.bankingapp.system.master.*
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0602.MBOP0602ErrorInformation
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0602.MBOP0602PageState
import jp.co.jsbank.mb.bankingapp.utils.*
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isHalfNum
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isPersonNameOther
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import java.util.*
import javax.inject.Inject

/**
 * MBOP0602ロジック
 */
@HiltViewModel
class MBOP0602Logic @Inject constructor(
    private var webService: RestService
) : ViewModel() {

    /**
     * MBOP0602ステータス
     */
    var viewStates by mutableStateOf(MBOP0602PageState())
        private set

    /**
     * ロカールDB
     */
    private var dbService: Realm = MyApp.INSTANCE

    /**
     * 初期化
     */
    init {
        PreferenceUtil.setPreferenceBooleanValue(ConstUtil.EDIT_FLAG, false)
        // 店舗リスト
        val departmentList = mutableListOf<DepartmentBean>()
        val deptInfo = dbService.findAll(EPassBookAB0112::class.java)
        if (deptInfo.isNotEmpty()) {
            val departmentJsonList = deptInfo[0]?.deptList
            if (!departmentJsonList.isNullOrEmpty()) {
                departmentJsonList.fromJson<List<Map<String, String>>>()?.forEach { item ->
                    departmentList.add(
                        DepartmentBean(
                            branchNumber = item["branchNumber"] ?: "",
                            branchKanjiName = item["branchKanjiName"] ?: ""
                        )
                    )
                }
            }
        }
        // 修正処理
        val accountOpeningAB0706 = dbService.findAll(AccountOpeningAB0706::class.java)
        if (accountOpeningAB0706.isNotEmpty()) {
            val customerInformation = accountOpeningAB0706[0]?.customerInformation?.fromJson<Individual>()!!
            viewStates = viewStates.copy(

                // 職業
                occupation = customerInformation.occupation,
                occupationOld = customerInformation.occupation,
                // 職業名
                occupationLabel = if (customerInformation.occupation.isNotEmpty())
                    occupationList.first { it.code == customerInformation.occupation }.value else "",
                // 職業（その他 ）
                occupationOther = customerInformation.occupationOther,
                // 取引目的
                transactionPurpose = customerInformation.transactPurpose,
                transactionPurposeOld = customerInformation.transactPurpose,
                // 取引目的名
                transactionPurposeLabel = if (customerInformation.transactPurpose.isNotEmpty())
                    individualTransactPurposeList.first {
                        it.code == customerInformation.transactPurpose
                    }.value else "",
                // 取引目的（その他 ）
                transactionPurposeOther = customerInformation.transactPurposeOther,
                // 取引のきっかけ
                transactionTrigger = customerInformation.transactionTrigger,
                // 取引のきっかけ名
                transactionTriggerLabel = if (customerInformation.transactionTrigger.isNotEmpty())
                    transactionTriggerList.first {
                        it.code == customerInformation.transactionTrigger
                    }.value else "",
                // 店番
                shop = customerInformation.branchNumber,
                // 店番名
                shopLabel = if (customerInformation.branchNumber.isNotEmpty() && departmentList.isNotEmpty())
                    customerInformation.branchNumber + " " + departmentList.first {
                        it.branchNumber == customerInformation.branchNumber
                    }.branchKanjiName else "",
                department = if (customerInformation.branchNumber.isNotEmpty() && departmentList.isNotEmpty())
                    customerInformation.branchNumber + " " + departmentList.first {
                        it.branchNumber == customerInformation.branchNumber
                    }.branchKanjiName else "",
                // 預金種目
                account = customerInformation.accountType,
                // 預金種目名
                accountLabel = if (customerInformation.accountType.isNotEmpty())
                    accountList.first { it.code == customerInformation.accountType }.value else "",
                // 口座番号
                accountNumber = customerInformation.accountNumber,
                // 取引原資
                transOriginalCapitalName = customerInformation.transOriginalCapitalName,
                transOriginalCapitalNameLabel = TransOriginalCapitalNameList.getName(customerInformation.transOriginalCapitalName),
                // 取引原資その他
                transOriginalCapitalOtherDescribeAnswer = customerInformation.transOriginalCapitalOtherDescribeAnswer,
                // 毎月の取引金額
                monthlyTransAmountName = customerInformation.monthlyTransAmountName,
                monthlyTransAmountNameLabel = MonthlyTransAmountNameList.getName(customerInformation.monthlyTransAmountName),
                // 取引頻度
                transFrequencyName = customerInformation.transFrequencyName,
                transFrequencyNameLabel = TransFrequencyNameList.getName(customerInformation.transFrequencyName),
                // ２００万超の現金取引予定
                twoMillionMoreCashTransScheduled = customerInformation.twoMillionMoreCashTransScheduled,
                twoMillionMoreCashTransScheduledLabel = TwoMillionMoreCashTransScheduled.getName(customerInformation.twoMillionMoreCashTransScheduled),
                // ２００万超取引理由
                twoMillionMoreTransReason = customerInformation.twoMillionMoreTransReason,
                // ２００万超取引頻度
                twoMillionMoreTransFrequencyName = customerInformation.twoMillionMoreTransFrequencyName,
                twoMillionMoreTransFrequencyNameLabel = TwoMillionMoreTransFrequencyName.getName(customerInformation.twoMillionMoreTransFrequencyName),
                // ２００万超取引金額
                twoMillionMoreTransAmountName = customerInformation.twoMillionMoreTransAmountName,
                twoMillionMoreTransAmountNameLabel = TwoMillionMoreTransAmountName.getName(customerInformation.twoMillionMoreTransAmountName),
            )
        }

        // 復元データを取得する
        getRestoreData(departmentList)
    }

    // 復元データを取得する
    private fun getRestoreData(departmentList: MutableList<DepartmentBean>) {
        val accountOpeningAB0701 = MyApp.INSTANCE.findAll(EPassBookAB0701::class.java)
        if (accountOpeningAB0701.isNotEmpty() && !MainActivity.HAS_RECOVERY_FLAG) {
            val individualInfo = accountOpeningAB0701[0]?.individual?.fromJson<Individual>()!!
            viewStates = viewStates.copy(
                // ご職業
                occupation = individualInfo.occupation,
                // ご職業
                occupationLabel = Occupation.getOccupationName(individualInfo.occupation),
                // ご職業（その他）
                occupationOther = individualInfo.occupationOther,
                // 取引目的
                transactionPurpose = individualInfo.transactPurpose,
                // 取引目的（その他）
                transactionPurposeOther = individualInfo.transactPurposeOther,
                // お取引の理由
                transactionTrigger = individualInfo.transactionTrigger,
                // お取引の理由
                transactionTriggerLabel =
                TransactionTrigger.getTransactionTriggerName(individualInfo.transactionTrigger),
                // 口座
                account = individualInfo.accountType,
                // 口座
                accountLabel = if (individualInfo.accountType.isNotEmpty())
                    AccountType.getAccountTypeName(individualInfo.accountType) else "",
                // 店舗名
                shop = individualInfo.branchNumber,
                // 店舗名
                shopLabel = if (individualInfo.branchNumber.isNotEmpty() && departmentList.isNotEmpty())
                    departmentList.first { it.branchNumber == individualInfo.branchNumber }.branchKanjiName else "",
                // 口座番号
                accountNumber = individualInfo.accountNumber,
                // 取引原資
                transOriginalCapitalName = individualInfo.transOriginalCapitalName,
                transOriginalCapitalNameLabel = TransOriginalCapitalNameList.getName(individualInfo.transOriginalCapitalName),
                // 取引原資その他
                transOriginalCapitalOtherDescribeAnswer = individualInfo.transOriginalCapitalOtherDescribeAnswer,
                // 毎月の取引金額
                monthlyTransAmountName = individualInfo.monthlyTransAmountName,
                monthlyTransAmountNameLabel = MonthlyTransAmountNameList.getName(individualInfo.monthlyTransAmountName),
                // 取引頻度
                transFrequencyName = individualInfo.transFrequencyName,
                transFrequencyNameLabel = TransFrequencyNameList.getName(individualInfo.transFrequencyName),
                // ２００万超の現金取引予定
                twoMillionMoreCashTransScheduled = individualInfo.twoMillionMoreCashTransScheduled,
                twoMillionMoreCashTransScheduledLabel = TwoMillionMoreCashTransScheduled.getName(individualInfo.twoMillionMoreCashTransScheduled),
                // ２００万超取引理由
                twoMillionMoreTransReason = individualInfo.twoMillionMoreTransReason,
                // ２００万超取引頻度
                twoMillionMoreTransFrequencyName = individualInfo.twoMillionMoreTransFrequencyName,
                twoMillionMoreTransFrequencyNameLabel = TwoMillionMoreTransFrequencyName.getName(individualInfo.twoMillionMoreTransFrequencyName),
                // ２００万超取引金額
                twoMillionMoreTransAmountName = individualInfo.twoMillionMoreTransAmountName,
                twoMillionMoreTransAmountNameLabel = TwoMillionMoreTransAmountName.getName(individualInfo.twoMillionMoreTransAmountName),
            )

            // 復元処理済みフラグ
            MainActivity.HAS_RECOVERY_FLAG = true
            MainActivity.SHOW_RETURN_BUTTON_FLAG = true
        }
    }

    /**
     * ご職業
     */
    fun setOccupation(value: String, code: String) {
        if (code != Occupation.OTHERS.code) {
            viewStates =
                viewStates.copy(occupationOther = "")
        }
        viewStates =
            viewStates.copy(occupationLabel = value, occupation = code)
        //ご職業が"学生"の場合
        if(viewStates.occupation == "07"){
            PreferenceUtil.setPreferenceBooleanValue("SHOW_SCHOOL", true)
            PreferenceUtil.setPreferenceBooleanValue("SHOW_WORK", false)
//       ご職業が"主婦・主夫"または"退職された方/無職の方"の場合
        }else if(viewStates.occupation == "06" || viewStates.occupation == "08" ){
            PreferenceUtil.setPreferenceBooleanValue("SHOW_SCHOOL", false)
            PreferenceUtil.setPreferenceBooleanValue("SHOW_WORK", false)
        }else{
            PreferenceUtil.setPreferenceBooleanValue("SHOW_WORK", true)
            PreferenceUtil.setPreferenceBooleanValue("SHOW_SCHOOL", false)
        }

    }
   // 2025/01/23 共同化ためマネロン　プルダウンを追加　end

    /**
     * 取引原資（名称）
     */
    fun setTransOriginalCapitalName(value: String, code: String) {
        if (code != TransOriginalCapitalNameList.OTHERS.code) {
            viewStates =
                viewStates.copy(transOriginalCapitalOtherDescribeAnswer = "")
        }
        viewStates =
            viewStates.copy(transOriginalCapitalNameLabel = value, transOriginalCapitalName = code)
    }

    /**
     * 毎月の取引金額
     */
    fun setMonthlyTransAmountName(value: String, code: String) {
        viewStates =
            viewStates.copy(monthlyTransAmountNameLabel = value, monthlyTransAmountName = code)
    }

    /**
     * 取引頻度
     */
    fun setTransFrequencyName(value: String, code: String) {
        viewStates =
            viewStates.copy(transFrequencyNameLabel = value, transFrequencyName = code)
    }

    /**
     * ２００万超の現金取引予定
     */
    fun setTwoMillionMoreCashTransScheduled(value: String, code: String) {
        viewStates =
            viewStates.copy(twoMillionMoreCashTransScheduledLabel = value, twoMillionMoreCashTransScheduled = code)
    }

    /**
     * ２００万超取引頻度
     */
    fun setTwoMillionMoreTransFrequencyName(value: String, code: String) {
        if (viewStates.twoMillionMoreCashTransScheduled != TwoMillionMoreCashTransScheduled.PLANNED.code) {
            viewStates =
                viewStates.copy(twoMillionMoreTransFrequencyName = "")
        }
        viewStates =
            viewStates.copy(twoMillionMoreTransFrequencyNameLabel = value, twoMillionMoreTransFrequencyName = code)
    }

    /**
     * ２００万超取引金額
     */
    fun setTwoMillionMoreTransAmountName(value: String, code: String) {
        if (viewStates.twoMillionMoreCashTransScheduled != TwoMillionMoreCashTransScheduled.PLANNED.code) {
            viewStates =
                viewStates.copy(twoMillionMoreTransFrequencyName = "")
        }
        viewStates =
            viewStates.copy(twoMillionMoreTransAmountNameLabel = value, twoMillionMoreTransAmountName = code)
    }
    // 2025/01/23 共同化ためマネロン　プルダウンを追加　end
    /**
     * 取引目的
     */
    fun setTransactionPurpose(value: String, code: String) {
        if (code != TransactPurpose.OTHERS.code) {
            viewStates.transactionPurposeOther = ""
        }
        viewStates = viewStates.copy(
            transactionPurposeLabel = value,
            transactionPurpose = code,
            transactionPurposeOther = viewStates.transactionPurposeOther
        )
    }

    /**
     * お取引の理由
     */
    fun setTransactionTrigger(value: String, code: String) {
        viewStates = viewStates.copy(transactionTriggerLabel = value)
        viewStates = viewStates.copy(transactionTrigger = code)
    }

    /**
     * 定期
     */
    fun setAccount(value: String, code: String) {
        viewStates = viewStates.copy(accountLabel = value)
        viewStates = viewStates.copy(account = code)
    }

    /**
     * エラーチェック
     */
    fun doNext(coroutineScope: CoroutineScope, scrollState: ScrollState) {
        // エラー情報初期化
        val errorBean = MBOP0602ErrorInformation()
        viewStates = viewStates.copy(isError = false, errorBean = errorBean, errMsgList = listOf())

        // ご職業が空白場合
        if (viewStates.occupation.isBlank()) {
            errorBean.occupationErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                        MyApp.CONTEXT.getString(R.string.mbop0602_page_label_occupation)
                    )
                )
            )
        }

        // ご職業がその他、かつ　ご職業（その他）が空白場合
        if (viewStates.occupation == Occupation.OTHERS.code) {
            if (viewStates.occupationOther.isBlank()) {
                errorBean.occupationOtherErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0602_page_label_occupation_other)
                        )
                    )
                )
            } else if (!viewStates.occupationOther.isPersonNameOther()) {
                // ご職業がその他の全角チェック
                errorBean.occupationOtherErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                            MyApp.CONTEXT.getString(R.string.mbop0602_page_label_occupation_other)
                        )
                    )
                )
            }
        }

        // 取引目的が空白場合
        if (viewStates.transactionPurpose.isBlank()) {
            errorBean.transactionPurposeErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                        MyApp.CONTEXT.getString(R.string.mbop0602_page_label_transaction_purpose)
                    )
                )
            )
        }

        // 取引目的がその他、かつ　取引目的（その他）が空白場合
        if (viewStates.transactionPurpose == TransactPurpose.OTHERS.code) {
            // 取引目的（その他）が空白場合
            if (viewStates.transactionPurposeOther.isBlank()) {
                errorBean.transactionPurposeOtherErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0602_page_label_transaction_purpose_other)
                        )
                    )
                )
            } else if (!viewStates.transactionPurposeOther.isPersonNameOther()) {
                // 取引目的（その他）の全角チェック
                errorBean.transactionPurposeOtherErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                            MyApp.CONTEXT.getString(R.string.mbop0602_page_label_transaction_purpose_other)
                        )
                    )
                )
            }
        }

        // お取引の理由が空白場合
        if (viewStates.transactionTrigger.isBlank()) {
            errorBean.transactionTriggerErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                        MyApp.CONTEXT.getString(R.string.mbop0602_page_label_transaction_trigger)
                    )
                )
            )
        }

        // 店番/科目/口座番号　のどれかが入力された場合は、３つ必須入力となる
        if (viewStates.account.isNotBlank() || viewStates.department.isNotBlank() ||
            viewStates.accountNumber.isNotBlank()
        ) {
            // 店舗名が空白場合
            if (viewStates.department.isBlank()) {
                errorBean.shopErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0602_page_label_shop_name)
                        )
                    )
                )
            }

            // 口座が空白場合
            if (viewStates.account.isBlank()) {
                errorBean.accountErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0602_page_label_account)
                        )
                    )
                )
            }

            // 口座番号が空白場合
            if (viewStates.accountNumber.isBlank()) {
                errorBean.accountNumberErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0602_page_label_account_number)
                        )
                    )
                )
            }
        }

//        // 口座を既に持ちの場合、店舗名を入力する必要がある
//        if (viewStates.account.isNotBlank() && viewStates.department.isBlank()) {
//            errorBean.shopErrorFlag = true
//            viewStates = viewStates.copy(errorBean = errorBean)
//            viewStates = viewStates.copy(isError = true)
//            viewStates = viewStates.copy(
//                errMsgList = viewStates.errMsgList.plus(
//                    MessageReplaceUtils.messageReplace(
//                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
//                        MyApp.CONTEXT.getString(R.string.mbop0602_page_label_shop_name)
//                    )
//                )
//            )
//        }
//
//        // 口座を既に持ちの場合、口座番号を入力する必要がある
//        if (viewStates.account.isNotBlank() && viewStates.accountNumber.isBlank()) {
//            errorBean.accountNumberErrorFlag = true
//            viewStates = viewStates.copy(errorBean = errorBean)
//            viewStates = viewStates.copy(isError = true)
//            viewStates = viewStates.copy(
//                errMsgList = viewStates.errMsgList.plus(
//                    MessageReplaceUtils.messageReplace(
//                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
//                        MyApp.CONTEXT.getString(R.string.mbop0602_page_label_account_number)
//                    )
//                )
//            )
//        }
        // 2025/01/23 共同化ため マネロン対応　を追加 start
        // 取引原資（名称）が空白場合
        if (viewStates.transOriginalCapitalName.isBlank()) {
            errorBean.transOriginalCapitalNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                        MyApp.CONTEXT.getString(R.string.mbop0602_page_label_trans_original_capital_name)
                    )
                )
            )
        }
        // 取引原資その他が空白場合
        if (viewStates.transOriginalCapitalName == TransOriginalCapitalNameList.OTHERS.code) {
            if (viewStates.transOriginalCapitalOtherDescribeAnswer.isBlank()) {
                errorBean.transOriginalCapitalOtherDescribeAnswerErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0602_page_label_transOriginal_capitalOther_describe_answer)
                        )
                    )
                )
            }
        }

        // 毎月の取引金額が空白場合
        if (viewStates.monthlyTransAmountName.isBlank()) {
            errorBean.monthlyTransAmountNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                        MyApp.CONTEXT.getString(R.string.mbop0602_page_label_monthly_transAmount_name)
                    )
                )
            )
        }

        // 取引頻度が空白場合
        if (viewStates.transFrequencyName.isBlank()) {
            errorBean.transFrequencyNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                        MyApp.CONTEXT.getString(R.string.mbop0602_page_label_trans_frequency_name)
                    )
                )
            )
        }

        // ２００万超の現金取引予定が空白場合
        if (viewStates.twoMillionMoreCashTransScheduled.isBlank()) {
            errorBean.twoMillionMoreCashTransScheduledErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                        MyApp.CONTEXT.getString(R.string.mbop0602_page_label_two_million_more_cash_trans_scheduled)
                    )
                )
            )
        } else if(viewStates.twoMillionMoreCashTransScheduled == TwoMillionMoreCashTransScheduled.NOT_SCHEDULED.code) {
            viewStates = viewStates.copy(twoMillionMoreTransReason = "")
            viewStates = viewStates.copy(twoMillionMoreTransFrequencyName = "")
            viewStates = viewStates.copy(twoMillionMoreTransAmountName = "")
        }

        // ２００万超取引理由が空白場合
        if (viewStates.twoMillionMoreCashTransScheduled == TwoMillionMoreCashTransScheduled.PLANNED.code) {
            if ( viewStates.twoMillionMoreTransReason.isBlank()) {
                errorBean.twoMillionMoreTransReasonErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                            MyApp.CONTEXT.getString(R.string.mbop0602_page_label_two_million_more_trans_reason)
                        )
                    )
                )
            }
        }

        // ２００万超取引頻度が空白場合
        if (viewStates.twoMillionMoreCashTransScheduled == TwoMillionMoreCashTransScheduled.PLANNED.code) {
            if (viewStates.twoMillionMoreTransFrequencyName.isBlank()) {
                errorBean.twoMillionMoreTransFrequencyNameErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                            MyApp.CONTEXT.getString(R.string.mbop0602_page_label_two_million_more_trans_frequency_name)
                        )
                    )
                )
            }
        }

        // ２００万超取引金額が空白場合
        if (viewStates.twoMillionMoreCashTransScheduled == TwoMillionMoreCashTransScheduled.PLANNED.code) {
            if (viewStates.twoMillionMoreTransAmountName.isBlank()) {
                errorBean.twoMillionMoreTransAmountNameErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                            MyApp.CONTEXT.getString(R.string.mbop0602_page_label_two_million_more_trans_amount_name)
                        )
                    )
                )
            }
        }
        // 2025/01/23 共同化ため マネロン対応　を追加 end

        if (viewStates.accountNumber.isNotBlank() &&
            !viewStates.accountNumber.isHalfNum()
        ) {
            // 口座番号が半角数字以外の場合
            errorBean.accountNumberErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                        MyApp.CONTEXT.getString(R.string.mbop0602_page_label_account_number)
                    )
                )
            )
        } else if (viewStates.accountNumber.isNotBlank() && viewStates.account == AccountType.FIXED_SAVINGS.code &&
            (!EditCheckUtil.lengthCheck(viewStates.accountNumber, 9) && !EditCheckUtil.lengthCheck(viewStates.accountNumber, 7))
        ) {
            // 定期預金：7/9桁
            errorBean.accountNumberErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(MyApp.CONTEXT.getString(R.string.MSG_ID_MB002024V))
            )
        } else if (viewStates.accountNumber.isNotBlank() && viewStates.account == AccountType.INSTALLMENT.code &&
             !EditCheckUtil.lengthCheck(viewStates.accountNumber, 7)
        ) {
            // 定期積金：7桁
            errorBean.accountNumberErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(MyApp.CONTEXT.getString(R.string.MSG_ID_MB002004V))
            )
        }

        if (!viewStates.isError) {
            occupationInput()
        } else {
            coroutineScope.launch {
                scrollState.animateScrollTo(0)
            }
        }
    }

    /**
     * ご職業などの入力
     */
    private fun occupationInput() {
        // 画面IDとイベントID設定
        PreferenceUtil.setScreenIDAndEventID("MBOP0602", "E06")
        paramSet(viewStates.requestBean)
        viewModelScope.launch {
            flow {
                ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, viewStates.requestBean.convertToParams().toJson())
                emit(webService.AB0707())
            }.map {
                // レスポンスからCiF情報をRealmに保存する
//                setCifRealmInfo(it.resultDto)

                // 画面入力した情報をRealmに保存する
                setRealmInfo(viewStates.requestBean)

                // 画面の店舗を選択場合
                if (viewStates.shop.isNotEmpty()) {
                    PreferenceUtil.setPreferenceStringValue(
                        ConstUtil.OPENED_DEPARTMENT,
                        viewStates.shop
                    )
                } else {
                    PreferenceUtil.removePreferenceStringValue(ConstUtil.OPENED_DEPARTMENT)
                }

                // 画面遷移
                navTo()
            }.catch {
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }
    }

    /**
     * レスポンスからCiF情報をRealmに保存
     */
    private fun setCifRealmInfo(responseBean: MBOP0602ResponseBean?) {
        // Realm情報更新
        dbService.deleteAll(AccountOpeningAB0707::class.java)
        val ab0707 = AccountOpeningAB0707()
        ab0707.id = UUID.randomUUID().toString()
        if (responseBean != null) {
            ab0707.cifInformation = responseBean.toJson()
        }
        dbService.create(ab0707)
    }

    /**
     * 画面入力した情報をRealmに保存する
     */
    fun setRealmInfo(requestBean: Individual) {
        // Realm情報更新
        val accountOpeningAB0706 = dbService.findAll(AccountOpeningAB0706::class.java)
        if (accountOpeningAB0706.isNotEmpty()) {
            val customerInformation =
                accountOpeningAB0706[0]?.customerInformation?.fromJson<Individual>()!!
            // 業種
//            customerInformation.category = viewStates.category;
            // 職業
            customerInformation.occupation = viewStates.occupation
            // 職業（その他 ）
            customerInformation.occupationOther = viewStates.occupationOther
            // 取引目的
            customerInformation.transactPurpose = viewStates.transactionPurpose
            // 取引目的（その他 ）
            customerInformation.transactPurposeOther = viewStates.transactionPurposeOther
            // 取引のきっかけ
            customerInformation.transactionTrigger = viewStates.transactionTrigger
            // 店番
            customerInformation.branchNumber = viewStates.shop.split(" ")[0]
            // 預金種目
            customerInformation.accountType = viewStates.account
            // 口座番号
            customerInformation.accountNumber = viewStates.accountNumber
            // 取引原資
            customerInformation.transOriginalCapitalName = viewStates.transOriginalCapitalName
            // 取引原資その他
            customerInformation.transOriginalCapitalOtherDescribeAnswer = viewStates.transOriginalCapitalOtherDescribeAnswer
            // 毎月の取引金額
            customerInformation.monthlyTransAmountName = viewStates.monthlyTransAmountName
            // 取引頻度
            customerInformation.transFrequencyName = viewStates.transFrequencyName
            // ２００万超の現金取引予定
            customerInformation.twoMillionMoreCashTransScheduled = viewStates.twoMillionMoreCashTransScheduled
            // ２００万超取引理由
            customerInformation.twoMillionMoreTransReason = viewStates.twoMillionMoreTransReason
            // ２００万超取引頻度
            customerInformation.twoMillionMoreTransFrequencyName = viewStates.twoMillionMoreTransFrequencyName
            // ２００万超取引金額
            customerInformation.twoMillionMoreTransAmountName = viewStates.twoMillionMoreTransAmountName

            dbService.deleteAll(AccountOpeningAB0706::class.java)
            val ab0706 = AccountOpeningAB0706()
            ab0706.id = UUID.randomUUID().toString()
            ab0706.customerInformation = customerInformation.toJson()
            dbService.create(ab0706)
        } else {
            dbService.deleteAll(AccountOpeningAB0706::class.java)
            val ab0706 = AccountOpeningAB0706()
            ab0706.id = UUID.randomUUID().toString()
            ab0706.customerInformation = requestBean.toJson()
            dbService.create(ab0706)
        }
    }

    /**
     * 画面遷移
     */
    private suspend fun navTo() {
        // 修正の場合
        if (PreferenceUtil.getPreferenceBooleanValue(ConstUtil.OPENED_EDIT_INFO_FLAG)) {
            PreferenceUtil.setPreferenceBooleanValue(ConstUtil.EDIT_FLAG, true)
            // 元職種が学生の場合
            if (viewStates.occupationOld == Occupation.STUDENT.code) {
                // 職種が変わらず場合
                if (viewStates.occupation == viewStates.occupationOld) {
                    // 元取引目的が「給与受取/年金受取」の場合
                    if (viewStates.transactionPurposeOld == TransactPurpose.SALARY_PENSION.code) {
                        // 取引目的が変わらず場合
                        if (viewStates.transactionPurpose == viewStates.transactionPurposeOld) {
                            PreferenceUtil.setPreferenceBooleanValue(ConstUtil.OPENED_EDIT_INFO_FLAG, false)
                            // MBOP1001申込内容入力確認画面（個人）に遷移する
                            RouteUtil.navTo(
                                RouteName.MBOP1001Page,
                            )
                        } else {
                            // 変更後の取引目的が「給与受取/年金受取」ではない場合、お勤め先の入力情報をクリアする
                            PreferenceUtil.removePreferenceStringValue(ConstUtil.OPENED_HOPE_DEPARTMENT)
                            // お勤め先情報クリア
                            enterCustomerInformation()
                            val requestBean = Individual()
                            paramSet(requestBean)
                            // MBOP0609　学校の入力
                            RouteUtil.navTo(
                                RouteName.MBOP0609Page + "/${requestBean.toJson()}",
                            )
                        }
                    } else {
                        // 元取引目的が「給与受取/年金受取」ではない場合 かつ　今の取引目的が「給与受取/年金受取」の場合
                        if (viewStates.transactionPurpose == TransactPurpose.SALARY_PENSION.code) {
                            PreferenceUtil.removePreferenceStringValue(ConstUtil.OPENED_HOPE_DEPARTMENT)
                            val requestBean = Individual()
                            paramSet(requestBean)
                            // MBOP0608お勤め先の入力に遷移する
                            RouteUtil.navTo(
                                RouteName.MBOP0608Page + "/${requestBean.toJson()}",
                            )
                        } else {
                            PreferenceUtil.setPreferenceBooleanValue(ConstUtil.OPENED_EDIT_INFO_FLAG, false)
                            // MBOP1001申込内容入力確認画面（個人）に遷移する
                            RouteUtil.navTo(
                                RouteName.MBOP1001Page,
                            )
                        }
                    }
                } else {
                    // 職種が変わる場合（学生ではない）
                    // 学校情報をクリアする
                    enterSchoolInformation()
                    PreferenceUtil.removePreferenceStringValue(ConstUtil.OPENED_HOPE_DEPARTMENT)

                    // 職種が退職された方/無職の方
                    // 「主婦/主夫」かつ「給与受取/年金受取」以外
                    if (viewStates.occupation == Occupation.RETIRED_UNEMPLOYED.code ||
                        (
                            viewStates.occupation == Occupation.HOUSEWIFE_HOUSEHUSBAND.code &&
                                viewStates.transactionPurpose != TransactPurpose.SALARY_PENSION.code
                            )
                    ) {
                        // お勤め先情報をクリアする
                        enterCustomerInformation()
                        PreferenceUtil.setPreferenceBooleanValue(ConstUtil.OPENED_EDIT_INFO_FLAG, false)
                        // MBOP1001申込内容入力確認画面（個人）に遷移する
                        RouteUtil.navTo(
                            RouteName.MBOP1001Page,
                        )
                    } else {
                        // お勤め先情報がある場合
                        val requestBean = Individual()
                        paramSet(requestBean)
                        // MBOP0608お勤め先の入力に遷移する
                        RouteUtil.navTo(
                            RouteName.MBOP0608Page + "/${requestBean.toJson()}",
                        )
                    }
                }
            } else if (viewStates.occupationOld == Occupation.RETIRED_UNEMPLOYED.code) {
                if (viewStates.occupation == viewStates.occupationOld) {
                    PreferenceUtil.setPreferenceBooleanValue(ConstUtil.OPENED_EDIT_INFO_FLAG, false)
                    // MBOP1001申込内容入力確認画面（個人）に遷移する
                    RouteUtil.navTo(
                        RouteName.MBOP1001Page,
                    )
                } else if (viewStates.occupation == Occupation.HOUSEWIFE_HOUSEHUSBAND.code) {
                    if (viewStates.transactionPurpose == TransactPurpose.SALARY_PENSION.code) {
                        PreferenceUtil.removePreferenceStringValue(ConstUtil.OPENED_HOPE_DEPARTMENT)
                        // お勤め先情報がある場合
                        val requestBean = Individual()
                        paramSet(requestBean)
                        // MBOP0608お勤め先の入力に遷移する
                        RouteUtil.navTo(
                            RouteName.MBOP0608Page + "/${requestBean.toJson()}",
                        )
                    } else {
                        PreferenceUtil.setPreferenceBooleanValue(ConstUtil.OPENED_EDIT_INFO_FLAG, false)
                        // MBOP1001申込内容入力確認画面（個人）に遷移する
                        RouteUtil.navTo(
                            RouteName.MBOP1001Page,
                        )
                    }
                } else if (viewStates.occupation == Occupation.STUDENT.code) {
                    if (viewStates.transactionPurpose == TransactPurpose.SALARY_PENSION.code) {
                        PreferenceUtil.removePreferenceStringValue(ConstUtil.OPENED_HOPE_DEPARTMENT)
                        // お勤め先情報がある場合
                        val requestBean = Individual()
                        paramSet(requestBean)
                        // MBOP0608お勤め先の入力に遷移する
                        RouteUtil.navTo(
                            RouteName.MBOP0608Page + "/${requestBean.toJson()}",
                        )
                    } else {
                        PreferenceUtil.removePreferenceStringValue(ConstUtil.OPENED_HOPE_DEPARTMENT)
                        val requestBean = Individual()
                        paramSet(requestBean)
                        // MBOP0609　学校の入力
                        RouteUtil.navTo(
                            RouteName.MBOP0609Page + "/${requestBean.toJson()}",
                        )
                    }
                } else {
                    PreferenceUtil.removePreferenceStringValue(ConstUtil.OPENED_HOPE_DEPARTMENT)
                    // お勤め先情報がある場合
                    val requestBean = Individual()
                    paramSet(requestBean)
                    // MBOP0608お勤め先の入力に遷移する
                    RouteUtil.navTo(
                        RouteName.MBOP0608Page + "/${requestBean.toJson()}",
                    )
                }
            } else if (viewStates.occupationOld == Occupation.HOUSEWIFE_HOUSEHUSBAND.code) {
                // 職種が変わらず場合
                if (viewStates.occupation == viewStates.occupationOld) {
                    // 元取引目的が「給与受取/年金受取」の場合
                    if (viewStates.transactionPurposeOld == TransactPurpose.SALARY_PENSION.code) {
                        // 取引目的が変わらず場合
                        if (viewStates.transactionPurpose == viewStates.transactionPurposeOld) {
                            PreferenceUtil.setPreferenceBooleanValue(ConstUtil.OPENED_EDIT_INFO_FLAG, false)
                            // MBOP1001申込内容入力確認画面（個人）に遷移する
                            RouteUtil.navTo(
                                RouteName.MBOP1001Page,
                            )
                        } else {
                            // 変更後の取引目的が「給与受取/年金受取」ではない場合、お勤め先の入力情報をクリアする
                            enterCustomerInformation()
                            PreferenceUtil.removePreferenceStringValue(ConstUtil.OPENED_HOPE_DEPARTMENT)
                            PreferenceUtil.setPreferenceBooleanValue(ConstUtil.OPENED_EDIT_INFO_FLAG, false)
                            // MBOP1001申込内容入力確認画面（個人）に遷移する
                            RouteUtil.navTo(
                                RouteName.MBOP1001Page,
                            )
                        }
                    } else {
                        // 元取引目的が「給与受取/年金受取」ではない場合 かつ　今の取引目的が「給与受取/年金受取」の場合
                        if (viewStates.transactionPurpose == TransactPurpose.SALARY_PENSION.code) {
                            PreferenceUtil.removePreferenceStringValue(ConstUtil.OPENED_HOPE_DEPARTMENT)
                            val requestBean = Individual()
                            paramSet(requestBean)
                            // MBOP0608お勤め先の入力に遷移する
                            RouteUtil.navTo(
                                RouteName.MBOP0608Page + "/${requestBean.toJson()}",
                            )
                        } else {
                            PreferenceUtil.setPreferenceBooleanValue(ConstUtil.OPENED_EDIT_INFO_FLAG, false)
                            // MBOP1001申込内容入力確認画面（個人）に遷移する
                            RouteUtil.navTo(
                                RouteName.MBOP1001Page,
                            )
                        }
                    }
                } else {
                    // 職種が変わる場合
                    // 職種が退職された方/無職の方
                    if (viewStates.occupation == Occupation.RETIRED_UNEMPLOYED.code) {
                        // 元取引目的が「給与受取/年金受取」の場合
                        if (viewStates.transactionPurposeOld == TransactPurpose.SALARY_PENSION.code) {
                            // お勤め先情報をクリアする
                            enterCustomerInformation()
                            PreferenceUtil.removePreferenceStringValue(ConstUtil.OPENED_HOPE_DEPARTMENT)
                            PreferenceUtil.setPreferenceBooleanValue(ConstUtil.OPENED_EDIT_INFO_FLAG, false)
                            // MBOP1001申込内容入力確認画面（個人）に遷移する
                            RouteUtil.navTo(
                                RouteName.MBOP1001Page,
                            )
                        } else {
                            // お勤め先情報をクリアする
                            enterCustomerInformation()
                            PreferenceUtil.setPreferenceBooleanValue(ConstUtil.OPENED_EDIT_INFO_FLAG, false)
                            // MBOP1001申込内容入力確認画面（個人）に遷移する
                            RouteUtil.navTo(
                                RouteName.MBOP1001Page,
                            )
                        }
                    } else if (viewStates.occupation == Occupation.STUDENT.code) {
                        if (viewStates.transactionPurpose == TransactPurpose.SALARY_PENSION.code) {
                            PreferenceUtil.removePreferenceStringValue(ConstUtil.OPENED_HOPE_DEPARTMENT)
                            // お勤め先情報がある場合
                            val requestBean = Individual()
                            paramSet(requestBean)
                            // MBOP0608お勤め先の入力に遷移する
                            RouteUtil.navTo(
                                RouteName.MBOP0608Page + "/${requestBean.toJson()}",
                            )
                        } else {
                            PreferenceUtil.removePreferenceStringValue(ConstUtil.OPENED_HOPE_DEPARTMENT)
                            // お勤め先情報クリア
                            enterCustomerInformation()
                            val requestBean = Individual()
                            paramSet(requestBean)
                            // MBOP0609　学校の入力
                            RouteUtil.navTo(
                                RouteName.MBOP0609Page + "/${requestBean.toJson()}",
                            )
                        }
                    } else {
                        PreferenceUtil.removePreferenceStringValue(ConstUtil.OPENED_HOPE_DEPARTMENT)
                        // お勤め先情報がある場合
                        val requestBean = Individual()
                        paramSet(requestBean)
                        // MBOP0608お勤め先の入力に遷移する
                        RouteUtil.navTo(
                            RouteName.MBOP0608Page + "/${requestBean.toJson()}",
                        )
                    }
                }
            } else {
                if (viewStates.occupation == viewStates.occupationOld) {
                    PreferenceUtil.setPreferenceBooleanValue(ConstUtil.OPENED_EDIT_INFO_FLAG, false)
                    // MBOP1001申込内容入力確認画面（個人）に遷移する
                    RouteUtil.navTo(
                        RouteName.MBOP1001Page,
                    )
                } else if (viewStates.occupation == Occupation.HOUSEWIFE_HOUSEHUSBAND.code) {
                    if (viewStates.transactionPurpose == TransactPurpose.SALARY_PENSION.code) {
                        PreferenceUtil.removePreferenceStringValue(ConstUtil.OPENED_HOPE_DEPARTMENT)
                        // お勤め先情報がある場合
                        val requestBean = Individual()
                        paramSet(requestBean)
                        // MBOP0608お勤め先の入力に遷移する
                        RouteUtil.navTo(
                            RouteName.MBOP0608Page + "/${requestBean.toJson()}",
                        )
                    } else {
                        PreferenceUtil.removePreferenceStringValue(ConstUtil.OPENED_HOPE_DEPARTMENT)
                        // お勤め先情報クリア
                        enterCustomerInformation()
                        PreferenceUtil.setPreferenceBooleanValue(ConstUtil.OPENED_EDIT_INFO_FLAG, false)
                        // MBOP1001申込内容入力確認画面（個人）に遷移する
                        RouteUtil.navTo(
                            RouteName.MBOP1001Page,
                        )
                    }
                } else if (viewStates.occupation == Occupation.STUDENT.code) {
                    if (viewStates.transactionPurpose == TransactPurpose.SALARY_PENSION.code) {
                        PreferenceUtil.removePreferenceStringValue(ConstUtil.OPENED_HOPE_DEPARTMENT)
                        // お勤め先情報がある場合
                        val requestBean = Individual()
                        paramSet(requestBean)
                        // MBOP0608お勤め先の入力に遷移する
                        RouteUtil.navTo(
                            RouteName.MBOP0608Page + "/${requestBean.toJson()}",
                        )
                    } else {
                        PreferenceUtil.removePreferenceStringValue(ConstUtil.OPENED_HOPE_DEPARTMENT)
                        // お勤め先情報クリア
                        enterCustomerInformation()
                        val requestBean = Individual()
                        paramSet(requestBean)
                        // MBOP0609　学校の入力
                        RouteUtil.navTo(
                            RouteName.MBOP0609Page + "/${requestBean.toJson()}",
                        )
                    }
                } else if (viewStates.occupation == Occupation.RETIRED_UNEMPLOYED.code) {
                    PreferenceUtil.removePreferenceStringValue(ConstUtil.OPENED_HOPE_DEPARTMENT)
                    // お勤め先情報クリア
                    enterCustomerInformation()
                    PreferenceUtil.setPreferenceBooleanValue(ConstUtil.OPENED_EDIT_INFO_FLAG, false)
                    // MBOP1001申込内容入力確認画面（個人）に遷移する
                    RouteUtil.navTo(
                        RouteName.MBOP1001Page,
                    )
                } else {
                    PreferenceUtil.removePreferenceStringValue(ConstUtil.OPENED_HOPE_DEPARTMENT)
                    // お勤め先情報がある場合
                    val requestBean = Individual()
                    paramSet(requestBean)
                    // MBOP0608お勤め先の入力に遷移する
                    RouteUtil.navTo(
                        RouteName.MBOP0608Page + "/${requestBean.toJson()}",
                    )
                }
            }
        } else {
            // お勤め先の入力画面は、以下が選択された場合に表示します。
            // ①ご職業に以下を選択した場合
            // 「会社役員/団体役員」
            // 「会社員/団体職員」
            // 「公務員」
            // 「個人事業主/自営業」
            // 「パート/アルバイト/派遣社員/契約社員」
            // 「その他」

            // ②ご職業と取引目的に以下を選択した場合
            // 「主婦/主夫」かつ「給与受取/年金受取」
            // 「学生」かつ「給与受取/年金受取」
            if ((
                    viewStates.occupation == Occupation.COMPANY_GROUP_OFFICER.code ||
                        viewStates.occupation == Occupation.COMPANY_GROUP_EMPLOYEE.code ||
                        viewStates.occupation == Occupation.CIVIL_SERVANT.code ||
                        viewStates.occupation == Occupation.SELF_EMPLOYED.code ||
                        viewStates.occupation == Occupation.PART_TEMPORARY_CONTRACT_EMPLOYEE.code ||
                        viewStates.occupation == Occupation.OTHERS.code
                    ) ||
                (
                    (
                        viewStates.occupation == Occupation.HOUSEWIFE_HOUSEHUSBAND.code &&
                            viewStates.transactionPurpose == TransactPurpose.SALARY_PENSION.code
                        ) ||
                        (
                            viewStates.occupation == Occupation.STUDENT.code &&
                                viewStates.transactionPurpose == TransactPurpose.SALARY_PENSION.code
                            )
                    )
            ) {
                val requestBean = Individual()
                paramSet(requestBean)
                // MBOP0608　お勤め先の入力
                RouteUtil.navTo(
                    RouteName.MBOP0608Page + "/${requestBean.toJson()}",
                )
            }

            // 学校の入力画面は、以下が選択された場合に表示します。
            // ①ご職業に以下を選択した場合
            // 「学生」
            else if (viewStates.occupation == Occupation.STUDENT.code &&
                viewStates.transactionPurpose != TransactPurpose.SALARY_PENSION.code
            ) {
                val requestBean = Individual()
                paramSet(requestBean)
                // MBOP0609　学校の入力
                RouteUtil.navTo(
                    RouteName.MBOP0609Page + "/${requestBean.toJson()}",
                )
            } else {
                // MBCO0201　メールアドレス入力
                RouteUtil.navTo(
                    RouteName.MBCO0201Page,
                    ConstUtil.MAIL_CONFIRM_TYPE_INDIVIDUAL
                )
            }
        }
    }

    /**
     * パラメータセット
     */
    fun paramSet(bean: Individual) {
        // ご職業
        bean.occupation = viewStates.occupation
        // ご職業（その他）
        bean.occupationOther = viewStates.occupationOther
        // 取引目的
        bean.transactPurpose = viewStates.transactionPurpose
        // 取引目的（その他）
        bean.transactPurposeOther = viewStates.transactionPurposeOther
        // お取引の理由
        bean.transactionTrigger = viewStates.transactionTrigger
        // 店舗名
        bean.branchNumber = viewStates.shop.split(" ")[0]
        // 定期・定積口座番号
        bean.accountType = viewStates.account
        // 口座番号
        bean.accountNumber = viewStates.accountNumber
        // 人格区分
        bean.personType = PersonalityFlag.INDIVIDUAL_OTHER.code
        // 受付番号
        bean.receiptNumber = KeyStoreUtil().getFromKeyStore(ConstUtil.RECEIPT_NUMBER)
        // 更新パターン
        bean.updateType = UpdateType.UPDATE_TYPE_002.code

        // 2025/04/18 共同化対応
        paramSet2(bean);
    }

    /**
     * パラメータセット(共同化対応)
     */
    private fun paramSet2(bean: Individual) {

        // 業種
        bean.category = "039"//TODO API対応のため、一旦固定値で渡す

        // 取引原資（名称）
        bean.transOriginalCapitalName = viewStates.transOriginalCapitalName
        // 取引原資その他
        bean.transOriginalCapitalOtherDescribeAnswer = viewStates.transOriginalCapitalOtherDescribeAnswer
        // 毎月の取引金額
        bean.monthlyTransAmountName = viewStates.monthlyTransAmountName
        // 取引頻度
        bean.transFrequencyName = viewStates.transFrequencyName
        // ２００万超の現金取引予定
        bean.twoMillionMoreCashTransScheduled = viewStates.twoMillionMoreCashTransScheduled
        // ２００万超取引理由
        bean.twoMillionMoreTransReason = viewStates.twoMillionMoreTransReason
        // ２００万超取引頻度
        bean.twoMillionMoreTransFrequencyName = viewStates.twoMillionMoreTransFrequencyName
        // ２００万超取引金額
        bean.twoMillionMoreTransAmountName = viewStates.twoMillionMoreTransAmountName
    }

    /**
     * お勤め先情報入力
     */
    private suspend fun enterCustomerInformation() {
        // 画面IDとイベントID設定
        PreferenceUtil.setScreenIDAndEventID("MBOP0602", "E06")
        val requestBean = Individual()
        requestBean.updateType = UpdateType.UPDATE_TYPE_009.code
        // 受付番号
        requestBean.receiptNumber = KeyStoreUtil().getFromKeyStore(ConstUtil.RECEIPT_NUMBER)
        viewModelScope.async {
            flow {
                ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, requestBean.convertToParams().toJson())
                emit(webService.AB0703())
            }.map {
                // 画面入力した情報をRealmに保存する
                MyApp.INSTANCE.deleteAll(AccountOpeningAB0703::class.java)
            }.catch {
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }.await()
    }

    /**
     * 学校情報入力入力
     */
    private suspend fun enterSchoolInformation() {
        // 画面IDとイベントID設定
        PreferenceUtil.setScreenIDAndEventID("MBOP0602", "E06")
        val requestBean = Individual()
        // 受付番号
        requestBean.receiptNumber = KeyStoreUtil().getFromKeyStore(ConstUtil.RECEIPT_NUMBER)
        // 更新パターン
        requestBean.updateType = UpdateType.UPDATE_TYPE_010.code
        viewModelScope.async {
            flow {
                ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, requestBean.convertToParams().toJson())
                emit(webService.AB0704())
            }.map {
                dbService.deleteAll(AccountOpeningAB0704::class.java)
            }.catch {
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }.await()
    }
}

package jp.co.jsbank.mb.bankingapp.logic.opened.mbop.mbop0701

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.gson.Gson
import dagger.hilt.android.lifecycle.HiltViewModel
import io.realm.Realm
import javax.inject.Inject
import jp.co.jsbank.mb.bankingapp.bean.common.CorporationBean
import jp.co.jsbank.mb.bankingapp.bean.common.Individual
import jp.co.jsbank.mb.bankingapp.bean.common.ZipCodeInfoBean
import jp.co.jsbank.mb.bankingapp.bean.opened.mbop.mbop0613.MBOP0613RequestBean
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.repositories.db.common.findAll
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.AccountOpeningAB0703
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.AccountOpeningAB0704
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.AccountOpeningAB0706
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.AccountOpeningAB0719
import jp.co.jsbank.mb.bankingapp.system.Config.isRetail
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.system.MyApp
import jp.co.jsbank.mb.bankingapp.system.master.CandidateFlag
import jp.co.jsbank.mb.bankingapp.system.master.PersonalityFlag
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0701.MBOP0701PageState
import jp.co.jsbank.mb.bankingapp.utils.*
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/**
 * MBOP0701ロジック
 */
@HiltViewModel
class MBOP0701Logic @Inject constructor(
    private var webService: RestService
) : ViewModel() {

    /**
     * ステータス
     */
    var viewStates by mutableStateOf(MBOP0701PageState())
        private set

    /**
     * ロカールDB
     */
    private var dbService: Realm = MyApp.INSTANCE

    /**
     * 初期化
     */
    init {
        // 復元処理済みフラグ
        MainActivity.HAS_RECOVERY_FLAG = true
        MainActivity.SHOW_RETURN_BUTTON_FLAG = true
        // 個人
        if (PreferenceUtil.getPreferenceStringValue(ConstUtil.PERSONALITY_FLAG) ==
            PersonalityFlag.INDIVIDUAL_OTHER.code
        ) {
            //ご職業が("主婦・主夫","退職された方/無職の方","学生")以外の場合
            if(PreferenceUtil.getPreferenceBooleanValue("SHOW_WORK")){
                // お勤め先情報
                val accountOpeningAB0703 = dbService.findAll(AccountOpeningAB0703::class.java)
                if (accountOpeningAB0703.isNotEmpty()) {
                    val workPlaceInformation = accountOpeningAB0703[0]?.workPlaceInformation?.fromJson<Individual>()!!
                    if (workPlaceInformation.wpZipCode.isNotBlank()) {
                        viewStates = viewStates.copy(showWorkPlace = true)
                    }
                }
             //ご職業が"学生"の場合
            }else if(PreferenceUtil.getPreferenceBooleanValue("SHOW_SCHOOL")){
                // 学校情報
                val accountOpeningAB0704 = dbService.findAll(AccountOpeningAB0704::class.java)
                if (accountOpeningAB0704.isNotEmpty()) {
                    val schoolInformation = accountOpeningAB0704[0]?.schoolInformation?.fromJson<Individual>()!!
                    if (schoolInformation.schZipCode.isNotBlank()) {
                        viewStates = viewStates.copy(showSchool = true)
                    }
                }
            }else{
                viewStates = viewStates.copy(showWorkPlace = false)
                viewStates = viewStates.copy(showSchool = false)
            }
        } else if (PreferenceUtil.getPreferenceStringValue(ConstUtil.PERSONALITY_FLAG) ==
            PersonalityFlag.CORPORATION.code
        ) {
            val accountOpeningAB0706 = dbService.findAll(AccountOpeningAB0706::class.java)
            if (accountOpeningAB0706.isNotEmpty()) {
                val customerInformation =
                    accountOpeningAB0706[0]?.customerInformation?.fromJson<CorporationBean>()!!
                if (customerInformation.headOfficeLocZipCode.isNotBlank()) {
                    viewStates = viewStates.copy(showHeadOfficeLoc = true)
                }
            }
        } else {
            // 所在地情報
            val accountOpeningAB0719 = dbService.findAll(AccountOpeningAB0719::class.java)
            if (accountOpeningAB0719.isNotEmpty()) {
                val locationInformation = accountOpeningAB0719[0]?.locationInformation
                    ?.fromJson<MBOP0613RequestBean>()!!
                if (locationInformation.locationZipCode.isNotBlank()) {
                    viewStates = viewStates.copy(showLocation = true)
                }
            }
        }
    }

    /**
     * 店舗検索
     */
    fun getDepartmentList(postCode: String?) {
        // 画面IDとイベントID設定
        PreferenceUtil.setScreenIDAndEventID("MBOP0701", "E02")
        viewModelScope.launch {
            val bean = ZipCodeInfoBean()
            bean.zipCode = postCode ?: ""
            flow {
                ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, bean.toJson())
                emit(webService.AB0708())
            }.map {
                when (it.resultDto!!.alternateFlg) {
                    // 候補有り
                    CandidateFlag.HAS_CANDIDATE.code -> {
                        MainActivity.STORE_SHOW_POSITION = ""
                        RouteUtil.navTo(
                            RouteName.MBOP0702Page,
                            Gson().toJson(it.resultDto!!.departmentStoreList)
                        )
                    }
                    // 候補なし
                    CandidateFlag.NO_CANDIDATE_DOWN.code -> {
                        // 個人場合
                        if (isRetail()) {
                            MainActivity.STORE_SHOW_POSITION = "2"
                        } else {
                            MainActivity.STORE_SHOW_POSITION = ""
                        }
                        RouteUtil.navTo(
                            RouteName.MBOP0704Page,
                            Gson().toJson(it.resultDto!!.branchList)
                        )
                    }
                    // 候補なし
                    CandidateFlag.NO_CANDIDATE_UP.code -> {
                        // 個人場合
                        if (isRetail()) {
                            MainActivity.STORE_SHOW_POSITION = "1"
                            RouteUtil.navTo(
                                RouteName.MBOP0704Page,
                                Gson().toJson(it.resultDto!!.branchList)
                            )
                        } else {
                            openAccountOpeningDialogFlag()
                        }
                    }
                    else -> {
                        openAccountOpeningDialogFlag()
                    }
                }
            }.catch {
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }
    }

    /**
     * 口座開設ダイアログ
     */
    private fun openAccountOpeningDialogFlag() {
        viewStates = viewStates.copy(accountOpeningDialogFlag = true)
    }

    /**
     * 口座開設ダイアログクルーズ
     */
    fun closeAccountOpeningDialogFlag() {
        viewStates = viewStates.copy(accountOpeningDialogFlag = false)
    }
}

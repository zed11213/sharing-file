package jp.co.jsbank.mb.bankingapp.logic.opened.mbop.mbop0103

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0103.MBOP0103PageState

/**
 * MBOP0103ロジック
 */
@HiltViewModel
class MBOP0103Logic @Inject constructor() : ViewModel() {

    // MBSU0103ステータス
    var viewStates by mutableStateOf(MBOP0103PageState())
        private set
}

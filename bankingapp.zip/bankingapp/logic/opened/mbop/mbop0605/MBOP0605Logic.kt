package jp.co.jsbank.mb.bankingapp.logic.opened.mbop.mbop0605

import androidx.compose.foundation.ScrollState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import io.realm.Realm
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.bean.common.CodeBean
import jp.co.jsbank.mb.bankingapp.bean.common.CorporationBean
import jp.co.jsbank.mb.bankingapp.bean.opened.mbop.mbop0601.MBOP0601RequestBean
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.repositories.db.common.create
import jp.co.jsbank.mb.bankingapp.repositories.db.common.deleteAll
import jp.co.jsbank.mb.bankingapp.repositories.db.common.findAll
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.AccountOpeningAB0706
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.EPassBookAB0701
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.system.MyApp
import jp.co.jsbank.mb.bankingapp.system.master.*
import jp.co.jsbank.mb.bankingapp.system.master.BusinessDescription.Companion.getBusinessDescriptionName
import jp.co.jsbank.mb.bankingapp.system.master.PreferredTrade.Companion.getPreferredTradeName
import jp.co.jsbank.mb.bankingapp.system.master.TransactPurpose.Companion.getTransactPurposeName
import jp.co.jsbank.mb.bankingapp.system.master.TransactionTrigger.Companion.getTransactionTriggerName
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0605.MBOP0605ErrorInformation
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0605.MBOP0605PageState
import jp.co.jsbank.mb.bankingapp.utils.*
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.MAIL_CONFIRM_TYPE_CORPORATION
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.PERSONALITY_FLAG
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.RECEIPT_NUMBER
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isHalfNum
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isPersonNameOther
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import java.util.*
import javax.inject.Inject

/**
 * MBOP0605ロジック
 */
@HiltViewModel
class MBOP0605Logic @Inject constructor(
    private var webService: RestService
) : ViewModel() {

    // ログインステータス
    var viewStates by mutableStateOf(MBOP0605PageState())
        private set

    // ロカールDB
    private var dbService: Realm = MyApp.INSTANCE

    // エラーチェック
    fun doNext(coroutineScope: CoroutineScope, scrollState: ScrollState) {
        // エラー情報初期化
        val errorBean = MBOP0605ErrorInformation()
        viewStates = viewStates.copy(isError = false)
        viewStates = viewStates.copy(errorBean = errorBean)
        viewStates = viewStates.copy(errorMessageList = listOf())

        // 取引目的（事業先）が空白場合
        if (viewStates.transactionPurpose.isBlank()) {
            errorBean.transactionPurposeErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                        MyApp.CONTEXT.getString(R.string.mbop0605_page_label_transaction_purpose)
                    )
                )
            )
        }

        if (viewStates.transactionPurpose == TransactPurpose.OTHERS.code) {
            // 取引目的（事業先）（その他）が空白場合
            if (viewStates.transactionPurposeOther.isBlank()) {
                errorBean.transactionPurposeOtherErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0605_page_label_transaction_purpose_other)
                        )
                    )
                )
            } else if (!viewStates.transactionPurposeOther.isPersonNameOther()) {
                // 取引目的（事業先）（その他）の全角チェック
                errorBean.transactionPurposeOtherErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                            MyApp.CONTEXT.getString(R.string.mbop0605_page_label_transaction_purpose_other)
                        )
                    )
                )
            }
        }
        if (viewStates.transactionPurposeDetail.isNotBlank()) {
            if (!viewStates.transactionPurposeDetail.isPersonNameOther()) {
                // 取引目的（詳細）の全角チェック
                errorBean.transactionPurposeDetailErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                            MyApp.CONTEXT.getString(R.string.mbop0605_page_label_transaction_purpose_detail)
                        )
                    )
                )
            }
        }

        // 事業内容が空白場合
        if (viewStates.businessContent.isBlank()) {
            errorBean.businessContentErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                        MyApp.CONTEXT.getString(R.string.mbop0605_page_label_business_content)
                    )
                )
            )
        }

        if (viewStates.businessContent == BusinessDescription.OTHERS.code) {
            // 事業内容（その他）が空白場合
            if (viewStates.businessContentOther.isBlank()) {
                errorBean.businessContentOtherErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0605_page_label_business_content_other)
                        )
                    )
                )
            } else if (!viewStates.businessContentOther.isPersonNameOther()) {
                // 事業内容（その他）の全角チェック
                errorBean.businessContentOtherErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                            MyApp.CONTEXT.getString(R.string.mbop0605_page_label_business_content_other)
                        )
                    )
                )
            }
        }

        // 取扱品目が空白場合
        if (viewStates.itemsHandled.isBlank()) {
            errorBean.itemsHandledErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0605_page_label_items_handled)
                    )
                )
            )
        } else if (!viewStates.itemsHandled.isPersonNameOther()) {
            errorBean.itemsHandledErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                        MyApp.CONTEXT.getString(R.string.mbop0605_page_label_items_handled)
                    )
                )
            )
        }

        // 主要取引先（仕入）が空白場合
        if (viewStates.majorCustomersPurchasing.isBlank()) {
            errorBean.majorCustomersPurchasingErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0605_page_label_major_customers_purchasing)
                    )
                )
            )
        } else if (!viewStates.majorCustomersPurchasing.isPersonNameOther()) {
            errorBean.majorCustomersPurchasingErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                        MyApp.CONTEXT.getString(R.string.mbop0605_page_label_major_customers_purchasing)
                    )
                )
            )
        }

        // 主要取引先（販売）が空白場合
        if (viewStates.majorCustomersSales.isBlank()) {
            errorBean.majorCustomersSalesErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0605_page_label_major_customers_sales)
                    )
                )
            )
        } else if (!viewStates.majorCustomersSales.isPersonNameOther()) {
            errorBean.majorCustomersSalesErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                        MyApp.CONTEXT.getString(R.string.mbop0605_page_label_major_customers_sales)
                    )
                )
            )
        }

        // 当金庫との主な取引希望が空白場合
        if (viewStates.preferredTrade.isBlank()) {
            errorBean.preferredTradeErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                        MyApp.CONTEXT.getString(R.string.mbop0605_page_label_preferred_trade)
                    )
                )
            )
        }

        if (viewStates.preferredTrade == PreferredTrade.OTHERS.code) {
            // 当金庫との主な取引希望（その他）が空白場合
            if (viewStates.preferredTradeOther.isBlank()) {
                errorBean.preferredTradeOtherErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0605_page_label_preferred_trade_other)
                        )
                    )
                )
            } else if (!viewStates.preferredTradeOther.isPersonNameOther()) {
                // 当金庫との主な取引希望（その他）の全角チェック
                errorBean.preferredTradeOtherErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                            MyApp.CONTEXT.getString(R.string.mbop0605_page_label_preferred_trade_other)
                        )
                    )
                )
            }
        }

        // お取引の理由が空白場合
        if (viewStates.triggerTransaction.isBlank()) {
            errorBean.triggerTransactionErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                        MyApp.CONTEXT.getString(R.string.mbop0605_page_label_trigger_transaction)
                    )
                )
            )
        }

        // 取引金融機関、預金状況、貸金状況どれかが入力された場合は、３つ必須入力となる
        if (viewStates.financialInstitution.isNotBlank() || viewStates.depositStatus.isNotBlank() ||
            viewStates.loanStatus.isNotBlank()
        ) {
            if (viewStates.financialInstitution.isBlank()) {
                errorBean.financialInstitutionErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0605_page_label_financial_institution)
                        )
                    )
                )
            } else {
                if (!viewStates.financialInstitution.isPersonNameOther()) {
                    errorBean.financialInstitutionErrorFlag = true
                    viewStates = viewStates.copy(errorBean = errorBean)
                    viewStates = viewStates.copy(isError = true)
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MessageReplaceUtils.messageReplace(
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                                MyApp.CONTEXT.getString(R.string.mbop0605_page_label_financial_institution)
                            )
                        )
                    )
                }
            }

            // 取引金融機関　預金状況が空白場合
            if (viewStates.depositStatus.isBlank()) {
                errorBean.depositStatusErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0605_page_label_deposit_status)
                        )
                    )
                )
            } else if (!viewStates.depositStatus.isHalfNum()) {
                errorBean.depositStatusErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                            MyApp.CONTEXT.getString(R.string.mbop0605_page_label_deposit_status)
                        )
                    )
                )
            }

            // 取引金融機関　貸金状況が空白場合
            if (viewStates.loanStatus.isBlank()) {
                errorBean.loanStatusErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0605_page_label_loan_status)
                        )
                    )
                )
            } else if (!viewStates.loanStatus.isHalfNum()) {
                errorBean.loanStatusErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                            MyApp.CONTEXT.getString(R.string.mbop0605_page_label_loan_status)
                        )
                    )
                )
            }
        }

        if (!viewStates.isError) {
            // 口座開設申込情報（法人）
            val corporation = viewStates.corporation
            corporation.receiptNumber = KeyStoreUtil().getFromKeyStore(RECEIPT_NUMBER)
            corporation.transactPurpose = viewStates.transactionPurpose
            corporation.transactPurposeOther = viewStates.transactionPurposeOther
            corporation.transactPurposeDetail = viewStates.transactionPurposeDetail
            corporation.businessDescription = viewStates.businessContent
            corporation.businessDescriptionOther = viewStates.businessContentOther
            corporation.handingItem = viewStates.itemsHandled
            corporation.mainlyTradePurchase = viewStates.majorCustomersPurchasing
            corporation.mainlyTradeSale = viewStates.majorCustomersSales
            corporation.preferredTrade = viewStates.preferredTrade
            corporation.otherBusinessWishes = viewStates.preferredTradeOther
            corporation.transactionTrigger = viewStates.triggerTransaction
            corporation.financialInstitution = viewStates.financialInstitution
            corporation.financialInstitutionDepositStatus = viewStates.depositStatus
            corporation.financialInstitutionLoanStatus = viewStates.loanStatus
            corporation.pageId = "MBOP0605"
            viewStates = viewStates.copy(corporation = corporation)
            // 画面IDとイベントID設定
            PreferenceUtil.setScreenIDAndEventID("MBOP0605", "E06")
            // リクエストボディ編集
            val requestBean = MBOP0601RequestBean()
            // 人格区分
            requestBean.personType = PreferenceUtil.getPreferenceStringValue(PERSONALITY_FLAG).toString()
            // 受付番号
            requestBean.receiptNumber = KeyStoreUtil().getFromKeyStore(RECEIPT_NUMBER)
            // 口座開設申込情報（法人）
            requestBean.corporationDto = corporation
            // 更新パターン
            requestBean.updateType = UpdateType.UPDATE_TYPE_016.code
            // お客様情報入力
            viewModelScope.launch {
                flow {
                    ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, requestBean.convertToParams().toJson())
                    emit(webService.AB0706())
                }.map {
                    set0706()
                    if (PreferenceUtil.getPreferenceBooleanValue(ConstUtil.OPENED_EDIT_INFO_FLAG)) {
                        PreferenceUtil.setPreferenceBooleanValue(ConstUtil.OPENED_EDIT_INFO_FLAG, false)
                        RouteUtil.navTo(
                            RouteName.MBOP1003Page
                        )
                    } else {
                        PreferenceUtil.setPreferenceBooleanValue(ConstUtil.OPENED_EDIT_INFO_FLAG, false)
                        RouteUtil.navTo(
                            RouteName.MBCO0201Page,
                            MAIL_CONFIRM_TYPE_CORPORATION
                        )
                    }
                }.catch {
                    ErrorUtil().apiErrorCatch(it.message.toString())
                }.collect()
            }
        } else {
            coroutineScope.launch {
                scrollState.animateScrollTo(0)
            }
        }
    }

    fun set0706() {
        // Realm情報更新
        val accountOpeningAB0706 = dbService.findAll(AccountOpeningAB0706::class.java)
        var customerInformation = CorporationBean()
        if (accountOpeningAB0706.isNotEmpty()) {
            customerInformation =
                accountOpeningAB0706[0]?.customerInformation?.fromJson<CorporationBean>()!!
        }
        customerInformation.transactPurpose = viewStates.transactionPurpose
        customerInformation.transactPurposeOther = viewStates.transactionPurposeOther
        customerInformation.transactPurposeDetail = viewStates.transactionPurposeDetail
        customerInformation.businessDescription = viewStates.businessContent
        customerInformation.businessDescriptionOther = viewStates.businessContentOther
        customerInformation.handingItem = viewStates.itemsHandled
        customerInformation.mainlyTradePurchase = viewStates.majorCustomersPurchasing
        customerInformation.mainlyTradeSale = viewStates.majorCustomersSales
        customerInformation.preferredTrade = viewStates.preferredTrade
        customerInformation.otherBusinessWishes = viewStates.preferredTradeOther
        customerInformation.transactionTrigger = viewStates.triggerTransaction
        customerInformation.financialInstitution = viewStates.financialInstitution
        customerInformation.financialInstitutionDepositStatus = viewStates.depositStatus
        customerInformation.financialInstitutionLoanStatus = viewStates.loanStatus
        dbService.deleteAll(AccountOpeningAB0706::class.java)
        val ab0706 = AccountOpeningAB0706()
        ab0706.id = UUID.randomUUID().toString()
        ab0706.customerInformation = customerInformation.toJson()
        dbService.create(ab0706)
    }

    /**
     * 取引目的（事業先）の切替
     */
    fun onTransactionPurposeChange(transactionPurpose: CodeBean) {
        viewStates = viewStates.copy(
            transactionPurpose = transactionPurpose.code,
            transactionPurposeLabel = transactionPurpose.value
        )
        if (transactionPurpose.code != TransactPurpose.OTHERS.code)
            viewStates = viewStates.copy(transactionPurposeOther = "")
    }

    /**
     * 事業内容の切替
     */
    fun onBusinessContentChange(businessContent: CodeBean) {
        viewStates = viewStates.copy(
            businessContent = businessContent.code,
            businessContentLabel = businessContent.value
        )
        if (businessContent.code != BusinessDescription.OTHERS.code)
            viewStates = viewStates.copy(businessContentOther = "")
    }

    /**
     * 当金庫との主な取引希望の切替
     */
    fun onPreferredTradeChange(preferredTrade: CodeBean) {
        viewStates = viewStates.copy(
            preferredTrade = preferredTrade.code,
            preferredTradeLabel = preferredTrade.value
        )
        if (preferredTrade.code != PreferredTrade.OTHERS.code)
            viewStates = viewStates.copy(preferredTradeOther = "")
    }

    /**
     * お取引の理由の切替
     */
    fun onTriggerTransactionChange(triggerTransaction: CodeBean) {
        viewStates = viewStates.copy(
            triggerTransaction = triggerTransaction.code,
            triggerTransactionLabel = triggerTransaction.value
        )
    }

    /**
     * 初期化
     */
    init {
        val accountOpeningAB0706 = dbService.findAll(AccountOpeningAB0706::class.java)
        if (accountOpeningAB0706.isNotEmpty()) {
            val customerInformation = accountOpeningAB0706[0]?.customerInformation?.fromJson<CorporationBean>()!!
            viewStates = viewStates.copy(
                transactionPurpose = customerInformation.transactPurpose,
                transactionPurposeLabel = getTransactPurposeName(customerInformation.transactPurpose),
                transactionPurposeOther = customerInformation.transactPurposeOther,
                transactionPurposeDetail = customerInformation.transactPurposeDetail,
                businessContent = customerInformation.businessDescription,
                businessContentLabel = getBusinessDescriptionName(customerInformation.businessDescription),
                businessContentOther = customerInformation.businessDescriptionOther,
                itemsHandled = customerInformation.handingItem,
                majorCustomersPurchasing = customerInformation.mainlyTradePurchase,
                majorCustomersSales = customerInformation.mainlyTradeSale,
                preferredTrade = customerInformation.preferredTrade,
                preferredTradeLabel = getPreferredTradeName(customerInformation.preferredTrade),
                preferredTradeOther = customerInformation.otherBusinessWishes,
                triggerTransaction = customerInformation.transactionTrigger,
                triggerTransactionLabel = getTransactionTriggerName(customerInformation.transactionTrigger),
                financialInstitution = customerInformation.financialInstitution,
                depositStatus = customerInformation.financialInstitutionDepositStatus,
                loanStatus = customerInformation.financialInstitutionLoanStatus,
            )
        }
        // 復元
        getRestoreData()
    }

    // 復元データを取得する
    private fun getRestoreData() {
        val accountOpeningAB0701 = MyApp.INSTANCE.findAll(EPassBookAB0701::class.java)
        if (accountOpeningAB0701.isNotEmpty() && !MainActivity.HAS_RECOVERY_FLAG) {
            val corporation = accountOpeningAB0701[0]?.corporation?.fromJson<CorporationBean>()!!
            viewStates = viewStates.copy(
                transactionPurpose = corporation.transactPurpose,
                transactionPurposeLabel = getTransactPurposeName(corporation.transactPurpose),
                transactionPurposeOther = corporation.transactPurposeOther,
                transactionPurposeDetail = corporation.transactPurposeDetail,
                businessContent = corporation.businessDescription,
                businessContentLabel = getBusinessDescriptionName(corporation.businessDescription),
                businessContentOther = corporation.businessDescriptionOther,
                itemsHandled = corporation.handingItem,
                majorCustomersPurchasing = corporation.mainlyTradePurchase,
                majorCustomersSales = corporation.mainlyTradeSale,
                preferredTrade = corporation.preferredTrade,
                preferredTradeLabel = getPreferredTradeName(corporation.preferredTrade),
                preferredTradeOther = corporation.otherBusinessWishes,
                triggerTransaction = corporation.transactionTrigger,
                triggerTransactionLabel = getTransactionTriggerName(corporation.transactionTrigger),
                financialInstitution = corporation.financialInstitution,
                depositStatus = corporation.financialInstitutionDepositStatus,
                loanStatus = corporation.financialInstitutionLoanStatus,
            )

            // 復元処理済みフラグ
            MainActivity.HAS_RECOVERY_FLAG = true
            MainActivity.SHOW_RETURN_BUTTON_FLAG = true
        }
    }
}

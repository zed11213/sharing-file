package jp.co.jsbank.mb.bankingapp.logic.opened.mbop.mbop0609

import androidx.compose.foundation.ScrollState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.bean.common.CodeBean
import jp.co.jsbank.mb.bankingapp.bean.common.Individual
import jp.co.jsbank.mb.bankingapp.bean.common.PostCodeRequestBean
import jp.co.jsbank.mb.bankingapp.bean.common.PostCodeResponseBean
import jp.co.jsbank.mb.bankingapp.logic.common.PostInfoSearchLogic
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.repositories.db.common.create
import jp.co.jsbank.mb.bankingapp.repositories.db.common.deleteAll
import jp.co.jsbank.mb.bankingapp.repositories.db.common.findAll
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.AccountOpeningAB0704
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.EPassBookAB0701
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.system.MyApp
import jp.co.jsbank.mb.bankingapp.system.master.Chome
import jp.co.jsbank.mb.bankingapp.system.master.PersonalityFlag
import jp.co.jsbank.mb.bankingapp.system.master.Phone
import jp.co.jsbank.mb.bankingapp.system.master.UpdateType
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0609.MBOP0609ErrorInformation
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0609.MBOP0609PageState
import jp.co.jsbank.mb.bankingapp.utils.*
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.MAIL_CONFIRM_TYPE_INDIVIDUAL
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.SCHOOL_POST_CODE
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isFixedTelePhone
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isHalfAngle
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isHalfNum
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isMobilePhone
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isPersonNameOther
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isPhone
import jp.co.jsbank.mb.bankingapp.utils.HalfToFullUtils.checkBuildRoom
import jp.co.jsbank.mb.bankingapp.utils.HalfToFullUtils.concatBuildRoom
import jp.co.jsbank.mb.bankingapp.utils.HalfToFullUtils.concatBuildRoomDb
import jp.co.jsbank.mb.bankingapp.utils.HalfToFullUtils.splitBuildRoom
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import java.util.*
import javax.inject.Inject

/**
 * MBOP0609ロジック
 */
@HiltViewModel
class MBOP0609Logic @Inject constructor(
    private var webService: RestService
) : ViewModel() {

    /**
     * ログインステータス
     */
    var viewStates by mutableStateOf(MBOP0609PageState())
        private set

    /**
     * 初期化
     */
    init {
        // 修正処理
        val accountOpeningAB0704 = MyApp.INSTANCE.findAll(AccountOpeningAB0704::class.java)
        if (accountOpeningAB0704.isNotEmpty()) {
            val schoolInformation = accountOpeningAB0704[0]?.schoolInformation?.fromJson<Individual>()!!
            // 候補表示フラグの判定：丁目カラムに「丁目」があれば、候補に表示されない
            var candidateFlag = false
            if (schoolInformation.schCity.isNotBlank() &&
                !schoolInformation.schStreet.contains(MyApp.CONTEXT.getString(R.string.common_label_chome))
            ) {
                candidateFlag = true
            }
            // 住所漢字リスト
            val addressList: MutableList<CodeBean> = mutableListOf()
            // 住所漢字丁目なしリスト
            val addressNashiList: MutableList<CodeBean> = mutableListOf()
            // 市区町村プルダウン作成
            addressList.add(
                CodeBean(
                    code = "1",
                    value = schoolInformation.schCity + schoolInformation.schStreet
                )
            )
            addressNashiList.add(
                CodeBean(
                    code = "1",
                    value = schoolInformation.schCity + schoolInformation.schStreet
                )
            )
            val buildRoom = splitBuildRoom(schoolInformation.schBuilding)
            viewStates = viewStates.copy(
                // 学校名
                schoolName = schoolInformation.schName,
                // 学校の郵便番号
                postCode = schoolInformation.schZipCode,
                postCodeOld = schoolInformation.schZipCode,
                // 学校の都道府県
                prefectures = schoolInformation.schPrefectures,
                // 学校の市区町村
                municipalities = schoolInformation.schCity,
                // 丁目
                chome = schoolInformation.schStreet,
                // 丁目
                chomeLabel = Chome.getChomeName(schoolInformation.schStreet),
                // 学校の番地（全角）
                address = schoolInformation.schAddress.trimEnd(),
                // 学校の建物名（全角）
                build = buildRoom.first,
                // 学校の号室（全角）
                room = buildRoom.second,
                // 学校の電話番号タイプ
                phoneType = schoolInformation.schPhoneNumberType,
                // 学校の電話番号タイプ
                phoneTypeLabel = Phone.getPhoneTypeName(schoolInformation.schPhoneNumberType),
                // お勤め先の電話番号
                phoneFirst = schoolInformation.schPhoneNumberFirst,
                // お勤め先の電話番号
                phoneSecond = schoolInformation.schPhoneNumberMid,
                // お勤め先の電話番号
                phoneThird = schoolInformation.schPhoneNumberLast,
                // 店舗名
                shop = schoolInformation.branchNumber,
                // 定期・定積口座番号
                account = schoolInformation.accountType,
                // 口座番号
                accountNumber = schoolInformation.accountNumber,
                // 候補表示フラグ
                candidateFlag = candidateFlag,
                // 市区町村プルダウン
                addressList = addressList,
                addressNashiList = addressNashiList,
                addressShowValue = "1",
                addressShowLabel = schoolInformation.schCity + schoolInformation.schStreet,
                candidateEnabled = false
            )
        } else {
//            val dataBean = MainActivity.NAVCTRL?.currentBackStackEntry?.arguments?.get(ConstUtil.DATA)
//                .toString().fromJson<Individual>()!!
//            viewStates = viewStates.copy(
//                account = dataBean.accountType,
//                shop = dataBean.branchNumber,
//                accountNumber = dataBean.accountNumber
//            )
        }

        // 復元データを取得する
        getRestoreData()
    }

    // 復元データを取得する
    private fun getRestoreData() {
        val accountOpeningAB0701 = MyApp.INSTANCE.findAll(EPassBookAB0701::class.java)
        if (accountOpeningAB0701.isNotEmpty() && !MainActivity.HAS_RECOVERY_FLAG) {
            val individualInfo = accountOpeningAB0701[0]?.individual?.fromJson<Individual>()!!
            // 候補表示フラグの判定：丁目カラムに「丁目」があれば、候補に表示されない
            var candidateFlag = false
            if (individualInfo.schCity.isNotBlank() &&
                !individualInfo.schStreet.contains(MyApp.CONTEXT.getString(R.string.common_label_chome))
            ) {
                candidateFlag = true
            }
            // 住所漢字リスト
            val addressList: MutableList<CodeBean> = mutableListOf()
            // 住所漢字丁目なしリスト
            val addressNashiList: MutableList<CodeBean> = mutableListOf()
            // 市区町村プルダウン作成
            addressList.add(
                CodeBean(
                    code = "1",
                    value = individualInfo.schCity + individualInfo.schStreet
                )
            )
            addressNashiList.add(
                CodeBean(
                    code = "1",
                    value = individualInfo.schCity + individualInfo.schStreet
                )
            )
            val buildRoom = splitBuildRoom(individualInfo.schBuilding)
            viewStates = viewStates.copy(
                // 学校名
                schoolName = individualInfo.schName,
                // 学校の郵便番号
                postCode = individualInfo.schZipCode,
                // 学校の都道府県
                prefectures = individualInfo.schPrefectures,
                // 学校の市区町村
                municipalities = individualInfo.schCity,
                // 丁目
                chome = individualInfo.schStreet,
                // 丁目
                chomeLabel = Chome.getChomeName(individualInfo.schStreet),
                // 学校の番地（全角）
                address = individualInfo.schAddress.trimEnd(),
                // 学校の建物名（全角）
                build = buildRoom.first,
                // 学校の号室（全角）
                room = buildRoom.second,
                // 学校の電話番号
                phoneType = individualInfo.schPhoneNumberType,
                // 学校の電話番号
                phoneTypeLabel = Phone.getPhoneTypeName(individualInfo.schPhoneNumberType),
                // 学校の電話番号1
                phoneFirst = individualInfo.schPhoneNumberFirst,
                // 学校の電話番号2
                phoneSecond = individualInfo.schPhoneNumberMid,
                // 学校の電話番号3
                phoneThird = individualInfo.schPhoneNumberLast,
                // 口座
                account = individualInfo.accountType,
                // 店舗名
                shop = individualInfo.branchNumber,
                // 口座番号
                accountNumber = individualInfo.accountNumber,
                // 候補表示フラグ
                candidateFlag = candidateFlag,
                candidateEnabled = false,
                // 市区町村プルダウン
                addressList = addressList,
                addressNashiList = addressNashiList,
                addressShowValue = "1",
                addressShowLabel = individualInfo.schCity + individualInfo.schStreet,
            )

            // 復元処理済みフラグ
            MainActivity.HAS_RECOVERY_FLAG = true
            MainActivity.SHOW_RETURN_BUTTON_FLAG = true
        }
    }

    /**
     * 電話番号
     */
    fun setPhoneType(value: String, code: String) {
        viewStates = viewStates.copy(phoneTypeLabel = value)
        viewStates = viewStates.copy(phoneType = code)
    }

    /**
     * エラーチェック
     */
    fun doNext(coroutineScope: CoroutineScope, scrollState: ScrollState) {
        // エラー情報初期化
        val errorBean = MBOP0609ErrorInformation()
        viewStates = viewStates.copy(isError = false, errorBean = errorBean, errMsgList = listOf())

        // 学校名が空白場合
        if (viewStates.schoolName.isBlank()) {
            errorBean.schoolNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0609_page_label_school_name)
                    )
                )
            )
        } else if (!viewStates.schoolName.isPersonNameOther()) {
            // 学校名の全角チェック
            errorBean.schoolNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                        MyApp.CONTEXT.getString(R.string.mbop0609_page_label_school_name)
                    )
                )
            )
        }

        // 郵便番号が空白場合
        if (viewStates.postCode.isBlank()) {
            errorBean.postCodeErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0609_page_label_postCode)
                    )
                )
            )
        } else if (!viewStates.postCode.isHalfNum()) {
            // 郵便番号の半角数字チェック
            errorBean.postCodeErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                        MyApp.CONTEXT.getString(R.string.mbop0609_page_label_postCode)
                    )
                )
            )
        } else if (!EditCheckUtil.lengthCheck(viewStates.postCode, 7)) {
            // 郵便番号の桁数チェック
            errorBean.postCodeErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002003V)
                )
            )
        }

        // 学校の市区町村が空白場合
        if (viewStates.municipalities.isBlank()) {
            errorBean.addressShowErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                        MyApp.CONTEXT.getString(R.string.mbop0609_page_label_municipalities)
                    )
                )
            )
        }

        // ご学校の番地（全角）が空白場合
        if (!viewStates.candidateFlag && viewStates.address.isBlank()) {
            errorBean.addressErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0609_page_label_address)
                    )
                )
            )
//        } else if (!viewStates.candidateFlag && !viewStates.address.isPersonNameOther()) {
//        } else if (!viewStates.address.isPersonNameOther()) {
        } else if (!HalfToFullUtils.fullToHalfChar(viewStates.address).isHalfAngle()) {
            // ご学校の番地の全角カナチェック
            errorBean.addressErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002023V),
                        MyApp.CONTEXT.getString(R.string.mbop0609_page_label_address)
                    )
                )
            )
//        } else if (!viewStates.candidateFlag && viewStates.address.startsWith(ConstUtil.FULL_HYPHEN)) {
        } else if (viewStates.address.startsWith(ConstUtil.FULL_HYPHEN)) {
            // お勤め先の番地の全角カナチェック
            errorBean.addressErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002023V),
                        MyApp.CONTEXT.getString(R.string.mbop0609_page_label_address)
                    )
                )
            )
        }
        // ご自宅の建物名/号室が入力された場合、全角
        if (viewStates.build.isNotBlank() && !viewStates.build.isPersonNameOther()) {
            errorBean.buildErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                        MyApp.CONTEXT.getString(R.string.mbop0609_page_label_build)
                    )
                )
            )
        }
        // ご自宅の建物名/号室が入力された場合、全角
        if (viewStates.room.isNotBlank() && !viewStates.room.isPersonNameOther()) {
            errorBean.roomErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                        MyApp.CONTEXT.getString(R.string.mbop0609_page_label_room)
                    )
                )
            )
        }

        if (checkBuildRoom(viewStates.build, viewStates.room)) {
            errorBean.buildErrorFlag = true
            errorBean.roomErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002098V)
                )
            )
        }

        // 学校の電話番号種別が空白場合
        if (viewStates.phoneType.isBlank()) {
            errorBean.phoneTypeErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                        MyApp.CONTEXT.getString(R.string.mbop0609_page_label_phone_type)
                    )
                )
            )
        }

        // 学校の電話番号が空白場合
        if (viewStates.phoneFirst.isBlank()) {
            errorBean.phoneFirstErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0609_page_label_phone)
                    )
                )
            )
        } else if (!viewStates.phoneFirst.isHalfNum()) {
            // 電話番号の半角数字チェック
            errorBean.phoneFirstErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                        MyApp.CONTEXT.getString(R.string.mbop0609_page_label_phone)
                    )
                )
            )
        }

        if (viewStates.phoneSecond.isBlank()) {
            errorBean.phoneSecondErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            if (!viewStates.errMsgList.contains(
                    MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0609_page_label_phone)
                        )
                )
            ) {
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0609_page_label_phone)
                        )
                    )
                )
            }
        } else if (!viewStates.phoneSecond.isHalfNum()) {
            // 電話番号の半角数字チェック
            errorBean.phoneSecondErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            if (!viewStates.errMsgList.contains(
                    MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                            MyApp.CONTEXT.getString(R.string.mbop0609_page_label_phone)
                        )
                )
            ) {
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                            MyApp.CONTEXT.getString(R.string.mbop0609_page_label_phone)
                        )
                    )
                )
            }
        }

        if (viewStates.phoneThird.isBlank()) {
            errorBean.phoneThirdErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            if (!viewStates.errMsgList.contains(
                    MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0609_page_label_phone)
                        )
                )
            ) {
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0609_page_label_phone)
                        )
                    )
                )
            }
        } else if (!viewStates.phoneThird.isHalfNum()) {
            // 電話番号の半角数字チェック
            errorBean.phoneThirdErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            if (!viewStates.errMsgList.contains(
                    MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                            MyApp.CONTEXT.getString(R.string.mbop0609_page_label_phone)
                        )
                )
            ) {
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                            MyApp.CONTEXT.getString(R.string.mbop0609_page_label_phone)
                        )
                    )
                )
            }
        }

        if (viewStates.phoneFirst.isNotBlank() && viewStates.phoneSecond.isNotBlank() &&
            viewStates.phoneThird.isNotBlank()
        ) {
            val frequentlyPhone =
                viewStates.phoneFirst + ConstUtil.HALF_HYPHEN + viewStates.phoneSecond +
                    ConstUtil.HALF_HYPHEN + viewStates.phoneThird
            if (viewStates.phoneType == Phone.FIXED_TELEPHONE.code &&
                !(
                    frequentlyPhone.isFixedTelePhone() && frequentlyPhone.isPhone(
                            Phone.FIXED_TELEPHONE.code,
                            frequentlyPhone
                        )
                    )
            ) {
                errorBean.phoneFirstErrorFlag = true
                errorBean.phoneSecondErrorFlag = true
                errorBean.phoneThirdErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002020V)
                    )
                )
            } else if (viewStates.phoneType == Phone.MOBILE_PHONE.code &&
                !(
                    frequentlyPhone.isMobilePhone() && frequentlyPhone.isPhone(
                            Phone.MOBILE_PHONE.code,
                            frequentlyPhone
                        )
                    )
            ) {
                errorBean.phoneFirstErrorFlag = true
                errorBean.phoneSecondErrorFlag = true
                errorBean.phoneThirdErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002019V)
                    )
                )
            }
        }

        if (!viewStates.isError) {
            enterSchoolInformation()
        } else {
            coroutineScope.launch {
                scrollState.animateScrollTo(0)
            }
        }
    }

    /**
     * 学校情報入力入力
     */
    private fun enterSchoolInformation() {
        // 画面IDとイベントID設定
        PreferenceUtil.setScreenIDAndEventID("MBOP0609", "E06")
        val requestBean = Individual()
        paramSet(requestBean)
        viewModelScope.launch {
            flow {
                ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, requestBean.convertToParams().toJson())
                emit(webService.AB0704())
            }.map {
                // 画面入力した情報をRealmに保存する
                setRealmInfo(requestBean)
                // 郵便番号
                PreferenceUtil.setPreferenceStringValue(SCHOOL_POST_CODE, viewStates.postCode)
                // 遷移のロジック
                if (PreferenceUtil.getPreferenceBooleanValue(ConstUtil.OPENED_EDIT_INFO_FLAG)) {
                    if (viewStates.postCodeOld != viewStates.postCode) {
                        PreferenceUtil.removePreferenceStringValue(ConstUtil.OPENED_HOPE_DEPARTMENT)
                    }
                    PreferenceUtil.setPreferenceBooleanValue(ConstUtil.OPENED_EDIT_INFO_FLAG, false)
                    RouteUtil.navTo(
                        RouteName.MBOP1001Page
                    )
                } else {
                    PreferenceUtil.setPreferenceBooleanValue(ConstUtil.OPENED_EDIT_INFO_FLAG, false)
                    // MBCO0201　メールアドレス入力
                    RouteUtil.navTo(
                        RouteName.MBCO0201Page,
                        MAIL_CONFIRM_TYPE_INDIVIDUAL
                    )
                }
            }.catch {
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }
    }

    /**
     * 画面入力した情報をRealmに保存する
     */
    fun setRealmInfo(requestBean: Individual) {
        MyApp.INSTANCE.deleteAll(AccountOpeningAB0704::class.java)
        val ab0704 = AccountOpeningAB0704()
        ab0704.id = UUID.randomUUID().toString()
        requestBean.schBuilding = concatBuildRoomDb(viewStates.build, viewStates.room)
        ab0704.schoolInformation = requestBean.toJson()
        MyApp.INSTANCE.create(ab0704)
    }

    // 郵便番号の自動検索
    fun postInfoSearch() {
        // エラー情報初期化
        val errorBean = MBOP0609ErrorInformation()
        viewStates = viewStates.copy(isError = false, errorBean = errorBean, errMsgList = listOf())

        // 郵便番号が空白場合
        if (viewStates.postCode.isBlank()) {
            errorBean.postCodeErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0609_page_label_postCode)
                    )
                )
            )
        } else if (!viewStates.postCode.isHalfNum()) {
            // 郵便番号の半角数字チェック
            errorBean.postCodeErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                        MyApp.CONTEXT.getString(R.string.mbop0609_page_label_postCode)
                    )
                )
            )
        } else if (!EditCheckUtil.lengthCheck(viewStates.postCode, 7)) {
            // 郵便番号の桁数チェック
            errorBean.postCodeErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002003V)
                )
            )
        }

        if (errorBean.postCodeErrorFlag) return
        // ・都道府県・市区町村・丁目
        cleanAddress()
        viewModelScope.launch {
            val res: List<PostCodeResponseBean> = PostInfoSearchLogic(webService)
                .getPostInfo(PostCodeRequestBean(viewStates.postCode), "MBOP0609", "E02")

            // 住所漢字リスト
            val addressList: MutableList<CodeBean> = mutableListOf()

            // 住所漢字丁目なしリスト
            val addressNashiList: MutableList<CodeBean> = mutableListOf()
            if (res.isNotEmpty()) {
                res.forEach { item ->
                    if (item.address.isNotBlank()) {
                        addressList.add(CodeBean(item.addressCode, item.address))
                    }
                    if (item.addressNashi.isNotBlank()) {
                        addressNashiList.add(CodeBean(item.addressCode, item.addressNashi))
                    }
                }
                var candidateEnabled = true
                var candidateFlag = false
                var showFirstRecordFlag = false
                // 「丁目あり」が０件だった場合に、「丁目なし」のリストより市区町村項目に自動的に１項目を表示する。
                if (addressList.size == 0) {
                    addressList.addAll(addressNashiList)
                    candidateEnabled = false
                    candidateFlag = true
                    showFirstRecordFlag = true
                }
                // 「丁目なし」が０件だった場合、チェックボックスのチェックができないようにする。
                if(addressNashiList.size == 0)
                {
                    candidateEnabled = false
                }
                // 郵便番号の自動検索により、以下の項目が自動反映されます。
                viewStates = viewStates.copy(
                    postData = res,
                    prefectures = if (res.isNotEmpty()) res[0].prefecture else "",
                    addressList = addressList,
                    addressNashiList = addressNashiList,
                    candidateEnabled = candidateEnabled,
                    candidateFlag = candidateFlag,
                    addressShowValue = if (showFirstRecordFlag && addressList.size > 0) addressList[0].code else "",
                    addressShowLabel = if (showFirstRecordFlag && addressList.size > 0) addressList[0].value else "",
                    municipalities = if (showFirstRecordFlag) res[0].city + res[0].addrDetail1 else "",
                    chome = if (showFirstRecordFlag) if (viewStates.candidateFlag) "" else res[0].addrDetail2 else "",
                )
            }
        }
    }

    fun cleanAddress() {
        viewStates = viewStates.copy(
            postData = listOf(),
            prefectures = "",
            addressShowValue = "",
            addressShowLabel = "",
            addressList = listOf(),
            addressNashiList = listOf(),
            municipalities = "",
            chome = "",
            candidateFlag = false,
            candidateEnabled = false,
        )
    }

    /**
     * アドレスの切替
     */
    fun onAddressShowChange(addressShow: CodeBean) {
        // 市区町村表示
        viewStates = viewStates.copy(addressShowValue = addressShow.code, addressShowLabel = addressShow.value)
        if (viewStates.addressShowValue.isNotBlank()) {
            // 郵便情報
            if (viewStates.postData.isNotEmpty()) {
                val thisPost = viewStates.postData.first { it.addressCode == addressShow.code }
                viewStates = viewStates.copy(
                    municipalities = thisPost.city + thisPost.addrDetail1,
                    chome = if (viewStates.candidateFlag) "" else thisPost.addrDetail2,
                )
            }
        } else {
            viewStates = viewStates.copy(municipalities = "", chome = "")
        }
    }

    /**
     * 候補を表示するフラグ切替
     */
    fun onCandidateFlagChange() {
        viewStates = viewStates.copy(
            candidateFlag = !viewStates.candidateFlag,
            addressShowValue = "",
            addressShowLabel = "",
            municipalities = "",
            chome = "",
        )
    }

    // パラメータセット
    fun paramSet(bean: Individual) {
        // 学校名
        bean.schName = viewStates.schoolName
        // 学校の郵便番号
        bean.schZipCode = viewStates.postCode
        // 学校の都道府県
        bean.schPrefectures = viewStates.prefectures
        // 学校の市区町村
        bean.schCity = viewStates.municipalities
        // 丁目
        bean.schStreet = viewStates.chome
        // 学校の建物名/号室（全角）
        bean.schBuilding = concatBuildRoom(viewStates.build, viewStates.room)
        // 学校の番地（全角）
        bean.schAddress = viewStates.address
        // 学校の電話番号タイプ
        bean.schPhoneNumberType = viewStates.phoneType
        // お勤め先の電話番号
        bean.schPhoneNumberFirst = viewStates.phoneFirst
        // お勤め先の電話番号
        bean.schPhoneNumberMid = viewStates.phoneSecond
        // お勤め先の電話番号
        bean.schPhoneNumberLast = viewStates.phoneThird
        // 店舗名
        bean.branchNumber = viewStates.shop
        // 定期・定積口座番号
        bean.accountType = viewStates.account
        // 口座番号
        bean.accountNumber = viewStates.accountNumber
        // 人格区分
        bean.personType = PersonalityFlag.INDIVIDUAL_OTHER.code
        // 受付番号
        bean.receiptNumber = KeyStoreUtil().getFromKeyStore(ConstUtil.RECEIPT_NUMBER)
        // 更新パターン
        bean.updateType = UpdateType.UPDATE_TYPE_008.code
    }
}

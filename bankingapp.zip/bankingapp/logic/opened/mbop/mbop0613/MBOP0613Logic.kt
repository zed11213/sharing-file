package jp.co.jsbank.mb.bankingapp.logic.opened.mbop.mbop0613

import androidx.compose.foundation.ScrollState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.bean.common.CodeBean
import jp.co.jsbank.mb.bankingapp.bean.common.PostCodeRequestBean
import jp.co.jsbank.mb.bankingapp.bean.common.PostCodeResponseBean
import jp.co.jsbank.mb.bankingapp.bean.common.SoleProprietorBean
import jp.co.jsbank.mb.bankingapp.bean.opened.mbop.mbop0613.MBOP0613RequestBean
import jp.co.jsbank.mb.bankingapp.logic.common.PostInfoSearchLogic
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.repositories.db.common.create
import jp.co.jsbank.mb.bankingapp.repositories.db.common.deleteAll
import jp.co.jsbank.mb.bankingapp.repositories.db.common.findAll
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.AccountOpeningAB0719
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.EPassBookAB0701
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.system.MyApp
import jp.co.jsbank.mb.bankingapp.system.master.Chome
import jp.co.jsbank.mb.bankingapp.system.master.ChomeHalf
import jp.co.jsbank.mb.bankingapp.system.master.UpdateType
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0613.MBOP0613ErrorInformation
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0613.MBOP0613PageState
import jp.co.jsbank.mb.bankingapp.utils.*
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.HALF_HYPHEN
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isHalfAngle
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isHalfNum
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isPersonNameKanaOther
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isPersonNameOther
import jp.co.jsbank.mb.bankingapp.utils.HalfToFullUtils.checkBuildRoom
import jp.co.jsbank.mb.bankingapp.utils.HalfToFullUtils.checkBuildRoomKana
import jp.co.jsbank.mb.bankingapp.utils.HalfToFullUtils.concatBuildRoom
import jp.co.jsbank.mb.bankingapp.utils.HalfToFullUtils.concatBuildRoomDb
import jp.co.jsbank.mb.bankingapp.utils.HalfToFullUtils.concatBuildRoomKana
import jp.co.jsbank.mb.bankingapp.utils.HalfToFullUtils.concatBuildRoomKanaDb
import jp.co.jsbank.mb.bankingapp.utils.HalfToFullUtils.fullToHalfChar
import jp.co.jsbank.mb.bankingapp.utils.HalfToFullUtils.splitBuildRoom
import jp.co.jsbank.mb.bankingapp.utils.HalfToFullUtils.splitBuildRoomKana
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import java.util.*
import javax.inject.Inject

/**
 * MBOP0613ロジック
 */
@HiltViewModel
class MBOP0613Logic @Inject constructor(
    private var webService: RestService
) : ViewModel() {

    /**
     * MBOP0613ステータス
     */
    var viewStates by mutableStateOf(MBOP0613PageState())
        private set

    /**
     * 初期化
     */
    init {
        // 修正の処理
        val accountOpeningAB0719 = MyApp.INSTANCE.findAll(AccountOpeningAB0719::class.java)
        if (accountOpeningAB0719.isNotEmpty()) {
            val locationInformation = accountOpeningAB0719[0]?.locationInformation?.fromJson<MBOP0613RequestBean>()!!
            // 候補表示フラグの判定：丁目カラムに「丁目」があれば、候補に表示されない
            var candidateFlag = false
            if (locationInformation.locationCity.isNotBlank() &&
                !locationInformation.locationStreet.contains(MyApp.CONTEXT.getString(R.string.common_label_chome))
            ) {
                candidateFlag = true
            }
            // 住所漢字リスト
            val addressList: MutableList<CodeBean> = mutableListOf()
            // 住所漢字丁目なしリスト
            val addressNashiList: MutableList<CodeBean> = mutableListOf()
            // 市区町村プルダウン作成
            addressList.add(
                CodeBean(
                    code = "1",
                    value = locationInformation.locationCity + locationInformation.locationStreet
                )
            )
            addressNashiList.add(
                CodeBean(
                    code = "1",
                    value = locationInformation.locationCity + locationInformation.locationStreet
                )
            )
            // 住所カナリスト
            val addressKanaList: MutableList<CodeBean> = mutableListOf()
            // 住所カナ丁目なしリスト
            val addressKanaNashiList: MutableList<CodeBean> = mutableListOf()
            // 市区町村カナプルダウン作成
            addressKanaList.add(
                CodeBean(
                    code = "1",
                    value = locationInformation.locationCityKana + locationInformation.locationStreetKana
                )
            )
            addressKanaNashiList.add(
                CodeBean(
                    code = "1",
                    value = locationInformation.locationCityKana + locationInformation.locationStreetKana
                )
            )

            val room = splitBuildRoom(locationInformation.locationBuildingRoom)
            val roomKana = splitBuildRoomKana(locationInformation.locationBuildingRoomKana)


            viewStates = viewStates.copy(
                // ご自宅の郵便番号
                postCode = locationInformation.locationZipCode,
                postCodeOld = locationInformation.locationZipCode,
                // ご自宅の都道府県
                prefectures = locationInformation.locationPrefecture,
                // ご自宅の市区町村
                city = locationInformation.locationCity,
                // 丁目
                chome = locationInformation.locationStreet,
                // 丁目
                chomeLabel = Chome.getChomeName(locationInformation.locationStreet),
                // ご自宅の番地（全角）
                address = locationInformation.locationAddress.trimEnd(),
                // ご自宅の建物名（全角）
                build = room.first,
                // ご自宅の号室（全角）
                room = room.second,
                // ご自宅の都道府県（半角カナ）
                prefecturesKana = locationInformation.locationPrefectureKana,
                // ご自宅の市区町村（半角カナ）
                cityKana = locationInformation.locationCityKana,
                // 丁目（半角カナ）
                chomeHalfwidth = locationInformation.locationStreetKana,
                // 丁目（半角カナ）
                chomeHalfwidthLabel = ChomeHalf.getChomeHalfName(locationInformation.locationStreetKana),
                // ご自宅の番地（半角）
                addressHalf = locationInformation.locationAddressKana.trimEnd(),
                // ご自宅の建物名（半角カナ）
                buildKana = roomKana.first,
                // ご自宅の号室（半角カナ）
                roomKana = roomKana.second,
                // 候補表示フラグ
                candidateFlag = candidateFlag,
                // 市区町村プルダウン
                addressList = addressList,
                addressNashiList = addressNashiList,
                addressShowValue = "1",
                addressShowLabel = locationInformation.locationCity + locationInformation.locationStreet,
                // 市区町村カナプルダウン
                addressKanaList = addressKanaList,
                addressKanaNashiList = addressKanaNashiList,
                addressKanaShowValue = "1",
                addressKanaShowLabel = locationInformation.locationCityKana + locationInformation.locationStreetKana,
                candidateEnabled = false
            )
        }

        // 復元データを取得する
        getRestoreData()
    }

    /**
     * 復元データを取得する
     */
    private fun getRestoreData() {
        val accountOpeningAB0701 = MyApp.INSTANCE.findAll(EPassBookAB0701::class.java)
        if (accountOpeningAB0701.isNotEmpty() && !MainActivity.HAS_RECOVERY_FLAG) {
            val soleProprietorInfo = accountOpeningAB0701[0]?.soleProprietor?.fromJson<SoleProprietorBean>()!!

            val room = splitBuildRoom(soleProprietorInfo.buildingRoom)
            val roomKana = splitBuildRoomKana(soleProprietorInfo.buildingRoomKana)

            viewStates = viewStates.copy(
                // ご自宅の郵便番号
                postCode = soleProprietorInfo.locationZipCode,
                // ご自宅の都道府県
                prefectures = soleProprietorInfo.locationPrefecture,
                // ご自宅の市区町村
                city = soleProprietorInfo.locationCity,
                // 丁目
                chome = soleProprietorInfo.locationStreet,
                // 丁目
                chomeLabel = Chome.getChomeName(soleProprietorInfo.locationStreet),
                // ご自宅の番地（全角）
                address = soleProprietorInfo.locationAddress.trimEnd(),
                // ご自宅の建物名（全角）
                build = room.first,
                // ご自宅の号室（全角）
                room = room.second,
                // ご自宅の都道府県（半角カナ）
                prefecturesKana = soleProprietorInfo.locationPrefectureKana,
                // ご自宅の市区町村（半角カナ）
                cityKana = soleProprietorInfo.locationCityKana,
                // 丁目（半角カナ）
                chomeHalfwidth = soleProprietorInfo.locationStreetKana.replace(HALF_HYPHEN, ""),
                // 丁目（半角カナ）
                chomeHalfwidthLabel = ChomeHalf.getChomeHalfName(soleProprietorInfo.locationStreetKana),
                // ご自宅の番地（半角）
                addressHalf = soleProprietorInfo.locationAddressKana.trimEnd(),
                // ご自宅の建物名（半角カナ）
                buildKana = roomKana.first,
                // ご自宅の号室（半角カナ）
                roomKana = roomKana.second,
                candidateEnabled = false
            )

            // 復元処理済みフラグ
            MainActivity.HAS_RECOVERY_FLAG = true
            MainActivity.SHOW_RETURN_BUTTON_FLAG = true
        }
    }

    /**
     * エラーチェック
     */
    fun doNext(coroutineScope: CoroutineScope, scrollState: ScrollState) {
        // エラー情報初期化
        val errorBean = MBOP0613ErrorInformation()
        viewStates = viewStates.copy(isError = false)
        viewStates = viewStates.copy(errorBean = errorBean)
        viewStates = viewStates.copy(errorMessageList = listOf())

        // 郵便番号が空白場合
        if (viewStates.postCode.isBlank()) {
            errorBean.postCodeErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0613_page_label_postCode)
                    )
                )
            )
        } else if (!viewStates.postCode.isHalfNum()) {
            // 郵便番号の半角数字チェック
            errorBean.postCodeErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                        MyApp.CONTEXT.getString(R.string.mbop0613_page_label_postCode)
                    )
                )
            )
        } else if (!EditCheckUtil.lengthCheck(viewStates.postCode, 7)) {
            // 郵便番号の桁数チェック
            errorBean.postCodeErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002003V)
                )
            )
        }

        // ご自宅の市区町村
        if (viewStates.city.isBlank()) {
            errorBean.addressShowErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                        MyApp.CONTEXT.getString(R.string.mbop0613_page_label_city)
                    )
                )
            )
        }

        // ご自宅の番地（全角）
        if (!viewStates.candidateFlag && viewStates.address.isBlank()) {
            errorBean.addressErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0613_page_label_address)
                    )
                )
            )
//        } else if (!viewStates.candidateFlag && !fullToHalfChar(viewStates.address).isHalfAngle()) {
        } else if (!fullToHalfChar(viewStates.address).isHalfAngle()) {
            // ご自宅の番地の全角カナチェック
            errorBean.addressErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002023V),
                        MyApp.CONTEXT.getString(R.string.mbop0613_page_label_address)
                    )
                )
            )
//        } else if (!viewStates.candidateFlag && viewStates.address.startsWith(ConstUtil.FULL_HYPHEN)) {
        } else if (viewStates.address.startsWith(ConstUtil.FULL_HYPHEN)) {
            // ご自宅の番地の全角カナチェック
            errorBean.addressErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002023V),
                        MyApp.CONTEXT.getString(R.string.mbop0613_page_label_address)
                    )
                )
            )
        }

        // ご自宅の市区町村（半角カナ）
        if (viewStates.cityKana.isBlank()) {
            errorBean.addressKanaShowErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                        MyApp.CONTEXT.getString(R.string.mbop0613_page_label_city_kana)
                    )
                )
            )
        }

        // ご自宅の番地（半角）
        if (!viewStates.candidateFlag && viewStates.addressHalf.isBlank()) {
            errorBean.addressHalfErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0613_page_label_address_half)
                    )
                )
            )
//        } else if (!viewStates.candidateFlag && !viewStates.addressHalf.isHalfAngle()) {
        } else if (!viewStates.addressHalf.isHalfAngle()) {
            errorBean.addressHalfErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002023V),
                        MyApp.CONTEXT.getString(R.string.mbop0613_page_label_address_half)
                    )
                )
            )
//        } else if (!viewStates.candidateFlag && viewStates.addressHalf.startsWith(HYPHEN)) {
        } else if (viewStates.addressHalf.startsWith(HALF_HYPHEN)) {
            errorBean.addressHalfErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002023V),
                        MyApp.CONTEXT.getString(R.string.mbop0613_page_label_address_half)
                    )
                )
            )
        }

        // ご自宅の番地（全角）が入力された場合、ご自宅の番地（半角）も入力必要です
        if (viewStates.addressHalf.isBlank() && viewStates.address.isNotBlank()) {
            errorBean.addressHalfErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0613_page_label_address_half)
                    )
                )
            )
        }

        // ご自宅の番地（半角）が入力された場合、ご自宅の番地（全角）も入力必要です
        if (viewStates.address.isBlank() && viewStates.addressHalf.isNotBlank()) {
            errorBean.addressErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0613_page_label_address)
                    )
                )
            )
        }


        // 建物名カナが入力された場合、建物名も入力必要です
        if (viewStates.build.isBlank() && viewStates.buildKana.isNotBlank()) {
            errorBean.buildErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0613_page_label_build)
                    )
                )
            )
        }

        // ご自宅の建物名/号室が入力された場合、ご自宅の建物名/号室カナも入力必要です
        if (viewStates.build.isNotBlank() && viewStates.buildKana.isBlank()) {
            errorBean.buildKanaErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0613_page_label_kana_build)
                    )
                )
            )
        }

        // ご自宅の建物名/号室が入力された場合、全角
        if (viewStates.build.isNotBlank() && !viewStates.build.isPersonNameOther()) {
            errorBean.buildErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                        MyApp.CONTEXT.getString(R.string.mbop0613_page_label_build)
                    )
                )
            )
        }

        // ご自宅の建物名/号室（半角カナ）が入力された場合、全角
        if (viewStates.buildKana.isNotBlank() && !viewStates.buildKana.isPersonNameKanaOther()) {
            errorBean.buildKanaErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002032V),
                        MyApp.CONTEXT.getString(R.string.mbop0613_page_label_kana_build)
                    )
                )
            )
        }

        //=====================room

        // 建物名/号室カナが入力された場合、建物名/号室も入力必要です
        if (viewStates.room.isBlank() && viewStates.roomKana.isNotBlank()) {
            errorBean.roomErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0613_page_label_room)
                    )
                )
            )
        }

        // ご自宅の建物名/号室が入力された場合、ご自宅の建物名/号室カナも入力必要です
        if (viewStates.room.isNotBlank() && viewStates.roomKana.isBlank()) {
            errorBean.roomKanaErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0613_page_label_kana_room)
                    )
                )
            )
        }

        // ご自宅の建物名/号室が入力された場合、全角
        if (viewStates.room.isNotBlank() && !viewStates.room.isPersonNameOther()) {
            errorBean.roomErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                        MyApp.CONTEXT.getString(R.string.mbop0613_page_label_room)
                    )
                )
            )
        }

        // ご自宅の建物名/号室（半角カナ）が入力された場合、全角
        if (viewStates.roomKana.isNotBlank() && !viewStates.roomKana.isPersonNameKanaOther()) {
            errorBean.roomKanaErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002032V),
                        MyApp.CONTEXT.getString(R.string.mbop0613_page_label_kana_room)
                    )
                )
            )
        }

        if (checkBuildRoom(viewStates.build, viewStates.room)) {
            errorBean.buildErrorFlag = true
            errorBean.roomErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002098V)
                )
            )
        }

        if (checkBuildRoomKana(viewStates.buildKana, viewStates.roomKana))   {
            errorBean.buildKanaErrorFlag = true
            errorBean.roomKanaErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002099V)
                )
            )
        }

        if (!viewStates.isError) {
            // 画面IDとイベントID設定
            PreferenceUtil.setScreenIDAndEventID("MBOP0613", "E03")
            // リクエストボディ編集
            val requestBean = MBOP0613RequestBean()
            requestBean.receiptNumber = KeyStoreUtil().getFromKeyStore(ConstUtil.RECEIPT_NUMBER)
            requestBean.locationZipCode = viewStates.postCode
            requestBean.locationPrefecture = viewStates.prefectures
            requestBean.locationCity = viewStates.city
            requestBean.locationStreet = viewStates.chome
            requestBean.locationBuildingRoom = concatBuildRoom(viewStates.build, viewStates.room)
            requestBean.locationAddress = viewStates.address
            requestBean.locationPrefectureKana = viewStates.prefecturesKana
            requestBean.locationCityKana = viewStates.cityKana
            requestBean.locationStreetKana = if (viewStates.chomeHalfwidth.isNotBlank()) {
                if (viewStates.chomeHalfwidth.last().isDigit()) {
                    viewStates.chomeHalfwidth + HALF_HYPHEN
                } else {
                    viewStates.chomeHalfwidth
                }
            } else ""
            requestBean.locationBuildingRoomKana = concatBuildRoomKana(viewStates.buildKana, viewStates.roomKana)
            requestBean.locationAddressKana = viewStates.addressHalf
            requestBean.updateType = UpdateType.UPDATE_TYPE_021.code
            // biz所在地情報保存
            viewModelScope.launch {
                flow {
                    ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, requestBean.convertToParams())
                    emit(webService.AB0719())
                }.map {
                    PreferenceUtil.setPreferenceStringValue(ConstUtil.LOCAL_POST_CODE, viewStates.postCode)

                    set0719()
                    // 遷移のロジック
                    if (PreferenceUtil.getPreferenceBooleanValue(ConstUtil.OPENED_EDIT_INFO_FLAG)) {
                        PreferenceUtil.setPreferenceBooleanValue(ConstUtil.EDIT_FLAG, true)
                    }
                    RouteUtil.navTo(
                        RouteName.MBOP0701Page
                    )
                }.catch {
                    ErrorUtil().apiErrorCatch(it.message.toString())
                }.collect()
            }
        } else {
            coroutineScope.launch {
                scrollState.animateScrollTo(0)
            }
        }
    }

    /**
     * 番地カナ更新
     */
    fun updateAddressKana(address: String) {
        viewStates = viewStates.copy(addressHalf = fullToHalfChar(address))
    }

    /**
     * 号室カナ更新
     */
    fun updateRoomKana(room: String) {
        viewStates = viewStates.copy(roomKana = fullToHalfChar(room))
    }

    fun set0719() {
        // Realm情報更新
        MyApp.INSTANCE.deleteAll(AccountOpeningAB0719::class.java)
        val locationInformation = MBOP0613RequestBean()
        locationInformation.locationZipCode = viewStates.postCode
        locationInformation.locationPrefecture = viewStates.prefectures
        locationInformation.locationCity = viewStates.city
        locationInformation.locationStreet = viewStates.chome
        locationInformation.locationAddress = viewStates.address
        locationInformation.locationBuildingRoom = concatBuildRoomDb(viewStates.build, viewStates.room)
        locationInformation.locationPrefectureKana = viewStates.prefecturesKana
        locationInformation.locationCityKana = viewStates.cityKana
        locationInformation.locationStreetKana = viewStates.chomeHalfwidth
        locationInformation.locationAddressKana = viewStates.addressHalf
        locationInformation.locationBuildingRoomKana = concatBuildRoomKanaDb(viewStates.buildKana, viewStates.roomKana)
        val ab0719 = AccountOpeningAB0719()
        ab0719.id = UUID.randomUUID().toString()
        ab0719.locationInformation = locationInformation.toJson()
        MyApp.INSTANCE.create(ab0719)
    }

    /**
     * 郵便番号の自動検索
     */
    fun postInfoSearch() {
        // エラー情報初期化
        val errorBean = MBOP0613ErrorInformation()
        viewStates = viewStates.copy(isError = false)
        viewStates = viewStates.copy(errorBean = errorBean)
        viewStates = viewStates.copy(errorMessageList = listOf())
        // 所在地の郵便番号
        if (viewStates.postCode.isBlank() ||
            !EditCheckUtil.lengthCheck(viewStates.postCode, 7)
        ) {
            errorBean.postCodeErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002003V)
                )
            )
            return
        }
        // ・都道府県・市区町村・丁目・都道府県（半角カナ）・市区町村（半角カナ）・丁目（半角）クリア
        cleanAddress()
        viewModelScope.launch {
            val res: List<PostCodeResponseBean> = PostInfoSearchLogic(webService)
                .getPostInfo(PostCodeRequestBean(viewStates.postCode), "MBOP0610", "E02")

            // 住所漢字リスト
            val addressList: MutableList<CodeBean> = mutableListOf()

            // 住所漢字丁目なしリスト
            val addressNashiList: MutableList<CodeBean> = mutableListOf()

            // 住所カナリスト
            val addressKanaList: MutableList<CodeBean> = mutableListOf()

            // 住所カナ丁目なしリスト
            val addressKanaNashiList: MutableList<CodeBean> = mutableListOf()
            if (res.isNotEmpty()) {
                res.forEach { item ->
                    if (item.address.isNotBlank()) {
                        addressList.add(CodeBean(item.addressCode, item.address))
                        addressKanaList.add(CodeBean(item.addressCode, item.addressKana))
                    }
                    if (item.addressNashi.isNotBlank()) {
                        addressNashiList.add(CodeBean(item.addressCode, item.addressNashi))
                        addressKanaNashiList.add(CodeBean(item.addressCode, item.addressKanaNashi))
                    }
                }
                var candidateEnabled = true
                var candidateFlag = false
                var showFirstRecordFlag = false
                // 「丁目あり」が０件だった場合に、「丁目なし」のリストより市区町村項目に自動的に１項目を表示する。
                if (addressList.size == 0 || addressKanaList.size == 0) {
                    addressList.addAll(addressNashiList)
                    addressKanaList.addAll(addressKanaNashiList)
                    candidateEnabled = false
                    candidateFlag = true
                    showFirstRecordFlag = true
                }
                // 「丁目なし」が０件だった場合、チェックボックスのチェックができないようにする。
                if(addressNashiList.size == 0)
                {
                    candidateEnabled = false
                }
                // 郵便番号の自動検索により、以下の項目が自動反映されます。
                viewStates = viewStates.copy(
                    postData = res,
                    prefectures = if (res.isNotEmpty()) res[0].prefecture else "",
                    addressList = addressList,
                    addressNashiList = addressNashiList,
                    prefecturesKana = if (res.isNotEmpty()) res[0].prefectureKana else "",
                    addressKanaList = addressKanaList,
                    addressKanaNashiList = addressKanaNashiList,
                    candidateEnabled = candidateEnabled,
                    candidateFlag = candidateFlag,
                    addressShowValue = if (showFirstRecordFlag && addressList.size > 0) addressList[0].code else "",
                    addressShowLabel = if (showFirstRecordFlag && addressList.size > 0) addressList[0].value else "",
                    addressKanaShowValue = if (showFirstRecordFlag && addressKanaList.size > 0) addressKanaList[0].code else "",
                    addressKanaShowLabel = if (showFirstRecordFlag && addressKanaList.size > 0) addressKanaList[0].value else "",
                    city = if (showFirstRecordFlag) res[0].city + res[0].addrDetail1 else "",
                    cityKana = if (showFirstRecordFlag) res[0].cityKana + res[0].addrdetail1Kana else "",
                    chome = if (showFirstRecordFlag) if (viewStates.candidateFlag) "" else res[0].addrDetail2 else "",
                    chomeHalfwidth = if (showFirstRecordFlag) if (viewStates.candidateFlag) "" else when {
                        // 丁目カラムに「ﾁｮｳﾒ」があれば、「-」に変換する
                        res[0].addrdetail2Kana.contains(
                            MyApp.CONTEXT.getString(R.string.common_label_chome_kana)
                        ) -> {
                            res[0].addrdetail2Kana.replace(
                                MyApp.CONTEXT.getString(R.string.common_label_chome_kana),
                                ""
                            )
                        }
                        else -> {
                            res[0].addrdetail2Kana
                        }
                    } else ""
                )
            }
        }
    }

    fun cleanAddress() {
        viewStates = viewStates.copy(
            postData = listOf(),
            prefectures = "",
            addressShowValue = "",
            addressShowLabel = "",
            addressList = listOf(),
            addressNashiList = listOf(),
            prefecturesKana = "",
            addressKanaShowValue = "",
            addressKanaShowLabel = "",
            addressKanaList = listOf(),
            addressKanaNashiList = listOf(),
            city = "",
            cityKana = "",
            chome = "",
            chomeHalfwidth = "",
            candidateFlag = false,
            candidateEnabled = false,
        )
    }

    /**
     * アドレスの切替
     */
    fun onAddressShowChange(addressShow: CodeBean) {
        // 市区町村表示
        viewStates = viewStates.copy(addressShowValue = addressShow.code, addressShowLabel = addressShow.value)
        if (viewStates.addressShowValue.isNotBlank()) {
            // 市区町村カナ表示
            val addressKanaList = if (viewStates.candidateFlag)
                viewStates.addressKanaNashiList else viewStates.addressKanaList
            val thisAddressKanaShow = addressKanaList.first { it.code == addressShow.code }
            viewStates = viewStates.copy(
                addressKanaShowValue = thisAddressKanaShow.code,
                addressKanaShowLabel = thisAddressKanaShow.value
            )
            // 郵便情報
            if (viewStates.postData.isNotEmpty()) {
                val thisPost = viewStates.postData.first { it.addressCode == addressShow.code }
                viewStates = viewStates.copy(
                    city = thisPost.city + thisPost.addrDetail1,
                    chome = if (viewStates.candidateFlag) "" else thisPost.addrDetail2,
                    cityKana = thisPost.cityKana + thisPost.addrdetail1Kana,
                    chomeHalfwidth = if (viewStates.candidateFlag) "" else when {
                        // 丁目カラムに「ﾁｮｳﾒ」があれば、「-」に変換する
                        thisPost.addrdetail2Kana.contains(
                            MyApp.CONTEXT.getString(R.string.common_label_chome_kana)
                        ) -> {
                            thisPost.addrdetail2Kana.replace(
                                MyApp.CONTEXT.getString(R.string.common_label_chome_kana),
                                ""
                            )
                        }
                        else -> {
                            thisPost.addrdetail2Kana
                        }
                    }
                )
            }
        } else {
            viewStates = viewStates.copy(
                addressKanaShowValue = "",
                addressKanaShowLabel = "",
                city = "",
                chome = "",
                cityKana = "",
                chomeHalfwidth = ""
            )
        }
    }

    /**
     * 候補を表示するフラグ切替
     */
    fun onCandidateFlagChange() {
        viewStates = viewStates.copy(
            candidateFlag = !viewStates.candidateFlag,
            addressShowValue = "",
            addressShowLabel = "",
            addressKanaShowValue = "",
            addressKanaShowLabel = "",
            city = "",
            chome = "",
            cityKana = "",
            chomeHalfwidth = ""
        )
    }

    /**
     * アドレスカナの切替
     */
    fun onAddressKanaShowChange(addressKanaShow: CodeBean) {
        // 市区町村カナ表示
        viewStates =
            viewStates.copy(addressKanaShowValue = addressKanaShow.code, addressKanaShowLabel = addressKanaShow.value)
        if (viewStates.addressKanaShowValue.isNotBlank()) {
            // 市区町村表示
            val addressList = if (viewStates.candidateFlag)
                viewStates.addressNashiList else viewStates.addressList
            val thisAddressShow = addressList.first { it.code == addressKanaShow.code }
            viewStates = viewStates.copy(
                addressShowValue = thisAddressShow.code,
                addressShowLabel = thisAddressShow.value
            )
            // 郵便情報
            if (viewStates.postData.isNotEmpty()) {
                val thisPost = viewStates.postData.first { it.addressCode == addressKanaShow.code }
                viewStates = viewStates.copy(
                    city = thisPost.city + thisPost.addrDetail1,
                    chome = if (viewStates.candidateFlag) "" else thisPost.addrDetail2,
                    cityKana = thisPost.cityKana + thisPost.addrdetail1Kana,
                    chomeHalfwidth = if (viewStates.candidateFlag) "" else when {
                        // 丁目カラムに「ﾁｮｳﾒ」があれば、「-」に変換する
                        thisPost.addrdetail2Kana.contains(
                            MyApp.CONTEXT.getString(R.string.common_label_chome_kana)
                        ) -> {
                            thisPost.addrdetail2Kana.replace(
                                MyApp.CONTEXT.getString(R.string.common_label_chome_kana),
                                ""
                            )
                        }
                        else -> {
                            thisPost.addrdetail2Kana
                        }
                    }
                )
            }
        } else {
            viewStates = viewStates.copy(
                addressShowValue = "",
                addressShowLabel = "",
                city = "",
                chome = "",
                cityKana = "",
                chomeHalfwidth = ""
            )
        }
    }
}

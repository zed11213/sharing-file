package jp.co.jsbank.mb.bankingapp.logic.opened.mbop.mbop0702

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import jp.co.jsbank.mb.bankingapp.bean.opened.mbop.mbop0701.DepartmentStore
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.system.master.CandidateFlag
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0702.MBOP0702PageState
import jp.co.jsbank.mb.bankingapp.utils.*
import javax.inject.Inject

/**
 * MBOP0702ロジック
 */
@HiltViewModel
class MBOP0702Logic @Inject constructor() : ViewModel() {

    /**
     * ステータス
     */
    var viewStates by mutableStateOf(MBOP0702PageState())
        private set

    /**
     * 経緯度取得
     */
    fun getLongitudeAndLatitude(bean: DepartmentStore) {
        PreferenceUtil.removePreferenceStringValue(ConstUtil.REASON)
        PreferenceUtil.removePreferenceStringValue(ConstUtil.REASON_OTHER)
        RouteUtil.navTo(RouteName.MBOP0703Page + "/${bean.toJson()}/" + CandidateFlag.HAS_CANDIDATE.code)
    }

    /**
     * 初期化
     */
    init {
        // 遷移元画面渡すパラメータ取得
        val departmentStoreList: List<Map<String, String>>
        val arguments = MainActivity.NAVCTRL?.currentBackStackEntry?.arguments?.get(ConstUtil.DATA_LIST)
        if (arguments != null) {
            departmentStoreList = arguments.toString().fromJson<List<Map<String, String>>>()!!
            if (departmentStoreList.isNotEmpty()) {
                viewStates.departmentStoreList = mutableListOf()
                departmentStoreList.forEach {
                    if (viewStates.departmentStoreList.none { dep -> dep.branchNumber == (it["branchNumber"] ?: "") }) {
                        viewStates.departmentStoreList.add(
                            DepartmentStore(
                                addressCode = it["addressCode"] ?: "",
                                branchNumber = it["branchNumber"] ?: "",
                                areaCode = it["areaCode"] ?: "",
                                prefecture = it["prefecture"] ?: "",
                                city = it["city"] ?: "",
                                addrDetail1 = it["addrDetail1"] ?: "",
                                addrDetail2 = it["addrDetail2"] ?: "",
                                areaZipCode = it["areaZipCode"] ?: "",
                                bankCode = it["bankCode"] ?: "",
                                branchKanjiName = it["branchKanjiName"] ?: "",
                                divisionType = it["divisionType"] ?: "",
                                branchInquiryType = it["branchInquiryType"] ?: "",
                                branchZipCode = it["branchZipCode"] ?: "",
                                branchKanjiAddress = it["branchKanjiAddress"] ?: "",
                                phoneNumber = it["phoneNumber"] ?: "",
                                latitude = it["latitude"] ?: "",
                                longitude = it["longitude"] ?: "",
                                displayGroupName = it["displayGroupName"] ?: "",
                                displayOrder = it["displayOrder"] ?: "",
                            )
                        )
                    }
                }
            }
        }
    }

    fun goToOtherShop() {
        RouteUtil.navTo(
            RouteName.MBOP0706Page
        )
    }
}

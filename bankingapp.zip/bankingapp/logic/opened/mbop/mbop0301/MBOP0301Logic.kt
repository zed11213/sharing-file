package jp.co.jsbank.mb.bankingapp.logic.opened.mbop.mbop0301

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0301.MBOP0301PageState

/**
 * MBOP0301ロジック
 */
@HiltViewModel
class MBOP0301Logic @Inject constructor() : ViewModel() {

    // ステータス
    var viewStates by mutableStateOf(MBOP0301PageState())
        private set

    fun showDetail(index: Int, flag: Boolean) {
        viewStates = when (index) {
            0 -> viewStates.copy(showFlag1 = !flag)
            1 -> viewStates.copy(showFlag2 = !flag)
            2 -> viewStates.copy(showFlag3 = !flag)
            3 -> viewStates.copy(showFlag4 = !flag)
            4 -> viewStates.copy(showFlag5 = !flag)
            5 -> viewStates.copy(showFlag6 = !flag)
            6 -> viewStates.copy(showFlag7 = !flag)
            7 -> viewStates.copy(showFlag8 = !flag)
            8 -> viewStates.copy(showFlag9 = !flag)
            9 -> viewStates.copy(showFlag10 = !flag)
            10 -> viewStates.copy(showFlag11 = !flag)
            11 -> viewStates.copy(showFlag12 = !flag)
            12 -> viewStates.copy(showFlag13 = !flag)
            13 -> viewStates.copy(showFlag14 = !flag)
            14 -> viewStates.copy(showFlag15 = !flag)
            15 -> viewStates.copy(showFlag16 = !flag)
            16 -> viewStates.copy(showFlag17 = !flag)
            else -> viewStates.copy(showFlag19 = !flag)
        }
    }

    /**
     * チェックボックスの切替え
     */
    fun onCheckChange(check: Boolean) {
        viewStates = viewStates.copy(check = !check)
    }

    /**
     * チェックボックスの切替え
     */
    fun onCheck1Change(check: Boolean) {
        viewStates = viewStates.copy(check1 = !check)
    }

    /**
     * チェックボックスの切替え
     */
    fun onCheck2Change(check: Boolean) {
        viewStates = viewStates.copy(check2 = !check)
    }

    /**
     * チェックボックスの切替え
     */
    fun onCheck3Change(check: Boolean) {
        viewStates = viewStates.copy(check3 = !check)
    }

    /**
     * チェックボックスの切替え
     */
    fun onCheckLawChange(check: Boolean) {
        viewStates = viewStates.copy(checkLaw = !check)
    }

    /**
     * チェックボックスの切替え
     */
    fun onCheck4Change(check: Boolean) {
        viewStates = viewStates.copy(check4 = !check)
    }
}

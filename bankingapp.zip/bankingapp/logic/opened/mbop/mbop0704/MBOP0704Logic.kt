package jp.co.jsbank.mb.bankingapp.logic.opened.mbop.mbop0704

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import jp.co.jsbank.mb.bankingapp.bean.opened.mbop.mbop0701.BranchStore
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.system.master.CandidateFlag
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0704.MBOP0704PageState
import jp.co.jsbank.mb.bankingapp.utils.*

/**
 * MBOP0704ロジック
 */
@HiltViewModel
class MBOP0704Logic @Inject constructor() : ViewModel() {

    /**
     * ステータス
     */
    var viewStates by mutableStateOf(MBOP0704PageState())
        private set

    /**
     * 初期化
     */
    init {
        // 遷移元画面渡すパラメータ取得
        val departmentStoreList: List<Map<String, String>>
        val arguments = MainActivity.NAVCTRL?.currentBackStackEntry?.arguments?.get(ConstUtil.DATA_LIST)
        if (arguments != null) {
            departmentStoreList = arguments.toString().fromJson<List<Map<String, String>>>()!!
            if (departmentStoreList.isNotEmpty()) {
                val deptList = mutableListOf<BranchStore>()
                departmentStoreList.forEach {
                    deptList.add(
                        BranchStore(
                            bankCode = it["bankCode"] ?: "",
                            branchNumber = it["branchNumber"] ?: "",
                            branchKanjiName = it["branchKanjiName"] ?: "",
                            divisionType = it["divisionType"] ?: "",
                            branchInquiryType = it["branchInquiryType"] ?: "",
                            zipCode = it["zipCode"] ?: "",
                            branchKanjiAddress = it["branchKanjiAddress"] ?: "",
                            phoneNumber = it["phoneNumber"] ?: "",
                            branchGuide = it["branchGuide"] ?: "",
                            latitude = it["latitude"] ?: "",
                            longitude = it["longitude"] ?: "",
                            displayGroupName = it["displayGroupName"] ?: "",
                            displayOrder = it["displayOrder"] ?: "",
                        )
                    )
                }
                viewStates = viewStates.copy(deptList = deptList)
                val newDeptList = if (deptList.size > 16) {
                    deptList.subList(0, 16)
                } else {
                    deptList
                }
                viewStates = viewStates.copy(branchStoreList = newDeptList)
            }
        }
    }

    /**
     * 経緯度取得
     */
    fun getLongitudeAndLatitude(bean: BranchStore) {
        PreferenceUtil.removePreferenceStringValue(ConstUtil.REASON)
        PreferenceUtil.removePreferenceStringValue(ConstUtil.REASON_OTHER)
        RouteUtil.navTo(RouteName.MBOP0703Page + "/${bean.toJson()}/" + CandidateFlag.NO_CANDIDATE_DOWN.code)
    }

    /**
     * 明細もっと見る/リストを最小化するの切替
     */
    fun switchShowMore() {
        val showMore = viewStates.showMore
        viewStates = if (showMore) {
            viewStates.copy(
                showMore = false,
                branchStoreList = viewStates.deptList.subList(0, 16)
            )
        } else {
            viewStates.copy(
                showMore = true,
                branchStoreList = viewStates.deptList
            )
        }
    }

    fun goToOtherShop() {
        RouteUtil.navTo(
            RouteName.MBOP0706Page
        )
    }
}

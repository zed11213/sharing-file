package jp.co.jsbank.mb.bankingapp.logic.opened.mbop.mbop0604

import androidx.compose.foundation.ScrollState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import io.realm.Realm
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.bean.common.*
import jp.co.jsbank.mb.bankingapp.bean.opened.mbop.mbop0601.MBOP0601RequestBean
import jp.co.jsbank.mb.bankingapp.logic.common.PostInfoSearchLogic
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.repositories.db.common.create
import jp.co.jsbank.mb.bankingapp.repositories.db.common.deleteAll
import jp.co.jsbank.mb.bankingapp.repositories.db.common.findAll
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.AccountOpeningAB0706
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.EPassBookAB0701
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.system.MyApp
import jp.co.jsbank.mb.bankingapp.system.master.*
import jp.co.jsbank.mb.bankingapp.system.master.JobTitle.Companion.getJobTitleName
import jp.co.jsbank.mb.bankingapp.system.master.Phone.Companion.getPhoneTypeName
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0604.*
import jp.co.jsbank.mb.bankingapp.utils.*
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.HALF_HYPHEN
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.OPENED_EDIT_INFO_FLAG
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.PERSONALITY_FLAG
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.RECEIPT_NUMBER
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isFixedTelePhone
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isHalfAngle
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isHalfNum
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isIPTelePhone
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isMobilePhone
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isPersonNameCharacters
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isPersonNameKana
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isPersonNameKanaOther
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isPersonNameOther
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isPhone
import jp.co.jsbank.mb.bankingapp.utils.HalfToFullUtils.checkBuildRoom
import jp.co.jsbank.mb.bankingapp.utils.HalfToFullUtils.checkBuildRoomKana
import jp.co.jsbank.mb.bankingapp.utils.HalfToFullUtils.concatBuildRoom
import jp.co.jsbank.mb.bankingapp.utils.HalfToFullUtils.concatBuildRoomDb
import jp.co.jsbank.mb.bankingapp.utils.HalfToFullUtils.concatBuildRoomKana
import jp.co.jsbank.mb.bankingapp.utils.HalfToFullUtils.concatBuildRoomKanaDb
import jp.co.jsbank.mb.bankingapp.utils.HalfToFullUtils.fullToHalfChar
import jp.co.jsbank.mb.bankingapp.utils.HalfToFullUtils.splitBuildRoom
import jp.co.jsbank.mb.bankingapp.utils.HalfToFullUtils.splitBuildRoomKana
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import java.util.*
import javax.inject.Inject

/**
 * MBOP0604ロジック
 */
@HiltViewModel
class MBOP0604Logic @Inject constructor(
    private var webService: RestService
) : ViewModel() {

    /**
     * ログインステータス
     */
    var viewStates by mutableStateOf(MBOP0604PageState())
        private set

    /**
     * ロカールDB
     */
    private var dbService: Realm = MyApp.INSTANCE

    /**
     * エラーチェック
     */
    fun doNext(coroutineScope: CoroutineScope, scrollState: ScrollState) {
        // エラー情報初期化
        val representativeErrorBeanList = mutableListOf<RepresentativeErrorInformation>()
        val beneficialOwnerErrorBeanList = mutableListOf<BeneficialOwnerErrorInformation>()
        viewStates = viewStates.copy(isError = false)
        viewStates = viewStates.copy(errorMessageList = listOf())

        viewStates.representativeList.forEach { representative ->
            val representativeErrorInformation = RepresentativeErrorInformation()
            // ご役職が空白場合
            if (representative.jobTitle.isBlank()) {
                representativeErrorInformation.jobTitleErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_job_title)
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_job_title)
                                )
                        )
                    )
                }
            }

            // 姓が空白場合
            if (representative.firstName.isBlank()) {
                representativeErrorInformation.firstNameErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_firstName)
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_firstName)
                                )
                        )
                    )
                }
            } else if (!representative.firstName.isPersonNameCharacters()) {
                representativeErrorInformation.firstNameErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_firstName)
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_firstName)
                                )
                        )
                    )
                }
            }

            // 名前が空白場合
            if (representative.secondName.isBlank()) {
                representativeErrorInformation.secondNameErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_secondName)
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_secondName)
                                )
                        )
                    )
                }
            } else if (!representative.secondName.isPersonNameCharacters()) {
                representativeErrorInformation.secondNameErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_secondName)
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_secondName)
                                )
                        )
                    )
                }
            }

            // セイが空白場合
            if (representative.firstKanaName.isBlank()) {
                representativeErrorInformation.firstKanaNameErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_kana_firstName)
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_kana_firstName)
                                )
                        )
                    )
                }
            } else if (!representative.firstKanaName.isPersonNameKana()) {
                representativeErrorInformation.firstKanaNameErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002031V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_kana_firstName)
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002031V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_kana_firstName)
                                )
                        )
                    )
                }
            }

            // メイが空白場合
            if (representative.secondKanaName.isBlank()) {
                representativeErrorInformation.secondKanaNameErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_kana_secondName)
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_kana_secondName)
                                )
                        )
                    )
                }
            } else if (!representative.secondKanaName.isPersonNameKana()) {
                representativeErrorInformation.secondKanaNameErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002031V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_kana_secondName)
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002031V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_kana_secondName)
                                )
                        )
                    )
                }
            }

            // 2025/01/30 共同化ため名前の桁数変更　start
            val kanaNameLength = representative.firstKanaName +" "+ representative.secondKanaName
            // セイ(代表者・役員) + ブランク + メイ(代表者・役員)桁数は２０を超える場合
            if (kanaNameLength.length > 20) {
                representativeErrorInformation.firstKanaNamSecondKanaNameLengthErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                            MessageReplaceUtils.messageReplace(
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002036V),
                                MyApp.CONTEXT.getString(R.string.mbop0601_page_label_kana_firstName_secondName)
                            )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002036V),
                                    MyApp.CONTEXT.getString(R.string.mbop0601_page_label_kana_firstName_secondName)
                                )
                        )
                    )
                }
            }
            // 2025/01/30 共同化ため名前の桁数変更　end
            // 年が空白場合
            if (representative.year.isBlank()) {
                representativeErrorInformation.yearErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MessageReplaceUtils.messageReplace(
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002014V),
                                MyApp.CONTEXT.getString(R.string.common_message_replace_label_officers_year)
                            )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MessageReplaceUtils.messageReplace(
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002014V),
                                MyApp.CONTEXT.getString(R.string.common_message_replace_label_officers_year)
                            )
                        )
                    )
                }
            } else if (!EditCheckUtil.lengthCheck(representative.year, 4)) {
                representativeErrorInformation.yearErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002006V)
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002006V)
                        )
                    )
                }
            }

            // 月が空白場合
            if (representative.month.isBlank()) {
                representativeErrorInformation.monthErrorFlag = true
                if (!viewStates.errorMessageList.contains(
                        MessageReplaceUtils.messageReplace(
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002014V),
                                MyApp.CONTEXT.getString(R.string.common_message_replace_label_officers_month)
                            )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MessageReplaceUtils.messageReplace(
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002014V),
                                MyApp.CONTEXT.getString(R.string.common_message_replace_label_officers_month)
                            )
                        )
                    )
                }
            }

            // 日が空白場合
            if (representative.day.isBlank()) {
                representativeErrorInformation.dayErrorFlag = true
                if (!viewStates.errorMessageList.contains(
                        MessageReplaceUtils.messageReplace(
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002014V),
                                MyApp.CONTEXT.getString(R.string.common_message_replace_label_officers_day)
                            )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MessageReplaceUtils.messageReplace(
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002014V),
                                MyApp.CONTEXT.getString(R.string.common_message_replace_label_officers_day)
                            )
                        )
                    )
                }
            }

            // 年月日
            if (representative.year.isNotBlank() &&
                representative.month.isNotBlank() &&
                representative.day.isNotBlank()
            ) {
                if (!EditCheckUtil.isDayCheck(
                        representative.year,
                        representative.month,
                        representative.day
                    )
                ) {
                    representativeErrorInformation.yearErrorFlag = true
                    representativeErrorInformation.monthErrorFlag = true
                    representativeErrorInformation.dayErrorFlag = true
                    viewStates = viewStates.copy(isError = true)
                    if (!viewStates.errorMessageList.contains(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                                MessageReplaceUtils.messageReplace(
                                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002007V),
                                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_birthday)
                                    )
                        )
                    ) {
                        viewStates = viewStates.copy(
                            errorMessageList = viewStates.errorMessageList.plus(
                                MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                                    MessageReplaceUtils.messageReplace(
                                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002007V),
                                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_birthday)
                                    )
                            )
                        )
                    }
                }
                // 15歳未満チェック
                else if (LifeAge.getAgeByBirth(
                        representative.year + HALF_HYPHEN + representative.month + HALF_HYPHEN + representative.day
                    ) < 15
                ) {
                    representativeErrorInformation.yearErrorFlag = true
                    representativeErrorInformation.monthErrorFlag = true
                    representativeErrorInformation.dayErrorFlag = true
                    viewStates = viewStates.copy(isError = true)
                    if (!viewStates.errorMessageList.contains(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002025V)
                        )
                    ) {
                        viewStates = viewStates.copy(
                            errorMessageList = viewStates.errorMessageList.plus(
                                MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002025V)
                            )
                        )
                    }
                }
                // 1900年生まれ以降チェック
                else if (!EditCheckUtil.isYearCheck(representative.year)) {
                    representativeErrorInformation.yearErrorFlag = true
                    representativeErrorInformation.monthErrorFlag = true
                    representativeErrorInformation.dayErrorFlag = true
                    viewStates = viewStates.copy(isError = true)
                    if (!viewStates.errorMessageList.contains(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                                MessageReplaceUtils.messageReplace(
                                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002007V),
                                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_birthday)
                                    )
                        )
                    ) {
                        viewStates = viewStates.copy(
                            errorMessageList = viewStates.errorMessageList.plus(
                                MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                                    MessageReplaceUtils.messageReplace(
                                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002007V),
                                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_birthday)
                                    )
                            )
                        )
                    }
                }
            }

            // 郵便番号が空白場合
            if (representative.postCode.isBlank() ||
                !EditCheckUtil.lengthCheck(representative.postCode, 7)
            ) {
                representativeErrorInformation.postCodeErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002003V)
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002003V)
                        )
                    )
                }
            }

            // 郵便番号が空白場合
            if (representative.postCode.isBlank()) {
                representativeErrorInformation.postCodeErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_postCode)
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_postCode)
                                )
                        )
                    )
                }
            } else if (!representative.postCode.isHalfNum()) {
                // 郵便番号の半角数字チェック
                representativeErrorInformation.postCodeErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_postCode)
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_postCode)
                                )
                        )
                    )
                }
            } else if (!EditCheckUtil.lengthCheck(representative.postCode, 7)) {
                // 郵便番号の桁数チェック
                representativeErrorInformation.postCodeErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002003V)
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002003V)
                        )
                    )
                }
            }

            // 代表者-市区町村が空白場合
            if (representative.homeCity.isBlank()) {
                representativeErrorInformation.addressShowErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_home_city)
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_home_city)
                                )
                        )
                    )
                }
            }

            // 代表者-番地（全角）が空白場合
            if (!representative.candidateFlag && representative.homeAddress.isBlank()) {
                representativeErrorInformation.homeAddressErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_home_address)
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_home_address)
                                )
                        )
                    )
                }
//            } else if (!representative.candidateFlag && !fullToHalfChar(representative.homeAddress).isHalfAngle()) {
            } else if (!fullToHalfChar(representative.homeAddress).isHalfAngle()) {
                representativeErrorInformation.homeAddressErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002023V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_home_address)
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002023V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_home_address)
                                )
                        )
                    )
                }
//            } else if (!representative.candidateFlag && representative.homeAddress.startsWith(ConstUtil.FULL_HYPHEN)) {
            } else if (representative.homeAddress.startsWith(ConstUtil.FULL_HYPHEN)) {
                representativeErrorInformation.homeAddressErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002023V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_home_address)
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002023V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_home_address)
                                )
                        )
                    )
                }
            }

            // 代表者-市区町村（半角カナ）が空白場合
            if (representative.homeCityKana.isBlank()) {
                representativeErrorInformation.addressKanaShowErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_home_city_kana)
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_home_city_kana)
                                )
                        )
                    )
                }
            }

            // 代表者-番地（半角）が空白場合
            if (!representative.candidateFlag && representative.homeAddressHalf.isBlank()) {
                representativeErrorInformation.homeAddressHalfErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_home_address_half)
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_home_address_half)
                                )
                        )
                    )
                }
            } else if (!representative.homeAddressHalf.isHalfAngle()) {
                representativeErrorInformation.homeAddressHalfErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002023V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_home_address_half)
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002023V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_home_address_half)
                                )
                        )
                    )
                }
            } else if (representative.homeAddressHalf.startsWith(HALF_HYPHEN)) {
                representativeErrorInformation.homeAddressHalfErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002023V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_home_address_half)
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002023V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_home_address_half)
                                )
                        )
                    )
                }
            }

            // ご自宅の番地（全角）が入力された場合、ご自宅の番地（半角）も入力必要です
            if (representative.homeAddressHalf.isBlank() && representative.homeAddress.isNotBlank()) {
                representativeErrorInformation.homeAddressHalfErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_home_address_half)
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_home_address_half)
                                )
                        )
                    )
                }
            }

            // ご自宅の番地（半角）が入力された場合、ご自宅の番地（全角）も入力必要です
            if (representative.homeAddress.isBlank() && representative.homeAddressHalf.isNotBlank()) {
                representativeErrorInformation.homeAddressErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_home_address)
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_home_address)
                                )
                        )
                    )
                }
            }

            checkRepresentativeBuildRoom(representative, representativeErrorInformation)

            representative.phoneType = viewStates.representativeList[0].phoneType
            representative.phoneFirst = viewStates.representativeList[0].phoneFirst
            representative.phoneSecond = viewStates.representativeList[0].phoneSecond
            representative.phoneThird = viewStates.representativeList[0].phoneThird
            // 代表者電話番号が空白場合
            if (representative.phoneType.isBlank()) {
                representativeErrorInformation.phoneTypeErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_phone_type)
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_phone_type)
                                )
                        )
                    )
                }
            }

            // 代表者電話番号が空白場合
            if (representative.phoneFirst.isBlank()) {
                representativeErrorInformation.phoneFirstErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_phone)
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_phone)
                                )
                        )
                    )
                }
            } else if (!representative.phoneFirst.isHalfNum()) {
                // 電話番号の半角数字チェック
                representativeErrorInformation.phoneFirstErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_phone)
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_phone)
                                )
                        )
                    )
                }
            }

            // 代表者電話番号が空白場合
            if (representative.phoneSecond.isBlank()) {
                representativeErrorInformation.phoneSecondErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_phone)
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_phone)
                                )
                        )
                    )
                }
            } else if (!representative.phoneSecond.isHalfNum()) {
                // 電話番号の半角数字チェック
                representativeErrorInformation.phoneSecondErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_phone)
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_phone)
                                )
                        )
                    )
                }
            }

            // 代表者電話番号が空白場合
            if (representative.phoneThird.isBlank()) {
                representativeErrorInformation.phoneThirdErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_phone)
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_phone)
                                )
                        )
                    )
                }
            } else if (!representative.phoneThird.isHalfNum()) {
                // 電話番号の半角数字チェック
                representativeErrorInformation.phoneThirdErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_phone)
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_phone)
                                )
                        )
                    )
                }
            }

            if (representative.phoneFirst.isNotBlank() && representative.phoneSecond.isNotBlank() &&
                representative.phoneThird.isNotBlank()
            ) {
                val phone =
                    representative.phoneFirst + HALF_HYPHEN + representative.phoneSecond +
                        HALF_HYPHEN + representative.phoneThird
                if (representative.phoneType == Phone.FIXED_TELEPHONE.code &&
                    !(
                        phone.isFixedTelePhone() && phone.isPhone(
                                Phone.FIXED_TELEPHONE.code,
                                phone
                            )
                        )
                ) {
                    representativeErrorInformation.phoneFirstErrorFlag = true
                    representativeErrorInformation.phoneSecondErrorFlag = true
                    representativeErrorInformation.phoneThirdErrorFlag = true
                    viewStates = viewStates.copy(isError = true)
                    if (!viewStates.errorMessageList.contains(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002020V)
                        )
                    ) {
                        viewStates = viewStates.copy(
                            errorMessageList = viewStates.errorMessageList.plus(
                                MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002020V)
                            )
                        )
                    }
                } else if (representative.phoneType == Phone.MOBILE_PHONE.code &&
                    !(
                        phone.isMobilePhone() && phone.isPhone(
                                Phone.MOBILE_PHONE.code,
                                phone
                            )
                        )
                ) {
                    representativeErrorInformation.phoneFirstErrorFlag = true
                    representativeErrorInformation.phoneSecondErrorFlag = true
                    representativeErrorInformation.phoneThirdErrorFlag = true
                    viewStates = viewStates.copy(isError = true)
                    if (!viewStates.errorMessageList.contains(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002019V)
                        )
                    ) {
                        viewStates = viewStates.copy(
                            errorMessageList = viewStates.errorMessageList.plus(
                                MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002019V)
                            )
                        )
                    }// 2025/02/06 共同化ため電話番号の登録・表示 start
                } else if (representative.phoneType == Phone.IP_PHONE.code &&
                    !(
                        phone.isIPTelePhone() && phone.isPhone(
                            Phone.IP_PHONE.code,
                            phone
                        )
                        )
                ) {
                    representativeErrorInformation.phoneFirstErrorFlag = true
                    representativeErrorInformation.phoneSecondErrorFlag = true
                    representativeErrorInformation.phoneThirdErrorFlag = true
                    viewStates = viewStates.copy(isError = true)
                    if (!viewStates.errorMessageList.contains(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002034V)
                        )
                    ) {
                        viewStates = viewStates.copy(
                            errorMessageList = viewStates.errorMessageList.plus(
                                MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002034V)
                            )
                        )
                    }
                }// 2025/02/06 共同化ため電話番号の登録・表示 end
            }
            representativeErrorBeanList.add(representativeErrorInformation)
        }

        val ceoList = viewStates.representativeList.filter { item -> item.jobTitle == JobTitle.CEO.code }.toList()
        if (ceoList.isNullOrEmpty()) {
            viewStates.representativeList.forEachIndexed { index, _ ->
                representativeErrorBeanList[index].jobTitleErrorFlag = true
            }
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002030V)
                )
            )
        }
        viewStates = viewStates.copy(representativeErrorBeanList = representativeErrorBeanList)

        viewStates.beneficialOwnerList.forEach { beneficialOwner ->
            val beneficialOwnerErrorInformation = BeneficialOwnerErrorInformation()
            // 姓(実質的支配者)が空白場合
            if (beneficialOwner.beneficialOwnerFirstName.isBlank()) {
                beneficialOwnerErrorInformation.beneficialOwnerFirstNameErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_firstName)
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_firstName)
                                )
                        )
                    )
                }
            } else if (!beneficialOwner.beneficialOwnerFirstName.isPersonNameCharacters()) {
                beneficialOwnerErrorInformation.beneficialOwnerFirstNameErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002028V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_firstName)
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002028V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_firstName)
                                )
                        )
                    )
                }
            }

            // 名前(実質的支配者)が空白場合
            if (beneficialOwner.beneficialOwnerSecondName.isBlank()) {
                beneficialOwnerErrorInformation.beneficialOwnerSecondNameErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_secondName)
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_secondName)
                                )
                        )
                    )
                }
            } else if (!beneficialOwner.beneficialOwnerSecondName.isPersonNameCharacters()) {
                beneficialOwnerErrorInformation.beneficialOwnerSecondNameErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002028V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_secondName)
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002028V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_secondName)
                                )
                        )
                    )
                }
            }

            // セイ(実質的支配者)が空白場合
            if (beneficialOwner.beneficialOwnerFirstKanaName.isBlank()) {
                beneficialOwnerErrorInformation.beneficialOwnerFirstKanaNameErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_kana_firstName)
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_kana_firstName)
                                )
                        )
                    )
                }
            } else if (!beneficialOwner.beneficialOwnerFirstKanaName.isPersonNameKana()) {
                beneficialOwnerErrorInformation.beneficialOwnerFirstKanaNameErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002031V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_kana_firstName)
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002031V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_kana_firstName)
                                )
                        )
                    )
                }
            }

            // メイ(実質的支配者)が空白場合
            if (beneficialOwner.beneficialOwnerSecondKanaName.isBlank()) {
                beneficialOwnerErrorInformation.beneficialOwnerSecondKanaNameErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_kana_secondName)
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_kana_secondName)
                                )
                        )
                    )
                }
            } else if (!beneficialOwner.beneficialOwnerSecondKanaName.isPersonNameKana()) {
                beneficialOwnerErrorInformation.beneficialOwnerSecondKanaNameErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002031V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_kana_secondName)
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002031V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_kana_secondName)
                                )
                        )
                    )
                }
            }

            // 2025/01/30 共同化ため名前の桁数変更　start
            val beneficialOwnerKanaNameLength = beneficialOwner.beneficialOwnerFirstKanaName +" "+ beneficialOwner.beneficialOwnerSecondKanaName
            // セイ(実質的支配者) + ブランク + メイ(実質的支配者)桁数は２０を超える場合
            if (beneficialOwnerKanaNameLength.length > 20) {
                beneficialOwnerErrorInformation.beneficialOwnerFirstKanaNamSecondKanaNameLengthErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                            MessageReplaceUtils.messageReplace(
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002036V),
                                MyApp.CONTEXT.getString(R.string.mbop0601_page_label_kana_firstName_secondName)
                            )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002036V),
                                    MyApp.CONTEXT.getString(R.string.mbop0601_page_label_kana_firstName_secondName)
                                )
                        )
                    )
                }
            }
            // 2025/01/30 共同化ため名前の桁数変更　end

            // 年が空白場合
            if (beneficialOwner.beneficialOwnerYear.isBlank()) {
                beneficialOwnerErrorInformation.beneficialOwnerYearErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MessageReplaceUtils.messageReplace(
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002014V),
                                MyApp.CONTEXT.getString(R.string.common_message_replace_label_ruler_year)
                            )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MessageReplaceUtils.messageReplace(
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002014V),
                                MyApp.CONTEXT.getString(R.string.common_message_replace_label_ruler_year)
                            )
                        )
                    )
                }
            } else if (!EditCheckUtil.lengthCheck(beneficialOwner.beneficialOwnerYear, 4)) {
                beneficialOwnerErrorInformation.beneficialOwnerYearErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002006V)
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002006V)
                        )
                    )
                }
            }

            // 月が空白場合
            if (beneficialOwner.beneficialOwnerMonth.isBlank()) {
                beneficialOwnerErrorInformation.beneficialOwnerMonthErrorFlag = true
                if (!viewStates.errorMessageList.contains(
                        MessageReplaceUtils.messageReplace(
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002014V),
                                MyApp.CONTEXT.getString(R.string.common_message_replace_label_ruler_month)
                            )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MessageReplaceUtils.messageReplace(
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002014V),
                                MyApp.CONTEXT.getString(R.string.common_message_replace_label_ruler_month)
                            )
                        )
                    )
                }
            }

            // 日が空白場合
            if (beneficialOwner.beneficialOwnerDay.isBlank()) {
                beneficialOwnerErrorInformation.beneficialOwnerDayErrorFlag = true
                if (!viewStates.errorMessageList.contains(
                        MessageReplaceUtils.messageReplace(
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002014V),
                                MyApp.CONTEXT.getString(R.string.common_message_replace_label_ruler_day)
                            )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MessageReplaceUtils.messageReplace(
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002014V),
                                MyApp.CONTEXT.getString(R.string.common_message_replace_label_ruler_day)
                            )
                        )
                    )
                }
            }

            // 年月日
            if (beneficialOwner.beneficialOwnerYear.isNotBlank() &&
                beneficialOwner.beneficialOwnerMonth.isNotBlank() &&
                beneficialOwner.beneficialOwnerDay.isNotBlank()
            ) {
                if (!EditCheckUtil.isDayCheck(
                        beneficialOwner.beneficialOwnerYear,
                        beneficialOwner.beneficialOwnerMonth,
                        beneficialOwner.beneficialOwnerDay
                    )
                ) {
                    beneficialOwnerErrorInformation.beneficialOwnerYearErrorFlag = true
                    beneficialOwnerErrorInformation.beneficialOwnerMonthErrorFlag = true
                    beneficialOwnerErrorInformation.beneficialOwnerDayErrorFlag = true
                    viewStates = viewStates.copy(isError = true)
                    if (!viewStates.errorMessageList.contains(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                                MessageReplaceUtils.messageReplace(
                                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002007V),
                                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_owner_birthday)
                                    )
                        )
                    ) {
                        viewStates = viewStates.copy(
                            errorMessageList = viewStates.errorMessageList.plus(
                                MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                                    MessageReplaceUtils.messageReplace(
                                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002007V),
                                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_owner_birthday)
                                    )
                            )
                        )
                    }
                }
                // 15歳未満チェック
                else if (LifeAge.getAgeByBirth(
                        beneficialOwner.beneficialOwnerYear + HALF_HYPHEN +
                            beneficialOwner.beneficialOwnerMonth + HALF_HYPHEN +
                            beneficialOwner.beneficialOwnerDay
                    ) < 15
                ) {
                    beneficialOwnerErrorInformation.beneficialOwnerYearErrorFlag = true
                    beneficialOwnerErrorInformation.beneficialOwnerMonthErrorFlag = true
                    beneficialOwnerErrorInformation.beneficialOwnerDayErrorFlag = true
                    viewStates = viewStates.copy(isError = true)
                    if (!viewStates.errorMessageList.contains(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002025V)
                        )
                    ) {
                        viewStates = viewStates.copy(
                            errorMessageList = viewStates.errorMessageList.plus(
                                MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002025V)
                            )
                        )
                    }
                }
                // 1900年生まれ以降チェック
                else if (!EditCheckUtil.isYearCheck(beneficialOwner.beneficialOwnerYear)) {
                    beneficialOwnerErrorInformation.beneficialOwnerYearErrorFlag = true
                    beneficialOwnerErrorInformation.beneficialOwnerMonthErrorFlag = true
                    beneficialOwnerErrorInformation.beneficialOwnerDayErrorFlag = true
                    viewStates = viewStates.copy(isError = true)
                    if (!viewStates.errorMessageList.contains(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                                MessageReplaceUtils.messageReplace(
                                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002007V),
                                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_owner_birthday)
                                    )
                        )
                    ) {
                        viewStates = viewStates.copy(
                            errorMessageList = viewStates.errorMessageList.plus(
                                MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                                    MessageReplaceUtils.messageReplace(
                                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002007V),
                                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_owner_birthday)
                                    )
                            )
                        )
                    }
                }
            }

            // 郵便番号が空白場合
            if (beneficialOwner.beneficialOwnerPostCode.isBlank()) {
                beneficialOwnerErrorInformation.beneficialOwnerPostCodeErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_owner_postCode)
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_owner_postCode)
                                )
                        )
                    )
                }
            } else if (!beneficialOwner.beneficialOwnerPostCode.isHalfNum()) {
                // 郵便番号の半角数字チェック
                beneficialOwnerErrorInformation.beneficialOwnerPostCodeErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_owner_postCode)
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_owner_postCode)
                                )
                        )
                    )
                }
            } else if (!EditCheckUtil.lengthCheck(beneficialOwner.beneficialOwnerPostCode, 7)) {
                // 郵便番号の桁数チェック
                beneficialOwnerErrorInformation.beneficialOwnerPostCodeErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002003V)
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002003V)
                        )
                    )
                }
            }

            // 実質的支配者-市区町村が空白場合
            if (beneficialOwner.beneficialOwnerHomeCity.isBlank()) {
                beneficialOwnerErrorInformation.addressShowErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_owner_home_city)
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_owner_home_city)
                                )
                        )
                    )
                }
            }

            // 実質的支配者-番地（全角）が空白場合
            if (!beneficialOwner.candidateFlag && beneficialOwner.beneficialOwnerHomeAddress.isBlank()) {
                beneficialOwnerErrorInformation.beneficialOwnerHomeAddressErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_owner_home_address)
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_owner_home_address)
                                )
                        )
                    )
                }
//            } else if (!beneficialOwner.candidateFlag &&
            } else if (
                !fullToHalfChar(beneficialOwner.beneficialOwnerHomeAddress).isHalfAngle()
            ) {
                beneficialOwnerErrorInformation.beneficialOwnerHomeAddressErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002023V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_owner_home_address)
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002023V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_owner_home_address)
                                )
                        )
                    )
                }
//            } else if (!beneficialOwner.candidateFlag &&
            } else if (
                beneficialOwner.beneficialOwnerHomeAddress.startsWith(ConstUtil.FULL_HYPHEN)
            ) {
                beneficialOwnerErrorInformation.beneficialOwnerHomeAddressErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002023V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_owner_home_address)
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002023V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_owner_home_address)
                                )
                        )
                    )
                }
            }

            // 実質的支配者-市区町村（半角カナ）が空白場合
            if (beneficialOwner.beneficialOwnerHomeCityKana.isBlank()) {
                beneficialOwnerErrorInformation.addressKanaShowErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                                    MyApp.CONTEXT.getString(
                                            R.string.mbop0604_page_label_beneficial_owner_home_city_kana
                                        )
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                                    MyApp.CONTEXT.getString(
                                        R.string.mbop0604_page_label_beneficial_owner_home_city_kana
                                    )
                                )
                        )
                    )
                }
            }

            // 実質的支配者-番地（半角）が空白場合
            if (!beneficialOwner.candidateFlag && beneficialOwner.beneficialOwnerHomeAddressHalf.isBlank()) {
                beneficialOwnerErrorInformation.beneficialOwnerHomeAddressHalfErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                    MyApp.CONTEXT.getString(
                                            R.string.mbop0604_page_label_beneficial_owner_home_address_half
                                        )
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                    MyApp.CONTEXT.getString(
                                        R.string.mbop0604_page_label_beneficial_owner_home_address_half
                                    )
                                )
                        )
                    )
                }
//            } else if (!beneficialOwner.candidateFlag &&
            } else if (
                !beneficialOwner.beneficialOwnerHomeAddressHalf.isHalfAngle()
            ) {
                beneficialOwnerErrorInformation.beneficialOwnerHomeAddressHalfErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002023V),
                                    MyApp.CONTEXT.getString(
                                            R.string.mbop0604_page_label_beneficial_owner_home_address_half
                                        )
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002023V),
                                    MyApp.CONTEXT.getString(
                                        R.string.mbop0604_page_label_beneficial_owner_home_address_half
                                    )
                                )
                        )
                    )
                }
//            } else if (!beneficialOwner.candidateFlag && beneficialOwner.beneficialOwnerHomeAddressHalf.startsWith(
            } else if (beneficialOwner.beneficialOwnerHomeAddressHalf.startsWith(
                    HALF_HYPHEN
                )
            ) {
                beneficialOwnerErrorInformation.beneficialOwnerHomeAddressHalfErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002023V),
                                    MyApp.CONTEXT.getString(
                                            R.string.mbop0604_page_label_beneficial_owner_home_address_half
                                        )
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002023V),
                                    MyApp.CONTEXT.getString(
                                        R.string.mbop0604_page_label_beneficial_owner_home_address_half
                                    )
                                )
                        )
                    )
                }
            }

            // 実質的支配者-番地（全角）が入力された場合、実質的支配者-番地（半角）も入力必要です
            if (beneficialOwner.beneficialOwnerHomeAddressHalf.isBlank() &&
                beneficialOwner.beneficialOwnerHomeAddress.isNotBlank()
            ) {
                beneficialOwnerErrorInformation.beneficialOwnerHomeAddressHalfErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                    MyApp.CONTEXT.getString(
                                            R.string.mbop0604_page_label_beneficial_owner_home_address_half
                                        )
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                    MyApp.CONTEXT.getString(
                                        R.string.mbop0604_page_label_beneficial_owner_home_address_half
                                    )
                                )
                        )
                    )
                }
            }

            // 実質的支配者-番地（半角）が入力された場合、実質的支配者-番地（全角）も入力必要です
            if (beneficialOwner.beneficialOwnerHomeAddress.isBlank() &&
                beneficialOwner.beneficialOwnerHomeAddressHalf.isNotBlank()
            ) {
                beneficialOwnerErrorInformation.beneficialOwnerHomeAddressErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_owner_home_address)
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_owner_home_address)
                                )
                        )
                    )
                }
            }

            // 建物名/号室カナが入力された場合、建物名/号室も入力必要です
            if (beneficialOwner.beneficialOwnerRoom.isBlank() && beneficialOwner.beneficialOwnerRoomKana.isNotBlank()) {
                beneficialOwnerErrorInformation.beneficialOwnerRoomErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_owner_room)
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_owner_room)
                                )
                        )
                    )
                }
            }

            // ご自宅の建物名/号室が入力された場合、ご自宅の建物名/号室カナも入力必要です
            if (beneficialOwner.beneficialOwnerRoom.isNotBlank() && beneficialOwner.beneficialOwnerRoomKana.isBlank()) {
                beneficialOwnerErrorInformation.beneficialOwnerRoomKanaErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_owner_room_kana)
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_owner_room_kana)
                                )
                        )
                    )
                }
            }

            // ご自宅の建物名/号室が入力された場合、全角
            if (beneficialOwner.beneficialOwnerRoom.isNotBlank() &&
                !beneficialOwner.beneficialOwnerRoom.isPersonNameOther()
            ) {
                beneficialOwnerErrorInformation.beneficialOwnerRoomErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_owner_room)
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_owner_room)
                                )
                        )
                    )
                }
            }

            // ご自宅の建物名/号室（半角カナ）が入力された場合、全角
            if (beneficialOwner.beneficialOwnerRoomKana.isNotBlank() &&
                !beneficialOwner.beneficialOwnerRoomKana.isPersonNameKanaOther()
            ) {
                beneficialOwnerErrorInformation.beneficialOwnerRoomKanaErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                            MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002032V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_owner_room_kana)
                                )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002032V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_owner_room_kana)
                                )
                        )
                    )
                }
            }

            // 2025/01/29 共同化ため　実質的支配者の電話番号　start
            beneficialOwner.phoneType = viewStates.beneficialOwnerList[0].phoneType
            beneficialOwner.phoneFirst = viewStates.beneficialOwnerList[0].phoneFirst
            beneficialOwner.phoneSecond = viewStates.beneficialOwnerList[0].phoneSecond
            beneficialOwner.phoneThird = viewStates.beneficialOwnerList[0].phoneThird
            // 実質的支配者電話番号が空白場合
            if (beneficialOwner.phoneType.isBlank()) {
                beneficialOwnerErrorInformation.phoneTypeErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                            MessageReplaceUtils.messageReplace(
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                                MyApp.CONTEXT.getString(R.string.mbop0604_page_label_phone_type)
                            )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_phone_type)
                                )
                        )
                    )
                }
            }

            // 実質的支配者電話番号が空白場合
            if (beneficialOwner.phoneFirst.isBlank()) {
                beneficialOwnerErrorInformation.phoneFirstErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                            MessageReplaceUtils.messageReplace(
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                MyApp.CONTEXT.getString(R.string.mbop0604_page_label_phone)
                            )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_phone)
                                )
                        )
                    )
                }
            } else if (!beneficialOwner.phoneFirst.isHalfNum()) {
                // 電話番号の半角数字チェック
                beneficialOwnerErrorInformation.phoneFirstErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                            MessageReplaceUtils.messageReplace(
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                                MyApp.CONTEXT.getString(R.string.mbop0604_page_label_phone)
                            )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_phone)
                                )
                        )
                    )
                }
            }

            // 実質的支配者電話番号が空白場合
            if (beneficialOwner.phoneSecond.isBlank()) {
                beneficialOwnerErrorInformation.phoneSecondErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                            MessageReplaceUtils.messageReplace(
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                MyApp.CONTEXT.getString(R.string.mbop0604_page_label_phone)
                            )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_phone)
                                )
                        )
                    )
                }
            } else if (!beneficialOwner.phoneSecond.isHalfNum()) {
                // 電話番号の半角数字チェック
                beneficialOwnerErrorInformation.phoneSecondErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                            MessageReplaceUtils.messageReplace(
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                                MyApp.CONTEXT.getString(R.string.mbop0604_page_label_phone)
                            )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_phone)
                                )
                        )
                    )
                }
            }

            // 実質的支配者電話番号が空白場合
            if (beneficialOwner.phoneThird.isBlank()) {
                beneficialOwnerErrorInformation.phoneThirdErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                            MessageReplaceUtils.messageReplace(
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                MyApp.CONTEXT.getString(R.string.mbop0604_page_label_phone)
                            )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_phone)
                                )
                        )
                    )
                }
            } else if (!beneficialOwner.phoneThird.isHalfNum()) {
                // 電話番号の半角数字チェック
                beneficialOwnerErrorInformation.phoneThirdErrorFlag = true
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                            MessageReplaceUtils.messageReplace(
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                                MyApp.CONTEXT.getString(R.string.mbop0604_page_label_phone)
                            )
                    )
                ) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                                MessageReplaceUtils.messageReplace(
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_phone)
                                )
                        )
                    )
                }
            }

            if (beneficialOwner.phoneFirst.isNotBlank() && beneficialOwner.phoneSecond.isNotBlank() &&
                beneficialOwner.phoneThird.isNotBlank()
            ) {
                val phone =
                    beneficialOwner.phoneFirst + HALF_HYPHEN + beneficialOwner.phoneSecond +
                        HALF_HYPHEN + beneficialOwner.phoneThird
                if (beneficialOwner.phoneType == Phone.FIXED_TELEPHONE.code &&
                    !(
                        phone.isFixedTelePhone() && phone.isPhone(
                            Phone.FIXED_TELEPHONE.code,
                            phone
                        )
                        )
                ) {
                    beneficialOwnerErrorInformation.phoneFirstErrorFlag = true
                    beneficialOwnerErrorInformation.phoneSecondErrorFlag = true
                    beneficialOwnerErrorInformation.phoneThirdErrorFlag = true
                    viewStates = viewStates.copy(isError = true)
                    if (!viewStates.errorMessageList.contains(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002020V)
                        )
                    ) {
                        viewStates = viewStates.copy(
                            errorMessageList = viewStates.errorMessageList.plus(
                                MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002020V)
                            )
                        )
                    }
                } else if (beneficialOwner.phoneType == Phone.MOBILE_PHONE.code &&
                    !(
                        phone.isMobilePhone() && phone.isPhone(
                            Phone.MOBILE_PHONE.code,
                            phone
                        )
                        )
                ) {
                    beneficialOwnerErrorInformation.phoneFirstErrorFlag = true
                    beneficialOwnerErrorInformation.phoneSecondErrorFlag = true
                    beneficialOwnerErrorInformation.phoneThirdErrorFlag = true
                    viewStates = viewStates.copy(isError = true)
                    if (!viewStates.errorMessageList.contains(
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002019V)
                        )
                    ) {
                        viewStates = viewStates.copy(
                            errorMessageList = viewStates.errorMessageList.plus(
                                MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002019V)
                            )
                        )
                    }
                }
            }
            // 2025/01/29 共同化ため　実質的支配者の電話番号　end
            checkBeneficialOwnerBuildRoom(beneficialOwner, beneficialOwnerErrorInformation)
            beneficialOwnerErrorBeanList.add(beneficialOwnerErrorInformation)
        }

        viewStates = viewStates.copy(beneficialOwnerErrorBeanList = beneficialOwnerErrorBeanList)

        if (!viewStates.isError) {
            // 口座開設申込情報（法人）
            val corporation = CorporationBean()
            viewStates.representativeList.forEach { representative ->
                val ceoOfficer = CeoOfficer()
                ceoOfficer.position = representative.jobTitle
                ceoOfficer.officerKanjiLastName = representative.firstName
                ceoOfficer.officerKanjiFirstName = representative.secondName
                ceoOfficer.officerLastName = representative.firstKanaName
                ceoOfficer.officerFirstName = representative.secondKanaName
                ceoOfficer.officerBirthday = representative.year + HALF_HYPHEN + representative.month +
                    HALF_HYPHEN + representative.day
                ceoOfficer.officerZipCode = representative.postCode
                ceoOfficer.officerPrefecture = representative.homePrefecture
                ceoOfficer.officerCity = representative.homeCity
                ceoOfficer.officerStreet = representative.chome
                ceoOfficer.officerBuilding = concatBuildRoom(representative.build, representative.room)
                ceoOfficer.officerAddress = representative.homeAddress
                ceoOfficer.officerPrefectureKana = representative.homePrefectureKana
                ceoOfficer.officerCityKana = representative.homeCityKana
                ceoOfficer.officerStreetKana = if (representative.chomeKana.isNotBlank()) {
                    if (representative.chomeKana.last().isDigit()) {
                        representative.chomeKana + HALF_HYPHEN
                    } else {
                        representative.chomeKana
                    }
                } else ""
                ceoOfficer.officerBuildingKana = concatBuildRoomKana(representative.buildKana, representative.roomKana)
                ceoOfficer.officerAddressKana = representative.homeAddressHalf
                ceoOfficer.officerPhoneType = representative.phoneType
                ceoOfficer.officerPhoneNumOneFirst = representative.phoneFirst
                ceoOfficer.officerPhoneNumOneMid = representative.phoneSecond
                ceoOfficer.officerPhoneNumOneLast = representative.phoneThird
                corporation.ceoOfficer.add(ceoOfficer)
            }
            viewStates.beneficialOwnerList.forEach { beneficialOwner ->
                val substantialRuler = SubstantialRuler()
                substantialRuler.rulerKanjiLastName = beneficialOwner.beneficialOwnerFirstName
                substantialRuler.rulerKanjiFirstName = beneficialOwner.beneficialOwnerSecondName
                substantialRuler.rulerLastName = beneficialOwner.beneficialOwnerFirstKanaName
                substantialRuler.rulerFirstName = beneficialOwner.beneficialOwnerSecondKanaName
                substantialRuler.rulerBirthday = beneficialOwner.beneficialOwnerYear + HALF_HYPHEN +
                    beneficialOwner.beneficialOwnerMonth + HALF_HYPHEN + beneficialOwner.beneficialOwnerDay
                substantialRuler.rulerZipCode = beneficialOwner.beneficialOwnerPostCode
                substantialRuler.rulerPrefecture = beneficialOwner.beneficialOwnerHomePrefecture
                substantialRuler.rulerCity = beneficialOwner.beneficialOwnerHomeCity
                substantialRuler.rulerStreet = beneficialOwner.beneficialOwnerChome
                substantialRuler.rulerBuilding =
                    concatBuildRoom(beneficialOwner.beneficialOwnerBuild, beneficialOwner.beneficialOwnerRoom)
                substantialRuler.rulerAddress = beneficialOwner.beneficialOwnerHomeAddress
                substantialRuler.rulerPrefectureKana = beneficialOwner.beneficialOwnerHomePrefectureKana
                substantialRuler.rulerCityKana = beneficialOwner.beneficialOwnerHomeCityKana

                // 2025/01/29 共同化ため実質的支配者の電話番号　start
                substantialRuler.rulerPhoneType = beneficialOwner.phoneType
                substantialRuler.rulerPhoneNumFirst = beneficialOwner.phoneFirst
                substantialRuler.rulerPhoneNumMid = beneficialOwner.phoneSecond
                substantialRuler.rulerPhoneNumLast = beneficialOwner.phoneThird
                // 2025/01/29 共同化ため実質的支配者の電話番号　end

                substantialRuler.rulerStreetKana =
                    if (beneficialOwner.beneficialOwnerChomeKana.isNotBlank())
                        if (beneficialOwner.beneficialOwnerChomeKana.last().isDigit()) {
                            beneficialOwner.beneficialOwnerChomeKana + HALF_HYPHEN
                        } else {
                            beneficialOwner.beneficialOwnerChomeKana
                        }
                    else ""
                substantialRuler.rulerBuildingKana =
                    concatBuildRoomKana(beneficialOwner.beneficialOwnerBuildKana, beneficialOwner.beneficialOwnerRoomKana)
                substantialRuler.rulerAddressKana = beneficialOwner.beneficialOwnerHomeAddressHalf
                corporation.substantialRuler.add(substantialRuler)
                // 受付番号
                corporation.receiptNumber = KeyStoreUtil().getFromKeyStore(RECEIPT_NUMBER)
                corporation.pageId = "MBOP0604"
            }
            viewStates = viewStates.copy(corporation = corporation)
            // 画面IDとイベントID設定
            PreferenceUtil.setScreenIDAndEventID("MBOP0604", "E04")
            // リクエストボディ編集
            val requestBean = MBOP0601RequestBean()
            // 人格区分
            requestBean.personType = PreferenceUtil.getPreferenceStringValue(PERSONALITY_FLAG).toString()
            // 受付番号
            requestBean.receiptNumber = KeyStoreUtil().getFromKeyStore(RECEIPT_NUMBER)
            // 口座開設申込情報（法人）
            requestBean.corporationDto = corporation
            // 更新パターン
            requestBean.updateType = UpdateType.UPDATE_TYPE_015.code
            // お客様情報入力
            viewModelScope.launch {
                flow {
                    ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, requestBean.convertToParams().toJson())
                    emit(webService.AB0706())
                }.map {
                    set0706()
                    if (PreferenceUtil.getPreferenceBooleanValue(OPENED_EDIT_INFO_FLAG)) {
                        PreferenceUtil.setPreferenceBooleanValue(OPENED_EDIT_INFO_FLAG, false)
                        RouteUtil.navTo(
                            RouteName.MBOP1003Page
                        )
                    } else {
                        PreferenceUtil.setPreferenceBooleanValue(OPENED_EDIT_INFO_FLAG, false)
                        RouteUtil.navTo(
                            RouteName.MBOP0605Page,
                        )
                    }
                }.catch {
                    ErrorUtil().apiErrorCatch(it.message.toString())
                }.collect()
            }
        } else {
            coroutineScope.launch {
                scrollState.animateScrollTo(0)
            }
        }
    }

    /**
     * 実質的支配者エラーチェック
     */
    private fun checkBeneficialOwnerBuildRoom(
        beneficialOwner: BeneficialOwner,
        beneficialOwnerErrorInformation: BeneficialOwnerErrorInformation
    ) {
        // 建物名カナが入力された場合、建物名も入力必要です
        if (beneficialOwner.beneficialOwnerBuild.isBlank() && beneficialOwner.beneficialOwnerBuildKana.isNotBlank()) {
            beneficialOwnerErrorInformation.beneficialOwnerBuildErrorFlag = true
            viewStates = viewStates.copy(isError = true)
            if (!viewStates.errorMessageList.contains(
                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_owner_build)
                        )
                )
            ) {
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                            MessageReplaceUtils.messageReplace(
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_owner_build)
                            )
                    )
                )
            }
        }

        // ご自宅の建物名が入力された場合、ご自宅の建物名カナも入力必要です
        if (beneficialOwner.beneficialOwnerBuild.isNotBlank() && beneficialOwner.beneficialOwnerBuildKana.isBlank()) {
            beneficialOwnerErrorInformation.beneficialOwnerBuildKanaErrorFlag = true
            viewStates = viewStates.copy(isError = true)
            if (!viewStates.errorMessageList.contains(
                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_owner_build_kana)
                        )
                )
            ) {
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                            MessageReplaceUtils.messageReplace(
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_owner_build_kana)
                            )
                    )
                )
            }
        }

        // ご自宅の建物名が入力された場合、全角
        if (beneficialOwner.beneficialOwnerBuild.isNotBlank() &&
            !beneficialOwner.beneficialOwnerBuild.isPersonNameOther()
        ) {
            beneficialOwnerErrorInformation.beneficialOwnerBuildErrorFlag = true
            viewStates = viewStates.copy(isError = true)
            if (!viewStates.errorMessageList.contains(
                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_owner_build)
                        )
                )
            ) {
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                            MessageReplaceUtils.messageReplace(
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                                MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_owner_build)
                            )
                    )
                )
            }
        }

        // ご自宅の建物名（半角カナ）が入力された場合、全角
        if (beneficialOwner.beneficialOwnerBuildKana.isNotBlank() &&
            !beneficialOwner.beneficialOwnerBuildKana.isPersonNameKanaOther()
        ) {
            beneficialOwnerErrorInformation.beneficialOwnerBuildKanaErrorFlag = true
            viewStates = viewStates.copy(isError = true)
            if (!viewStates.errorMessageList.contains(
                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002032V),
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_owner_build_kana)
                        )
                )
            ) {
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                            MessageReplaceUtils.messageReplace(
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002032V),
                                MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_owner_build_kana)
                            )
                    )
                )
            }
        }


        //=================room

        // 号室カナが入力された場合、号室も入力必要です
        if (beneficialOwner.beneficialOwnerRoom.isBlank() && beneficialOwner.beneficialOwnerRoomKana.isNotBlank()) {
            beneficialOwnerErrorInformation.beneficialOwnerRoomErrorFlag = true
            viewStates = viewStates.copy(isError = true)
            if (!viewStates.errorMessageList.contains(
                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_owner_room)
                        )
                )
            ) {
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                            MessageReplaceUtils.messageReplace(
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_owner_room)
                            )
                    )
                )
            }
        }

        // ご自宅の建物名/号室が入力された場合、ご自宅の建物名/号室カナも入力必要です
        if (beneficialOwner.beneficialOwnerRoom.isNotBlank() && beneficialOwner.beneficialOwnerRoomKana.isBlank()) {
            beneficialOwnerErrorInformation.beneficialOwnerRoomKanaErrorFlag = true
            viewStates = viewStates.copy(isError = true)
            if (!viewStates.errorMessageList.contains(
                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_owner_room_kana)
                        )
                )
            ) {
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                            MessageReplaceUtils.messageReplace(
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_owner_room_kana)
                            )
                    )
                )
            }
        }

        // ご自宅の建物名/号室が入力された場合、全角
        if (beneficialOwner.beneficialOwnerRoom.isNotBlank() &&
            !beneficialOwner.beneficialOwnerRoom.isPersonNameOther()
        ) {
            beneficialOwnerErrorInformation.beneficialOwnerRoomErrorFlag = true
            viewStates = viewStates.copy(isError = true)
            if (!viewStates.errorMessageList.contains(
                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_owner_room)
                        )
                )
            ) {
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                            MessageReplaceUtils.messageReplace(
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                                MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_owner_room)
                            )
                    )
                )
            }
        }

        // ご自宅の建物名/号室（半角カナ）が入力された場合、全角
        if (beneficialOwner.beneficialOwnerRoomKana.isNotBlank() &&
            !beneficialOwner.beneficialOwnerRoomKana.isPersonNameKanaOther()
        ) {
            beneficialOwnerErrorInformation.beneficialOwnerRoomKanaErrorFlag = true
            viewStates = viewStates.copy(isError = true)
            if (!viewStates.errorMessageList.contains(
                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002032V),
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_owner_room_kana)
                        )
                )
            ) {
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_error) +
                            MessageReplaceUtils.messageReplace(
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002032V),
                                MyApp.CONTEXT.getString(R.string.mbop0604_page_label_beneficial_owner_room_kana)
                            )
                    )
                )
            }
        }

        if (checkBuildRoom(beneficialOwner.beneficialOwnerBuild, beneficialOwner.beneficialOwnerRoom)) {
            beneficialOwnerErrorInformation.beneficialOwnerBuildErrorFlag = true
            beneficialOwnerErrorInformation.beneficialOwnerRoomErrorFlag = true
            viewStates = viewStates.copy(isError = true)
            if (!viewStates.errorMessageList.contains(MyApp.CONTEXT.getString(R.string.MSG_ID_MB002098V))) {
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002098V)
                    )
                )
            }
        }

        if (checkBuildRoomKana(beneficialOwner.beneficialOwnerBuildKana, beneficialOwner.beneficialOwnerRoomKana)) {
            beneficialOwnerErrorInformation.beneficialOwnerBuildKanaErrorFlag = true
            beneficialOwnerErrorInformation.beneficialOwnerRoomKanaErrorFlag = true
            viewStates = viewStates.copy(isError = true)
            if (!viewStates.errorMessageList.contains(MyApp.CONTEXT.getString(R.string.MSG_ID_MB002099V))) {
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002099V)
                    )
                )
            }
        }
    }

    /**
     * 代表者エラーチェック
     */
    private fun checkRepresentativeBuildRoom(
        representative: Representative,
        representativeErrorInformation: RepresentativeErrorInformation
    ) {
        // ご自宅の建物が入力された場合、ご自宅の建物名カナも入力必要です
        if (representative.build.isBlank() && representative.buildKana.isNotBlank()) {
            representativeErrorInformation.buildErrorFlag = true
            viewStates = viewStates.copy(isError = true)
            if (!viewStates.errorMessageList.contains(
                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_build)
                        )
                )
            ) {
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                            MessageReplaceUtils.messageReplace(
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                MyApp.CONTEXT.getString(R.string.mbop0604_page_label_build)
                            )
                    )
                )
            }
        }

        // ご自宅の建物名が入力された場合、ご自宅の建物名カナも入力必要です
        if (representative.build.isNotBlank() && representative.buildKana.isBlank()) {
            representativeErrorInformation.buildKanaErrorFlag = true
            viewStates = viewStates.copy(isError = true)
            if (!viewStates.errorMessageList.contains(
                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_build_kana)
                        )
                )
            ) {
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                            MessageReplaceUtils.messageReplace(
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                MyApp.CONTEXT.getString(R.string.mbop0604_page_label_build_kana)
                            )
                    )
                )
            }
        }

        // ご自宅の建物名が入力された場合、全角
        if (representative.build.isNotBlank() && !representative.build.isPersonNameOther()) {
            representativeErrorInformation.buildErrorFlag = true
            viewStates = viewStates.copy(isError = true)
            if (!viewStates.errorMessageList.contains(
                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_build)
                        )
                )
            ) {
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                            MessageReplaceUtils.messageReplace(
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                                MyApp.CONTEXT.getString(R.string.mbop0604_page_label_build)
                            )
                    )
                )
            }
        }

        // ご自宅の建物名/号室（半角カナ）が入力された場合、全角
        if (representative.buildKana.isNotBlank() && !representative.buildKana.isPersonNameKanaOther()) {
            representativeErrorInformation.buildKanaErrorFlag = true
            viewStates = viewStates.copy(isError = true)
            if (!viewStates.errorMessageList.contains(
                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002032V),
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_build_kana)
                        )
                )
            ) {
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                            MessageReplaceUtils.messageReplace(
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002032V),
                                MyApp.CONTEXT.getString(R.string.mbop0604_page_label_build_kana)
                            )
                    )
                )
            }
        }

        //-------------------------room

        // 建物名/号室カナが入力された場合、建物名/号室も入力必要です
        if (representative.roomKana.isBlank() && representative.room.isNotBlank()) {
            representativeErrorInformation.roomKanaErrorFlag = true
            viewStates = viewStates.copy(isError = true)
            if (!viewStates.errorMessageList.contains(
                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_room_kana)
                        )
                )
            ) {
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                            MessageReplaceUtils.messageReplace(
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                MyApp.CONTEXT.getString(R.string.mbop0604_page_label_room_kana)
                            )
                    )
                )
            }
        }

        // ご自宅の建物名/号室が入力された場合、ご自宅の建物名/号室カナも入力必要です
        if (representative.room.isBlank() && representative.roomKana.isNotBlank()) {
            representativeErrorInformation.roomErrorFlag = true
            viewStates = viewStates.copy(isError = true)
            if (!viewStates.errorMessageList.contains(
                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_room)
                        )
                )
            ) {
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                            MessageReplaceUtils.messageReplace(
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                                MyApp.CONTEXT.getString(R.string.mbop0604_page_label_room)
                            )
                    )
                )
            }
        }

        // ご自宅の建物名/号室が入力された場合、全角
        if (representative.room.isNotBlank() && !representative.room.isPersonNameOther()) {
            representativeErrorInformation.roomErrorFlag = true
            viewStates = viewStates.copy(isError = true)
            if (!viewStates.errorMessageList.contains(
                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_room)
                        )
                )
            ) {
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                            MessageReplaceUtils.messageReplace(
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                                MyApp.CONTEXT.getString(R.string.mbop0604_page_label_room)
                            )
                    )
                )
            }
        }

        // ご自宅の建物名/号室（半角カナ）が入力された場合、全角
        if (representative.roomKana.isNotBlank() && !representative.roomKana.isPersonNameKanaOther()) {
            representativeErrorInformation.roomKanaErrorFlag = true
            viewStates = viewStates.copy(isError = true)
            if (!viewStates.errorMessageList.contains(
                    MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002032V),
                            MyApp.CONTEXT.getString(R.string.mbop0604_page_label_room_kana)
                        )
                )
            ) {
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MyApp.CONTEXT.getString(R.string.mbop0604_page_label_representative_error) +
                            MessageReplaceUtils.messageReplace(
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002032V),
                                MyApp.CONTEXT.getString(R.string.mbop0604_page_label_room_kana)
                            )
                    )
                )
            }
        }

        if (checkBuildRoom(representative.build, representative.room)) {
            representativeErrorInformation.buildErrorFlag = true
            representativeErrorInformation.roomErrorFlag = true
            viewStates = viewStates.copy(isError = true)
            if (!viewStates.errorMessageList.contains(MyApp.CONTEXT.getString(R.string.MSG_ID_MB002098V))) {
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002098V)
                    )
                )
            }
        }

        if (checkBuildRoomKana(representative.buildKana, representative.roomKana)) {
            representativeErrorInformation.buildKanaErrorFlag = true
            representativeErrorInformation.roomKanaErrorFlag = true
            viewStates = viewStates.copy(isError = true)
            if (!viewStates.errorMessageList.contains(MyApp.CONTEXT.getString(R.string.MSG_ID_MB002099V))) {
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002099V)
                    )
                )
            }
        }

    }

    /**
     * 代表者・役員 番地カナ更新
     */
    fun updateRepresentativeHomeAddressKana(index: Int, homeAddress: String, representative: Representative) {
        val newRepresentative = representative.copy()
        newRepresentative.homeAddressHalf = fullToHalfChar(homeAddress)
        val representativeList = viewStates.representativeList.toMutableList()
        representativeList[index] = newRepresentative
        viewStates = viewStates.copy(representativeList = representativeList)
    }

    /**
     * 実質的支配者 番地カナ更新
     */
    fun updateBeneficialOwnerHomeAddressKana(index: Int, homeAddress: String, beneficialOwner: BeneficialOwner) {
        val newBeneficialOwner = beneficialOwner.copy()
        newBeneficialOwner.beneficialOwnerHomeAddressHalf = fullToHalfChar(homeAddress)
        val beneficialOwnerList = viewStates.beneficialOwnerList.toMutableList()
        beneficialOwnerList[index] = newBeneficialOwner
        viewStates = viewStates.copy(beneficialOwnerList = beneficialOwnerList)
    }

    /**
     * 代表者・役員 号室カナ更新
     */
    fun updateRepresentativeRoomKana(index: Int, room: String, representative: Representative) {
        val newRepresentative = representative.copy()
        newRepresentative.roomKana = fullToHalfChar(room)
        val representativeList = viewStates.representativeList.toMutableList()
        representativeList[index] = newRepresentative
        viewStates = viewStates.copy(representativeList = representativeList)
    }

    /**
     * 実質的支配者 号室カナ更新
     */
    fun updateBeneficialOwnerRoomKana(index: Int, room: String, beneficialOwner: BeneficialOwner) {
        val newBeneficialOwner = beneficialOwner.copy()
        newBeneficialOwner.beneficialOwnerRoomKana = fullToHalfChar(room)
        val beneficialOwnerList = viewStates.beneficialOwnerList.toMutableList()
        beneficialOwnerList[index] = newBeneficialOwner
        viewStates = viewStates.copy(beneficialOwnerList = beneficialOwnerList)
    }


    fun set0706() {
        // Realm情報更新
        val accountOpeningAB0706 = dbService.findAll(AccountOpeningAB0706::class.java)
        var customerInformation = CorporationBean()
        if (accountOpeningAB0706.isNotEmpty()) {
            customerInformation =
                accountOpeningAB0706[0]?.customerInformation?.fromJson<CorporationBean>()!!
        }
        customerInformation.ceoOfficer = mutableListOf()
        viewStates.representativeList.forEach { representative ->
            val ceoOfficer = CeoOfficer()
            ceoOfficer.position = representative.jobTitle
            ceoOfficer.officerKanjiLastName = representative.firstName
            ceoOfficer.officerKanjiFirstName = representative.secondName
            ceoOfficer.officerLastName = representative.firstKanaName
            ceoOfficer.officerFirstName = representative.secondKanaName
            ceoOfficer.officerBirthday =
                dateAddHyphen(representative.year, representative.month, representative.day)
            ceoOfficer.officerZipCode = representative.postCode
            ceoOfficer.officerPrefecture = representative.homePrefecture
            ceoOfficer.officerCity = representative.homeCity
            ceoOfficer.officerStreet = representative.chome
            ceoOfficer.officerAddress = representative.homeAddress
            ceoOfficer.officerBuilding = concatBuildRoomDb(representative.build, representative.room)
            ceoOfficer.officerPrefectureKana = representative.homePrefectureKana
            ceoOfficer.officerCityKana = representative.homeCityKana
            ceoOfficer.officerStreetKana = representative.chomeKana
            ceoOfficer.officerAddressKana = representative.homeAddressHalf
            ceoOfficer.officerBuildingKana = concatBuildRoomKanaDb(representative.buildKana, representative.roomKana)
            ceoOfficer.officerPhoneType = representative.phoneType
            ceoOfficer.officerPhoneNumOneFirst = representative.phoneFirst
            ceoOfficer.officerPhoneNumOneMid = representative.phoneSecond
            ceoOfficer.officerPhoneNumOneLast = representative.phoneThird
            customerInformation.ceoOfficer.add(ceoOfficer)
        }

        customerInformation.substantialRuler = mutableListOf()
        viewStates.beneficialOwnerList.forEach { beneficialOwner ->
            val substantialRuler = SubstantialRuler()
            substantialRuler.rulerKanjiLastName =
                beneficialOwner.beneficialOwnerFirstName
            substantialRuler.rulerKanjiFirstName =
                beneficialOwner.beneficialOwnerSecondName
            substantialRuler.rulerLastName =
                beneficialOwner.beneficialOwnerFirstKanaName
            substantialRuler.rulerFirstName =
                beneficialOwner.beneficialOwnerSecondKanaName
            substantialRuler.rulerBirthday = dateAddHyphen(
                beneficialOwner.beneficialOwnerYear,
                beneficialOwner.beneficialOwnerMonth,
                beneficialOwner.beneficialOwnerDay
            )
            substantialRuler.rulerZipCode = beneficialOwner.beneficialOwnerPostCode
            substantialRuler.rulerPrefecture = beneficialOwner.beneficialOwnerHomePrefecture
            substantialRuler.rulerCity = beneficialOwner.beneficialOwnerHomeCity
            substantialRuler.rulerStreet = beneficialOwner.beneficialOwnerChome
            substantialRuler.rulerAddress = beneficialOwner.beneficialOwnerHomeAddress
            substantialRuler.rulerBuilding =
                concatBuildRoomDb(beneficialOwner.beneficialOwnerBuild, beneficialOwner.beneficialOwnerRoom)
            substantialRuler.rulerPrefectureKana =
                beneficialOwner.beneficialOwnerHomePrefectureKana
            substantialRuler.rulerCityKana =
                beneficialOwner.beneficialOwnerHomeCityKana
            substantialRuler.rulerStreetKana =
                beneficialOwner.beneficialOwnerChomeKana
            substantialRuler.rulerAddressKana = beneficialOwner.beneficialOwnerHomeAddressHalf
            substantialRuler.rulerBuildingKana =
                concatBuildRoomKanaDb(beneficialOwner.beneficialOwnerBuildKana, beneficialOwner.beneficialOwnerRoomKana)

            // 2025/01/29 共同化ため実質的支配者の電話番号　start
            substantialRuler.rulerPhoneType =
                beneficialOwner.phoneType
            substantialRuler.rulerPhoneNumFirst =
                beneficialOwner.phoneFirst
            substantialRuler.rulerPhoneNumMid =
                beneficialOwner.phoneSecond
            substantialRuler.rulerPhoneNumLast = beneficialOwner.phoneThird
            // 2025/01/29 共同化ため実質的支配者の電話番号　end
            customerInformation.substantialRuler.add(substantialRuler)
        }
        dbService.deleteAll(AccountOpeningAB0706::class.java)
        val ab0706 = AccountOpeningAB0706()
        ab0706.id = UUID.randomUUID().toString()
        ab0706.customerInformation = customerInformation.toJson()
        dbService.create(ab0706)
    }

    /**
     * ご役職の切替
     */
    fun onJobTitleChange(jobTitle: CodeBean, index: Int, representative: Representative) {
        if (jobTitle.code == JobTitle.CEO.code) {
            viewStates.representativeList.forEach { item ->
                if (item.jobTitle == JobTitle.CEO.code) {
                    viewStates = viewStates.copy(
                        delegateDialog = true
                    )
                    return
                }
            }
        }

        val newRepresentative = representative.copy()
        newRepresentative.jobTitle = jobTitle.code
        newRepresentative.jobTitleLabel = jobTitle.value
        val representativeList = viewStates.representativeList.toMutableList()
        representativeList[index] = newRepresentative
        viewStates = viewStates.copy(
            representativeList = representativeList
        )
    }

    /**
     * 郵便番号の自動検索
     */
    fun postInfoSearch(index: Int, representative: Representative) {
        // エラー情報初期化
        viewStates.representativeErrorBeanList[index].postCodeErrorFlag = false
        viewStates = viewStates.copy(isError = false)
        viewStates = viewStates.copy(errorMessageList = listOf())
        val representativeErrorBeanList = viewStates.representativeErrorBeanList.toMutableList()

        // 郵便番号が空白場合
        if (representative.postCode.isBlank() ||
            !EditCheckUtil.lengthCheck(representative.postCode, 7)
        ) {
            viewStates.representativeErrorBeanList[index].postCodeErrorFlag = true
            viewStates = viewStates.copy(isError = true)
            if (!viewStates.errorMessageList.contains(
                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002003V)
                )
            ) {
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002003V)
                    )
                )
            }
            return
        }
        representativeErrorBeanList[index] = viewStates.representativeErrorBeanList[index]
        viewStates = viewStates.copy(representativeErrorBeanList = representativeErrorBeanList)
        // ・都道府県・市区町村・丁目・都道府県（半角カナ）・市区町村（半角カナ）・丁目（半角）クリア
        cleanAddress(representative, index)
        viewModelScope.launch {
            val newRepresentative2 = representative.copy()
            val representativeList2 = viewStates.representativeList.toMutableList()

            val res: List<PostCodeResponseBean> = PostInfoSearchLogic(webService)
                .getPostInfo(PostCodeRequestBean(representative.postCode), "MBOP0604", "E08")

            // 住所漢字リスト
            val addressList: MutableList<CodeBean> = mutableListOf()

            // 住所漢字丁目なしリスト
            val addressNashiList: MutableList<CodeBean> = mutableListOf()

            // 住所カナリスト
            val addressKanaList: MutableList<CodeBean> = mutableListOf()

            // 住所カナ丁目なしリスト
            val addressKanaNashiList: MutableList<CodeBean> = mutableListOf()
            if (res.isNotEmpty()) {
                res.forEach { item ->
                    if (item.address.isNotBlank()) {
                        addressList.add(CodeBean(item.addressCode, item.address))
                        addressKanaList.add(CodeBean(item.addressCode, item.addressKana))
                    }
                    if (item.addressNashi.isNotBlank()) {
                        addressNashiList.add(CodeBean(item.addressCode, item.addressNashi))
                        addressKanaNashiList.add(CodeBean(item.addressCode, item.addressKanaNashi))
                    }
                }
                var candidateEnabled = true
                var candidateFlag = false
                var showFirstRecordFlag = false
                // 「丁目あり」が０件だった場合に、「丁目なし」のリストより市区町村項目に自動的に１項目を表示する。
                if (addressList.size == 0 || addressKanaList.size == 0) {
                    addressList.addAll(addressNashiList)
                    addressKanaList.addAll(addressKanaNashiList)
                    candidateEnabled = false
                    candidateFlag = true
                    showFirstRecordFlag = true
                }
                // 「丁目なし」が０件だった場合、チェックボックスのチェックができないようにする。
                if(addressNashiList.size == 0)
                {
                    candidateEnabled = false
                }
                // 郵便番号の自動検索により、以下の項目が自動反映されます。
                newRepresentative2.homePrefecture = if (res.isNotEmpty()) res[0].prefecture else ""
                newRepresentative2.homePrefectureKana = if (res.isNotEmpty()) res[0].prefectureKana else ""
                newRepresentative2.postData = res
                newRepresentative2.addressList = addressList
                newRepresentative2.addressNashiList = addressNashiList
                newRepresentative2.addressKanaList = addressKanaList
                newRepresentative2.addressKanaNashiList = addressKanaNashiList
                newRepresentative2.candidateEnabled = candidateEnabled
                newRepresentative2.candidateFlag = candidateFlag
                newRepresentative2.addressShowValue =
                    if (showFirstRecordFlag && addressList.size > 0) addressList[0].code else ""
                newRepresentative2.addressShowLabel =
                    if (showFirstRecordFlag && addressList.size > 0) addressList[0].value else ""
                newRepresentative2.addressKanaShowValue =
                    if (showFirstRecordFlag && addressKanaList.size > 0) addressKanaList[0].code else ""
                newRepresentative2.addressKanaShowLabel =
                    if (showFirstRecordFlag && addressKanaList.size > 0) addressKanaList[0].value else ""
                newRepresentative2.homeCity = res[0].city + res[0].addrDetail1
                newRepresentative2.chome =
                    if (newRepresentative2.candidateFlag) "" else res[0].addrDetail2
                newRepresentative2.homeCityKana = res[0].cityKana + res[0].addrdetail1Kana
                newRepresentative2.chomeKana = if (newRepresentative2.candidateFlag) "" else when {
                    // 丁目カラムに「ﾁｮｳﾒ」があれば、「-」に変換する
                    res[0].addrdetail2Kana.contains(
                        MyApp.CONTEXT.getString(R.string.common_label_chome_kana)
                    ) -> {
                        res[0].addrdetail2Kana.replace(
                            MyApp.CONTEXT.getString(R.string.common_label_chome_kana),
                            ""
                        )
                    }
                    else -> {
                        res[0].addrdetail2Kana
                    }
                }
                representativeList2[index] = newRepresentative2
                viewStates = viewStates.copy(
                    representativeList = representativeList2
                )
            }
        }
    }

    fun cleanAddress(
        representative: Representative,
        index: Int
    ) {
        val newRepresentative = representative.copy()
        val representativeList = viewStates.representativeList.toMutableList()
        newRepresentative.homePrefecture = ""
        newRepresentative.homePrefectureKana = ""
        newRepresentative.addressShowValue = ""
        newRepresentative.addressShowLabel = ""
        newRepresentative.addressKanaShowValue = ""
        newRepresentative.addressKanaShowLabel = ""
        newRepresentative.postData = listOf()
        newRepresentative.addressList = listOf()
        newRepresentative.addressNashiList = listOf()
        newRepresentative.addressKanaList = listOf()
        newRepresentative.addressKanaNashiList = listOf()
        newRepresentative.homeCity = ""
        newRepresentative.homeCityKana = ""
        newRepresentative.chome = ""
        newRepresentative.chomeKana = ""
        newRepresentative.candidateFlag = false
        newRepresentative.candidateEnabled = false
        representativeList[index] = newRepresentative
        viewStates = viewStates.copy(
            representativeList = representativeList
        )
    }

    /**
     * 実質的支配者郵便番号の自動検索
     */
    fun beneficialOwnerPostInfoSearch(index: Int, beneficialOwner: BeneficialOwner) {
        // エラー情報初期化
        viewStates.beneficialOwnerErrorBeanList[index].beneficialOwnerPostCodeErrorFlag = false
        viewStates = viewStates.copy(isError = false)
        viewStates = viewStates.copy(errorMessageList = listOf())
        val beneficialOwnerErrorBeanList = viewStates.beneficialOwnerErrorBeanList.toMutableList()

        // 郵便番号(実質的支配者)が空白場合
        if (beneficialOwner.beneficialOwnerPostCode.isBlank() ||
            !EditCheckUtil.lengthCheck(beneficialOwner.beneficialOwnerPostCode, 7)
        ) {
            viewStates.beneficialOwnerErrorBeanList[index].beneficialOwnerPostCodeErrorFlag = true
            viewStates = viewStates.copy(isError = true)
            if (!viewStates.errorMessageList.contains(
                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002003V)
                )
            ) {
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002003V)
                    )
                )
            }
        }
        viewStates = viewStates.copy(beneficialOwnerErrorBeanList = beneficialOwnerErrorBeanList)
        // ・都道府県・市区町村・丁目・都道府県（半角カナ）・市区町村（半角カナ）・丁目（半角）クリア
        cleanBeneficialOwnerAddress(beneficialOwner, index)
        viewModelScope.launch {
            val newBeneficialOwner2 = beneficialOwner.copy()
            val beneficialOwnerList2 = viewStates.beneficialOwnerList.toMutableList()

            val res: List<PostCodeResponseBean> = PostInfoSearchLogic(webService)
                .getPostInfo(PostCodeRequestBean(beneficialOwner.beneficialOwnerPostCode), "MBOP0604", "E08")
            // 住所漢字リスト
            val addressList: MutableList<CodeBean> = mutableListOf()

            // 住所漢字丁目なしリスト
            val addressNashiList: MutableList<CodeBean> = mutableListOf()

            // 住所カナリスト
            val addressKanaList: MutableList<CodeBean> = mutableListOf()

            // 住所カナ丁目なしリスト
            val addressKanaNashiList: MutableList<CodeBean> = mutableListOf()
            if (res.isNotEmpty()) {
                res.forEach { item ->
                    if (item.address.isNotBlank()) {
                        addressList.add(CodeBean(item.addressCode, item.address))
                        addressKanaList.add(CodeBean(item.addressCode, item.addressKana))
                    }
                    if (item.addressNashi.isNotBlank()) {
                        addressNashiList.add(CodeBean(item.addressCode, item.addressNashi))
                        addressKanaNashiList.add(CodeBean(item.addressCode, item.addressKanaNashi))
                    }
                }
                var candidateEnabled = true
                var candidateFlag = false
                var showFirstRecordFlag = false
                // 「丁目あり」が０件だった場合に、「丁目なし」のリストより市区町村項目に自動的に１項目を表示する。
                if (addressList.size == 0 || addressKanaList.size == 0) {
                    addressList.addAll(addressNashiList)
                    addressKanaList.addAll(addressKanaNashiList)
                    candidateEnabled = false
                    candidateFlag = true
                    showFirstRecordFlag = true
                }
                // 「丁目なし」が０件だった場合、チェックボックスのチェックができないようにする。
                if(addressNashiList.size == 0)
                {
                    candidateEnabled = false
                }
                // 郵便番号の自動検索により、以下の項目が自動反映されます。
                newBeneficialOwner2.beneficialOwnerHomePrefecture = if (res.isNotEmpty()) res[0].prefecture else ""
                newBeneficialOwner2.beneficialOwnerHomePrefectureKana =
                    if (res.isNotEmpty()) res[0].prefectureKana else ""
                newBeneficialOwner2.postData = res
                newBeneficialOwner2.addressList = addressList
                newBeneficialOwner2.addressNashiList = addressNashiList
                newBeneficialOwner2.addressKanaList = addressKanaList
                newBeneficialOwner2.addressKanaNashiList = addressKanaNashiList
                newBeneficialOwner2.candidateEnabled = candidateEnabled
                newBeneficialOwner2.candidateFlag = candidateFlag
                newBeneficialOwner2.addressShowValue =
                    if (showFirstRecordFlag && addressList.size > 0) addressList[0].code else ""
                newBeneficialOwner2.addressShowLabel =
                    if (showFirstRecordFlag && addressList.size > 0) addressList[0].value else ""
                newBeneficialOwner2.addressKanaShowValue =
                    if (showFirstRecordFlag && addressKanaList.size > 0) addressKanaList[0].code else ""
                newBeneficialOwner2.addressKanaShowLabel =
                    if (showFirstRecordFlag && addressKanaList.size > 0) addressKanaList[0].value else ""
                newBeneficialOwner2.beneficialOwnerHomeCity = res[0].city + res[0].addrDetail1
                newBeneficialOwner2.beneficialOwnerChome =
                    if (newBeneficialOwner2.candidateFlag) "" else res[0].addrDetail2
                newBeneficialOwner2.beneficialOwnerHomeCityKana = res[0].cityKana + res[0].addrdetail1Kana
                newBeneficialOwner2.beneficialOwnerChomeKana = if (newBeneficialOwner2.candidateFlag) "" else when {
                    // 丁目カラムに「ﾁｮｳﾒ」があれば、「-」に変換する
                    res[0].addrdetail2Kana.contains(
                        MyApp.CONTEXT.getString(R.string.common_label_chome_kana)
                    ) -> {
                        res[0].addrdetail2Kana.replace(
                            MyApp.CONTEXT.getString(R.string.common_label_chome_kana),
                            ""
                        )
                    }
                    else -> {
                        res[0].addrdetail2Kana
                    }
                }
                beneficialOwnerList2[index] = newBeneficialOwner2
                viewStates = viewStates.copy(
                    beneficialOwnerList = beneficialOwnerList2
                )
            }
        }
    }

    fun cleanBeneficialOwnerAddress(
        beneficialOwner: BeneficialOwner,
        index: Int
    ) {
        val newBeneficialOwner = beneficialOwner.copy()
        val beneficialOwnerList = viewStates.beneficialOwnerList.toMutableList()
        newBeneficialOwner.beneficialOwnerHomePrefecture = ""
        newBeneficialOwner.beneficialOwnerHomePrefectureKana = ""
        newBeneficialOwner.addressShowValue = ""
        newBeneficialOwner.addressShowLabel = ""
        newBeneficialOwner.addressKanaShowValue = ""
        newBeneficialOwner.addressKanaShowLabel = ""
        newBeneficialOwner.postData = listOf()
        newBeneficialOwner.addressList = listOf()
        newBeneficialOwner.addressNashiList = listOf()
        newBeneficialOwner.addressKanaList = listOf()
        newBeneficialOwner.addressKanaNashiList = listOf()
        newBeneficialOwner.beneficialOwnerHomeCity = ""
        newBeneficialOwner.beneficialOwnerHomeCityKana = ""
        newBeneficialOwner.beneficialOwnerChome = ""
        newBeneficialOwner.beneficialOwnerChomeKana = ""
        newBeneficialOwner.candidateFlag = false
        newBeneficialOwner.candidateEnabled = false
        beneficialOwnerList[index] = newBeneficialOwner
        viewStates = viewStates.copy(
            beneficialOwnerList = beneficialOwnerList
        )
    }

    /**
     * アドレスの切替
     */
    fun onBeneficialOwnerAddressShowChange(addressShow: CodeBean, index: Int, beneficialOwner: BeneficialOwner) {
        val newBeneficialOwner = beneficialOwner.copy()
        // 市区町村表示
        newBeneficialOwner.addressShowValue = addressShow.code
        newBeneficialOwner.addressShowLabel = addressShow.value

        if (newBeneficialOwner.addressShowValue.isNotBlank()) {
            // 市区町村カナ表示
            val addressKanaList = if (newBeneficialOwner.candidateFlag)
                newBeneficialOwner.addressKanaNashiList else newBeneficialOwner.addressKanaList
            val thisAddressKanaShow = addressKanaList.first { it.code == addressShow.code }
            newBeneficialOwner.addressKanaShowValue = thisAddressKanaShow.code
            newBeneficialOwner.addressKanaShowLabel = thisAddressKanaShow.value
            // 郵便情報
            if (newBeneficialOwner.postData.isNotEmpty()) {
                val thisPost = newBeneficialOwner.postData.first { it.addressCode == addressShow.code }
                newBeneficialOwner.beneficialOwnerHomeCity = thisPost.city + thisPost.addrDetail1
                newBeneficialOwner.beneficialOwnerChome =
                    if (newBeneficialOwner.candidateFlag) "" else thisPost.addrDetail2
                newBeneficialOwner.beneficialOwnerHomeCityKana = thisPost.cityKana + thisPost.addrdetail1Kana
                newBeneficialOwner.beneficialOwnerChomeKana = if (newBeneficialOwner.candidateFlag) "" else when {
                    // 丁目カラムに「ﾁｮｳﾒ」があれば、「-」に変換する
                    thisPost.addrdetail2Kana.contains(
                        MyApp.CONTEXT.getString(R.string.common_label_chome_kana)
                    ) -> {
                        thisPost.addrdetail2Kana.replace(
                            MyApp.CONTEXT.getString(R.string.common_label_chome_kana),
                            ""
                        )
                    }
                    else -> {
                        thisPost.addrdetail2Kana
                    }
                }
                val beneficialOwnerList = viewStates.beneficialOwnerList.toMutableList()
                beneficialOwnerList[index] = newBeneficialOwner
                viewStates = viewStates.copy(
                    beneficialOwnerList = beneficialOwnerList
                )
            }
        } else {
            newBeneficialOwner.addressKanaShowValue = ""
            newBeneficialOwner.addressKanaShowLabel = ""
            newBeneficialOwner.beneficialOwnerHomeCity = ""
            newBeneficialOwner.beneficialOwnerChome = ""
            newBeneficialOwner.beneficialOwnerHomeCityKana = ""
            newBeneficialOwner.beneficialOwnerChomeKana = ""
            val beneficialOwnerList = viewStates.beneficialOwnerList.toMutableList()
            beneficialOwnerList[index] = newBeneficialOwner
            viewStates = viewStates.copy(
                beneficialOwnerList = beneficialOwnerList
            )
        }
    }

    /**
     * 候補を表示するフラグ切替
     */
    fun onBeneficialOwnerCandidateFlagChange(index: Int, beneficialOwner: BeneficialOwner) {
        val newBeneficialOwner = beneficialOwner.copy()
        newBeneficialOwner.candidateFlag = !beneficialOwner.candidateFlag
        newBeneficialOwner.addressShowValue = ""
        newBeneficialOwner.addressShowLabel = ""
        newBeneficialOwner.addressKanaShowValue = ""
        newBeneficialOwner.addressKanaShowLabel = ""
        newBeneficialOwner.beneficialOwnerHomeCity = ""
        newBeneficialOwner.beneficialOwnerChome = ""
        newBeneficialOwner.beneficialOwnerHomeCityKana = ""
        newBeneficialOwner.beneficialOwnerChomeKana = ""
        val beneficialOwnerList = viewStates.beneficialOwnerList.toMutableList()
        beneficialOwnerList[index] = newBeneficialOwner
        viewStates = viewStates.copy(
            beneficialOwnerList = beneficialOwnerList
        )
    }

    /**
     * アドレスカナの切替
     */
    fun onBeneficialOwnerAddressKanaShowChange(
        addressKanaShow: CodeBean,
        index: Int,
        beneficialOwner: BeneficialOwner
    ) {
        val newBeneficialOwner = beneficialOwner.copy()
        // 市区町村カナ表示
        newBeneficialOwner.addressKanaShowValue = addressKanaShow.code
        newBeneficialOwner.addressKanaShowLabel = addressKanaShow.value

        if (newBeneficialOwner.addressKanaShowValue.isNotBlank()) {
            // 市区町村表示
            val addressList = if (newBeneficialOwner.candidateFlag)
                newBeneficialOwner.addressNashiList else newBeneficialOwner.addressList
            val thisAddressKanaShow = addressList.first { it.code == addressKanaShow.code }
            newBeneficialOwner.addressShowValue = thisAddressKanaShow.code
            newBeneficialOwner.addressShowLabel = thisAddressKanaShow.value

            // 郵便情報
            if (newBeneficialOwner.postData.isNotEmpty()) {
                val thisPost = newBeneficialOwner.postData.first { it.addressCode == addressKanaShow.code }
                newBeneficialOwner.beneficialOwnerHomeCity = thisPost.city + thisPost.addrDetail1
                newBeneficialOwner.beneficialOwnerChome =
                    if (newBeneficialOwner.candidateFlag) "" else thisPost.addrDetail2
                newBeneficialOwner.beneficialOwnerHomeCityKana = thisPost.cityKana + thisPost.addrdetail1Kana
                newBeneficialOwner.beneficialOwnerChomeKana = if (newBeneficialOwner.candidateFlag) "" else when {
                    // 丁目カラムに「ﾁｮｳﾒ」があれば、「-」に変換する
                    thisPost.addrdetail2Kana.contains(
                        MyApp.CONTEXT.getString(R.string.common_label_chome_kana)
                    ) -> {
                        thisPost.addrdetail2Kana.replace(
                            MyApp.CONTEXT.getString(R.string.common_label_chome_kana),
                            ""
                        )
                    }
                    else -> {
                        thisPost.addrdetail2Kana
                    }
                }
                val beneficialOwnerList = viewStates.beneficialOwnerList.toMutableList()
                beneficialOwnerList[index] = newBeneficialOwner
                viewStates = viewStates.copy(
                    beneficialOwnerList = beneficialOwnerList
                )
            }
        } else {
            newBeneficialOwner.addressKanaShowValue = ""
            newBeneficialOwner.addressKanaShowLabel = ""
            newBeneficialOwner.beneficialOwnerHomeCity = ""
            newBeneficialOwner.beneficialOwnerChome = ""
            newBeneficialOwner.beneficialOwnerHomeCityKana = ""
            newBeneficialOwner.beneficialOwnerChomeKana = ""
            val beneficialOwnerList = viewStates.beneficialOwnerList.toMutableList()
            beneficialOwnerList[index] = newBeneficialOwner
            viewStates = viewStates.copy(
                beneficialOwnerList = beneficialOwnerList
            )
        }
    }

    /**
     * アドレスの切替
     */
    fun onAddressShowChange(addressShow: CodeBean, index: Int, representative: Representative) {
        val newRepresentative = representative.copy()
        // 市区町村表示
        newRepresentative.addressShowValue = addressShow.code
        newRepresentative.addressShowLabel = addressShow.value

        if (newRepresentative.addressShowValue.isNotBlank()) {
            // 市区町村カナ表示
            val addressKanaList = if (newRepresentative.candidateFlag)
                newRepresentative.addressKanaNashiList else newRepresentative.addressKanaList
            val thisAddressKanaShow = addressKanaList.first { it.code == addressShow.code }
            newRepresentative.addressKanaShowValue = thisAddressKanaShow.code
            newRepresentative.addressKanaShowLabel = thisAddressKanaShow.value
            // 郵便情報
            if (newRepresentative.postData.isNotEmpty()) {
                val thisPost = newRepresentative.postData.first { it.addressCode == addressShow.code }
                newRepresentative.homeCity = thisPost.city + thisPost.addrDetail1
                newRepresentative.chome = if (newRepresentative.candidateFlag) "" else thisPost.addrDetail2
                newRepresentative.homeCityKana = thisPost.cityKana + thisPost.addrdetail1Kana
                newRepresentative.chomeKana = if (newRepresentative.candidateFlag) "" else when {
                    // 丁目カラムに「ﾁｮｳﾒ」があれば、「-」に変換する
                    thisPost.addrdetail2Kana.contains(
                        MyApp.CONTEXT.getString(R.string.common_label_chome_kana)
                    ) -> {
                        thisPost.addrdetail2Kana.replace(
                            MyApp.CONTEXT.getString(R.string.common_label_chome_kana),
                            ""
                        )
                    }
                    else -> {
                        thisPost.addrdetail2Kana
                    }
                }
                val representativeList = viewStates.representativeList.toMutableList()
                representativeList[index] = newRepresentative
                viewStates = viewStates.copy(
                    representativeList = representativeList
                )
            }
        } else {
            newRepresentative.addressKanaShowValue = ""
            newRepresentative.addressKanaShowLabel = ""
            newRepresentative.homeCity = ""
            newRepresentative.chome = ""
            newRepresentative.homeCityKana = ""
            newRepresentative.chomeKana = ""
            val representativeList = viewStates.representativeList.toMutableList()
            representativeList[index] = newRepresentative
            viewStates = viewStates.copy(
                representativeList = representativeList
            )
        }
    }

    /**
     * 候補を表示するフラグ切替
     */
    fun onCandidateFlagChange(index: Int, representative: Representative) {
        val newRepresentative = representative.copy()
        newRepresentative.candidateFlag = !newRepresentative.candidateFlag
        newRepresentative.addressShowValue = ""
        newRepresentative.addressShowLabel = ""
        newRepresentative.addressKanaShowValue = ""
        newRepresentative.addressKanaShowLabel = ""
        newRepresentative.homeCity = ""
        newRepresentative.chome = ""
        newRepresentative.homeCityKana = ""
        newRepresentative.chomeKana = ""
        val representativeList = viewStates.representativeList.toMutableList()
        representativeList[index] = newRepresentative
        viewStates = viewStates.copy(
            representativeList = representativeList
        )
    }

    /**
     * アドレスカナの切替
     */
    fun onAddressKanaShowChange(addressKanaShow: CodeBean, index: Int, representative: Representative) {
        val newRepresentative = representative.copy()
        // 市区町村カナ表示
        newRepresentative.addressKanaShowValue = addressKanaShow.code
        newRepresentative.addressKanaShowLabel = addressKanaShow.value

        if (newRepresentative.addressKanaShowValue.isNotBlank()) {
            // 市区町村表示
            val addressList = if (newRepresentative.candidateFlag)
                newRepresentative.addressNashiList else newRepresentative.addressList
            val thisAddressKanaShow = addressList.first { it.code == addressKanaShow.code }
            newRepresentative.addressShowValue = thisAddressKanaShow.code
            newRepresentative.addressShowLabel = thisAddressKanaShow.value

            // 郵便情報
            if (newRepresentative.postData.isNotEmpty()) {
                val thisPost = newRepresentative.postData.first { it.addressCode == addressKanaShow.code }
                newRepresentative.homeCity = thisPost.city + thisPost.addrDetail1
                newRepresentative.chome = if (newRepresentative.candidateFlag) "" else thisPost.addrDetail2
                newRepresentative.homeCityKana = thisPost.cityKana + thisPost.addrdetail1Kana
                newRepresentative.chomeKana = if (newRepresentative.candidateFlag) "" else when {
                    // 丁目カラムに「ﾁｮｳﾒ」があれば、「-」に変換する
                    thisPost.addrdetail2Kana.contains(
                        MyApp.CONTEXT.getString(R.string.common_label_chome_kana)
                    ) -> {
                        thisPost.addrdetail2Kana.replace(
                            MyApp.CONTEXT.getString(R.string.common_label_chome_kana),
                            ""
                        )
                    }
                    else -> {
                        thisPost.addrdetail2Kana
                    }
                }
                val representativeList = viewStates.representativeList.toMutableList()
                representativeList[index] = newRepresentative
                viewStates = viewStates.copy(
                    representativeList = representativeList
                )
            }
        } else {
            newRepresentative.addressKanaShowValue = ""
            newRepresentative.addressKanaShowLabel = ""
            newRepresentative.homeCity = ""
            newRepresentative.chome = ""
            newRepresentative.homeCityKana = ""
            newRepresentative.chomeKana = ""
            val representativeList = viewStates.representativeList.toMutableList()
            representativeList[index] = newRepresentative
            viewStates = viewStates.copy(
                representativeList = representativeList
            )
        }
    }

    /**
     * 代表者電話番号の切替
     */
    fun onPhoneTypeChange(phoneType: CodeBean, index: Int, representative: Representative) {
        val newRepresentative = representative.copy()
        newRepresentative.phoneType = phoneType.code
        newRepresentative.phoneTypeLabel = phoneType.value
        val representativeList = viewStates.representativeList.toMutableList()
        representativeList[index] = newRepresentative
        viewStates = viewStates.copy(
            representativeList = representativeList
        )
    }
    // 2025/01/29 共同化ため実質的支配者の電話番号　start
    /**
     * 実質的支配電話番号の切替
     */
    fun onPhoneTypeChangeBeneficialOwner(phoneType: CodeBean, index: Int, beneficialOwner: BeneficialOwner) {
        val newBeneficialOwner = beneficialOwner.copy()
        newBeneficialOwner.phoneType = phoneType.code
        newBeneficialOwner.phoneTypeLabel = phoneType.value
        val beneficialOwnerList = viewStates.beneficialOwnerList.toMutableList()
        beneficialOwnerList[index] = newBeneficialOwner
        viewStates = viewStates.copy(
            beneficialOwnerList = beneficialOwnerList
        )
    }
    // 2025/01/29 共同化ため実質的支配者の電話番号　end
    init {
        // Realm情報
        val accountOpeningAB0706 = dbService.findAll(AccountOpeningAB0706::class.java)
        if (accountOpeningAB0706.isNotEmpty()) {
            val customerInformation =
                accountOpeningAB0706[0]?.customerInformation?.fromJson<CorporationBean>()!!
            if (customerInformation.ceoOfficer.isNotEmpty()) {
                val representativeList = mutableListOf<Representative>()
                val representativeErrorBeanList = mutableListOf<RepresentativeErrorInformation>()
                customerInformation.ceoOfficer.forEach { ceoOfficer ->
                    val representative = Representative()
                    // 候補表示フラグの判定：丁目カラムに「丁目」があれば、候補に表示されない
                    var candidateFlag = false
                    if (ceoOfficer.officerCity.isNotBlank() &&
                        !ceoOfficer.officerStreet.contains(MyApp.CONTEXT.getString(R.string.common_label_chome))
                    ) {
                        candidateFlag = true
                    }
                    // 住所漢字リスト
                    val addressList: MutableList<CodeBean> = mutableListOf()
                    // 住所漢字丁目なしリスト
                    val addressNashiList: MutableList<CodeBean> = mutableListOf()
                    // 市区町村プルダウン作成
                    addressList.add(
                        CodeBean(
                            code = "1",
                            value = ceoOfficer.officerCity + ceoOfficer.officerStreet
                        )
                    )
                    addressNashiList.add(
                        CodeBean(
                            code = "1",
                            value = ceoOfficer.officerCity + ceoOfficer.officerStreet
                        )
                    )
                    // 住所カナリスト
                    val addressKanaList: MutableList<CodeBean> = mutableListOf()
                    // 住所カナ丁目なしリスト
                    val addressKanaNashiList: MutableList<CodeBean> = mutableListOf()
                    // 市区町村カナプルダウン作成
                    addressKanaList.add(
                        CodeBean(
                            code = "1",
                            value = ceoOfficer.officerCityKana + ceoOfficer.officerStreetKana
                        )
                    )
                    addressKanaNashiList.add(
                        CodeBean(
                            code = "1",
                            value = ceoOfficer.officerCityKana + ceoOfficer.officerStreetKana
                        )
                    )
                    representative.jobTitle = ceoOfficer.position
                    representative.jobTitleLabel = getJobTitleName(ceoOfficer.position)
                    representative.firstName = ceoOfficer.officerKanjiLastName
                    representative.secondName = ceoOfficer.officerKanjiFirstName
                    representative.firstKanaName = ceoOfficer.officerLastName
                    representative.secondKanaName = ceoOfficer.officerFirstName
                    var year = ""
                    var month = ""
                    var day = ""
                    val birthday = ceoOfficer.officerBirthday.split(HALF_HYPHEN)
                    if (ceoOfficer.officerBirthday.length > 2) {
                        year = birthday[0]
                        month = birthday[1]
                        day = birthday[2]
                    }

                    val buildRoom = splitBuildRoom(ceoOfficer.officerBuilding)
                    val buildRoomKana = splitBuildRoomKana(ceoOfficer.officerBuildingKana)

                    representative.year = year
                    representative.month = month
                    representative.day = day
                    representative.postCode = ceoOfficer.officerZipCode
                    representative.homePrefecture = ceoOfficer.officerPrefecture
                    representative.homeCity = ceoOfficer.officerCity
                    representative.chome = ceoOfficer.officerStreet
                    representative.homeAddress = ceoOfficer.officerAddress
                    representative.build = buildRoom.first
                    representative.room = buildRoom.second
                    representative.homePrefectureKana = ceoOfficer.officerPrefectureKana
                    representative.homeCityKana = ceoOfficer.officerCityKana
                    representative.chomeKana = ceoOfficer.officerStreetKana
                    representative.homeAddressHalf = ceoOfficer.officerAddressKana
                    representative.buildKana = buildRoomKana.first
                    representative.roomKana = buildRoomKana.second
                    representative.phoneType = ceoOfficer.officerPhoneType
                    representative.phoneTypeLabel = getPhoneTypeName(ceoOfficer.officerPhoneType)
                    representative.phoneFirst = ceoOfficer.officerPhoneNumOneFirst
                    representative.phoneSecond = ceoOfficer.officerPhoneNumOneMid
                    representative.phoneThird = ceoOfficer.officerPhoneNumOneLast
                    // 候補表示フラグ
                    representative.candidateFlag = candidateFlag
                    // 市区町村プルダウン
                    representative.addressList = addressList
                    representative.addressNashiList = addressNashiList
                    representative.addressShowValue = "1"
                    representative.addressShowLabel = ceoOfficer.officerCity + ceoOfficer.officerStreet
                    // 市区町村カナプルダウン
                    representative.addressKanaList = addressKanaList
                    representative.addressKanaNashiList = addressKanaNashiList
                    representative.addressKanaShowValue = "1"
                    representative.addressKanaShowLabel = ceoOfficer.officerCityKana + ceoOfficer.officerStreetKana
                    representative.candidateEnabled = false
                    representativeList.add(representative)
                    representativeErrorBeanList.add(RepresentativeErrorInformation())
                }
                viewStates = viewStates.copy(
                    representativeList = representativeList,
                    representativeErrorBeanList = representativeErrorBeanList,
                )
            }
            if (customerInformation.substantialRuler.isNotEmpty()) {
                val beneficialOwnerList = mutableListOf<BeneficialOwner>()
                val beneficialOwnerErrorBeanList = mutableListOf<BeneficialOwnerErrorInformation>()
                customerInformation.substantialRuler.forEach { substantialRuler ->
                    val beneficialOwner = BeneficialOwner()
                    // 候補表示フラグの判定：丁目カラムに「丁目」があれば、候補に表示されない
                    var candidateFlag = false
                    if (substantialRuler.rulerCity.isNotBlank() &&
                        !substantialRuler.rulerStreet.contains(MyApp.CONTEXT.getString(R.string.common_label_chome))
                    ) {
                        candidateFlag = true
                    }
                    // 住所漢字リスト
                    val addressList: MutableList<CodeBean> = mutableListOf()
                    // 住所漢字丁目なしリスト
                    val addressNashiList: MutableList<CodeBean> = mutableListOf()
                    // 市区町村プルダウン作成
                    addressList.add(
                        CodeBean(
                            code = "1",
                            value = substantialRuler.rulerCity + substantialRuler.rulerStreet
                        )
                    )
                    addressNashiList.add(
                        CodeBean(
                            code = "1",
                            value = substantialRuler.rulerCity + substantialRuler.rulerStreet
                        )
                    )
                    // 住所カナリスト
                    val addressKanaList: MutableList<CodeBean> = mutableListOf()
                    // 住所カナ丁目なしリスト
                    val addressKanaNashiList: MutableList<CodeBean> = mutableListOf()
                    // 市区町村カナプルダウン作成
                    addressKanaList.add(
                        CodeBean(
                            code = "1",
                            value = substantialRuler.rulerCityKana + substantialRuler.rulerStreetKana
                        )
                    )
                    addressKanaNashiList.add(
                        CodeBean(
                            code = "1",
                            value = substantialRuler.rulerCityKana + substantialRuler.rulerStreetKana
                        )
                    )
                    beneficialOwner.beneficialOwnerFirstName = substantialRuler.rulerKanjiLastName
                    beneficialOwner.beneficialOwnerSecondName = substantialRuler.rulerKanjiFirstName
                    beneficialOwner.beneficialOwnerFirstKanaName = substantialRuler.rulerLastName
                    beneficialOwner.beneficialOwnerSecondKanaName = substantialRuler.rulerFirstName
                    var year = ""
                    var month = ""
                    var day = ""
                    val birthday = substantialRuler.rulerBirthday.split(HALF_HYPHEN)
                    if (substantialRuler.rulerBirthday.length > 2) {
                        year = birthday[0]
                        month = birthday[1]
                        day = birthday[2]
                    }

                    val buildRoom = splitBuildRoom(substantialRuler.rulerBuilding)
                    val buildRoomKana = splitBuildRoomKana(substantialRuler.rulerBuildingKana)

                    beneficialOwner.beneficialOwnerYear = year
                    beneficialOwner.beneficialOwnerMonth = month
                    beneficialOwner.beneficialOwnerDay = day
                    beneficialOwner.beneficialOwnerPostCode = substantialRuler.rulerZipCode
                    beneficialOwner.beneficialOwnerHomePrefecture = substantialRuler.rulerPrefecture
                    beneficialOwner.beneficialOwnerHomeCity = substantialRuler.rulerCity
                    beneficialOwner.beneficialOwnerChome = substantialRuler.rulerStreet
                    beneficialOwner.beneficialOwnerHomeAddress = substantialRuler.rulerAddress.trimEnd()
                    beneficialOwner.beneficialOwnerBuild = buildRoom.first
                    beneficialOwner.beneficialOwnerRoom = buildRoom.second
                    beneficialOwner.beneficialOwnerHomePrefectureKana = substantialRuler.rulerPrefectureKana
                    beneficialOwner.beneficialOwnerHomeCityKana = substantialRuler.rulerCityKana
                    beneficialOwner.beneficialOwnerChomeKana = substantialRuler.rulerStreetKana
                    beneficialOwner.beneficialOwnerHomeAddressHalf = substantialRuler.rulerAddressKana.trimEnd()
                    beneficialOwner.beneficialOwnerBuildKana = buildRoomKana.first
                    beneficialOwner.beneficialOwnerRoomKana = buildRoomKana.second
                    // 候補表示フラグ
                    beneficialOwner.candidateFlag = candidateFlag
                    // 市区町村プルダウン
                    beneficialOwner.addressList = addressList
                    beneficialOwner.addressNashiList = addressNashiList
                    beneficialOwner.addressShowValue = "1"
                    beneficialOwner.addressShowLabel = substantialRuler.rulerCity + substantialRuler.rulerStreet
                    // 市区町村カナプルダウン
                    beneficialOwner.addressKanaList = addressKanaList
                    beneficialOwner.addressKanaNashiList = addressKanaNashiList
                    beneficialOwner.addressKanaShowValue = "1"
                    beneficialOwner.addressKanaShowLabel = substantialRuler.rulerCityKana +
                        substantialRuler.rulerStreetKana
                    beneficialOwner.candidateEnabled = false
                    beneficialOwnerList.add(beneficialOwner)
                    beneficialOwnerErrorBeanList.add(BeneficialOwnerErrorInformation())
                }
                viewStates = viewStates.copy(
                    beneficialOwnerList = beneficialOwnerList,
                    beneficialOwnerErrorBeanList = beneficialOwnerErrorBeanList
                )
            }
            if (customerInformation.ceoOfficer.isNullOrEmpty() &&
                customerInformation.substantialRuler.isNullOrEmpty()
            ) {
                var birthday = PreferenceUtil.getPreferenceStringValue(ConstUtil.EKYC_INFO_BIRTHDATE)
                birthday = birthday?.replace("年", "")
                    ?.replace("月", "")
                    ?.replace("日", "") ?: ""

                val representativeList = listOf(
                    if (birthday.isNotEmpty()) {
                        Representative(
                            firstName = PreferenceUtil
                                .getPreferenceStringValue(ConstUtil.EKYC_INFO_LAST_NAME).toString(),
                            secondName = PreferenceUtil
                                .getPreferenceStringValue(ConstUtil.EKYC_INFO_FIRST_NAME).toString(),
                            year = birthday.replace("-", "").substring(0, 4),
                            month = birthday.replace("-", "").substring(4, 6),
                            day = birthday.replace("-", "").substring(6, 8),
                            postCode = PreferenceUtil
                                .getPreferenceStringValue(ConstUtil.EKYC_INFO_POSTALCODE).toString(),
                            jobTitle = JobTitle.CEO.code,
                            jobTitleLabel = JobTitle.CEO.value
                        )
                    } else {
                        Representative(
                            firstName = PreferenceUtil
                                .getPreferenceStringValue(ConstUtil.EKYC_INFO_LAST_NAME).toString(),
                            secondName = PreferenceUtil
                                .getPreferenceStringValue(ConstUtil.EKYC_INFO_FIRST_NAME).toString(),
                            postCode = PreferenceUtil
                                .getPreferenceStringValue(ConstUtil.EKYC_INFO_POSTALCODE).toString(),
                            jobTitle = JobTitle.CEO.code,
                            jobTitleLabel = JobTitle.CEO.value
                        )
                    }
                )
                val beneficialOwnerList = listOf(
                    BeneficialOwner()
                )
                val representativeErrorBeanList = listOf(
                    RepresentativeErrorInformation()
                )
                val beneficialOwnerErrorBeanList = listOf(
                    BeneficialOwnerErrorInformation()
                )

                viewStates = viewStates.copy(
                    representativeList = representativeList,
                    beneficialOwnerList = beneficialOwnerList,
                    representativeErrorBeanList = representativeErrorBeanList,
                    beneficialOwnerErrorBeanList = beneficialOwnerErrorBeanList
                )
            }
        }
        // 復元
        getRestoreData()
    }

    fun doCopy() {
        val representative = viewStates.representativeList.stream()
            .filter { e -> e.jobTitle == JobTitle.CEO.code }.findFirst()

        if (representative.isPresent) {
            val newBeneficialOwner = viewStates.beneficialOwnerList[0].copy()
            newBeneficialOwner.beneficialOwnerFirstName = representative.get().firstName
            newBeneficialOwner.beneficialOwnerSecondName = representative.get().secondName
            newBeneficialOwner.beneficialOwnerFirstKanaName = representative.get().firstKanaName
            newBeneficialOwner.beneficialOwnerSecondKanaName = representative.get().secondKanaName
            newBeneficialOwner.beneficialOwnerYear = representative.get().year
            newBeneficialOwner.beneficialOwnerMonth = representative.get().month
            newBeneficialOwner.beneficialOwnerDay = representative.get().day
            newBeneficialOwner.beneficialOwnerPostCode = representative.get().postCode
            newBeneficialOwner.beneficialOwnerHomePrefecture = representative.get().homePrefecture
            newBeneficialOwner.beneficialOwnerHomeCity = representative.get().homeCity
            newBeneficialOwner.beneficialOwnerChome = representative.get().chome
            newBeneficialOwner.beneficialOwnerChomeLabel = representative.get().chomeLabel
            newBeneficialOwner.beneficialOwnerHomeAddress = representative.get().homeAddress
            newBeneficialOwner.beneficialOwnerBuild = representative.get().build
            newBeneficialOwner.beneficialOwnerRoom = representative.get().room
            newBeneficialOwner.beneficialOwnerHomePrefectureKana =
                representative.get().homePrefectureKana
            newBeneficialOwner.addressShowLabel = representative.get().addressShowLabel
            newBeneficialOwner.addressShowValue = representative.get().addressShowValue
            newBeneficialOwner.addressKanaShowLabel = representative.get().addressKanaShowLabel
            newBeneficialOwner.addressKanaShowValue = representative.get().addressKanaShowValue
            newBeneficialOwner.candidateFlag = representative.get().candidateFlag
            newBeneficialOwner.beneficialOwnerHomeCityKana = representative.get().homeCityKana
            newBeneficialOwner.beneficialOwnerChomeKana = representative.get().chomeKana
            newBeneficialOwner.beneficialOwnerChomeKanaLabel = representative.get().chomeKanaLabel
            newBeneficialOwner.beneficialOwnerHomeAddressHalf = representative.get().homeAddressHalf
            newBeneficialOwner.beneficialOwnerBuildKana = representative.get().buildKana
            newBeneficialOwner.beneficialOwnerRoomKana = representative.get().roomKana
            val beneficialOwnerList = viewStates.beneficialOwnerList.toMutableList()
            beneficialOwnerList[0] = newBeneficialOwner
            viewStates = viewStates.copy(
                beneficialOwnerList = beneficialOwnerList
            )
        }
    }

    fun addRepresentative(index: Int) {
        val newRepresentativeList = viewStates.representativeList.toMutableList()
        val representative = Representative()
        representative.phoneType = viewStates.representativeList[index].phoneType
        representative.phoneTypeLabel = viewStates.representativeList[index].phoneTypeLabel
        representative.phoneFirst = viewStates.representativeList[index].phoneFirst
        representative.phoneSecond = viewStates.representativeList[index].phoneSecond
        representative.phoneThird = viewStates.representativeList[index].phoneThird
        newRepresentativeList.add(representative)
        val newRepresentativeErrorBeanList = viewStates.representativeErrorBeanList.toMutableList()
        val representativeErrorInformation = RepresentativeErrorInformation()
        newRepresentativeErrorBeanList.add(representativeErrorInformation)
        viewStates = viewStates.copy(
            representativeList = newRepresentativeList,
            representativeErrorBeanList = newRepresentativeErrorBeanList,
            representativeOverDialog = index > 7
        )
    }

    fun removeRepresentative(index: Int) {
        val newRepresentativeList = viewStates.representativeList.toMutableList()
        newRepresentativeList.removeAt(index)
        val newRepresentativeErrorBeanList = viewStates.representativeErrorBeanList.toMutableList()
        newRepresentativeErrorBeanList.removeAt(index)
        viewStates = viewStates.copy(
            representativeList = newRepresentativeList,
            representativeErrorBeanList = newRepresentativeErrorBeanList,
            representativeOverDialog = false
        )
    }

    fun addBeneficialOwner(index: Int) {
        val newBeneficialOwnerList = viewStates.beneficialOwnerList.toMutableList()
        val beneficialOwner = BeneficialOwner()
        newBeneficialOwnerList.add(beneficialOwner)
        val newBeneficialOwnerErrorBeanList = viewStates.beneficialOwnerErrorBeanList.toMutableList()
        val beneficialOwnerErrorInformation = BeneficialOwnerErrorInformation()
        newBeneficialOwnerErrorBeanList.add(beneficialOwnerErrorInformation)
        viewStates = viewStates.copy(
            beneficialOwnerList = newBeneficialOwnerList,
            beneficialOwnerErrorBeanList = newBeneficialOwnerErrorBeanList,
            beneficialOwnerOverDialog = index > 1
        )
    }

    fun removeBeneficialOwner(index: Int) {
        val newBeneficialOwnerList = viewStates.beneficialOwnerList.toMutableList()
        newBeneficialOwnerList.removeAt(index)
        val newBeneficialOwnerErrorBeanList = viewStates.beneficialOwnerErrorBeanList.toMutableList()
        newBeneficialOwnerErrorBeanList.removeAt(index)
        viewStates = viewStates.copy(
            beneficialOwnerList = newBeneficialOwnerList,
            beneficialOwnerErrorBeanList = newBeneficialOwnerErrorBeanList,
            beneficialOwnerOverDialog = false
        )
    }

    fun closeDelegateDialog() {
        viewStates = viewStates.copy(delegateDialog = false)
    }

    // 復元データを取得する
    private fun getRestoreData() {
        val accountOpeningAB0701 = MyApp.INSTANCE.findAll(EPassBookAB0701::class.java)
        if (accountOpeningAB0701.isNotEmpty() && !MainActivity.HAS_RECOVERY_FLAG) {
            val corporation = accountOpeningAB0701[0]?.corporation?.fromJson<CorporationBean>()!!

            val representativeList = mutableListOf<Representative>()
            val beneficialOwnerList = mutableListOf<BeneficialOwner>()
            val representativeErrorBeanList = mutableListOf<RepresentativeErrorInformation>()
            val beneficialOwnerErrorBeanList = mutableListOf<BeneficialOwnerErrorInformation>()
            corporation.ceoOfficer.forEach { ceoOfficer ->
                val representative = Representative()

                val buildRoom = splitBuildRoom(ceoOfficer.officerBuilding)
                val buildRoomKana = splitBuildRoomKana(ceoOfficer.officerBuildingKana);

                representative.jobTitle = ceoOfficer.position
                representative.jobTitleLabel = getJobTitleName(ceoOfficer.position)
                representative.firstName = ceoOfficer.officerKanjiLastName
                representative.secondName = ceoOfficer.officerKanjiFirstName
                representative.firstKanaName = ceoOfficer.officerLastName
                representative.secondKanaName = ceoOfficer.officerFirstName
                representative.year = ceoOfficer.officerBirthday.replace("-", "").substring(0, 4)
                representative.month = ceoOfficer.officerBirthday.replace("-", "").substring(4, 6)
                representative.day = ceoOfficer.officerBirthday.replace("-", "").substring(6, 8)
                representative.postCode = ceoOfficer.officerZipCode
                representative.homePrefecture = ceoOfficer.officerPrefecture
                representative.homeCity = ceoOfficer.officerCity
                representative.chome = ceoOfficer.officerStreet
                representative.chomeLabel = Chome.getChomeName(ceoOfficer.officerStreet)
                representative.homeAddress = ceoOfficer.officerAddress.trimEnd()
                representative.room = buildRoom.first
                representative.room = buildRoom.second
                representative.homePrefectureKana = ceoOfficer.officerPrefectureKana
                representative.homeCityKana = ceoOfficer.officerCityKana
                representative.chomeKana = ceoOfficer.officerStreetKana.replace(HALF_HYPHEN, "")
                representative.chomeKanaLabel = ChomeHalf.getChomeHalfName(ceoOfficer.officerStreetKana)
                representative.homeAddressHalf = ceoOfficer.officerAddressKana.trimEnd()
                representative.roomKana = buildRoomKana.first
                representative.roomKana = buildRoom.second
                representative.phoneType = ceoOfficer.officerPhoneType
                representative.phoneTypeLabel = getPhoneTypeName(ceoOfficer.officerPhoneType)
                representative.phoneFirst = ceoOfficer.officerPhoneNumOneFirst
                representative.phoneSecond = ceoOfficer.officerPhoneNumOneMid
                representative.phoneThird = ceoOfficer.officerPhoneNumOneLast
                representative.candidateEnabled = false
                representativeList.add(representative)
                representativeErrorBeanList.add(RepresentativeErrorInformation())
            }
            corporation.substantialRuler.forEach { substantialRuler ->
                val beneficialOwner = BeneficialOwner()

                val buildRoom = splitBuildRoom(substantialRuler.rulerBuilding)
                val buildRoomKana = splitBuildRoomKana(substantialRuler.rulerBuildingKana)

                beneficialOwner.beneficialOwnerFirstName = substantialRuler.rulerKanjiLastName
                beneficialOwner.beneficialOwnerSecondName = substantialRuler.rulerKanjiFirstName
                beneficialOwner.beneficialOwnerFirstKanaName = substantialRuler.rulerLastName
                beneficialOwner.beneficialOwnerSecondKanaName = substantialRuler.rulerFirstName
                beneficialOwner.beneficialOwnerYear =
                    substantialRuler.rulerBirthday.replace("-", "").substring(0, 4)
                beneficialOwner.beneficialOwnerMonth =
                    substantialRuler.rulerBirthday.replace("-", "").substring(4, 6)
                beneficialOwner.beneficialOwnerDay =
                    substantialRuler.rulerBirthday.replace("-", "").substring(6, 8)
                beneficialOwner.beneficialOwnerPostCode = substantialRuler.rulerZipCode
                beneficialOwner.beneficialOwnerHomePrefecture = substantialRuler.rulerPrefecture
                beneficialOwner.beneficialOwnerHomeCity = substantialRuler.rulerCity
                beneficialOwner.beneficialOwnerChome = substantialRuler.rulerStreet.replace(HALF_HYPHEN, "")
                beneficialOwner.beneficialOwnerChomeLabel = Chome.getChomeName(substantialRuler.rulerStreet)
                beneficialOwner.beneficialOwnerHomeAddress = substantialRuler.rulerAddress
                beneficialOwner.beneficialOwnerBuild = buildRoom.first
                beneficialOwner.beneficialOwnerRoom = buildRoom.second
                beneficialOwner.beneficialOwnerHomePrefectureKana = substantialRuler.rulerPrefectureKana
                beneficialOwner.beneficialOwnerHomeCityKana = substantialRuler.rulerCityKana
                beneficialOwner.beneficialOwnerChomeKana = substantialRuler.rulerStreetKana
                beneficialOwner.beneficialOwnerChomeKanaLabel =
                    ChomeHalf.getChomeHalfName(substantialRuler.rulerStreetKana)
                beneficialOwner.beneficialOwnerHomeAddressHalf = substantialRuler.rulerAddressKana
                beneficialOwner.beneficialOwnerBuildKana = buildRoomKana.first
                beneficialOwner.beneficialOwnerRoomKana = buildRoomKana.second
                beneficialOwner.candidateEnabled = false
                beneficialOwnerList.add(beneficialOwner)
                beneficialOwnerErrorBeanList.add(BeneficialOwnerErrorInformation())
            }
            viewStates = viewStates.copy(
                representativeList = representativeList,
                beneficialOwnerList = beneficialOwnerList,
                representativeErrorBeanList = representativeErrorBeanList,
                beneficialOwnerErrorBeanList = beneficialOwnerErrorBeanList
            )

            // 復元処理済みフラグ
            MainActivity.HAS_RECOVERY_FLAG = true
            MainActivity.SHOW_RETURN_BUTTON_FLAG = true
        }
    }
}

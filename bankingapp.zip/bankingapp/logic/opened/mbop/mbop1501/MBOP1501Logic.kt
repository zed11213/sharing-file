package jp.co.jsbank.mb.bankingapp.logic.opened.mbop.mbop1501

import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import jp.co.jsbank.mb.bankingapp.bean.opened.mbop.mbop1401.MBOP1401RequestBean
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop1501.MBOP1501PageState
import jp.co.jsbank.mb.bankingapp.utils.*
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.PERSONALITY_FLAG
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.RECEIPT_NUMBER
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * MBOP1501ロジック
 */
@HiltViewModel
class MBOP1501Logic @Inject constructor(
    private var webService: RestService
) : ViewModel() {

    /**
     * MBOP1501ステータス
     */
    var viewStates by mutableStateOf(MBOP1501PageState())
        private set

    /**
     * 画像クリア
     */
    fun doClear(type: String) {
        when (type) {
            "1" -> viewStates = viewStates.copy(identificationDocumentSurface = mutableStateOf(null))
            "2" -> viewStates = viewStates.copy(identificationDocumentBack = mutableStateOf(null))
        }
    }

    /**
     * 画像設定
     */
    fun doSet(result: Any?) {
        when (viewStates.focusIndex) {
            "1" -> {
                viewStates = viewStates.copy(identificationDocumentSurface = mutableStateOf(result))
            }
            "2" -> {
                viewStates = viewStates.copy(identificationDocumentBack = mutableStateOf(result))
            }
        }
    }

    /**
     * 画像設定Bitmap
     */
    fun doSetBitmap(result: Bitmap?) {
        when (viewStates.focusIndex) {
            "1" -> {
                viewStates = viewStates.copy(
                    identificationDocumentSurfaceBitmap = mutableStateOf(result),
                    identificationDocumentSurfaceUri = mutableStateOf(null)
                )
            }
            "2" -> {
                viewStates = viewStates.copy(
                    identificationDocumentBackBitmap = mutableStateOf(result),
                    identificationDocumentBackUri = mutableStateOf(null)
                )
            }
        }
    }

    /**
     * 画像設定Uri
     */
    fun doSetUri(result: Uri?) {
        when (viewStates.focusIndex) {
            "1" -> {
                viewStates = viewStates.copy(
                    identificationDocumentSurfaceBitmap = mutableStateOf(null),
                    identificationDocumentSurfaceUri = mutableStateOf(result)
                )
            }
            "2" -> {
                viewStates = viewStates.copy(
                    identificationDocumentBackBitmap = mutableStateOf(null),
                    identificationDocumentBackUri = mutableStateOf(result)
                )
            }
        }
    }

    /**
     * フォーカスリセット
     */
    fun resetFocusIndex(focusIndex: String) {
        viewStates = viewStates.copy(focusIndex = focusIndex)
    }

    /**
     * 次への処理
     */
    fun doNext() {
        viewStates = viewStates.copy(errorMessage = "")
        // 代表者本人確認書類の必須チェック
        if (viewStates.identificationDocumentSurface.value == null ||
            viewStates.identificationDocumentBack.value == null
        ) {
            viewStates = viewStates.copy(errorMessage = "代表者本人確認書類を添付してください。")
            return
        }
        // 画面IDとイベントID設定
        PreferenceUtil.setScreenIDAndEventID("MBOP1501", "E02")
        // リクエストボディ編集
        val requestBean = MBOP1401RequestBean()
        // 人格区分
        requestBean.personType = PreferenceUtil.getPreferenceStringValue(PERSONALITY_FLAG).toString()
        // 受付番号
        requestBean.receiptNumber = KeyStoreUtil().getFromKeyStore(RECEIPT_NUMBER)
        // ファイルリスト
//        // 代表者本人確認書類（表面）
//        requestBean.fileStreams.add(
//            FileInfo(
//                documentsType = DocumentType.IDENTIFICATION_DOCUMENT_SURFACE.code,
//                fileName = DocumentType.IDENTIFICATION_DOCUMENT_SURFACE.value + LocalDateTime.now()
//                    .toInstant(ZoneOffset.UTC).toEpochMilli().toString() + JPEG,
//                fileStream = if (viewStates.identificationDocumentSurfaceBitmap.value != null)
//                    CommonKeyAESUtil().encrypt(
//                        bitmapToBase64(viewStates.identificationDocumentSurfaceBitmap.value!!),
//                        commonKey
//                    )
//                else
//                    CommonKeyAESUtil().encrypt(
//                        uriToBase64(viewStates.identificationDocumentSurfaceUri.value!!),
//                        commonKey
//                    )
//            ),
//        )
//        // 代表者本人確認書類（裏面）
//        requestBean.fileStreams.add(
//            FileInfo(
//                documentsType = DocumentType.IDENTIFICATION_DOCUMENT_BACK.code,
//                fileName = DocumentType.IDENTIFICATION_DOCUMENT_BACK.value + LocalDateTime.now()
//                    .toInstant(ZoneOffset.UTC).toEpochMilli().toString() + JPEG,
//                fileStream = if (viewStates.identificationDocumentBackBitmap.value != null)
//                    CommonKeyAESUtil().encrypt(
//                        bitmapToBase64(viewStates.identificationDocumentBackBitmap.value!!),
//                        commonKey
//                    )
//                else
//                    CommonKeyAESUtil().encrypt(
//                        uriToBase64(viewStates.identificationDocumentBackUri.value!!),
//                        commonKey
//                    )
//            ),
//        )
        // AB0702 ICOSへ本人確認書類格納を呼び出す
        viewModelScope.launch {
            flow {
                ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_PUT, requestBean.toJson())
                emit(webService.AB0702())
            }.map {
                // ステップ3画面へ遷移する
                RouteUtil.navTo(
                    RouteName.MBOP0203Page,
                )
            }.catch {
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }
    }
}

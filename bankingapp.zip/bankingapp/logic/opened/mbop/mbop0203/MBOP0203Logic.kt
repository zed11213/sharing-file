package jp.co.jsbank.mb.bankingapp.logic.opened.mbop.mbop0203

import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import jp.co.jsbank.mb.bankingapp.system.master.PersonalityFlag
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.utils.*
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.PERSONALITY_FLAG

/**
 * MBOP0203ロジック
 */
@HiltViewModel
class MBOP0203Logic @Inject constructor() : ViewModel() {

    /**
     * 口座開設申込内容を照会する
     */
    fun inquireIntoApplication() {
        // 人格区分
        when (PreferenceUtil.getPreferenceStringValue(PERSONALITY_FLAG).toString()) {
            PersonalityFlag.INDIVIDUAL_OTHER.code -> {
                // 個人の場合、MBOP0601　情報入力へ遷移する
                RouteUtil.navTo(
                    RouteName.MBOP0601Page
                )
            }
            PersonalityFlag.CORPORATION.code -> {
                // 法人の場合、お客様情報入力（法人(1/3)）へ遷移する
                RouteUtil.navTo(
                    RouteName.MBOP0603Page
                )
            }
            PersonalityFlag.INDIVIDUAL_BUSINESS.code -> {
                // 個人事業主の場合、お客様情報入力（個人事業主(1/2)）へ遷移する
                RouteUtil.navTo(
                    RouteName.MBOP0606Page
                )
            }
        }
    }
}

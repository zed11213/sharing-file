package jp.co.jsbank.mb.bankingapp.logic.opened.mbop.mbop0603

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import io.realm.Realm
import java.util.*
import javax.inject.Inject
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.bean.common.CodeBean
import jp.co.jsbank.mb.bankingapp.bean.common.CorporationBean
import jp.co.jsbank.mb.bankingapp.bean.opened.mbop.mbop0601.MBOP0601RequestBean
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.repositories.db.common.create
import jp.co.jsbank.mb.bankingapp.repositories.db.common.deleteAll
import jp.co.jsbank.mb.bankingapp.repositories.db.common.findAll
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.AccountOpeningAB0706
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.EPassBookAB0701
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.system.MyApp
import jp.co.jsbank.mb.bankingapp.system.master.CompanyForm
import jp.co.jsbank.mb.bankingapp.system.master.CompanyForm.Companion.getCompanyFormName
import jp.co.jsbank.mb.bankingapp.system.master.CompanyFormLocation.Companion.getCompanyFormLocationName
import jp.co.jsbank.mb.bankingapp.system.master.Phone
import jp.co.jsbank.mb.bankingapp.system.master.Phone.Companion.getPhoneTypeName
import jp.co.jsbank.mb.bankingapp.system.master.UpdateType
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0603.MBOP0603ErrorInformation
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0603.MBOP0603PageState
import jp.co.jsbank.mb.bankingapp.utils.*
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.OPENED_EDIT_INFO_FLAG
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.PERSONALITY_FLAG
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.RECEIPT_NUMBER
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isFixedTelePhone
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isHalfNum
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isIPTelePhone
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isMobilePhone
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isPersonNameKanaOther
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isPersonNameOther
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isPhone
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/**
 * MBOP0603ロジック
 */
@HiltViewModel
class MBOP0603Logic @Inject constructor(
    private var webService: RestService
) : ViewModel() {

    /**
     * ログインステータス
     */
    var viewStates by mutableStateOf(MBOP0603PageState())
        private set

    /**
     * ロカールDB
     */
    private var dbService: Realm = MyApp.INSTANCE

    /**
     * 初期化
     */
    init {
        val accountOpeningAB0706 = dbService.findAll(AccountOpeningAB0706::class.java)
        if (accountOpeningAB0706.isNotEmpty()) {
            val customerInformation = accountOpeningAB0706[0]?.customerInformation?.fromJson<CorporationBean>()!!
            var year = ""
            var month = ""
            var day = ""
            val birthday = customerInformation.establishDate.split(ConstUtil.HALF_HYPHEN)
            if (customerInformation.establishDate.length > 2) {
                year = birthday[0]
                month = birthday[1]
                day = birthday[2]
            }
            viewStates = viewStates.copy(
                companyForm = customerInformation.companyForm.ifBlank { CompanyForm.CORPORATION.code },
                companyFormLabel = if (customerInformation.companyForm.isNotBlank())
                    getCompanyFormName(customerInformation.companyForm) else CompanyForm.CORPORATION.value,
                other = customerInformation.companyFormOther,
                companyFormPosition = customerInformation.companyFormLocation,
                companyFormPositionLabel = getCompanyFormLocationName(customerInformation.companyFormLocation),
                businessName = customerInformation.businessNameKanji,
                businessNameKana = customerInformation.businessNameKana,
                year = year,
                month = month,
                day = day,
                capital = customerInformation.capital,
                employeesNumber = customerInformation.numberOfEmployees,
                phoneType = customerInformation.businessPhoneType,
                phoneTypeLabel = getPhoneTypeName(customerInformation.businessPhoneType),
                phoneFirst = customerInformation.businessPhoneNumFirst,
                phoneSecond = customerInformation.businessPhoneNumMid,
                phoneThird = customerInformation.businessPhoneNumLast,
            )
        }

        // 復元
        getRestoreData()
    }

    // 復元データを取得する
    private fun getRestoreData() {
        val accountOpeningAB0701 = MyApp.INSTANCE.findAll(EPassBookAB0701::class.java)
        if (accountOpeningAB0701.isNotEmpty() && !MainActivity.HAS_RECOVERY_FLAG) {
            val corporation = accountOpeningAB0701[0]?.corporation?.fromJson<CorporationBean>()!!
            viewStates = viewStates.copy(
                // 会社形態
                companyForm = corporation.companyForm,
                // 会社形態
                companyFormLabel = getCompanyFormName(corporation.companyForm),
                // 会社形態（その他 ）
                other = corporation.companyFormOther,
                // 会社形態位置
                companyFormPosition = corporation.companyFormLocation,
                // 会社形態位置
                companyFormPositionLabel = getCompanyFormLocationName(corporation.companyFormLocation),
                // 事業先名（漢字）
                businessName = corporation.businessNameKanji,
                // 事業先名（半角カナ）
                businessNameKana = corporation.businessNameKana,
                // 年
                year = corporation.establishDate.replace("-", "").substring(0, 4),
                // 月
                month = corporation.establishDate.replace("-", "").substring(4, 6),
                // 日
                day = corporation.establishDate.replace("-", "").substring(6, 8),
                // 資本金
                capital = corporation.capital,
                // 従業員人数
                employeesNumber = corporation.numberOfEmployees,
                // 事業先電話番号種別
                phoneType = corporation.businessPhoneType,
                // 事業先電話番号種別
                phoneTypeLabel = getPhoneTypeName(corporation.businessPhoneType),
                // 事業先電話番号（上）
                phoneFirst = corporation.businessPhoneNumFirst,
                // 事業先電話番号（中）
                phoneSecond = corporation.businessPhoneNumMid,
                // 事業先電話番号（下）
                phoneThird = corporation.businessPhoneNumLast,
            )

            // 復元処理済みフラグ
            MainActivity.HAS_RECOVERY_FLAG = true
            MainActivity.SHOW_RETURN_BUTTON_FLAG = true
        }
    }

    /**
     * エラーチェック
     */
    fun doNext() {
        // エラー情報初期化
        val errorBean = MBOP0603ErrorInformation()
        viewStates = viewStates.copy(isError = false)
        viewStates = viewStates.copy(errorMessageList = listOf())
        viewStates = viewStates.copy(errorBean = errorBean)

        // 会社形態が空白場合
        if (viewStates.companyForm.isBlank()) {
            errorBean.companyFormErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                        MyApp.CONTEXT.getString(R.string.mbop0603_page_label_company_form)
                    )
                )
            )
        }

        if (viewStates.companyForm == CompanyForm.OTHERS.code) {
            // その他が空白場合
            if (viewStates.other.isBlank()) {
                errorBean.otherErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0603_page_label_other)
                        )
                    )
                )
            } else if (!viewStates.other.isPersonNameOther()) {
                // その他の全角チェック
                errorBean.otherErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                            MyApp.CONTEXT.getString(R.string.mbop0603_page_label_other)
                        )
                    )
                )
            }
        }

        // 会社形態位置が空白場合
        if (viewStates.companyFormPosition.isBlank()) {
            errorBean.companyFormPositionErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                        MyApp.CONTEXT.getString(R.string.mbop0603_page_label_company_form_position)
                    )
                )
            )
        }

        // 事業先名が空白場合
        if (viewStates.businessName.isBlank()) {
            errorBean.businessNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0603_page_label_business_name)
                    )
                )
            )
        } else if (!viewStates.businessName.isPersonNameOther()) {
            // 事業先名の全角カナチェック
            errorBean.businessNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                        MyApp.CONTEXT.getString(R.string.mbop0603_page_label_business_name)
                    )
                )
            )
        }

        // 事業先名（半角カナ）が空白場合
        if (viewStates.businessNameKana.isBlank()) {
            errorBean.businessNameKanaErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0603_page_label_business_name_kana)
                    )
                )
            )
        } else if (!viewStates.businessNameKana.isPersonNameKanaOther()) {
            // 事業先名（半角カナ）の全角カナチェック
            errorBean.businessNameKanaErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002032V),
                        MyApp.CONTEXT.getString(R.string.mbop0603_page_label_business_name_kana)
                    )
                )
            )// 2025/01/30 同化ため 名前の桁数変更 start
        } else if (viewStates.businessNameKana.length > 20) {
            // 事業先名（半角カナ）桁数は20を超える場合
            errorBean.businessNameKanaErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002036V),
                        MyApp.CONTEXT.getString(R.string.mbop0603_page_label_business_name_kana)
                    )
                )
            )
        }
       // 2025/01/30 同化ため 名前の桁数変更 end
        // 年が空白場合
        if (viewStates.year.isBlank()) {
            errorBean.yearErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002014V),
                        MyApp.CONTEXT.getString(R.string.common_message_replace_label_setYear)
                    )
                )
            )
        } else if (!EditCheckUtil.lengthCheck(viewStates.year, 4)) {
            errorBean.yearErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002006V)
                )
            )
        }

        // 月が空白場合
        if (viewStates.month.isBlank()) {
            errorBean.monthErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002014V),
                        MyApp.CONTEXT.getString(R.string.common_message_replace_label_setMonth)
                    )
                )
            )
        }

        // 日が空白場合
        if (viewStates.day.isBlank()) {
            errorBean.dayErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002014V),
                        MyApp.CONTEXT.getString(R.string.common_message_replace_label_setDay)
                    )
                )
            )
        }

        // 生年月日チェック
        if (viewStates.year.isNotBlank() &&
            viewStates.month.isNotBlank() &&
            viewStates.day.isNotBlank()
        ) {
            if (!EditCheckUtil.isDayCheck(
                    viewStates.year,
                    viewStates.month,
                    viewStates.day
                )
            ) {
                errorBean.yearErrorFlag = true
                errorBean.monthErrorFlag = true
                errorBean.dayErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002007V),
                            MyApp.CONTEXT.getString(R.string.mbop0603_page_label_established_date)
                        )
                    )
                )
            } else // 未来日チェック
                if (EditCheckUtil.isFutureDays(
                        viewStates.year + viewStates.month + viewStates.day
                    )
                ) {
                    errorBean.yearErrorFlag = true
                    errorBean.monthErrorFlag = true
                    errorBean.dayErrorFlag = true
                    viewStates = viewStates.copy(errorBean = errorBean)
                    viewStates = viewStates.copy(isError = true)
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MessageReplaceUtils.messageReplace(
                                MyApp.CONTEXT.getString(R.string.MSG_ID_MB002007V),
                                MyApp.CONTEXT.getString(R.string.mbop0603_page_label_established_date)
                            )
                        )
                    )
                }
        }

        // 資本金が空白場合
        if (viewStates.capital.isBlank()) {
            errorBean.capitalErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0603_page_label_capital)
                    )
                )
            )
        } else if (!viewStates.capital.isHalfNum()) {
            errorBean.capitalErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                        MyApp.CONTEXT.getString(R.string.mbop0603_page_label_capital)
                    )
                )
            )
        }

        // 従業員人数が空白場合
        if (viewStates.employeesNumber.isBlank()) {
            errorBean.employeesNumberErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0603_page_label_employees_number)
                    )
                )
            )
        } else if (!viewStates.employeesNumber.isHalfNum()) {
            errorBean.employeesNumberErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                        MyApp.CONTEXT.getString(R.string.mbop0603_page_label_employees_number)
                    )
                )
            )
        } else if (viewStates.employeesNumber == "0") {
            errorBean.employeesNumberErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0603_page_label_employees_number)
                    )
                )
            )
        }

        // 事業先電話番号が空白場合
        if (viewStates.phoneType.isBlank()) {
            errorBean.phoneTypeErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                        MyApp.CONTEXT.getString(R.string.mbop0603_page_label_phone_type)
                    )
                )
            )
        }

        // 事業先電話番号が空白場合
        if (viewStates.phoneFirst.isBlank()) {
            errorBean.phoneFirstErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0603_page_label_phone)
                    )
                )
            )
        } else if (!viewStates.phoneFirst.isHalfNum()) {
            errorBean.phoneFirstErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                        MyApp.CONTEXT.getString(R.string.mbop0603_page_label_phone)
                    )
                )
            )
        }

        // 事業先電話番号が空白場合
        if (viewStates.phoneSecond.isBlank()) {
            errorBean.phoneSecondErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            if (!viewStates.errorMessageList.contains(
                    MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0603_page_label_phone)
                        )
                )
            ) {
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0603_page_label_phone)
                        )
                    )
                )
            }
        } else if (!viewStates.phoneSecond.isHalfNum()) {
            errorBean.phoneSecondErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            if (!viewStates.errorMessageList.contains(
                    MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                            MyApp.CONTEXT.getString(R.string.mbop0603_page_label_phone)
                        )
                )
            ) {
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                            MyApp.CONTEXT.getString(R.string.mbop0603_page_label_phone)
                        )
                    )
                )
            }
        }

        // 事業先電話番号が空白場合
        if (viewStates.phoneThird.isBlank()) {
            errorBean.phoneThirdErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            if (!viewStates.errorMessageList.contains(
                    MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0603_page_label_phone)
                        )
                )
            ) {
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                            MyApp.CONTEXT.getString(R.string.mbop0603_page_label_phone)
                        )
                    )
                )
            }
        } else if (!viewStates.phoneThird.isHalfNum()) {
            errorBean.phoneThirdErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            if (!viewStates.errorMessageList.contains(
                    MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                            MyApp.CONTEXT.getString(R.string.mbop0603_page_label_phone)
                        )
                )
            ) {
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                            MyApp.CONTEXT.getString(R.string.mbop0603_page_label_phone)
                        )
                    )
                )
            }
        }

        if (viewStates.phoneFirst.isNotBlank() && viewStates.phoneSecond.isNotBlank() &&
            viewStates.phoneThird.isNotBlank()
        ) {
            val phone =
                viewStates.phoneFirst + ConstUtil.HALF_HYPHEN + viewStates.phoneSecond +
                    ConstUtil.HALF_HYPHEN + viewStates.phoneThird
            if (viewStates.phoneType == Phone.FIXED_TELEPHONE.code && !(
                phone.isFixedTelePhone() && phone.isPhone(
                        Phone.FIXED_TELEPHONE.code,
                        phone
                    )
                )
            ) {
                errorBean.phoneFirstErrorFlag = true
                errorBean.phoneSecondErrorFlag = true
                errorBean.phoneThirdErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(MyApp.CONTEXT.getString(R.string.MSG_ID_MB002020V))) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002020V)
                        )
                    )
                }
            } else if (viewStates.phoneType == Phone.MOBILE_PHONE.code && !(
                phone.isMobilePhone() && phone.isPhone(
                        Phone.MOBILE_PHONE.code,
                        phone
                    )
                )
            ) {
                errorBean.phoneFirstErrorFlag = true
                errorBean.phoneSecondErrorFlag = true
                errorBean.phoneThirdErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(MyApp.CONTEXT.getString(R.string.MSG_ID_MB002019V))) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002019V)
                        )
                    )
                }// 2025/02/06 共同化ため電話番号の登録・表示 start
            } else if (viewStates.phoneType == Phone.IP_PHONE.code && !(
                    phone.isIPTelePhone() && phone.isPhone(
                        Phone.IP_PHONE.code,
                        phone
                    )
                    )
            ) {
                errorBean.phoneFirstErrorFlag = true
                errorBean.phoneSecondErrorFlag = true
                errorBean.phoneThirdErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                if (!viewStates.errorMessageList.contains(MyApp.CONTEXT.getString(R.string.MSG_ID_MB002034V))) {
                    viewStates = viewStates.copy(
                        errorMessageList = viewStates.errorMessageList.plus(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002034V)
                        )
                    )
                }
            }
            // 2025/02/06 共同化ため電話番号の登録・表示 end
        }

        if (!viewStates.isError) {
            // 口座開設申込情報（法人）
            val corporation = CorporationBean(
                // 受付番号
                receiptNumber = KeyStoreUtil().getFromKeyStore(RECEIPT_NUMBER),
                companyForm = viewStates.companyForm,
                companyFormOther = viewStates.other,
                companyFormLocation = viewStates.companyFormPosition,
                businessNameKanji = viewStates.businessName,
                businessNameKana = viewStates.businessNameKana,
                establishDate = dateAddHyphen(viewStates.year, viewStates.month, viewStates.day),
                capital = viewStates.capital,
                numberOfEmployees = viewStates.employeesNumber,
                businessPhoneType = viewStates.phoneType,
                businessPhoneNumFirst = viewStates.phoneFirst,
                businessPhoneNumMid = viewStates.phoneSecond,
                businessPhoneNumLast = viewStates.phoneThird,
                pageId = "MBOP0603"
            )
            viewStates = viewStates.copy(serverErrorMessage = "")
            // 画面IDとイベントID設定
            PreferenceUtil.setScreenIDAndEventID("MBOP0603", "E02")
            // リクエストボディ編集
            val requestBean = MBOP0601RequestBean()
            // 人格区分
            requestBean.personType = PreferenceUtil.getPreferenceStringValue(PERSONALITY_FLAG).toString()
            // 受付番号
            requestBean.receiptNumber = KeyStoreUtil().getFromKeyStore(RECEIPT_NUMBER)
            // 口座開設申込情報（法人）
            requestBean.corporationDto = corporation
            // 更新パターン
            requestBean.updateType = UpdateType.UPDATE_TYPE_014.code

            // お客様情報入力
            viewModelScope.launch {
                flow {
                    ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, requestBean.convertToParams().toJson())
                    emit(webService.AB0706())
                }.map {
                    set0706()
                    if (PreferenceUtil.getPreferenceBooleanValue(OPENED_EDIT_INFO_FLAG)) {
                        PreferenceUtil.setPreferenceBooleanValue(OPENED_EDIT_INFO_FLAG, false)
                        RouteUtil.navTo(
                            RouteName.MBOP1003Page
                        )
                    } else {
                        PreferenceUtil.setPreferenceBooleanValue(OPENED_EDIT_INFO_FLAG, false)
                        RouteUtil.navTo(
                            RouteName.MBOP0604Page,
                        )
                    }
                }.catch {
                    ErrorUtil().apiErrorCatch(it.message.toString())
                }
                    .collect()
            }
        }
    }

    fun set0706() {
        // Realm情報更新
        val accountOpeningAB0706 = dbService.findAll(AccountOpeningAB0706::class.java)
        var customerInformation = CorporationBean()
        if (accountOpeningAB0706.isNotEmpty()) {
            customerInformation =
                accountOpeningAB0706[0]?.customerInformation?.fromJson<CorporationBean>()!!
        }
        customerInformation.companyForm = viewStates.companyForm
        customerInformation.companyFormOther = viewStates.other
        customerInformation.companyFormLocation = viewStates.companyFormPosition
        customerInformation.businessNameKanji = viewStates.businessName
        customerInformation.businessNameKana = viewStates.businessNameKana
        customerInformation.establishDate = dateAddHyphen(viewStates.year, viewStates.month, viewStates.day)
        customerInformation.capital = viewStates.capital
        customerInformation.numberOfEmployees = viewStates.employeesNumber
        customerInformation.businessPhoneType = viewStates.phoneType
        customerInformation.businessPhoneNumFirst = viewStates.phoneFirst
        customerInformation.businessPhoneNumMid = viewStates.phoneSecond
        customerInformation.businessPhoneNumLast = viewStates.phoneThird
        dbService.deleteAll(AccountOpeningAB0706::class.java)
        val ab0706 = AccountOpeningAB0706()
        ab0706.id = UUID.randomUUID().toString()
        ab0706.customerInformation = customerInformation.toJson()
        dbService.create(ab0706)
    }

    /**
     * 会社形態の切替
     */
    fun onCompanyFormChange(companyForm: CodeBean) {
        viewStates = viewStates.copy(companyForm = companyForm.code, companyFormLabel = companyForm.value)
        if (companyForm.code != CompanyForm.OTHERS.code) viewStates = viewStates.copy(other = "")
    }

    /**
     * 会社形態位置
     */
    fun onCompanyFormPositionChange(companyFormPosition: CodeBean) {
        viewStates = viewStates.copy(
            companyFormPosition = companyFormPosition.code,
            companyFormPositionLabel = companyFormPosition.value
        )
    }

    /**
     * 事業先電話番号
     */
    fun onPhoneTypeChange(phoneType: CodeBean) {
        viewStates = viewStates.copy(
            phoneType = phoneType.code,
            phoneTypeLabel = phoneType.value
        )
    }
}

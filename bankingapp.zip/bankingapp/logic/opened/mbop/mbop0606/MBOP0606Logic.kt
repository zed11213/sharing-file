package jp.co.jsbank.mb.bankingapp.logic.opened.mbop.mbop0606

import android.annotation.SuppressLint
import androidx.compose.foundation.ScrollState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import io.realm.Realm
import java.util.*
import javax.inject.Inject
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.bean.common.SoleProprietorBean
import jp.co.jsbank.mb.bankingapp.bean.opened.mbop.mbop0601.MBOP0601RequestBean
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.repositories.db.common.create
import jp.co.jsbank.mb.bankingapp.repositories.db.common.deleteAll
import jp.co.jsbank.mb.bankingapp.repositories.db.common.findAll
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.AccountOpeningAB0706
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.EPassBookAB0701
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.system.MyApp
import asia.liquidinc.ekyc.applicant.external.result.chip.Sex
import jp.co.jsbank.mb.bankingapp.system.master.SexType
import jp.co.jsbank.mb.bankingapp.system.master.UpdateType
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0606.MBOP0606ErrorInformation
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbop.mbop0606.MBOP0606PageState
import jp.co.jsbank.mb.bankingapp.utils.*
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.HALF_HYPHEN
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.PERSONALITY_FLAG
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.containsInvalidCharacter
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isHalfNum
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isPersonNameCharacters
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isPersonNameKana
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isPersonNameKanaOther
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isPersonNameOther
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/**
 * MBOP0606ロジック
 */
@HiltViewModel
class MBOP0606Logic @Inject constructor(
    private var webService: RestService
) : ViewModel() {

    /**
     * ログインステータス
     */
    var viewStates by mutableStateOf(MBOP0606PageState())
        private set

    /**
     * ロカールDB
     */
    private var dbService: Realm = MyApp.INSTANCE

    /**
     * 初期化
     */
    init {
        val accountOpeningAB0706 = dbService.findAll(AccountOpeningAB0706::class.java)
        if (accountOpeningAB0706.isNotEmpty()) {
            val customerInformation = accountOpeningAB0706[0]?.customerInformation?.fromJson<SoleProprietorBean>()!!
            var year = ""
            var month = ""
            var day = ""
            val birthday = customerInformation.birthday.split(HALF_HYPHEN)
            if (customerInformation.birthday.length > 2) {
                year = birthday[0]
                month = birthday[1]
                day = birthday[2]
            }
            viewStates = viewStates.copy(
                firstName = customerInformation.customerKanjiLastName,
                secondName = customerInformation.customerKanjiFirstName,
                firstKanaName = customerInformation.customerLastName,
                secondKanaName = customerInformation.customerFirstName,
                sex = customerInformation.gender,
                storeName = customerInformation.roomNo,
                storeNameKana = customerInformation.roomNoKana,
                employeesNumber = customerInformation.numberOfEmployees,
                year = year,
                month = month,
                day = day,
            )
        } else {
            var birthday = PreferenceUtil.getPreferenceStringValue(ConstUtil.EKYC_INFO_BIRTHDATE)
            birthday = birthday?.replace("年", "")
                ?.replace("月", "")
                ?.replace("日", "") ?: ""
            val cleanBirthday = birthday.replace("-", "")
            val ekycGender = PreferenceUtil.getPreferenceStringValue(ConstUtil.EKYC_INFO_GENDER).toString()
            val sex = when (ekycGender) {
                Sex.MALE.name -> SexType.MAN.code
                Sex.FEMALE.name -> SexType.WOMAN.code
                else -> SexType.UN_KNOW.code
            }
            if (cleanBirthday.length >= 8) {
                viewStates = viewStates.copy(
                    firstName = PreferenceUtil.getPreferenceStringValue(ConstUtil.EKYC_INFO_LAST_NAME).toString(),
                    secondName = PreferenceUtil.getPreferenceStringValue(ConstUtil.EKYC_INFO_FIRST_NAME).toString(),
                    sex = sex,
                    year = cleanBirthday.substring(0, 4),
                    month = cleanBirthday.substring(4, 6),
                    day = cleanBirthday.substring(6, 8),
                )
            }
        }

        // 復元データを取得する
        getRestoreData()
    }

    // 復元データを取得する
    private fun getRestoreData() {
        val accountOpeningAB0701 = MyApp.INSTANCE.findAll(EPassBookAB0701::class.java)
        if (accountOpeningAB0701.isNotEmpty() && !MainActivity.HAS_RECOVERY_FLAG) {
            val soleProprietorInfo = accountOpeningAB0701[0]?.soleProprietor?.fromJson<SoleProprietorBean>()!!
            val cleanBirthday = soleProprietorInfo.birthday.replace("-", "")
            viewStates = viewStates.copy(
                // 姓
                firstName = if (soleProprietorInfo.customerKanjiLastName.isNotBlank()) soleProprietorInfo.customerKanjiLastName else viewStates.firstName,
                // 名前
                secondName = if (soleProprietorInfo.customerKanjiFirstName.isNotBlank()) soleProprietorInfo.customerKanjiFirstName else viewStates.secondName,
                // セイ
                firstKanaName = if (soleProprietorInfo.customerLastName.isNotBlank()) soleProprietorInfo.customerLastName else viewStates.firstKanaName,
                // メイ
                secondKanaName = if (soleProprietorInfo.customerFirstName.isNotBlank()) soleProprietorInfo.customerFirstName else viewStates.secondKanaName,
                // 性別
                sex = if (soleProprietorInfo.gender.isNotBlank()) soleProprietorInfo.gender else viewStates.sex,
                // 屋号
                storeName = if (soleProprietorInfo.roomNo.isNotBlank()) soleProprietorInfo.roomNo else viewStates.storeName,
                // 屋号（半角カナ）
                storeNameKana = if (soleProprietorInfo.roomNoKana.isNotBlank()) soleProprietorInfo.roomNoKana else viewStates.storeNameKana,
                // 従業員人数
                employeesNumber = if (soleProprietorInfo.numberOfEmployees.isNotBlank()) soleProprietorInfo.numberOfEmployees else viewStates.employeesNumber,
                // 年
                year = if (cleanBirthday.length >= 4) cleanBirthday.substring(0, 4) else viewStates.year,
                // 月
                month = if (cleanBirthday.length >= 6) cleanBirthday.substring(4, 6) else viewStates.month,
                // 日
                day = if (cleanBirthday.length >= 8) cleanBirthday.substring(6, 8) else viewStates.day,
            )

            // 復元処理済みフラグ
            MainActivity.HAS_RECOVERY_FLAG = true
            MainActivity.SHOW_RETURN_BUTTON_FLAG = true
        }
    }

    // エラーチェック
    @SuppressLint("WeekBasedYear")
    fun doNext(coroutineScope: CoroutineScope, scrollState: ScrollState) {
        // エラー情報初期化
        val errorBean = MBOP0606ErrorInformation()
        viewStates = viewStates.copy(isError = false)
        viewStates = viewStates.copy(errorBean = errorBean)
        viewStates = viewStates.copy(errorMessageList = listOf())

        // 姓が空白場合
        if (viewStates.firstName.isBlank()) {
            errorBean.firstNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0606_page_label_firstName)
                    )
                )
            )
        } else if (!viewStates.firstName.isPersonNameCharacters()) {
            errorBean.firstNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                        MyApp.CONTEXT.getString(R.string.mbop0606_page_label_firstName)
                    )
                )
            )
        }

        if (containsInvalidCharacter(viewStates.firstName)) {
            errorBean.firstNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002015V)
                )
            )
        }

        // 名前が空白場合
        if (viewStates.secondName.isBlank()) {
            errorBean.secondNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0606_page_label_secondName)
                    )
                )
            )
        } else if (!viewStates.secondName.isPersonNameCharacters()) {
            errorBean.secondNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                        MyApp.CONTEXT.getString(R.string.mbop0606_page_label_secondName)
                    )
                )
            )
        }

        if (containsInvalidCharacter(viewStates.secondName)) {
            errorBean.secondNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002015V)
                )
            )
        }

        // セイが空白場合
        if (viewStates.firstKanaName.isBlank()) {
            errorBean.firstKanaNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0606_page_label_kana_firstName)
                    )
                )
            )
        } else if (!viewStates.firstKanaName.isPersonNameKana()) {
            // セイ（半角カナ）の全角カナチェック
            errorBean.firstKanaNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002031V),
                        MyApp.CONTEXT.getString(R.string.mbop0606_page_label_kana_firstName)
                    )
                )
            )
        }

        // メイが空白場合
        if (viewStates.secondKanaName.isBlank()) {
            errorBean.secondKanaNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0606_page_label_kana_secondName)
                    )
                )
            )
        } else if (!viewStates.secondKanaName.isPersonNameKana()) {
            // メイ（半角カナ）の全角カナチェック
            errorBean.secondKanaNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002031V),
                        MyApp.CONTEXT.getString(R.string.mbop0606_page_label_kana_secondName)
                    )
                )
            )
        }

        // 性別
        if (viewStates.sex.isEmpty()) {
            errorBean.sexErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002022V),
                        MyApp.CONTEXT.getString(R.string.mbop0606_page_label_sex)
                    )
                )
            )
        }

        // 屋号が空白場合
        if (viewStates.storeName.isBlank()) {
            errorBean.storeNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0606_page_label_store_name)
                    )
                )
            )
        } else if (!viewStates.storeName.isPersonNameOther()) {
            // 屋号の全角チェック
            errorBean.storeNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002011V),
                        MyApp.CONTEXT.getString(R.string.mbop0606_page_label_store_name_kana)
                    )
                )
            )
        }

        // 屋号（半角カナ）が空白場合
        if (viewStates.storeNameKana.isBlank()) {
            errorBean.storeNameKanaErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0606_page_label_store_name_kana)
                    )
                )
            )
        } else if (!viewStates.storeNameKana.isPersonNameKanaOther()) {
            // 屋号（半角カナ）の全角カナチェック
            errorBean.storeNameKanaErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002032V),
                        MyApp.CONTEXT.getString(R.string.mbop0606_page_label_store_name_kana)
                    )
                )
            )
        }

        // 従業員人数が空白場合
        if (viewStates.employeesNumber.isBlank()) {
            errorBean.employeesNumberErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0606_page_label_employees_number)
                    )
                )
            )
        } else if (!viewStates.employeesNumber.isHalfNum()) {
            errorBean.employeesNumberErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002012V),
                        MyApp.CONTEXT.getString(R.string.mbop0606_page_label_employees_number)
                    )
                )
            )
        } else if (viewStates.employeesNumber == "0") {
            errorBean.employeesNumberErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbop0606_page_label_employees_number)
                    )
                )
            )
        }

        // 年が空白場合
        if (viewStates.year.isBlank()) {
            errorBean.yearErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002014V),
                        MyApp.CONTEXT.getString(R.string.common_message_replace_label_year)
                    )
                )
            )
        } else if (!EditCheckUtil.lengthCheck(viewStates.year, 4)) {
            errorBean.yearErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB002006V)
                )
            )
        }

        // 月が空白場合
        if (viewStates.month.isBlank()) {
            errorBean.monthErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002014V),
                        MyApp.CONTEXT.getString(R.string.common_message_replace_label_month)
                    )
                )
            )
        }

        // 日が空白場合
        if (viewStates.day.isBlank()) {
            errorBean.dayErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errorMessageList = viewStates.errorMessageList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002014V),
                        MyApp.CONTEXT.getString(R.string.common_message_replace_label_day)
                    )
                )
            )
        }

        // 年月日
        if (viewStates.year.isNotBlank() &&
            viewStates.month.isNotBlank() &&
            viewStates.day.isNotBlank()
        ) {
            if (!EditCheckUtil.isDayCheck(
                    viewStates.year,
                    viewStates.month,
                    viewStates.day
                )
            ) {
                errorBean.yearErrorFlag = true
                errorBean.monthErrorFlag = true
                errorBean.dayErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002007V),
                            MyApp.CONTEXT.getString(R.string.mbop0606_page_label_birthday)
                        )
                    )
                )
            }
            // 15歳未満チェック
            else if (LifeAge.getAgeByBirth(viewStates.year + HALF_HYPHEN + viewStates.month + HALF_HYPHEN + viewStates.day)
                < 15
            ) {
                errorBean.yearErrorFlag = true
                errorBean.monthErrorFlag = true
                errorBean.dayErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002025V)
                    )
                )
            }
            // 1900年生まれ以降チェック
            else if (!EditCheckUtil.isYearCheck(viewStates.year)) {
                errorBean.yearErrorFlag = true
                errorBean.monthErrorFlag = true
                errorBean.dayErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errorMessageList = viewStates.errorMessageList.plus(
                        MessageReplaceUtils.messageReplace(
                            MyApp.CONTEXT.getString(R.string.MSG_ID_MB002007V),
                            MyApp.CONTEXT.getString(R.string.mbop0606_page_label_birthday)
                        )
                    )
                )
            }
        }

        if (!viewStates.isError) {
            viewStates = viewStates.copy(serverErrorMessage = "")
            // 画面IDとイベントID設定
            PreferenceUtil.setScreenIDAndEventID("MBOP0606", "E02")
            // パラメータセット
            paramSet(viewStates.requestBean)
            // お客様情報入力
            viewModelScope.launch {
                flow {
                    ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, viewStates.requestBean.convertToParams().toJson())
                    emit(webService.AB0706())
                }.map {
                    // 画面入力した情報をRealmに保存する
                    setRealmInfo(viewStates.requestBean.selfempDto)
                    // 修正場合
                    if (PreferenceUtil.getPreferenceBooleanValue(ConstUtil.OPENED_EDIT_INFO_FLAG)) {
                        PreferenceUtil.setPreferenceBooleanValue(ConstUtil.OPENED_EDIT_INFO_FLAG, false)
                        RouteUtil.navTo(
                            RouteName.MBOP1002Page
                        )
                    } else {
                        RouteUtil.navTo(
                            RouteName.MBOP0607Page,
                            viewStates.requestBean.selfempDto.toJson()
                        )
                    }
                }.catch {
                    ErrorUtil().apiErrorCatch(it.message.toString())
                }.collect()
            }
        } else {
            coroutineScope.launch {
                scrollState.animateScrollTo(0)
            }
        }
    }

    /**
     * 画面入力した情報をRealmに保存する
     */
    @SuppressLint("WeekBasedYear")
    fun setRealmInfo(soleProprietor: SoleProprietorBean) {
        // 画面入力した情報をRealmに保存する
        val accountOpeningAB0706 = dbService.findAll(AccountOpeningAB0706::class.java)
        if (accountOpeningAB0706.isNotEmpty()) {
            val customerInformation =
                accountOpeningAB0706[0]?.customerInformation?.fromJson<SoleProprietorBean>()!!
            customerInformation.customerKanjiLastName = viewStates.firstName

            customerInformation.customerKanjiFirstName = viewStates.secondName

            customerInformation.customerLastName = viewStates.firstKanaName
            customerInformation.customerFirstName = viewStates.secondKanaName
            customerInformation.gender = viewStates.sex
            customerInformation.roomNo = viewStates.storeName
            customerInformation.roomNoKana = viewStates.storeNameKana
            customerInformation.numberOfEmployees = viewStates.employeesNumber
            customerInformation.birthday = dateAddHyphen(viewStates.year, viewStates.month, viewStates.day)
            dbService.deleteAll(AccountOpeningAB0706::class.java)
            val ab0706 = AccountOpeningAB0706()
            ab0706.id = UUID.randomUUID().toString()
            ab0706.customerInformation = customerInformation.toJson()
            dbService.create(ab0706)
        } else {
            dbService.deleteAll(AccountOpeningAB0706::class.java)
            val ab0706 = AccountOpeningAB0706()
            ab0706.id = UUID.randomUUID().toString()
            ab0706.customerInformation = soleProprietor.toJson()
            dbService.create(ab0706)
        }
    }

    /**
     * パラメータセット
     */
    fun paramSet(bean: MBOP0601RequestBean) {

        // 口座開設申込情報（個人事業主）
        val soleProprietor = SoleProprietorBean(
            receiptNumber = KeyStoreUtil().getFromKeyStore(ConstUtil.RECEIPT_NUMBER),
            updateType = UpdateType.UPDATE_TYPE_024.code,
            customerKanjiLastName = viewStates.firstName,
            customerKanjiFirstName = viewStates.secondName,
            customerLastName = viewStates.firstKanaName,
            customerFirstName = viewStates.secondKanaName,
            gender = viewStates.sex,
            genderAnswer = if (viewStates.sex != SexType.UN_KNOW.code) "1" else "2",
            roomNo = viewStates.storeName,
            roomNoKana = viewStates.storeNameKana,
            numberOfEmployees = viewStates.employeesNumber,
            birthday = dateAddHyphen(viewStates.year, viewStates.month, viewStates.day),
        )
        // 人格区分
        bean.personType = PreferenceUtil.getPreferenceStringValue(PERSONALITY_FLAG).toString()
        // 受付番号
        bean.receiptNumber = KeyStoreUtil().getFromKeyStore(ConstUtil.RECEIPT_NUMBER)
        // 口座開設申込情報（個人事業主）
        bean.selfempDto = soleProprietor
        // 更新パターン
        bean.updateType = UpdateType.UPDATE_TYPE_024.code
    }

    /**
     * 性別の切替
     */
    fun onGenderChange(gender: String) {
        viewStates = viewStates.copy(sex = gender)
    }
}

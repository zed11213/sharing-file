package jp.co.jsbank.mb.bankingapp.logic.opened.mbop.mbop0705

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import jp.co.jsbank.mb.bankingapp.bean.opened.mbop.mbop0703.MBOP0703RequestBean
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.system.master.UpdateType
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.utils.*
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.INTERNET_SHOP_ID
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.INTERNET_SHOP_NAME
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * MBOP0705ロジック
 */
@HiltViewModel
class MBOP0705Logic @Inject constructor(
    private var webService: RestService
) : ViewModel() {

    /**
     * 希望店設定
     */
    fun setDepartment() {
        // 画面IDとイベントID設定
        PreferenceUtil.setScreenIDAndEventID("MBOP0705", "E02")
        viewModelScope.launch {
            flow {
                val bean = MBOP0703RequestBean(
                    receptionNumber = KeyStoreUtil().getFromKeyStore(ConstUtil.RECEIPT_NUMBER),
                    personType = PreferenceUtil.getPreferenceStringValue(ConstUtil.PERSONALITY_FLAG).toString(),
                    hopeDepartmentStore = INTERNET_SHOP_ID,
                    reasonToOpenAccAnotherBranch = PreferenceUtil.getPreferenceStringValue(ConstUtil.REASON).toString(),
                    reasonToOpenAccAnotherBranchOther =
                    PreferenceUtil.getPreferenceStringValue(ConstUtil.REASON_OTHER).toString(),
                    updateType = UpdateType.UPDATE_TYPE_004.code
                )
                ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, bean.toJson())
                emit(webService.AB0709())
            }.map {
                PreferenceUtil.setPreferenceStringValue(
                    ConstUtil.OPENED_HOPE_DEPARTMENT,
                    INTERNET_SHOP_NAME
                )
                if (PreferenceUtil.getPreferenceBooleanValue(ConstUtil.OPENED_EDIT_INFO_FLAG)) {
                    PreferenceUtil.setPreferenceBooleanValue(ConstUtil.OPENED_EDIT_INFO_FLAG, false)
                    RouteUtil.navTo(RouteName.MBOP1001Page)
                } else {
                    RouteUtil.navTo(
                        RouteName.MBOP0401Page
                    )
                }
            }.catch {
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }
    }
}

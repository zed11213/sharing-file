package jp.co.jsbank.mb.bankingapp.logic.opened.mbco.mbco0403

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbco.mbco0403.MBCO0403PageState

/**
 * MBCO0403ロジック
 */
@HiltViewModel
class MBCO0403Logic @Inject constructor(
    private var webService: RestService,
) : ViewModel() {

    // ログインステータス
    var viewStates by mutableStateOf(MBCO0403PageState())
        private set
}

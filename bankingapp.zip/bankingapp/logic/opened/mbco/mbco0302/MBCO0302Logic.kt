package jp.co.jsbank.mb.bankingapp.logic.opened.mbco.mbco0302

import android.annotation.SuppressLint
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import javax.inject.Inject
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.bean.cashCard.mbcc.mbcc0901.MBCC0901RequestBean
import jp.co.jsbank.mb.bankingapp.bean.opened.mbco.mbco0302.AB0808RequestBean
import jp.co.jsbank.mb.bankingapp.bean.opened.mbco.mbco0302.MBCO0302Param
import jp.co.jsbank.mb.bankingapp.bean.opened.mbco.mbco0302.MBCO0302RequestBean
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.system.MyApp
import jp.co.jsbank.mb.bankingapp.system.master.PersonalityFlag
import jp.co.jsbank.mb.bankingapp.system.master.UpdateType
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbco.mbco0302.MBCO0302PageState
import jp.co.jsbank.mb.bankingapp.utils.*
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.AUTHENTICATION_RESULT_OK
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.MAIL_CONFIRM_TYPE_CASH_CARD
import jp.co.jsbank.mb.bankingapp.utils.RouteUtil.back
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/**
 * MBCO0302ロジック
 */
@HiltViewModel
class MBCO0302Logic @Inject constructor(
    private var webService: RestService,
) : ViewModel() {

    /**
     * MBCO0302ステータス
     */
    var viewStates by mutableStateOf(MBCO0302PageState())
        private set

    /**
     * 初期化
     */
    init {
        val arguments = MainActivity.NAVCTRL?.currentBackStackEntry?.arguments?.get(ConstUtil.DATA).toString()
            .fromJson<MBCO0302Param>()!!
        viewStates.type = arguments.type
        viewStates.phoneNumber = arguments.phoneNumber
    }

    /**
     * 電話認証
     */
    private fun certificationCodeAuthentication(type: String) {
        // 画面IDとイベントID設定
        PreferenceUtil.setScreenIDAndEventID("MBCO0302", "E03")
        val personalityFlag = PreferenceUtil.getPreferenceStringValue(ConstUtil.PERSONALITY_FLAG).toString()
        if (type == MAIL_CONFIRM_TYPE_CASH_CARD) {
            val requestBean = AB0808RequestBean(
                // IVROTP
                ivrOtp = viewStates.otp,
                // 受付番号
                receiptNumber = KeyStoreUtil().getFromKeyStore(ConstUtil.CC_RECEIPT_NUMBER),
                // 電話番号
                phoneNumber = viewStates.phoneNumber,
                // 更新パターン
                updateType = UpdateType.UPDATE_TYPE_114.code,
            )
            viewModelScope.launch {
                flow {
                    ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, requestBean.toJson())
                    emit(webService.AB0808())
                }.map {
                    if (it.resultDto!!.authenticationResult == AUTHENTICATION_RESULT_OK) {
                        issuanceRequest()
                    }
                }.catch {
                    ErrorUtil().apiErrorCatch(it.message.toString())
                }.collect()
            }
        } else {
            val requestBean = MBCO0302RequestBean(
                // IVROTP
                ivrOtp = viewStates.otp,
                // 受付番号
                receiptNumber = KeyStoreUtil().getFromKeyStore(ConstUtil.RECEIPT_NUMBER),
                // 電話番号
                phoneNumber = viewStates.phoneNumber,
                // 依頼番号
                requestNo = PreferenceUtil.getPreferenceStringValue(ConstUtil.REQUEST_NO).toString(),
                // 人格区分
                personType = PreferenceUtil.getPreferenceStringValue(ConstUtil.PERSONALITY_FLAG).toString(),
                // 更新パターン
                updateType = when (personalityFlag) {
                    // 個人の場合
                    PersonalityFlag.INDIVIDUAL_OTHER.code -> {
                        UpdateType.UPDATE_TYPE_111.code
                    }
                    // 法人の場合
                    PersonalityFlag.CORPORATION.code -> {
                        UpdateType.UPDATE_TYPE_112.code
                    }
                    // 個人事業主の場合
                    else -> {
                        UpdateType.UPDATE_TYPE_113.code
                    }
                }
            )
            viewModelScope.launch {
                flow {
                    ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, requestBean.toJson())
                    emit(webService.AB0715())
                }.map {
                    if (it.resultDto!!.authenticationResult == AUTHENTICATION_RESULT_OK) {
                        if (PreferenceUtil.getPreferenceStringValue(ConstUtil.OPENED_DEPARTMENT)
                            .toString().isNotEmpty()
                        ) {
                            PreferenceUtil.removePreferenceStringValue(ConstUtil.OPENED_HOPE_DEPARTMENT)
                            RouteUtil.navTo(
                                RouteName.MBOP0401Page
                            )
                        } else {
                            // MBOP0701　希望店選択
                            RouteUtil.navTo(
                                RouteName.MBOP0701Page,
                            )
                        }
                    }
                }.catch {
                    ErrorUtil().apiErrorCatch(it.message.toString())
                }.collect()
            }
        }
    }

    /**
     * エラーチェック
     */
    fun phoneCodeCheck(type: String) {
        // エラー情報初期化
        viewStates = viewStates.copy(errMsgList = listOf())

        // 確認番号が空白場合
        if (viewStates.otp.isBlank()) {
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002014V),
                        MyApp.CONTEXT.getString(R.string.mbco0302_page_error_message)
                    )
                )
            )
        } else if (!EditCheckUtil.lengthCheck(viewStates.otp, 4)) {
            // 確認番号は4桁以外
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB008001V),
                        MyApp.CONTEXT.getString(R.string.mbco0302_page_error_message)
                    )
                )
            )
        } else if (!EditCheckUtil.numberCheck(viewStates.otp)) {
            // 確認番号が半角数字以外
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB008002V),
                        MyApp.CONTEXT.getString(R.string.mbco0302_page_error_message)
                    )
                )
            )
        }

        if (viewStates.errMsgList.isEmpty()) {
            certificationCodeAuthentication(type)
        }
    }

    /**
     * 暗証番号の入力イベント
     */
    fun onPhoneCodeChange(value: String) {
        viewStates = viewStates.copy(otp = value)
    }

    /**
     * かけ直す
     */
    @SuppressLint("WeekBasedYear")
    fun callBack() {
        val callBackCount = PreferenceUtil.getPreferenceIntValue(
            ConstUtil.MBCO0302_CALL_BACK_COUNT + LocalDate.now().format(
                DateTimeFormatter.ofPattern(ConstUtil.DATE_FORMAT_YYYY_MM_DD)
            )
        )
        if (callBackCount >= 10) {
            // 1日の上限に達した場合
            openAchievedDialog()
        } else {
            PreferenceUtil.setPreferenceIntValue(
                ConstUtil.MBCO0302_CALL_BACK_COUNT + LocalDate.now().format(
                    DateTimeFormatter.ofPattern(ConstUtil.DATE_FORMAT_YYYY_MM_DD)
                ),
                callBackCount + 1
            )
            MainActivity.NAVCTRL?.back()
        }
    }

    private fun openAchievedDialog() {
        viewStates = viewStates.copy(achievedFlag = true)
    }

    fun closeAchievedDialog() {
        viewStates = viewStates.copy(achievedFlag = false)
    }

    /**
     * CC発行依頼
     */
    private fun issuanceRequest() {
        // 画面IDとイベントID設定
        PreferenceUtil.setScreenIDAndEventID("MBCC0901", "E02")
        val requestBean = MBCC0901RequestBean()
        requestBean.receptionNumber = KeyStoreUtil().getFromKeyStore(ConstUtil.CC_RECEIPT_NUMBER)
        requestBean.applicationDate = LocalDateTime.now().format(
            DateTimeFormatter.ofPattern(ConstUtil.DATE_FORMAT_YYYY_MM_DD_T_HH_MM_SS_MI)
        )
        viewModelScope.launch {
            flow {
                ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, requestBean.toJson())
                emit(webService.AB0804())
            }.map {
                // MBCC0901　申込完了
                RouteUtil.navTo(
                    RouteName.MBCC0901Page,
                )
            }.catch {
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }
    }
}

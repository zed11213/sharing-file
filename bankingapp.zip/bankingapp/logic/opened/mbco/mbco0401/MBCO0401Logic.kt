package jp.co.jsbank.mb.bankingapp.logic.opened.mbco.mbco0401

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import asia.liquidinc.ekyc.applicant.LiquidSdk
import asia.liquidinc.ekyc.applicant.external.DisplayLanguage
import asia.liquidinc.ekyc.applicant.external.FaceVerificationType
import asia.liquidinc.ekyc.applicant.external.LiquidFaceVerificationCallback
import asia.liquidinc.ekyc.applicant.external.LiquidProcessingResultCallback
import asia.liquidinc.ekyc.applicant.external.TermsOfUseSettings
import asia.liquidinc.ekyc.applicant.external.VerifyFaceParameters
import asia.liquidinc.ekyc.applicant.external.result.LiquidFaceVerificationResult
import asia.liquidinc.ekyc.applicant.external.result.chip.Sex
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import jp.co.jsbank.mb.bankingapp.bean.ekyc.GetTokenRequest
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.system.master.EkycCard
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbco.mbco0401.MBCO0401PageState
import jp.co.jsbank.mb.bankingapp.utils.ApiRequestUtil
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil
import jp.co.jsbank.mb.bankingapp.utils.ErrorUtil
import jp.co.jsbank.mb.bankingapp.utils.PreferenceUtil
import jp.co.jsbank.mb.bankingapp.utils.toJson
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import javax.inject.Inject
import asia.liquidinc.ekyc.applicant.external.result.LiquidProcessingResult
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.system.MyApp
import jp.co.jsbank.mb.bankingapp.system.MyApp.Companion.CONTEXT
import jp.co.jsbank.mb.bankingapp.system.master.EkycResult
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.EKYC_TYPE
import jp.co.jsbank.mb.bankingapp.utils.RouteUtil
import jp.co.jsbank.mb.bankingapp.utils.bitmapToBase64

/**
 * MBCO0401ロジック
 */
@HiltViewModel
class MBCO0401Logic @Inject constructor(
    private var webService: RestService,
    @ApplicationContext private val context: Context
) : ViewModel() {

    /**
     * ログインステータス
     */
    var viewStates by mutableStateOf(MBCO0401PageState())
        private set
    /**
     * 初期化
     */
    init {
        //初期化
        PreferenceUtil.setPreferenceBooleanValue(ConstUtil.EKYC_TERM_SUCCESS,false)
    }

    fun initSDK(skip: String? = null) {
        if(skip != null){
            skipEkyc()
            RouteUtil.navTo(RouteName.MBCO0405Page)
        }else {
            acquireTokenAndStartEkyc()
        }
    }
    private fun acquireTokenAndStartEkyc(){
        viewModelScope.launch {
            var tokenAcquired = false
            flow {
                val requestBean = GetTokenRequest()
                requestBean.applicantId = ""
                ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, requestBean.toJson())
                emit(webService.AB1201())
            }.map {
                // アプリケーションID
                Log.i("ekyc","applicantId = ${it.resultDto?.applicantId}")
                Log.i("ekyc","token = ${it.resultDto?.token}")
                PreferenceUtil.setPreferenceStringValue(
                    ConstUtil.LIQUID_EKYC_APPLICANT_ID, it.resultDto?.applicantId.toString()
                )
                // トークン
                PreferenceUtil.setPreferenceStringValue(
                    ConstUtil.LIQUID_EKYC_TOKEN, it.resultDto?.token.toString()
                )
                tokenAcquired = true
            }.catch {
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
            if (tokenAcquired) {
                startEkyc()
            }
        }
    }
    fun skipEkyc() {
        MainActivity.IS_EKYC_SHOOT_AGAIN_FLAG = false
        PreferenceUtil.setPreferenceStringValue(ConstUtil.EKYC_INFO_LAST_NAME, "太郎1234")
        PreferenceUtil.setPreferenceStringValue(ConstUtil.EKYC_INFO_FIRST_NAME, "テスト1234")
        PreferenceUtil.setPreferenceStringValue(ConstUtil.EKYC_INFO_BIRTHDATE, "1996年02月11日")
        PreferenceUtil.setPreferenceStringValue(ConstUtil.EKYC_INFO_ADDRESS, "東京都江戸川区西葛西５丁目２番３")
        PreferenceUtil.setPreferenceStringValue(ConstUtil.EKYC_INFO_ADDRESS1, "東京都")
        PreferenceUtil.setPreferenceStringValue(ConstUtil.EKYC_INFO_ADDRESS2, "江戸川区西葛西")
        PreferenceUtil.setPreferenceStringValue(ConstUtil.EKYC_INFO_ADDRESS3, "５丁目２番３")
        PreferenceUtil.setPreferenceStringValue(ConstUtil.EKYC_INFO_POSTALCODE, "1400004")
        PreferenceUtil.setPreferenceStringValue(ConstUtil.EKYC_INFO_GENDER, Sex.MALE.name)
        PreferenceUtil.setPreferenceIntValue(ConstUtil.EKYC_INFO_GENDER_CODE, Sex.MALE.ordinal)
        PreferenceUtil.setPreferenceBooleanValue(ConstUtil.EKYC_INFO_SHOW_GENDER,true)

        val fakeImage = BitmapFactory.decodeResource(MyApp.CONTEXT.resources, R.drawable.ekyc_face)
        var fakeValue = bitmapToBase64(fakeImage)
        PreferenceUtil.setPreferenceStringValue(ConstUtil.EKYC_IMAGE_SELF, fakeValue)
        PreferenceUtil.setPreferenceStringValue(ConstUtil.EKYC_IMAGE_TILTED, fakeValue)
        PreferenceUtil.setPreferenceStringValue(ConstUtil.EKYC_IMAGE_FRONT, fakeValue)
        PreferenceUtil.setPreferenceStringValue(ConstUtil.EKYC_IMAGE_BACK, fakeValue)

        PreferenceUtil.setPreferenceStringValue(ConstUtil.EKYC_RESULT, EkycResult.OK.code)
    }
    /**
     * 通帳デザイン選択
     */
    fun onBankbookPatternChange(pattern: EkycCard) {
        viewStates = viewStates.copy(ekycCardPattern = pattern)
    }

    fun showTerms(activity: Activity?){
        var termSetting = TermsOfUseSettings.Builder()
            .setHeaderFontColor(Color.parseColor("#000000"))
            .setScreenBgColor(Color.parseColor("#ffffff"))
            .setPrefaceFontColor(Color.parseColor("#333333"))
            .setButtonInactiveBgColor(Color.parseColor("#dddddd"))
            .setButtonActiveBgColor(Color.parseColor("#1bb0d1"))
            .setButtonFontColor(Color.parseColor("#ffffff"))
            .build()
        var intent = Intent()
        LiquidSdk.getInstance(context.applicationContext).handleShowTermsOfUseResult(100, 101, intent, object :LiquidProcessingResultCallback {
            override fun onComplete(result:LiquidProcessingResult ){
                Log.i("ekyc", "OnComplete terms")
            }
        } )

        LiquidSdk.getInstance(context.applicationContext).handleFaceVerificationResult(200, 201, intent, object : LiquidFaceVerificationCallback {
            override  fun onComplete(result: LiquidFaceVerificationResult) {
                Log.i("ekyc", "OnComplete face")
            }
        })

        var faceParameters = VerifyFaceParameters.Builder().setFaceVerificationType(FaceVerificationType.ACTIVE).build()
        LiquidSdk.getInstance(context.applicationContext).verifyFace(faceParameters, activity)


    }
}

private fun startEkyc() {
    val activity = MainActivity.ACTIVITY
    Log.i("ekyc", "startEkyc: ACTIVITY=$activity")
    if (activity is MainActivity) {
        activity.startEkycFlow()
    } else {
        Log.e("ekyc", "startEkyc: ACTIVITY is null or not MainActivity!")
    }
}

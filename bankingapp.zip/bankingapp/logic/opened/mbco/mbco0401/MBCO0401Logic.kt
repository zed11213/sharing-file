package jp.co.jsbank.mb.bankingapp.logic.opened.mbco.mbco0401

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import jp.co.jsbank.mb.bankingapp.system.master.EkycCard
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbco.mbco0401.MBCO0401PageState

/**
 * MBCO0401ロジック
 */
@HiltViewModel
class MBCO0401Logic @Inject constructor() : ViewModel() {

    /**
     * ログインステータス
     */
    var viewStates by mutableStateOf(MBCO0401PageState())
        private set

    /**
     * 通帳デザイン選択
     */
    fun onBankbookPatternChange(pattern: EkycCard) {
        viewStates = viewStates.copy(ekycCardPattern = pattern)
    }
}

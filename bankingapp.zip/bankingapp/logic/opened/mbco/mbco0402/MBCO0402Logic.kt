package jp.co.jsbank.mb.bankingapp.logic.opened.mbco.mbco0402

import android.content.Intent
import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import jp.co.jsbank.mb.bankingapp.system.MyApp.Companion.CONTEXT
import jp.co.jsbank.mb.bankingapp.system.liquidekyc.LiquidEkycActivity

/**
 * MBCO0402ロジック
 */
@HiltViewModel
class MBCO0402Logic @Inject constructor() : ViewModel() {

    /**
     * ekyc起動
     */
    fun getMatchingID() {
        val intent = Intent()
        intent.setClass(CONTEXT, LiquidEkycActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        CONTEXT.startActivity(intent)
    }
}

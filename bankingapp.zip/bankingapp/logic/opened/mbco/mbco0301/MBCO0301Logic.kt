package jp.co.jsbank.mb.bankingapp.logic.opened.mbco.mbco0301

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import jp.co.jsbank.mb.bankingapp.bean.opened.mbco.mbco0301.MBCO0301RequestBean
import jp.co.jsbank.mb.bankingapp.bean.opened.mbco.mbco0302.MBCO0302Param
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.system.master.PersonalityFlag
import jp.co.jsbank.mb.bankingapp.system.master.UpdateType
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbco.mbco0301.MBCO0301PageState
import jp.co.jsbank.mb.bankingapp.utils.*
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.PHONE_FIRST
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.PHONE_SECOND
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.PHONE_THREE
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/**
 * MBCO0301ロジック
 */
@HiltViewModel
class MBCO0301Logic @Inject constructor(
    private var webService: RestService,
) : ViewModel() {

    /**
     * ログインステータス
     */
    var viewStates by mutableStateOf(MBCO0301PageState())
        private set

    /**
     * 初期化
     */
    init {
        if (PreferenceUtil.getPreferenceStringValue(PHONE_FIRST)?.isNotBlank() == true) {
            viewStates.phoneList.add(PreferenceUtil.getPreferenceStringValue(PHONE_FIRST).toString())
        }
        if (PreferenceUtil.getPreferenceStringValue(PHONE_SECOND)?.isNotBlank() == true) {
            viewStates.phoneList.add(PreferenceUtil.getPreferenceStringValue(PHONE_SECOND).toString())
        }
        // 2025/01/16 共同化ため電話番号の登録・表示　電話３追加　start
        if (PreferenceUtil.getPreferenceStringValue(PHONE_THREE)?.isNotBlank() == true) {
            viewStates.phoneList.add(PreferenceUtil.getPreferenceStringValue(PHONE_THREE).toString())
        }
        // 2025/01/16 共同化ため電話番号の登録・表示　電話３追加　　end
    }

    /**
     * 電話番号選択
     */
    fun onPhonePatternChange(phonePattern: Int) {
        viewStates = viewStates.copy(phonePattern = phonePattern)
    }

    // 電話認証
    fun telephoneAuthentication(type: String) {
        // 画面IDとイベントID設定
        PreferenceUtil.setScreenIDAndEventID("MBCO0301", "E02")
        val personalityFlag = PreferenceUtil.getPreferenceStringValue(ConstUtil.PERSONALITY_FLAG).toString()
        val requestBean = MBCO0301RequestBean(
            // 電話番号
            phoneNumber = viewStates.phoneList[viewStates.phonePattern],
            // 受付番号
            receiptNumber = if (type == ConstUtil.MAIL_CONFIRM_TYPE_CASH_CARD)
                KeyStoreUtil().getFromKeyStore(ConstUtil.CC_RECEIPT_NUMBER) else KeyStoreUtil().getFromKeyStore(ConstUtil.RECEIPT_NUMBER),
            // 人格区分
            personType = PreferenceUtil.getPreferenceStringValue(ConstUtil.PERSONALITY_FLAG).toString(),
            // 更新パターン
            updateType = if (type == ConstUtil.MAIL_CONFIRM_TYPE_CASH_CARD) {
                UpdateType.UPDATE_TYPE_114.code
            } else {
                when (personalityFlag) {
                    // 個人場合
                    PersonalityFlag.INDIVIDUAL_OTHER.code -> {
                        UpdateType.UPDATE_TYPE_111.code
                    }
                    // 法人の場合
                    PersonalityFlag.CORPORATION.code -> {
                        UpdateType.UPDATE_TYPE_112.code
                    }
                    // 個人事業主の場合
                    else -> {
                        UpdateType.UPDATE_TYPE_113.code
                    }
                }
            }
        )
        viewModelScope.launch {
            flow {
                ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, requestBean.toJson())
                emit(webService.AB0714())
            }.map {
                val param = MBCO0302Param()
                param.type = type
                param.phoneNumber = viewStates.phoneList[viewStates.phonePattern]
                // MBCO0302　認証番号入力
                RouteUtil.navTo(
                    RouteName.MBCO0302Page,
                    args = param
                )
            }.catch {
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }
    }
}

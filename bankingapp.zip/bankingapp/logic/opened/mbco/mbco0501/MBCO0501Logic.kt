package jp.co.jsbank.mb.bankingapp.logic.opened.mbco.mbco0501

import androidx.compose.foundation.ScrollState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import io.realm.Realm
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.bean.opened.mbco.mbco0501.MBCO0501RequestBean
import jp.co.jsbank.mb.bankingapp.bean.opened.mbop.mbop0602.MBOP0602ResponseBean
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.repositories.db.common.findAll
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.AccountOpeningAB0707
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.EPassBookAB0701
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.system.MyApp
import jp.co.jsbank.mb.bankingapp.system.master.PersonalityFlag
import jp.co.jsbank.mb.bankingapp.system.master.UpdateType
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbco.mbco0501.MBCO0501ErrorInformation
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbco.mbco0501.MBCO0501PageState
import jp.co.jsbank.mb.bankingapp.utils.ApiRequestUtil
import jp.co.jsbank.mb.bankingapp.utils.CalendarChangeUtil
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.CC_PASSWORD
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.MAIL_CONFIRM_TYPE_CASH_CARD
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.MAIL_CONFIRM_TYPE_INDIVIDUAL
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil
import jp.co.jsbank.mb.bankingapp.utils.ErrorUtil
import jp.co.jsbank.mb.bankingapp.utils.KeyStoreUtil
import jp.co.jsbank.mb.bankingapp.utils.MessageReplaceUtils
import jp.co.jsbank.mb.bankingapp.utils.PreferenceUtil
import jp.co.jsbank.mb.bankingapp.utils.RouteUtil
import jp.co.jsbank.mb.bankingapp.utils.fromJson
import jp.co.jsbank.mb.bankingapp.utils.toJson
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import javax.inject.Inject


/**
 * MBCO0501ロジック
 */
@HiltViewModel
class MBCO0501Logic @Inject constructor(
    private var webService: RestService,
) : ViewModel() {

    /**
     * MBCO0501ステータス
     */
    var viewStates by mutableStateOf(MBCO0501PageState())
        private set

    /**
     * ロカールDB
     */
    private var dbService: Realm = MyApp.INSTANCE

    /**
     * 暗証番号チェック結果
     */
    private var isError: Boolean = false

    /**
     * 初期化
     */
    init {
        // 復元データを取得する
        getRestoreData()
    }

    // 復元データを取得する
    private fun getRestoreData() {
        // 人格区分
        val personType = PreferenceUtil.getPreferenceStringValue(ConstUtil.PERSONALITY_FLAG).toString()
        val accountOpeningAB0701 = MyApp.INSTANCE.findAll(EPassBookAB0701::class.java)
        if (accountOpeningAB0701.isNotEmpty() && !MainActivity.HAS_RECOVERY_FLAG) {
            when (personType) {
                // 個人場合
                PersonalityFlag.INDIVIDUAL_OTHER.code -> {
                    viewStates = viewStates.copy(
                        type = MAIL_CONFIRM_TYPE_INDIVIDUAL
                    )
                }
                // 法人の場合
                PersonalityFlag.CORPORATION.code -> {
                    viewStates = viewStates.copy(
                        type = ConstUtil.MAIL_CONFIRM_TYPE_CORPORATION
                    )
                }
                // 個人事業主の場合
                PersonalityFlag.INDIVIDUAL_BUSINESS.code -> {
                    viewStates = viewStates.copy(
                        type = ConstUtil.MAIL_CONFIRM_TYPE_SOLE_PROPRIETOR
                    )
                }

                else -> {
                    viewStates = viewStates.copy(
                        type = MAIL_CONFIRM_TYPE_CASH_CARD
                    )
                }
            }

            // 復元処理済みフラグ
            MainActivity.HAS_RECOVERY_FLAG = true
            MainActivity.SHOW_RETURN_BUTTON_FLAG = true
        } else {
            val type = MainActivity.NAVCTRL?.currentBackStackEntry?.arguments?.get(ConstUtil.DATA).toString()
            viewStates = viewStates.copy(type = type)
        }
    }

    /**
     * 次の処理
     */
    fun doNext(coroutineScope: CoroutineScope, scrollState: ScrollState) {
        // エラー情報初期化
        val errorBean = MBCO0501ErrorInformation()
        viewStates = viewStates.copy(isError = false, errorBean = errorBean, errMsgList = listOf())

        // 暗証番号がブランクの場合
        if (viewStates.cashCardNumber.isBlank()) {
            errorBean.cashCardNumberErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbsu0501_page_label_cash_card_pin_check)
                    )
                )
            )
        } else if (!EditCheckUtil.lengthCheck(viewStates.cashCardNumber, 4)) {
            // 暗証番号は4桁必要です
            errorBean.cashCardNumberErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB009001V)
                )
            )
        } else if (!EditCheckUtil.numberCheck(viewStates.cashCardNumber)) {
            // 暗証番号は半角数字で入力してください
            errorBean.cashCardNumberErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB009002V)
                )
            )
        }

        // キャッシュカードの暗証番号（再度入力）
        if (viewStates.cashCardNumberAgain.isBlank()) {
            errorBean.cashCardNumberAgainErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbsu0501_page_label_cash_card_pin_check_confirm)
                    )
                )
            )
        } else if (!EditCheckUtil.lengthCheck(viewStates.cashCardNumberAgain, 4)) {
            // 暗証番号は4桁必要です
            errorBean.cashCardNumberAgainErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB009001V)
                )
            )
        } else if (!EditCheckUtil.numberCheck(viewStates.cashCardNumberAgain)) {
            // 暗証番号は半角数字で入力してください
            errorBean.cashCardNumberAgainErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB009002V)
                )
            )
        }

        // 暗証番号が一致しません
        if (viewStates.cashCardNumber != viewStates.cashCardNumberAgain) {
            // 暗証番号が一致しません
            errorBean.cashCardNumberErrorFlag = true
            errorBean.cashCardNumberAgainErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB009003V)
                )
            )
        }

        if (viewStates.cashCardNumber == "0000") {
            // 0000の場合
            errorBean.cashCardNumberErrorFlag = true
            errorBean.cashCardNumberAgainErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB009004V)
                )
            )
        }

        // 2025/06/02 共同化ため カード暗証番号 連続数字4桁をチェックを追加　start
        if (isContinuousDigits(viewStates.cashCardNumber)) {
            errorBean.cashCardNumberErrorFlag = true
            errorBean.cashCardNumberAgainErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB009004V)
                )
            )
        }
        // 2025/06/02 共同化ため カード暗証番号 連続数字4桁をチェックを追加　end


        if (!viewStates.isError) {
            if (ruleCheck()) {
                // 暗証番号が暗証番号のルールに則っていないチェック
                errorBean.cashCardNumberErrorFlag = true
                errorBean.cashCardNumberAgainErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB009004V)
                    )
                )
                coroutineScope.launch {
                    scrollState.animateScrollTo(0)
                }
            } else {
                pinNumberSetting()
            }
        } else {
            coroutineScope.launch {
                scrollState.animateScrollTo(0)
            }
        }
    }

    /**
     * 暗証番号が暗証番号のルールに則っていないチェック
     */
    private fun ruleCheck(): Boolean {
        // 保存したCiF情報を取得する
        val accountOpeningAB0707 = dbService.findAll(AccountOpeningAB0707::class.java)
        var cifInformation = MBOP0602ResponseBean()
        if (accountOpeningAB0707.isNotEmpty()) {
            cifInformation = accountOpeningAB0707[0]?.cifInformation?.fromJson<MBOP0602ResponseBean>()!!
        }

        // 前2桁
        val front2Truss = viewStates.cashCardNumber.substring(0, 2)
        // 後2桁
        val rear2Truss = viewStates.cashCardNumber.substring(2, 4)

        // 生年月日取得キー
        val birthdayKey = if (viewStates.type == MAIL_CONFIRM_TYPE_CASH_CARD) {
            ConstUtil.DATE_OF_BIRTH
        } else {
            ConstUtil.EKYC_INFO_BIRTHDATE
        }
        // 生年月日
        val birthday = PreferenceUtil.getPreferenceStringValue(birthdayKey).toString()
            .replace("年", "")
            .replace("月", "")
            .replace("日", "")
            .replace("-", "")
        val cifBirthday = cifInformation.birthday
            .replace("年", "")
            .replace("月", "")
            .replace("日", "")
            .replace("-", "")

        // 生年月日が空白以外場合
        birthdayCheck(birthday, front2Truss, rear2Truss)
        birthdayCheck(cifBirthday, front2Truss, rear2Truss)

        // 電話番号の下4桁
        val frequentlyPhone = if (viewStates.type == MAIL_CONFIRM_TYPE_CASH_CARD) {
            PreferenceUtil.getPreferenceStringValue(ConstUtil.PHONE_FIRST).toString()
        } else {
            PreferenceUtil.getPreferenceStringValue(ConstUtil.PHONE_NUMBER).toString()
        }
        val cifFrequentlyPhone = if (viewStates.type == MAIL_CONFIRM_TYPE_CASH_CARD) {
            PreferenceUtil.getPreferenceStringValue(ConstUtil.PHONE_FIRST).toString()
        } else {
            cifInformation.phoneNumber1
        }
        // 電話番号が空白以外場合
        phoneCheck(frequentlyPhone)
        phoneCheck(cifFrequentlyPhone)

        // 丁目
        val chomeKana = extractNumbersFromString(PreferenceUtil.getPreferenceStringValue(ConstUtil.CHOME).toString())
        // 番地
        val homeAddress = PreferenceUtil.getPreferenceStringValue(ConstUtil.ADDRESS).toString()
        val cifHomeAddress = extractNumbersFromString(cifInformation.addrDetail3)

        // 口座開設時は丁目と番地、CC発行時は番地をチェック
        addressCheck(homeAddress, chomeKana)
        addressCheck(cifHomeAddress, chomeKana)

        // 方書
        val room = extractNumbersFromString(
            PreferenceUtil.getPreferenceStringValue(ConstUtil.HOSHO).toString()
        )
        val cifRoom = extractNumbersFromString(cifInformation.addressDetail)

        // 方書
        roomCheck(room)
        roomCheck(cifRoom)
        // 2025/01/20 共同化ため カード暗証番号 連番数字4桁をチェックを追加　start
        //sequentialNumbersFourDigitCheck()
        // 2025/01/20 共同化ため カード暗証番号 連番数字4桁をチェックを追加　end
        return isError
    }

    /**
     * 電話番号チェックを呼び出す
     */
    private fun phoneCheck(frequentlyPhone: String): Boolean {
        if (frequentlyPhone.isNotEmpty()) {
            // 4桁　電話番号の下4桁
            if (viewStates.cashCardNumber == frequentlyPhone.substring(
                    frequentlyPhone.length - 4, frequentlyPhone.length
                )
            ) {
                isError = true
            }
        }
        return isError
    }

    /**
     * 生年月日チェックを呼び出す
     */
    private fun birthdayCheck(
        birthday: String,
        front2Truss: String,
        rear2Truss: String
    ): Boolean {
        if (birthday.isNotEmpty()) {
            // 和暦年
            val year = CalendarChangeUtil.imperialCalendarChange(birthday).split("年")[0].substring(2)

            // 業務チェック
            // 前2桁　生年月日の和暦年
            if (front2Truss == year) {
                isError = true
            }
            // 前2桁　生年月日の西暦年下2桁
            if (front2Truss == birthday.substring(2, 4)) {
                isError = true
            }
            // 前2桁　生年月日の月
            if (front2Truss == birthday.substring(4, 6)) {
                isError = true
            }
            // 前2桁　生年月日の日
            if (front2Truss == birthday.substring(6, 8)) {
                isError = true
            }
            // 後2桁　生年月日の和暦年
            if (rear2Truss == year) {
                isError = true
            }
            // 後2桁　生年月日の西暦年下2桁
            if (rear2Truss == birthday.substring(2, 4)) {
                isError = true
            }
            // 後2桁　生年月日の月
            if (rear2Truss == birthday.substring(4, 6)) {
                isError = true
            }
            // 後2桁　生年月日の日
            if (rear2Truss == birthday.substring(6, 8)) {
                isError = true
            }
            // 4桁　　生年月日の西暦年
            if (viewStates.cashCardNumber == birthday.substring(0, 4)) {
                isError = true
            }
        }
        return isError
    }

    /**
     * 番地チェックを呼び出す
     */
    private fun addressCheck(
        homeAddress: String,
        chomeKana: String,
    ): Boolean {
        val address = if (viewStates.type == MAIL_CONFIRM_TYPE_CASH_CARD) homeAddress else chomeKana + homeAddress
        if (address.length >= 4) {
            // 4桁　　丁目に番地の下4桁
            if (viewStates.cashCardNumber == address.substring(address.length - 4, address.length)) {
                isError = true
            }
            // 4桁　　丁目に番地の上4桁
            if (viewStates.cashCardNumber == address.substring(0, 4)) {
                isError = true
            }
        } else {
            // 4桁「右補0」
            if (viewStates.cashCardNumber == address.padEnd(4, '0')) {
                isError = true
            }
            // 4桁「左補0」
            if (viewStates.cashCardNumber == address.padStart(4, '0')) {
                isError = true
            }
        }
        return isError
    }

    /**
     * 方書チェックを呼び出す
     */
    private fun roomCheck(room: String): Boolean {
        if (room.length >= 4) {
            // 4桁　　方書の下4桁
            if (viewStates.cashCardNumber == room.substring(room.length - 4, room.length)) {
                isError = true
            }
            // 4桁　　方書の上4桁
            if (viewStates.cashCardNumber == room.substring(0, 4)) {
                isError = true
            }
        } else {
            // 4桁「右補0」
            if (viewStates.cashCardNumber == room.padEnd(4, '0')) {
                isError = true
            }
            // 4桁「左補0」
            if (viewStates.cashCardNumber == room.padStart(4, '0')) {
                isError = true
            }
        }
        return isError
    }

    /**
     * CC暗証番号設定を呼び出す
     */
    private fun pinNumberSetting() {
        // 画面IDとイベントID設定
        PreferenceUtil.setScreenIDAndEventID("MBCO0501", "E06")
        val requestBean = MBCO0501RequestBean()
        // 受付番号
        requestBean.receptionNumber =
            if (viewStates.type == MAIL_CONFIRM_TYPE_CASH_CARD) KeyStoreUtil().getFromKeyStore(ConstUtil.CC_RECEIPT_NUMBER)
            else KeyStoreUtil().getFromKeyStore(ConstUtil.RECEIPT_NUMBER)
        // CC暗証番号
        requestBean.ccPassword = viewStates.cashCardNumber
        // 人格区分
        if (viewStates.type == MAIL_CONFIRM_TYPE_INDIVIDUAL) requestBean.personalityKubun =
            PersonalityFlag.INDIVIDUAL_OTHER.code
        // 更新パターン
        requestBean.updateType = if (viewStates.type == MAIL_CONFIRM_TYPE_CASH_CARD) UpdateType.UPDATE_TYPE_033.code
        else UpdateType.UPDATE_TYPE_005.code
        viewModelScope.launch {
            flow {
                ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, requestBean.toJson())
                emit(webService.AB0802())
            }.map {
                KeyStoreUtil().saveToKeyStore(CC_PASSWORD, viewStates.cashCardNumber)
                if (PreferenceUtil.getPreferenceBooleanValue(ConstUtil.OPENED_EDIT_INFO_FLAG)) {
                    PreferenceUtil.setPreferenceBooleanValue(ConstUtil.OPENED_EDIT_INFO_FLAG, false)
                    RouteUtil.navTo(
                        RouteName.MBOP1001Page
                    )
                } else {
                    PreferenceUtil.setPreferenceBooleanValue(ConstUtil.OPENED_EDIT_INFO_FLAG, false)
                    if (viewStates.type == MAIL_CONFIRM_TYPE_CASH_CARD) {
                        // MBCO0201　メールアドレス入力
                        RouteUtil.navTo(
                            RouteName.MBCO0201Page, args = viewStates.type
                        )
                    } else {
                        openDialog()
                    }
                }
            }.catch {
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }
    }

    /**
     * ダイアログを開
     */
    private fun openDialog() {
        viewStates = viewStates.copy(openDialogFlag = true)
    }

    /**
     * ダイアログを閉じる
     */
    fun closeDialog() {
        viewStates = viewStates.copy(openDialogFlag = false)
    }

    /**
     * 文字列から数字を取り出す
     */
    private fun extractNumbersFromString(inputString: String): String {
        val regex = "\\d+".toRegex()
        val numbers = regex.findAll(inputString).map { it.value }.toList()
        return numbers.joinToString(separator = "")
    }

//    // 2025/01/20 共同化ため カード暗証番号 連番数字4桁をチェックを追加　start
//    /**
//     * 連番数字4桁をチェック
//     */
//    private fun sequentialNumbersFourDigitCheck(): Boolean {
//
//        val num1: Int = viewStates.cashCardNumber.substring(0, 1).toInt()
//        val num2: Int = viewStates.cashCardNumber.substring(1, 2).toInt()
//        val num3: Int = viewStates.cashCardNumber.substring(2, 3).toInt()
//        val num4: Int = viewStates.cashCardNumber.substring(3, 4).toInt()
//
//        // 連続増
//        val valid: Boolean = num1 < num2 && num2 < num3 && num3 < num4
//        // 連続減
//        val validMix: Boolean = num1 > num2 && num2 > num3 && num3 > num4
//
//        isError = valid || validMix || viewStates.cashCardNumber == "9012" || viewStates.cashCardNumber == "2109" || viewStates.cashCardNumber == "8901" || viewStates.cashCardNumber == "7890"
//        return isError
//    }
//    // 2025/01/20 共同化ため カード暗証番号 連番数字4桁をチェックを追加　end
    // 2025/06/02 共同化ため カード暗証番号 連続数字4桁をチェックを追加　start
    private fun isContinuousDigits(pin: String): Boolean {
        if (pin.length != 4) return false
        val digits = pin.map { it - '0' }
        // 連続増
        val increasing = digits.zipWithNext().all { (a, b) -> b == a + 1 }
        // 連続減
        val decreasing = digits.zipWithNext().all { (a, b) -> b == a - 1 }
        return increasing || decreasing
    }
    // 2025/06/02 共同化ため カード暗証番号 連続数字4桁をチェックを追加　end
}

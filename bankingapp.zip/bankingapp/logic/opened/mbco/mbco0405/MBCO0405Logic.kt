package jp.co.jsbank.mb.bankingapp.logic.opened.mbco.mbco0405

import android.util.Log
import android.widget.Toast
import androidx.compose.foundation.ScrollState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import asia.liquidinc.ekyc.applicant.LiquidSdk
import asia.liquidinc.ekyc.applicant.external.result.LiquidProcessingResultStatus
import asia.liquidinc.ekyc.applicant.external.result.chip.Sex
import dagger.hilt.android.lifecycle.HiltViewModel
import java.time.LocalDateTime
import java.time.ZoneOffset
import javax.inject.Inject
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.bean.common.CorporationBean
import jp.co.jsbank.mb.bankingapp.bean.common.Individual
import jp.co.jsbank.mb.bankingapp.bean.common.SoleProprietorBean
import jp.co.jsbank.mb.bankingapp.bean.opened.mbop.mbop1202.MBOP1202RequestBean
import jp.co.jsbank.mb.bankingapp.bean.opened.mbop.mbop1401.FileInfo
import jp.co.jsbank.mb.bankingapp.bean.opened.mbop.mbop1401.MBOP1401RequestBean
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.repositories.db.common.findAll
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.EPassBookAB0701
import jp.co.jsbank.mb.bankingapp.system.Config
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.system.MyApp
import jp.co.jsbank.mb.bankingapp.system.MyApp.Companion.CONTEXT
import jp.co.jsbank.mb.bankingapp.system.master.DocumentType
import jp.co.jsbank.mb.bankingapp.system.master.EkycCard
import jp.co.jsbank.mb.bankingapp.system.master.PersonalityFlag
import jp.co.jsbank.mb.bankingapp.system.master.UpdateType
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbco.mbco0405.MBCO0405ErrorInformation
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbco.mbco0405.MBCO0405PageState
import jp.co.jsbank.mb.bankingapp.utils.*
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.EKYC_IMAGE_BACK
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.EKYC_IMAGE_FRONT
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.EKYC_IMAGE_LIVENESS
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.EKYC_IMAGE_SELF
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.EKYC_IMAGE_TILTED
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.HALF_HYPHEN
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.containsInvalidCharacter
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isHalfNum
import jp.co.jsbank.mb.bankingapp.utils.EditCheckUtil.isPersonNameCharacters
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import java.time.format.DateTimeFormatter

/**
 * MBCO0405ロジック
 */
@HiltViewModel
class MBCO0405Logic @Inject constructor(
    private var webService: RestService,
) : ViewModel() {

    /**
     * MBCO0405ステータス
     */
    var viewStates by mutableStateOf(MBCO0405PageState())
        private set

    private var isActivating = false

    /**
     * 初期化
     */
    init {
        // 復元データを取得する
        getRestoreData()
    }

    // 復元データを取得する
    private fun getRestoreData() {
        var birthday = PreferenceUtil.getPreferenceStringValue(ConstUtil.EKYC_INFO_BIRTHDATE).toString()
        birthday = birthday.replace("年", "")
            .replace("月", "")
            .replace("日", "")
        // 姓
        var lastName = PreferenceUtil.getPreferenceStringValue(ConstUtil.EKYC_INFO_LAST_NAME).toString()
        // 名
        var firstName = PreferenceUtil.getPreferenceStringValue(ConstUtil.EKYC_INFO_FIRST_NAME).toString()
        // 年
        var year = if (birthday.isNotEmpty()) birthday.substring(0, 4) else ""
        // 月
        var month = if (birthday.isNotEmpty()) birthday.substring(4, 6) else ""
        // 日
        var day = if (birthday.isNotEmpty()) birthday.substring(6, 8) else ""
        // 郵便番号
        var postCode = PreferenceUtil.getPreferenceStringValue(ConstUtil.EKYC_INFO_POSTALCODE).toString()

        // 人格区分
        val personType = PreferenceUtil.getPreferenceStringValue(ConstUtil.PERSONALITY_FLAG).toString()
        val accountOpeningAB0701 = MyApp.INSTANCE.findAll(EPassBookAB0701::class.java)
        if (accountOpeningAB0701.isNotEmpty() && !MainActivity.HAS_RECOVERY_FLAG) {
            when (personType) {
                // 個人場合
                PersonalityFlag.INDIVIDUAL_OTHER.code -> {
                    val individualInfo = accountOpeningAB0701[0]?.individual?.fromJson<Individual>()!!
                    // 姓
                    lastName = individualInfo.customerKanjiLastName
                    // 名
                    firstName = individualInfo.customerKanjiFirstName
                    // 年
                    year = if (individualInfo.birthday.isNotBlank())
                        individualInfo.birthday.replace("-", "").substring(0, 4) else ""
                    // 月
                    month = if (individualInfo.birthday.isNotBlank())
                        individualInfo.birthday.replace("-", "").substring(4, 6) else ""
                    // 日
                    day = if (individualInfo.birthday.isNotBlank())
                        individualInfo.birthday.replace("-", "").substring(6, 8) else ""
                    // 郵便番号
                    postCode = individualInfo.zipCode
                }
                // 法人の場合
                PersonalityFlag.CORPORATION.code -> {
                    val corporationInfo = accountOpeningAB0701[0]?.corporation?.fromJson<CorporationBean>()!!
                    if (corporationInfo.officerKanjiLastName.isNotBlank()) {
                        // 姓
                        lastName = corporationInfo.officerKanjiLastName
                    }
                    if (corporationInfo.officerKanjiFirstName.isNotBlank()) {
                        // 名
                        firstName = corporationInfo.officerKanjiFirstName
                    }
                    if (corporationInfo.officerBirthday.isNotBlank()) {
                        // 年
                        year = corporationInfo.officerBirthday.replace("-", "").substring(0, 4)
                        // 月
                        month = corporationInfo.officerBirthday.replace("-", "").substring(4, 6)
                        // 日
                        day = corporationInfo.officerBirthday.replace("-", "").substring(6, 8)
                    }
                    if (corporationInfo.officerZipCode.isNotBlank()) {
                        // 郵便番号
                        postCode = corporationInfo.officerZipCode
                    }
                }
                // 個人事業主の場合
                PersonalityFlag.INDIVIDUAL_BUSINESS.code -> {
                    val soleProprietorInfo = accountOpeningAB0701[0]?.soleProprietor?.fromJson<SoleProprietorBean>()!!
                    if (soleProprietorInfo.customerKanjiLastName.isNotBlank()) {
                        // 姓
                        lastName = soleProprietorInfo.customerKanjiLastName
                    }
                    if (soleProprietorInfo.customerKanjiFirstName.isNotBlank()) {
                        // 名
                        firstName = soleProprietorInfo.customerKanjiFirstName
                    }
                    if (soleProprietorInfo.birthday.isNotBlank()) {
                        // 年
                        year = soleProprietorInfo.birthday.replace("-", "").substring(0, 4)
                        // 月
                        month = soleProprietorInfo.birthday.replace("-", "").substring(4, 6)
                        // 日
                        day = soleProprietorInfo.birthday.replace("-", "").substring(6, 8)
                    }
                    if (soleProprietorInfo.homeZipCode.isNotBlank()) {
                        // 郵便番号
                        postCode = soleProprietorInfo.homeZipCode
                    }
                }
            }

            // 復元処理済みフラグ
            MainActivity.HAS_RECOVERY_FLAG = true
            MainActivity.SHOW_RETURN_BUTTON_FLAG = true
        }

        //住所
        val address = PreferenceUtil.getPreferenceStringValue(ConstUtil.EKYC_INFO_ADDRESS).toString()
        //性別
        val ekycGender = PreferenceUtil.getPreferenceStringValue(ConstUtil.EKYC_INFO_GENDER).toString()
        val gender = when (ekycGender) {
            Sex.FEMALE.name -> "女性"
            Sex.MALE.name -> "男性"
            else -> ""
        }
        //性別フラグ
        val genderFlg = PreferenceUtil.getPreferenceBooleanValue(ConstUtil.EKYC_INFO_SHOW_GENDER)

        viewStates = viewStates.copy(
            lastName = lastName,
            firstName = firstName,
            year = year,
            month = month,
            day = day,
            postCode = postCode,
            address = address,
            gender = gender,
            genderFlg = genderFlg
        )
    }


    /**
     * エラーチェック
     */
    fun doNext(coroutineScope: CoroutineScope, scrollState: ScrollState) {
        // 完了API済みの場合、直接遷移する
        if (PreferenceUtil.getPreferenceBooleanValue(ConstUtil.MBCO0405_COMPLETED)) {
            navigateNext()
            return
        }
        if (isActivating) return
        // エラーチェック
        val errorBean = MBCO0405ErrorInformation()
        viewStates = viewStates.copy(isError = false, errorBean = errorBean, errMsgList = listOf())

//        check(errorBean)

        if (!viewStates.isError) {
            isActivating = true
            activate()
        } else {
            coroutineScope.launch {
                scrollState.animateScrollTo(0)
            }
        }
    }


    private fun activate() {
        // アクティベートファンクションの呼び出し例
        LiquidSdk.getInstance(MainActivity.ACTIVITY).activate { liquidProcessingResult ->
            when (liquidProcessingResult.result) {
                LiquidProcessingResultStatus.SUCCESS -> {
                    Log.i("ekyc", " activate success")
                    // 正常時の処理
                    viewModelScope.launch {
                        letterOfConfirmation()
                    }

                }

                LiquidProcessingResultStatus.ERROR -> {
                    isActivating = false
                    Log.e("ekyc", " activate error: errorCode=${liquidProcessingResult.errorCode}")
                    openCautionIndicationCodeDialog(liquidProcessingResult.errorCode)
                }

                else -> {
                    isActivating = false
                    Log.e("ekyc", " activate unknown result: status=${liquidProcessingResult.result}, errorCode=${liquidProcessingResult.errorCode}")
                    openCautionIndicationCodeDialog(liquidProcessingResult.errorCode)
                }
            }
        }
    }

    fun openCautionIndicationCodeDialog(errorCode: String) {
        viewStates = viewStates.copy(showDialogFlag = true, sorryMessage = "エラー番号:$errorCode")
    }

    /**
     * 注意コード誘導メッセージダイアログクルーズ
     */
    fun closeAccountOpeningDialogFlag() {
        viewStates = viewStates.copy(showDialogFlag = false)
    }


    private fun check(errorBean: MBCO0405ErrorInformation) {
        if (!PreferenceUtil.getPreferenceBooleanValue(ConstUtil.EKYC_TYPE) &&
            viewStates.firstName.isBlank()
        ) {
            errorBean.firstNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        CONTEXT.getString(R.string.mbco0405_page_label_firstName)
                    )
                )
            )
        }

        if (!PreferenceUtil.getPreferenceBooleanValue(ConstUtil.EKYC_TYPE) &&
            viewStates.lastName.isBlank()
        ) {
            errorBean.lastNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        CONTEXT.getString(R.string.mbco0405_page_label_lastName)
                    )
                )
            )
        }

        if (containsInvalidCharacter(viewStates.firstName)) {
            errorBean.firstNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    CONTEXT.getString(R.string.MSG_ID_MB002015V)
                )
            )
        }

        if (containsInvalidCharacter(viewStates.lastName)) {
            errorBean.lastNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    CONTEXT.getString(R.string.MSG_ID_MB002015V)
                )
            )
        }

        // 名
        if (!PreferenceUtil.getPreferenceBooleanValue(ConstUtil.EKYC_TYPE) &&
            viewStates.firstName.isNotBlank() && !viewStates.firstName.isPersonNameCharacters()
        ) {
            errorBean.firstNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        CONTEXT.getString(R.string.MSG_ID_MB002028V),
                        CONTEXT.getString(R.string.mbco0405_page_label_firstName)
                    )
                )
            )
        }

        // 姓
        if (!PreferenceUtil.getPreferenceBooleanValue(ConstUtil.EKYC_TYPE) &&
            viewStates.lastName.isNotBlank() && !viewStates.lastName.isPersonNameCharacters()
        ) {
            errorBean.lastNameErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        CONTEXT.getString(R.string.MSG_ID_MB002028V),
                        CONTEXT.getString(R.string.mbco0405_page_label_lastName)
                    )
                )
            )
        }

        // 年
        if (viewStates.year.isBlank()) {
            errorBean.yearErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        CONTEXT.getString(R.string.common_message_replace_label_year)
                    )
                )
            )
        }

        // 月
        if (viewStates.month.isBlank()) {
            errorBean.monthErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        CONTEXT.getString(R.string.common_message_replace_label_month)
                    )
                )
            )
        }

        // 日
        if (viewStates.day.isBlank()) {
            errorBean.dayErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(isError = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        CONTEXT.getString(R.string.common_message_replace_label_day)
                    )
                )
            )
        }

        // 生年月日チェック
        if (viewStates.year.isNotBlank() &&
            viewStates.month.isNotBlank() &&
            viewStates.day.isNotBlank()
        ) {
            if (!EditCheckUtil.isDayCheck(
                    viewStates.year,
                    viewStates.month,
                    viewStates.day
                )
            ) {
                errorBean.yearErrorFlag = true
                errorBean.monthErrorFlag = true
                errorBean.dayErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        MessageReplaceUtils.messageReplace(
                            CONTEXT.getString(R.string.MSG_ID_MB002007V),
                            CONTEXT.getString(R.string.mbco0405_page_label_year)
                        )
                    )
                )
            } else if (EditCheckUtil.isFutureDays(viewStates.year + viewStates.month + viewStates.day)) {
                // 未来日チェック
                errorBean.yearErrorFlag = true
                errorBean.dayErrorFlag = true
                errorBean.monthErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        MessageReplaceUtils.messageReplace(
                            CONTEXT.getString(R.string.MSG_ID_MB002007V),
                            CONTEXT.getString(R.string.mbco0405_page_label_year)
                        )
                    )
                )
            }
            // 15歳未満チェック
            else if (LifeAge.getAgeByBirth(
                    viewStates.year + HALF_HYPHEN + viewStates.month + HALF_HYPHEN + viewStates.day
                ) < 15
            ) {
                errorBean.yearErrorFlag = true
                errorBean.monthErrorFlag = true
                errorBean.dayErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        CONTEXT.getString(R.string.MSG_ID_MB002025V)
                    )
                )
            }
            // 1900年生まれ以降チェック
            else if (!EditCheckUtil.isYearCheck(viewStates.year)) {
                errorBean.yearErrorFlag = true
                errorBean.monthErrorFlag = true
                errorBean.dayErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        MessageReplaceUtils.messageReplace(
                            CONTEXT.getString(R.string.MSG_ID_MB002007V),
                            CONTEXT.getString(R.string.mbcc0401_page_label_birthday)
                        )
                    )
                )
            }
        }
        if (!PreferenceUtil.getPreferenceBooleanValue(ConstUtil.EKYC_TYPE) &&
            PreferenceUtil.getPreferenceStringValue(ConstUtil.PERSONALITY_FLAG)
            != PersonalityFlag.INDIVIDUAL_BUSINESS.code
        ) {
            if (viewStates.postCode.isBlank()) {
                errorBean.postCodeErrorFlag = true
                viewStates = viewStates.copy(errorBean = errorBean)
                viewStates = viewStates.copy(isError = true)
                viewStates = viewStates.copy(
                    errMsgList = viewStates.errMsgList.plus(
                        CONTEXT.getString(R.string.MSG_ID_MB002003V)
                    )
                )
            } else {
                if (!viewStates.postCode.isHalfNum()) {
                    // 郵便番号の半角数字チェック
                    errorBean.postCodeErrorFlag = true
                    viewStates = viewStates.copy(errorBean = errorBean)
                    viewStates = viewStates.copy(isError = true)
                    viewStates = viewStates.copy(
                        errMsgList = viewStates.errMsgList.plus(
                            MessageReplaceUtils.messageReplace(
                                CONTEXT.getString(R.string.MSG_ID_MB002012V),
                                CONTEXT.getString(R.string.mbco0405_page_label_postcode)
                            )
                        )
                    )
                } else if (!EditCheckUtil.lengthCheck(viewStates.postCode, 7)) {
                    // 郵便番号の桁数チェック
                    errorBean.postCodeErrorFlag = true
                    viewStates = viewStates.copy(errorBean = errorBean)
                    viewStates = viewStates.copy(isError = true)
                    viewStates = viewStates.copy(
                        errMsgList = viewStates.errMsgList.plus(
                            CONTEXT.getString(R.string.MSG_ID_MB002003V)
                        )
                    )
                }
            }
        }
    }

    /**
     * 完了APIを呼び出す
     */
    private fun letterOfConfirmation() {
        LoadingUtil.setLoadingValue(value = true, type = false)
        // 画面IDとイベントID設定
        PreferenceUtil.setScreenIDAndEventID("MBCO0405", "E06")
        val requestBean = initAB1202Bean()
        Log.i("ekyc", " letterOfConfirmation request: ${requestBean.toJson()}")

        viewModelScope.launch {
            // 画面IDとイベントID設定
            PreferenceUtil.setScreenIDAndEventID("MBCO0405", "E02")
            flow {
                ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, requestBean.toJson())
                val ekycDocumentType =
                    PreferenceUtil.getPreferenceStringValue(ConstUtil.EKYC_DOCUMENT_TYPE)
                if (ekycDocumentType == EkycCard.MEMBER.toString()) {
                    emit(webService.AB1202())
                } else {
                    emit(webService.AB1203())
                }
            }.map {
                // EKYC情報を更新する
                // 姓
                PreferenceUtil.setPreferenceStringValue(ConstUtil.EKYC_INFO_LAST_NAME, viewStates.lastName)
                // 名
                PreferenceUtil.setPreferenceStringValue(ConstUtil.EKYC_INFO_FIRST_NAME, viewStates.firstName)
                // 生年月日
                PreferenceUtil.setPreferenceStringValue(
                    ConstUtil.EKYC_INFO_BIRTHDATE,
                    viewStates.year + CONTEXT.getString(R.string.common_label_year) +
                        viewStates.month + CONTEXT.getString(R.string.common_label_month) +
                        viewStates.day + CONTEXT.getString(R.string.common_label_day)
                )
                // 郵便番号
                PreferenceUtil.setPreferenceStringValue(ConstUtil.EKYC_INFO_POSTALCODE, viewStates.postCode)
                // 完了API実行済みフラグを設定する
                PreferenceUtil.setPreferenceBooleanValue(ConstUtil.MBCO0405_COMPLETED, true)
                if (!PreferenceUtil.getPreferenceBooleanValue(ConstUtil.EKYC_TYPE)) {
                    when (PreferenceUtil.getPreferenceStringValue(ConstUtil.PERSONALITY_FLAG)) {
                        PersonalityFlag.INDIVIDUAL_OTHER.code -> {
                            // 受付番号を保存する
                            KeyStoreUtil().saveToKeyStore(ConstUtil.RECEIPT_NUMBER, it.resultDto!!.toString())
                        }
                        PersonalityFlag.CORPORATION.code -> {
                            // 法人の場合
                        }
                        PersonalityFlag.INDIVIDUAL_BUSINESS.code -> {
                            // 受付番号を保存する
                            KeyStoreUtil().saveToKeyStore(ConstUtil.RECEIPT_NUMBER, it.resultDto!!.toString())
                        }
                    }
                } else {
                    // 受付番号を保存する
                    KeyStoreUtil().saveToKeyStore(ConstUtil.CC_RECEIPT_NUMBER, it.resultDto!!.toString())
                }
                navigateNext()
            }.catch {
                Log.e("ekyc", " letterOfConfirmation error: ${it.message}", it)
                if (it is retrofit2.HttpException) {
                    val errorBody = it.response()?.errorBody()?.string()
                    Log.e("ekyc", " letterOfConfirmation response body: $errorBody")
                }
                ErrorUtil().apiErrorCatch(it.message.toString())
                isActivating = false
            }.collect()
        }
    }

    /**
     * 次の画面へ遷移する
     */
    private fun navigateNext() {
        if (!PreferenceUtil.getPreferenceBooleanValue(ConstUtil.EKYC_TYPE)) {
            when (PreferenceUtil.getPreferenceStringValue(ConstUtil.PERSONALITY_FLAG)) {
                PersonalityFlag.INDIVIDUAL_OTHER.code -> {
                    // 個人の場合、MBOP0203　ガイド（情報入力）
                    RouteUtil.navTo(RouteName.MBOP0203Page)
                }
                PersonalityFlag.CORPORATION.code -> {
                    // 法人の場合、本人確認 - 1.書類アップロード（法人）へ遷移する
                    RouteUtil.navTo(RouteName.MBOP1401Page)
                }
                PersonalityFlag.INDIVIDUAL_BUSINESS.code -> {
                    // 個人事業主の場合、MBOP0203　ガイド（情報入力）
                    RouteUtil.navTo(RouteName.MBOP0203Page)
                }
            }
        } else {
            // MBCC0103　ガイド（情報入力）
            RouteUtil.navTo(RouteName.MBCC0103Page)
        }
    }

    private fun initAB0702Bean(): MBOP1401RequestBean {
        val personalityFlag = PreferenceUtil.getPreferenceStringValue(ConstUtil.PERSONALITY_FLAG).toString()
        // リクエストボディ編集
        val requestBean = MBOP1401RequestBean()
        // ファイルリスト
        // 本人確認書類（表面）
        requestBean.fileStreams.add(
            FileInfo(
                documentsType = DocumentType.PERSONAL_SHOOT_SURFACE.code,
                fileName = DocumentType.PERSONAL_SHOOT_SURFACE.code + HALF_HYPHEN + LocalDateTime.now()
                    .toInstant(ZoneOffset.UTC).toEpochMilli().toString() + ConstUtil.JPEG,
                fileStream = PreferenceUtil.getPreferenceStringValue(EKYC_IMAGE_FRONT)!!
            ),
        )

        // マイナンバーカード場合
        if (PreferenceUtil.getPreferenceStringValue(ConstUtil.EKYC_CARD_TYPE) != EkycCard.MEMBER.toString()) {
            // 本人確認書類（裏面）
            requestBean.fileStreams.add(
                FileInfo(
                    documentsType = DocumentType.PERSONAL_SHOOT_BACK.code,
                    fileName = DocumentType.PERSONAL_SHOOT_BACK.code + HALF_HYPHEN + LocalDateTime.now()
                        .toInstant(ZoneOffset.UTC).toEpochMilli().toString() + ConstUtil.JPEG,
                    fileStream = PreferenceUtil.getPreferenceStringValue(EKYC_IMAGE_BACK)!!,
                ),
            )
        }

        // 本人確認書類（斜め面）
        requestBean.fileStreams.add(
            FileInfo(
                documentsType = DocumentType.PERSONAL_SHOOT_DIAGONAL.code,
                fileName = DocumentType.PERSONAL_SHOOT_DIAGONAL.code + HALF_HYPHEN + LocalDateTime.now()
                    .toInstant(ZoneOffset.UTC).toEpochMilli().toString() + ConstUtil.JPEG,
                fileStream = PreferenceUtil.getPreferenceStringValue(EKYC_IMAGE_TILTED)!!,
            ),
        )

        // 本人確認書類（セルフィー）
        requestBean.fileStreams.add(
            FileInfo(
                documentsType = DocumentType.PERSONAL_SHOOT_FACE.code,
                fileName = DocumentType.PERSONAL_SHOOT_FACE.code + HALF_HYPHEN + LocalDateTime.now()
                    .toInstant(ZoneOffset.UTC).toEpochMilli().toString() + ConstUtil.JPEG,
                fileStream = PreferenceUtil.getPreferenceStringValue(EKYC_IMAGE_SELF)!!,
            ),
        )

        // まばたき
        requestBean.fileStreams.add(
            FileInfo(
                documentsType = DocumentType.BLINK.code,
                fileName = DocumentType.BLINK.code + HALF_HYPHEN + LocalDateTime.now()
                    .toInstant(ZoneOffset.UTC).toEpochMilli().toString() + ConstUtil.JPEG,
                fileStream = PreferenceUtil.getPreferenceStringValue(EKYC_IMAGE_LIVENESS)!!,
            )
        )
        // 人格区分
        requestBean.personType = if (PreferenceUtil.getPreferenceBooleanValue(ConstUtil.EKYC_TYPE))
            "" else PreferenceUtil.getPreferenceStringValue(ConstUtil.PERSONALITY_FLAG).toString()
        // 受付番号
        requestBean.receiptNumber = if (PreferenceUtil.getPreferenceBooleanValue(ConstUtil.EKYC_TYPE))
            KeyStoreUtil().getFromKeyStore(ConstUtil.CC_RECEIPT_NUMBER)
        else
            KeyStoreUtil().getFromKeyStore(ConstUtil.RECEIPT_NUMBER)
        // eKYC確認結果
        requestBean.ekycResult = PreferenceUtil.getPreferenceStringValue(ConstUtil.EKYC_RESULT).toString()

        // 01 運転免許証
        // 02 マイナンバーカード
        requestBean.identificationDocumentCode =
            if (PreferenceUtil.getPreferenceStringValue(ConstUtil.EKYC_CARD_TYPE) != EkycCard.MEMBER.toString()) {
                "01"
            } else {
                "02"
            }

        // 郵便番号
        requestBean.zipCode = viewStates.postCode
        // 漢字氏名（姓）
        requestBean.customerKanjiLastName = if (!PreferenceUtil.getPreferenceBooleanValue(ConstUtil.EKYC_TYPE))
            HalfToFullUtils.halfToFullChar(viewStates.lastName) else ""
        // 漢字氏名（名）
        requestBean.customerKanjiFirstName = if (!PreferenceUtil.getPreferenceBooleanValue(ConstUtil.EKYC_TYPE))
            HalfToFullUtils.halfToFullChar(viewStates.firstName) else ""
        // 生年月日
        requestBean.birthday = viewStates.year + HALF_HYPHEN + viewStates.month + HALF_HYPHEN + viewStates.day
        // 更新パターン
        requestBean.updateType = when (personalityFlag) {
            PersonalityFlag.INDIVIDUAL_OTHER.code -> ""
            PersonalityFlag.INDIVIDUAL_BUSINESS.code -> UpdateType.UPDATE_TYPE_023.code
            PersonalityFlag.CORPORATION.code -> UpdateType.UPDATE_TYPE_013.code
            else -> UpdateType.UPDATE_TYPE_031.code
        }
        return requestBean
    }

    private fun initAB1202Bean(): MBOP1202RequestBean {
        val personalityFlag = PreferenceUtil.getPreferenceStringValue(ConstUtil.PERSONALITY_FLAG).toString()
        val personName = parseFullName();
        // 性別コード変換: Liquid SDK ordinal -> API値
        val genderCode = PreferenceUtil.getPreferenceIntValue(ConstUtil.EKYC_INFO_GENDER_CODE)
        val sex = when (genderCode) {
            Sex.MALE.ordinal -> "1"
            Sex.FEMALE.ordinal -> "2"
            else -> "9"
        }
        // リクエストボディ編集
        val requestBean = MBOP1202RequestBean(
            // 人格区分
            personType = if (PreferenceUtil.getPreferenceBooleanValue(ConstUtil.EKYC_TYPE))
                ""
            else if (Config.isRetail())
                PersonalityFlag.INDIVIDUAL_OTHER.code
            else
                PreferenceUtil.getPreferenceStringValue(ConstUtil.PERSONALITY_FLAG).toString(),
            // 受付番号
            receptionNumber = if (PreferenceUtil.getPreferenceBooleanValue(ConstUtil.EKYC_TYPE))
                KeyStoreUtil().getFromKeyStore(ConstUtil.CC_RECEIPT_NUMBER)
            else
                KeyStoreUtil().getFromKeyStore(ConstUtil.RECEIPT_NUMBER),
            // 更新区分
            updateType = if (PreferenceUtil.getPreferenceBooleanValue(ConstUtil.EKYC_TYPE))
                "031"
            else if (Config.isRetail())
                ""
            else when (personalityFlag) {
                PersonalityFlag.CORPORATION.code -> "013"
                PersonalityFlag.INDIVIDUAL_BUSINESS.code -> "023"
                else -> "017"
            },
//            lastName = personName.lastName,
//            firstName = personName.firstName,
            lastNameKana = personName.lastNameKana,
            firstNameKana = personName.firstNameKana,
            birthday = getFormatBirthDay(),
            sex = sex,
            zipCode = PreferenceUtil.getPreferenceStringValue(ConstUtil.EKYC_INFO_POSTALCODE).toString(),
            address1 = PreferenceUtil.getPreferenceStringValue(ConstUtil.EKYC_INFO_ADDRESS).toString() ,
            idNumber = PreferenceUtil.getPreferenceStringValue(ConstUtil.EKYC_INFO_ID_NUMBER).toString() ,
            applicantId = PreferenceUtil.getPreferenceStringValue(ConstUtil.LIQUID_EKYC_APPLICANT_ID).toString(),
        )
        return requestBean
    }

    fun getFormatBirthDay(): String {
        var birthday = PreferenceUtil.getPreferenceStringValue(ConstUtil.EKYC_INFO_BIRTHDATE).toString()
        birthday = birthday.replace("年", "")
            .replace("月", "")
            .replace("日", "")
        // 年
        var year = if (birthday.isNotEmpty()) birthday.substring(0, 4) else ""
        // 月
        var month = if (birthday.isNotEmpty()) birthday.substring(4, 6) else ""
        // 日
        var day = if (birthday.isNotEmpty()) birthday.substring(6, 8) else ""

        return year + HALF_HYPHEN + month + HALF_HYPHEN + day
    }

    fun parseFullName(): ParsedName {
        val name = PreferenceUtil.getPreferenceStringValue(ConstUtil.EKYC_INFO_NAME).toString()

        val parenStart = name.indexOf("（")
        val parenEnd = name.lastIndexOf("）")

        val kanjiPart: String
        val kanaPart: String

        if (parenStart != -1 && parenEnd != -1 && parenEnd > parenStart) {
            kanaPart = name.substring(0, parenStart)
            kanjiPart = name.substring(parenStart + 1, parenEnd)
        } else {
            kanjiPart = name
            kanaPart = ""
        }


        val kanjiNames = kanjiPart.split("　")
        val kanaNames = kanaPart.split("　")

        val lastName = if (kanjiNames.size > 1) kanjiNames[0] else kanjiPart
        val firstName = if (kanjiNames.size > 1) kanjiNames[1] else ""

        val lastNameKana = if (kanaNames.size > 1) kanaNames[0] else kanaPart
        val firstNameKana = if (kanaNames.size > 1) kanaNames[1] else ""

        return ParsedName(lastName, firstName, lastNameKana, firstNameKana)
    }

    data class ParsedName(
        val lastName: String,
        val firstName: String,
        val lastNameKana: String,
        val firstNameKana: String
    )
}

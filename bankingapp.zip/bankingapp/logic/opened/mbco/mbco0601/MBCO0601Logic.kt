package jp.co.jsbank.mb.bankingapp.logic.opened.mbco.mbco0601

import androidx.compose.foundation.ScrollState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.bean.opened.mbco.mbco0601.MBCO0601RequestBean
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.system.MyApp
import jp.co.jsbank.mb.bankingapp.system.master.PersonalityFlag
import jp.co.jsbank.mb.bankingapp.system.master.UpdateType
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbco.mbco0601.MBCO0601ErrorInformation
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbco.mbco0601.MBCO0601PageState
import jp.co.jsbank.mb.bankingapp.utils.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/**
 * MBCO0601ロジック
 */
@HiltViewModel
class MBCO0601Logic @Inject constructor(
    private var webService: RestService,
) : ViewModel() {

    /**
     * ステータス
     */
    var viewStates by mutableStateOf(MBCO0601PageState())
        private set

    /**
     * パスワードをロカールに保存する
     */
    private fun passwordSave() {
        // 画面IDとイベントID設定
        PreferenceUtil.setScreenIDAndEventID("MBCO0601", "E06")
        val requestBean = MBCO0601RequestBean()
        // 受付番号
        requestBean.receptionNumber = KeyStoreUtil().getFromKeyStore(ConstUtil.RECEIPT_NUMBER)
        // IBパスワード
        requestBean.ibPassword = viewStates.password
        // CC暗証番号
        requestBean.ccPassword = KeyStoreUtil().getFromKeyStore(ConstUtil.CC_PASSWORD)
        // 人格区分
        requestBean.personalityKubun = PersonalityFlag.INDIVIDUAL_OTHER.code
        // 更新パターン
        requestBean.updateType = UpdateType.UPDATE_TYPE_006.code

        viewModelScope.launch {
            flow {
                ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, requestBean.toJson())
                emit(webService.AB0711())
            }.map {
                KeyStoreUtil().saveToKeyStore(ConstUtil.IB_PASSWORD, viewStates.password)
                // MBOP1001　申し込み確認（個人）
                RouteUtil.navTo(
                    RouteName.MBOP1001Page,
                )
            }.catch {
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }
    }

    /**
     * エラーチェック
     */
    fun passwordCheck(coroutineScope: CoroutineScope, scrollState: ScrollState) {
        // エラー情報初期化
        val errorBean = MBCO0601ErrorInformation()
        viewStates = viewStates.copy(errorFlag = false, errorBean = errorBean, errMsgList = listOf())

        // パスワードが空白場合
        if (viewStates.password.isBlank()) {
            errorBean.passwordErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(errorFlag = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002021V),
                        MyApp.CONTEXT.getString(R.string.mbco0601_page_label_password_set)
                    )
                )
            )// 2025/01/20 共同化ためインバン利用登録修正　start
        } else if (!EditCheckUtil.lengthCheckRange(viewStates.password, 6)) {
            // パスワードは6~12桁必要です
            errorBean.passwordErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(errorFlag = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB003007H)
                )
            )
        } else if (!EditCheckUtil.halfEnglishNumCheck(viewStates.password)) {
            // パスワードは半角英数字で入力してください
            errorBean.passwordErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(errorFlag = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB003008V)
                )
            )
        } else if (!EditCheckUtil.halfEnglishNumMinLengthCheck(viewStates.password)) {
            // 「英字」「数字」の文字種を１文字以上組み合わせてください。
            errorBean.passwordErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(errorFlag = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB003009V)
                )
            )
            // 2025/01/20 共同化ためインバン利用登録修正　end
        } else if (viewStates.password != viewStates.confirmPassword) {
            // パスワードが一致しません
            errorBean.confirmPasswordErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(errorFlag = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB003003V)
                )
            )
        } else if (viewStates.password == "0000" || viewStates.password == "9999") {
            // 暗証番号が暗証番号のルールに則っていないチェック
            errorBean.confirmPasswordErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean)
            viewStates = viewStates.copy(errorFlag = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB009004V)
                )
            )
        }

        if (!viewStates.errorFlag) {
            passwordSave()
        } else {
            coroutineScope.launch {
                scrollState.animateScrollTo(0)
            }
        }
    }
}

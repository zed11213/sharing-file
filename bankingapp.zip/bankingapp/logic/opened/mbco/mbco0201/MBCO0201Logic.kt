package jp.co.jsbank.mb.bankingapp.logic.opened.mbco.mbco0201

import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.bean.common.CorporationBean
import jp.co.jsbank.mb.bankingapp.bean.common.Individual
import jp.co.jsbank.mb.bankingapp.bean.common.SoleProprietorBean
import jp.co.jsbank.mb.bankingapp.bean.opened.mbco.mbco0201.MBCO0201RequestBean
import jp.co.jsbank.mb.bankingapp.bean.opened.mbco.mbco0201.MBCO0202Param
import jp.co.jsbank.mb.bankingapp.logic.login.mbsu.MBSU0501Logic
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.repositories.db.common.findAll
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.EPassBookAB0701
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.system.MyApp
import jp.co.jsbank.mb.bankingapp.system.master.PersonalityFlag
import jp.co.jsbank.mb.bankingapp.system.master.UpdateType
import jp.co.jsbank.mb.bankingapp.system.master.UpdateTypeMail
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbco.mbco0201.MBCO0201ErrorInformation
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbco.mbco0201.MBCO0201PageState
import jp.co.jsbank.mb.bankingapp.utils.*
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.CC_RECEIPT_NUMBER
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.MAIL_CONFIRM_TYPE_CASH_CARD
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.MAIL_CONFIRM_TYPE_CORPORATION
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.MAIL_CONFIRM_TYPE_INDIVIDUAL
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.MAIL_CONFIRM_TYPE_SOLE_PROPRIETOR
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.OPENED_MAIL_ADDRESS
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.RECEIPT_NUMBER
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/**
 * MBCO0201ロジック
 */
@HiltViewModel
class MBCO0201Logic @Inject constructor(
    private var webService: RestService,
) : ViewModel() {

    /**
     * MBCO0201ステータス
     */
    var viewStates by mutableStateOf(MBCO0201PageState())
        private set

    /**
     * 初期化
     */
    init {
        // 復元データを取得する
        getRestoreData()
    }

    // 復元データを取得する
    private fun getRestoreData() {
        // 人格区分
        val personType = PreferenceUtil.getPreferenceStringValue(ConstUtil.PERSONALITY_FLAG).toString()
        val accountOpeningAB0701 = MyApp.INSTANCE.findAll(EPassBookAB0701::class.java)
        if (accountOpeningAB0701.isNotEmpty() && !MainActivity.HAS_RECOVERY_FLAG) {
            when (personType) {
                // 個人場合
                PersonalityFlag.INDIVIDUAL_OTHER.code -> {
                    val individualInfo = accountOpeningAB0701[0]?.individual?.fromJson<Individual>()!!
                    viewStates = viewStates.copy(
                        // メールアドレス
                        mailAddress = individualInfo.emailAddress,
                        // 確認メールアドレス
                        confirmEmailAddress = individualInfo.emailAddress,
                        // タイプ
                        type = MAIL_CONFIRM_TYPE_INDIVIDUAL
                    )
                }
                // 法人の場合
                PersonalityFlag.CORPORATION.code -> {
                    val corporationInfo = accountOpeningAB0701[0]?.corporation?.fromJson<CorporationBean>()!!
                    viewStates = viewStates.copy(
                        // メールアドレス
                        mailAddress = corporationInfo.emailAddress,
                        // 確認メールアドレス
                        confirmEmailAddress = corporationInfo.emailAddress,
                        // タイプ
                        type = MAIL_CONFIRM_TYPE_CORPORATION
                    )
                }
                // 個人事業主の場合
                PersonalityFlag.INDIVIDUAL_BUSINESS.code -> {
                    val soleProprietorInfo = accountOpeningAB0701[0]?.soleProprietor?.fromJson<SoleProprietorBean>()!!
                    viewStates = viewStates.copy(
                        // メールアドレス
                        mailAddress = soleProprietorInfo.emailAddress,
                        // 確認メールアドレス
                        confirmEmailAddress = soleProprietorInfo.emailAddress,
                        // タイプ
                        type = MAIL_CONFIRM_TYPE_SOLE_PROPRIETOR
                    )
                }
            }

            // 復元処理済みフラグ
            MainActivity.HAS_RECOVERY_FLAG = true
            MainActivity.SHOW_RETURN_BUTTON_FLAG = true
        } else {
            viewStates = viewStates.copy(
                // タイプ
                type = MainActivity.NAVCTRL?.currentBackStackEntry?.arguments?.get(ConstUtil.DATA).toString(),
            )
        }
    }

    /**
     * メール送信
     */
    private suspend fun emailSend() {
        // 画面IDとイベントID設定
        PreferenceUtil.setScreenIDAndEventID("MBCO0201", "E02")
        val personType = PreferenceUtil.getPreferenceStringValue(ConstUtil.PERSONALITY_FLAG).toString()
        // TODO リクエストパラメータ設定値不明
        val requestBean = MBCO0201RequestBean(
            // 受付番号
            receptionNumber = if (viewStates.type == MAIL_CONFIRM_TYPE_CASH_CARD) KeyStoreUtil().getFromKeyStore(
                CC_RECEIPT_NUMBER
            ) // ktlint-disable max-line-length
            else KeyStoreUtil().getFromKeyStore(RECEIPT_NUMBER),
            // メールアドレス
            emailAddress = viewStates.mailAddress,
            // 処理区分（0：新規　１：更新）
            processKubun = UpdateTypeMail.OPENING_ACCOUNT_INDIVIDUAL.code,
            // 取引種別
            transactionType = "",
            // 更新パターン
            updateType = if (viewStates.type == MAIL_CONFIRM_TYPE_CASH_CARD) {
                UpdateType.UPDATE_TYPE_104.code
            } else {
                when (personType) {
                    // 個人場合
                    PersonalityFlag.INDIVIDUAL_OTHER.code -> {
                        UpdateType.UPDATE_TYPE_101.code
                    }
                    // 法人の場合
                    PersonalityFlag.CORPORATION.code -> {
                        UpdateType.UPDATE_TYPE_102.code
                    }
                    // 個人事業主の場合
                    else -> {
                        UpdateType.UPDATE_TYPE_103.code
                    }
                }
            },
            // 人格区分
            personType = if (viewStates.type == MAIL_CONFIRM_TYPE_CASH_CARD) "" else personType,
        )
        viewModelScope.launch {
            flow {
                ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, requestBean.toJson())
                emit(webService.AB0712())
            }.map {
                PreferenceUtil.setPreferenceStringValue(OPENED_MAIL_ADDRESS, viewStates.mailAddress)
                val param = MBCO0202Param()
                param.emailAddress = viewStates.mailAddress
                param.transactionCode = it.resultDto!!.transactionCode
                param.type = viewStates.type
                // MBCO0202　確認番号入力
                RouteUtil.navTo(
                    RouteName.MBCO0202Page,
                    args = param
                )
            }.catch {
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }.join()
    }

    /**
     * エラーチェック
     */
    suspend fun emailCheck() {

        // エラー情報初期化
        val errorBean = MBCO0201ErrorInformation()
        viewStates = viewStates.copy(errorFlag = false)
        viewStates = viewStates.copy(errorBean = errorBean)
        viewStates = viewStates.copy(errMsgList = listOf())

        // 入力されたメールフォーマットの確認
        if (!Regex("^[a-zA-Z0-9._-]+@[a-zA-Z0-9_-]+(\\.[a-zA-Z0-9_-]+)+\$")
            .matches(viewStates.mailAddress)
        ) {
            errorBean.mailAddressErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean, errorFlag = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB004006V)
                )
            )
        }

        // メールアドレスと確認メールアドレス不一致
        if (viewStates.mailAddress != viewStates.confirmEmailAddress) {
            errorBean.confirmEmailAddressErrorFlag = true
            viewStates = viewStates.copy(errorBean = errorBean, errorFlag = true)
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MyApp.CONTEXT.getString(R.string.MSG_ID_MB004005V)
                )
            )
        }

        if (!viewStates.errorFlag) {
            viewModelScope.launch {
                // メール送信
                emailSend()
            }.join()
        }
    }
}

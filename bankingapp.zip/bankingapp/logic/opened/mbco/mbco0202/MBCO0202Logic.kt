package jp.co.jsbank.mb.bankingapp.logic.opened.mbco.mbco0202

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import jp.co.jsbank.mb.bankingapp.R
import jp.co.jsbank.mb.bankingapp.bean.opened.mbco.mbco0201.MBCO0202Param
import jp.co.jsbank.mb.bankingapp.bean.opened.mbco.mbco0202.AB0807RequestBean
import jp.co.jsbank.mb.bankingapp.bean.opened.mbco.mbco0202.MBCO0202RequestBean
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.system.MyApp
import jp.co.jsbank.mb.bankingapp.system.master.PersonalityFlag
import jp.co.jsbank.mb.bankingapp.system.master.UpdateType
import jp.co.jsbank.mb.bankingapp.ui.pages.common.navigation.RouteName
import jp.co.jsbank.mb.bankingapp.ui.pages.opened.mbco.mbco0202.MBCO0202PageState
import jp.co.jsbank.mb.bankingapp.utils.*
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.CC_RECEIPT_NUMBER
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.MAIL_CONFIRM_TYPE_CASH_CARD
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.MAIL_CONFIRM_TYPE_CORPORATION
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.MAIL_CONFIRM_TYPE_SOLE_PROPRIETOR
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.RECEIPT_NUMBER
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/**
 * MBCO0202ロジック
 */
@HiltViewModel
class MBCO0202Logic @Inject constructor(
    private var webService: RestService,
) : ViewModel() {

    /**
     * MBCO0202ステータス
     */
    var viewStates by mutableStateOf(MBCO0202PageState())
        private set

    /**
     * 初期化
     */
    init {
        val arguments = MainActivity.NAVCTRL?.currentBackStackEntry?.arguments?.get(ConstUtil.DATA).toString()
            .fromJson<MBCO0202Param>()!!
        viewStates.emailAddress = arguments.emailAddress
        viewStates.transactionCode = arguments.transactionCode
        viewStates.type = arguments.type
    }

    /**
     * 確認番号認証
     */
    fun errorCheck(type: String) {
        // エラー情報初期化
        viewStates = viewStates.copy(errMsgList = listOf())

        // 確認番号が空白場合
        if (viewStates.confirmationCode.isBlank()) {
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB002014V),
                        MyApp.CONTEXT.getString(R.string.mbsu0502_page_label_confirmation_no)
                    )
                )
            )
        } else if (!EditCheckUtil.lengthCheck(viewStates.confirmationCode, 6)) {
            // 確認番号は6桁以外
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB007001V),
                        MyApp.CONTEXT.getString(R.string.mbsu0502_page_label_confirmation_no)
                    )
                )
            )
        } else if (!EditCheckUtil.numberCheck(viewStates.confirmationCode)) {
            // 確認番号が半角数字以外
            viewStates = viewStates.copy(
                errMsgList = viewStates.errMsgList.plus(
                    MessageReplaceUtils.messageReplace(
                        MyApp.CONTEXT.getString(R.string.MSG_ID_MB007002V),
                        MyApp.CONTEXT.getString(R.string.mbsu0502_page_label_confirmation_no)
                    )
                )
            )
        }

        if (viewStates.errMsgList.isEmpty()) {
            numberAuthentication(type)
        }
    }

    /**
     * 確認番号認証
     */
    private fun numberAuthentication(type: String) {
        // 画面IDとイベントID設定
        PreferenceUtil.setScreenIDAndEventID("MBCO0202", "E02")
        val personalityFlag = PreferenceUtil.getPreferenceStringValue(ConstUtil.PERSONALITY_FLAG).toString()
        val requestBean = MBCO0202RequestBean()
        val ab0807RequestBean = AB0807RequestBean()
        if (type == MAIL_CONFIRM_TYPE_CASH_CARD) {
            // 受付番号
            ab0807RequestBean.receiptNumber = KeyStoreUtil().getFromKeyStore(CC_RECEIPT_NUMBER)
            // 人格区分
            ab0807RequestBean.personType = ""
            // メールOTP
            ab0807RequestBean.mailOtp = viewStates.transactionCode + viewStates.confirmationCode
            // メールアドレス
            ab0807RequestBean.emailAddress = viewStates.emailAddress
            // 依頼番号
            ab0807RequestBean.requestNo = PreferenceUtil.getPreferenceStringValue(ConstUtil.REQUEST_NO).toString()
            // CIF番号
            ab0807RequestBean.cifNumber = ""
            // 認証キー
            ab0807RequestBean.authCode = ""
            // 更新パターン
            ab0807RequestBean.updateType = UpdateType.UPDATE_TYPE_104.code
        } else {
            // 受付番号
            requestBean.receiptNumber = KeyStoreUtil().getFromKeyStore(RECEIPT_NUMBER)
            // 人格区分
            requestBean.personType = PreferenceUtil.getPreferenceStringValue(ConstUtil.PERSONALITY_FLAG).toString()
            // otp
            requestBean.mailOtp = viewStates.transactionCode + viewStates.confirmationCode
            // メールアドレス
            requestBean.emailAddress = viewStates.emailAddress
            // 更新パターン
            requestBean.updateType = when (personalityFlag) {
                PersonalityFlag.INDIVIDUAL_OTHER.code -> UpdateType.UPDATE_TYPE_101.code
                PersonalityFlag.INDIVIDUAL_BUSINESS.code -> UpdateType.UPDATE_TYPE_103.code
                else -> UpdateType.UPDATE_TYPE_102.code
            }
        }
        if (type == MAIL_CONFIRM_TYPE_CASH_CARD) {
            viewModelScope.launch {
                flow {
                    ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, ab0807RequestBean.toJson())
                    emit(webService.AB0807())
                }.map {
                    // MBCO0301　電話番号認証
                    RouteUtil.navTo(
                        RouteName.MBCO0301Page,
                        args = type
                    )
                }.catch {
                    ErrorUtil().apiErrorCatch(it.message.toString())
                }.collect()
            }
        } else {
            viewModelScope.launch {
                flow {
                    ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, requestBean.toJson())
                    emit(webService.AB0713())
                }.map {
                    when (type) {
                        MAIL_CONFIRM_TYPE_CORPORATION -> {
                            // MBOP1003　申し込み確認（法人）へ遷移する
                            RouteUtil.navTo(
                                RouteName.MBOP1003Page
                            )
                        }
                        MAIL_CONFIRM_TYPE_SOLE_PROPRIETOR -> {
                            // MBOP1002　申し込み確認（個人事業主）
                            RouteUtil.navTo(
                                RouteName.MBOP1002Page
                            )
                        }
                        else -> {
                            if (PreferenceUtil.getPreferenceBooleanValue(ConstUtil.OPENED_EDIT_INFO_FLAG)) {
                                PreferenceUtil.setPreferenceBooleanValue(ConstUtil.OPENED_EDIT_INFO_FLAG, false)
                                RouteUtil.navTo(
                                    RouteName.MBOP1001Page
                                )
                            } else {
                                PreferenceUtil.setPreferenceBooleanValue(ConstUtil.OPENED_EDIT_INFO_FLAG, false)
                                // MBCO0301　電話番号認証
                                RouteUtil.navTo(
                                    RouteName.MBCO0301Page,
                                    args = type
                                )
                            }
                        }
                    }
                }.catch {
                    ErrorUtil().apiErrorCatch(it.message.toString())
                }.collect()
            }
        }
    }
}

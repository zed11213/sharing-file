package jp.co.jsbank.mb.bankingapp.logic.splash.mbco6201

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.gson.Gson
import dagger.hilt.android.lifecycle.HiltViewModel
import io.realm.Realm
import jp.co.jsbank.mb.bankingapp.bean.common.CorporationBean
import jp.co.jsbank.mb.bankingapp.bean.common.Individual
import jp.co.jsbank.mb.bankingapp.bean.common.JagPeerBean
import jp.co.jsbank.mb.bankingapp.bean.common.SoleProprietorBean
import jp.co.jsbank.mb.bankingapp.bean.login.mblg.mblg0304.MBLG0304RequestBean
import jp.co.jsbank.mb.bankingapp.bean.splash.mbco6201.MBCO6201RequestBean
import jp.co.jsbank.mb.bankingapp.logic.common.RecoveryLogic
import jp.co.jsbank.mb.bankingapp.repositories.api.request.RestService
import jp.co.jsbank.mb.bankingapp.repositories.api.request.gateway.GatewayRestService
import jp.co.jsbank.mb.bankingapp.repositories.db.common.create
import jp.co.jsbank.mb.bankingapp.repositories.db.common.deleteAll
import jp.co.jsbank.mb.bankingapp.repositories.db.common.findAll
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.CommonKey
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.EPassBookAB0112
import jp.co.jsbank.mb.bankingapp.repositories.db.entity.EPassBookAB0701
import jp.co.jsbank.mb.bankingapp.system.Config
import jp.co.jsbank.mb.bankingapp.system.JsBankFirebaseMessagingService
import jp.co.jsbank.mb.bankingapp.system.MainActivity
import jp.co.jsbank.mb.bankingapp.system.MainActivity.Companion.PUSH_API_RUN_FLAG
import jp.co.jsbank.mb.bankingapp.system.MainActivity.Companion.RECOVERY_API_ERROR_FLAG
import jp.co.jsbank.mb.bankingapp.system.MyApp
import jp.co.jsbank.mb.bankingapp.system.master.JagApiServiceCode
import jp.co.jsbank.mb.bankingapp.ui.pages.splash.MBCO6201PageState
import jp.co.jsbank.mb.bankingapp.utils.*
import jp.co.jsbank.mb.bankingapp.utils.FirebaseUtil
import jp.co.jsbank.mb.bankingapp.BuildConfig
import android.util.Log
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.ACTIVITY_FLAG_ACCESS_LOGIN
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.ACTIVITY_FLAG_NO_ACCESS_NO_LOGIN
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.API_RESULT_OK
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.API_SERVICE_NAME
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.COMMON_KEY_LABEL
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.JAG_PROFILE_JWT
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.JAG_TRX_DO_CONFIRM
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.JAG_TRX_TYPE_NRM
import jp.co.jsbank.mb.bankingapp.utils.ConstUtil.JAG_TRX_TYPE_TCC
import kotlinx.coroutines.async
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import java.util.*
import javax.inject.Inject

/**
 * MBCO6201ロジック
 */
@HiltViewModel
class MBCO6201Logic @Inject constructor(
    private var webService: RestService,
    private var gatewayWebService: GatewayRestService
) : ViewModel() {

    // ログインステータス
    var viewStates by mutableStateOf(MBCO6201PageState())
        private set

    /**
     * ロカールDB
     */
    private var dbService: Realm = MyApp.INSTANCE

    /**
     * 受付番号
     */
    private var receiptNumber: String = KeyStoreUtil().getFromKeyStore(ConstUtil.RECEIPT_NUMBER)

    private fun openErrorDialog() {
        viewStates = viewStates.copy(recoveryErrorFlag = true)
    }

    fun closeErrorDialog() {
        viewStates = viewStates.copy(recoveryErrorFlag = false)
    }

    /**
     * アプリ起動の処理
     */
    suspend fun doAppStartLogic(onNextPage: () -> Unit) {
        // Firebase ユーザー追跡設定
        val userId = KeyStoreUtil().getFromKeyStore(ConstUtil.USER_ID_TOKEN)
        val deviceId = KeyStoreUtil().getFromKeyStore(ConstUtil.DEVICE_ID)
        if (userId.isNotEmpty()) {
            FirebaseUtil.setUser(userId)
        }
        FirebaseUtil.setCustomKey("deviceId", deviceId)
        Log.d("MBCO6201", "deviceId=$deviceId")
        FirebaseUtil.setCustomKey("appVersion", BuildConfig.VERSION_NAME)
        FirebaseUtil.setCustomKey("buildType", BuildConfig.BUILD_TYPE)
        val deviceModel = android.os.Build.MODEL
        FirebaseUtil.setCustomKey("deviceModel", deviceModel)
        FirebaseUtil.sendLogImmediately("MBCO6201: Start - userId=$userId, deviceId=$deviceId, model=$deviceModel")

        // キーストアキャッシュを有効化
        KeyStoreUtil().activateCache()
        FirebaseUtil.sendLogImmediately("MBCO6201: KeyStore cache activated")

        // 共通キーの保存先は「Realm」を「keystore」に変更するので、登録した端末アンインストール不要ために、下記ソースを追加
        if (!PreferenceUtil.getPreferenceBooleanValue(ConstUtil.OLD_RESTORE_INFO)) {
            accessInfoUpdate()
        }
        // 口座開設入力情報確認修正フラグ
        PreferenceUtil.setPreferenceBooleanValue(ConstUtil.OPENED_EDIT_INFO_FLAG, false)
        // 簡単受付画面遷移元
        PreferenceUtil.setPreferenceBooleanValue(ConstUtil.EASY_RECEPTION_PAGE_HOME, false)
        // ローディング閉じるフラグ
        LoadingUtil.setLoadingValue(closeFlag = true)
        // エラーフラグ
        viewStates = viewStates.copy(errorFlag = false)

        FirebaseUtil.setCustomKey("activityFlag", MainActivity.ACTIVITY_FLAG)
        FirebaseUtil.sendLogImmediately("MBCO6201: ACTIVITY_FLAG=${MainActivity.ACTIVITY_FLAG}")

        // 端末ID取得：OSの標準方法で利用者の端末ID(UUID)を取得して設定する
        if (MainActivity.ACTIVITY_FLAG == ACTIVITY_FLAG_NO_ACCESS_NO_LOGIN) {
            // Jag情報取得
            val list: Array<String> = arrayOf(
                ConstUtil.ACCESS_TOKEN,
                ConstUtil.REFRESH_TOKEN,
                ConstUtil.JBA_ID_TOKEN,
                ConstUtil.USER_ID_TOKEN
            )
            val jagPeerBean = KeyStoreUtil().getJagInfo(list)
            FirebaseUtil.sendLogImmediately("MBCO6201: jagPeerBean - customerId=${jagPeerBean.customerId.isNotBlank()}, userId=${jagPeerBean.userId.isNotBlank()}, accessToken=${jagPeerBean.jagAccessToken.isNotBlank()}, refreshToken=${jagPeerBean.jagRefreshToken.isNotBlank()}")

            // 顧客ID、利用者ID、アクセストークン、リフレッシュトークンが全部空白以外場合
            if (jagPeerBean.customerId.isNotBlank() && jagPeerBean.userId.isNotBlank() &&
                jagPeerBean.jagAccessToken.isNotBlank() && jagPeerBean.jagRefreshToken.isNotBlank()
            ) {
                FirebaseUtil.sendLogImmediately("MBCO6201: Calling az0911() - already logged in")
                MainActivity.ACTIVITY_FLAG = ACTIVITY_FLAG_ACCESS_LOGIN
                // 認可コード取得
                az0911()
                FirebaseUtil.sendLogImmediately("MBCO6201: az0911() completed")
            } else {
                // deviceIdをバンディングされていない場合
                if (!PreferenceUtil.getPreferenceBooleanValue(ConstUtil.DEVICE_BINDING_FLAG)) {
                    FirebaseUtil.sendLogImmediately("MBCO6201: DEVICE_BINDING_FLAG=false, generating new keys")
                    try {
                        // 公開鍵なしの場合、公開鍵、秘密鍵を生成する
                        RSAUtil().initKey()
                        FirebaseUtil.sendLogImmediately("MBCO6201: RSA keys generated successfully")
                    } catch (e: Exception) {
                        FirebaseUtil.sendReport(userId, "RSAInitError", e.message ?: "Unknown")
                        viewStates = viewStates.copy(errorFlag = true)
                        LoadingUtil.setLoadingValue(closeFlag = false)
                        return
                    }
                    // デバイス初回作成
                    val uuid = UUID.randomUUID().toString()
                    KeyStoreUtil().jagInfoSave(
                        JagPeerBean(deviceId = uuid)
                    )
                    // トークンクリア
                    KeyStoreUtil().jagInfoClear()
                    FirebaseUtil.sendLogImmediately("MBCO6201: Calling az0901() - public key registration")
                    // 公開鍵登録APIを呼び出す
                    az0901()
                    FirebaseUtil.sendLogImmediately("MBCO6201: az0901() completed")
                } else {
                    FirebaseUtil.sendLogImmediately("MBCO6201: DEVICE_BINDING_FLAG=true, skipping key generation")
                }

                // 復元処理
                if (!viewStates.errorFlag && receiptNumber != "") {
                    // 復元処理を呼び出す
                    val result = RecoveryLogic(webService).restorationProcess(receiptNumber)
                    if (!result) {
                        RECOVERY_API_ERROR_FLAG = true
                        openErrorDialog()
                    } else {
                        val accountOpeningAB0701 = MyApp.INSTANCE.findAll(EPassBookAB0701::class.java)
                        if (accountOpeningAB0701.isNotEmpty()) {
                            val individual = accountOpeningAB0701[0]?.individual?.fromJson<Individual>()!!
                            val corporation = accountOpeningAB0701[0]?.corporation?.fromJson<CorporationBean>()!!
                            val soleProprietor =
                                accountOpeningAB0701[0]?.soleProprietor?.fromJson<SoleProprietorBean>()!!
                            if (individual.receiptNumber.isNotBlank() ||
                                corporation.receiptNumber.isNotBlank() ||
                                soleProprietor.receiptNumber.isNotBlank()
                            ) {
                                MainActivity.SHOW_RETURN_BUTTON_FLAG = false
                                // 復元ダイアログを呼び出す
                                viewStates = viewStates.copy(isRecoveryFlag = true)
                                return
                            }
                        }
                    }
                    LoadingUtil.setLoadingValue(closeFlag = false)
                }
            }
        } else if (MainActivity.ACTIVITY_FLAG == ACTIVITY_FLAG_ACCESS_LOGIN) {
            FirebaseUtil.sendLogImmediately("MBCO6201: ACTIVITY_FLAG_ACCESS_LOGIN, calling az0911()")
            // 認可コード取得
            az0911()
            FirebaseUtil.sendLogImmediately("MBCO6201: az0911() completed")
        }

        FirebaseUtil.setCustomKey("errorFlag", viewStates.errorFlag.toString())
        FirebaseUtil.sendLogImmediately("MBCO6201: errorFlag=${viewStates.errorFlag}, proceeding to getDeptList")

        if (!viewStates.errorFlag) {
            FirebaseUtil.sendLogImmediately("MBCO6201: No error, calling getDeptList")
            // ローカルDBで保存した復元データを削除する
            delete()
            // プッシュ通知登録失敗場合
            if (PreferenceUtil.getPreferenceStringValue(ConstUtil.PUSH_OK_FLAG) == "1") {
                if (!JsBankFirebaseMessagingService().isNullFirebaseToken()) {
                    pushInfoSignUp()
                }
            }
            getDeptList(onNextPage)
            LoadingUtil.setLoadingValue(closeFlag = false)
        } else {
            FirebaseUtil.sendLogImmediately("MBCO6201: errorFlag=true, skipping getDeptList")
            // エラーがある場合もキーストアキャッシュを無効化して終了
            KeyStoreUtil().deactivateCache()
        }

        FirebaseUtil.sendLogImmediately("MBCO6201: doAppStartLogic completed")
        // キーストアキャッシュを無効化
        KeyStoreUtil().deactivateCache()
    }

    /**
     * 共通キーの保存先は「Realm」を「keystore」に変更するので、登録した端末アンインストール不要ために、下記ソースを追加
     */
    private fun accessInfoUpdate() {
        // 共通鍵
        val commonInfo = Realm.getDefaultInstance().findAll(CommonKey::class.java)
        if (commonInfo.isNotEmpty()) {
            KeyStoreUtil().saveToKeyStore(COMMON_KEY_LABEL, commonInfo[0]!!.commonKey)
        }

        // 共通鍵
        val commonKey = KeyStoreUtil().getFromOldKeyStore(COMMON_KEY_LABEL)
        if (commonKey.isNotEmpty()) {
            KeyStoreUtil().saveToKeyStore(COMMON_KEY_LABEL, commonKey)
        }

        // トランザクションID
        val jagResTrxId = KeyStoreUtil().getFromOldKeyStore(ConstUtil.JAG_RES_TRXID)
        if (jagResTrxId.isNotEmpty()) {
            KeyStoreUtil().saveToKeyStore(ConstUtil.JAG_RES_TRXID, jagResTrxId)
        }

        // アクセストークン
        val jagAccessToken = KeyStoreUtil().getFromOldKeyStore(ConstUtil.ACCESS_TOKEN)
        if (jagAccessToken.isNotEmpty()) {
            KeyStoreUtil().saveToKeyStore(ConstUtil.ACCESS_TOKEN, jagAccessToken)
        }

        // リフレッシュトークン
        val jagRefreshToken = KeyStoreUtil().getFromOldKeyStore(ConstUtil.REFRESH_TOKEN)
        if (jagRefreshToken.isNotEmpty()) {
            KeyStoreUtil().saveToKeyStore(ConstUtil.REFRESH_TOKEN, jagRefreshToken)
        }

        // 顧客ID
        val customerId = KeyStoreUtil().getFromOldKeyStore(ConstUtil.JBA_ID_TOKEN)
        if (customerId.isNotEmpty()) {
            KeyStoreUtil().saveToKeyStore(ConstUtil.JBA_ID_TOKEN, customerId)
        }

        // 利用者ID
        val userId = KeyStoreUtil().getFromOldKeyStore(ConstUtil.USER_ID_TOKEN)
        if (userId.isNotEmpty()) {
            KeyStoreUtil().saveToKeyStore(ConstUtil.USER_ID_TOKEN, userId)
        }

        // デバイスID
        val deviceId = KeyStoreUtil().getFromOldKeyStore(ConstUtil.DEVICE_ID)
        if (deviceId.isNotEmpty()) {
            KeyStoreUtil().saveToKeyStore(ConstUtil.DEVICE_ID, deviceId)
        }

        // 受付番号
        val receiptNumber = KeyStoreUtil().getFromOldKeyStore(ConstUtil.RECEIPT_NUMBER)
        if (receiptNumber.isNotEmpty()) {
            KeyStoreUtil().saveToKeyStore(ConstUtil.RECEIPT_NUMBER, receiptNumber)
        }

        // 受付番号(CC発行)
        val ccReceiptNumber = KeyStoreUtil().getFromOldKeyStore(ConstUtil.CC_RECEIPT_NUMBER)
        if (ccReceiptNumber.isNotEmpty()) {
            KeyStoreUtil().saveToKeyStore(ConstUtil.CC_RECEIPT_NUMBER, ccReceiptNumber)
        }

        // パスワード
        val pin = KeyStoreUtil().getFromOldKeyStore(ConstUtil.PIN)
        if (pin.isNotEmpty()) {
            KeyStoreUtil().saveToKeyStore(ConstUtil.PIN, pin)
        }

        // CC暗証番号
        val ccPassword = KeyStoreUtil().getFromOldKeyStore(ConstUtil.CC_PASSWORD)
        if (ccPassword.isNotEmpty()) {
            KeyStoreUtil().saveToKeyStore(ConstUtil.CC_PASSWORD, ccPassword)
        }

        // IBパスワード
        val ibPassword = KeyStoreUtil().getFromOldKeyStore(ConstUtil.IB_PASSWORD)
        if (ibPassword.isNotEmpty()) {
            KeyStoreUtil().saveToKeyStore(ConstUtil.IB_PASSWORD, ibPassword)
        }

        // 受付番号発行
        val receiptNumberIssue = KeyStoreUtil().getFromOldKeyStore(ConstUtil.RECEIPT_NUMBER_ISSUE)
        if (receiptNumberIssue.isNotEmpty()) {
            KeyStoreUtil().saveToKeyStore(ConstUtil.RECEIPT_NUMBER_ISSUE, receiptNumberIssue)
        }

        PreferenceUtil.setPreferenceBooleanValue(ConstUtil.OLD_RESTORE_INFO, true)
    }

    /**
     * AZ0901 公開鍵登録
     */
    private suspend fun az0901() {
        val param = MBCO6201RequestBean()
        val list: Array<String> = arrayOf(
            ConstUtil.DEVICE_ID
        )
        val jagPeerBean = KeyStoreUtil().getJagInfo(list)
        // デバイスID
        val deviceId = jagPeerBean.deviceId

        // パラメータを下記よに設定する
        // デバイスID
        param.jagDeviceId = deviceId
        // アプリケーションID
        param.jagApplicationId = Config.getAppId()
        // 公開鍵
        param.jagPublicKey = RSAUtil().loadPublicKeyByFile()
        // チャレンジトークン
        param.jagChallengeToken = RSAUtil().encryptAESByJavaCrypt(
            deviceId,
            String(Base64.getDecoder().decode(ConstUtil.JAG_ENV_SECRET_KEY)),
            String(Base64.getDecoder().decode(ConstUtil.JAG_ENV_CLIENT_SECRET_KEY))
        )
        // TRX種別
        param.jagTrxType = JAG_TRX_TYPE_TCC
        // トランザクションID
        param.jagTrxId = ""
        // API サービス名称
        PreferenceUtil.setPreferenceStringValue(API_SERVICE_NAME, JagApiServiceCode.AZ0901.value)

        viewModelScope.async {
            flow {
                emit(gatewayWebService.AZ0901(param))
            }.map {
                // Jag情報ローカルに保存する
                KeyStoreUtil().jagInfoSave(JagPeerBean(jagTrxId = it.jagTrxId, jagEncryptedKey = it.jagEncryptedKey))
                // TCC確定
                az0906()
            }.catch {
                viewStates = viewStates.copy(errorFlag = true)
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }.await()
    }

    /**
     * AZ0906 TCC確定
     */
    private suspend fun az0906() {
        val param = MBCO6201RequestBean()
        val list: Array<String> = arrayOf(
            ConstUtil.JAG_RES_TRXID,
            ConstUtil.COMMON_KEY_LABEL,
            ConstUtil.DEVICE_ID
        )
        val jagPeerBean = KeyStoreUtil().getJagInfo(list)
        // デバイスID
        val deviceId = jagPeerBean.deviceId
        // トランザクションID
        val trxId = jagPeerBean.jagTrxId
        // チャレンジトークン
        val challengeToken = RSAUtil().encryptAESByJavaCrypt(
            trxId,
            RSAUtil().rsaDecrypt(jagPeerBean.jagEncryptedKey),
            String(Base64.getDecoder().decode(ConstUtil.JAG_ENV_CLIENT_SECRET_KEY))
        )

        // パラメータを下記よに設定する
        // デバイスID
        param.jagDeviceId = deviceId
        // アプリケーションID
        param.jagApplicationId = Config.getAppId()
        // トランザクションID
        param.jagTrxId = trxId
        // チャレンジトークン
        param.jagChallengeToken = challengeToken
        // 確定キャンセル要求
        param.jagDoCancel = JAG_TRX_DO_CONFIRM
        // API サービス名称
        PreferenceUtil.setPreferenceStringValue(API_SERVICE_NAME, JagApiServiceCode.AZ0906.value)

        viewModelScope.async {
            flow {
                emit(gatewayWebService.AZ0906(param))
            }.map {
                if (it != API_RESULT_OK) {
                    viewStates = viewStates.copy(errorFlag = true)
                } else {
                    // デバイスバンディングフラグをtrueに設定する
                    PreferenceUtil.setPreferenceBooleanValue(ConstUtil.DEVICE_BINDING_FLAG, true)
                }
            }.catch {
                viewStates = viewStates.copy(errorFlag = true)
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }.await()
    }

    /**
     * AZ0911 認可コード取得
     */
    private suspend fun az0911() {
        viewModelScope.async {
            val param = MBCO6201RequestBean()
            val list: Array<String> = arrayOf(
                ConstUtil.JAG_RES_TRXID,
                ConstUtil.DEVICE_ID
            )
            val jagPeerBean = KeyStoreUtil().getJagInfo(list)

            // JAG PROFILE JWTをローカルに保存する
            val jagProfile = JWTUtil().createJWT()
            PreferenceUtil.setPreferenceStringValue(JAG_PROFILE_JWT, jagProfile)

            // JAG PROFILE JWT
            param.jagProfile = jagProfile
            // デバイスID
            param.jagDeviceId = jagPeerBean.deviceId
            // アプリケーションID
            param.jagApplicationId = Config.getAppId()
            // TRX種別
            param.jagTrxType = JAG_TRX_TYPE_NRM
            // トランザクションID
            param.jagTrxId = jagPeerBean.jagTrxId
            // API サービス名称
            PreferenceUtil.setPreferenceStringValue(API_SERVICE_NAME, JagApiServiceCode.AZ0911.value)
            flow {
                emit(gatewayWebService.AZ0911(param))
            }.map {
                // Jag情報ローカルに保存する
                KeyStoreUtil().jagInfoSave(
                    JagPeerBean(
                        jagTrxId = it.jagTrxId,
                        jagAccessToken = it.jagAccessToken,
                        jagRefreshToken = it.jagRefreshToken
                    )
                )
            }.catch {
                viewStates = viewStates.copy(errorFlag = true)
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }.await()
    }

    /**
     * ローカルDBで保存した復元データを削除する
     */
    fun delete() {
        // ローカルDBで保存した復元データを削除する
        RealmClearUtil.realmClear()
        MainActivity.HAS_RECOVERY_FLAG = false
        MainActivity.SHOW_RETURN_BUTTON_FLAG = true

        // 復元受付番号クリア
        KeyStoreUtil().saveToKeyStore(ConstUtil.RECEIPT_NUMBER, "")
        // 復元受付番号クリア(CC発行)
        KeyStoreUtil().saveToKeyStore(ConstUtil.CC_RECEIPT_NUMBER, "")

        // MBCO0405完了API実行済みフラグクリア
        PreferenceUtil.setPreferenceBooleanValue(ConstUtil.MBCO0405_COMPLETED, false)

        // 丁目クリア
        PreferenceUtil.removePreferenceStringValue(ConstUtil.CHOME)

        // ダイアログをクローズ
        viewStates = viewStates.copy(isRecoveryFlag = false)
    }

    /**
     * 店舗リストを取得する
     *
     */
    private suspend fun getDeptList(onNextPage: () -> Unit) {
        FirebaseUtil.sendLogImmediately("MBCO6201: getDeptList started")
        // 画面IDとイベントID設定
        PreferenceUtil.setScreenIDAndEventID("MBCO6201", "E01")
        viewModelScope.async {
            flow {
                ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST)
                emit(webService.AB0112())
            }.map {
                FirebaseUtil.sendLogImmediately("MBCO6201: AB0112 success, saving dept list")
                dbService.deleteAll(EPassBookAB0112::class.java)
                val ab0112 = EPassBookAB0112()
                ab0112.id = UUID.randomUUID().toString()
                ab0112.deptList = Gson().toJson(it.resultDto)
                dbService.create(ab0112)
                onNextPage.invoke()
            }.catch {
                FirebaseUtil.sendReport("", "AB0112Error", it.message ?: "Unknown")
                ErrorUtil().apiErrorCatch(it.message.toString())
                // API失敗時も次のページへ進む（エラー表示後）
                viewStates = viewStates.copy(errorFlag = true)
                onNextPage.invoke()
            }.collect()
        }.await()
    }

    /**
     * プッシュ通知登録
     */
    private suspend fun pushInfoSignUp() {
        // 画面IDとイベントID設定
        PreferenceUtil.setScreenIDAndEventID("MBCO6201", "E01")
        // パラメータ設定
        val requestBean = MBLG0304RequestBean()
        requestBean.identity = PreferenceUtil.getPreferenceStringValue(ConstUtil.PUSH_TOKEN_IDENTIFY).toString()
        requestBean.address = PreferenceUtil.getPreferenceStringValue(ConstUtil.PUSH_TOKEN).toString()
        // サービスを呼び出す
        viewModelScope.async {
            flow {
                ApiRequestUtil.setApiParam(ConstUtil.API_METHOD_TYPE_POST, requestBean.toJson())
                emit(webService.AB0121())
            }.map {
                PUSH_API_RUN_FLAG = true
                if (it.resultDto != API_RESULT_OK) {
                    PreferenceUtil.setPreferenceStringValue(ConstUtil.PUSH_OK_FLAG, "1")
                } else {
                    PreferenceUtil.removePreferenceStringValue(ConstUtil.PUSH_OK_FLAG)
                }
            }.catch {
                ErrorUtil().apiErrorCatch(it.message.toString())
            }.collect()
        }.await()
    }
}

package jp.co.jsbank.mb.bankingapp.animation

import androidx.compose.animation.core.TweenSpec

fun simpleChartAnimation() = TweenSpec<Float>(durationMillis = 500)
